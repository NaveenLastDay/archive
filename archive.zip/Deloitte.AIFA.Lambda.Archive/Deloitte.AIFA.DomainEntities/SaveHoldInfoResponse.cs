﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
    public class SaveHoldInfoResponse
    {
        public string OutputMessage { get; set; }
        public Int32? HoldId { get; set; }
        public string HoldNumber { get; set; }
    }
}
