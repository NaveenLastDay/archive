﻿using Amazon.SQS.Model;
using Deloitte.AIFA.DataModels;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Deloitte.AIFA.IMessageServices.Contracts
{
	public interface ISQSService
	{
		Task<SendMessageResponse> SendMessageAsync(SendMessageRequestModel model);
		Task<ReceiveMessageResponse> ReceiveMessageAsync();
		Task<DeleteMessageBatchResponse> DeleteMessageBatchAsync(IList<DeleteMessageBatchRequestModel> entries);
		Task<SendMessageBatchResponse> SendMessageBatchAsync(IList<SendMessageRequestModel> entries);
	}
}
