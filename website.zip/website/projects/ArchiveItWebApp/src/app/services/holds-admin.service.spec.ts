import { TestBed } from '@angular/core/testing';

import { HoldsService } from './holds-admin.service';

describe('HoldsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: HoldsService = TestBed.get(HoldsService);
    expect(service).toBeTruthy();
  });
});
