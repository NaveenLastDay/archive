import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormArray } from '@angular/forms';
import { PeoplePickerService } from '../../../services/MDREmployeeeDetails.service';
import { ModalService } from '../../shared/modal';
import { ActivatedRoute, Router, NavigationEnd } from '@angular/router';
import { NotifierService } from 'angular-notifier';
import { Form3283SService } from '../../../services/form3283-s.service';
import { NgxSpinnerService } from "ngx-spinner";
import { PubsubService } from '../../../services/pubsub.service';
import { LoginuserdetailsService } from '../../../services/loginuserdetails.service';
import { NativeDateAdapter, DateAdapter, MAT_DATE_FORMATS, MatAutocompleteTrigger } from '@angular/material';
import { formatDate } from '@angular/common';
import { ArchiveHomeService } from '../../../services/archive-home.service';
import { UserActions } from '../../../models/archive-role.model';
import { BehaviorSubject, Subscription } from 'rxjs';
import { distinctUntilChanged, debounceTime } from 'rxjs/operators';
import * as moment from 'moment';

export const PICK_FORMATS = {
  parse: { dateInput: { month: 'short', year: 'numeric', day: 'numeric' } },
  display: {
    dateInput: 'input',
    monthYearLabel: { year: 'numeric', month: 'short' },
    dateA11yLabel: { year: 'numeric', month: 'long', day: 'numeric' },
    monthYearA11yLabel: { year: 'numeric', month: 'long' }
  }
};

//class PickDateAdapter extends NativeDateAdapter {
export class PickDateAdapter extends NativeDateAdapter {
  format(date: Date, displayFormat: Object): string {
    if (displayFormat === 'input') {
      return formatDate(date, 'MM/dd/yyyy', this.locale);;
    } else {
      return date.toDateString();
    }
  }
}


@Component({
  selector: 'app-form3283-s',
  templateUrl: './form3283-s.component.html',
  styleUrls: ['./form3283-s.component.css'],
  providers: [
    { provide: DateAdapter, useClass: PickDateAdapter },
    { provide: MAT_DATE_FORMATS, useValue: PICK_FORMATS }
  ]
})
export class Form3283SComponent implements OnInit {
  login_form: FormGroup;
  myForm: FormGroup;
  reasonList: any[] = [];
  selectedAdditionalDetails: string = "";
  selectedActionsToBeTaken: string = "";
  AdditionalDetails: string = "";
  ActionsToBeTaken: string = "";
  AddDescCount: number = 0;
  ActionsCount: number = 0;
  selectedAuditPICViewName: string = "";
  selectedAuditPPDViewName: string = "";
  ADCEDDate: any;
  users: any[];
  selectedAuditPIC: string = "";
  selectedAuditPPD: string = "";
  archiveNumber: any;
  currentUrl: string;
  form3283sinfo: any;
  ArchivePartner: string;
  TypeOfEntity: string;
  EDCDDate: any;
  RDCDDate: any;
  minDate: any;
  IsRequestor: boolean = true;
  isEnableSubmit: boolean = false;
  isEnableCancel: boolean = true;
  reasonIDs: any;
  reasonarraylistlength: number;
  IsInCorrectPerson: boolean = false;
  ReasonDescription: string = "";
  FormId: any;
  selectedReasonDescription: string = "";
  AuditPICName: string = "";
  AuditPPDName: string = "";
  ActionItems: any[] = [];
  AuditPICActionStatusDesc: string = "";
  AuditPPDActionStatusDesc: string = "";
  showSubmitCancelButtons: boolean;
  EnableEditMode: boolean = false;
  ActionItemId: any;
  Approveinfo: any;
  ApproverRole: any;
  AuditPICApprovedDate: any = null;
  AuditPPDApprovedDate: any = null;
  ArchivePartnerStatusDesc: any = "";
  ArchivePartnerApprovedDate: any = null;
  IsSubmitButtonEnable: boolean;
  UserAlias: string;
  IsApprover: boolean;
  AwaitingStatus: boolean;
  AwaitingPPDStatus: boolean;
  AwaitingPICStatus: boolean;
  AwaitingPartnerStatus: boolean;
  searchString: string;
  selectedPIC: any;
  FormStatusInfo: any;
  FormStatus: any;
  FormStatusDate: any;
  IsReasonRequired: boolean;
  IsSelectReason: boolean;
  IsRejected: boolean = false;
  AllframesUp: any;
  ApproversAllFramesUp: any;
  IsCancelButtonEnable: boolean = true;
  EditCount: number = 0;
  EditFormText: string = "";
  selectedRejectReason: any;
  IsEnableConfirm: any = false;
  totalRejectCSS: any;
  requireEditsCSS: any;
  editText: any;
  rejectDetails: any;
  selectedRejection: boolean;
  reject_form: FormGroup;
  RejectionReason: any;
  ArchivePartnerUserAlias: any;
  RejectedBy: any;
  RejectedDate: any;
  SubmitOrSaveButtonText: string = "Submit";
  AllReasonDescriptions: string = "";
  expPanelHeight: boolean = true;
  canUpdate: boolean = false;
  SubmissionDate: any = null;
  Forms: any[] = [];
  EnableMainForm: boolean = true;
  FormDetails: any[] = [];
  isExpanded: boolean = true;
  disablePanel: boolean;
  isApprovePanelExpanded: boolean;

  roleMapping = new UserActions();
  IsEditButtonEnable: boolean = false;
  popUpHeaderText: string;
  ChangedTo: string;
  Identifier: string;
  EnableEditPICPPD: boolean;
  hoverEditPPDText: any = false;
  hoverEditPICText: any = false;
  UserName: any;
  popupAuditPICViewName: string;
  popupAuditPPDViewName: string;
  IsInCorrectPICPerson: boolean = false;
  IsInCorrectPPDPerson: boolean = false;
  rolecode: string;
  proposedADCEDInfo: string = "If, and at the earliest point at which, the Engagement Partner identifies any actual or potential circumstance that may or will result in the final audit file not being assembled and archived by the expected documentation completion date,1 the Engagement Partner shall obtain approval from the Audit PIC and Audit PPD to complete the assembly and archival of the final audit file by the approved documentation completion extension date (i.e., a date between 30 and 45 days from the report release date or the date fieldwork was substantially completed, if no report was issued)."

  lastSearchKeyword: string = '';
  currentSearchKeyword: string = '';
  EDCDinfoCriteria : Subscription;

  private _subject: BehaviorSubject<string> = new BehaviorSubject<string>("");
  archiveDueDateCriteria: any;
  archiveDueDate: any;
  deliverableType: any;
  edcdinfoMsg: string;
  rdcdinfomsg: string;
  DateDrivesEDCD: string;
  newforminfo: any[];
  LatestRDCDDate: Date;
  IsFormEnabled: any;
  @ViewChild('autoCompleteInputPIC', { read: MatAutocompleteTrigger, static: false }) autoCompletePIC: MatAutocompleteTrigger;
  @ViewChild('autoCompleteInputPPD', { read: MatAutocompleteTrigger, static: false }) autoCompletePPD: MatAutocompleteTrigger;

  constructor(public fb: FormBuilder, private peoplePickerService: PeoplePickerService, private pubsub: PubsubService,
    private modalService: ModalService, private notifier: NotifierService, private forminfo: Form3283SService,
    private archiveHomeService: ArchiveHomeService,
    private activatedRoute: ActivatedRoute, private router: Router,
    private SpinnerService: NgxSpinnerService, private loginservice: LoginuserdetailsService) {
    router.events.subscribe((_: NavigationEnd) => this.currentUrl = this.router.url);
    this.getEDCDInfoCriteria();

    this.login_form = fb.group({
      'ProposedADCED': [null, Validators.required],
      'ActionsToBeTaken': ['', Validators.compose([Validators.required, Validators.minLength(5)])],
      'AdditionalDetails': ['', Validators.compose([Validators.required, Validators.minLength(5)])],
      'auditPIC': ['', Validators.required],
      'auditPPD': ['', Validators.required],
      'terms': [false]
    });

    this.reject_form = fb.group({
      'EditFormText': ['', Validators.compose([Validators.required, Validators.minLength(5)])]
    });

    this.myForm = this.fb.group({
      'reasonCheckbox': [false, Validators.requiredTrue],
      'reasonCheckboxinput': ['', Validators.compose([Validators.required, Validators.minLength(5)])],
      reasonFormList: this.fb.array([], Validators.required)
    });
  }
  scrollEvent = (event: any): void => {
    if (this.autoCompletePIC && this.autoCompletePIC.openPanel)
      this.autoCompletePIC.updatePosition();
    if (this.autoCompletePPD && this.autoCompletePPD.openPanel)
      this.autoCompletePPD.updatePosition();
  };
  getEDCDInfoCriteria(){
    this.EDCDinfoCriteria = this.pubsub.getEDCDinfoCriteria().subscribe(
      message =>{
        this.archiveDueDateCriteria = message.text.archiveDueDateCriteria;
        this.deliverableType = message.text.deliverableType;
        var date = moment(message.text.originalDate).format("MM/DD/YYYY");
        this.DateDrivesEDCD = date;
        if (this.archiveDueDateCriteria == 'DateEngagementCeased') {
          this.edcdinfoMsg = `Date driving the EDCD is the Date Engagement Ceased of ${date}.`;
          this.rdcdinfomsg = `The calculated required documentation completion date for this archive is 45 days past the Date Engagement Ceased of ${date}.`;
        }
        else if (this.archiveDueDateCriteria == 'EarlyDeliverableReleaseDate') {
          this.edcdinfoMsg = `Date driving the EDCD is the earliest deliverable release date or group audit report release date of ${this.deliverableType} : ${date}.`;
          this.rdcdinfomsg = `The calculated required documentation completion date for this archive is 45 days past the earliest deliverable release date or group audit report release date of ${this.deliverableType} : ${date}.`;
        }
        else if (this.archiveDueDateCriteria == 'DateFieldworkWasSubstantiallyCompleted') {
          this.edcdinfoMsg = `Date driving the EDCD is the Date Fieldwork Related to this Archive was Substantially Completed, Date of Other issued Communications or Letters or Group Audit Report Release Date of ${date}.`;
          this.rdcdinfomsg = `The calculated required documentation completion date for this archive is 45 days past the Date Fieldwork Related to this Archive was Substantially Completed, Date of Other issued Communications or Letters or Group Audit Report Release Date of ${date}.`;
        }
        else if (this.archiveDueDateCriteria == 'EstimatedReportReleaseDate') {
          this.edcdinfoMsg = `Date driving the EDCD is the Estimated Date of ${date}.`;
          this.rdcdinfomsg = `The calculated required documentation completion date for this archive is 45 days past the Estimated Date of ${date}.`;
        }
      }
    )
  }
  ngOnInit() {
    this.archiveNumber = this.activatedRoute.snapshot.parent.paramMap.get('aN');
    window.addEventListener('scroll', this.scrollEvent, true);
    this.UserAlias = this.loginservice.GetUserAlias();
    this.UserName = this.loginservice.GetUserName();
    //this.SpinnerService.show();
    this.GetFormStatus();
    this.getFormInfo(this.UserAlias);
    this.archiveHomeService.SyncArchiveDueDate(this.archiveNumber,this.UserAlias);
   }

   GetFormStatus(){
     this.archiveHomeService.GetForm3283SStatus(this.archiveNumber).subscribe(
       data => {
         this.IsFormEnabled = data.isFormEnabled;
         if(this.IsFormEnabled == 1){
          this.router.navigate(['/archive/myarchives/' + this.archiveNumber + '/form3283S']);
         }
         else{
          this.router.navigate(['/archive/myarchives/' + this.archiveNumber + '/archivehome']);
         }
       }
     )
   }



  ngDoCheck() {
    this.validations();
    this.roleMapping = this.pubsub.getRoleMappingResult();

  }

  validations() {
    if (
      (this.ADCEDDate != "") &&
      // (this.IsSelectReason !=false) &&
      (this.AdditionalDetails != "") &&
      (this.ActionsToBeTaken != "") &&
      (this.selectedAuditPICViewName != "") &&
      (this.selectedAuditPPDViewName != "") && (this.FormId == 0)
    ) {
      this.isEnableSubmit = true;
    }
    else if (
      (this.ADCEDDate != "") &&
      // (this.IsSelectReason !=false) &&
      (this.AdditionalDetails != "") &&
      (this.ActionsToBeTaken != "") &&
      (this.selectedAuditPICViewName != "") &&
      (this.selectedAuditPPDViewName != "") && (this.FormId != 0)
    ) {
      if (this.FormStatus == "Submitted" && this.IsApprover == false) {
        this.isEnableSubmit = false;
        this.isEnableCancel = false;
      }
      else if (this.FormStatus == "Submitted" && this.IsApprover == true) {
        var partnerlist = this.ActionItems[0].filter((x) => { return x.actionItemIdentifier == "ArchivePartner" });
        var statusdesc = partnerlist.map(x => x.actionItemStatusDescription);
        var partneralias = partnerlist.map(x => x.actionItemAssignedTo);
        if (this.UserAlias == partneralias) {

          if (statusdesc == "Awaiting Approval") {
            this.isEnableSubmit = true;
            this.EnableEditMode = true;
          }
          else if (statusdesc == "Approved") {
            this.isEnableSubmit = false;
          }
        }
      }
      else if (this.FormStatus == "Approved") {
        this.isEnableSubmit = false;
      }
      else if (this.FormStatus == "Rejected") {
        if(this.IsApprover == true){
          this.isEnableSubmit = true;
          this.isEnableCancel = true;
        }
        else if (this.IsApprover == false){
          if(this.UserAlias != this.ArchivePartnerUserAlias){
            this.isEnableSubmit = true;
            this.isEnableCancel = true;
          }
          else {
            this.isEnableSubmit = false;
            this.isEnableCancel = false;
          }
        }
      }
      else if (this.FormStatus == null) {
        this.isEnableSubmit = true;
      }

    }
    else if (this.FormId != 0 && this.IsApprover == true) {
      this.isEnableSubmit = true;
    }
    else {
      this.isEnableSubmit = false;
    }
  }
  afterMainPanelClosed() {
    this.isExpanded = false;
  }
  afterMainPanelOpened() {
    this.isExpanded = true;
  }
  afterPanelClosed() {
    this.isApprovePanelExpanded = false;
  }
  afterPanelOpened() {
    this.isApprovePanelExpanded = true;
  }

  //Reason capturing from checkbox

  onChangeEventFunc(reasonId, isChecked: boolean) {
    if (reasonId == 5 && isChecked == true) {
      this.IsReasonRequired = true;
    }
    else {
      this.IsReasonRequired = false;
    }
    this.reasonList[0].find((x) => x.reasonTypeId == reasonId).isSelectedBefore = isChecked;
    var array = this.reasonList[0].filter((x) => { return x.isSelectedBefore == true });
    const reasonFormList: FormArray = array as FormArray;
    if (reasonFormList.length > 0) {
      this.IsSelectReason = false;
    }
    else {
      this.IsSelectReason = true;
    }

  }

  // Entered ADCED Date
  onChange(event: any) {
    this.ADCEDDate = event.toISOString();
  }

  onKeyUp(event) {

    this.AddDescCount = 3000 - event.target.value.length;

  }

  onKey(event) {

    this.ActionsCount = 3000 - event.target.value.length;

  }

  onKey2(event) {
    this.EditCount = 500 - event.target.value.length;
    this.editText = event.target.value;

    if (this.editText = "" || this.editText.length < 5) {
      this.IsEnableConfirm = false;
    }
    else {
      this.IsEnableConfirm = true;
    }
  }
  OpenAuditPICModalDialog() {
    this.modalService.openWithCustomWidth('auditpic-form-modal', "595");
  }

  Reject(PageUrl) {
    if (this.UserAlias == this.selectedAuditPPD || this.UserAlias == this.selectedAuditPIC) {
      this.isEnableCancel = false;
      this.FinalReject(PageUrl);
    }
    else {
      this.modalService.openWithCustomWidth('reject-form-modal', "595");
      this.IsEnableConfirm = false;
      this.EditFormText = "";
      this.requireEditsCSS = {
        'border-color': '#E6E6E6'
      }
    }
  }
  totalReject(status: boolean) {
    this.selectedRejection = status;
    if (status === true) {
      if (this.EditFormText == "" || this.editText.length >= 5) {
        this.IsEnableConfirm = true;
        this.totalRejectCSS = {
          'border-color': '#007CB0'
        }
        this.requireEditsCSS = {
          'border-color': '#E6E6E6'
        }
      }

      else if (this.editText.length < 5) {
        this.IsEnableConfirm = false;
        this.requireEditsCSS = {
          'border-color': '#007CB0'
        }
        this.totalRejectCSS = {
          'border-color': '#E6E6E6'
        }
      }
    }
    else if (status === false) {
      if (this.EditFormText == "" || this.editText.length < 5) {
        this.IsEnableConfirm = false;
        this.totalRejectCSS = {
          'border-color': '#E6E6E6'
        }
      }
    }
  }


  Confirm(PageUrl) {
    if (this.selectedRejection == true) {
      this.FinalReject(PageUrl);
    }
    else {
      this.requireEditRejection(PageUrl);
    }
  }

  FinalReject(PageUrl) {
    this.isEnableCancel = false;
   // this.SpinnerService.show();
    if (this.ActionItemId == undefined || this.ActionItemId == null) {
      this.notifier.notify("error", "Dont have permission to approve");
    }
    else {
      this.ActionItemId;
      var parameters = {
        "ActionItemId": this.ActionItemId,
        "RejectedBy": '',
        "ArchiveNumber": this.archiveNumber
      }

      this.forminfo.RejectForm3283(parameters).subscribe(
        data => {
          if (data != 'UnAuthorized') {
            this.rejectDetails = data;
            if (this.rejectDetails.isSuccessful == true) {
              this.pubsub.sendFormSubmitNotifier("Reject");
              this.archiveHomeService.SyncForm3283SStatus(this.archiveNumber);
              this.router.navigate(["/" + PageUrl]);
            }
            else {
              this.notifier.notify('error', this.rejectDetails.responseMessage)
            }
          } else {
            this.notifier.notify("error", "User does not have access to perform action");
            this.getFormInfo(this.UserAlias);
          }
        }
      )
    }
    //this.SpinnerService.hide();
  }
  requireEditRejection(PageUrl) {
    if (this.ActionItemId == undefined || this.ActionItemId == null) {
      this.notifier.notify("error", "Dont have permission to approve");
    }
    else {
      this.ActionItemId;
      var parameters = {
        "ActionItemId": this.ActionItemId,
        "RejectedBy": '',
        "IsEditRequired": true,
        "RejectionReason": this.EditFormText,
        "ArchiveNumber": this.archiveNumber
      }
      this.forminfo.RejectForm3283(parameters).subscribe(
        data => {
          var requireEdit = data;
          if (requireEdit.isSuccessful == true) {
            this.pubsub.sendFormSubmitNotifier("Reject");
            this.archiveHomeService.SyncForm3283SStatus(this.archiveNumber);
            this.router.navigate(["/" + PageUrl]);
          }
          else {
            this.notifier.notify('error', requireEdit.responseMessage)
          }
        }
      )
    }
  }


  //For PeoplePicker

  onInputChanged(searchString: string, rolecode?: string) {
    this.users = [];
    this.rolecode = rolecode;
    this.searchString = searchString;
    this.currentSearchKeyword = searchString;
    this._subject.next(this.currentSearchKeyword ? this.currentSearchKeyword.trim() : "");

    if (searchString.length >= 3) {
      this._subject.pipe(
        distinctUntilChanged(),
        debounceTime(500),
      ).subscribe(value => this.getPeople(value))
    }
    else {
      this.users = [];
      this.lastSearchKeyword = '';
    }
  // this.SpinnerService.hide();
  }

  onFocusTB() {
    this.users = [];
  }

  getPeople(searchString: string) {
    if (searchString.length >= 3 && this.lastSearchKeyword != searchString) {
      this.lastSearchKeyword = searchString;
      this.peoplePickerService.GetPeople(searchString).subscribe(
        (value) => {
          this.users = [];
          value.forEach(element => {
            if (this.currentSearchKeyword.length >= 3) {
              // if (element.isPPD)
              this.users = value;
            } else {
              this.users = [];
            }
          });
        },
        (err) => {
          console.log("error is ", err)
        }
      );
     this.SpinnerService.hide();
    }
  }

  selectedAuditPICName(auditPIC, index) {
    if (this.selectedAuditPPDViewName == auditPIC.source.value) {
      this.IsInCorrectPICPerson = true;
      this.IsInCorrectPPDPerson = false;
      this.IsInCorrectPerson = true;
    }
    else {
      this.IsInCorrectPICPerson = false;
      this.IsInCorrectPPDPerson = false;
      this.IsInCorrectPerson = false;

    }
    this.selectedAuditPICViewName = auditPIC.source.value;
    this.selectedAuditPIC = this.users[index].userAlias;
  }


  selectedAuditPPDName(auditPPD, index) {
    if (this.selectedAuditPICViewName == auditPPD.source.value) {
      this.IsInCorrectPPDPerson = true;
      this.IsInCorrectPICPerson = false;
      this.IsInCorrectPerson = true;
    }
    else {
      this.IsInCorrectPPDPerson = false;
      this.IsInCorrectPICPerson = false;
      this.IsInCorrectPerson = false;
    }
    this.selectedAuditPPDViewName = auditPPD.source.value;
    this.selectedAuditPPD = this.users[index].userAlias;
  }


  // Cancel button functionality

  cancel() {
    this.modalService.openWithCustomWidth('cancel-form-modal', "500");
  }
  ResetForm() {
    this.ADCEDDate = undefined;
    this.selectedAuditPICViewName = "";
    this.selectedAuditPPDViewName = "";
    this.selectedAuditPPD = "";
    this.selectedAuditPIC = "";
    this.AddDescCount = 0;
    this.ActionsCount = 0;
    this.login_form.get('ProposedADCED').reset();
    this.login_form.get('ActionsToBeTaken').reset();
    this.login_form.get('AdditionalDetails').reset();
    this.login_form.get('auditPIC').reset();
    this.login_form.get('auditPPD').reset();
    this.myForm.get('reasonCheckbox').reset();
    this.myForm.get('reasonCheckboxinput').reset();
  }

  openModalDialog() {
    this.modalService.openWithCustomWidth('form-edit-modal', "540");
    this.popUpHeaderText = "Audit Professional Practice Director";
    this.popupAuditPPDViewName = this.AuditPPDName;
  }

  closeModalDialog(Action) {
    this.modalService.close(Action);
    this.EditFormText = "";
    this.EditCount = 0;
    this.IsEnableConfirm = false;
    this.requireEditsCSS = { 'border-color': '#E6E6E6' };
    this.totalRejectCSS = { 'border-color': '#E6E6E6' };
  }
  closeModalDialogForEditPIC(Action) {
    this.modalService.close(Action);
    this.popupAuditPICViewName = "";
    this.IsInCorrectPerson = false;
    this.login_form.get('auditPIC').reset();
  }
  closeModalDialogForEditPPD(Action) {
    this.modalService.close(Action);
    this.popupAuditPPDViewName = "";
    this.IsInCorrectPerson = false;
    this.login_form.get('auditPPD').reset();
  }
  openPICModalDialog() {
    this.modalService.openWithCustomWidth('formpic-edit-modal', "540");
    this.popupAuditPICViewName = this.AuditPICName;
  }

  SaveClick(Action) {
    if (Action == "ChangePIC") {
      this.ChangedTo = this.selectedAuditPIC;
      this.Identifier = "AuditPIC";
    }
    else {
      this.ChangedTo = this.selectedAuditPPD;
      this.Identifier = "AuditPPD";
    }
    this.ChangeApprover();
  }
  ChangeApprover() {
    var parameters =
    {
      "FormId": this.FormId,
      "Identifier": this.Identifier,
      "ChangedTo": this.ChangedTo,
      "ChangedBy": '',
      "ArchiveNumber": this.archiveNumber
    };
    var objstr = JSON.stringify(parameters);
    if (this.selectedAuditPPD == this.selectedAuditPIC) {
      this.notifier.notify("error", "Please make sure that PIC and PPD are different users.");
    }
    else if (this.selectedAuditPICViewName == this.selectedAuditPPDViewName) {
      this.notifier.notify("error", "Please make sure that PIC and PPD are different users.");
    }
    else if (this.selectedAuditPICViewName != '' && (this.selectedAuditPIC == undefined || this.selectedAuditPIC == "")) {
      this.notifier.notify("error", "Please select valid Audit PIC");
    }
    else if (this.selectedAuditPPDViewName != '' && (this.selectedAuditPPD == undefined || this.selectedAuditPPD == "")) {
      this.notifier.notify("error", "Please select valid Audit PPD");
    }
    else {
      this.forminfo.ChangePICPPD(objstr).subscribe(
        data => {
          if (data != 'UnAuthorized') {

            var changeapprover = data;
            if (changeapprover.isSuccessful == true) {
              this.notifier.notify("success", changeapprover.responseMessage);
              this.getFormInfo(this.UserAlias);
            }
            else {
              this.notifier.notify("error", changeapprover.responseMessage);
              this.getFormInfo(this.UserAlias);
            }
          } else {
            this.notifier.notify("error", "User does not have access to perform action");
            this.getFormInfo(this.UserAlias);
          }
        }
      );
    }
    this.getFormInfo(this.UserAlias);
  }

  getFormInfo(UserAlias: string) {
   // this.SpinnerService.show();
    this.forminfo.GetPrepopulatedFormInfo(this.archiveNumber, UserAlias).subscribe(
      data => {
        if (data != "" || data != undefined) {
          this.Forms = data;
          if (this.Forms.length == 1) {
            this.isExpanded = true;
            this.isApprovePanelExpanded = true;
            this.disablePanel = true;
          }
          else if (this.Forms.length > 1) {
            this.isExpanded = true;
            this.isApprovePanelExpanded = false;
          }
          this.FormDetails = this.Forms.filter((x) => { return x.formStatus == "Approved" });
          this.newforminfo = this.Forms.filter((x) => { return x.formStatus == "" });
          var rdcdDate = this.newforminfo.map(x => x.rdcdDate)[0];
          this.LatestRDCDDate = new Date(rdcdDate);
          var now = new Date();
          var currentUTCDate = new Date(now.getTime() + now.getTimezoneOffset() * 60000);
         //removing timestamp
          currentUTCDate = new Date(currentUTCDate.toDateString());
          if (this.FormDetails.length > 0) {

            if( currentUTCDate <= this.LatestRDCDDate){
              this.EnableMainForm = false;
              this.isApprovePanelExpanded = true;
                var PICuseraliaslist = this.FormDetails[0].actionItems.filter((x) => { return x.actionItemIdentifier == "AuditPIC" });
                var PICuseralias = PICuseraliaslist.map(x => x.actionItemAssignedTo).toString();
                var PPDuseraliaslist = this.FormDetails[0].actionItems.filter((x) => { return x.actionItemIdentifier == "AuditPPD" });
                var PPDuseralias = PPDuseraliaslist.map(x => x.actionItemAssignedTo).toString();

                  if (this.UserAlias == PICuseralias || this.UserAlias == PPDuseralias) {
                     this.canUpdate = false;
                    }
                  else {
                     this.canUpdate = true;
                    }
              }
              else{
              this.canUpdate = false;
              this.EnableMainForm = false;
              this.isApprovePanelExpanded = true;
              }

          }
          else {
            this.EnableMainForm = true;
            this.canUpdate = false;
          }
          this.form3283sinfo = this.Forms.filter((x) => { return x.formStatus == "Submitted" || x.formStatus == "" || (x.formStatus == "Rejected" && x.rejectionReason != "") });
          if (this.form3283sinfo.length > 0) {
            this.FormId = this.form3283sinfo.map(x => x.formId).toString();
            var isapprover = this.form3283sinfo.map(x => x.isApprover).toString();
            this.IsApprover = Boolean(JSON.parse(isapprover));
            this.ArchivePartner = this.form3283sinfo.map(x => x.archivePartner).toString();
            this.RejectionReason = this.form3283sinfo.map(x => x.rejectionReason).toString();
            this.RejectedBy = this.form3283sinfo.map(x => x.rejectionReasonByFullName).toString();
            this.RejectedDate = this.form3283sinfo.map(x => x.rejectionReasonDate).toString();
            this.FormStatus = this.form3283sinfo.map(x => x.formStatus).toString();
            if (this.FormStatus == "Submitted" || this.RejectionReason != '') {
              this.EnableMainForm = true;
              this.canUpdate = false;
            }
            if (this.FormStatus == "") {
              this.disablePanel = true;
            }
            this.SubmissionDate = this.form3283sinfo.map(x => x.submittedDate).toString();
            this.TypeOfEntity = this.form3283sinfo.map(x => x.typeOfEntity).toString();
            this.EDCDDate = this.form3283sinfo.map(x => x.edcdDate).toString();
            this.RDCDDate = this.form3283sinfo.map(x => x.rdcdDate).toString();
            this.AdditionalDetails = this.form3283sinfo.map(x => x.additionalDetails).toString();
            this.ActionsToBeTaken = this.form3283sinfo.map(x => x.actionsToBeTaken).toString();
            this.ADCEDDate = this.form3283sinfo.map(x => x.proposedADCEDDate).toString();

            this.reasonList = this.form3283sinfo.map(x => x.reasonTypes);
            if (this.reasonList.length > 0) {
              var otherReasonarray = this.reasonList[0].filter((x) => { return x.isSelectedBefore == true && x.reasonTypeId == 5 });
              var array = this.reasonList[0].filter((x) => { return x.isSelectedBefore == true });
              this.ReasonDescription = otherReasonarray.map(x => x.reasonTypeDescription).toString();
              this.reasonIDs = array.map(x => x.reasonTypeId).toString();
              var reasonarray = array.map(x => x.reasonTypeDescription).toString();
              var reasonstringarray = reasonarray.replace(/,/g, ", ");
               this.AllReasonDescriptions = reasonstringarray;
            }
            var tempDate = new Date(this.EDCDDate);
            tempDate.setDate(tempDate.getDate() + 1);
            this.minDate = tempDate;

            this.ActionItems = this.form3283sinfo.map(x => x.actionItems);
            if (this.ActionItems.length > 0) {
              var piclist = this.ActionItems[0].filter((x) => { return x.actionItemIdentifier == "AuditPIC" });
              this.AuditPICName = piclist.map(x => x.actionItemAssignedToFullName).toString();
              this.selectedAuditPICViewName = this.AuditPICName;
              this.selectedAuditPIC = piclist.map(x => x.actionItemAssignedTo).toString();

              this.AuditPICActionStatusDesc = piclist.map(x => x.actionItemStatusDescription).toString();
              this.AuditPICApprovedDate = piclist.map(x => x.completedDate);

              var ppdlist = this.ActionItems[0].filter((x) => { return x.actionItemIdentifier == "AuditPPD" });
              this.AuditPPDName = ppdlist.map(x => x.actionItemAssignedToFullName).toString();
              this.selectedAuditPPDViewName = this.AuditPPDName;
              this.selectedAuditPPD = ppdlist.map(x => x.actionItemAssignedTo).toString();

              this.AuditPPDActionStatusDesc = ppdlist.map(x => x.actionItemStatusDescription).toString();
              this.AuditPPDApprovedDate = ppdlist.map(x => x.completedDate);


              var partnerlist = this.ActionItems[0].filter((x) => { return x.actionItemIdentifier == "ArchivePartner" });
              if (partnerlist.length > 0) {
                this.ArchivePartnerStatusDesc = partnerlist.map(x => x.actionItemStatusDescription);
                this.ArchivePartnerApprovedDate = partnerlist.map(x => x.completedDate);
                this.ArchivePartnerUserAlias = partnerlist.map(x => x.actionItemAssignedTo);
              }

              if (this.UserAlias == this.ArchivePartnerUserAlias && this.ArchivePartnerStatusDesc != "Rejected") {
                this.EnableEditPICPPD = true;
              }
              else if (this.UserAlias == this.ArchivePartnerUserAlias && this.ArchivePartnerStatusDesc == "Rejected") {
                this.EnableEditPICPPD = false;
              }
              else if (this.UserAlias == this.selectedAuditPPD || this.selectedAuditPPD == '') {
                this.EnableEditPICPPD = false;
              }
              else if (this.UserAlias == this.selectedAuditPIC || this.selectedAuditPIC == '') {
                this.EnableEditPICPPD = false;
              }
              else {
                this.EnableEditPICPPD = true;
              }

              var id = this.ActionItems[0].filter((x) => { return x.actionItemAssignedTo == UserAlias && x.actionItemId != 0 });
              this.ActionItemId = id.map(x => x.actionItemId).toString();
              this.ApproverRole = id.map(x => x.actionItemIdentifier).toString();
            }
            if (this.RejectionReason != "") {
              this.IsRejected = true;
            }
            else {
              this.IsRejected = false;
            }
            if (this.IsApprover == false && this.FormId == 0) {
              this.IsRequestor = true;
              this.expPanelHeight = true;
              this.showSubmitCancelButtons = true;
              this.IsSubmitButtonEnable = true;
              this.isEnableCancel = true;
              this.EnableEditMode = false;
              this.AllframesUp = {
                'top': '75px'
              }
            }
            else if (this.IsApprover == false && this.FormId != 0) {
              if (this.IsRejected == false) {
                this.IsRequestor = false;
                this.expPanelHeight = false;
                this.showSubmitCancelButtons = true;
                this.IsSubmitButtonEnable = true;
                this.isEnableSubmit = false;
                this.isEnableCancel = false;
                this.EnableEditMode = false;
                this.AllframesUp = {
                  'top': '20px'
                }
              }
              else {
                this.isEnableSubmit = true;
                this.isEnableCancel = true;
                this.IsRequestor = true;
                this.expPanelHeight = true;
                this.showSubmitCancelButtons = true;
                this.IsSubmitButtonEnable = true;
                this.EnableEditMode = false;
                if(this.RejectionReason.length <= 150){
                  this.AllframesUp = {
                    'top': '180px'
                  }
                  this.ApproversAllFramesUp = {
                    'top': '180px'
                  }
                 }
                 else if (this.RejectionReason.length > 150 && this.RejectionReason.length <= 300){
                    this.AllframesUp = {
                      'top': '215px'
                    }
                    this.ApproversAllFramesUp = {
                      'top': '215px'
                    }
                 }
                 else if (this.RejectionReason.length > 300 && this.RejectionReason.length <= 500){
                  this.AllframesUp = {
                    'top': '250px'
                  }
                  this.ApproversAllFramesUp = {
                    'top': '250px'
                  }
               }

              }
              //Edit Mode for Archive Partner changes.
              if (this.UserAlias == this.ArchivePartnerUserAlias && this.ArchivePartnerStatusDesc != "Awaiting Approval") {
                this.IsSubmitButtonEnable = false;
                this.showSubmitCancelButtons = false;
                this.isEnableSubmit = false;
                this.isEnableCancel = false;
                this.EnableEditMode = false;
                this.IsRequestor = false;
                this.expPanelHeight = false;
              }

              else if ((this.UserAlias == this.selectedAuditPIC || this.UserName == this.AuditPICName) && this.AuditPICActionStatusDesc != "Awaiting Approval") {
                this.IsSubmitButtonEnable = false;
                this.showSubmitCancelButtons = false;
                this.isEnableSubmit = false;
                this.isEnableCancel = false;
                this.EnableEditMode = false;
                this.IsRequestor = false;
                this.expPanelHeight = false;

              }

              else if ((this.UserAlias == this.selectedAuditPPD || this.UserName == this.AuditPPDName) && this.AuditPPDActionStatusDesc != "Awaiting Approval") {
                this.IsSubmitButtonEnable = false;
                this.showSubmitCancelButtons = false;
                this.isEnableSubmit = false;
                this.isEnableCancel = false;
                this.EnableEditMode = false;
                this.IsRequestor = false;
                this.expPanelHeight = false;

              }

            }
            else if (this.IsApprover == true && this.FormId != 0) {
              if (this.UserAlias == this.ArchivePartnerUserAlias) {
                this.IsRequestor = false;
                this.expPanelHeight = false;
                this.EnableEditMode = true;
                this.showSubmitCancelButtons = false;
                this.IsSubmitButtonEnable = false;
                this.isEnableCancel = true;
                this.isEnableSubmit = true;
              }

              else {
                this.IsRequestor = false;
                this.expPanelHeight = false;
                this.showSubmitCancelButtons = false;
                this.EnableEditMode = false;
                this.IsSubmitButtonEnable = false;
                this.isEnableSubmit = true;
                this.isEnableCancel = true;
              }

            }
            if (this.UserAlias != this.ArchivePartner || this.UserAlias != this.AuditPICName || this.UserAlias != this.AuditPPDName) {
              this.IsEditButtonEnable = true;
            }
            else {
              this.IsEditButtonEnable = false;
            }


            if (this.AuditPICActionStatusDesc == "Awaiting Approval") {
              this.AwaitingPICStatus = true;
            }
            else {
              this.AwaitingPICStatus = false;
            }
            if (this.AuditPPDActionStatusDesc == "Awaiting Approval") {
              this.AwaitingPPDStatus = true;
            }
            else {
              this.AwaitingPPDStatus = false;
            }
            if (this.ArchivePartnerStatusDesc == "Awaiting Approval") {
              this.AwaitingPartnerStatus = true;
            }
            else {
              this.AwaitingPartnerStatus = false;
            }
          }
         // this.SpinnerService.hide();

        }
        else {
          this.notifier.notify("error", "Error occured! Please contact administrator.")
        }
      }
    );
  }

  markFormTouched(group: FormGroup | FormArray) {
    Object.keys(group.controls).forEach((key: string) => {
      const control = group.controls[key];
      if (control instanceof FormGroup || control instanceof FormArray) { control.markAsTouched(); this.markFormTouched(control); }
      else { control.markAsTouched(); };
    });
  };

  Submit(PageUrl) {
    this.isEnableSubmit = false;
  //  this.SpinnerService.show();
    this.markFormTouched(this.login_form);
    this.markFormTouched(this.myForm);
    var reasonList = this.reasonList[0].filter((x) => x.isSelectedBefore == true);
    var OtherReasonDescList = this.reasonList[0].filter((x) => x.isSelectedBefore == true && x.reasonTypeId == 5);
    var desc = OtherReasonDescList.map((y) => y.reasonTypeDescription).toString();

    if (this.ADCEDDate == null || this.ADCEDDate == undefined) {
      this.notifier.notify("error", "Please select valid Proposed ADCED Date");
    }
    else if (this.selectedAuditPICViewName != '' && (this.selectedAuditPIC == undefined || this.selectedAuditPIC == "")) {
      this.notifier.notify("error", "Please select valid Audit PIC");
    }
    else if (this.selectedAuditPPDViewName != '' && (this.selectedAuditPPD == undefined || this.selectedAuditPPD == "")) {
      this.notifier.notify("error", "Please select valid Audit PPD");
    }
    else if (this.selectedAuditPPD == this.selectedAuditPIC || this.selectedAuditPICViewName == this.selectedAuditPPDViewName) {
      this.notifier.notify("error", "Please make sure that PIC and PPD are different users.");
    }
    else if (this.selectedAuditPPDViewName == this.selectedAuditPICViewName) {
      this.notifier.notify("error", "Please make sure that PIC and PPD are different users.");
    }
    else if (reasonList.length == 0) {
      this.notifier.notify("error", "Please select atleast one reason");
    }
    else if (OtherReasonDescList.length != 0 && desc == "") {
      this.notifier.notify("error", "Please enter the reason");
    }
    else if (OtherReasonDescList.length != 0 && desc.length < 5) {
      this.notifier.notify("error", "Please enter atleast 5 characters for the reason");
    }

    else if (this.login_form.valid && reasonList.length > 0) {
      this.reasonIDs = this.reasonList[0].filter((x) => x.isSelectedBefore == true).map((y) => y.reasonTypeId).toString();
      console.log(this.reasonIDs);
      var parameters =
      {
        "Id": this.FormId,
        "ArchiveNumber": this.archiveNumber,
        "ProposedADCEDDate": new Date(this.ADCEDDate).toLocaleDateString(),
        "ReasonTypeIDs": this.reasonIDs,
        "ReasonDescription": this.ReasonDescription,
        "AdditionalDetails": this.AdditionalDetails,
        "ActionsToBeTaken": this.ActionsToBeTaken,
        "AuditPICAlias": this.selectedAuditPIC,
        "AuditPPDAlias": this.selectedAuditPPD,
        "CreatedBy": ''
      };
      var objstr = JSON.stringify(parameters);
      //Submit method
      console.log("ProposedDate :" + this.ADCEDDate);
      console.log("Post conversion :" + new Date(this.ADCEDDate).toLocaleDateString());
      this.forminfo.SubmitForm3283S(objstr).subscribe(
        data => {
          if (data != 'UnAuthorized') {

            var submittedFormDetails = data;

            if (submittedFormDetails != undefined) {
              this.archiveHomeService.SyncForm3283SStatus(this.archiveNumber);
              if (this.SubmitOrSaveButtonText == "Submit") {
                this.pubsub.sendFormSubmitNotifier("Submit");
                // this.notifier.notify("success", "Submitted successfully! You have successfully submitted Form 3283S for approval");
                this.router.navigate(["/" + PageUrl]);
              }
              else {
              //  this.SpinnerService.show();
                this.getFormInfo(this.UserAlias);
                this.notifier.notify("success", "You have successfully saved Form 3283S");
               // this.SpinnerService.hide();
              }

            }
            else {
              this.notifier.notify("error", "Error occurred while submitting the Form");
            }

          } else {
            this.notifier.notify("error", "User does not have access to perform action");
          }
        }
      );
    }


    else {
      this.login_form.controls['terms'].setValue(false);
    }
  //  this.SpinnerService.hide();
  }

  Approve(PageUrl) {
    this.isEnableSubmit = false;
   // this.SpinnerService.show();
    if (this.ActionItemId == undefined || this.ActionItemId == null) {
      this.notifier.notify("error", "Dont have permission to approve");
    }
    else {
      this.ActionItemId;
      var parameters = {
        "ActionItemId": this.ActionItemId,
        "ApprovedBy": '',
        "ArchiveNumber": this.archiveNumber,
        "ArchiveDueDateCriteria" :this.archiveDueDateCriteria,
        "DeliverableType" :this.deliverableType,
        "DateThatDrivesEDCD" :this.DateDrivesEDCD,
        "RDCDDate": this.RDCDDate
      };
      this.forminfo.ApproveForm3283(parameters).subscribe(
        data => {
          if (data != 'UnAuthorized') {
            this.Approveinfo = data;
            if (this.Approveinfo.isSuccessful == true) {

              if (this.ApproverRole == "AuditPIC") {
                this.AuditPICActionStatusDesc = this.Approveinfo.actionItemStatusDescription;
                this.AuditPICApprovedDate = this.Approveinfo.completedDate;
              }

              else if (this.ApproverRole == "AuditPPD") {
                this.AuditPPDActionStatusDesc = this.Approveinfo.actionItemStatusDescription;
                this.AuditPPDApprovedDate = this.Approveinfo.completedDate;
              }
              else {
                this.ArchivePartnerStatusDesc = this.Approveinfo.actionItemStatusDescription;
                this.ArchivePartnerApprovedDate = this.Approveinfo.completedDate;
              }

              if (this.AuditPICActionStatusDesc == "Awaiting Approval") {
                this.AwaitingPICStatus = true;
              }
              else {
                this.AwaitingPICStatus = false;
              }
              if (this.AuditPPDActionStatusDesc == "Awaiting Approval") {
                this.AwaitingPPDStatus = true;
              }
              else {
                this.AwaitingPPDStatus = false;
              }
              if (this.ArchivePartnerStatusDesc == "Awaiting Approval") {
                this.AwaitingPartnerStatus = true;
              }
              else {
                this.AwaitingPartnerStatus = false;
              }
              this.pubsub.sendFormSubmitNotifier("Approve");
              this.archiveHomeService.SyncForm3283SStatus(this.archiveNumber);
              this.router.navigate(["/" + PageUrl]);


            }
            else {
              this.notifier.notify('error', this.Approveinfo.responseMessage);
            }
          } else {
            this.notifier.notify("error", "User does not have access to perform action");
            this.getFormInfo(this.UserAlias);
          }
        }
      )
    }
   // this.SpinnerService.hide();
  }
  EditMode() {
    this.IsRequestor = true;
    this.expPanelHeight = true;
    this.AllframesUp = {
      'top': '75px'
    };
    this.IsSubmitButtonEnable = true;
    this.showSubmitCancelButtons = true;
    this.isEnableSubmit = true;
    this.isEnableCancel = true;
    this.SubmitOrSaveButtonText = "Save";
  }

  UpdateForm() {
    this.canUpdate = false;
    this.EnableMainForm = true;
    this.IsRequestor = true;
    this.AllframesUp = {
      'top': '75px'
    };
    this.IsSubmitButtonEnable = true;
    this.showSubmitCancelButtons = true;
    this.isEnableSubmit = true;
    this.isEnableCancel = true;
    this.SubmitOrSaveButtonText = "Submit";
    this.isApprovePanelExpanded = false;
  }

  OnClick(PageUrl) {
    this.router.navigate(["/" + PageUrl + ""]);
  }

  redirectToArchiveHomePage(PageUrl) {
    this.router.navigate(["/" + PageUrl + "/" + this.archiveNumber]);
  }
  redirectToHomePage(PageUrl) {
    this.router.navigate(["/" + PageUrl]);
  }

}
