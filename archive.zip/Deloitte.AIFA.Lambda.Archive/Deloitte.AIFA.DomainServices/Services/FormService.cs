﻿using Deloitte.AIFA.Common;
using Deloitte.AIFA.DomainEntities;
using Deloitte.AIFA.DomainEntities.EmailEntities;
using Deloitte.AIFA.DomainEntities.Enums;
using Deloitte.AIFA.DomainServices.Common;
using Deloitte.AIFA.DomainServices.Contracts;
using Deloitte.AIFA.EmailNotificationServices;
using Deloitte.AIFA.EmailNotificationServices.NotificationServices.Services;
using Deloitte.AIFA.ICloudServices;
using Deloitte.AIFA.IRepositories;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Deloitte.AIFA.DomainServices.Services
{
    public class FormService : BaseService, IFormService
    {
        IFormRepository _formRepository;
        ILogger _logger;
        IMemoryCache _cache;
        IEmailNotificationService _emailNotificationService;
        public FormService(IMemoryCache cache, IConfigManager configManager,
                              IFormRepository formRepository, IEmailNotificationService emailNotificationService,
                                ILogger<FormService> logger) : base(cache, configManager)
        {
            _cache = cache;
            _logger = logger;
            _formRepository = formRepository;
            _emailNotificationService = emailNotificationService;
        }

        public List<Form> GetFormsPrepopulatedData(string archiveNumber, string loggedInUser)
        {
            var result = _formRepository.GetForm3283PrepopulatedData(archiveNumber, loggedInUser);
            foreach (var form in result.Forms)
            {
                form.ReasonTypes = result.ReasonTypes.Where(i => i.FormId == form.FormId).ToList();
                form.ActionItems = result.FormActions.Where(i => i.EntityId == form.FormId).ToList();
            }
            return result.Forms;
        }

        public FormActionResponse CreateOrUpdateForm(FormSubmitInfo submitForm)
        {
            var resultForm = _formRepository.CreateOrUpdateForm(submitForm);

            #region Email

            //For Archive submission - Approved Action
            if (resultForm.IsSuccessful)
            {
                if (resultForm.ApprovedBy == "ArchivePartner")
                {
                    Console.WriteLine("Pushing Message to Email SNS Starts for Status Rejected for Archive Number " + submitForm.ArchiveNumber);
                    Form3283SNotification rtn = new Form3283SNotification();
                    BaseEmailEntity be = new BaseEmailEntity();
                    var ActionItemID = "FormId-" + resultForm.ResponseMessage.ToString();
                    be = rtn.Form3283S_PIC_Awaiting_Approval_Notification("Form3283SPICAwaitingApproval", "Form3283SPICAwaitingApproval", "63", submitForm.ArchiveNumber, resultForm.ApprovedBy, (ActionItemID + "-PIC"));
                    _emailNotificationService.PublishEmailNotification(be);
                    BaseEmailEntity be1 = new BaseEmailEntity();
                    be1 = rtn.Form3283S_PPD_Awaiting_Approval_Notification("Form3283SPPDAwaitingApproval", "Form3283SPPDAwaitingApproval", "63", submitForm.ArchiveNumber, resultForm.ApprovedBy, (ActionItemID + "-PPD"));
                    _emailNotificationService.PublishEmailNotification(be1);
                }
                else
                {
                    Console.WriteLine("Pushing Message to Email SNS Starts for Status Approved for Archive Number " + submitForm.ArchiveNumber);
                    Form3283SNotification rtn = new Form3283SNotification();
                    BaseEmailEntity be = new BaseEmailEntity();
                    var ActionItemID = "FormId-" + resultForm.ResponseMessage.ToString();
                    be = rtn.Form3283S_AP_Awaiting_Approval_Notification("Form3283SAPAwaitingApproval", "Form3283SAPAwaitingApproval", "63", submitForm.ArchiveNumber, resultForm.ApprovedBy, (ActionItemID+"-AP"));

                    _emailNotificationService.PublishEmailNotification(be);
                }





            }


            #endregion

            return resultForm;
        }

        public FormActionResponse ApproveForm(ApproveOrRejectFormRequest request)
        {
            var result = _formRepository.ApproveForm(request);

            #region Email

            //For Archive submission - Approved Action
            if (result.FormStatus == "Approved")
            {
                Console.WriteLine("Pushing Message to Email SNS Starts for Status Approved for Archive Number " + request.ArchiveNumber);
                Form3283SNotification rtn = new Form3283SNotification();
                BaseEmailEntity be = new BaseEmailEntity();
                be = rtn.Form3283S_Fully_Approved_Notification("Form3283SFullyApproved", "Form3283SFullyApproved", "60", request.ArchiveNumber, request.ApprovedBy, result.ADCED.ToString(), request.ActionItemId.ToString());

                be.TemplateId = "60";

                _emailNotificationService.PublishEmailNotification(be);

            }

            if (result.ApprovedBy == "ArchivePartner")
            {
                Console.WriteLine("Pushing Message to Email SNS Starts for Status Rejected for Archive Number " + request.ArchiveNumber);
                Form3283SNotification rtn = new Form3283SNotification();
                BaseEmailEntity be = new BaseEmailEntity();
                var ActionItemID = "ActionItemId-" + request.ActionItemId.ToString();
                be = rtn.Form3283S_PIC_Awaiting_Approval_Notification("Form3283SPICAwaitingApproval", "Form3283SPICAwaitingApproval", "63", request.ArchiveNumber, request.ApprovedBy, (ActionItemID + "-PIC"));
                _emailNotificationService.PublishEmailNotification(be);
                BaseEmailEntity be1 = new BaseEmailEntity();
                be1 = rtn.Form3283S_PPD_Awaiting_Approval_Notification("Form3283SPPDAwaitingApproval", "Form3283SPPDAwaitingApproval", "63", request.ArchiveNumber, request.ApprovedBy, (ActionItemID + "-PPD"));
                _emailNotificationService.PublishEmailNotification(be1);

            }
            #endregion

            return result;
        }

        public FormActionResponse RejectForm(ApproveOrRejectFormRequest request)
        {
            var result = _formRepository.RejectForm(request);
            #region Email

            //For Form Rejection 
            if (result.FormStatus == "Rejected" && (request.RejectionReason != "" && request.RejectionReason != null))
            {
                Console.WriteLine("Pushing Message to Email SNS Starts for Status Rejected for Archive Number " + request.ArchiveNumber);
                Form3283SNotification rtn = new Form3283SNotification();
                BaseEmailEntity be = new BaseEmailEntity();
                be = rtn.Form3283S_Rejected_Notification("Form3283SRejectedByAP", "Form3283SRejectedByAP", "81", request.ArchiveNumber, request.RejectedBy, result.SubmittedBy, request.RejectionReason, request.ActionItemId.ToString());

                be.TemplateId = "81";

                _emailNotificationService.PublishEmailNotification(be);

            }

            else
            {
                Console.WriteLine("Pushing Message to Email SNS Starts for Status Rejected for Archive Number " + request.ArchiveNumber);
                Form3283SNotification rtn = new Form3283SNotification();
                BaseEmailEntity be = new BaseEmailEntity();
                be = rtn.Form3283S_Rejected_Notification("Form3283SFullyRejected", "Form3283SFullyRejected", "82", request.ArchiveNumber, request.RejectedBy, result.SubmittedBy, request.RejectionReason, request.ActionItemId.ToString());

                be.TemplateId = "82";

                _emailNotificationService.PublishEmailNotification(be);

            }

            #endregion
            return result;
        }

        public FormActionResponse ChangeApprover(ChangeApproverRequest request)
        {
            var result = _formRepository.ChangeApprover(request);
            return result;
        }
    }
}
