﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.EmailNotificationServices.NotificationEntities
{
    public static class EmailPlaceholders
    {

        #region Request Temporary Access
        public const string RequesteeFirstName = "[RequesteeFirstName]";
        public const string RequesteeName = "[RequesteeName]";
        public const string RequestorFirstName = "[RequestorFirstName]";
        public const string GrantDenyLink = "[GrantDenyLink]";
        #endregion
        public const string DpsProjectManager = "[DpsProjectManager]";
        public const string WbsLevelOneNumber = "[WbsLevelOneNumber]";
        public const string WbsLevelOneNameName = "[WbsLevelOneName]";
        public const string ArchiveDeclineReason = "[ArchiveDeclineReason]";
        public const string ArchiveManager = "[ArchiveManager]";
        public const string ArchivePartner = "[ArchivePartner]";
        public const string ArchiveManagerRoleDeclineReason = "[ArchiveManagerRoleDeclineReason]";
        public const string ArchiveNumber = "[ArchiveNumber]";
        public const string ArchiveName = "[ArchiveName]";
        public const string DaysUntilDueDate = "[DaysUntilDueDate]";
        public const string ClientName = "[ClientName]";
        public const string ArchiveDueDate = "[ArchiveDueDate]";
        public const string DaysOverdue = "[DaysOverdue]";
        public const string Submitter = "[Submitter]";
        public const string SubmissionDate = "[SubmissionDate]";
        public const string Approver = "[Approver]";
        public const string ApproveDate = "[ApproveDate]";
        public const string Rejecter = "[Rejecter]";
        public const string RejectionDate = "[RejectionDate]";
        public const string RetentionPeriod = "[RetentionPeriod]";
        public const string Recipient = "[Recipient]";
        public const string Number = "[Number]";
        public const string RequestedBy = "[RequestedBy]";
        public const string RequestedOf = "[RequestedOf]";
        public const string RequestReasons = "[RequestReasons]";
        public const string NotificationDate = "[NotificationDate]";
        public const string SubmitterRole = "[SubmitterRole]";

        public const string AppoinmentStartDate = "[AppoinmentStartDate]";
        public const string AppoinmentAttendees = "[AppoinmentAttendees]";
        public const string MeetingLocation = "[MeetingLocation]";
        public const string AppoinmentEndDate = "[AppoinmentEndDate]";
        public const string AppoinmentCreated = "[AppoinmentCreated]";
        public const string AppoinmentLocation = "[AppoinmentLocation]";
        public const string ActionDateTime = "[ActionDateTime]";
        public const string AdminEmailAddress = "[AdminEmailAddress]";
        public const string EDCD = "[EDCD]";

        public const string HourAndTime = "[HourAndTime]";

        public const string PartnerDashBoardUrl = "[DashboardURL]";

        public const string DomainName = "#DomainName#";
        public const string EngagementId = "#EngagementId#";
        public const string ArchiveId = "#ArchiveId#";
        public const string ActionTypeId = "#ActionTypeId#";
        public const string AccessRequestId = "#AccessRequestId#";
        public const string ReportServerURL = "#ReportServerURL#";
        public const string NavigationPageName = "#NavigationPageName#";

        public const string DpsProjectDetails = "<!--DpsProjectDetails-->";
        public const string ArchiveInfo = "<!--ArchiveInfo-->";
        public const string ArchiveComingDueInfo = "<!--ArchiveComingDueInfo-->";
        public const string ArchiveOverdueInfo = "<!--ArchiveOverdueInfo-->";
        public const string ArchiveTeamInfo = "<!--ArchiveTeamInfo-->";
        public const string MessageText = "<!--MessageText-->";
        public const string RejectionReasons = "[RejectionReason]";
        public const string ReportsListInfo = "<!--ReportsListInfo-->";
        public const string BindersListInfo = "<!--BindersListInfo-->";
        public const string FileUploadFailedInfo = "<!--FileUploadFailedInfo-->";
        public const string ArchiveLegalHoldDetails = "<!--ArchiveLegalHoldDetails-->";
        public const string LegalHoldInfo = "<!--LegalHoldInfo-->";
        public const string YouAreAteamMember = "<!--YouAreAteamMember-->";
        public const string YouAreAteamMemberValue = " (You are a team member for this archive.) ";

        public const string EmailLogId = "#EmailLogId#";

        public const string VersionStartPattern = "<Version_{0}>";
        public const string VersionEndPattern = "</Version_{0}>";

        public const string EMSFailedFileName = "[EMSFailedFileName]";
        public const string EMSFailedFiledException = "[EMSFailedFiledException]";
        public const string RoleName = "<!--RoleName-->";
        public const string LoggedInUser = "<!--LoggedInUser-->";

        public const string FileName = "[FileName]";
        public const string FileVerificationStatusDescription = "[FileVerificationStatusDescription]";

        public const string ActiveBindersInfo = "<!--ActiveBindersInfo-->";

        public const string Role = "[Role]";
        public const string TeamMemberName = "[TeamMemberName]";
        public const string TeamChangedBy = "[TeamChangedBy]";
        public const string TeamMemberAlias = "[TeamMemberAlias]";
        public const string CreatedBy = "[CreatedBy]";

        public const string ADCED = "[ADCED]";
        public const string SubmittedBy = "[SubmittedBy]";
    }
}
