﻿namespace Deloitte.AIFA.DomainEntities
{
    public class SearchOptions
    {
        public long ItemId { get; set; }
        public string ItemName { get; set; }
    }
}
