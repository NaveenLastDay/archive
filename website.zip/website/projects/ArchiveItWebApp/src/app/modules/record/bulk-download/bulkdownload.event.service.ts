import { Injectable, Output, EventEmitter } from "@angular/core";
import { NotifierService } from 'angular-notifier';
import { NgxSpinnerService } from 'ngx-spinner';
import { Subject } from 'rxjs';
import { FielUploadService } from '../../../services/fileupload.service';
import { WorkingPaperService } from '../../../services/working-paper.service';
import { FileUploadEventService } from '../file-upload/fileupload.event.service';
import { FileUploadProcessService } from '../file-upload/fileupload.process.service';

@Injectable()
export class BulkdownloadEventService {


  bulkDownloadsArray = [];
  bulkDownloadIntervalId: any;
  service: WorkingPaperService;
  notifier: NotifierService;

  constructor(private _service: WorkingPaperService,
    private _fuService: FielUploadService,
    private _uploadEventService: FileUploadEventService,
    private SpinnerService: NgxSpinnerService,
    private _notifier: NotifierService) {
    this.notifier = _notifier;
    this.service = _service;
  }


  notifybulkdownload() {

    var self = this;

    setInterval(function () {
     
      let bdownloadPending = self.bulkDownloadsArray;
      if (bdownloadPending.length > 0) {

        let inputjobids = bdownloadPending.toString();
       
        self.service.notifybulkdownload(inputjobids, false).subscribe(
          datas => {
            console.log(datas);


            if (self.bulkDownloadsArray.length == 0)
              return;
            var currjobId = self.bulkDownloadsArray[0];
            var data = datas.find(x => x.jobId == currjobId);

            if (data && (data.statusId == 3 || data.statusId == 4)) {
              if (data.s3FileName) {

                var metaData = {};
                let indx = data.s3FileName.indexOf('_');
                let zipFileName = data.s3FileName.substring(indx + 1, data.s3FileName.length);
                var fileUploadProcessService = new FileUploadProcessService(
                  self._fuService,
                  self._uploadEventService,
                  self.SpinnerService,
                  null,
                  null,
                  metaData
                );
                fileUploadProcessService.downloadFile(data.s3FileName, zipFileName);
                self.bulkDownloadsArray = self.bulkDownloadsArray.filter(x => x != data.jobId);
              }
              else {
                self.notifier.notify("error", "Something went wrong, please try again.");
              }
            }


          },
          err => {
            console.log(err);
            self.notifier.notify("error", "Something went wrong, please try again.");
           // self.SpinnerService.hide();
          }
        )
      }
    }, 60 * 1000);
  }

}
