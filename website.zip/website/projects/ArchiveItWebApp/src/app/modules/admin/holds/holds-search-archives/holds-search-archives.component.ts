import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-holds-search-archives',
  templateUrl: './holds-search-archives.component.html',
  styleUrls: ['./holds-search-archives.component.css']
})
export class HoldsSearchArchivesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
