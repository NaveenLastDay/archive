﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;

namespace Deloitte.AIFA.DomainEntities
{
    public class ArchiveLegalHold
    {
        public string ArchiveNumber { get; set; }
        public string OGCHoldNumber { get; set; }
        public DateTime OGCPreservationNoticeDate { get; set; }
        public string OGCAttorneyName { get; set; }
        public string Description { get; set; }
        public string CreatedBy { get; set; }
    }
}
