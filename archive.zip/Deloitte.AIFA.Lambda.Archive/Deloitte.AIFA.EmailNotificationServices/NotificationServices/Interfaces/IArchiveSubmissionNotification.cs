﻿using Deloitte.AIFA.DomainEntities;
using Deloitte.AIFA.DomainEntities.EmailEntities;
using Deloitte.AIFA.EmailNotificationServices.NotificationEntities;
using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.EmailNotificationServices.NotificationServices.Interfaces
{
    interface IArchiveSubmissionNotification
    {
        BaseEmailEntity Submission_ForApproval_Notification(string argOperationType, string argOperationDescription, string argTemplateId, string ArchiveNumber, string userAlias);

        BaseEmailEntity Submission_Approved_Notification(string argOperationType, string argOperationDescription, string argTemplateId, string ArchiveNumber, string userAlias, string approvedDate, string timeZone);

        BaseEmailEntity Submission_Rejected_Notification(string argOperationType, string argOperationDescription, string argTemplateId, string ArchiveNumber, string userAlias);


    }
}
