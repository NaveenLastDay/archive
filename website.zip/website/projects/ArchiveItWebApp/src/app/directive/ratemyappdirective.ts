import { Directive } from '@angular/core';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { AppConfig } from '../services/appconfig.service';
import { NgxSpinnerService } from "ngx-spinner";
import { RateThisAppService } from '../services/ratethisapp.service';

declare var $: any;

@Directive({
    selector: '[rateMyApp]',
   
})

export class RateMyAppDirective {
    userEmail = this.adalSvc.LoggedInUserEmail;
    userAlias = this.userEmail.substring(0, this.userEmail.lastIndexOf("@"));
    rateThisAppUri=AppConfig.settings.rateThisApp.RateThisAppUri;
    useRateThisAppService=AppConfig.settings.rateThisApp.UseRateThisAppService;
    applicationID=AppConfig.settings.rateThisApp.ApplicationID;
    rating=0;
    constructor(private adalSvc: MsAdalAngular6Service,private service: RateThisAppService,private SpinnerService: NgxSpinnerService) {
        if (this.userAlias) {
            if (this.useRateThisAppService == "true") {
                $("#rateThisApp").rateThisApp({
                    userAlias: this.userAlias,
                    serviceUri: this.rateThisAppUri,
                    applicationKey: this.applicationID,
                    ratingValue: this.rating
                });
            }
            else
            {
                // this.service.GetRatingByUserAlias(this.userAlias,this.applicationID).subscribe(
                //     data => {
                //         this.rating=data;
                   
            $("#rateThisApp").rateThisApp({
                userAlias: '',
                ratingValue: this.rating,
                showSummaryOnSubmit: false,
                showLocationSelection: false,
                useCentralRatingRepository: false,
                forceRatingSelection: true,
                enableBandwidthCalculation: false,
                applicationID:this.applicationID,
                submit: function(e, info) {
                    var ratingInfo ={"UserAlias": info.userAlias,"Comment": info.comment,"Rating": info.rating,"Url": info.url,"ApplicationId": this.applicationID};
                   // SpinnerService.show();
                    service.SubmitRating(JSON.stringify(ratingInfo)).subscribe(
                    data => {
                    var successData = data;
                   // SpinnerService.hide();
                    }
              );
                    }
                });
                //});
                }
            }
        }
    }





