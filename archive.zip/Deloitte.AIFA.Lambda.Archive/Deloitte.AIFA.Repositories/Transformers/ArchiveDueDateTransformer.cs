﻿using System;
using System.Data;
using Deloitte.AIFA.DBHelper;
using Deloitte.AIFA.Models;
using Deloitte.AIFA.Repositories.UtilityHelper;

namespace Deloitte.AIFA.Repositories.Transformers
{
    public enum ArchiveDueDateParameter
    {
        [CreateField(Name = "p_ArchiveNumber", Direction = ParameterDirection.Input, Type = DbType.String)]
        ArchiveNumber,
        [CreateField(Name = "p_UserAlias", Direction = ParameterDirection.Input, Type = DbType.String)]
        UserAlias

    }

    public enum ArchiveDueDateField
    {
        ArchiveDueDateCriteria,
        OriginalDate,
        ArchiveDueDate,
        ExpectedDocumentationCompletionDate,
        DeliverableType,
        ArchiveApprovedDate,
        OfficeZone

    }
    public class ArchiveDueDateTransformer : BaseTransformer<ArchiveDueDateEngineModel>
    {
        internal override ArchiveDueDateEngineModel TransformElement(IDataReader dr, Func<IDataReader, ArchiveDueDateEngineModel, ArchiveDueDateEngineModel> bindExtraFields = null)
        {
            var archiveDueDate = new ArchiveDueDateEngineModel();

            if(dr.Read())
            {
                archiveDueDate = new ArchiveDueDateEngineModel()
                {
                    ArchiveDueDateCriteria = dr[ArchiveDueDateField.ArchiveDueDateCriteria.ToString()].ToString(),
                    OriginalDate = (dr[ArchiveDueDateField.OriginalDate.ToString()] is DBNull ? DateTime.MinValue : DateTime.Parse(dr[ArchiveDueDateField.OriginalDate.ToString()].ToString())),
                    ArchiveDueDate = (dr[ArchiveDueDateField.ArchiveDueDate.ToString()] is DBNull ? DateTime.MinValue : DateTime.Parse(dr[ArchiveDueDateField.ArchiveDueDate.ToString()].ToString())),
                    ExpectedDocumentationCompletionDate = (dr[ArchiveDueDateField.ExpectedDocumentationCompletionDate.ToString()] is DBNull ? DateTime.MinValue : DateTime.Parse(dr[ArchiveDueDateField.ExpectedDocumentationCompletionDate.ToString()].ToString())),
                    DeliverableType = dr[ArchiveDueDateField.DeliverableType.ToString()].ToString(),
                    ArchiveApprovedDate = (dr[ArchiveDueDateField.ArchiveApprovedDate.ToString()] is DBNull ? DateTime.MinValue : DateTime.Parse(dr[ArchiveDueDateField.ArchiveApprovedDate.ToString()].ToString())),
                    OfficeZone = dr[ArchiveDueDateField.OfficeZone.ToString()].ToString(),
                };
            }
            return archiveDueDate;


        }

    }
}
