import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ExistingArchivesService {
apidata:any;
  constructor(private _http: HttpClient) { }

  httpOptions = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json'
          })
        } 

public getExistingArchives(seacrhTerm:string, userAlias: string, pagenumber: number, pagesize: number):Observable<any[]>{
    return this._http.get<any[]>("archive/GetExistingArchivesDetails?wbsLevelOne=" + seacrhTerm +"&PageNumber="+pagenumber + "&PageSize="+pagesize);
   }


}
