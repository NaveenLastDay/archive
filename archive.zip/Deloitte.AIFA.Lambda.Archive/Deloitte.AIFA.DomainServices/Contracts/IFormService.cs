﻿using Deloitte.AIFA.DomainEntities;
using System.Collections.Generic;

namespace Deloitte.AIFA.DomainServices.Contracts
{
    public interface IFormService
    {
        FormActionResponse CreateOrUpdateForm(FormSubmitInfo submitForm);
        List<Form> GetFormsPrepopulatedData(string archiveNumber, string loggedInUser);
        FormActionResponse ApproveForm(ApproveOrRejectFormRequest request);
        FormActionResponse RejectForm(ApproveOrRejectFormRequest request);
        FormActionResponse ChangeApprover(ChangeApproverRequest request);
    }
}
