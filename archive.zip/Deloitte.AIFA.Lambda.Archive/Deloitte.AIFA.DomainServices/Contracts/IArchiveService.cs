﻿
using Deloitte.AIFA.DomainEntities;
using Deloitte.AIFA.DomainEntities.Report;
using Deloitte.AIFA.Helpers.ExcelGenerator;
using System;
using System.Collections.Generic;

namespace Deloitte.AIFA.DomainServices.Contracts
{
    public interface IArchiveService
    {
        Archive GetArchiveDetail(int archiveId);

        List<EngagementType> GetEngagementType();

        List<ArchiveType> GetArchiveType();

        List<EntityType> GetEntityType();

        List<ProfessionalStandards> GetProfessionalStandard();
        List<RetentionReason> GetRetentionReasons();
        List<ActiveRoles> GetActiveRoles(string ArchiveNumber);
        List<ActiveRoles> GetActiveRolesForRequestTemporaryAccess(string ArchiveNumber);

        List<ArchiveTeamHistory> GetArchiveTeamHistory(string ArchiveNumber, int PageNumber, int PageSize, int SortBy);
        List<ArchiveSearchBase> GetWBSSerchResults(string term, int rowcount);

        WBSDetails GetWBSDetails(string wbsLevelOne);

        string CreateArchiveRetention(ArchiveRetention archiveRetention);

        string CreateArchiveLegalHold(ArchiveLegalHold archiveLegalHold);

        Archive CreateArchive(Archive archive);

        //List<MyArchive> GetMyArchives(int personnelNumber, int pageNumber, int pageSize, string sortDirection, string orderBy, string search);
        List<MyArchive> GetMyArchives(string employeeUniqueIdentifier, int pageNumber, int pageSize, int sortBy, int filterBy, string filterText);

        List<ArchiveAccessRequestForApproval> GetArchiveAccessRequestsForApproval(string EmployeeUniqueIdentifier, int PageNumber, int PageSize);

        ArchiveAccessRequestDetailsReport GetArchiveAccessRequestDetailsReport(string EmployeeUniqueIdentifier, int PageNumber = 0, int PageSize = 0);

        List<XlsxSheetToGenerate> GetBoxListingReportSheets(ArchiveAccessRequestDetailsReport boxListingReportSheets);

        RequestCountForApproval GetArchiveAccessRequestCountForApproval(string EmployeeUniqueIdentifier);

        RequestCountForApproval GetForm3283sCountForApproval(string EmployeeUniqueIdentifier);

        List<ArchiveAccessRequestDetails> GetArchiveAccessRequestsDetailsReport(string EmployeeUniqueIdentifier, int PageNumber = 0, int PageSize = 0);

        List<MyForm3283Data> GetForm3283RequestDetailsToExportToExcel(string EmployeeUniqueIdentifier, int PageNumber = 0, int PageSize = 0);

        List<MyPendingSubmissionData> GetMyPendingSubmissionDashBoardDataToExcel(string EmployeeUniqueIdentifier, int PageNumber = 0, int PageSize = 0);


        MyArchiveDetails GetMyArchiveDetails(string ArchiveNumber);

        List<ExistingArchivesInfo> GetExistingArchivesDetails(string wbsLevelOne, string userAlias, int PageNumber, int PageSize);

        ProjectMetaData GetSwiftEngagementInfo(string wbsLevelOne);

        EditArchiveDetails GetEditArchiveDetails(string archiveNumber);
        AutoCreateArchiveDetails GetAutoCreateArchiveDetails(string archiveNumber);

        string UpdateArchiveDetails(UpdateArchive updateArchive);

        ArchiveDetails GetArchiveDetailsInfo(string archiveNumber, string employeeUniqueIdentifier);

        int GetMatRoiUpdates(string archiveNumber);

        string UpdateArchiveTeam(ArchiveTeam archiveTeam, string UserAlias);

        List<MyArchivesFilterData> GetMyArchivesFilterDataByType(string employeeUniqueIdentifier, int filterBy);

        void LogMessageId(string messageId);
        ArchiveSubmission CreateArchiveSubmission(ArchiveSubmission archiveSubmission, string userAlias = "");
        ArchiveRetentionDetails GetArchiveRetentionDetails(string archiveNumber);

        string UpdateEstimatedReleaseDate(string ArchiveNumber, DateTime EstimatedReleaseDate);

        string SubtantiveResubmissionUpdatePPDorNPPD(string ArchiveNumber, string CreatedBy, string PPDUserAlias, int IsPPD);

        ArchiveSubmissionStatus GetDateAndPeoplePickerStatus(string archiveNumber, string userAlias);

        LinkedArchivesStatus GetLinkedArchiveStatus(string archiveNumber, string userAlias);

		EngagementRelatedPersonalStatus GetEngagementRelatedPersonalStatus(string archiveNumber);

		List<ArchiveAtcionsForIndividualSections> GetArchiveAtcionsForIndividualSections(string archiveNumber);

		WorkingPapersStatus GetWorkingPapersStatus(string archiveNumber, string userAlias);
		DeliverablesStatus GetDeliverablesStatus(string archiveNumber, string userAlias);

        RetentionExceptionStatus GetRetentionExceptionStatus(string archiveNumber, string userAlias);

        ArchiveSubmissionStatus GetArchiveSubmissionStatus(string archiveNumber, string userAlias);
        EarlyTerminationCeasedDate UpdateEarlyTerminationDate(EarlyTerminationCeasedDate EarlyTerminationValues);
        EarlyTerminationCeasedDate FetchEarlyTerminationDate(EarlyTerminationCeasedDate FetchEarlyTerminationValues);

        string InsertTempArciveTeam(TemporaryArchiveTeam archiveTeam);
        InsertArchiveAccessRequest CreateTempArchiveAccessRequest(RequestTemporaryArchiveAccess requestAccess);
        FormStatus GetFormStatus(string archiveNumber, int timeOffset = 0);
        string GrantDenyTempArchiveAccessRequest(GrantDenyTemporaryArchiveAccess argGrantDenyAccess, string userAlias);
        Object GetTemporaryArchiveAccessRequest(GrantDenyTemporaryArchiveAccess argGrantDenyAccess);
        ArchiveDueDateEngine GetArchiveDueDateCriteria(string ArchiveNumber, string UserAlias);
        List<ArchiveDeletionStatus> GetArchiveDeletionStatus(string ArchiveNumber);
        string ArchiveResubmissionOpen(ArchiveSubmission archiveSubmission);

        List<ResubmissionApprover> GetResubmissionApproverDetails(string ArchiveNumber, string UserAlias);

        (string successMessage, string archiveStatus, string zoneName) InsertResubmissionApprover(string UserAlias, string ArchiveNumber, int? RoleID);
        List<ResubmissionApproverList> SubtantiveResubmissionGetPPDorNPPD(string ArchiveNumber);
        IList<string> GetROINumbers(string archiveNumber);
        bool UpdateRoiFilePath(string archiveNumber, string roiNumber, string eTag, long fileTransferId, string s3FilePath, string createdBy);
        // IList<ROIFileDetails> GetROIFiles(string archiveNumber);
        string GetUserAlias(string employeeUniqueIdentifier);
        Memo CreateOrUpdateMemo(Memo memoModel);
        List<ResubmissionReason> GetResubmissionReasons();
        List<Memo> GetUploadedMemo(string ArchiveNumber);
        string DeleteUploadedMemo(string ArchiveFileID, string userAlias);
        string InsertUpdateArchiveSubmissionFlow(string ArchiveNumber, string UserAlias);
        GetArchiveApproverFromSubmitter GetArchiveApproverforArchiveSubmission(string ArchiveNumber, string UserAlias, int RoleID);
        GetArchiveApproverFromSubmitter CheckAPSubmitterInactive(string ArchiveNumber, string UserAlias, int CheckType);
        string UpdateFirstLevelResubmissionApprovalFlag(string UserAlias, string ArchiveNumber);

        List<ArchiveHistory> GetArchiveHistory(string ArchiveNumber, int PageNumber, int PageSize, int SortBy);
        List<MyPendingSubmissionData> GetMyRequiringApprovalDashBoardDataToExcel(string userAlias, int pageNumber, int pageSize);
        List<MyPendingSubmissionData> GetMyAwaitingApprovalDashBoardDataToExcel(string userAlias, int pageNumber, int pageSize);
        List<MyPendingSubmissionData> GetDeletionRequestsDashBoardDataToExcel(string userAlias, int pageNumber, int pageSize);

        string DeleteArchive(ArchiveDeletionAction deletionrequest);
        OmniaArchiveSubmissionStatus CheckOmniaSubmissionAllowed(string archiveNumber);
        List<Binders> GetBinderDetails(string archiveNumber, int pageNumber, int pageSize, int sortBy);
		List<AppliedArchiveHoldsInformation> ApplyArchiveHolds(ApplyArchiveHolds applyArchiveHolds);

		List<HoldHistoryDetails> GetHoldHistoryDetails(int HoldId,string HoldNumber,int ArchiveHoldHistoryId);
		string RemoveArchiveFromHold(int HoldId, string ArchiveNumber, string userAlias);
		string RemoveHoldFromArchive(string ArchiveNumber, string HoldNumber, string userAlias);

		List<HoldDetailsMetadata> GetArchivesAssociatedtoHolds(string HoldNumber, int BusinessId, string ClientId, string FilterText, int SortBy);

		string CreateRequestImageAction(RMIntegrationActions requestImage);
        List<AppliedArchiveHoldsInformation> GetArchivesForApplyingHold(string searchBy, string searchByValue, string includeOrExclude, string holdName, string business, string periodStart, string periodEnd, string sortBy, string sortOrder, int pageNumber, int pageSize);
    }
}
