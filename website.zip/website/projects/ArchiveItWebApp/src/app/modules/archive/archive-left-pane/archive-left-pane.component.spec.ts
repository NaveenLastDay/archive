import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ArchiveLeftPaneComponent } from './archive-left-pane.component';

describe('ArchiveLeftPaneComponent', () => {
  let component: ArchiveLeftPaneComponent;
  let fixture: ComponentFixture<ArchiveLeftPaneComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ArchiveLeftPaneComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ArchiveLeftPaneComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
