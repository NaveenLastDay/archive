﻿using Deloitte.AIFA.DomainServices.Contracts;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Deloitte.AIFA.Lambda.Archive.Controllers
{
    [Route("api/ArchiveSearch")]
    [ApiController]
    public class ArchiveSearchController : ControllerBase
    {
        IArchiveSearchService _archiveSearchService;
        ILogger _logger { get; set; }
        public ArchiveSearchController(IArchiveSearchService archiveSearchServie, ILogger<ArchiveController> logger)
        {
            _logger = logger;
            _archiveSearchService = archiveSearchServie;

            _logger.LogInformation("ArchiveSearch Detail Controller Initiated");
        }
        [HttpGet]
        [Route("GetSearchResults")]
        public IActionResult GetSearchResults(string search, string category)
        {
            var SearchResults = _archiveSearchService.SearchByCategory(search, category);
            _logger.LogInformation("GetArchiveSearchDetail: " + System.Web.HttpUtility.HtmlEncode(search + category));
            return Ok(SearchResults);
        }
    }
}