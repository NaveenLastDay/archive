﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DataModels
{
    public class UtilityMetaDataModel
    {
        //public string EngagementDesc { get; set; }
        //public DateTime PeriodEnd { get; set; }
        //public string EngagementType { get; set; }
        //public bool IsDeliverable { get; set; }
    }
}
