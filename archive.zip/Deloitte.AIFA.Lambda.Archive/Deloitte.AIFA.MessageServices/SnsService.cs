﻿using Deloitte.AIFA.IMessageServices;

namespace Deloitte.AIFA.MessageServices
{
    public class SnsService : IPushMessageService
    {
        public bool PushMesageToQueue(string message)
        {
            //Pushed to queue

            return true;
        }
    }
}
