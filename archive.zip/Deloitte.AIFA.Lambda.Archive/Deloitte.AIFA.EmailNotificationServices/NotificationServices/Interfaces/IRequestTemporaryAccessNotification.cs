﻿using Deloitte.AIFA.DomainEntities;
using Deloitte.AIFA.DomainEntities.EmailEntities;
using Deloitte.AIFA.EmailNotificationServices.NotificationEntities;
using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.EmailNotificationServices.NotificationServices.Interfaces
{
    interface IRequestTemporaryAccessNotification
    {
        BaseEmailEntity GetTemporaryAceessRaisedNotification(string argOperationType, string argOperationDescription, string argTemplateId, RequestTemporaryArchiveAccess argRTA, InsertArchiveAccessRequest IA);
        BaseEmailEntity GetTemporaryAceessGrantedNotification(string argOperationType, string argOperationDescription, string argTemplateId, string otherInfo);
        BaseEmailEntity GetTemporaryAceessRejectedNotification(string argOperationType, string argOperationDescription, string argTemplateId,GrantDenyTemporaryArchiveAccess argGrantDeny, string userAlias);
    }
}
