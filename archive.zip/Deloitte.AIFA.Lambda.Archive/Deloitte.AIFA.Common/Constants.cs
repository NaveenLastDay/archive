﻿
namespace Deloitte.AIFA.Common
{
    public static class Constants
    {
        //public const string Env_Development1 = "d1";
        //public const string Env_Development2 = "d2";
        //public const string Env_QA1 = "q1";
        //public const string Env_QA2 = "q2";
        //public const string Env_Stage1 = "s1";
        //public const string Env_Stage2 = "s2";
        //public const string Env_Production = "prodution";
        public const string DBDataSource = "<%DataSource%>";
        public const string DBDatabase = "<%Database%>";
        public const string DBLUserID = "<%UserId%>";
        public const string DBPassword = "<%Password%>";
        public const string DBConnectionstring = "DBConnectionString";
        public const string DBConnectionstringReader = "DBConnectionstringReader";

        public const string Action = "ROI.UpdateArchiveNumbers";
        public const string App = "ArchiveIT";
        public const string Country = "US";
    }
}
