import { Component, OnInit, OnDestroy, Renderer2, Inject } from '@angular/core';
import { ArchiveService } from '../../../services/archive.service';
import { GrantDenyTemporaryArchiveAccess } from './grantDeny.model';
import { ModalService } from '../../shared/modal';
import { CKEditorModule } from 'ng2-ckeditor';
import { DOCUMENT } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
// import { NgxSpinnerService } from 'ngx-spinner';
import { NotifierService } from 'angular-notifier';

@Component({
  selector: 'app-dashboard-temporary-access',
  templateUrl: './dashboard-temporary-access.component.html',
  styleUrls: ['./dashboard-temporary-access.component.css']
})
export class DashboardTemporaryAccessComponent implements OnInit, OnDestroy {
  grantDenyTemporaryArchiveAccess = new GrantDenyTemporaryArchiveAccess();
  Alert: string = '';
  BodyCount: number = 0;
  getTemporaryArchiveData: any;
  archiveIDValFromParent: any;
  ckEditorForm: FormGroup;
  bodytext: any;
  boxInput: any;
  modelTypeForDeny: string;

  constructor(private archiveSrv: ArchiveService, private notifier: NotifierService, private formBuilder: FormBuilder, private router: Router, private activatedRoute: ActivatedRoute, private modalService: ModalService, private _renderer2: Renderer2, @Inject(DOCUMENT) private _document: Document) {
    console.log('this.activatedRoute.snapshot.params', this.activatedRoute);
  }

  //  ckeditorConfig:CKEditorModule={
  //         allowedContent: false,
  //         extraPlugins:'autolink',
  //         forcePasteAsPlainText: true,
  //         toolbar: 'Full',
  //         height:"70px",
  //         removeButtons: 'Source,Save,ImageButton,NewPage,Preview,Print,Templates,Cut,Copy,Paste,PasteText,PasteFromWord,Undo,Redo,Find,Replace,SelectAll,Scayt,Form,Checkbox,Radio,TextField,Textarea,Select,Button,HiddenField,Strike,Subscript,Superscript,CopyFormatting,RemoveFormat,Outdent,Indent,CreateDiv,Blockquote,BidiLtr,BidiRtl,Language,Unlink,Anchor,Imagebutton,Flash,Table,HorizontalRule,Smiley,SpecialChar,PageBreak,Iframe,Maximize,ShowBlocks,About',
  //         removePlugins : 'elementspath'
  //     };

  ngOnInit() {
    this.checkSize();
    // this.disableBack();
    this.ckEditorForm = this.formBuilder.group({
      denyReason: new FormControl('', [Validators.required, Validators.minLength(5)])
    });
    // this.SpinnerService.show();
    this.archiveIDValFromParent = this.archiveSrv.GetArchiveIdChildVal();
    console.log('this.archiveIDValFromParent', this.archiveIDValFromParent);
    this.grantDenyTemporaryArchiveAccess.ArchiveAccessRequestId = this.archiveIDValFromParent;
    this.grantDenyTemporaryArchiveAccess.GrantDenyReason = '';
    this.grantDenyTemporaryArchiveAccess.GrantOrDeny = '';
    this.archiveSrv.GetTemporaryArchiveAccessRequest(this.grantDenyTemporaryArchiveAccess).subscribe((data) => {
      console.log(data);
      this.getTemporaryArchiveData = data;
      // this.SpinnerService.hide();
    });
    let element = document.getElementById("customBreadcrumb");
    element.classList.add("custom-breadcrumb");
    let element1 = document.getElementById("spnBreadcrumbTxt");
    element1.classList.add("spn-breadcrumb-text");
    let element2 = document.getElementById("spnLiBreadcrumb");
    element2.classList.add("spn-li-breadcrumb");

    // const s = this._renderer2.createElement('script');
    // s.src = 'https://cdn.ckeditor.com/4.15.1/full-all/ckeditor.js';
    // s.text = ``;
    // this._renderer2.appendChild(this._document.body, s);
  }
  ngOnDestroy() {
    let element = document.getElementById("customBreadcrumb");
    element.classList.remove("custom-breadcrumb");
    let element1 = document.getElementById("spnBreadcrumbTxt");
    element1.classList.remove("spn-breadcrumb-text");
    let element2 = document.getElementById("spnLiBreadcrumb");
    element2.classList.remove("spn-li-breadcrumb");
    let element4 = document.getElementById("temporaryAccessReasondiv");
    element4.classList.add("pb-custom-96");
    let element5 = document.getElementById("temporaryAccessReasondiv");
    element5.classList.remove("pb-custom-27");
    let element3 = document.getElementById("temporaryAccessReasondiv");
    element3.classList.remove("pb-custom-180");
    let element6 = document.getElementById("temporaryAccessReasondiv");
    element6.classList.remove("pb-custom-272");
    this.ckEditorForm.reset();
  }
  //   disableBack() {
  //   window.history.forward();
  // }
  sendRequestAccess() {
    // this.SpinnerService.show();
    this.grantDenyTemporaryArchiveAccess.ArchiveAccessRequestId = this.getTemporaryArchiveData.archiveAccessRequestID;
    this.grantDenyTemporaryArchiveAccess.GrantDenyReason = 'Granted';
    this.grantDenyTemporaryArchiveAccess.GrantOrDeny = '1';

    this.archiveSrv.GrantDenyTempArchiveAccessRequest(this.grantDenyTemporaryArchiveAccess).subscribe((data) => {
      // console.log('data',data);
      // this.SpinnerService.hide();
      this.notifier.notify("success", "Access request has been approved successfully.");
      setTimeout(() => {
        this.router.navigate(['/home'], { replaceUrl: true });
      }, 1000)
    });
  }
  confirmRequest() {
    // this.SpinnerService.show();
    this.grantDenyTemporaryArchiveAccess.ArchiveAccessRequestId = this.getTemporaryArchiveData.archiveAccessRequestID;
    this.grantDenyTemporaryArchiveAccess.GrantDenyReason = this.bodytext;
    this.grantDenyTemporaryArchiveAccess.GrantOrDeny = '0';

    this.archiveSrv.GrantDenyTempArchiveAccessRequest(this.grantDenyTemporaryArchiveAccess).subscribe((data) => {
      // console.log('data', data);
      // this.SpinnerService.hide();
      this.closeModalDialog(this.modelTypeForDeny);
      this.notifier.notify("success", "Access request has been rejected successfully.");
      setTimeout(() => {
        this.router.navigate(['/home'], { replaceUrl: true });
      }, 1000)
    });
  }
  openModal(modalType: string) {
    this.modelTypeForDeny = modalType;
    this.modalService.openWithCustomWidth(modalType, "600");
  }

  closeModalDialog(Action) {
    this.ckEditorForm.reset();
    this.modalService.close(Action);
    this.bodytext = '';
    this.boxInput = '';
  }
  // onchangeBody(boxInput) {  
  //   this.boxInput = boxInput;  
  //   this.bodytext=boxInput.replace(/<\/?[^>]+(>|$)/g,"").trim('');
  //   console.log(this.bodytext);
  //   this.BodyCount = this.bodytext.length;
  //   console.log('boxinput',boxInput,this.BodyCount);
  // }
  onKeyUp(event) {
    this.bodytext = event.target.value;
    this.BodyCount = event.target.value.length;
  }
  checkSize() {
    console.log(window.devicePixelRatio);
    if (window.devicePixelRatio == 1.5) {
      let element = document.getElementById("temporaryAccessReasondiv");
      element.classList.add("pb-custom-27");
      let element1 = document.getElementById("temporaryAccessReasondiv");
      element1.classList.remove("pb-custom-96");
      let element2 = document.getElementById("temporaryAccessReasondiv");
      element2.classList.remove("pb-custom-180");
      let element3 = document.getElementById("temporaryAccessReasondiv");
      element3.classList.remove("pb-custom-272");
    }
    else if ((window.devicePixelRatio <= 1.35) && (window.devicePixelRatio > 1.3)) {
      let element = document.getElementById("temporaryAccessReasondiv");
      element.classList.add("pb-custom-96");
      let element1 = document.getElementById("temporaryAccessReasondiv");
      element1.classList.remove("pb-custom-27");
      let element2 = document.getElementById("temporaryAccessReasondiv");
      element2.classList.remove("pb-custom-180");
      let element3 = document.getElementById("temporaryAccessReasondiv");
      element3.classList.remove("pb-custom-272");
    }
    else if ((window.devicePixelRatio >= 1.1) && (window.devicePixelRatio <= 1.22)) {
      let element = document.getElementById("temporaryAccessReasondiv");
      element.classList.add("pb-custom-180");
      let element1 = document.getElementById("temporaryAccessReasondiv");
      element1.classList.remove("pb-custom-27");
      let element2 = document.getElementById("temporaryAccessReasondiv");
      element2.classList.remove("pb-custom-96");
      let element3 = document.getElementById("temporaryAccessReasondiv");
      element3.classList.remove("pb-custom-272");
    }
    else if (window.devicePixelRatio == 1) {
      let element = document.getElementById("temporaryAccessReasondiv");
      element.classList.remove("pb-custom-180");
      let element1 = document.getElementById("temporaryAccessReasondiv");
      element1.classList.remove("pb-custom-27");
      let element2 = document.getElementById("temporaryAccessReasondiv");
      element2.classList.remove("pb-custom-96");
      let element3 = document.getElementById("temporaryAccessReasondiv");
      element3.classList.add("pb-custom-272");
    }
  }

}

