﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
    public class MyArchive
    {
        public int ArchiveID { get; set; }
        public string ArchiveNumber { get; set; }
        public string Description { get; set; }
        public DateTime PeriodEndDate { get; set; }
        public string EngagementDescription { get; set; }
        public string ClientName { get; set; }
        public string WBSLevelOneName { get; set; }
        public DateTime EstimatedIssuanceReportDate { get; set; }
        public string Business { get; set; }
        public string WBSLevelOne { get; set; }
        public string ArchiveType { get; set; }
        public string SubmissionStatus { get; set; }
        public int RowNumber { get; set; }
        public int Count { get; set; }
        public bool IsPrivacyPeriodExp { get; set; }
        public bool IsTemporary { get; set; }
        public string EntityTypeDescription { get; set; }
        public string ProfessionalStandardDescription { get; set; }
        public bool IsArchiveCompleted { get; set; }
    }
}
