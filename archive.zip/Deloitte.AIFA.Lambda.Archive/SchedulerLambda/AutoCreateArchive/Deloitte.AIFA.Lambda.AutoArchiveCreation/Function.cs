using System;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using MySqlConnector;
using Amazon.Lambda.Core;
using Deloitte.AIFA.Lambda.AutoArchiveCreation.Services;
using Deloitte.AIFA.DBHelper;
using Newtonsoft.Json;
using Deloitte.AIFA.Lambda.AutoArchiveCreation.Entities;
using Deloitte.AIFA.PushMessageSNSHelper;
using Deloitte.AIFA.EmailNotificationServices.NotificationServices.Services;
using Deloitte.AIFA.DomainEntities.EmailEntities;
using Deloitte.AIFA.EmailNotificationServices;
using System.Linq;
using System.Data;
using System.Collections.Generic;
using Deloitte.AIFA.EmailNotificationServices.NotificationEntities;
using Newtonsoft.Json.Linq;

// Assembly attribute to enable the Lambda function's JSON input to be converted into a .NET class.
[assembly: LambdaSerializer(typeof(Amazon.Lambda.Serialization.Json.JsonSerializer))]

namespace Deloitte.AIFA.Lambda.AutoArchiveCreation
{
    public class Function
    {
        public const string DBConnectionstring = "DBConnectionString";
        IEmailNotificationService _emailNotificationService;

        public Function()
        {
            _emailNotificationService = new EmailNotificationService();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="input"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        public string FunctionHandler(JObject input, ILambdaContext context)
        {
            AutoCreateArchive();
            Console.WriteLine("Success");
            return "Success";
        }

        private void AutoCreateArchive()
        {
            try
            {
                var sourceType = "In Scheduled Lambda: " + System.Reflection.Assembly.GetEntryAssembly().GetName().Name;
                LambdaLogger.Log(String.Format("{0} :", LogCategory.Information.ToString()) + " :" + "Calling Auto Archive Creation Sp");
                var provider = new ServiceCollection()
                                    .AddMemoryCache()
                                    .BuildServiceProvider();
                var cache = provider.GetService<IMemoryCache>();
                var builders = new ConfigurationBuilder()
                                   .AddJsonFile("appsettings.json");
                var config = builders.Build();
                LambdaLogger.Log(String.Format("{0} :", LogCategory.Information.ToString()) + " :" + "Built Configuration in AutoArchiveCreation");
                SecretsManagerService secret = new SecretsManagerService(config, cache);
                LambdaLogger.Log(String.Format("{0} :", LogCategory.Information.ToString()) + " :" + "Connection string constructed in AutoArchiveCreation");
                var connectionString = cache.Get<string>(DBConnectionstring);
                MySqlCommand cmd = new MySqlCommand();

                DataAccessHelper dataobj = new DataAccessHelper(connectionString);
                Console.WriteLine("connection established");
                //dataobj.ExecuteNonQuery("pub_AIFA_AutoCreateEnagagementArchive ", null, true, null);
                EventSource eventSource = eventSource = dataobj.ExecuteReader<EventSource>("pub_AIFA_AutoCreateEnagagementArchive", null, x => { x.Read(); return new EventSource() { EventSourceID = int.Parse(x["EventSourceID"]?.ToString()), Metadata = x["Metadata"].ToString(), EventTypeID = int.Parse(x["EventTypeID"].ToString()) }; }, true, null);

                if (eventSource != null && eventSource.EventSourceID > 0 && eventSource.Metadata != null && eventSource.Metadata != string.Empty)
                {
                    var jsonData = JsonConvert.SerializeObject(new { EventSourceID = eventSource.EventSourceID, EventTypeID = eventSource.EventTypeID, Metadata = eventSource.Metadata });
                    LambdaLogger.Log($"Before calling PushMessageSNS service, jsonData : {jsonData}.");
                    PushMessageSNS obj = new PushMessageSNS("redshiftDataRefreshNotifyArn");
                    string messageId = obj.PushMsgtoSNS(jsonData).Result;
                    LambdaLogger.Log("After calling PushMessageSNS service.");

                    if (messageId != null && messageId != string.Empty)
                    {
                        LambdaLogger.Log("After calling PushMessageSNS service.");
                        LambdaLogger.Log("SNS MessageId: " + messageId + " for EventSourceID: " + eventSource.EventSourceID + " for Metadata: " + eventSource.Metadata);
                    }
                    // Get auto created archives for email sender
                    GetAutoCreatedArchiveDetails();
                }

                LambdaLogger.Log(String.Format("{0} :", LogCategory.Information.ToString()) + "SP Executed successfully");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                LambdaLogger.Log(String.Format("{0} :", LogCategory.Error.ToString()) + ": AutoArchiveCreation exception :" + ex.Message);
                Console.WriteLine($"Exception occured while processing AutoCreateArchive method ErrorMessage: {ex.Message}, Stacktrace: {ex.StackTrace}.");
            }

        }

        public void GetAutoCreatedArchiveDetails()
        {
            try
            {
                LambdaLogger.Log(String.Format("{0} :", LogCategory.Information.ToString()) + " :" + "Calling Auto Archive Get Details (GetAutoCreatedArchiveDetails) Method");
                var provider = new ServiceCollection().AddMemoryCache().BuildServiceProvider();
                var cache = provider.GetService<IMemoryCache>();
                var builders = new ConfigurationBuilder().AddJsonFile("appsettings.json");
                var config = builders.Build();

                LambdaLogger.Log(String.Format("{0} :", LogCategory.Information.ToString()) + " :" + "Built Configuration in Auto Archive Get Details");
                SecretsManagerService secret = new SecretsManagerService(config, cache);

                LambdaLogger.Log(String.Format("{0} :", LogCategory.Information.ToString()) + " :" + "Connection string constructed in Auto Archive Get Details");
                var connectionString = cache.Get<string>(DBConnectionstring);

                MySqlCommand cmd = new MySqlCommand();
                DataAccessHelper dataobj = new DataAccessHelper(connectionString);
                Console.WriteLine("connection established");

                LambdaLogger.Log(String.Format("{0} :", LogCategory.Information.ToString()) + " :" + "Connection establishing and Calling Auto Created Archive Get Details SP");
                List<AutoCreateArchive> archiveListObject = new List<AutoCreateArchive>();
                MySqlConnection mcn = new MySqlConnection(connectionString);
                mcn.Open();
                MySqlCommand smd = new MySqlCommand("CALL pub_AIFA_GetListOfAutoCreatedAchives();", mcn);
                smd.CommandType = CommandType.Text;
                MySqlDataReader dr = smd.ExecuteReader();
                while (dr.Read())
                {
                    AutoCreateArchive archiveObj = new AutoCreateArchive();
                    archiveObj.ArchiveNumber = dr["ArchiveNumber"] == DBNull.Value ? string.Empty : dr["ArchiveNumber"].ToString();
                    archiveObj.WBSLevelOneNumber = dr["WBSLevelOneNumber"] == DBNull.Value ? string.Empty : dr["WBSLevelOneNumber"].ToString();
                    archiveObj.ClientName = dr["ClientName"] == DBNull.Value ? string.Empty : dr["ClientName"].ToString();
                    archiveObj.EstimatedDate = dr["EstimatedDate"] == DBNull.Value ? string.Empty : dr["EstimatedDate"].ToString();
                    archiveObj.ArchivePartnerAlias = dr["ArchivePartnerAlias"] == DBNull.Value ? string.Empty : dr["ArchivePartnerAlias"].ToString();
                    archiveObj.ArchiveManagerAlias = dr["ArchiveManagerAlias"] == DBNull.Value ? string.Empty : dr["ArchiveManagerAlias"].ToString();
                    archiveObj.ArchivePartnerName = dr["ArchivePartnerName"] == DBNull.Value ? string.Empty : dr["ArchivePartnerName"].ToString();
                    archiveObj.ArchiveManagerName = dr["ArchiveManagerName"] == DBNull.Value ? string.Empty : dr["ArchiveManagerName"].ToString();
                    archiveObj.IsArchiveCompleted = dr["IsArchiveCompleted"] == DBNull.Value ? string.Empty : dr["IsArchiveCompleted"].ToString();
                    archiveListObject.Add(archiveObj);
                }
                //var archiveSource = dataobj.ExecuteReader("pub_AIFA_GetListOfAutoCreatedAchives", null, dr => new AutoCreateArchiveTransformer().Transform(dr).ToList());

                LambdaLogger.Log(String.Format("{0} :", LogCategory.Information.ToString()) + "pub_AIFA_GetListOfAutoCreatedAchives SP Executed successfully");

                if (archiveListObject != null && archiveListObject.Count > 0)
                {
                    foreach (var archive in archiveListObject)
                    {
                        LambdaLogger.Log(String.Format("{0} :", LogCategory.Information.ToString()) + " :" + "Preparing email notification data for Archive Number: " + archive.ArchiveNumber);
                        string toEmails = archive.ArchivePartnerAlias + ";" + archive.ArchiveManagerAlias;
                        var jsonData = JsonConvert.SerializeObject(new { ArchiveNumber = archive.ArchiveNumber, WBSLevelOne = archive.WBSLevelOneNumber, ClientName = archive.ClientName, EstimatedDate = archive.EstimatedDate });
                        LambdaLogger.Log($"Before calling Email service, jsonData : {jsonData}.");

                        CreateArchiveNotification rtn = new CreateArchiveNotification();
                        BaseEmailEntity be = new BaseEmailEntity();
                        be = SetUpAutoArchive_Notification("AutoCreateArchive", "AutoCreateArchive", "62", archive.ArchiveNumber, archive.WBSLevelOneNumber, archive.ClientName, archive.EstimatedDate, toEmails);

                        PublishEmailNotification(be);
                        LambdaLogger.Log(String.Format("{0} :", LogCategory.Information.ToString()) + "published email notification for Archive Number: " + archive.ArchiveNumber);
                    }
                }
                LambdaLogger.Log(String.Format("{0} :", LogCategory.Information.ToString()) + "GetAutoCreatedArchiveDetails method executed successfully");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                LambdaLogger.Log(String.Format("{0} :", LogCategory.Error.ToString()) + ": Auto Archive Get Details or publish email service exception :" + ex.Message);
                Console.WriteLine($"Exception occured while processing Auto Archive Get Details method ErrorMessage: {ex.Message}, Stacktrace: {ex.StackTrace}.");
            }
        }

        private BaseEmailEntity SetUpAutoArchive_Notification(string argOperationType, string argOperationDescription, string argTemplateId, string ArchiveNumber, string WBSNumber, string ClientName, string EDCD, string toEmails)
        {
            BaseEmailEntity objTAR = new BaseEmailEntity();
            //Build Tag Values
            objTAR.MinimumTagValues = new Dictionary<string, string>();

            objTAR.MinimumTagValues.Add(EmailPlaceholders.ArchiveNumber, ArchiveNumber);

            objTAR.MinimumTagValues.Add(EmailPlaceholders.WbsLevelOneNumber, WBSNumber);

            objTAR.MinimumTagValues.Add(EmailPlaceholders.ClientName, ClientName);

            objTAR.MinimumTagValues.Add(EmailPlaceholders.EDCD, EDCD);

            objTAR.AdditionalInfo = toEmails;
            objTAR.TemplateId = argTemplateId;
            objTAR.OperationDescription = argOperationDescription;
            objTAR.OperationType = argOperationType;

            return objTAR;
        }

        public bool PublishEmailNotification(BaseEmailEntity argBE)
        {
            bool retval = false;
            try
            {
                PushMessageSNS objEmail = new PushMessageSNS("emailembeddednotifyarn");
                string JSONData = JsonConvert.SerializeObject(argBE);
                var messageIdEmail = objEmail.PushMsgtoSNS(JSONData).Result;
                Console.WriteLine("Message Pushed with Id" + messageIdEmail);
                retval = messageIdEmail == null ? false : true;
                LambdaLogger.Log(String.Format("{0} :", ": Auto created Archive Details published to email service Successfully:"));
            }
            catch (Exception ex)
            {
                LambdaLogger.Log(String.Format("{0} :", LogCategory.Error.ToString()) + ": Auto created Archive Details publish email service exception :" + ex.Message);
                // _emailNotificationService.PublishEmailNotification(argBE);

                Console.WriteLine(ex.Message);
                Console.WriteLine($"Exception occured while publishing Auto Archive Details to email service ErrorMessage: {ex.Message}, Stacktrace: {ex.StackTrace}.");
            }
            return retval;
        }
    }
}
