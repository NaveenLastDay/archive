import { DestructionBatch } from "./batch-details.model";

  export class SubBatchDetails{
    archiveNumber:string;
    clientName: string;
    eligibleDate: string;
    retentionAppliedtDate: string;
    holdFlag: string;
    uniqueId:number;
    hardCopyStatus:string;
    electronicStatus:string;
    barCode:string;
    ObjectsCount: number;
    linkedArchives: number;
    isSelected:boolean;
    destructionSubBatchRecordDetail= new Array<DestructionSubBatchRecordDetail>();
  }

  export enum SubBatchDetailsResultGridColumns
  {
    ArchiveNumber = 1,
    Client = 2,
    DestructionEligibleDate = 3,
    RetentionExceptionTriggerDate = 4,
    HoldFlag= 5,
    Objects = 6,
    UniqueId=7,
    IsPhysicalRecord=8,
    Barcode=9,
    ElectronicRecordStatus=10,
    HardCopyRecordStatus=11
  }

  export class DestructionSubBatch{
    batchID:number;
    batchNumber:string;
    destructionEligibleFromDate:string;
    destructionEligibleToDate:string;
    business:string;
    businessID:number;
    status:string;
    statusID:number;
    createdBy:string;
    createdDate:string;
    modifiedDate:string;
    modifiedBy:string;
    archivesLeft:number;
    archivesTotal:number;
    objectsTotal:number;
    objectsLeft:number;
    batchCount:number;
    recordsCount:number;
    operationType:number;
    userAlias:string;
  }

  export class SubBatchDetailsInfo{
    subBatch:DestructionSubBatch;
    subBatchDetails: SubBatchDetails[];
    inEligibleCount:number;
    totalRecords:number;
  }

  export class DestructionSubBatchRecordDetail{
    batchDetailsID:number;
    uniqueID:string;
    isPhysicalRecord:boolean;
    barCode:string;
    hardCopyRecordStatus:string;
    electronicRecordStatus:string;
    destructionStatus:number;
  }