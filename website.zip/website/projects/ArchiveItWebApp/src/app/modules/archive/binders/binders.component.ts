import { Router, ActivatedRoute, Params } from "@angular/router";
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { ArchiveService } from './../../../services/archive.service';
import { NotifierService, NotifierModule, NotifierOptions } from "angular-notifier";
import { ArchiveHomeService } from '../../../services/archive-home.service';
import { archiveInfoService } from '../../../services/archiveinfo.service'
import { ModalService } from "../../shared/modal";
import { EmployeeService } from '../../../services/employee.service'
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { UserActions } from '../../../models/archive-role.model';
import { PubsubService } from '../../../services/pubsub.service';
import { SharedService } from '../../../services/shared.service';

@Component({
  selector: 'binders',
  templateUrl: './binders.component.html',
  styleUrls: ['./binders.component.css']
})
export class BindersComponent implements OnInit {
  currentPageNumber: number = 1;
  readonly pageSize: number = 10;
  archiveNumber: string = '';
  appendBindersGrid: boolean = false;
  bindersData: any[];
  totalBinders: number = 0;
  sortByEnum: any = BindersSortBy;
  sortBy: number = this.sortByEnum.SortBy_BarCode_Asc;
  expand1: boolean[] = [];
  sortColumnDialog: number = -1;
  columnByEnum: any = BindersColumnBy;
  bindersResultGridColumns: any =BindersResultGridColumns;
  Message: string;
  readonly emptyStringInReport : string = " ";

  columnFilters: any[] =
  [
    {
      "displayName": "ID",
      "value": this.bindersResultGridColumns.ID,
      "checked": true
    },
    {
      "displayName": "Description",
      "value": this.bindersResultGridColumns.Description,
      "checked": true
    },
    {
      "displayName": "BarCode",
      "value": this.bindersResultGridColumns.BarCode,
      "checked": true
    },
    {
      "displayName": "Status",
      "value": this.bindersResultGridColumns.Status,
      "checked": true
    }
  ]

  userAlias =this.adalSvc.LoggedInUserEmail.substring(0, this.adalSvc.LoggedInUserEmail.lastIndexOf("@"));
  public initialDataLoaded: boolean = false;
  roleMapping = new UserActions();
  
  constructor(private SpinnerService: NgxSpinnerService
    , private archiveService: ArchiveService
    , private notifier: NotifierService
    , private archiveHomeService: ArchiveHomeService
    , private archiveInfoService: archiveInfoService,
    private pubsub: PubsubService,
    private adalSvc: MsAdalAngular6Service,
    private dataService: EmployeeService,
    private modalservice: ModalService,
    private activatedRoute: ActivatedRoute,
    private sharedService: SharedService,
    private router: Router,
  ) { }
 
  ngOnInit() {
    this.archiveNumber = this.activatedRoute.snapshot.parent.params.aN;
    this.roleMapping = this.pubsub.getRoleMappingResult();
    this.getBinders();
  }

  ngDoCheck() {
    this.roleMapping = this.pubsub.getRoleMappingResult();
  }

  ExpansionCollapse(Action, id) {
    if (Action === 'Fulldescription') {
      this.expand1[id] = true;

    }
    if (Action === 'Lessdescription') {
      this.expand1[id] = false;
    }
  }

  sortOrderChanged(event) {
    this.sortBy = event;
    this.getBinders();
  }

  memberSortDialog(event) {
    if (this.sortColumnDialog == event) this.sortColumnDialog = -1;
    else this.sortColumnDialog = event;
  }

  updateGridData(event) {
    this.appendBindersGrid = event.isLoadMoreClicked;
    this.currentPageNumber = event.pageNumber;
    this.getBinders();
  }

  getBinders() {
    //this.SpinnerService.show();
    this.archiveService.GetBinders(this.archiveNumber, this.currentPageNumber, this.pageSize, this.sortBy).subscribe(
      data => {
        if (this.appendBindersGrid && data) {
          this.bindersData = this.bindersData.concat(data);
        }
        else {
          this.bindersData = data ? data : [];
        }

        if (this.bindersData.length > 0) {
          this.totalBinders = this.bindersData[0]["count"];
        }
        else {
          this.totalBinders = 0;
        }

      //  this.SpinnerService.hide();
      }
    );
  }

  requestImageAction(binderID:number)
  {
    this.requestImageActiontoRM(binderID);
    this.Message = "Within 1 business day you will receive an email about the request status.";
    this.notifier.notify("success", this.Message);
    setTimeout(() => {
      this.router.navigate(["/archive/myarchives/"+ this.archiveNumber + "/archivehome"]);
    }, 3000); 
  }

  requestImageActiontoRM(binderID: number) {
    var parameters = {
      "ArchiveNumber":this.archiveNumber,
      "BinderID":binderID,
      "RequestedBy":this.userAlias,
      "RequestTypeID":1,
      "IsBinderOrDeliverable":1
    }
    this.archiveService.CreateRequestImageAction(parameters).subscribe(data => {
      let success = data;
      console.log(success);
    });
  }

  generateReportClicked(data1){
   // this.SpinnerService.show();
    let bindersForReport: any[] = [];
    let filterdColumns = (data1.filter(x => x.checked));
    this.archiveService.GetBinders(this.archiveNumber, this.currentPageNumber, this.pageSize, this.sortBy).subscribe(
      (data) => {
        debugger;
        if(data.length!=0)
        {
          data.forEach(element => {
            let binder = {};
            filterdColumns.forEach(column => {
              debugger;

              if (column["value"] == this.bindersResultGridColumns.ID) { //#
                binder[this.bindersResultGridColumns[this.bindersResultGridColumns.ID]] = element.rowNumber || this.emptyStringInReport;
              }

              if (column["value"] == this.bindersResultGridColumns.Description) { //Description
                binder[this.bindersResultGridColumns[this.bindersResultGridColumns.Description]] = element.description || this.emptyStringInReport;
              }

              if (column["value"] == this.bindersResultGridColumns.BarCode) { //Barcode
                binder[this.bindersResultGridColumns[this.bindersResultGridColumns.BarCode]] = element.barcode || this.emptyStringInReport;
              }

              if (column["value"] == this.bindersResultGridColumns.Status) { //Status
                binder[this.bindersResultGridColumns[this.bindersResultGridColumns.Status]] = element.physicalRecordStatus || this.emptyStringInReport;
              }
               
            });
            bindersForReport.push(binder);
          });
          if (bindersForReport && bindersForReport.length) {
            this.sharedService.generateExcel("BindersFor"+this.archiveNumber, "binders", filterdColumns.map(x => x.displayName), bindersForReport);
          }

        }
        
      }
      ,
      (err) => {
        console.log("error is ", "generateReportClicked", err)
      }
      );

  }
  
}

export enum BindersSortBy {
  SortBy_BarCode_Asc = 1,
  SortBy_BarCode_Desc = 2,
  SortBy_Status_Asc = 3,
  SortBy_Status_Desc = 4,
}

export enum BindersColumnBy {
  ColumnBy_Default = -1,
  ColumnBy_BarCode = 1,
  ColumnBy_Status = 2,
}

export enum BindersResultGridColumns
{
  ID = 1, 
  Description = 2, 
  BarCode = 3, 
  Status = 4, 
}

