﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
    public class DeliverablesStatus
    {
        public string deliverabledescription { get; set; }
        public string createdBy { get; set; }
    }
}
