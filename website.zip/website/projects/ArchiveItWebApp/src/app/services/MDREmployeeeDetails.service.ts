import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { catchError, map } from 'rxjs/operators';
import { throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PeoplePickerService {

  data = [];
  api: string = 'Utility/PeoplePickerFilter/';
  apiData: any;

  constructor(private _http: HttpClient) { }

  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'

    })
  }

  public GetPeople(parameters: string, rolecode?: string) {
    // // debugger;
    // this.apiData = this._http.get<any>(this.api
    //   + parameters+'/'+rolecode);
    // // // debugger;
    // return this.apiData;

    return this._http.get<any>(this.api
      + parameters + '/' + rolecode).pipe(
        map((data: any) => {
          return data;
        }), catchError(error => {
          return throwError('Something went wrong!');
        })
      );

  }


}


