﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
    public class ActionItem
    {
        public int EntityId { get; set; }
        public int ActionItemId { get; set; }
        public string ActionItemIdentifier { get; set; }
        public string ActionItemAssignedTo { get; set; }
        public string ActionItemAssignedToFullName { get; set; }
        public string ActionItemStatusDescription { get; set; }
        public DateTime? CompletedDate { get; set; }
    }

    public class ActionItemResponse
    {
        public bool IsSuccessful { get; set; }
        public DateTime? CompletedDate { get; set; }
        public string ActionItemStatusDescription { get; set; }
        public string ResponseMessage { get; set; }
    }
}
