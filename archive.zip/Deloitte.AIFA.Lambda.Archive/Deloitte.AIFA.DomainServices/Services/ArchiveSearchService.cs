﻿using Deloitte.AIFA.DomainEntities;
using Deloitte.AIFA.DomainServices.Contracts;
using Deloitte.AIFA.ICloudServices;
using Deloitte.AIFA.IRepositories;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;

namespace Deloitte.AIFA.DomainServices.Services
{
    public class ArchiveSearchService:BaseService, IArchiveSearchService
    {
        IArchiveSearchRepository _archiveRepository;
        ILogger _logger;
        IMemoryCache _cache;
        public ArchiveSearchService(IMemoryCache cache, IConfigManager configManager,
                              IArchiveSearchRepository archiveRepository,
                                ILogger<ArchiveService> logger) : base(cache, configManager)
        {
            _cache = cache;
            _logger = logger;
            _archiveRepository = archiveRepository;
        }
        public List<SearchOptions> SearchByCategory(string Search, string CategoryType)
        {
            var CategoryDetails = _archiveRepository.SearchByCategory(Search, CategoryType);
            return CategoryDetails;
        }

    }
}
