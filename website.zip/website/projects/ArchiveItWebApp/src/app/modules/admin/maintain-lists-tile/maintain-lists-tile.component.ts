import { Component, OnInit, Input } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-listtile',
  templateUrl: './maintain-lists-tile.component.html',
  styleUrls: ['./maintain-lists-tile.component.css']
})
export class MaintainliststileComponent implements OnInit {
  @Input('text') TileText: string;
  @Input('className') TileClass: string;
  @Input('TileTopBarClassName') TileTopBarClassName: string;
  @Input('PageUrl') PageUrl: string;
  @Input('TileTextClassName') TileTextClassName: string;
  // isHover: boolean = false;

  currentUrl: string;
  constructor(private router: Router) {
  router.events.subscribe((_: NavigationEnd) => this.currentUrl = this.router.url);
  }

  ngOnInit() {
  }

}
