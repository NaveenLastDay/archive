export class BatchDetails{
  archiveNumber:string;
  clientName: string;
  eligibleDate: string;
  retentionAppliedtDate: string;
  holdFlag: string;
  ObjectsCount: number;
  linkedArchives: number;
  isSelected:boolean;
}

export class DestructionBatch{
  batchID:number;
  batchNumber:string;
  destructionEligibleFromDate:string;
  destructionEligibleToDate:string;
  business:string;
  businessID:number;
  status:string;
  statusID:number;
  createdBy:string;
  createdDate:string;
  modifiedDate:string;
  modifiedBy:string;
  archivesLeft:number;
  archivesTotal:number;
  objectsTotal:number;
  objectsLeft:number;
  batchCount:number;
  recordsCount:number;
  operationType:number;
  userAlias:string;
  erObjectsLeft:number;
  erObjectsTotal:number;
  prObjectsLeft:number;
  prObjectsTotal:number;
}
export class BatchDetailsInfo{
  batch:DestructionBatch;
  clientDetails:DestructionClientDetail[];
  batchDetails: DestructionBatchDetail[];
  inEligibleCount:number;
  eligibleArchivesCount:number;
  eligibleArchivesObjCount:number;
  totalRecords:number;
}
export class DestructionClientDetail{
  clientName:String;
  batchDetails:DestructionBatchDetail[];;
  clientObjCount:number;
  clientArchivesCount:number;
  clientRowSpan:number;
}
export class DestructionBatchDetail{
  batchDetailsID:string;
  archiveNumber:string;
  clientName:string;
  destructionEligibleDate:string;
  retentionExceptionTriggerDate:string;
  holdsApplied:string;
  objectsCount:string;
  linkedArchivesCount:string;
  isInEligibleArchive:string;
  totalRecords:number;
  isSelectedArchive:boolean;
  destructionBatchRecordDetail= new Array<DestructionBatchRecordDetail>();
}

export class DestructionBatchRecordDetail{
  batchDetailsID:number;
  uniqueID:string;
  isPhysicalRecord:boolean;
  barCode:string;
  hardCopyRecordStatus:string;
  electronicRecordStatus:string;
  destructionStatus:number;
}

export class BatchHistoryDetails{
  archiveNumber:string;
  status:string;
  createdBy:string;
  createdDate:string;
}

export class DestructionSubBatch{
  subBatchID:number;
  subBatchNumber:string;
  destructionEligibleFromDate:string;
  destructionEligibleToDate:string;
  business:string;
  businessID:number;
  status:string;
  statusID:number;
  createdBy:string;
  createdDate:string;
  modifiedDate:string;
  modifiedBy:string;
  archivesLeft:number;
  archivesTotal:number;
  objectsTotal:number;
  objectsLeft:number;
  batchCount:number;
  recordsCount:number;
  operationType:number;
  userAlias:string;
}
