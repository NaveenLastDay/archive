import { DatePipe } from '@angular/common';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
 
@Component({
  selector: 'app-custom-date-range-picker',
  templateUrl: './custom-date-range-picker.component.html',
  styleUrls: ['./custom-date-range-picker.component.css'],
})
export class CustomDateRangePickerComponent  implements OnInit{
  @Output() DatePickerEvent = new EventEmitter<any>();
  @Output() DatePickerEventWithFormat = new EventEmitter<any>();
  @Input() eventValue:any;
  bsDatePickerValue:any;
  bsValue = new Date();
  bsRangeValue: Date[];
  maxDate = new Date();
  constructor(private datePipe: DatePipe) {
    this.maxDate.setDate(this.maxDate.getDate() + 7);
    this.bsRangeValue = [this.bsValue, this.maxDate];
  }
  ngOnInit()
  {
    if(this.eventValue!=undefined){
      this.bsDatePickerValue = this.eventValue;
      console.log("eventValue",this.eventValue);
    }
  }

  onDateChange(event)
  {
    // default value in - DatePickerEvent
    this.DatePickerEvent.emit([{fromdate:''},{todate:''}]);
    this.DatePickerEventWithFormat.emit(event);

    if((event != null) && (event!=undefined) && (event != ''))
    {
      var fromDate = this.datePipe.transform(event[0],"MM/dd/yyyy");
      var toDate = this.datePipe.transform(event[1],"MM/dd/yyyy");
      this.bsDatePickerValue = event;

      this.DatePickerEvent.emit(
        [
          {
            fromdate:fromDate
          },
          {
            todate:toDate
          }
        ]
      );
      console.log(event);
    }
  }
  justChange(event)
  {
    console.log('checking===',event);
  }
}
