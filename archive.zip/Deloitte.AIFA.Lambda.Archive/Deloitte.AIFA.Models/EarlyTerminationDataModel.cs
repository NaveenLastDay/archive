﻿using System;

namespace Deloitte.AIFA.Models
{
	public class EarlyTerminationDataModel
	{
		public string ArchiveNumber { get; set; }
		public DateTime EarlyTerminationDate { get; set; }
		public Boolean EarlyTerminated { get; set; }
		public string ModifiedBy { get; set; }
		public DateTime ModifiedDate { get; set; }
        public int MetadataID { get; set; }
    }
}
