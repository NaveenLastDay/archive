﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
    public class ERPDetails
    {
        public string Personnel { get; set; }
        public string Fullname { get; set; }
        public string Officelocation { get; set; }
        public string Business { get; set; }
        public string Designation { get; set; }



    }
}
