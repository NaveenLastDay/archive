﻿using Deloitte.AIFA.DataModels;
using Deloitte.AIFA.DomainEntities;
using Deloitte.AIFA.DomainServices.Contracts;
using Deloitte.AIFA.Helpers;
using Deloitte.AIFA.ICloudServices;
using Deloitte.AIFA.IRepositories;
using Deloitte.AIFA.Models;
using Deloitte.AIFA.PushMessageSNSHelper;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Deloitte.AIFA.DomainServices
{
    public class UtilityService : BaseService, IUtilityService
    {
        IUtilityRepository _utilityRepository;
        ILogger _logger;
        IConfiguration _configManager;
        public UtilityService(IMemoryCache cache, IConfigManager configManager, IConfiguration config,
                              IUtilityRepository UtilityRepository,
                                ILogger<UtilityService> logger) : base(cache, configManager)
        {
            this._configManager = config;
            _logger = logger;
            _utilityRepository = UtilityRepository;
        }
        public List<Utility> GetUtilityDetail(string useralias, string rolecode)
        {
            _logger.LogError("This error from UtilityService: GetUtilityDetail");
            var utilities = _utilityRepository.GetUtilityDetail(useralias, 0, 1, 0, rolecode);
            return utilities;
        }

        #region UpsertEventSource        
        public EventSource UpsertEventSource(EventSource eventSource)
        {
            EventSource eventSourceOut = null;
            try
            {
                if (eventSource != null && eventSource.Metadata != null && eventSource.Metadata != string.Empty)
                {
                    _logger.LogInformation("Started processing UpsertEventSource method.");
                    eventSourceOut = _utilityRepository.UpsertEventSource(eventSource);
                    _logger.LogInformation("After inserting record into EventSource table.");

                    if (eventSourceOut != null && eventSourceOut.EventSourceID > 0)
                    {
                        _logger.LogInformation("EventSourceID: {0}.", System.Web.HttpUtility.HtmlEncode(eventSourceOut.EventSourceID));
                        //var jsonData = @"{""RequestParameters"":{""EventSourceID"":""" + eventSourceOut.EventSourceID + @""",""EventTypeID"":""" + eventSourceOut.EventTypeID + @""",""Metadata"":""" + eventSourceOut.Metadata + @"""}}"; ;
                        var jsonData = JsonConvert.SerializeObject(new { EventSourceID = eventSourceOut.EventSourceID, EventTypeID = eventSourceOut.EventTypeID, Metadata = eventSourceOut.Metadata });
                        _logger.LogInformation("Before calling PushMessageSNS service, jsonData : {0}.", System.Web.HttpUtility.HtmlEncode(jsonData));
                        PushMessageSNS obj = new PushMessageSNS("redshiftDataRefreshNotifyArn");
                        string messageId = obj.PushMsgtoSNS(jsonData).Result;
                        _logger.LogInformation("After calling PushMessageSNS service.");

                        if (messageId != null && messageId != string.Empty)
                        {
                            _logger.LogInformation("After calling PushMessageSNS service.");
                            _logger.LogInformation("SNS MessageId: " + System.Web.HttpUtility.HtmlEncode(messageId) + " for EventSourceID: " + System.Web.HttpUtility.HtmlEncode(eventSourceOut.EventSourceID) + " for Metadata: " + System.Web.HttpUtility.HtmlEncode(eventSourceOut.Metadata));
                        }
                    }
                    _logger.LogInformation("Completed processing UpsertEventSource method.");
                }
                else
                {
                    _logger.LogInformation("Completed processing UpsertEventSource method. Metadata is empty or null.");
                }

            }
            catch (Exception ex)
            {
                _logger.LogError("Exception occured in UpsertEventSource service, error message is: {0}  stacktrace is: {1}", ex.Message, ex.StackTrace);
            }

            return eventSourceOut;
        }
        #endregion UpsertEventSource

        public List<RoleFunction> GetRoleFunctions()
        {
            var functions = _utilityRepository.GetRoleFunctions();
            return functions;
        }


        public bool IsUserAuthorizedtoPerformAction(string archiveNumber, int functionId, string userAlias, string Keyword = null)
        {
            return _utilityRepository.IsUserAuthorizedtoPerformAction(archiveNumber, functionId, userAlias, Keyword);
        }

        private string SanitizeInput(string argInput)
        {
            var blacklistedTags = _configManager.GetSection("BlacklistedTag").Get<HashSet<string>>();
            _logger.LogInformation("Sanitizing input : " + System.Web.HttpUtility.HtmlEncode(argInput));
            return HtmlSanitizerHelper.Sanitize(argInput, blacklistedTags);
        }
        private string ValidateProperties(object argInput)
        {
            _logger.LogInformation("Validating input Properties : " + System.Web.HttpUtility.HtmlEncode(argInput));
            var inputstringRegex = _configManager["ValidInputStringRegex"];
            _logger.LogInformation("string regex is : " + System.Web.HttpUtility.HtmlEncode(inputstringRegex));
            return HtmlSanitizerHelper.validateProperties(argInput, inputstringRegex);
        }

        public object IsInputIsSanitized(object value, out bool isValid)
        {
            var json = JsonConvert.SerializeObject(value);
            _logger.LogInformation("Before Sanitization Input is: " + System.Web.HttpUtility.HtmlEncode(json));
            var sanitizedjson = this.SanitizeInput(json);
            _logger.LogInformation("After sanitization json is: " + sanitizedjson);
            var sanitizedclass = sanitizeObject(sanitizedjson, value.GetType().Name);
            var resut = this.ValidateProperties(sanitizedclass);
            if (resut == "invalid")
                isValid = false;
            else
                isValid = true;

            return sanitizedclass;
        }

        private object sanitizeObject(string sanitizedjson, string className)
        {
            switch (className)
            {
                case "Archive":
                    {
                        var result = JsonConvert.DeserializeObject<Archive>(sanitizedjson);
                        return result;
                    }
                case "FormSubmitInfo":
                    {
                        var result = JsonConvert.DeserializeObject<FormSubmitInfo>(sanitizedjson);
                        return result;
                    }
                case "ApproveOrRejectFormRequest":
                    {
                        var result = JsonConvert.DeserializeObject<ApproveOrRejectFormRequest>(sanitizedjson);
                        return result;
                    }
                case "ChangeApproverRequest":
                    {
                        var result = JsonConvert.DeserializeObject<ChangeApproverRequest>(sanitizedjson);
                        return result;
                    }
                case "ArchiveTeam":
                    {
                        var result = JsonConvert.DeserializeObject<ArchiveTeam>(sanitizedjson);
                        return result;
                    }
                case "ArchiveLegalHold":
                    {
                        var result = JsonConvert.DeserializeObject<ArchiveLegalHold>(sanitizedjson);
                        return result;
                    }
                case "ArchiveRetention":
                    {
                        var result = JsonConvert.DeserializeObject<ArchiveRetention>(sanitizedjson);
                        return result;
                    }
                case "EarlyTerminationCeasedDate":
                    {
                        var result = JsonConvert.DeserializeObject<EarlyTerminationCeasedDate>(sanitizedjson);
                        return result;
                    }
                case "UpdateArchive":
                    {
                        var result = JsonConvert.DeserializeObject<UpdateArchive>(sanitizedjson);
                        return result;
                    }
                case "ArchiveSubmission":
                    {
                        var result = JsonConvert.DeserializeObject<ArchiveSubmission>(sanitizedjson);
                        return result;
                    }
                case "ResubmissionParameters":
                    {
                        var result = JsonConvert.DeserializeObject<ResubmissionParameters>(sanitizedjson);
                        return result;
                    }
                case "ArchiveDeletionAction":
                    {
                        var result = JsonConvert.DeserializeObject<ArchiveDeletionAction>(sanitizedjson);
                        return result;
                    }
                case "RMIntegrationActions":
                    {
                        var result = JsonConvert.DeserializeObject<RMIntegrationActions>(sanitizedjson);
                        return result;
                    }
                case "Memo":
                    {
                        var result = JsonConvert.DeserializeObject<Memo>(sanitizedjson);
                        return result;
                    }
                case "UpdatePPDNPPDDetails":
                    {
                        var result = JsonConvert.DeserializeObject<UpdatePPDNPPDDetails>(sanitizedjson);
                        return result;
                    }
                case "GrantDenyTemporaryArchiveAccess":
                    {
                        var result = JsonConvert.DeserializeObject<GrantDenyTemporaryArchiveAccess>(sanitizedjson);
                        return result;
                    }
                case "DistributionList":
                    {
                        var result = JsonConvert.DeserializeObject<DistributionList>(sanitizedjson);
                        return result;
                    }
                case "ArchiveFlowDetails":
                    {
                        var result = JsonConvert.DeserializeObject<ArchiveFlowDetails>(sanitizedjson);
                        return result;
                    }
            }
            return null;
        }

        public object IsUserAuthorizedAndInputIsValid(string archiveNumber, int functionId, string userAlias, object value, out bool isValid, string Keyword = null)
        {
            object sanitizeClass = null;
            var isAuthorized = this.IsUserAuthorizedtoPerformAction(archiveNumber, functionId, userAlias, Keyword);
            _logger.LogInformation("IsUserAuthorizedAndInputIsValid() is: " + isAuthorized);
            if (isAuthorized)
            {
                sanitizeClass = this.IsInputIsSanitized(value, out isValid);
                _logger.LogInformation("isSanitized() is: ");
                if (isValid)
                {
                    isValid = true;
                }
                else
                {
                    _logger.LogInformation("Input is not valid");
                    isValid = false;
                }
            }
            else
            {
                _logger.LogInformation("Unauthorized Request" + JsonConvert.SerializeObject(value));
                isValid = false;
            }
            return sanitizeClass;
        }
    }
}
