import { Component, OnInit, Input, Output } from '@angular/core';



@Component({
  selector: 'app-people-picker',
  templateUrl: './people-picker.component.html',
  styleUrls: ['./people-picker.component.css']
})
export class PeoplePickerComponent implements OnInit {

  emptyString : string = '';

  
  @Input() displayName : string = this.emptyString;
  @Input() legalEntity : string = this.emptyString;
  @Input() officeLocation : string = this.emptyString;
  @Input() title : string = this.emptyString;


  constructor() { }

  ngOnInit() {
  }

}
