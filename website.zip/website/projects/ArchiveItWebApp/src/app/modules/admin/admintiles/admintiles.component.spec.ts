import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdmintilesComponent } from './admintiles.component';

describe('AdmintilesComponent', () => {
  let component: AdmintilesComponent;
  let fixture: ComponentFixture<AdmintilesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdmintilesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdmintilesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
