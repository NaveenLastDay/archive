import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable, BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LegalHoldService {
  constructor(private _http: HttpClient) { }

  private statusMessageSource = new BehaviorSubject("");
  statusMessage = this.statusMessageSource.asObservable();
  apiData: any;

  httpOptions = {
   headers: new HttpHeaders({
     'Content-Type': 'application/json'
   })
  } 
   public SaveLegalHold(parameters: any): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'text/plain; charset=utf-8');
    let result = this._http.post("archive/createlegalhold", parameters, { headers, responseType: 'text'});
    this.statusMessageSource.next(result.toString());
    return result;
  } 
}
