﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Filters;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

namespace Deloitte.AIFA.Lambda.Archive.Filters
{
    public class EventSourceFilter : ResultFilterAttribute
    {
        public string ArchiveNumber {get;set;}
        public int EventID { get; set; }

        public override void OnResultExecuting(ResultExecutingContext context)
        {
            string strBody = string.Empty;
            string strCurrentMethodName = MethodBase.GetCurrentMethod().Name;
            string strRequestPath = context.HttpContext.Request.Path;

            if (context.HttpContext.Request.Method == "POST")
            {
                using (StreamReader sr = new StreamReader(context.HttpContext.Request.Body))
                {
                    strBody = sr.ReadToEnd();
                }                    

                if (!string.IsNullOrEmpty(strBody))
                {
                    strBody = strBody.Replace("\"", "");
                }                

                Console.WriteLine($"ArchiveNumber {0}", ArchiveNumber);
            }
            base.OnResultExecuting(context);
        }
    }
}
