import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable, BehaviorSubject } from 'rxjs';
import { PubsubService } from './pubsub.service';
import { map, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ArchiveHomeService {

  successstmt: Observable<any>;
  getcomments: any;
  getMembers: any;
  getformstatus:any;
  apiData: any;
  private archiveMessageSource = new BehaviorSubject("");
  archiveSubmitStatus = this.archiveMessageSource.asObservable();

  private archiveSubstantiveSource = new BehaviorSubject("");
  archiveSubstantiveStatus = this.archiveSubstantiveSource.asObservable();

  FormStatusinfo: any;
  FormStatus: any;
  FormStatusDate: any;
  IsFormEnabled: any;
  success: Observable<any>;
  ADCEDDate: any;
  archiveDueDateData: any;
  constructor(private _http: HttpClient, private pubsub:PubsubService) { }
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'

    }),
  }

  public GetForm3283SStatus(archiveNumber:string):Observable<any>{
   var timeOffSet = new Date().getTimezoneOffset();
   this.getformstatus = this._http.get<any>("archive/getformstatus?archiveNumber="+archiveNumber+"&timeOffset=" + timeOffSet);
    return this.getformstatus;
  }

  public SyncForm3283SStatus(ArchiveNumber:string){
    this.GetForm3283SStatus(ArchiveNumber).subscribe(
      data =>{
        this.FormStatusinfo = data;
        this.IsFormEnabled = data.isFormEnabled;
        this.FormStatus = data.formStatusDescription;
        this.ADCEDDate = data.adcdDate;
        this.FormStatusDate = data.formStatusDate;
        this.sendFormSubmissionStatus();
      }
    );
  }

  sendFormSubmissionStatus(){
    this.pubsub.sendForm3283SStatus(this.FormStatusinfo);
    }

  public GetArchiveStatus(archiveNumber:string, userAlias: string): Observable<any> {
    return this._http.get<any>("archive/getarchivesubmissionstatus?archivenumber="+ archiveNumber);
  }
   //public substantiveresubmissionEmployeeRolesCreate(archiveNumber:string, createdBy: string,pPDUserAlias :String,isPPD :number): Observable<any> {
   // return this._http.post<any>("archive/substantiveresubmissionupdateppdornppd?ArchiveNumber="+ archiveNumber +"&CreatedBy="+ createdBy+"&PPDUserAlias="+ pPDUserAlias+"&IsPPD="+ isPPD,this.httpOptions);
   // }
 public substantiveresubmissionEmployeeRolesCreate(parameters:any): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'text/plain; charset=utf-8');
    this.success = this._http.post("archive/substantiveresubmissionupdateppdornppd",parameters, { headers, responseType: 'text'});
    console.log("Updated Resubmission archive is", this.success);
    return this.success;
 }

  public Getsubstantiveresubmissionppdornppd(archiveNumber:string): Observable<any> {
    return this._http.get<any>("archive/Getsubstantiveresubmissionppdornppd?ArchiveNumber="+ archiveNumber,this.httpOptions);
  }

  public GetUploadedMemo(archiveNumber:string): Observable<any> {
    //debugger;
    return this._http.get<any>("archive/GetUploadedMemo?ArchiveNumber="+ archiveNumber,this.httpOptions);
  }


  public GetResubmissionApprovalFlowStatuses(parameters:any):Observable<any> {
    this.apiData = this._http.post<any>("archive/GetResubmissionApproverDetails",  parameters, this.httpOptions);
    return this.apiData;
  }

  public GetResubmissionReasonsforArchive(archiveNumber:string):Observable<any> {
    this.apiData = this._http.get<any>("archiveflow/GetResubmissionReasonsforArchive?ArchiveNumber="+ archiveNumber, this.httpOptions);
    return this.apiData;
  }


  public GetResubmissionReason():Observable<any>
  {
    this.apiData = this._http.get<any>("archive/GetResubmissionReason", this.httpOptions);
    return this.apiData;
  }


  public InsertResubmissionApproverFlow(parameters:any):Observable<any>
  {
    this.apiData = this._http.post<any>("archive/InsertResubmissionApprover",  parameters, this.httpOptions);
    return this.apiData;
  }


  public DeleteFile(deleteRequest: any): Observable<boolean> {
    this.apiData = this._http.post<boolean>("record/Delete", deleteRequest, this.httpOptions);
    return this.apiData;
  }

  public GetArchiveDueDate(archiveNumber:string, userAlias: string): Observable<any> {
    return this._http.get<any>("archivemetadata/getarchiveduedatecriteria?ArchiveNumber="+ archiveNumber);
  }

  public SyncArchiveDueDate(ArchiveNumber:string, userAlias: string){
    this.GetArchiveDueDate(ArchiveNumber,userAlias).subscribe(
      data =>{
        this.archiveDueDateData = data;
        this.sendEDCDinfo();
      }
    );
  }

  sendEDCDinfo(){
    this.pubsub.sendEDCDinfoCriteria(this.archiveDueDateData);
  }
  public OnApproveOrRejection(parameters) : Observable<any>{
    const headers = new HttpHeaders().set('Content-Type', 'application/json; charset=utf-8');
    this.successstmt = this._http.post("archiveflow/createOrUpdateArchiveActions",parameters, { headers, responseType: 'text'});
    return this.successstmt;
   }

  public SavereasonsForArchiveDetails(reasonparameters:any):Observable<any>
  {
    this.apiData = this._http.post<any>("record/AddEditSubstantiation", reasonparameters, this.httpOptions);
    return this.apiData;
  }

  public GetPersonnelForWBSNumber(archiveNumber : string,wbsNumber : string): Observable<any> {
    this.getMembers = this._http.get<any>('erp/GetPersonnelForWBSNumber?ArchiveNumber=' + archiveNumber
    +'&WbsNumber='+wbsNumber,this.httpOptions);
    return this.getMembers;
  }

  public AddEngagementPersonnels(parameters:any):Observable<any>
  {
    this.successstmt = this._http.post<any>("archive/addengagementpersonnels", parameters, this.httpOptions);
    return this.successstmt;
  }

  public Getsectioncomments(archiveNumber : string,SectionId : number,ActionTypeId:number): Observable<any> {
    this.getcomments = this._http.get<any>('archiveflow/getarchivesectioncomments?ArchiveNumber=' + archiveNumber
    +'&sectionId='+SectionId+'&ActionTypeId='+ActionTypeId,this.httpOptions);
    return this.getcomments;
  }
  public OnArchiveSubmit(parameters) : Observable<any>{
    return this._http.post<any>("archive/createarchivesubmission",parameters, this.httpOptions);
   }

   public InsertUpdateArchiveSubmitter(archiveNumber:string,userAlias:string):Observable<any>{
   return this._http.post<any>('archive/InsertUpdateArchiveSubmissionFlow?ArchiveNumber='+archiveNumber, this.httpOptions);
   }

  public GetArchiveApproverForArchiveSubmission(archiveNumber:string,RoleID:number): Observable<any> {
    return this._http.get<any>('archive/GetArchiveApproverforArchiveSubmission?ArchiveNumber=' + archiveNumber +'&RoleID='+RoleID,this.httpOptions);
  }

  public CheckInactiveAPSubmitter(archiveNumber:string,userAlias:string,checkType:number): Observable<any> {
    return this._http.get<any>('archive/CheckAPSubmitterInactive?ArchiveNumber=' + archiveNumber+'&CheckType='+checkType,this.httpOptions);
  }

  public updateArchiveStatus(status){
    this.archiveMessageSource.next(status);
  }
  public updateArchiveSubstantiation()
  {
    this.archiveSubstantiveSource.next("Substantive");
  }
  public IsUserApprover(parameters:string,parameters1:string){
    return this._http.get<any>("archive/getarchivesubmissionstatus?archivenumber="+parameters, this.httpOptions);
  }
  public ArchiveResubmitInitiate(parameters):Observable<any>{
     //debugger;
    console.log("Archive service: Resumbit initiated ");
    const headers = new HttpHeaders().set('Content-Type', 'text/plain; charset=utf-8');
    this.success = this._http.post("archive/ArchiveResubmissionOpen", parameters, { headers, responseType: 'text'});
    console.log("Updated Resubmission archive is", this.success);
    return this.success;

   }
  // public CreateOrUpdateMemo(parameters: any){
  //   this._http.post("archive/CreateOrUpdateMemo",parameters , this.httpOptions)
  //   .toPromise().then((data:any)=>{
  //     console.log(data);
  //     this.apiData = data.archiveFileIdOut;
  //   });
  //   console.log("created archive is", this.apiData);
  //   return this.apiData;
  // }
  public CreateOrUpdateMemo(parameters:any):Observable<any>
  {
    this.apiData = this._http.post<any>("archive/CreateOrUpdateMemo",  parameters, this.httpOptions);
    return this.apiData;
  }

  public DeleteUploadedMemo(ArchiveFileID:string,userAlias: string,archiveNumber:string): Observable<any> {
    return this._http.get<any>("archive/DeleteUploadedMemo?ArchiveFileID="+ ArchiveFileID+"&ArchiveNumber="+ archiveNumber,this.httpOptions);
  }
  public PendingapprovalClick(parameters) : Observable<any>{
    const headers = new HttpHeaders().set('Content-Type', 'application/json; charset=utf-8');
      return this._http.post("archive/UpdateFirstLevelResubmissionApprovalFlag",parameters, { headers, responseType: 'text'});
   }

   public GetMatRoiUpdates(archiveNumber:string): Observable<any> {
    return this._http.get<any>("archive/GetMatRoiUpdates?archivenumber="+ archiveNumber);
  }

  public GetArchiveActionsForIndividualSections(archiveNumber:string): Observable<any> {
    return this._http.get<any>("archive/GetArchiveAtcionsForIndividualSections?archivenumber="+ archiveNumber);
  }

  public GetOmniaUpdates(archiveNumber:string): Observable<any> {
    return this._http.get<any>("archive/checkomniasubmissionallowed?archivenumber="+ archiveNumber);
  }

  public GetLinkedArchivesTileData(archiveNumber:string): Observable<any> {
    return this._http.get<any>("archive/GetLinkedArchiveStatus?archivenumber="+ archiveNumber);
  }

  public GetERPTileData(archiveNumber:string): Observable<any> {
    return this._http.get<any>("archive/GetERPStatus?archivenumber="+ archiveNumber);
  }


}