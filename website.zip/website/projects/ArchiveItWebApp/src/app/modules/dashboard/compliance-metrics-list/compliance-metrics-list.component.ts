import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ArchiveService } from '../../../services/archive.service';
// import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-compliance-metrics-list',
  templateUrl: './compliance-metrics-list.component.html',
  styleUrls: ['./compliance-metrics-list.component.css']
})
export class ComplianceMetricsListComponent implements OnInit {
  archiveDetails:any;
  @Input('archiveNumber') archiveNumber : string;
  @Input('entityTypeDescription') entityTypeDescription : string;
  @Input('professionalStandardDescription') professionalStandardDescription : string;
  @Input('adced') adced : string;
  @Output() archiveID = new EventEmitter();
  @Input('archiveAccessRequestID') archiveAccessRequestID : string;
  @Input('estimatedIssuanceReportDate') estimatedIssuanceReportDate : any;
  @Input('engagementTypeDescription') engagementTypeDescription : any;
  @Input('reportingEntity') reportingEntity : any;
  @Input('archivePartner') archivePartner : any;
  @Input('archiveManager') archiveManager : any;
  @Input('archiveFieldSenior') archiveFieldSenior : any;
  @Input('addArchiveFieldSenior') addArchiveFieldSenior : any;
  @Input('archiveDueDate') archiveDueDate : any;
  @Input('isResubmissionInProgress') isResubmissionInProgress : any;
  @Input('description') description : any;
  
  

  constructor() { }
  ngOnInit() {
  }

}
