import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { String } from 'aws-sdk/clients/cloudtrail';
import { ReturnStatement } from '@angular/compiler';
import { DateTime } from 'aws-sdk/clients/devicefarm';


@Injectable({
  providedIn: 'root'
})

export class DestructionService {


  data: any;
  apiData: any;
  create: any;
  useralias: string;
  result: string;
  roles: any;
  success: Observable<any>;


  constructor(private _http: HttpClient) { }
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'

    }),
  }


 public GetBatchInfo(pageNumber : number = 0, pageSize : number = 0, sortBy : number = 1, filterBy : number = 0, filterText : string = "", batchNumber : string ='', isDTScreen:number
 ): Observable<any> {
  const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
  this.apiData = this._http.get<any>("destruction/GetBatchInfo?pageNumber="+pageNumber
  +'&pageSize='+ pageSize
  +'&sortDirection='+ sortBy
  +'&filterByBatchNumber='+filterBy
  +'&sortBy='+filterText
  +'&batchNumber='+batchNumber
  +'&isDTScreen='+isDTScreen
  , httpOptions);
  return this.apiData;

}

public CreateAndUpdateBatch(parameters: any): Observable<any> {
  const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
  this.apiData = this._http.post<any>("destruction/CreateAndUpdateBatch", parameters, this.httpOptions);

  return this.apiData;
}

public GetBusinessType(): Observable<any> {
  return this._http.get<any[]>("destruction/GetBusiness", this.httpOptions);
}

public GetBatchDetailInfo(batchNumber: string, pageNumber : number = 0, pageSize : number = 100, sortDirection: number= 0, sortByColumn : string,
IsSimpleSearch: number =0, filterText : string = "", archiveNumber: string, clientName: string, physicalRecordStatus: string, rententionExceptionApplied:number,
holdApplied:number, linkedArchives:number, showInElgibleArchives:number): Observable<any> {
 this.apiData = this._http.get<any>("destruction/GetBatchDetails?batchNumber="+batchNumber
 +'&pageNumber='+pageNumber
 +'&pageSize='+ pageSize
 +'&sortDirection='+ sortDirection
 +'&sortBy='+sortByColumn
 +'&IsSimpleSearch='+IsSimpleSearch
 +'&filterText='+filterText
 +'&archiveNumber='+archiveNumber
 +'&clientName='+ clientName
 +'&physicalRecordStatus='+physicalRecordStatus
 +'&rententionExceptionApplied='+rententionExceptionApplied
 +'&holdApplied='+holdApplied
 +'&linkedArchives='+linkedArchives
 +'&showInElgibleArchives='+showInElgibleArchives
 , this.httpOptions);
 return this.apiData;
}

public GetBatchSubDetailInfo(batchNumber: string, pageNumber : number = 0, pageSize : number = 100, sortDirection: number= 0, sortByColumn : string,
  IsSimpleSearch: number =0, filterText : string = "", archiveNumber: string, clientName: string, physicalRecordStatus: string, rententionExceptionApplied:number,
  holdApplied:number, linkedArchives:number, showInElgibleArchives:number): Observable<any> {
   this.apiData = this._http.get<any>("destruction/GetSubBatchDetails?batchNumber="+batchNumber
   +'&pageNumber='+pageNumber
   +'&pageSize='+ pageSize
   +'&sortDirection='+ sortDirection
   +'&sortBy='+sortByColumn
   +'&IsSimpleSearch='+IsSimpleSearch
   +'&filterText='+filterText
   +'&archiveNumber='+archiveNumber
   +'&clientName='+ clientName
   +'&physicalRecordStatus='+physicalRecordStatus
   +'&rententionExceptionApplied='+rententionExceptionApplied
   +'&holdApplied='+holdApplied
   +'&linkedArchives='+linkedArchives
   +'&showInElgibleArchives='+showInElgibleArchives
   , this.httpOptions);
   return this.apiData;
  }

public GetBatchDetailInfobybatchid(batchNumber: string, pageNumber : number = 0, pageSize : number = 100, sortDirection: number= 0, sortByColumn : string,
  IsSimpleSearch: number =0, filterText : string = "",
archiveNumber: string, clientName: string,uniqueId:string,destructionEligibleDate:string, physicalRecordStatus: string, rententionExceptionApplied:number,
holdApplied:number, linkedArchives:number, showElgibleArchives:boolean,tileName:string
): Observable<any> {
 this.apiData = this._http.get<any>("destruction/GetBatchDetailsByBatchID?batchNumber="+batchNumber
 +'&pageNumber='+pageNumber
 +'&pageSize='+ pageSize
 +'&sortDirection='+ sortDirection
 +'&sortBy='+sortByColumn
 +'&IsSimpleSearch='+IsSimpleSearch
 +'&filterText='+filterText
 +'&archiveNumber='+archiveNumber
 +'&clientName='+ clientName
 +'&uniqueId='+uniqueId
 +'&destructionEligibleDate='+destructionEligibleDate
 +'&physicalRecordStatus='+physicalRecordStatus
 +'&rententionExceptionApplied='+rententionExceptionApplied
 +'&holdApplied='+holdApplied
 +'&linkedArchives='+linkedArchives
 +'&showElgibleArchives='+showElgibleArchives
 +'&tileName='+tileName
 , this.httpOptions);
 return this.apiData;
}
public GetBatchDetailInfoForExportToExcel(batchNumber: string, pageNumber : number = 0, pageSize : number = 100, sortDirection: number= 0, sortByColumn : string,
  IsSimpleSearch: number =0, filterText : string = "", archiveNumber: string, clientName: string, physicalRecordStatus: string, rententionExceptionApplied:number,
  holdApplied:number, linkedArchives:number, showInElgibleArchives:number): Observable<any> {
   this.apiData = this._http.get<any>("destruction/GetBatchDetailsForExportToExcel?batchNumber="+batchNumber
   +'&pageNumber='+pageNumber
   +'&pageSize='+ pageSize
   +'&sortDirection='+ sortDirection
   +'&sortBy='+sortByColumn
   +'&IsSimpleSearch='+IsSimpleSearch
   +'&filterText='+filterText
   +'&archiveNumber='+archiveNumber
   +'&clientName='+ clientName
   +'&physicalRecordStatus='+physicalRecordStatus
   +'&rententionExceptionApplied='+rententionExceptionApplied
   +'&holdApplied='+holdApplied
   +'&linkedArchives='+linkedArchives
   +'&showInElgibleArchives='+showInElgibleArchives
   , this.httpOptions);
   return this.apiData;
  }

public RemoveIneligibleRecords(parameters: any): Observable<any> {
  const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
  return this._http.post<String>("destruction/RemoveInEligibleRecords", parameters, {headers : this.httpOptions.headers, responseType:'text' as 'json'});

}
public GetBatchArchiveDetails(batchNumber: string, pageNumber : number = 0, pageSize : number = 100, sortDirection: number= 0, sortByColumn : string,
  IsSimpleSearch: number =0, filterText : string = "", archiveNumber: string, clientName: string, physicalRecordStatus: string, rententionExceptionApplied:number,
  holdApplied:number, linkedArchives:number, showInElgibleArchives:number): Observable<any> {
   this.apiData = this._http.get<any>("destruction/GetBatchArchiveDetails?batchNumber="+batchNumber
   +'&pageNumber='+pageNumber
   +'&pageSize='+ pageSize
   +'&sortDirection='+ sortDirection
   +'&sortBy='+sortByColumn
   +'&IsSimpleSearch='+IsSimpleSearch
   +'&filterText='+filterText
   +'&archiveNumber='+archiveNumber
   +'&clientName='+ clientName
   +'&physicalRecordStatus='+physicalRecordStatus
   +'&rententionExceptionApplied='+rententionExceptionApplied
   +'&holdApplied='+holdApplied
   +'&linkedArchives='+linkedArchives
   +'&showInElgibleArchives='+showInElgibleArchives
   , this.httpOptions);
   return this.apiData;
  }
  public AddArchiveDetailsToBatch(addArchiveList): Observable<any> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
     return this._http.post<String>("destruction/AddDestructionArchives", addArchiveList, {headers : this.httpOptions.headers, responseType:'text' as 'json'});
  }

  public GetBatchHistoryDetails(batchNumber : string ='' ): Observable<any> {
  const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
  this.apiData = this._http.get<any>("destruction/GetBatchHistory?batchNumber=" + batchNumber
  , httpOptions);
  return this.apiData;

}

  public GetSubBatchInfo(batchNumber : string): Observable<any> {
    return this._http.get<any>("destruction/GetSubBatchInfo?batchNumber=" + batchNumber, this.httpOptions);
  }
  public GetDestructionProcessExport(batchNumber: string, pageNumber : number = 0, pageSize : number = 100, sortDirection: number= 0, sortByColumn : string,
    IsSimpleSearch: number =0, filterText : string = "",
  archiveNumber: string, clientName: string,uniqueId:string,destructionEligibleDate:string, physicalRecordStatus: string, rententionExceptionApplied:number,
  holdApplied:number, linkedArchives:number, showElgibleArchives:boolean , exportToExcel:number, tileName:string
  ): Observable<any> {
   this.apiData = this._http.get<any>("destruction/GetDestructionProcessExport?batchNumber="+batchNumber
   +'&pageNumber='+pageNumber
   +'&pageSize='+ pageSize
   +'&sortDirection='+ sortDirection
   +'&sortBy='+sortByColumn
   +'&IsSimpleSearch='+IsSimpleSearch
   +'&filterText='+filterText
   +'&archiveNumber='+archiveNumber
   +'&clientName='+ clientName
   +'&uniqueId='+uniqueId
   +'&destructionEligibleDate='+destructionEligibleDate
   +'&physicalRecordStatus='+physicalRecordStatus
   +'&rententionExceptionApplied='+rententionExceptionApplied
   +'&holdApplied='+holdApplied
   +'&linkedArchives='+linkedArchives
   +'&showElgibleArchives='+showElgibleArchives
   +'&exportToExcel='+exportToExcel
   +'&tileName='+tileName
   , this.httpOptions);
   return this.apiData;
  }

  public GetSubBatchDetailInfo(subBatchNumber: string, pageNumber : number = 0, pageSize : number = 100, sortDirection: number= 0, sortByColumn : string,
    IsSimpleSearch: number =0, filterText : string = "", archiveNumber: string, clientName: string,uniqueId:string,destructionEligibleDate:string, physicalRecordStatus: string, rententionExceptionApplied:number,
    holdApplied:number, linkedArchives:number, showElgibleArchives:number): Observable<any> {
   this.apiData = this._http.get<any>("destruction/GetSubBatchDetailsByBatchID?subBatchNumber="+subBatchNumber
   +'&pageNumber='+pageNumber
   +'&pageSize='+ pageSize
   +'&sortDirection='+ sortDirection
   +'&sortBy='+sortByColumn
   +'&IsSimpleSearch='+IsSimpleSearch
   +'&filterText='+filterText
   +'&archiveNumber='+archiveNumber
   +'&clientName='+ clientName
   +'&uniqueId='+uniqueId
   +'&destructionEligibleDate='+destructionEligibleDate
   +'&physicalRecordStatus='+physicalRecordStatus
   +'&rententionExceptionApplied='+rententionExceptionApplied
   +'&holdApplied='+holdApplied
   +'&linkedArchives='+linkedArchives
   +'&showElgibleArchives='+showElgibleArchives
   , this.httpOptions);
   return this.apiData;
  }
  public createSubBatch(subBatchParams): Observable<any> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
     return this._http.post<any>("destruction/CreateSubBatch", subBatchParams, this.httpOptions);
  }

  public beginDestructionProcess(subBatchParams): Observable<any> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
     return this._http.post<String>("destruction/SubBatchDestruction", subBatchParams, {headers : this.httpOptions.headers, responseType:'text' as 'json'});
  }
}