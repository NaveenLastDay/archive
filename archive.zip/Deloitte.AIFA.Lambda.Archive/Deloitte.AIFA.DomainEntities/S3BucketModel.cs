﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
    public class S3BucketModel
    {
        public string DestinationKey { get; set; }
        public string SourceKey { get; set; }
        public string DestinationBucket { get; set; }
        public string SourceBucket { get; set; }
    }
}
