import { Component, OnInit, ElementRef, HostListener } from '@angular/core';
import { of, Subject, fromEvent } from 'rxjs';
import { distinctUntilChanged, map, debounceTime, switchAll } from 'rxjs/operators';
import { HomePageService } from '../../services/homepage.service'
import { Router } from '@angular/router';
import { FileUploadProcessService } from '../../modules/record/file-upload/fileupload.process.service';
import { FielUploadService } from '../../services/fileupload.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { FileUploadEventService } from '../../modules/record/file-upload/fileupload.event.service';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { NgbTooltip } from '@ng-bootstrap/ng-bootstrap';
import { UserConfigSettingService } from '../../guards/user-role-guard.service';


@Component({
  selector: 'app-archive-search',
  templateUrl: './archive-search.component.html',
  styleUrls: ['./archive-search.component.css']
})
export class ArchiveSearchComponent implements OnInit {

  //    archiveDetails: Observable<any[]>;
  //  archiveDetails: any[]=[];
  archiveSearchValue = '';
  private searchTerms = new Subject<string>();
  isSearchLoading: boolean = false;
  showArchiveSearch: boolean = false;
  archiveKeyMessage: string = "";
  archiveValueMessage: string = "";
  searchTipKeyMessage: string = "Search tip";
  searchTipValueMessage: string = "Please type atleast 3 characters";
  NoResultKeyMessage: string = "No Results Found";// For Archive
  NoResultValueMessage: string = "";
  testval: any[];
  hoverIndex: number = -1;
  totalRecords: number = 0;
  documentData: any;
  showMessages: boolean;
  showArchiveMessages: boolean = true;
  archiveDetails: any;
  recordDetails: any;
  UserName = this.adalSvc.LoggedInUserName;
  LoggedInUserName: string;
  userEmail = this.adalSvc.LoggedInUserEmail;
  userAlias = this.userEmail.substring(0, this.userEmail.lastIndexOf("@"));
  isAccessbleCol: any;
  showTooltipRow: boolean = false;
  tooltipInfo: string;
  userConfig: any;

  //@ViewChild("archiveHomeSearch",{read:true,static:true}) private archiveHomeSearch:ElementRef;
  constructor(private homepageSvc: HomePageService, private adalSvc: MsAdalAngular6Service, private _elementRef: ElementRef, private router: Router, private _fuService: FielUploadService, private SpinnerService: NgxSpinnerService,
    private _userConfig: UserConfigSettingService,
    private _uploadEventService: FileUploadEventService,) {
    this.archiveKeyMessage = this.searchTipKeyMessage;
    this.archiveValueMessage = this.searchTipValueMessage;
    this.userConfig = this._userConfig.FetchLoggedInUser(this.userAlias);
  }

  ngOnInit() {

  }
  goToMyArchives(archiveNum) {
    this.router.navigate(["archive/myarchives/" + archiveNum + '/archivehome'])
    .then(() => {
     location.reload();
    });
    setTimeout(() => {
      this.clearSearchResult();
    }, 1000)
  }
  goToRequestAccess(archiveNum) {
  //  this.SpinnerService.show();
    // this.homepageSvc.getActiveRoles(archiveNum).subscribe((data) => {
    //   data;
    // })
    this.router.navigate(['archive/requestAccess/' + archiveNum]);
    this.clearSearchResult();
  }
  getArchiveSearchDetails(event) {
    if(event) {
      // const obs = fromEvent(this._elementRef.nativeElement.querySelector('#archiveHeaderUniqueSearch'), 'keyup')
      // .pipe(
      //   map((e: any) => {
      //     return e.target.value;
      //   }), 
      //   distinctUntilChanged(),
      //   debounceTime(500), 
      //   map((query: string) => {
      //     return of(query)
      //   }
      //   ),
      //   switchAll()
      // );

    // obs.subscribe((result) => {
      if ((this.archiveSearchValue && this.archiveSearchValue.length > 2)) {
        this.isSearchLoading = true;
        this.homepageSvc.archiveHomeSearch(this.archiveSearchValue, this.userAlias).subscribe(
          (details) => {
            if(this.showArchiveSearch) {
            let element = document.getElementById("archive_record_section");
            element.classList.add("archive-record-bg");
          }
          if(!this.isSearchLoading) {
            let element1 = document.getElementById("searchIconSImpleSearch");
            element1.classList.add("custom-search-icon-alignment");
          }
            this.archiveDetails = details;
            this.showArchiveMessages = true;
            this.archiveKeyMessage = this.NoResultKeyMessage;
            this.archiveValueMessage = this.NoResultValueMessage;
            this.isSearchLoading = false;
            if (!(this.archiveSearchValue && this.archiveSearchValue.length > 2)) {
              this.archiveKeyMessage = this.searchTipKeyMessage;
              this.archiveValueMessage = this.searchTipValueMessage;
              this.archiveDetails.ArchivesFound = [];
              if(this.showArchiveSearch) {
              let element = document.getElementById("archive_record_section");
              element.classList.remove("archive-record-bg");
              }
            }
            else if (!(details && details.ArchivesFound.length > 0)) {
              this.archiveDetails.ArchivesFound = [];
              if(this.showArchiveSearch) {
              let element = document.getElementById("archive_record_section");
              element.classList.remove("archive-record-bg");
              }
            }
            else {
              let limit = 3;
              this.archiveDetails.ArchivesFound = details.ArchivesFound.slice(0, limit);
              for (let i in this.archiveDetails.ArchivesFound) {
                if (this.userConfig.value.isAdmin || this.userConfig.value.isGlobalReader || this.userConfig.value.isRCO) {
                  this.archiveDetails.ArchivesFound[i][0].IsAccesible = 0;
                }
              }

            }

          },
          (err) => {
            this.isSearchLoading = false;
          }
        );
      }
      else {
        this.showArchiveMessages = true;
        this.archiveKeyMessage = this.searchTipKeyMessage;
        this.archiveValueMessage = this.searchTipValueMessage;
        if(this.archiveDetails) {
        this.archiveDetails.ArchivesFound = [];
      }
      if(this.showArchiveSearch) {
        let element = document.getElementById("archive_record_section");
        element.classList.remove("archive-record-bg");
      }
      }
    // });


    //record archive search
    // const obsDoc = fromEvent(this._elementRef.nativeElement.querySelector('#archiveHeaderUniqueSearch'), 'keyup')
    //   .pipe (
    //       map((e:any) => {

    //         return e.target.value;
    //       }),

    //       distinctUntilChanged(),
    //       debounceTime(500), 

    //       map((query:string) => {
    //        return of(query) 
    //         }
    //         ), 
    //         switchAll()
    //       ); 

    //       obsDoc.subscribe((result) => {
    //      if((this.archiveSearchValue&&this.archiveSearchValue.length > 2))
    //           {
    //      this.isSearchLoading=true;
    //      this.homepageSvc.documentHomeSearch(this.archiveSearchValue,this.userAlias) .subscribe(
    //       (details) =>{
    //         let element = document.getElementById("archive_record_section");
    //             element.classList.add("archive-record-bg");
    //         this.recordDetails = details;
    //         console.log('record details',this.recordDetails);
    //        this.showMessages = true;
    //        if(this.NoResultKeyMessage == 'No Data found For Archive Grid') {
    //         this.archiveKeyMessage= 'No Data Found For Records Grid';
    //       } else {
    //         this.archiveKeyMessage=this.NoResultKeyMessage;
    //       }
    //         this.archiveValueMessage=this.NoResultValueMessage;
    //            this.isSearchLoading=false;
    //           if(!(this.archiveSearchValue&&this.archiveSearchValue.length > 2))
    //           {
    //             this.archiveKeyMessage=this.searchTipKeyMessage;
    //             this.archiveValueMessage=this.searchTipValueMessage;
    //             this.recordDetails.RecordsFound = [];
    //             let element = document.getElementById("archive_record_section");
    //             element.classList.remove("archive-record-bg");
    //           }
    //           else if(!(details&&details.RecordsFound.length>0))
    //           {
    //             this.recordDetails.RecordsFound = [];
    //             let element = document.getElementById("archive_record_section");
    //             element.classList.remove("archive-record-bg");

    //           }
    //           else
    //           {
    //             let limit=3;
    //             this.recordDetails.RecordsFound=details.RecordsFound.slice(0,limit);
    //           }

    //       },
    //       (err) => {
    //           this.isSearchLoading=false;
    //         console.log("Error Occured", err);
    //       }
    //     );
    //           }
    //           else    
    //           {
    //             this.showMessages = false;
    //             this.archiveKeyMessage=this.searchTipKeyMessage;
    //             this.archiveValueMessage=this.searchTipValueMessage;
    //             this.recordDetails.RecordsFound = [];
    //             let element = document.getElementById("archive_record_section");
    //             element.classList.remove("archive-record-bg");
    //           } 
    // });
    }
    this.SpinnerService.hide();
    if (this.archiveSearchValue.length < 2) {
      this.archiveKeyMessage = this.searchTipKeyMessage;
      this.archiveValueMessage = this.searchTipValueMessage;
    }
    this.showArchiveSearch = true;
    if (this.showArchiveSearch = true) {
      let element = document.getElementById("customSearchBlock");
      element.classList.add("custom-search-block");
      if(!this.isSearchLoading) {
      let element1 = document.getElementById("searchIconSImpleSearch");
      element1.classList.add("custom-search-icon-alignment");
      }
      let element2 = document.getElementById("archiveHeaderUniqueSearch");
      element2.classList.add("custom-mat-form-field-autofill-control");
      if(this.archiveSearchValue.length > 1) {
      let element3 = document.getElementById("customIconcloseSpcl");
      element3.classList.add("custom-icon-Cross_close_SPECIAL");
    }
    } else {
      return false;
    }

  }
  mouseOver(event: any, index: number) {
    this.hoverIndex = index;
    //event.stopPropagation();
  }

  navigateSearch() {
    //this.SpinnerService.show();
    //this.clearSearchResult();
    this.router.navigate(["/search/advancedsearch/archives/" + this.archiveSearchValue]);
    this.homepageSvc.advanceSearchBtnDisable = false;
    this.clearSearchResult();
  }
  mouseRowEvent(event) {
    if (event == 2) {
      this.tooltipInfo = "An archive may be unavailable to you if you are not on the archive team and the archive has not been approved or is undergoing a resubmission. You may request access once the archive is in an approved status."
    } else {
      this.tooltipInfo = '';
    }
  }
  clearSearchResult() {
    let element1 = document.getElementById("customSearchBlock");
    element1.classList.remove("custom-search-block");
    let element2 = document.getElementById("searchIconSImpleSearch");
    element2.classList.remove("custom-search-icon-alignment");
    let element3 = document.getElementById("archiveHeaderUniqueSearch");
    element3.classList.remove("custom-mat-form-field-autofill-control");
    let element4 = document.getElementById("customIconcloseSpcl");
    element4.classList.remove("custom-icon-Cross_close_SPECIAL");
    this.archiveSearchValue = '';
    this.isSearchLoading = false;
    this.showArchiveSearch = false;
    this.showMessages = false;
    this.archiveDetails.ArchivesFound = [];
    // this.recordDetails.RecordsFound=[];
    this.documentData = [];
    let element = document.getElementById("archive_record_section");
    element.classList.remove("archive-record-bg");
    this.archiveKeyMessage = this.searchTipKeyMessage;
    this.archiveValueMessage = this.searchTipValueMessage;
  }
  // downloadFile(fileTansferId,fileName: string) {
  //   if (!fileName && !fileTansferId) return false;
  //   var metaData = {};
  //   var fileUploadProcessService = new FileUploadProcessService(
  //     this._fuService,
  //     this._uploadEventService,
  //     this.SpinnerService,
  //     null,
  //     null,
  //     metaData
  //   );
  //   var s3fileName =  fileTansferId + "_" + fileName;
  //   fileUploadProcessService.downloadFile(s3fileName,fileName);
  // }

  @HostListener('document:keydown.escape', ['$event']) onKeydownHandler(event: KeyboardEvent) {
    this.clearSearchResult();
  }

}