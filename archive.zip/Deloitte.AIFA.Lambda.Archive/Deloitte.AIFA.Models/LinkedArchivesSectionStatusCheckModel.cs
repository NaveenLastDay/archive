﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DataModels
{
    public class LinkedArchivesSectionStatusCheckModel
    {
        public string ladescription { get; set; }
        public string createdBy { get; set; }
    }
}
