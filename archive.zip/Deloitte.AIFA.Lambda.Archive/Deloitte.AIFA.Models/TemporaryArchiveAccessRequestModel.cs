﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DataModels
{
    public class TemporaryArchiveAccessRequestModel
    {
        public string RequestedBy { get; set; }
        public string RequestDesc { get; set; }
        public string ArchiveAccessRequestID { get; set; }
    }
}
