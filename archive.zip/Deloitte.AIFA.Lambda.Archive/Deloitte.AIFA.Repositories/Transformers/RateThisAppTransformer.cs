﻿using Deloitte.AIFA.DataModels;
using Deloitte.AIFA.DBHelper;
using Deloitte.AIFA.DomainEntities;
using Deloitte.AIFA.Models;
using Deloitte.AIFA.Repositories.UtilityHelper;
using System;
using System.Data;

namespace Deloitte.AIFA.Repositories.Transformers
{
    public enum RateThisAppField
    {
        RatingVal
    }
    public enum GetUserRatingParameter
    {
        [CreateField(Direction = ParameterDirection.Input, Type = DbType.String)]
        UserAlias,
        [CreateField(Direction = ParameterDirection.Input, Type = DbType.String, Name = "ApplicationID")]
        ApplicationId,
        [CreateField(Direction = ParameterDirection.Output, Type = DbType.Int32)]
        RatingVal
    }

    public enum RatingSubmissionInfoSubmitParameter
    {
        [CreateField(Direction = ParameterDirection.Input, Type = DbType.Int32)]
        PersonnelNbr,
        [CreateField(Direction = ParameterDirection.Input, Type = DbType.String)]
        Comments,
        [CreateField(Direction = ParameterDirection.Input, Type = DbType.String)]
        PageName,
        [CreateField(Direction = ParameterDirection.Input, Type = DbType.String, Name = "ApplicationID")]
        ApplicationId,
        [CreateField(Direction = ParameterDirection.Input, Type = DbType.DateTime)]
        FeedbackProvidedDateTime,
        [CreateField(Direction = ParameterDirection.Input, Type = DbType.Int32)]
        Rating,
        [CreateField(Direction = ParameterDirection.Input, Type = DbType.String)]
        UserAlias,
    }
}
