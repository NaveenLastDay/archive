import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sub-batch-home',
  templateUrl: './sub-batch-home.component.html',
  styleUrls: ['./sub-batch-home.component.css']
})

export class SubBatchHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}