import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DestructionHomeComponent } from './destruction-home.component';

describe('DestructionHomeComponent', () => {
  let component: DestructionHomeComponent;
  let fixture: ComponentFixture<DestructionHomeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DestructionHomeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DestructionHomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
