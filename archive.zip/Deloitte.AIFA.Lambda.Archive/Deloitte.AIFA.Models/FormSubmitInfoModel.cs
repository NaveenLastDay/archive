﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DataModels
{
    public class FormSubmitInfoModel
    {
        public int Id { get; set; }
        public string ArchiveNumber { get; set; }
        public DateTime ProposedADCEDDate { get; set; }
        public string Reason { get; set; }
        public string AdditionalDetails { get; set; }
        public string ActionsTobeTaken { get; set; }
        public string AuditPICName { get; set; }
        public string AuditPPDName { get; set; }
        public string CreatedBy { get; set; }
        //public string ResponseMessage { get; set; }
    }
}
