﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
    public class AppliedArchiveHoldsInformation
    {
        public string ClientName { get; set; }
        public string ArchiveNumber { get; set; }
        public string Business { get; set; }
        public DateTime? PeriodEndDate { get; set; }
        public DateTime? EffectiveStartDate { get; set; }
        public DateTime? EffectiveEndDate { get; set; }
        public string Status { get; set; }
        public string ArchiveName { get; set; }
        public string RecordDescription { get; set; }
        public int Count { get; set; }
    }
    public class ApplyArchiveHolds
    {
        public string HoldNumber { get; set; }
        public string ArchiveNumber { get; set; }
        public string CreatedBy { get; set; }
        public string SortBy { get; set; }
        public string SortOrder { get; set; }
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
    }

}
