import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'highlightcolorText',
  pure: false
})
export class HighlightcolorTextPipe implements PipeTransform {
  transform(value: string, query: string) {
    if (value.toLowerCase().includes(query.toLowerCase()) && value != undefined && value != "" && value != null && query != undefined && query != "" && query != null)
      return value.toLocaleLowerCase().replace(query.toLocaleLowerCase(), `<span class="highlightedtextcolor">${value.substr(value.toLocaleLowerCase().indexOf(query.toLocaleLowerCase()), query.length)}</span>`)

    else {
      return value;
    }
  }
}
