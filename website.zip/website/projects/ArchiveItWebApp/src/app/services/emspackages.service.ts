import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EmspackagesService {
  data = [];
  apiData: any;
  APIData : any;
  finalSelectedJson = {    
    "isMasterData": false, 
    "isAutoComplete":false,
    "clientautotext":'',
    "from": 0,
    "pageSize": 10,
    "sortBy":1,
    "includeTeammember":true,
    "clientName":'',
    "clientId":0,
    "submitterName":'',
    "engagementType":'',
    "etmName":'',
    "approverName":'',
    "officeEngagement":'',
    "packagecreationDateFrom":'',
    "packagecreationDateTo":'',
    "submittedDateFrom":'',
    "submittedDateTo":'',
    "periodDateFrom":'',
    "periodDateTo":'',
    "approverDateFrom":'',
    "approverDateTo":''
  };
  simpleSelectJson = {    
    "keyword": '', 
    "from": 0,
    "pageSize": 10,
    "sortBy": 1
  };

  constructor(private _http: HttpClient) { }
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'

    }),
}

public GetEmsInfo(simpleSelectJson:any): Observable<any> {
  this.apiData = this._http.post<any[]>('getemsmetadatasimplesearch',simpleSelectJson, this.httpOptions);
  return this.apiData;
}

public getMasterDataResults(finalSelected:any):Observable<any>{  
  debugger;
  this.apiData = this._http.post<any[]>('getemsadvancedsearchdetails',finalSelected,  this.httpOptions);
  return this.apiData;
}

public getEmsAdvancedSearch(finalSelected:any):Observable<any>{  
  debugger;
  this.apiData = this._http.post<any[]>('getemsadvancedsearchdetails',finalSelected,  this.httpOptions);
  return this.apiData;
}

// public archiveHomeSearch(searchValue:string,argloggedinuser :string): Observable<any> {
//   const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
//   this.apiData = this._http.get<any[]>('v1/getsimplesearcharchivedetails/'+searchValue+'/'+argloggedinuser, httpOptions);
//   return this.apiData;
// }

}

