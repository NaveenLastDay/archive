﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
    public class ArchiveHistory
    {
        public string Action { get; set; }
        public int ArchiveID { get; set; }
        public string ArchiveNumber { get; set; }
        public string RoleName { get; set; }
        public string CreatedDate { get; set; }
        public string ZoneName { get; set; }
        public string CreatedZoneDate { get; set; }
        public string CreatedBy { get; set; }
        public string ChangedFrom { get; set; }
        public string ChangedTo { get; set; }
        public int RowNumber { get; set; }
        public int Count { get; set; }
        public string ResubmissionReason { get; set; }
    }
}
