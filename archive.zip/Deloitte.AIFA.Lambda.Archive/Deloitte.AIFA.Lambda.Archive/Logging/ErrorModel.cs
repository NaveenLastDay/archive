﻿using Microsoft.Extensions.Logging;
using System;

namespace Deloitte.AIFA.Lambda.Logging
{
    public class ErrorModel
    {
        public string CorrelationId { get; set; }
        public string Message { get; set; }
        public int StatusCode { get; set; }
        public string StackTrace { get; set; }
    }
}
