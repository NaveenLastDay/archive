import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ArchiveService } from '../../../services/archive.service';
// import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-pending-access-search-list',
  templateUrl: './pending-access-search-list.component.html',
  styleUrls: ['./pending-access-search-list.component.css']
})
export class PendingAccessSearchListComponent implements OnInit {
  archiveDetails:any;
  @Input('archiveNumber') archiveNumber : string;
  @Input('entityTypeDescription') entityTypeDescription : string;
  @Input('professionalStandardDescription') professionalStandardDescription : string;
  @Output() archiveID = new EventEmitter();
  @Input('archiveAccessRequestID') archiveAccessRequestID : string;
  @Input('estimatedIssuanceReportDate') estimatedIssuanceReportDate : any;

  constructor(private archiveService : ArchiveService) { }

  ngOnInit() {
    // this.SpinnerService.show();
    this.archiveService.SetArchiveIdChildVal(this.archiveAccessRequestID);
    this.archiveService.GetMyArchiveDetails(this.archiveNumber).subscribe(
      data => {
        this.archiveDetails = data;
        this.archiveID.emit(this.archiveAccessRequestID);
        // this.SpinnerService.hide();
      });
  }

}
