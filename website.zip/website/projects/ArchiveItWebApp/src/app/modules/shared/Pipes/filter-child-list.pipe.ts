import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'listChildFilter'
})
export class ListChildFilterPipe implements PipeTransform {
  transform(items: Array<any>, linkedArchiveID: string): Array<any> {
    return items.filter(item => item.parentHierarchy === linkedArchiveID);
  }
}
