import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { FormGroup, Validators, FormBuilder, FormArray } from '@angular/forms';
import { ArchiveSearchService } from '../../../services/archive-search.service';
import { PeoplePickerService } from '../../../services/MDREmployeeeDetails.service';
import { NgbDateStruct } from "@ng-bootstrap/ng-bootstrap";
import { MatAutocompleteTrigger, MatDatepickerInputEvent } from '@angular/material';
import { MatAutocompleteSelectedEvent } from '@angular/material';
import { Router, NavigationEnd } from '@angular/router'
import { Observable, of } from 'rxjs';
import { WBSData } from '../../archive/search-wbs/search-wbs.component';
import { SearchWbsService } from '../../../services/searchwbs.service';
import { NotifierService } from 'angular-notifier';
import { AppConfig } from '../../../services/appconfig.service';
import { ViewChild } from '@angular/core';
import { SearchEventService } from '../search.event.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { DatePipe } from '@angular/common';
import * as moment from 'moment';

@Component({
  selector: 'custom-rule',
  templateUrl: './custom-rule.component.html',
  styleUrls: ['./custom-rule.component.css']
})
export class CustomRuleComponent implements OnInit {
  fromDate: NgbDateStruct;
  // toDate: NgbDateStruct;
  estimatedate: any;
  containers = [];
  statusList = [];
  labeltextfrom: string = 'From';
  labeltextto: string = 'To';
  advancefilter: boolean = true;
  defaultmanager: any;
  archivemanager: string;
  users: Array<any> = [];
  clients: Array<any> = [];
  login_form: FormGroup;
  client_form: FormGroup;
  searchResult: Array<any> = [];
  customRules: Array<any> = [];
  selectedManagerViewName: string = "";
  selectedManager: string;
  selectedManagerDisplayName: string;
  selectedClientViewName: string = "";
  selectedClient: string;
  selectedClients: Array<any> = [];
  selectedManagers: Array<any> = [];
  selectedStatusList: Array<any> = [];
  selectedWBSList: Array<any> = [];
  customRulesFormGroup: FormGroup;
  customRuleFormGroup: FormGroup;
  fieldtype: number;
  startDate: string;
  toDate: string;
  selectedStatusValue = "Please select";
  fieldControlValues: Array<any> = [];
  @Input() customRuleIndex: number;
  @Input() indexValue: number;
  @Input() fromDateVal: any;
  @Input() position: string = 'bottom';
  @Input() toDateVal: any;
  @Input() fieldArray:Array<any> = [];
  @Output() deletedCustomRule = new EventEmitter();
  @ViewChild('autoCompleteInput', { read: MatAutocompleteTrigger, static: false }) autoComplete: MatAutocompleteTrigger;

  fieldId: any;
  //wbs//
  autoTrigger: MatAutocompleteTrigger;
  $wbsClientData: Observable<any[]>;
  $searchWBSData: WBSData[];
  $filteredwbsClientData: Observable<any[]>;
  wbsCount: any;
  apiData2: any[];
  rowcount: any;
  searchedWBSResults: string;
  searchWBSData2: any[];
  wbslength: any;
  buttonDisabled: boolean;
  textlength: any;
  searchedtext: string = "";
  selectDate: string;
  selectedFeilds: Array<any> = [];
  fieldName: string = "";
  customRulesFilterArray: Array<any> = [];
  Date : any;
  maxDate: any;
  OGCDate: Date = undefined;
  minDate: any;
  Displaydate: NgbDateStruct;
  selectedday: string;
  selectedmonth: string;
  //customRulesArray:Array<any>=["Archive Name","Archive Number","Client","Archive Member","Status","WBS","Period End"];
  // customRulesArray=[{
  //   "1":"Archive Name",
  //   "2":"Archive Number",
  //   "3":"Client","4":"Archive Member","Status","WBS","Period End"

  // }]

  constructor(private router: Router, private datePipe: DatePipe, private fb: FormBuilder, private search: ArchiveSearchService, private searchEventService: SearchEventService, private searchwbs: SearchWbsService, private notifier: NotifierService, private peoplePickerService: PeoplePickerService, private SpinnerService: NgxSpinnerService) {
    this.login_form = fb.group({
      'archivemanager': [null, Validators.required],
    });
    this.client_form = fb.group({
      'archiveclient': [null, Validators.required],
    });
    this.rowcount = 10;
    this.searchedWBSResults = '';
    if(this.fromDateVal != undefined) {
      this.startDate = this.fromDateVal;
      console.log('this.startDate constructor',this.startDate);
    }
  }

  ngOnInit() {
    this.customRulesFormGroup = this.fb.group({

      fieldControl: this.fb.control('null'),
      operatorControl: this.fb.control(''),
      valueControl: this.fb.control('')
    });
    this.customRulesFilterArray=this.fieldArray
    this.bindStatus();
    this.fieldtype = 0;
    this.fieldId = 0;
    if (this.searchEventService.bindCustomRules) {
      this.bindExistingCustomRules();
    }

  }
  onChange(event: any) {
    this.OGCDate = event;
  }
  bindExistingCustomRules() {
    var obj = this.searchEventService.customRuleJson.sort((n1, n2) => n1.Index - n2.Index);

    for (var key in obj) {
      if (obj != null) {
        if (obj.hasOwnProperty(key)) {
          var val = obj[key];

          if (val.ArchiveName && this.searchEventService.selectedFieldName.indexOf("archiveName") == -1) {
            this.fieldtype = 1;
            this.customRulesFormGroup.get('fieldControl').setValue(1);
            this.customRulesFormGroup.controls.valueControl.setValue(val.ArchiveName);
            this.searchEventService.selectedFieldName.push("archiveName");
            this.searchEventService.selectedFields.push({ Index: this.indexValue, id: "1" })
            obj = [];
          }
          else if (val.ArchiveNumber && this.searchEventService.selectedFieldName.indexOf("archiveNumber") == -1) {
            this.fieldtype = 1;
            this.customRulesFormGroup.get('fieldControl').setValue(2);
            this.customRulesFormGroup.controls.valueControl.setValue(val.ArchiveNumber);
            this.searchEventService.selectedFieldName.push("archiveNumber");
            this.searchEventService.selectedFields.push({ Index: this.indexValue, id: "2" })
            obj = [];
          }
          else if (val.ClientName && this.searchEventService.selectedFieldName.indexOf("clientName") == -1) {
            this.fieldtype = 5
            this.customRulesFormGroup.get('fieldControl').setValue(3);
            this.searchEventService.customRuleJson.forEach(client => {
              if (client.ClientName) {
                this.selectedClients.push(client.ClientName);
                this.searchEventService.selectedClientsList.push({ Index: this.indexValue, ClientName: client.ClientName })
              }

            });
            this.searchEventService.selectedFieldName.push("clientName");
            this.searchEventService.selectedFields.push({ Index: this.indexValue, id: "3" })
            obj = [];
          }
          else if (val.WBS && this.searchEventService.selectedFieldName.indexOf("WBSNumber") == -1) {
            this.fieldtype = 6
            this.customRulesFormGroup.get('fieldControl').setValue(6);
            this.searchEventService.customRuleJson.forEach(Wbsvalue => {
              if (Wbsvalue.WBS) {
                this.selectedWBSList.push(Wbsvalue.WBS);
                this.searchEventService.selectedWbsList.push({ Index: this.indexValue, WBS: Wbsvalue.WBS })
              }
            });


            this.searchEventService.selectedFieldName.push("WBSNumber");
            this.searchEventService.selectedFields.push({ Index: this.indexValue, id: "6" })
            obj = [];
          }
          else if (val.Status && this.searchEventService.selectedFieldName.indexOf("archiveStatus") == -1) {
            this.fieldtype = 2
            this.customRulesFormGroup.get('fieldControl').setValue(5);
            this.searchEventService.customRuleJson.forEach(status => {
              if (status.Status) {
                this.selectedStatusList.push(status.Status);
                this.searchEventService.selectedStatusList.push({ Index: this.indexValue, Status: status.Status })
              }
            });

            this.searchEventService.selectedFieldName.push("archiveStatus");
            this.fieldtype = 2
            this.customRulesFormGroup.patchValue({
              valueControl: null,
            });
            this.searchEventService.selectedFields.push({ Index: this.indexValue, id: "5" })
            obj = [];
          }
          else if (val.ManagerName && this.searchEventService.selectedFieldName.indexOf("archiveTeamMembers") == -1) {
            this.fieldtype = 3
            this.customRulesFormGroup.get('fieldControl').setValue(4);


            this.searchEventService.customRuleJson.forEach(name => {
              if (name.ManagerName) {
                this.selectedManagers.push({
                  alias: name.ManagerName,
                  displayName: name.DisplayName
                });
                this.searchEventService.selectedManagerList.push({ Index: this.indexValue, alias: name.ManagerName })
              }


            });
            obj = [];
            this.searchEventService.selectedFieldName.push("archiveTeamMembers");
            this.searchEventService.selectedFields.push({ Index: this.indexValue, id: "4" })
          }
          else if (val.FromDate && this.searchEventService.selectedFieldName.indexOf("periodEndDate") == -1) {
            this.fieldtype = 4
            this.customRulesFormGroup.get('fieldControl').setValue(7);
            this.searchEventService.customRuleJson.forEach(date => {
              if (date.FromDate) {
                this.startDate = date.FromDate;
                console.log('this.startDate',this.startDate);
              }
              if (date.ToDate) {
                this.toDate = date.ToDate;
              }

            });


            this.searchEventService.selectedFieldName.push("periodEndDate");
            this.searchEventService.selectedFields.push({ Index: this.indexValue, id: "7" })
            obj = [];
          }


        }
      }

    }
  }
  SaveDate(event) {
    this.selectDate = event["selectDate"];
  }
  //select the customrule from dropdown 
   onFieldSelect(e) {
     this.fieldId = e.target.value;
     if (this.fieldId == "null") {
       this.customRulesFormGroup = this.fb.group({

         fieldControl: this.fb.control('null'),
         valueControl: this.fb.control('')
       });
       this.fieldtype = 0;
       this.notifier.notify("error", "Please select  search parameter");
     }
     else {
       if (this.searchEventService.selectedFields.length > 0) {
         var existIndexfield = this.searchEventService.selectedFields.findIndex(x => x.Index == this.indexValue);
         if (existIndexfield != -1) {
           var id = this.searchEventService.selectedFields[existIndexfield].id;
           this.searchEventService.selectedFields = this.searchEventService.selectedFields.filter(x => x.id != id);
           this.resetSelectedList(id)
         }
       }

       var fieldExists = this.searchEventService.selectedFields.findIndex(x => x.id == this.fieldId);
       if (fieldExists == -1) {
         this.searchEventService.selectedFields.push({ id: this.fieldId, Index: this.indexValue });
         if (this.fieldId == 1 || this.fieldId == 2) {
           this.fieldtype = 1
         }
         else if (this.fieldId == 4) {
           this.fieldtype = 3
         }
         else if (this.fieldId == 3) {
           this.fieldtype = 5
         }
         else if (this.fieldId == 7) {
           this.fieldtype = 4
         }
         else if (this.fieldId == 5) {
           this.fieldtype = 2
           this.customRulesFormGroup.patchValue({
             valueControl: null,
           });
         }
         else if (this.fieldId == 6) {
           this.fieldtype = 6
         }
         this.searchEventService.showApplied = false;
         this.searchEventService.showApplyAll = true;

       }
       else {
         // this.searchEventService.onDeleteClick(this.indexValue);
         this.customRulesFormGroup = this.fb.group({

           fieldControl: this.fb.control('null'),
           valueControl: this.fb.control('')
         });
         this.fieldtype = 0;
         this.notifier.notify("error", "Search parameter already exists");
       }


     }
   }
  //removing already selected feild for dropdown change
  resetSelectedList(fieldId: string) {
    this.searchEventService.customRuleJson = this.searchEventService.customRuleJson.filter(x => !(x.Index == this.indexValue));
    if (fieldId == "1") {
      this.customRulesFormGroup.get('valueControl').reset();
    }
    else if (fieldId == "2") {
      this.customRulesFormGroup.get('valueControl').reset();
    }
    else if (fieldId == "4") {
      this.login_form.get('archivemanager').reset();
      this.selectedManagers = [];
      this.users = [];
      this.searchEventService.selectedManagerList = [];
    }
    else if (fieldId == "3") {
      this.client_form.get('archiveclient').reset();
      this.selectedClients = [];
      this.clients = [];
      this.searchEventService.selectedClientsList = [];
    }
    else if (fieldId == "7") {
      this.startDate = "";
      this.toDate = "";
    }
    else if (fieldId == "5") {
      this.selectedStatusList = [];
      this.searchEventService.selectedStatusList = [];
      this.customRulesFormGroup.patchValue({
        valueControl: null,
      });

    }
    else if (fieldId == "6") {
      this.selectedWBSList = [];
      this.searchEventService.selectedWbsList = [];
      this.$searchWBSData = null;
      this.customRulesFormGroup.get('valueControl').reset();
    }
  }
  //on click Delete Icon
  deletefield(indexValue) {
    this.searchEventService.onDeleteClick(indexValue);
    this.searchEventService.customRuleJson = this.searchEventService.customRuleJson.filter(x => !(x.Index == this.indexValue));
    this.deletedCustomRule.emit(this.indexValue);
    this.searchEventService.selectedManagerList = this.searchEventService.selectedManagerList.filter(x => !(x.Index == this.indexValue));
    this.searchEventService.selectedClientsList = this.searchEventService.selectedClientsList.filter(x => !(x.Index == this.indexValue));
    this.searchEventService.selectedStatusList = this.searchEventService.selectedStatusList.filter(x => !(x.Index == this.indexValue));
    this.searchEventService.selectedWbsList = this.searchEventService.selectedWbsList.filter(x => !(x.Index == this.indexValue));
    var deletefieldValue = this.customRulesFormGroup.get('fieldControl').value;
    this.searchEventService.selectedFields = this.searchEventService.selectedFields.filter(x => x.id != deletefieldValue);
    this.searchEventService.showApplied = false;
    this.searchEventService.showApplyAll = true;
    if (this.searchEventService.selectedFields.length < 7) {
      this.searchEventService.enableCustomRuleBtn = true;
    }
  }
  //on Archive Name or Number change
  onBlurOutFunction() {
    var nameValue = this.customRulesFormGroup.get('valueControl').value;
    var selectedField = this.customRulesFormGroup.get('fieldControl').value;
    if (nameValue != '' && nameValue.length > 2) {
      //checking wheather ArchiveName or not 
      if (selectedField == "1") {
        this.searchEventService.customRuleJson = this.searchEventService.customRuleJson.filter(x => !(x.Index == this.indexValue));
        this.searchEventService.customRuleJson.push({
          Index: this.indexValue,
          ArchiveName: nameValue,
        });
      }
      //will execute if it is Archive Number
      else {
        this.searchEventService.customRuleJson = this.searchEventService.customRuleJson.filter(x => !(x.Index == this.indexValue))
        this.searchEventService.customRuleJson.push({
          Index: this.indexValue,
          ArchiveNumber: nameValue
        });
      }
      this.searchEventService.showApplied = false;
      this.searchEventService.showApplyAll = true;
    }
    else {
      // this.notifier.notify("error", "Please enter more than 2 characters");
      this.searchEventService.customRuleJson = this.searchEventService.customRuleJson.filter(x => !(x.Index == this.indexValue))
      this.searchEventService.showApplied = false;
      this.searchEventService.showApplyAll = true;
    }

  }

  //Period End
  //When Period End From date Selected
  fromSelectedDate(event) {
    //debugger;
    // var date = this.datePipe.transform(event, "yyyy-MM-dd");
    this.minDate = event; 
   (event!=='' && event.day != null && event.day.toString().length == 1) ? this.selectedday = '0'+event.day : this.selectedday = event.day;
   (event!=='' && event.month != null && event.month.toString().length == 1) ? this.selectedmonth = '0'+event.month : this.selectedmonth = event.month;
   if(event!=='') {
       var date = event.year+'-'+this.selectedmonth+'-'+this.selectedday;
      } else {
         date = event;
      }
    var index = this.searchEventService.customRuleJson.findIndex(x => x.FromDate != undefined);
    if (index > -1) {
      this.searchEventService.customRuleJson.splice(index, 1);
    }
    this.searchEventService.customRuleJson.push({
      Index: this.indexValue,
      FromDate: date
    });
    this.searchEventService.disableSearchBtn = false;
    this.searchEventService.showApplied = false;
    this.searchEventService.showApplyAll = true;
  }
  //When Period End To date Selected
  toSelectedDate(event) {
    // var date = this.datePipe.transform(event.target.value, "yyyy-MM-dd");
    this.maxDate = event;
    (event!=='' && event.day != null && event.day.toString().length == 1) ? this.selectedday = '0'+event.day : this.selectedday = event.day;
   (event!=='' && event.day != null && event.month.toString().length == 1) ? this.selectedmonth = '0'+event.month : this.selectedmonth = event.month;
   if(event!=='') {
   var date = event.year+'-'+this.selectedmonth+'-'+this.selectedday;
  } else {
    date = event;
 }
    var index = this.searchEventService.customRuleJson.findIndex(x => x.ToDate != undefined);
    if (index > -1) {
      this.searchEventService.customRuleJson.splice(index, 1);
    }
    this.searchEventService.customRuleJson.push({
      Index: this.indexValue,
      ToDate: date
    });
    this.searchEventService.showApplied = false;
    this.searchEventService.showApplyAll = true;
  }

  //Archive Member 
  //To get Archive Member
  onInputChanged(searchString: string) {
    this.users = [];

    if (searchString.length >= 3) {
      this.users = [];
      this.peoplePickerService.GetPeople(searchString).subscribe(
        (value) => {
          this.users = value;
        },
        (err) => {
          console.log("error is ", err)
        }
      );
    }
    else if (searchString.length == 0) {
      this.users = [];
    }
    else {
      this.users = [];
    }
    this.SpinnerService.hide();
  }
  //To store selected Archive member Details
  selectedManagerName(partner, index) {
    this.selectedManagerViewName = partner.source.viewValue;
    this.selectedManager = this.users[index].userAlias;
    this.selectedManagerDisplayName = this.users[index].displayName;

    if (this.searchEventService.selectedManagerList.length > 0) {
      var managerExists = this.searchEventService.selectedManagerList.findIndex(x => x.alias == this.selectedManager)
      if (managerExists == -1) {
        this.searchEventService.selectedManagerList.push({ Index: this.indexValue, alias: this.selectedManager, displayName: this.selectedManagerDisplayName });
        this.selectedManagers.push({ alias: this.selectedManager, displayName: this.selectedManagerDisplayName });
        this.searchEventService.customRuleJson.push({
          Index: this.indexValue,
          ManagerName: this.selectedManager,
          DisplayName: this.selectedManagerDisplayName
        });
        this.searchEventService.showApplied = false;
        this.searchEventService.showApplyAll = true;
      }
    }
    else {
      this.searchEventService.selectedManagerList.push({ alias: this.selectedManager, displayName: this.selectedManagerDisplayName });
      this.selectedManagers.push({ alias: this.selectedManager, displayName: this.selectedManagerDisplayName });
      this.searchEventService.customRuleJson.push({
        Index: this.indexValue,
        ManagerName: this.selectedManager,
        DisplayName: this.selectedManagerDisplayName
      });
      this.searchEventService.showApplied = false;
      this.searchEventService.showApplyAll = true;
    }
    //change to useralias once lambda is changed.
    this.users = [];
    this.login_form.get('archivemanager').reset();

  }
  //To delete Archive Member
  deleteManager(memberName) {
    this.selectedManagers = this.selectedManagers.filter(e => e.displayName !== memberName.displayName);
    this.searchEventService.customRuleJson = this.searchEventService.customRuleJson.filter(x => !(x.ManagerName == memberName.alias));
    this.searchEventService.selectedManagerList = this.searchEventService.selectedManagerList.filter(x => x.alias !== memberName.alias);
    this.searchEventService.showApplied = false;
    this.searchEventService.showApplyAll = true;
  }

  //Client 
  //To get client Details 
  onClientInputChanged(searchString: string) {
    this.clients = [];
    if (searchString.length >= 3) {
      this.search.getArchiveSearchResults(searchString, "Client").subscribe(result => {
        if (result.length > 0) {
          this.clients = result;
        }
        else {
          this.clients = null;

        }
      },
        (err) => {
          console.log("error is ", err)
        }
      );
    }
    else if (searchString.length == 0) {
      this.clients = [];
    }
    else {
      this.clients = [];
    }
    this.SpinnerService.hide();
  }
  //To store the selected Client details 
  selectedClientName(client, index) {
    this.selectedClientViewName = client.source.viewValue;
    this.selectedClient = this.clients[index].itemName;
    if (this.searchEventService.selectedClientsList.length > 0) {
      var clientExists = this.searchEventService.selectedClientsList.findIndex(x => x.ClientName == this.selectedClient)
      if (clientExists == -1) {
        this.searchEventService.selectedClientsList.push({ Index: this.indexValue, ClientName: this.selectedClient });
        this.selectedClients.push(this.selectedClient);
        this.searchEventService.customRuleJson.push({
          Index: this.indexValue,
          ClientName: this.selectedClient

        });
        this.searchEventService.showApplied = false;
        this.searchEventService.showApplyAll = true;
      }
    }
    else {
      this.selectedClients.push(this.selectedClient);
      this.searchEventService.selectedClientsList.push({ Index: this.indexValue, ClientName: this.selectedClient });
      this.searchEventService.customRuleJson.push({
        Index: this.indexValue,
        ClientName: this.selectedClient

      });
      this.searchEventService.showApplied = false;
      this.searchEventService.showApplyAll = true;
    }

    //change to useralias once lambda is changed.
    this.clients = [];
    this.client_form.get('archiveclient').reset();

  }
  //To delete the selected Client
  deleteClient(clientName) {
    this.selectedClients = this.selectedClients.filter(e => e !== clientName);
    this.searchEventService.customRuleJson = this.searchEventService.customRuleJson.filter(x => !(x.ClientName == clientName));
    this.searchEventService.selectedClientsList = this.searchEventService.selectedClientsList.filter(x => x.ClientName !== clientName);
    this.searchEventService.showApplied = false;
    this.searchEventService.showApplyAll = true;
  }

  // Status 
  //To bind status data into dropdown
  bindStatus() {
    this.search.getArchiveSearchResults("", "SubmissionStatus").subscribe(result => {
      if (result.length > 0) {
        this.statusList = result
      }
      else {

        this.statusList = null
      }
    },
      (err) => {
        console.log("error is ", err)
      }
    );


  }
  //To store the selected status 
  onStatusSelect(e) {
    var selectedstatus = e.target.value;
    if (selectedstatus == "null") {

    }
    else {
      if (this.searchEventService.selectedStatusList.length > 0) {
        var statusExists = this.searchEventService.selectedStatusList.findIndex(x => x.Status == selectedstatus)
        if (statusExists == -1) {
          this.searchEventService.selectedStatusList.push({ Index: this.indexValue, Status: selectedstatus })
          this.selectedStatusList.push(selectedstatus);
          this.searchEventService.customRuleJson.push({
            Index: this.indexValue,
            Status: selectedstatus

          });
          this.searchEventService.showApplied = false;
          this.searchEventService.showApplyAll = true;
        }
        this.customRulesFormGroup.patchValue({
          valueControl: null,
        });
      }
      else {
        this.selectedStatusList.push(selectedstatus);
        this.searchEventService.selectedStatusList.push({ Index: this.indexValue, Status: selectedstatus })
        this.searchEventService.customRuleJson.push({
          Index: this.indexValue,
          Status: selectedstatus

        });
        this.customRulesFormGroup.patchValue({
          valueControl: null,
        });
        this.searchEventService.showApplied = false;
        this.searchEventService.showApplyAll = true;
      }
    }
    //this.addingJsontoObject();

  }
  //to delete the status 
  deleteStatus(statusName) {
    this.selectedStatusList = this.selectedStatusList.filter(e => e !== statusName);
    this.searchEventService.customRuleJson = this.searchEventService.customRuleJson.filter(x => !(x.Status == statusName))
    this.searchEventService.selectedStatusList = this.searchEventService.selectedStatusList.filter(x => x.Status !== statusName);
    this.customRulesFormGroup.patchValue({
      valueControl: null,
    });
    this.searchEventService.showApplied = false;
    this.searchEventService.showApplyAll = true;
  }
  //WBS
  //To bind the WBS data  
  SearchWBSOne(event: any) {
    if (event.target.value.length >= this.textlength) {
      this.searchwbs.GetWBSSerchResults(event.target.value, this.rowcount).subscribe(result => {
        if (result.length > 0) {
          this.$searchWBSData = result;
        }
        else {
          this.$searchWBSData = null;
          this.notifier.notify("error", "No results found for Search WBS");
        }

      });
    }
    else {
      this.$searchWBSData = null;
    }
    if (this.$searchWBSData != undefined)
      this.wbsCount = this.$searchWBSData.length;
  }
  onWbsInputChanged(event: any) {
    this.wbslength = event.length;
    this.textlength = AppConfig.settings.searchwbs.textboxlength;
    //  var addedWbs= event.target.value;
    //  this.selectedWBSList.push(addedWbs);
  }
  //To store selected WBS data
  optionSelected(event: MatAutocompleteSelectedEvent) {
    var selectedWbs = event.option.value;
    if (this.searchEventService.selectedWbsList.length > 0) {
      var wbsExists = this.searchEventService.selectedWbsList.findIndex(x => x.WBS == selectedWbs)
      if (wbsExists == -1) {
        this.searchEventService.selectedWbsList.push({ Index: this.indexValue, WBS: selectedWbs });
        this.selectedWBSList.push(selectedWbs);
        this.searchEventService.customRuleJson.push({
          Index: this.indexValue,
          WBS: selectedWbs
        });
        this.searchEventService.showApplied = false;
        this.searchEventService.showApplyAll = true;
      }
      this.$searchWBSData = null;
      this.customRulesFormGroup.get('valueControl').reset();

    }
    else {
      this.searchEventService.selectedWbsList.push({ Index: this.indexValue, WBS: selectedWbs });
      this.selectedWBSList.push(selectedWbs);
      this.searchEventService.customRuleJson.push({
        Index: this.indexValue,
        WBS: selectedWbs
      });
      this.$searchWBSData = null;
      this.customRulesFormGroup.get('valueControl').reset();
      this.searchEventService.showApplied = false;
      this.searchEventService.showApplyAll = true;
    }
    this.autoComplete.closePanel();
    this.searchedtext = '';

  }
  //delete the selected WBS data
  deleteWBS(wbsName) {
    this.selectedWBSList = this.selectedWBSList.filter(e => e !== wbsName);
    this.searchEventService.customRuleJson = this.searchEventService.customRuleJson.filter(x => !(x.WBS == wbsName))
    this.searchEventService.selectedWbsList = this.searchEventService.selectedWbsList.filter(x => x.WBS !== wbsName);
    this.searchEventService.showApplied = false;
    this.searchEventService.showApplyAll = true;
  }
  ///Wbs///
  OnReset() {
    this.searchedtext = '';
    this.$searchWBSData = [];
    this.buttonDisabled = true;
  }

}
