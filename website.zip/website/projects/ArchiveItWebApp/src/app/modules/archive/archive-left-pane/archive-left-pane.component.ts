import { Component, OnInit } from '@angular/core';
import { archiveInfoService } from '../../../services/archiveinfo.service'
import { ActivatedRoute, NavigationEnd, Params } from '@angular/router';
// import { Router, NavigationEnd } from '@angular/router';
import { Router } from '@angular/router';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { PubsubService } from '../../../services/pubsub.service';
import { ArchiveService } from '../../../services/archive.service';
import { HomePageService } from '../../../services/homepage.service';
import { UserConfigSettingService } from '../../../guards/user-role-guard.service';
import { ArchiveHomeService } from '../../../services/archive-home.service';
import { NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { UserActions } from '../../../models/archive-role.model';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-archive-left-pane',
  templateUrl: './archive-left-pane.component.html',
  styleUrls: ['./archive-left-pane.component.css']
})
export class ArchiveLeftPaneComponent implements OnInit {
  wbsNumber: string;
  EnableStatusbox: boolean;
  EnableSubStyle: boolean;
  EnableApproveStyle: boolean;
  EnableApproveDatebox: boolean = false;
  EnableRejectStatusbox: boolean = false;
  ADCEDDate: any = null;
  canViewSwiftEngagementDetails: boolean;
  canChangeEstimatedReleaseDate: boolean;
  canRequestLegalHold: boolean;
  canRequestArchiveDeletion: boolean;
  formstatusCSS: { 'top': any, 'height': any };
  FormStatus: string = "";
  archiveNumber: string;
  archiveStatus: string;
  userConfig: any;
  selectDate: string;
  updateedcd: boolean;
  estimatedate: any;
  Displaydate: NgbDateStruct;
  employeeUniqueIdentifier: string;
  userAlias = this.adalSvc.LoggedInUserEmail.substring(0, this.adalSvc.LoggedInUserEmail.lastIndexOf("@"));
  canRequestForm3283S: any;
  canApproveForm3283S: any;
  roleMapping = new UserActions();
  IsFormEnabled: any;
  forminfo: any;
  formAvailableStatus: string = "As stated above, approval should be requested at the earliest point at which the Engagement Partner identifies the need for an extension, not to exceed 24 hours after the expected documentation completion date (i.e., the end of Day 31). In order for this Form to serve as an extension for archiving compliance performance reporting purposes, this Form will be reviewed to ensure Audit PIC and Audit PPD approval was requested within this time frame.  The date of PIC/PPD request for approval will be documented below by the engagement team."
  isAutocreatedArchive: boolean;
  WBSNumber: string;
  currentUrl: string;
  roleid: any;
  isArchiveDestroyed: number = 0;
  archiveinfo: any;

  constructor(
    private archiveinfoSvc: archiveInfoService, private router: Router, private _userConfig: UserConfigSettingService,
    private archiveService: ArchiveService, private SpinnerService: NgxSpinnerService,
    private homepageService: HomePageService, private activatedRoute: ActivatedRoute, private adalSvc: MsAdalAngular6Service,
    private pubsub: PubsubService, private archiveHomeService: ArchiveHomeService) {
    router.events.subscribe((_: NavigationEnd) => this.currentUrl = this.router.url);
    // activatedRoute.params.subscribe(val => 
    //   {
    //   debugger;
    // }
    // );
  }

  ngOnInit() {
    this.archiveNumber = this.activatedRoute.snapshot.paramMap.get('aN');
    this.employeeUniqueIdentifier = this.adalSvc.LoggedInUserEmail.split('@')[0];
    this.userConfig = this._userConfig.FetchLoggedInUser(this.employeeUniqueIdentifier);
    this.pubsub.setRoleMappingResult(this.roleMapping);
    this.archiveService.GetRoleMappingsForUser(this.employeeUniqueIdentifier, this.archiveNumber).subscribe(x => {
      if (x) {
        this.roleid = x.roleId;
        if (x != null && x.roleId == 27 && !this.userConfig.value.isAdmin) {
          this.router.navigate(['/archive/myarchives']);
        }
        this.roleMappingResult(x);
      }
      else this.router.navigate(['/archive/myarchives']);
    });
    this.WBSNumber = localStorage.getItem('WBS_Number');
    this.archiveinfoSvc.getArchiveInfo(this.archiveNumber, this.employeeUniqueIdentifier).subscribe(
      (info) => {
        this.isArchiveDestroyed = info.isDestroyed;
      }
    );
    this.isAutocreatedArchiveDetails();
    if (this.isAutocreatedArchive)
      this.setArchiveRebbonCSS();
    else
      this.removeArchiveRebbonCSS();
  }
  setArchiveRebbonCSS() {
    let element = document.getElementById("customBreadcrumb");
    element.classList.add("custom-breadcrumb");
    let element1 = document.getElementById("spnBreadcrumbTxt");
    element1.classList.add("spn-breadcrumb-text");
    let element2 = document.getElementById("spnLiBreadcrumb");
    element2.classList.add("spn-li-breadcrumb");
  }
  removeArchiveRebbonCSS() {
    let element = document.getElementById("customBreadcrumb");
    element.classList.remove("custom-breadcrumb");
    let element1 = document.getElementById("spnBreadcrumbTxt");
    element1.classList.remove("spn-breadcrumb-text");
    let element2 = document.getElementById("spnLiBreadcrumb");
    element2.classList.remove("spn-li-breadcrumb");
  }
  isAutocreatedArchiveDetails() {
    this.archiveinfoSvc.getautocreatearchivedetails(this.archiveNumber).subscribe(
      (info) => {
        this.isAutocreatedArchive = info.isArchiveCompleted;
        if (this.isAutocreatedArchive)
          this.setArchiveRebbonCSS();
        else
          this.removeArchiveRebbonCSS();
      });
  }
  ngOnDestroy() {
    this.removeArchiveRebbonCSS();
  }
  InfoDetails(event) {
    //this.wbsNumber = event["wbsNumber"];
    this.EnableSubStyle = event["EnableSubStyle"];
    this.EnableApproveDatebox = event["EnableApproveDatebox"];
    this.EnableRejectStatusbox = event["EnableRejectStatusbox"];
    this.EnableStatusbox = event["EnableStatusbox"];
    this.ADCEDDate = event["ADCEDDate"];
    // this.wbsNumber = event["wbsNumber"];
    this.FormStatus = event["FormStatus"];
    this.formstatusCSS = event["formstatusCSS"];
    this.IsFormEnabled = event["IsFormEnabled"];
    if (this.IsFormEnabled == true) {
      this.forminfo = "";
    }
    else {
      this.forminfo = "Form Not Available";
    }
    //this.Displaydate=event["Displaydate"];
    console.log("Display date:" + this.Displaydate);
    console.log("UserAlias:" + this.userAlias);
  }
  // ShiftEngDetails(event) {
  //   //debugger;
  //   this.canViewSwiftEngagementDetails = event["canViewSwiftEngagementDetails"];
  //   this.canChangeEstimatedReleaseDate = event["canChangeEstimatedReleaseDate"];
  //   this.canRequestArchiveDeletion = event["canRequestArchiveDeletion"];
  //   this.canRequestLegalHold = event["canRequestLegalHold"];
  //   this.canRequestForm3283S = event["canRequestForm3283S"];
  //   this.canApproveForm3283S = event["canApproveForm3283S"];

  // }
  WBSDetails(event) {
    this.wbsNumber = event["wbsNumber"];
    this.archiveNumber = event["archiveNumber"];
    this.archiveStatus = event["archiveStatus"];
    if (this.activatedRoute.snapshot['_routerState'].url.includes('deletionarchive') && (((this.roleid != 5) && (this.roleid != 6) && (this.roleid != 7) && (this.roleid != 15)) || (this.archiveStatus != 'Open' && this.archiveStatus != 'Ready For Approval' && this.archiveStatus != 'Rejected'))) {
      this.router.navigate(['/archive/myarchives']);
    }
  }
  EstimatedDateDetails(event) {
    this.Displaydate = event["Displaydate"];
    this.estimatedate = event["estimatedate"];
  }
  SaveDate(event) {

    this.selectDate = event["selectDate"];
    this.archiveinfoSvc.updateEDCDDate(this.archiveNumber, this.selectDate).subscribe(
      (info) => {
        console.log("Success" + info);
        this.updateedcd = true; this.sendArchiveDueDate();
        if (this.currentUrl == '/archive/myarchives/' + this.archiveNumber + '/form3283S') {
          this.router.navigate(['/archive/myarchives/' + this.archiveNumber + '/archivehome']);
          this.archiveHomeService.SyncForm3283SStatus(this.archiveNumber);
        }
        else {
          this.archiveHomeService.SyncForm3283SStatus(this.archiveNumber);
        }
      }
    );

  }

  sendArchiveDueDate() {
    this.pubsub.sendduedate(this.updateedcd);
  }

  roleMappingResult(x: any) {
    // this.archiveService.GetRoleMappingsForUser(this.employeeUniqueIdentifier, this.archiveNumber).subscribe(x => {
    //   // debugger;
    //   if (x) {
    this.roleMapping.roleId = x.roleId;
    this.roleMapping.roleDescription = x.roleDescription;
    this.roleMapping.canSearchArchives = x.archivePermissions.includes('Search Archives');
    this.roleMapping.canAccessArchives = x.archivePermissions.includes('Access Archive');
    this.roleMapping.canCreateArchive = x.archivePermissions.includes('Manual Archive Creation');
    this.roleMapping.canManageArchiveInfo = x.archivePermissions.includes('Manage Archive Info');
    this.roleMapping.canManageAccess = x.archivePermissions.includes('Manage Access');
    this.roleMapping.canSubmit = x.archivePermissions.includes('Submission');
    this.roleMapping.canUpload = x.archivePermissions.includes('Upload Record');
    this.roleMapping.canDownload = x.archivePermissions.includes('Download Record');
    this.roleMapping.canDelete = x.archivePermissions.includes('Delete Record');
    this.roleMapping.canMarkAsInactive = x.archivePermissions.includes('Mark as Inactive');
    this.roleMapping.canManageERP = x.archivePermissions.includes('Manage ERP');
    this.roleMapping.canRequestRetentionException = x.archivePermissions.includes('Request Retention Exception');
    this.roleMapping.canRequestAccess = x.archivePermissions.includes('Request Access');
    this.roleMapping.canApproveTemporaryAccess = x.archivePermissions.includes('Approve Temporary Access');
    this.roleMapping.canViewArchiveHistory = x.archivePermissions.includes('View Archive History');
    this.roleMapping.canPrintBinderReportCovers = x.archivePermissions.includes('Print Binder & Report Covers');
    this.roleMapping.canRequestImage = x.archivePermissions.includes('Request Image');
    this.roleMapping.canLinkArchives = x.archivePermissions.includes('Archive Linking');
    this.roleMapping.canApprove = x.archivePermissions.includes('Approval');
    this.roleMapping.canResubmit = x.archivePermissions.includes('Resubmission (Substantive or Adminstrative)');
    // this.roleMapping.canResubmitAdminApproval = x.archivePermissions.includes('Resubmission (Substantive or Adminstrative)');
    this.roleMapping.canResubmitAdminApproval = x.archivePermissions.includes('Administrative Resubmission Approval');
    this.roleMapping.canRequestArchiveDeletion = x.archivePermissions.includes('Request Archive Deletion');
    this.roleMapping.canRequestForm3283S = x.archivePermissions.includes('Request Form 3283S');
    this.roleMapping.canApproveForm3283S = x.archivePermissions.includes('Approve Form 3283S');
    this.roleMapping.canRequestLegalHold = x.archivePermissions.includes('Request Legal Hold');
    this.roleMapping.canTempArchiveAccess = x.archivePermissions.includes('Temporary Archive Access');
    this.roleMapping.canViewSwiftEngagementDetails = x.archivePermissions.includes('View Swift EngagementDetails');
    this.roleMapping.canMarkRestrictedAccess = x.archivePermissions.includes('Mark with restricted access');
    this.roleMapping.canChangeEstimatedReleaseDate = x.archivePermissions.includes('Change Estimated Release Date');
    // }
    console.log(this.roleMapping);
    // this.ViewSwiftEngagementDetailsEvent.emit({
    //   canChangeEstimatedReleaseDate: this.roleMapping.canChangeEstimatedReleaseDate, canViewSwiftEngagementDetails: this.roleMapping.canViewSwiftEngagementDetails,
    //   canRequestLegalHold: this.roleMapping.canRequestLegalHold, canRequestArchiveDeletion: this.roleMapping.canRequestArchiveDeletion, canRequestForm3283S: this.roleMapping.canRequestForm3283S, canApproveForm3283S: this.roleMapping.canApproveForm3283S
    // });
    // localStorage.setItem('roleMapping', JSON.stringify(this.roleMapping));
    this.pubsub.setRoleMappingResult(this.roleMapping);
    // });
  }
}
