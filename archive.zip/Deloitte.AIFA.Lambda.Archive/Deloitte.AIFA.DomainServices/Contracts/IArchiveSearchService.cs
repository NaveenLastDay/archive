﻿using Deloitte.AIFA.DomainEntities;
using System.Collections.Generic;

namespace Deloitte.AIFA.DomainServices.Contracts
{
    public interface IArchiveSearchService
    {
        List<SearchOptions> SearchByCategory(string Search, string CategoryType);
    }
}
