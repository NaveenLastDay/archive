﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;

namespace Deloitte.AIFA.Helpers.ExcelGenerator
{
    public class XlsxSheetToGenerate
    {
        public PropertyInfo[] Properties { get; set; }

        public List<IDataForSheet> DataSource { get; set; }

        public string SheetName { get; set; }
    }

}
