import { ArchiveService } from './../../../services/archive.service';
import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { JsonPipe } from '@angular/common';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { NgxSpinnerService } from 'ngx-spinner';
import { NotifierService, NotifierModule, NotifierOptions } from "angular-notifier";
import { UserConfigSettingService } from '../../../guards/user-role-guard.service';

@Component({
  // selector: 'app-my-archives',
  templateUrl: './my-archives.component.html',
  styleUrls: ['./my-archives.component.css']
})
export class MyArchivesComponent implements OnInit {

  currentUrl: string;

  employeeUniqueIdentifier: string;
  archiveNumber: string = '';
  eventType: string = '';
  myArchives: any[];
  myArchivesFilterData: any[];
  hoverIndex: number = -1;
  periodEndToolTip: string = "";
  sortByEnum: any = MyArchivesSortBy;
  filterByEnum: any = MyArchivesFilterBy;
  currentPageNumber: number = 1;
  totalArchivesAssigned: number = 0;
   pageSize: number = 10;
  pageCount: number = 1;
  pageArray = Array();
  appendArchivesGrid: boolean = false;
  //sortBy: number = this.sortByEnum.SortBy_EmployeeLastArchive;
  sortBy: number = this.sortByEnum.SortBy_ArchiveName_Asc;
  filterBy: number = this.filterByEnum.FilterBy_ArchiveType;
  filterText: string = "";
  displayingRecordsFrom: number = 0;
  displayingRecordsTo: number = 0;
  userConfig: any;
  constructor(private router: Router,private _userConfig:UserConfigSettingService, private archiveService: ArchiveService, private adalSvc: MsAdalAngular6Service,
    private SpinnerService: NgxSpinnerService, private notifier: NotifierService) {
    router.events.subscribe((_: NavigationEnd) => this.currentUrl = this.router.url);
  }

  ngOnInit() {
    let element4 = document.getElementById("customBreadcrumb");
    element4.classList.remove("custom-breadcrumb");
    console.log(this.pageArray);
    this.employeeUniqueIdentifier = this.adalSvc.LoggedInUserEmail.split('@')[0];
    this.userConfig = this._userConfig.FetchLoggedInUser(this.employeeUniqueIdentifier);
    localStorage['isERPSectionVisitedinOpenBySubmitter']=0;
    localStorage['IsSectionVisited']=0;
    localStorage['archiveInfoData']='';
    console.log("LocalStorage Reset to 0 in My Archives (54):",localStorage['IsSectionVisited']);
    // localStorage['isFirstLevelEdited']="null";
    this.getMyArchives();
  }

  redirectToWorkingPapers(archiveNumber: string) {
    this.router.navigate(["/record/workingpapers/" + archiveNumber]);
  }

  redirectToCreatArchive(PageUrl: string) {
    this.router.navigate(["/" + PageUrl + ""]);
  }
  redirectToAppropriatePage(archiveNumber:string, wbsNumber?:string, isArchiveCompleted?:boolean){
    localStorage.setItem('WBS_Number', wbsNumber);
    localStorage.setItem('isAutoCreatedArchive', isArchiveCompleted.toString());
    if(isArchiveCompleted)
    this.router.navigate(["/archive/myarchives/"+ archiveNumber]);
    else{
    this.router.navigate(["/archive/myarchives/"+ archiveNumber +"/createarchive/"+ wbsNumber]);
    }
  }
  showArchiveDetails(archiveNumber, index) {
    if (this.archiveNumber == archiveNumber) {
      this.archiveNumber = '';
      this.eventType = ''

    }
    else {
      this.archiveNumber = archiveNumber;
      this.eventType = 'select';

    }
  }

  mouseOver(event: any, index: number) {
    this.hoverIndex = index;
    //event.stopPropagation();
  }

  mouseOut(event: any) {
    let name: string = '';
    let present: number = -1;

    name = event.toElement ? event.toElement.getAttribute('name') : '';
    present = name ? name.search("AccessArchiveTop") : -1;

    if (event.toElement && present == -1 && (event.toElement["tagName"] != 'td' || event.toElement.className == 'trMyArchivesGridHeadFont')) {
      this.hoverIndex = -1;
    }
  }

  changePage(event, requestedPage: any) {


    if (isNaN(requestedPage) || requestedPage < 1 || requestedPage > this.pageCount) {
      this.notifier.notify("error", "Invalid page number.");
      return false;
    }
    this.currentPageNumber = parseInt(requestedPage);
    this.getMyArchives();

  }

  jumpToNextPage() {
    console.log('jumpToNextPage');

    if (this.currentPageNumber < this.pageArray.length) {
      this.currentPageNumber++;
      this.getMyArchives();
    }

  }

  jumpToPreviousPage() {
    console.log('jumpToPreviousPage');

    if (this.currentPageNumber > 1) {
      this.currentPageNumber--;
      this.getMyArchives();
    }
  }

  jumpToStartPage() {
    console.log('jumpToStartPage');
    // this.currentPageNumber = this.pageArray[0];
    this.currentPageNumber = 1;
    this.getMyArchives();
  }

  jumToEndPage() {
    console.log('jumToEndPage');
    //this.currentPageNumber = this.pageArray[this.pageArray.length-1];
    this.currentPageNumber = this.pageArray[this.pageArray.length - 1];
    this.getMyArchives();
  }

  calculatePageCount() {
    let possiblePages: number;

    if (this.myArchives && this.myArchives.length > 0) {
      let possiblePages = Math.ceil(parseInt(this.myArchives[0]["count"]) / this.pageSize);
      this.pageCount = possiblePages;
      this.pageArray = Array(this.pageCount).fill(0).map((e, i) => i + 1);
      this.totalArchivesAssigned = this.myArchives[0]["count"];
      this.displayingRecordsFrom = this.myArchives[0]["rowNumber"];
      this.displayingRecordsTo = this.myArchives[this.myArchives.length - 1]["rowNumber"];

      // this.displayingRecordsFrom  = this.pageSize * (this.currentPageNumber-1) + 1;
      // this.displayingRecordsTo = this.displayingRecordsFrom + this.pageSize - 1;
    }
    else {
      this.clearPageCount();
    }
  }

  getMyArchives() {
    this.archiveService.GetMyArchives(this.employeeUniqueIdentifier, this.currentPageNumber, this.pageSize, this.sortBy, this.filterBy, this.filterText).subscribe(
      data => {
        // added by satish
        if (this.appendArchivesGrid && data) {
          this.myArchives = this.myArchives.concat(data);
        }
        else {
          this.myArchives = data ? data : [];
        }

        if (this.myArchives.length > 0) {
          this.totalArchivesAssigned = this.myArchives[0]["count"];
        }
        else {
          this.totalArchivesAssigned = 0;
        }
      }
    );
  }

  updateGridData(event) {
    this.appendArchivesGrid = event.isLoadMoreClicked;
    this.currentPageNumber = event.pageNumber;
    this.getMyArchives();
  }

  clearPageCount() {
    this.currentPageNumber = 1;
    this.pageCount = 1;
    this.pageArray = Array();
  }

  sortOrderChanged(event) {
    //// debugger;
    this.resetPage();
    this.sortBy = event["sortBy"];
    this.getMyArchives();
  }
  resetPage(){
    this.appendArchivesGrid = false;
    this.currentPageNumber=1;
    this.pageSize=10;
    this.totalArchivesAssigned = 0;
  }

  onFilterChangeEvent(event) {
    //// debugger;

    this.resetPage();

    if (event["filterText"] == "0") {
      this.filterBy = 0;
      this.filterText = "";
    }
    else {
      this.filterBy = event["filterBy"];
      this.filterText = event["filterText"];
    }
    this.getMyArchives();
  }
}

export enum MyArchivesSortBy {
  SortBy_EmployeeLastArchive = 1,
  SortBy_ArchiveName_Asc = 2,
  SortBy_ArchiveName_Desc = 3,
  SortBy_ClientName_Asc = 4,
  SortBy_ClientName_Desc = 5,
  SortBy_PeriodEnd_Asc = 6,
  SortBy_PeriodEnd_Desc = 7,
  SortBy_ArchiveStatus_Asc = 8,
  SortBy_ArchiveStatus_Desc = 9,
  SortBy_WBSNumber_Asc = 10,
  SortBy_WBSNumber_Desc = 11,
  SortBy_ArchiveNumber_Asc = 12,
  SortBy_ArchiveNumber_Desc = 13,
}

export enum MyArchivesFilterBy {
  FilterBy_Business = 1,
  FilterBy_ClientName = 2,
  FilterBy_WBS = 3,
  FilterBy_Status = 4,
  FilterBy_ArchiveType = 5,
}
