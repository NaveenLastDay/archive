import { Component, OnInit, Input } from '@angular/core';
import { FormGroup, FormBuilder, FormArray, Validators } from '@angular/forms';
import { FaceSetSearchService } from '../../../services/facesetSearch.service';
import { SearchEventService } from '../search.event.service';
import { HomePageService } from '../../../services/homepage.service';
import { MatAutocompleteTrigger, MatDatepickerInputEvent } from '@angular/material';
import { DatePipe } from '@angular/common';
import { NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';

@Component({
    selector: 'archive-facet-search',
    templateUrl: './archive-facet-search.component.html',
    styleUrls: ['./archive-facet-search.component.css']
})
export class ArchivesFacetSearchComponent implements OnInit  {

    archiveSearchFormGroup: FormGroup;
    clientData = [];
    WBSData = [];
    BusinessData = []; ArchivedescriptionData = [];
    ProfessionalStandard=[];
    TypeData = [];
    EntityType=[];
    ArchiveStatus=[];
    EngagementType=[];
    TeamMember=[];
    advancefilter: boolean = true;
    labeltextfrom: string = 'From';
    labeltextto: string = 'To';
    @Input() indexValue: number;
    startDate: string;
    toDate: string;
    Displaydate: NgbDateStruct;
    searchEventService : SearchEventService;
    Date : any;
    maxDate: any;
  minDate: any;
  selectedday: string;
  selectedmonth: string;
    constructor(private fb: FormBuilder, private faceSetSearchService: FaceSetSearchService, 
        private searchEveSrvc: SearchEventService,private homeService:HomePageService,private datePipe: DatePipe) {
          this.searchEventService = searchEveSrvc;
    }
    selectedItems : any;
    errormessage:boolean=false;
    errormessagerange:boolean=false;
    ngOnInit() {
        this.homeService.advanceSearchBtnDisable=false;
        this.searchEventService.rebindFacetComponents.subscribe(
            data => {
                this.clientData = this.searchEventService.clientDataArray;
                this.WBSData = this.searchEventService.WBSDataArray;
                this.BusinessData = this.searchEventService.BusinessDataArray;
                this.TypeData = this.searchEventService.TypeDataArray;
                this.ArchivedescriptionData = this.searchEventService.ArchivedescriptionDataArray;
                this.ProfessionalStandard=this.searchEventService.ProfessionalstandardsDataArray;
                this.EngagementType=this.searchEventService.EngagementtypeDataArray;
                this.EntityType=this.searchEventService.TypeofentityDataArray;
                this.ArchiveStatus=this.searchEventService.ArchiveStatusDataArray;   
                this.TeamMember=
                this.searchEventService.AddArchvieFieldSeniorDataArray.concat(
                (this.searchEventService.ArchvieFieldSeniorDataArray.concat(
                (this.searchEventService.ArchiveManagerDataArray.concat(this.searchEventService.ArchivePartnerDataArray.
                  filter(value => !this.searchEventService.ArchiveStatusDataArray.includes(value)))).
                  filter(value=>!this.searchEventService.ArchvieFieldSeniorDataArray.includes(value))))
                  .filter(value=>!this.searchEventService.AddArchvieFieldSeniorDataArray.includes(value)))    
            });
      this.searchEventService.clearFacets.subscribe(data=>{
        this.searchEventService.periodStartDate = '';
        this.searchEventService.periodEndDate = '';
      });
    }

  
  //Period End
  //When Period End From date Selected
  fromSelectedDate(datevalue) {
    //debugger;
    if(typeof datevalue != "string") {
      this.minDate = datevalue; 
    (datevalue.day.toString().length == 1) ? this.selectedday = '0'+datevalue.day : this.selectedday = datevalue.day;
    (datevalue.month.toString().length == 1) ? this.selectedmonth = '0'+datevalue.month : this.selectedmonth = datevalue.month;
    datevalue = this.selectedmonth+'/'+this.selectedday+'/'+datevalue.year;
    }
    var datef= /(0[1-9]|1[012])[- /.](0[1-9]|[12][0-9]|3[01])[- /.](19|20)\d\d/;
    this.searchEventService.startDate=datevalue;
    var match=datevalue.match(datef);
    var match1=this.searchEventService.toDate.match(datef);
    this.searchEventService.errormessage=false;
    this.searchEventService.errormessagerange=false;
    this.searchEventService.periodEndStartDateCustomRule = this.searchEventService.periodEndStartDateCustomRule=="" ?  this.searchEventService.finalSelectedJson.rules['periodEndDate'][0].StartDate : this.searchEventService.periodEndStartDateCustomRule;
    if(match!=null)
    {
      var date = this.datePipe.transform(datevalue, "yyyy-MM-dd");
      this.searchEventService.periodStartDate=date;
    }
    if( match!=null&&match1!=null)
    {  
     var index = this.searchEventService.finalSelectedJson.rules.periodEndDate.findIndex(x =>x.StartDate != undefined);
    if (index > -1) {
      this.searchEventService.finalSelectedJson.rules.periodEndDate.splice(index,1);
    }
    
    if( this.searchEventService.periodStartDate && this.searchEventService.periodEndDate ){
      this.searchEventService.finalSelectedJson.rules.periodEndDate.push({
        StartDate:  this.searchEventService.periodStartDate,
        EndDate: this.searchEventService.periodEndDate
      });
      let date1= new Date(this.searchEventService.periodStartDate);
        let date2= new Date(this.searchEventService.periodEndDate);
        if(date1<=date2 )
        {
          this.searchEventService.errormessagerange=false;
          this.searchEventService.errormessage=false;
          if(this.searchEventService.facetcounter==1 )
          this.searchEventService.selectedFacetsCount--;
          this.searchEventService.selectedFacetsCount++;
          this.searchEventService.facetcounter=1;
        this.searchEventService.onTriggerAdvanceSearch();
        
        }
        else
        {
          if(!this.searchEventService.errormessagerange)
          this.searchEventService.errormessagerange=true;
        }
        
  }
  
}
else
if(this.searchEventService.startDate!='' && this.searchEventService.toDate!='') 
    this.searchEventService.errormessage=true;
    

  }
  //When Period End To date Selected
  toSelectedDate(datevalue) {
    //debugger;
     if(typeof datevalue != "string") {
      this.maxDate = datevalue;
      (datevalue.day.toString().length == 1) ? this.selectedday = '0'+datevalue.day : this.selectedday = datevalue.day;
     (datevalue.month.toString().length == 1) ? this.selectedmonth = '0'+datevalue.month : this.selectedmonth = datevalue.month;
     datevalue = this.selectedmonth+'/'+this.selectedday+'/'+datevalue.year;
    }
    var datef= /(0[1-9]|1[012])[- /.](0[1-9]|[12][0-9]|3[01])[- /.](19|20)\d\d/;
    this.searchEventService.toDate=datevalue;
    var match=datevalue.match(datef);
    var match1=this.searchEventService.startDate.match(datef);
    this.searchEventService.errormessage=false;
    this.searchEventService.errormessagerange=false;
    this.searchEventService.periodEndToDateCustomRule = this.searchEventService.periodEndToDateCustomRule =="" ? this.searchEventService.finalSelectedJson.rules['periodEndDate'][0].EndDate : this.searchEventService.periodEndToDateCustomRule;
    if(match!=null)
    {
    var date = this.datePipe.transform(datevalue, "yyyy-MM-dd");
    this.searchEventService.periodEndDate=date;
    }
    if( match!=null && match1!=null)
    {  
    var index = this.searchEventService.finalSelectedJson.rules.periodEndDate.findIndex(x =>x.EndDate != undefined);
    if (index > -1) {
      this.searchEventService.finalSelectedJson.rules.periodEndDate.splice(index,1);
    }
    
      if(  this.searchEventService.periodStartDate && this.searchEventService.periodEndDate){
        this.searchEventService.finalSelectedJson.rules.periodEndDate.push({
          StartDate:   this.searchEventService.periodStartDate,
          EndDate:  this.searchEventService.periodEndDate
        });
        this.searchEventService.facesetJson.push({
          field: 'periodEndDate',
          value: {
            StartDate:   this.searchEventService.periodStartDate,
            EndDate:  this.searchEventService.periodEndDate
          }
      });
      
        let date1= new Date( this.searchEventService.periodStartDate);
        let date2= new Date(this.searchEventService.periodEndDate);
        if(date1<=date2)
        {
          this.searchEventService.errormessagerange=false;
          this.searchEventService.errormessage=false;
          if(this.searchEventService.facetcounter==1)
         this.searchEventService.selectedFacetsCount--;
          this.searchEventService.facetcounter=1;
          this.searchEventService.selectedFacetsCount++;
        this.searchEventService.onTriggerAdvanceSearch();
        }
        else
        {
          if(!this.searchEventService.errormessagerange)
          this.searchEventService.errormessagerange=true;
        }
    }
   
  }
    else 
    if(this.searchEventService.startDate!='' && this.searchEventService.toDate!='')
    this.searchEventService.errormessage=true;

    // console.log(this.searchEventService.finalSelectedJson);
   
  }

}