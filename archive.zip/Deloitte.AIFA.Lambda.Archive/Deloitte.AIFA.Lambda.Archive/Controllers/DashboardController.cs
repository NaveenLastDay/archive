﻿using Deloitte.AIFA.DomainServices.Contracts;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Deloitte.AIFA.DomainEntities;
using Deloitte.AIFA.PushMessageSNSHelper;
using System;
using Deloitte.AIFA.DomainEntities.Report;
using Deloitte.AIFA.Helpers.ExcelGenerator;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Primitives;
using Deloitte.AIFA.CloudServices;
using Deloitte.AIFA.DataModels;
using System.Collections.Generic;
using System.Linq;
using Deloitte.AIFA.IMessageServices.Contracts;
using Amazon.Lambda.Core;
using Amazon.Lambda.APIGatewayEvents;


namespace Deloitte.AIFA.Lambda.Archive.Controllers
{
    [Route("api/dashboard")]
    [ApiController]
    public class DashboardController : ControllerBase
    {
        IDashBoardService _dashboardService;       
        
        ILogger _logger { get; set; }
        private readonly IHttpContextAccessor _contextAccessor;
        private string userAlias;

        public DashboardController(IHttpContextAccessor contextAccessor, IDashBoardService dashboardService, ILogger<DashboardController> logger)
        {
            _logger = logger;
            _dashboardService = dashboardService;
            _logger.LogInformation("DashBoard Controller Initiated");
            this._contextAccessor = contextAccessor;

            //Environment.GetEnvironmentVariable("stagingbucketname");
            try
            {
                LambdaLogger.Log("Inside Dashboard Controller");
                var _context = this._contextAccessor.HttpContext;
                try
                {
                    if (_context?.User?.Claims.Any() == true)
                    {
                        LambdaLogger.Log("Has claims in Dashboard Controller");
                        foreach (var claim in _context?.User?.Claims)
                        {
                            //LambdaLogger.Log(claim.Type);
                            if (claim.Type == "UserAlias")
                            {
                                userAlias = claim.Value.Split('@')[0].ToString();
                            }
                            LambdaLogger.Log("User Alias from DashboardController," + userAlias);
                        }
                    }
                    else
                    {
                        LambdaLogger.Log("Has No claims");
                    }
                }
                catch (Exception ex)
                {
                    LambdaLogger.Log("Error with Http context in Dashboard controller: " + ex.Message);
                }
            }
            catch (Exception e)
            {
                LambdaLogger.Log("Error in Dashboard controller: " + e.Message);
            }

        }

        [HttpGet]
        [Route("GetUserDashBoardData")]
        public IActionResult GetUserDashBoardData()
        {
            //Dashboard details

            var dashboardDetail = _dashboardService.GetUserDashboardData(userAlias);
            _logger.LogInformation("GetUserDashBoardDetails: " + userAlias);
            _logger.LogInformation("GetUserDashBoardDetails: " + dashboardDetail);
            return Ok(dashboardDetail);
        }

        [HttpGet]
        [Route("getmyform3283dashboarddata")]
        public IActionResult GetMyForm3283DashBoardData(int pageNumber,int pagesize)
        {
            //Dashboard details
            _logger.LogInformation("GetForm3283DashBoardData for : " + userAlias);

            var dashboardDetail = _dashboardService.GetForm3283DashBoardData(userAlias,pageNumber,pagesize);
           
            _logger.LogInformation("GetForm3283DashBoardData: " + dashboardDetail);
            return Ok(dashboardDetail);
        }

        [HttpGet]
        [Route("getmycompliancemetrics")]
        public IActionResult GetMyComplianceMetrics(int pageNumber, int pagesize,int sortBy,string filterText)
        {
            //Dashboard details
            _logger.LogInformation("GetMyComplianceMetrics for : " + userAlias);

            var dashboardDetail = _dashboardService.GetComplianceMetrics(userAlias, pageNumber, pagesize,sortBy,filterText);

            _logger.LogInformation("GetMyComplianceMetrics: " + dashboardDetail);
            return Ok(dashboardDetail);
        }
        [HttpGet]
        [Route("getmyawaitingapprovaldashboarddata")]
        public IActionResult GetMyAwaitingApprovalDashBoardData(int pageNumber, int pagesize)
        {
            //Dashboard details
            _logger.LogInformation("GetMyAwaitingApprovalDashBoardData for : " + userAlias);

            var dashboardDetail = _dashboardService.GetMyAwaitingApprovalDashBoardData(userAlias, pageNumber, pagesize);

            _logger.LogInformation("GetMyAwaitingApprovalDashBoardData: " + dashboardDetail);
            return Ok(dashboardDetail);
        }

        [HttpGet]
        [Route("getarchivedeletionsdashboarddata")]
        public IActionResult GetArchiveDeletionsDashBoardData(int pageNumber, int pagesize)
        {
            //Dashboard details
            _logger.LogInformation("GetArchiveDeletionsDashBoardData for : " + userAlias);

            var dashboardDetail = _dashboardService.GetArchiveDeletionsDashBoardData(userAlias, pageNumber, pagesize);

            _logger.LogInformation("GetArchiveDeletionsDashBoardData: " + dashboardDetail);
            return Ok(dashboardDetail);
        }

        [HttpGet]
        [Route("getmyawaitingsubmissiondashboarddata")]
        public IActionResult GetMyAwaitingSubmissionDashBoardData(int pageNumber, int pagesize)
        {
            //Dashboard details
            _logger.LogInformation("GetMyAwaitingApprovalDashBoardData for : " + userAlias);

            var dashboardDetail = _dashboardService.GetMyAwaitingSubmissionDashBoardData(userAlias, pageNumber, pagesize);

            _logger.LogInformation("GetMyAwaitingApprovalDashBoardData: " + dashboardDetail);
            return Ok(dashboardDetail);
        }

        [HttpGet]
        [Route("getmyrequiringapprovaldashboarddata")]
        public IActionResult GetMyRequiringApprovalDashBoardData(int pageNumber, int pagesize)
        {
            //Dashboard details
            _logger.LogInformation("GetMyRequiringSubmissionDashBoardData for : " + userAlias);

            var dashboardDetail = _dashboardService.GetMyRequiringApprovalDashBoardData(userAlias, pageNumber, pagesize);

            _logger.LogInformation("GetMyAwaitingApprovalDashBoardData: " + dashboardDetail);
            return Ok(dashboardDetail);
        }
    }
}