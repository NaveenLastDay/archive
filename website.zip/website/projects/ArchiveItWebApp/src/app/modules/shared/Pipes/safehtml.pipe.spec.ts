import { SafeHtmlPipe } from '../Pipes/safehtml.pipe';
import {DomSanitizer} from "@angular/platform-browser";
import { TestBed, async } from '@angular/core/testing';


describe('SafehtmlPipe', () => {

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      providers: [
        {
          provide: DomSanitizer}]
    })
    .compileComponents();
  }));

  
  it('create an instance', () => {  
    const pipe = new SafeHtmlPipe();
    expect(pipe).toBeTruthy();
  });
});
