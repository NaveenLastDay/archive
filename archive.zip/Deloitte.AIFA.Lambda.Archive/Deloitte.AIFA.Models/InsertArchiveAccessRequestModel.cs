﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DataModels
{
    public class InsertArchiveAccessRequestModel
    {
        public string Message { get; set; }
        public string RequestedByName { get; set; }
        public string RequestedOfName { get; set; }

    }
}
