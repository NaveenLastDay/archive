﻿using Amazon.Lambda.Core;
using Deloitte.AIFA.DomainEntities;
using Deloitte.AIFA.ICloudServices;
using Microsoft.Extensions.Configuration;
using StackExchange.Redis;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Deloitte.AIFA.CloudServices
{
    public class CloudCacheService : ICloudCacheService
    {
        IConfiguration _configuration;
        IConfigManager _secretManager;

        private readonly IConnectionMultiplexer _connectionMultiplexer;

        public CloudCacheService(IConfiguration configuration, IConfigManager secretManager)
        {
            try
            {
                _configuration = configuration;
                _secretManager = secretManager;

                var host = _configuration["rediscacheendpointkey"];
                var password = _secretManager.GetCacheSecretValueByKey("cachesharedsecretkey");

                LambdaLogger.Log("CloudCacheService host: " + host);

                ConfigurationOptions options = ConfigurationOptions.Parse(host + ":6379");
                options.AllowAdmin = true;
                options.Password = password;
                options.Ssl = true;

                _connectionMultiplexer = ConnectionMultiplexer.Connect(options);

                if (_connectionMultiplexer != null)
                {
                    LambdaLogger.Log("CloudCacheService connected successfully");
                }
            }
            catch (Exception ex)
            {
                LambdaLogger.Log("CloudCacheService error at constructor: " + ex.StackTrace);
                throw ex;
            }

            LambdaLogger.Log("CloudCacheService Initiated");
        }

        public bool SetValue(CacheRequestModel request)
        {
            LambdaLogger.Log("CloudCacheServiceSetValueKey " + request.Key);
            LambdaLogger.Log("CloudCacheServiceSetValueKey " + request.Value);

            try
            {
                var db = _connectionMultiplexer.GetDatabase();
                return db.StringSetAsync(request.Key, request.Value).Result;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public string GetValue(CacheRequestModel request)
        {
            try
            {
                var db = _connectionMultiplexer.GetDatabase();
                var result = db.StringGetAsync(request.Key).Result;

                LambdaLogger.Log("CloudCacheServiceGetValueresult " + result);

                return result;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public bool RemoveValue(CacheRequestModel request)
        {
            try
            {
                var db = _connectionMultiplexer.GetDatabase();
                return db.KeyDeleteAsync(request.Key).Result;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public List<CacheRequestModel> GetAll()
        {
            try
            {
                List<CacheRequestModel> cacheItems = new List<CacheRequestModel>();

                System.Net.EndPoint endPoint = _connectionMultiplexer.GetEndPoints().First();
                RedisKey[] keys = _connectionMultiplexer.GetServer(endPoint).Keys(pattern: "*").ToArray();

                foreach (var key in keys)
                {
                    LambdaLogger.Log("RemoveStackExchangeKey " + key.ToString());

                    cacheItems.Add(new CacheRequestModel()
                    {
                        Key = key,
                        Value = GetValue(new CacheRequestModel() { Key = key.ToString() })
                    });
                }

                return cacheItems;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public bool RemoveAll()
        {
            LambdaLogger.Log("removeallservice");
            try
            {
                List<CacheRequestModel> cacheItems = new List<CacheRequestModel>();

                System.Net.EndPoint endPoint = _connectionMultiplexer.GetEndPoints().First();
                RedisKey[] keys = _connectionMultiplexer.GetServer(endPoint).Keys(pattern: "*").ToArray();
                LambdaLogger.Log("removeallget keys");

                foreach (var key in keys)
                {
                    LambdaLogger.Log("RemoveStackExchangeKey " + key.ToString());
                    RemoveValue(new CacheRequestModel() { Key = key });
                }

                return true;
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
