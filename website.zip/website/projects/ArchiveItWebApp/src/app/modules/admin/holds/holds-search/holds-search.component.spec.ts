import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HoldsSearchComponent } from './holds-search.component';

describe('HoldsSearchComponent', () => {
  let component: HoldsSearchComponent;
  let fixture: ComponentFixture<HoldsSearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HoldsSearchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HoldsSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
