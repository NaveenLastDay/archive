﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.Models
{
    public class DistributionListModel
    {
        //public int DistributionListID { get; set; }
        public int? SubmissionPackageID { get; set; }
        //public int PersonnelNumber { get; set; }
        public bool IsManualSubmission { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string DeletedBy { get; set; }
        public DateTime DeletedDate { get; set; }

        public string Personnels { get; set; }
        public int? TotalPersonnelsProcessed { get; set; }
        public string ArchiveNumber { get; set; }
        public string EngagementPersonnel { get; set; }
    }
}
