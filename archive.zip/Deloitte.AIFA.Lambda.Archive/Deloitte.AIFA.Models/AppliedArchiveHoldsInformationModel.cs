﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.Models
{
    public class AppliedArchiveHoldsInformationModel
    {
        public string ClientName { get; set; }
        public string ArchiveNumber { get; set; }
        public string Business { get; set; }
        public DateTime? PeriodEndDate { get; set; }
        public DateTime? EffectiveStartDate { get; set; }
        public DateTime? EffectiveEndDate { get; set; }
        public string Status { get; set; }
        public string ArchiveName { get; set; }
        public string RecordDescription { get; set; }
        public int Count { get; set; }
    }
}
