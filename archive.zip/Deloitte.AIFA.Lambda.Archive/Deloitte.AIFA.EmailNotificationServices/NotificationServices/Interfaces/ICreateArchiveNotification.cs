﻿using Deloitte.AIFA.DomainEntities;
using Deloitte.AIFA.DomainEntities.EmailEntities;
using Deloitte.AIFA.EmailNotificationServices.NotificationEntities;
using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.EmailNotificationServices.NotificationServices.Interfaces
{
    interface ICreateArchiveNotification
    {
        BaseEmailEntity CreateArchiveManual_Notification(string argOperationType, string argOperationDescription, string argTemplateId, string ArchiveNumber,string WBSNumber,string CreatedBy);
        BaseEmailEntity SetUpAutoArchive_Notification(string argOperationType, string argOperationDescription, string argTemplateId, string ArchiveNumber,string WBSNumber,string ClientName, string EDCD, string additionalOrgs);
      
    }
}
