﻿using Deloitte.AIFA.DomainEntities;
using System.Collections.Generic;

namespace Deloitte.AIFA.IRepositories
{
    public interface IArchiveFolderRepository
    {
        List<ArchiveFolder> GetArchiveFolders(ArchiveFolder archiveFolder);
    }
}
