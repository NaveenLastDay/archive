﻿using System;
using System.Collections.Generic;
using System.Text;
using Deloitte.AIFA.IRepositories;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Microsoft.Extensions.Logging;
using Deloitte.AIFA.DomainServices.Services;
using Deloitte.AIFA.DomainEntities;
using Deloitte.AIFA.EmailNotificationServices;
//using Microsoft.Extensions.Caching.Memory;

namespace Deloitte.AIFA.DomainServices.Tests
{
    [TestClass]
    public class ArchiveServiceTestCases
    {
        private static readonly Mock<IArchiveRepository> _archiveRepository = new Mock<IArchiveRepository>();
        private static readonly Mock<ILogger<ArchiveService>> _logger = new Mock<ILogger<ArchiveService>>();
        private static readonly Mock<EmailNotificationService> _email = new Mock<EmailNotificationService>();
        private static ArchiveService _archiveservice = new ArchiveService(null, null, _archiveRepository.Object, _logger.Object, _email.Object,null);


        [TestMethod]
        public void ArchiveDueDate_Success()
        {
            ArchiveDueDateEngine result = new ArchiveDueDateEngine();
            string ArchiveNumber = "AEA501457";
            string UserAlias = "guspandana";
            _archiveRepository.Setup(x => x.GetArchiveDueDateCriteria(ArchiveNumber, UserAlias)).Returns(result);
            var actual = _archiveservice.GetArchiveDueDateCriteria(ArchiveNumber, UserAlias);

            Assert.IsNotNull(actual);
            Assert.AreEqual(actual.GetType(), typeof(ArchiveDueDateEngine));

        }

        [TestMethod]
        public void ArchiveDueDate_invalidinput()
        {
            ArchiveDueDateEngine result = new ArchiveDueDateEngine();
            string ArchiveNumber = "AEA501460";
            string UserAlias = "guspand";
            _archiveRepository.Setup(x => x.GetArchiveDueDateCriteria(ArchiveNumber, UserAlias)).Returns(result);
            var actual = _archiveservice.GetArchiveDueDateCriteria(ArchiveNumber, UserAlias);

            Assert.IsNotNull(actual);
            Assert.AreEqual(actual.GetType(), typeof(ArchiveDueDateEngine));

        }
        [TestMethod]
        public void GetEngagementTypes_success()
        {
            List<EngagementType> result = new List<EngagementType>();
            _archiveRepository.Setup(x => x.GetEngagementType()).Returns(result);
            var actual = _archiveservice.GetEngagementType();

            Assert.IsNotNull(actual);
            Assert.AreEqual(actual.GetType(), typeof(List<EngagementType>));

        }

        [TestMethod]
        public void GetArchiveTypes_success()
        {
            List<ArchiveType> result = new List<ArchiveType>();
            _archiveRepository.Setup(x => x.GetArchiveType()).Returns(result);
            var actual = _archiveservice.GetArchiveType();

            Assert.IsNotNull(actual);
            Assert.AreEqual(actual.GetType(), typeof(List<ArchiveType>));

        }

        [TestMethod]
        public void GetEntityTypes_success()
        {
            List<EntityType> result = new List<EntityType>();
            _archiveRepository.Setup(x => x.GetEntityType()).Returns(result);
            var actual = _archiveservice.GetEntityType();

            Assert.IsNotNull(actual);
            Assert.AreEqual(actual.GetType(), typeof(List<EntityType>));

        }
        [TestMethod]
        public void GetProfessionalStandard_success()
        {
            List<ProfessionalStandards> result = new List<ProfessionalStandards>();
            _archiveRepository.Setup(x => x.GetProfessionalStandard()).Returns(result);
            var actual = _archiveservice.GetProfessionalStandard();

            Assert.IsNotNull(actual);
            Assert.AreEqual(actual.GetType(), typeof(List<ProfessionalStandards>));

        }

        [TestMethod]
        public void GetRetentionReasons_success()
        {
            List<RetentionReason> result = new List<RetentionReason>();
            _archiveRepository.Setup(x => x.GetRetentionReasons()).Returns(result);
            var actual = _archiveservice.GetRetentionReasons();

            Assert.IsNotNull(actual);
            Assert.AreEqual(actual.GetType(), typeof(List<RetentionReason>));

        }

        [TestMethod]
        public void GetActiveRoles_validinput()
        {
            List<ActiveRoles> result = new List<ActiveRoles>();
            string ArchiveNumber = "AEA501460";
            _archiveRepository.Setup(x => x.GetActiveRoles(ArchiveNumber)).Returns(result);
            var actual = _archiveservice.GetActiveRoles(ArchiveNumber);

            Assert.IsNotNull(actual);
            Assert.AreEqual(actual.GetType(), typeof(List<ActiveRoles>));

        }

        [TestMethod]
        public void GetArchiveTeamHistory_validinput()
        {
            List<ArchiveTeamHistory> result = new List<ArchiveTeamHistory>();
            string ArchiveNumber = "AEA501460";
            int PageNumber = 1;
            int PageSize = 10;
            int SortBy = 1;
            _archiveRepository.Setup(x => x.GetArchiveTeamHistory(ArchiveNumber, PageNumber, PageSize, SortBy)).Returns(result);
            var actual = _archiveservice.GetArchiveTeamHistory(ArchiveNumber, PageNumber, PageSize, SortBy);

            Assert.IsNotNull(actual);
            Assert.AreEqual(actual.GetType(), typeof(List<ArchiveTeamHistory>));

        }

        [TestMethod]
        public void GetSwiftEngagementInfo_validwbs()
        {
            ProjectMetaData result = new ProjectMetaData();
            string wbsLevelOne = "EDR10001-01";
            _archiveRepository.Setup(x => x.GetSwiftEngagementInfo(wbsLevelOne)).Returns(result);
            var actual = _archiveservice.GetSwiftEngagementInfo(wbsLevelOne);

            Assert.IsNotNull(actual);
            Assert.AreEqual(actual.GetType(), typeof(ProjectMetaData));

        }

        [TestMethod]
        public void GetSwiftEngagementInfo_Invalidwbs()
        {
            ProjectMetaData result = new ProjectMetaData();
            string wbsLevelOne = "ABCD";
            _archiveRepository.Setup(x => x.GetSwiftEngagementInfo(wbsLevelOne)).Returns(result);
            var actual = _archiveservice.GetSwiftEngagementInfo(wbsLevelOne);

            Assert.IsNotNull(actual);
            Assert.AreEqual(actual.GetType(), typeof(ProjectMetaData));

        }

        [TestMethod]
        public void CreateArchive_Validinput()
        {
            Assert.IsTrue(true, "CreateArchive_Validinput method start");
            Archive input = new Archive();
            Archive result = new Archive();
            input.ArchiveInfo = new ArchiveMetaData();
            input.WBSInfo = new ProjectMetaData();

            input.WBSLevelOneNumber = "EDR10001-01";

            input.WBSInfo.EngagementManager = "mpabballa";
            input.WBSInfo.SigningPartners = " ";
            input.WBSInfo.WBSEngagementPPMD = "thjerpe";

            input.ArchiveInfo.Createdby = "mpabballa";
            input.ArchiveInfo.PeriodEnd = Convert.ToDateTime("8/6/2020");
            input.ArchiveInfo.EstimatedDate = Convert.ToDateTime("8/16/2020");
            input.ArchiveInfo.ArchiveFieldSenior = "guspandana";
            input.ArchiveInfo.ArchiveType = "Mutual Fund";
            input.ArchiveInfo.Description = "Mutual Fund";
            input.ArchiveInfo.EngagementDesc = "test archive";
            input.ArchiveInfo.EngagementType = "Interim review – with report";
            input.ArchiveInfo.EntityType = "Public Non-SEC Filer";
            input.ArchiveInfo.ProfessionalStandard = "GAAS";


            _archiveRepository.Setup(x => x.CreateArchive(input)).Returns(result);
            var actual = _archiveservice.CreateArchive(input);

            Assert.IsNotNull(actual);
            Assert.IsTrue(actual!=null, "CreateArchive_Validinput method end");
        }

        [TestMethod]
        public void CreateArchive_Invalidinput()
        {
            Assert.IsTrue(true, "CreateArchive_Invalidinput method start");
            Archive input = new Archive();
            Archive result = new Archive();
            input.ArchiveInfo = new ArchiveMetaData();
            input.WBSInfo = new ProjectMetaData();

            input.WBSLevelOneNumber = "EDR10001-01";

            input.WBSInfo.EngagementManager = "mpabballa";
            input.WBSInfo.SigningPartners = " ";
            input.WBSInfo.WBSEngagementPPMD = "thjerpe";

            input.ArchiveInfo.Createdby = "mpabballa";
            input.ArchiveInfo.PeriodEnd = Convert.ToDateTime("8/6/2020");
            input.ArchiveInfo.EstimatedDate = Convert.ToDateTime("8/16/2020");
            input.ArchiveInfo.ArchiveFieldSenior = "guspandana";
            input.ArchiveInfo.ArchiveType = "Mutual Fund";
            input.ArchiveInfo.Description = "Mutual Fund";
            //input.ArchiveInfo.EngagementDesc = "test archive";
            input.ArchiveInfo.EngagementType = "Interim review – with report";
            input.ArchiveInfo.EntityType = "Public Non-SEC Filer";
            input.ArchiveInfo.ProfessionalStandard = "GAAS";


            _archiveRepository.Setup(x => x.CreateArchive(input)).Returns(result);
            var actual = _archiveservice.CreateArchive(input);

            Assert.IsNull(actual.ArchiveNumber);
            Assert.IsTrue(actual.ArchiveNumber==null, "CreateArchive_Invalidinput method end");
        }

        [TestMethod]
        public void GetArchiveHistory_validinput()
        {
            Assert.IsTrue(true, "GetArchiveHistory_validinput method start");
            List<ArchiveHistory> result = new List<ArchiveHistory>();
            string ArchiveNumber = "AEA501460";
            int PageNumber = 1;
            int PageSize = 10;
            int SortBy = 1;
            _archiveRepository.Setup(x => x.GetArchiveHistory(ArchiveNumber, PageNumber, PageSize, SortBy)).Returns(result);
            var actual = _archiveservice.GetArchiveHistory(ArchiveNumber, PageNumber, PageSize, SortBy);

            Assert.IsNotNull(actual);
            Assert.AreEqual(actual.GetType(), typeof(List<ArchiveHistory>));
            Assert.IsTrue(actual!=null, "GetArchiveHistory_validinput method end");
        }

        [TestMethod]
        public void GetArchiveHistory_Invalidinput()
        {
            Assert.IsTrue(true, "GetArchiveHistory_Invalidinput method start");
            List<ArchiveHistory> result = new List<ArchiveHistory>();
            string ArchiveNumber = "AEA500000";
            int PageNumber = 0;
            int PageSize = 10;
            int SortBy = 0;
            _archiveRepository.Setup(x => x.GetArchiveHistory(ArchiveNumber, PageNumber, PageSize, SortBy)).Returns(result);
            var actual = _archiveservice.GetArchiveHistory(ArchiveNumber, PageNumber, PageSize, SortBy);

            Assert.IsTrue(actual.Count<=0);
            Assert.AreEqual(actual.GetType(), typeof(List<ArchiveHistory>));
            Assert.IsTrue(true, "GetArchiveHistory_Invalidinput method end");
        }

        [TestMethod]
        public void UpdateArchiveTeam_success()
        {
            ArchiveTeamChangeDetailsData result = new ArchiveTeamChangeDetailsData();
            
            ArchiveTeam team = new ArchiveTeam()
            {
                ArchiveNumber = "AEA501452",
                ArchivePartner = "guspandana",
                ArchiveManager = "guspandana",
                ArchiveFieldSenior = "guspandana",
                AdditionalArchiveFieldSenior = "guspandana",
                SigningPartners = "guspandana",
                CreatedBy = "guspandana"
            };
            _archiveRepository.Setup(x => x.UpdateArchiveTeam(team,team.CreatedBy)).Returns(result);
            var actual = _archiveservice.UpdateArchiveTeam(team,team.CreatedBy);

            Assert.IsNotNull(actual);
            Assert.AreEqual(actual.GetType(), result.GetType());
        }

        [TestMethod]
        public void CreateArchiveSubmission_success()
        {
            ArchiveSubmission result = new ArchiveSubmission()
            {
                ArchiveStatus = "Ready For Approval"
            };
            ArchiveSubmission input = new ArchiveSubmission()
            {
                ArchiveNumber = "AEA501456",
                CreatedBy = "guspandana",
                PPDUserAlias = "dmukundapriya",
                EstimatedDate = Convert.ToDateTime("2020-08-24 18:30:00.000"),
                ArchiveStatus = "Open"
            };
            _archiveRepository.Setup(x => x.CreateArchiveSubmission(input)).Returns(result);
            var actual = _archiveservice.CreateArchiveSubmission(input);

            Assert.IsNotNull(actual);
            Assert.AreEqual(actual.GetType(), typeof(ArchiveSubmission));
        }

        [TestMethod]
        public void GetDateAndPeoplepickerstatus_success()
        {
            ArchiveSubmissionStatus result = new ArchiveSubmissionStatus()
            {
                ShowPeoplePicker = true,
                ShowDatePicker = true
            };
            string archiveNumber = "AEA501456";
            string userAlias = "guspandana";
            _archiveRepository.Setup(x => x.GetDateAndPeoplePickerStatus(archiveNumber, userAlias)).Returns(result);
            var actual = _archiveservice.GetDateAndPeoplePickerStatus(archiveNumber, userAlias);

            Assert.IsNotNull(actual);
            Assert.AreEqual(actual.GetType(), typeof(ArchiveSubmissionStatus));
        }

        [TestMethod]
        public void GetWorkingPaperStatus_success()
        {
            WorkingPapersStatus result = new WorkingPapersStatus();
            string archiveNumber = "AEA501456";
            string userAlias = "guspandana";
            _archiveRepository.Setup(x => x.GetWorkingPapersStatus(archiveNumber, userAlias)).Returns(result);
            var actual = _archiveservice.GetWorkingPapersStatus(archiveNumber, userAlias);

            Assert.IsNotNull(actual);
            Assert.AreEqual(actual.GetType(), typeof(WorkingPapersStatus));
        }
    }
}
