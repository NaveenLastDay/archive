﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DataModels
{
    public class DeliverablesStatusCheckModel
    {
        public string deliverabledescription { get; set; }
        public string createdBy { get; set; }
    }
}
