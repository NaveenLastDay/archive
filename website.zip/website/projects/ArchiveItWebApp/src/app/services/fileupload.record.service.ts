import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class FileUploadRecordService {
  data = [];
  apiData: any;
  APIData : any;
  constructor(private _http: HttpClient) { }
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'

    }),
  }

  public GetFileTypes(): Observable<any> {
    this.apiData = this._http.get<any>("record/GetFileTypes", this.httpOptions);
    return this.apiData;
  }

  public GetWorkingPapersByArchiveNumber(archiveNumber: string): Observable<any> {
    this.apiData = this._http.get<any>("record/GetWorkingPapersByArchiveNumber?ArchiveNumber=" + archiveNumber, this.httpOptions);
    return this.apiData;
  }

  public CreateOrUpdateWorkingPaper(parameters: any): Observable<any> {
    this.apiData = this._http.post<any>("record/CreateOrUpdateWorkingPaper" , parameters, this.httpOptions);
    return this.apiData;
  }

  public CreateOrUpdateEmsPackages(parameters: any): Observable<any> {
    this.apiData = this._http.post<any>("record/CreateOrUpdateEmsPackages" , parameters, this.httpOptions);
    return this.apiData;
  }  

  public CreateOrUpdateHolds(parameters: any): Observable<any> {
    this.apiData = this._http.post<any>("hold/CreateOrUpdateHolds" , parameters, this.httpOptions);
    return this.apiData;
  }

  public IsBatchJobTriggeredAsync(batchType:string,parameters: any): Observable<any> {
    this.apiData = this._http.post<any>("ems/isBatchJobTriggeredAsync?BatchType="+batchType, parameters, this.httpOptions);
    return this.apiData;
  }
  
}
