﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DataModels
{
    public class ArchiveAccessRequestsForApprovalModel
    {
        public string ArchiveNumber { get; set; }
        public string ClientName { get; set; }
        public string EngagementDescription { get; set; }
        public DateTime PeriodEndDate { get; set; }
        public string WBSLevelOneNumber { get; set; }
        public DateTime EstimatedIssuanceReportDate { get; set; }
        public string LastName { get; set; }
        public string FirstName { get; set; }
        public int RowNumber { get; set; }
        public int Count { get; set; }
        public string EntityTypeDescription { get; set; }
        public string ProfessionalStandardDescription { get; set; }
        public string ArchiveAccessRequestID { get; set; }
        public string Due { get; set; }
        public string ArchiveStatus { get; set; }
        public int CountOrange { get; set; }
        public int CountRed { get; set; }
        public int CountYellow { get; set; }

    }
}
