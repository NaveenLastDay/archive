import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ComplianceStatusOverrideComponent } from './compliance-status-override.component';

describe('ComplianceStatusOverrideComponent', () => {
  let component: ComplianceStatusOverrideComponent;
  let fixture: ComponentFixture<ComplianceStatusOverrideComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ComplianceStatusOverrideComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ComplianceStatusOverrideComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
