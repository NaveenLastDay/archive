import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RetentionExceptionComponent } from './retention-exception.component';

describe('RetentionExceptionComponent', () => {
  let component: RetentionExceptionComponent;
  let fixture: ComponentFixture<RetentionExceptionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RetentionExceptionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RetentionExceptionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
