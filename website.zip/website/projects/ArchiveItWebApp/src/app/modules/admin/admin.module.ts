import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdmintilesComponent } from './admintiles/admintiles.component';
import { RouterModule } from '@angular/router';
import { MaintainalertsComponent } from './maintainalerts/maintainalerts.component';
import { MatTableModule, MatCheckboxModule, MatButtonToggleModule, MatSidenavModule, MatLineModule, MatListModule, MatSlideToggleModule, MatMenuModule, MatIconModule,MatFormFieldModule } from "@angular/material";
import { SgfoldersComponent } from './sgfolders/sgfolders.component';
import { FormBuilder, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CustomModalModule } from '../shared/modal/modal.module';
import { NotifierModule, NotifierOptions } from "angular-notifier";
import { BreadcrumbModule } from '../../breadcrumb/breadcrumb.module';
import { AdminSidenavbarComponent } from './admin-sidenavbar/admin-sidenavbar.component';
import { NgxSpinnerModule } from "ngx-spinner";
import { DragDropModule } from '@angular/cdk/drag-drop';
import { MaintainlistsComponent } from './maintain-lists/maintain-lists.component';
import { MaintainliststileComponent } from './maintain-lists-tile/maintain-lists-tile.component';
import { CKEditorModule } from 'ng2-ckeditor';
import { PipeModule } from '../shared/Pipes/pipe.module';
import { HoldsComponent } from './holds/holds.component';
import { HoldDetailsComponent } from './holds/hold-details/hold-details.component';
import { MatDatepickerModule } from '@angular/material';
import { AdminGuardService } from '../../guards/admin-guard.service';
import { HTPGuardService } from '../../guards/htp-guard.service';
import { HoldsSearchArchivesComponent } from './holds/holds-search-archives/holds-search-archives.component';
import { CreateEditHoldInfoComponent } from './creation-edit-hold-info/creation-edit-hold-info.component'
import { HoldsSearchComponent } from './holds/holds-search/holds-search.component';
import { AppliedHoldsStatusComponent } from './holds/applied-holds-status/applied-holds-status.component';
import { ManageCacheService } from '../../services/manage-cache.service';
import { ManageCacheComponent } from './cache/cache-management.component';
import { ManageElasticIndexComponent } from './Indexing/manage-elasticIndex.component';
import { ManageElasticIndexService } from '../../services/manage-elasticindex.service';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { HoldsLandingComponent } from './holds/holds-landing/holds-landing.component';
import { PaginationComponent } from './../shared/pagination/pagination.component';
import { SharedComponentsModule } from "../shared/shared-components.module";
import { HoldArchiveDetailsComponent } from './holds/hold-archive-details/hold-archive-details.component';
import { HoldsApplyholdsConfirmationComponent } from './holds/holds-applyholds-confirmation/holds-applyholds-confirmation.component';
import { ArchiveDetailsComponent } from './holds/archive-details/archive-details.component';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { AppliedHoldsFilterComponent } from './holds/applied-holds-status/filter/applied-holds-filter.component';
import { HoldsHomeComponent } from './holds/holds-home/holds-home.component';
import { MatSelectModule } from '@angular/material/select';
import { HoldsSearchHomeComponent } from './holds/holds-search-home.component';
import { BatchDetailsComponent } from './destruction/batch/batch-details/batch-details.component';
import { DestructionComponent } from './destruction/destruction.component';
import { BatchHomeComponent } from './destruction/batch/batch-home/batch-home.component';
import { DestructionHomeComponent } from './destruction/destruction-home/destruction-home.component';
import { DestructionProcessHomeComponent } from './destruction/destruction-process/destruction-process-home/destruction-process-home.component';
import { DestructionProcessShowdetailsComponent } from './destruction/destruction-process/destruction-process-showdetails/destruction-process-showdetails.component';
import { ComplianceStatusOverrideComponent } from './compliance-status-override/compliance-status-override.component';
import { CreateormanageBatchComponent } from './destruction/batch/createormanage-batch/createormanage-batch.component';
import { DestructionProcessRouteComponent } from './destruction/destruction-process/destruction-process-route/destruction-process-route.component';
import { NgbModule } from "@ng-bootstrap/ng-bootstrap";
import { SubBatchHomeComponent } from './destruction/destruction-process/sub-batch/sub-batch-home/sub-batch-home.component';
import { SubBatchInfoComponent } from './destruction/destruction-process/sub-batch/sub-batch-info/sub-batch-info.component';
import { SubBatchDetailsComponent } from './destruction/destruction-process/sub-batch/sub-batch-details/sub-batch-details.component';


const customNotifierOptions: NotifierOptions = {
  position: {
    horizontal: {
      position: 'right',
      distance: 12
    },
    vertical: {
      position: 'top',
      distance: 85,
      gap: 30
    }
  },
  theme: 'material',
  behaviour: {
    autoHide: 500,
    onClick: 'hide',
    onMouseover: 'pauseAutoHide',
    showDismissButton: true,
    stacking: 1
  },
  animations: {
    enabled: true,
    show: {
      preset: 'slide',
      speed: 200,
      easing: 'ease'
    },
    hide: {
      preset: 'fade',
      speed: 3000,
      easing: 'ease-in',
      offset: 50
    },
    shift: {
      speed: 300,
      easing: 'ease'
    },
    overlap: 150
  }
};

@NgModule({
    declarations: [AdmintilesComponent, MaintainalertsComponent, SgfoldersComponent, ComplianceStatusOverrideComponent, AdminSidenavbarComponent, ArchiveDetailsComponent, MaintainlistsComponent, MaintainliststileComponent, HoldsComponent, HoldDetailsComponent, HoldsSearchArchivesComponent, HoldsSearchComponent, AppliedHoldsStatusComponent, ManageCacheComponent, HoldsLandingComponent, CreateEditHoldInfoComponent, HoldArchiveDetailsComponent, HoldsApplyholdsConfirmationComponent, AppliedHoldsFilterComponent, HoldsHomeComponent, HoldsSearchHomeComponent, BatchDetailsComponent, DestructionComponent, BatchHomeComponent, DestructionHomeComponent, DestructionProcessHomeComponent, DestructionProcessShowdetailsComponent, CreateormanageBatchComponent, DestructionProcessRouteComponent, SubBatchHomeComponent, SubBatchInfoComponent, ManageElasticIndexComponent, SubBatchDetailsComponent],
  imports: [
    MatAutocompleteModule,CommonModule, DragDropModule, NgxSpinnerModule, MatTableModule, MatSlideToggleModule, MatCheckboxModule, MatButtonToggleModule, MatSidenavModule, MatListModule, FormsModule, CustomModalModule, BreadcrumbModule, NotifierModule.withConfig(customNotifierOptions),
    CKEditorModule, PipeModule, MatDatepickerModule, MatIconModule, ReactiveFormsModule,MatSelectModule,
    SharedComponentsModule,MatFormFieldModule,MatProgressBarModule,NgbModule,

    RouterModule.forChild(
      [
        {
          path: 'admintiles', component: AdmintilesComponent, data: { title: 'AdminTiles', showbreadcrumb: 'false' }, canActivate: [AdminGuardService]
        },
        {
          path: 'adminsidenavbar', component: AdminSidenavbarComponent, data: { title: 'Admin panel', showbreadcrumb: 'true', url:'/admin/adminsidenavbar/maintainalerts' },
          children: [
            {
              path: 'maintainalerts', component: MaintainalertsComponent, data: { title: 'Maintain Alerts', showbreadcrumb: 'true' },canActivate: [AdminGuardService],
            },
            {
              path: 'destructions', component: DestructionHomeComponent, data: { title: 'Destruction', showbreadcrumb: 'true', url: '/admin/adminsidenavbar/destructions' }, canActivate: [AdminGuardService],
              children: [
                {
                  path: '', component: DestructionComponent, data: { title: '', showbreadcrumb: 'false' },
                },
                {
                  path: 'createormanagebatches', component: BatchHomeComponent, data: { title: 'Create or manage batches', showbreadcrumb: 'true', url: '/admin/adminsidenavbar/destructions/createormanagebatches' },
                  children: [
                    {
                      path: '', component: CreateormanageBatchComponent, data: { title: '', showbreadcrumb: 'false' },
                    },
                    {
                      path: 'batchdetails/:batchId', component: BatchDetailsComponent, data: { title: 'BatchDetails', showbreadcrumb: 'true', url: '/admin/adminsidenavbar/destructions/createormanagebatches' },
                    }],
                },
                {
                  path: 'destructionprocess', component: DestructionProcessRouteComponent, data: { title: 'Desctruction process', showbreadcrumb: 'true', url: '/admin/adminsidenavbar/destructions/destructionprocess' },
                  children: [
                    {
                      path: '', component: DestructionProcessHomeComponent, data: { title: '', showbreadcrumb: 'false' },
                    },
                    {
                      // batches-grid
                      path: ':batchId', component: DestructionProcessShowdetailsComponent, data: { title: 'Desctruction Process Details', showbreadcrumb: 'true', url: '/admin/adminsidenavbar/destructions/destructionprocess/' },
                    },
                    {
                      // sub-batches-list
                      path: 'subbatchinfo/:batchId', component: SubBatchInfoComponent, data: { title: 'subbatchinfo', showbreadcrumb: 'true', url: '/admin/adminsidenavbar/destructions/destructionprocess/' },
                    },
                    {
                      // sub-batches-details
                      path: 'subbatchdetails/:subBatchId', component: SubBatchDetailsComponent, data: { title: 'SubBatchDetails', showbreadcrumb: 'true' },
                    }
                  ]
                }
              ]
            },
            {
              path: 'sgfolders', component: SgfoldersComponent, data: { title: 'SGFolders', showbreadcrumb: 'true'},canActivate: [AdminGuardService],
            },
            {
              path: 'maintainlists', component: MaintainlistsComponent, data: { title: 'Maintain Lists', showbreadcrumb: 'true' },canActivate: [AdminGuardService],
            },
            {
              path: 'listtile', component: MaintainliststileComponent, data: { title: 'Tile List', showbreadcrumb: 'true' },canActivate: [AdminGuardService],
            },
            {
              path: 'complianceStatusOverride', component: ComplianceStatusOverrideComponent, data: { title: 'Compliance Status Override', showbreadcrumb: 'true' },canActivate: [AdminGuardService],
            },
            {
              path: 'holds', component: HoldsHomeComponent, data: { title: 'Holds', showbreadcrumb: 'true', url:'/admin/adminsidenavbar/holds' }, canActivate: [HTPGuardService]
              , children:[
                { path: '', component: HoldsLandingComponent, data: { title: '', showbreadcrumb: 'false'} },
                {
                  path: 'CreateHold', component: CreateEditHoldInfoComponent, data: { title: 'CreateHold', showbreadcrumb: 'true' }
               },
               {
                path: 'holdsearch', component: HoldsSearchHomeComponent, data: { title: 'Search and manage holds', showbreadcrumb: 'true', url:'/admin/adminsidenavbar/holds/holdsearch' }, children:[
                  { path: '', component: HoldsComponent, data: { title: '', showbreadcrumb: 'false'} },
                  {
                    path: 'applyHold', component: AppliedHoldsStatusComponent, data: { title: 'Apply Hold', showbreadcrumb: 'true' }
                  },
                  {
                    path: 'archivedetails', component:ArchiveDetailsComponent, data:{title:'Archive Details',showbreadcrumb:'true'},
                  },
                   {  path: ':aN', component: HoldsSearchHomeComponent, data: { title: 'HoldDetails', showbreadcrumb: 'true', url:'/admin/adminsidenavbar/holds/holdsearch/' }, children:[
                      { path: '', component: HoldDetailsComponent, data: { title: '', showbreadcrumb: 'false'} },
                      { path: 'EditHold', component: CreateEditHoldInfoComponent, data: { title: 'Edit Hold', showbreadcrumb: 'true' } }

                    ] }

                 ]
               },
               {
                 path: 'holdarchivedetails', component: HoldArchiveDetailsComponent, data: { title: 'Archive Hold Details', showbreadcrumb: 'true' },
               },
               {
                  path: 'applyHoldconfirmation', component: HoldsApplyholdsConfirmationComponent, data: { title: 'Apply Hold Confirmation', showbreadcrumb: 'true' }
                }
              ]
            }

          ]
        },

       // {
       //   path: 'holds/holddetails', component: HoldDetailsComponent, data: { title: 'Hold Details', showbreadcrumb: 'true' },
       // },
        { path: 'cachemgmt', component: ManageCacheComponent, data: { title: 'Cache Management', showbreadcrumb: 'false' } },
        { path: 'elasticindexmgmt', component: ManageElasticIndexComponent, data: { title: 'Elastic Index Management', showbreadcrumb: 'false' } }
        // {path:'', redirectTo:'admin/admintiles', pathMatch:'full'}
      ]
    )
  ],
  providers: [FormBuilder, AdminGuardService, ManageCacheService,HTPGuardService, ManageElasticIndexService],
  //schemas: [CUSTOM_ELEMENTS_SCHEMA ]
})
export class AdminModule { }
