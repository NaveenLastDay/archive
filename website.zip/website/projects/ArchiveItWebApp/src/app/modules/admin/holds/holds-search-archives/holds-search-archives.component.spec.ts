import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HoldsSearchArchivesComponent } from './holds-search-archives.component';

describe('HoldsSearchArchivesComponent', () => {
  let component: HoldsSearchArchivesComponent;
  let fixture: ComponentFixture<HoldsSearchArchivesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HoldsSearchArchivesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HoldsSearchArchivesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
