import { Component, OnInit } from '@angular/core';
import { SearchService } from '../../../services/search.service';
import { SearchEventService } from '../../search/search.event.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { LinkedArchivesService } from '../../../services/linked-archives.service';
import { Router,ActivatedRoute } from '@angular/router';
import { NotifierService } from 'angular-notifier';
import { FormGroup, Validators, FormBuilder, FormArray } from '@angular/forms';
import { ArchiveSearchService } from '../../../services/archive-search.service';
import { WBSData } from '../../archive/search-wbs/search-wbs.component';
import { AppConfig } from '../../../services/appconfig.service';
import { SearchWbsService } from '../../../services/searchwbs.service';
import { ViewChild } from '@angular/core';
import { MatAutocompleteTrigger, MatDatepickerInputEvent } from '@angular/material';
import { MatAutocompleteSelectedEvent } from '@angular/material';
import { PeoplePickerService } from '../../../services/MDREmployeeeDetails.service';
import { ArchiveHomeService } from '../../../services/archive-home.service';
import { DeliverableService } from '../../../services/deliverable.service';
import { PubsubService } from '../../../services/pubsub.service';
import { UserActions } from '../../../models/archive-role.model';
import { ModalService } from "../../shared/modal";
import { stringToKeyValue } from '@angular/flex-layout/extended/typings/style/style-transforms';
import { distinctUntilChanged, debounceTime } from 'rxjs/operators';
import { BehaviorSubject } from 'rxjs';

@Component({
  selector: 'app-add-linked-archives',
  templateUrl: './add-linked-archives.component.html',
  styleUrls: ['./add-linked-archives.component.css']
})
export class AddLinkedArchivesComponent implements OnInit {

  searchtextvalue: string; 
  archives: any[] = [];
  appendArchiveToGrid: boolean = false;
  readonly emptyStringInReport : string = " "; 
  readonly pageSize: number = 10;
  totalArchives: number = -1;
  currentPageNumber: number = 1;
  fromRecord: number = 0;
  LinkedArchiveNumber: string;
  archiveNumber: string;
  isDefaultResult: boolean = true;
  isLoadedResult: boolean = false;
  //advance search
  show: boolean = false;
  filterarray: any = [];
  selectedClientViewName: string = "";
  selectedClient: string;
  selectedClients: Array<any> = [];
  users: Array<any> = [];
  clients: Array<any> = [];
  addLA_form: FormGroup;
  searchedWBSResults: string;
  searchWBSData2: any[];
  wbslength: any;
  textlength: any;
  searchedtext: string = "";
  $searchWBSData: WBSData[];
  rowcount: any;
  wbsCount: any;
  selectedWBSList: Array<any> = [];
  periodEndDate: string;
  periodEndDateFrom: string;
  periodEndDateTo: string;
  periodendDtShow: boolean = false;
  readonly DateFormat: string = "MM/DD/YYYY";
  readonly searchClientParam: string = "Client: ";
  readonly searchWBSParam: string = "WBS: ";
  readonly searchPeriodendParam: string = "Period end: ";
  readonly searchNumberParam: string = "Archive Number: ";
  readonly searchNameParam: string = "Archive Name: ";
  readonly searchDescParam: string = "Archive Description: ";
  readonly searchStatusParam: string = "Status: ";
  readonly searchManagerParam: string = "Archive Member:" ;
  archiveNumberParam: string;
  archiveNameParam: string;
  archiveDescParam: string;
  selectedStatusList: Array<any> = [];
  statusList = [];
  selectedManagerViewName: string = "";
  selectedManager: string;
  selectedManagerDisplayName: string;
  selectedManagers: Array<any> = [];
  login_form: FormGroup;
  paramindex: number = 0;
  isBasicShow: boolean = true;
  FileSelectionFlag: boolean;
  euserAlias:any;
  isApprover:boolean=false;
  CurrentArchiveStatusforLinkedArchives:any;
  roleMapping = new UserActions();
  linkbuttonDisabled = false;
  LinkedArchivesEditedInResubmit: boolean;
  LinkedArchivesProvidedInResubmit: string;
  LinkedArchivesEditedDate:Date;

  lastSearchKeyword: string = '';
  currentSearchKeyword: string = '';
  eventValue: any;

  private _subject: BehaviorSubject<string> = new BehaviorSubject<string>("");


  @ViewChild('autoCompleteInput', { read: MatAutocompleteTrigger, static: false }) autoComplete: MatAutocompleteTrigger;
  constructor(
    private _searchService: SearchService,
    private eventService: SearchEventService,
    private SpinnerService: NgxSpinnerService,
    private adalSvc: MsAdalAngular6Service,
    private linkedArchivesService: LinkedArchivesService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private notifier: NotifierService,
    private fb: FormBuilder,
    private archiveSearchService: ArchiveSearchService,
    private searchwbs: SearchWbsService,
    private peoplePickerService: PeoplePickerService,
    private deliverableService: DeliverableService,
    private archiveHomeService: ArchiveHomeService,
    private pubsub: PubsubService,
    private modalService: ModalService
    
    ) { 
      this.addLA_form = fb.group({
        'alaarchiveclient': [null, Validators.required],
      });
      this.login_form = fb.group({
        'archivemanager': [null, Validators.required],
      });
      this.rowcount=10;
  }

  ngOnInit() {
    this.euserAlias = this.adalSvc.LoggedInUserEmail.split('@')[0];
    this.archiveNumber = this.activatedRoute.snapshot.parent.paramMap.get('aN');
    this.IsUserApprover(this.archiveNumber, this.euserAlias);
    this.bindStatus();
  }
  ngDoCheck() {
    this.roleMapping = this.pubsub.getRoleMappingResult();
  }

  IsUserApprover(archivenumber, userlias) {
    debugger;
    this.deliverableService.IsUserApprover(archivenumber, userlias).subscribe(
      (data) => {
        if (data != undefined) {
          this.isApprover = data.canApprove;
          console.log("Is Approver" , this.isApprover);
          this.CurrentArchiveStatusforLinkedArchives = data.archiveInfo.archiveStatus;
          //Added newly to diable editing the deiverable to archive team except for the archive approver
          //ShowContentForEditDeliverables will hide 
          //DisableSelectCheckboxes will disable the Select all & individual checkboxes for each deliverable added.
          this.HideorShowlogic();
        }
      });
  }
  HideorShowlogic() {
    var archiveStatusHome: string = this.CurrentArchiveStatusforLinkedArchives;
    switch (archiveStatusHome) {
      case 'Ready For Approval': {
        this.archiveHomeService.GetArchiveApproverForArchiveSubmission(this.archiveNumber,this.roleMapping.roleId).subscribe(data =>
        {
            if(data){
                console.log('GetArchiveApproverForArchiveSubmission-LinkedArchives',data.canApprove);
                this.isApprover=data.canApprove;
            }
          if (this.isApprover) {
          this.commonViewForEdit();
          this.specificViewToApprover();
          }
          else {
          this.commonViewForReadonly();
          }
        });
        break;
      }
      case "Resubmitted - Ready for Approval": {
        this.GetResubmissionApprovalFlow();
        break;
      }

      /* common for Open, Resubmitted – Open*/
      case 'Open': {
        this.commonViewForEdit();
        break;
      }
      case "Resubmitted – Open": {
        this.commonViewForEdit();
        this.archiveHomeService.GetResubmissionReasonsforArchive(this.archiveNumber).subscribe(data=>
          { 
            if(data){
             if(data.length>0)
             {
              debugger;
              this.LinkedArchivesEditedInResubmit=data[3].actionTypeId==3?true:false;
              this.LinkedArchivesProvidedInResubmit= data[3].comments!=""?data[3].comments:"";
              this.LinkedArchivesEditedDate=data[3].rejectedDate;
             }
            }
          });
        break;
      }
      /*End common for Open, Resubmitted – Open*/

      /*Common for Approved, Resubmitted – Approved and Resubmitted - Rejected */
      case "Approved": {
        this.commonViewForReadonly();
        break;
      }
      case "Resubmitted – Approved": {
        this.commonViewForReadonly();
        break;
      }
      case "Resubmitted - Rejected": {
        if(this.roleMapping.roleId==11 || this.roleMapping.roleId==12)
        {
          this.commonViewForReadonly();
        }
        else{
          this.commonViewForEdit();}
        break;
      }
      /*End Common for Approved, Resubmitted – Approved and Resubmitted - Rejected */

      case "Rejected":
        {
          this.commonViewForEdit();
          break;
        }
    }
  }
  ShowEditedReasonPop(ActionType)
      { 
        debugger;
        // if(this.CurrentArchiveStatusforLinkedArchives=="Resubmitted – Open" || this.CurrentArchiveStatusforLinkedArchives=="Resubmitted - Ready for Approval")
        // {
        //   //Initial popup
        //   if(Action==='SaveChanges-addarchivelinked-AdministrativeResubmission-Modal' && ActionType==='addLinkedArchive')
        //     {
        //       this.modalService.openWithCustomWidth("SaveChanges-addarchivelinked-AdministrativeResubmission-Modal", "544");
        //     }
        //   // Upon click on Save & State changes button from above popup below popup will be called
        //   if(Action==='Reasons-Adminstrativeresubmission-modal' && ActionType==='addLinkedArchive')
        //     {
        //       debugger;
        //       this.linkArchive();
        //       this.modalService.close("SaveChanges-addarchivelinked-AdministrativeResubmission-Modal");
        //     }
        // }
        // else 
        if(ActionType==='addLinkedArchive')
        {
            this.linkArchive();
        }
      }

  GetResubmissionApprovalFlow() {
    var inparameters = {
      "ArchiveNumber": this.archiveNumber,
      "UserAlias": ''
    }
    var parameters = JSON.stringify(inparameters);
    this.archiveHomeService.GetResubmissionApprovalFlowStatuses(parameters).subscribe(
      (obj) => {
        this.isApprover = obj[0].canApprove;
        if (obj[0].completedApprovel >= 1) {
          this.isApprover = false;
        }
        // else if (obj[0].completedApprovel == 0) {
        //   if (localStorage['isFirstLevelEdited'] == "null" || localStorage['isFirstLevelEdited'] == 0)
        //     this.isApprover = false;
        // }
        this.archiveHomeService.GetResubmissionReasonsforArchive(this.archiveNumber).subscribe(data => {
          if (data) {
            if (data.length > 0) {
              this.LinkedArchivesEditedInResubmit = data[3].actionTypeId == 3 ? true : false;
              this.LinkedArchivesProvidedInResubmit = data[3].comments != "" ? data[3].comments : "";
              this.LinkedArchivesEditedDate=data[3].rejectedDate;
            }
          }
        });
        //Added from outside of the method to inside
        if (this.isApprover) {
          this.commonViewForEdit();
          this.specificViewToApprover();         
        }
        else {
          this.commonViewForReadonly();
        }
        // this.ShowContentForEditDeliverables = 1;
        // this.DisableSelectCheckboxes = false;
      },
      (err) => {
        console.log("error is ", err)
      }
    );
  }

  //Method For Open and Resubmitted – Open
  commonViewForEdit() {
    this.linkbuttonDisabled=false;
  }
  specificViewToApprover() {
    this.linkbuttonDisabled=false;
  }
  commonViewForReadonly() {
    this.linkbuttonDisabled=true;
  }

 
  LinkedArchiveSearch() {
    //this.archives = [];
    //this.totalArchives = 0;
    this.resetPagination();
    this.FileSelectionFlag = false;    
    this.searchLinkedArchives();   
  }
  searchLinkedArchives()
  {    
    if (this.searchtextvalue.length >=3 ) {
        this.getLinkArchives();        
    }
    else if(this.filterarray.length > 0)
    {
      this.advanceSearch();
    }
    else {
      return false;
    }
  }
  getLinkArchives(){
    debugger;
    this.fromRecord = (this.pageSize * (this.currentPageNumber - 1));
    this.eventService.finalSelectedJson.employeeAlias=this.adalSvc.LoggedInUserEmail.split('@')[0];
    this.eventService.finalSelectedJson.from=this.fromRecord;
    this.eventService.finalSelectedJson.pageSize=this.pageSize;
    this.eventService.finalSelectedJson.isKeywordbaseSearch=true;
    this.eventService.finalSelectedJson.searchKeyword=this.searchtextvalue.trim();
    this.clearFinalRules();
    this._searchService.getAdvancedSearchResults(this.eventService.finalSelectedJson).subscribe(

      data => {
        debugger;

        if (data && data.hits && data.hits.total.value && data.hits.hits.length) {
          console.log("data exists");
          if (!this.appendArchiveToGrid) {
            this.archives = [];
          }

          data.hits.hits.forEach(element => {
            let archive = {};
            archive["archiveNumber"] = element._source.ArchiveNumber;
            archive["clientName"] = element._source.ClientName.original;
            archive["archiveName"] = element._source.ArchiveName.original;
            archive["archivePartner"] = element._source.ArchivePartner.original || this.emptyStringInReport;
            archive["archiveDescription"] = element._source.ArchiveType.original;
            archive["periodEndDate"] = element._source.RetentionPeriodEndDate;
            archive["wbsLevelOne"] = element._source.WbsNumber.original;
            archive["related"] = element._source.LinkedArchiveCount;
            archive["isPeriodendCrossed"] = false;
            var curdate =new Date();
            var periodendDate = new Date(element._source.RetentionPeriodEndDate);
            if(curdate > periodendDate)
            {
              var diffMonth = (curdate.getFullYear() - periodendDate.getFullYear())*12 + (curdate.getMonth() - periodendDate.getMonth())
              archive["isPeriodendCrossed"] = diffMonth > 48 ? true: false;
            }           
           
            this.archives.push(archive);
          });
          this.totalArchives = data.hits.total.value;  
          this.isLoadedResult = true;
        }
        else
        { this.totalArchives =0; }
      });
  }
  closeModalDialog(Action) {
    this.modalService.close(Action);
  }
  updateGridData(event) {
    debugger;
    this.appendArchiveToGrid = event.isLoadMoreClicked;
    this.currentPageNumber = event.pageNumber;    
    if (!this.appendArchiveToGrid) {
      this.FileSelectionFlag = false;
      }   
    this.searchLinkedArchives();
  }

  ALASelectedRow(item) {
    this.LinkedArchiveNumber = item.archiveNumber;
    this.FileSelectionFlag = true;
  }

  cancel(){
    this.archives=[];
    this.totalArchives=-1;
    this.searchtextvalue="";
    this.filterarray =[];
    this.selectedClients=[];
    this.selectedWBSList=[];
    this.selectedStatusList=[];
    this.selectedManagers=[];
    this.archiveNameParam='';
    this.archiveNumberParam='';
    this.archiveDescParam='';
    this.searchedtext='';
    this.isBasicShow=true;
    this.selectedManagerViewName='';
    this.bindStatus();
  }
  linkArchive(){
    debugger;
    this.archiveNumber = this.activatedRoute.snapshot.parent.paramMap.get('aN');

    // check for self-archive
    if (this.archiveNumber == this.LinkedArchiveNumber) {
      this.notifier.notify("error", "Archive " + this.LinkedArchiveNumber + " cannot be linked to itself");
      return;
    }
    else {
      this.linkedArchivesService.insertLinkedArchives(this.archiveNumber, this.LinkedArchiveNumber, this.adalSvc.LoggedInUserEmail.split('@')[0]).subscribe(
        data => {
          debugger;
          console.log("linkArchive()::data=========");
          console.log(data);

          if (data == "1")
          {
            this.notifier.notify("error", "Linked archive " + this.LinkedArchiveNumber + " already exists.");
            return;
          }
          else if (data == "3")
          {
            this.notifier.notify("success", "Linked Archive saved successfully.");
            // if(!(this.CurrentArchiveStatusforLinkedArchives=="Resubmitted – Open" || this.CurrentArchiveStatusforLinkedArchives=="Resubmitted - Ready for Approval"))
            // {
                
            // }
            this.router.navigate(["archive/myarchives/" + this.archiveNumber + '/linkedarchives']);
          }
        }
      );
    }
  }


  resetfilter(){
    this.cancel();
    this.FileSelectionFlag = false;
    this.eventValue = '';
      this.periodEndDate = '';
      this.periodEndDateFrom = '';
      this.periodEndDateTo = '';

  }

  toggle(){
    this.periodendDtShow = false;
    this.show = !this.show;
  }
  DtPickerFormat(event)
  {
    this.eventValue = event;
  }
  filterList(isAddFilter: boolean, textToFilter: string, isCommitFilter: boolean = false, isFilterPrefix: number = 0) {

    if (isAddFilter) {
      if (isCommitFilter && this.filterarray) {
        if (textToFilter != undefined) {
          var filterPrefix = this.searchClientParam;
          var filterPrefixString = "";
          if (isFilterPrefix == 1) {
            filterPrefix = this.searchWBSParam;
          }
          else if (isFilterPrefix == 2) {
            filterPrefix = this.searchPeriodendParam;
          }
          else if (isFilterPrefix == 3) {
            filterPrefix = this.searchNumberParam;
          }
          else if (isFilterPrefix == 4) {
            filterPrefix = this.searchNameParam;
          }
          else if (isFilterPrefix == 5) {
            filterPrefix = this.searchStatusParam;
          }
          else if (isFilterPrefix == 6) {
            filterPrefix = this.searchManagerParam;
          }
          else if (isFilterPrefix == 7) {
            filterPrefix = this.searchDescParam;
          }
          filterPrefixString = filterPrefix + textToFilter;
          this.deleteItemFromFilterArray(filterPrefix);
          this.filterarray.push(filterPrefixString);
        }
      }
    }
  }

  deleteItemFromFilterArray(msg: string) {
    if (this.filterarray && this.filterarray.length > 0) {
      this.filterarray.forEach(textToFilter => {
        if (textToFilter.includes(msg)) {
          const index: number = this.filterarray.indexOf(textToFilter);
          if (index !== -1) {
            this.filterarray.splice(index, 1);
          }
        }
      });
    }
  }

  searchtrigger()
  {
    debugger;
    this.filterarray = [];
    this.totalArchives = -1;
    this.archives = [];
    this.searchtextvalue = '';
    if ((this.selectedClients.length >0 || this.selectedWBSList.length >0 || this.periodEndDate
       || this.archiveNumberParam || this.archiveNameParam || this.archiveDescParam || this.selectedStatusList.length >0
       || this.selectedManagers.length >0) && this.filterarray) {

      if (this.selectedClients.length >0 && !this.filterarray.includes(this.selectedClients.toString())) {
        this.filterList(true, this.selectedClients.toString(), true, 0);
      }

      if (this.selectedWBSList.length >0 && !this.filterarray.includes(this.selectedWBSList.toString())) {
        this.filterList(true, this.selectedWBSList.toString(), true, 1);
      }

      if (this.periodEndDate != '' && !this.filterarray.includes(this.periodEndDate)) {
        this.filterList(true, this.periodEndDate, true, 2);
      }

      if (this.archiveNumberParam != '' && !this.filterarray.includes(this.archiveNumberParam)) {
        this.filterList(true, this.archiveNumberParam, true, 3);
      }

      if (this.archiveNameParam != '' && !this.filterarray.includes(this.archiveNameParam)) {
        this.filterList(true, this.archiveNameParam, true, 4);
      }

      if (this.selectedStatusList.length >0 && !this.filterarray.includes(this.selectedStatusList.toString())) {
        this.filterList(true, this.selectedStatusList.toString(), true, 5);
      }

      if (this.selectedManagers.length >0 && !this.filterarray.includes(this.selectedManagers.map(o => o.displayName).join('; '))) {
        this.filterList(true, this.selectedManagers.map(o => o.displayName).join('; '), true, 6);
      }

      if (this.archiveDescParam != '' && !this.filterarray.includes(this.archiveDescParam)) {
        this.filterList(true, this.archiveDescParam, true, 7);
      }
      this.toggle();
      this.advanceSearch();
      this.checkBasicSearch();
    }
    else{
      return false;
    }

  }

  advanceSearch(){
    debugger;
    this.fromRecord = (this.pageSize * (this.currentPageNumber - 1));
    this.eventService.finalSelectedJson.employeeAlias=this.adalSvc.LoggedInUserEmail.split('@')[0];
    this.eventService.finalSelectedJson.from=this.fromRecord;
    this.eventService.finalSelectedJson.pageSize=this.pageSize;
    this.eventService.finalSelectedJson.isKeywordbaseSearch=false;
    this.eventService.finalSelectedJson.searchKeyword="";
    this.clearFinalRules();
    if(typeof this.archiveNameParam!='undefined' && this.archiveNameParam){
    this.eventService.finalSelectedJson.rules.archiveName.push(this.archiveNameParam);
    }
    if(typeof this.archiveNumberParam!='undefined' && this.archiveNumberParam){
    this.eventService.finalSelectedJson.rules.archiveNumber.push(this.archiveNumberParam);
    }
    if(typeof this.archiveDescParam!='undefined' && this.archiveDescParam){
      this.eventService.finalSelectedJson.rules.archiveType.push(this.archiveDescParam);
      }
    if(this.selectedClients.length >0){
      this.selectedClients.forEach(x => this.eventService.finalSelectedJson.rules.clientName.push(x));
    }
    if(this.selectedWBSList.length >0){
      this.selectedWBSList.forEach(x => this.eventService.finalSelectedJson.rules.WBSNumber.push(x));
    }
    if(this.selectedStatusList.length >0){
      this.selectedStatusList.forEach(x => this.eventService.finalSelectedJson.rules.archiveStatus.push(x));
    }
    if(this.selectedManagers.length >0){
      this.selectedManagers.forEach(x => this.eventService.finalSelectedJson.rules.archiveTeamMembers.push(x.displayName));
    }
    if(this.periodEndDateFrom && this.periodEndDateTo){
    this.eventService.finalSelectedJson.rules.periodEndDate.push({
      StartDate: this.periodEndDateFrom,
      EndDate: this.periodEndDateTo
    });
  }
    this._searchService.getAdvancedSearchResults(this.eventService.finalSelectedJson).subscribe(

      data => {
        debugger;

        if (data && data.hits && data.hits.total.value && data.hits.hits.length) {
          console.log("data exists");
          if (!this.appendArchiveToGrid) {
            this.archives = [];
          }

          data.hits.hits.forEach(element => {
            let archive = {};
            archive["archiveNumber"] = element._source.ArchiveNumber;
            archive["clientName"] = element._source.ClientName.original;
            archive["archiveName"] = element._source.ArchiveName.original;
            archive["archivePartner"] = element._source.ArchivePartner.original || this.emptyStringInReport;
            archive["archiveDescription"] = element._source.ArchiveType.original;
            archive["periodEndDate"] = element._source.RetentionPeriodEndDate;
            archive["wbsLevelOne"] = element._source.WbsNumber.original;
            archive["related"] = element._source.LinkedArchiveCount;
            archive["isPeriodendCrossed"] = false;
            var curdate =new Date();
            var periodendDate = new Date(element._source.RetentionPeriodEndDate);
            if(curdate > periodendDate)
            {
              var diffMonth = (curdate.getFullYear() - periodendDate.getFullYear())*12 + (curdate.getMonth() - periodendDate.getMonth())
              archive["isPeriodendCrossed"] = diffMonth > 48 ? true: false;
            }        
            this.archives.push(archive);
          });
          this.totalArchives = data.hits.total.value;  
          this.isLoadedResult = true;
        }
        else
        { this.totalArchives =0; }
      });
  }

  clearFinalRules() {
    this.eventService.finalSelectedJson.rules.archiveName = [];
    this.eventService.finalSelectedJson.rules.archiveNumber = [];
    this.eventService.finalSelectedJson.rules.archiveType = [];
    this.eventService.finalSelectedJson.rules.clientName = [];
    this.eventService.finalSelectedJson.rules.archiveTeamMembers = [];
    this.eventService.finalSelectedJson.rules.archiveStatus = [];
    this.eventService.finalSelectedJson.rules.WBSNumber = [];
    this.eventService.finalSelectedJson.rules.periodEndDate = [];
  }

  resetPagination()
  {    
      this.appendArchiveToGrid = false;
      this.currentPageNumber=1;
      this.totalArchives=0;
  }

  removeparam(event, searchparam: any, index: any) {
    if(searchparam.includes('Period end')) {
      this.eventValue = '';
    } 
    this.archives = [];
    this.totalArchives = -1;
    this.paramindex = index;
    this.FileSelectionFlag = false;
    this.filterarray.splice(this.paramindex, 1);

    if (searchparam.includes(this.searchClientParam)) {
      this.selectedClients = [];
      this.searchedtext = '';
    }

    if (searchparam.includes(this.searchWBSParam)) {
      this.selectedWBSList = [];
      this.searchedtext = '';
    }

    if (searchparam.includes(this.searchPeriodendParam)) {
      this.periodEndDate = '';
      this.periodEndDateFrom = '';
      this.periodEndDateTo = '';
    }

    if (searchparam.includes(this.searchNumberParam)) {
      this.archiveNumberParam = '';
    }

    if (searchparam.includes(this.searchNameParam)) {
      this.archiveNameParam = '';
    }

    if (searchparam.includes(this.searchDescParam)) {
      this.archiveDescParam = '';
    }

    if (searchparam.includes(this.searchStatusParam)) {
      this.selectedStatusList = [];
      this.selectedManagerViewName = '';
    }

    if (searchparam.includes(this.searchManagerParam)) {
      this.selectedManagers = [];
      this.searchedtext = '';
    }

    this.checkBasicSearch();

    if (this.filterarray.length > 0) {
      this.advanceSearch();
    }
  }

  checkBasicSearch() {
    if (this.filterarray && this.filterarray.length > 0) {
      this.filterarray.forEach(textToFilter => {
        if (textToFilter.includes(this.searchClientParam)
          || textToFilter.includes(this.searchWBSParam)
          || textToFilter.includes(this.searchPeriodendParam)
          || textToFilter.includes(this.searchNumberParam)
          || textToFilter.includes(this.searchNameParam)
          || textToFilter.includes(this.searchDescParam)
          || textToFilter.includes(this.searchStatusParam)
          || textToFilter.includes(this.searchManagerParam)          
        ) {
          this.isBasicShow = false;
        }
        else {
          this.isBasicShow = true;
        }
      });
    }
    else {
      this.isBasicShow = true;
    }
  }

   //Client 
  //To get client Details 
  onClientInputChanged(searchString: string) {
    this.clients = [];
    if (searchString.length >= 3) {
      this.archiveSearchService.getArchiveSearchResults(searchString, "Client").subscribe(result => {
        if (result.length > 0) {
          this.clients = result;
        }
        else {
          this.clients = null;

        }
      },
        (err) => {
          console.log("error is ", err)
        }
      );
    }
    else if (searchString.length == 0) {
      this.clients = [];
    }
    else {
      this.clients = [];
    }
  }

    //To store the selected Client details 
    selectedClientName(client, index) {
      this.selectedClientViewName = client.source.viewValue;
      this.selectedClient = this.clients[index].itemName;
      this.selectedClients.push(this.selectedClient);
      //change to useralias once lambda is changed.
      this.clients = [];
      this.addLA_form.get('alaarchiveclient').reset();
  
    }
    //To delete the selected Client
    deleteClient(clientName) {
      this.selectedClients = this.selectedClients.filter(e => e !== clientName);
    }

    //WBS
  //To bind the WBS data  
  SearchWBSOne(event: any) {
    if (event.target.value.length >= this.textlength) {
      this.searchwbs.GetWBSSerchResults(event.target.value, this.rowcount).subscribe(result => {
        if (result.length > 0) {
          this.$searchWBSData = result;
        }
        else {
          this.$searchWBSData = null;
          this.notifier.notify("error", "No results found for Search WBS");
        }

      });
    }
    else {
      this.$searchWBSData = null;
    }
    if (this.$searchWBSData != undefined)
      this.wbsCount = this.$searchWBSData.length;
  }
  onWbsInputChanged(event: any) {
    this.wbslength = event.length;
    this.textlength = AppConfig.settings.searchwbs.textboxlength;
  }

  //To store selected WBS data
  optionSelected(event: MatAutocompleteSelectedEvent) {
    var selectedWbs = event.option.value;
    this.selectedWBSList.push(selectedWbs);
    this.searchedtext = '';
    this.autoComplete.closePanel();
  }
  //delete the selected WBS data
  deleteWBS(wbsName) {
    this.selectedWBSList = this.selectedWBSList.filter(e => e !== wbsName);
  }

  SavePeriodEndDate(event) {
    // debugger;
    if (event != undefined) {
      this.periodEndDate = "";
      if (event[0].fromdate != "" && event[1].todate != "") {
        this.periodEndDateFrom = this.getDateInMySQLFomat(event[0].fromdate);
        this.periodEndDateTo = this.getDateInMySQLFomat(event[1].todate);
        this.periodEndDate = event[0].fromdate + " — " + event[1].todate;
      }
    }
  }

  getDateInMySQLFomat(date: string) {
    return date.split("/")[2] + "-" + date.split("/")[0] + "-" + date.split("/")[1];
  }

  DatePickerToggle() {
    this.periodendDtShow = !this.periodendDtShow;
  }
  // Status 
  //To bind status data into dropdown
  bindStatus() {
    this.archiveSearchService.getArchiveSearchResults("", "SubmissionStatus").subscribe(result => {
      if (result.length > 0) {
        this.statusList = result
      }
      else {

        this.statusList = null
      }
    },
      (err) => {
        console.log("error is ", err)
      }
    );


  }

  onStatusSelect(e) {
    var selectedstatus = e.target.value;
    this.selectedStatusList.push(selectedstatus);
  }
  deleteStatus(statusName) {
    this.selectedStatusList = this.selectedStatusList.filter(e => e !== statusName);
  }

  //Archive Member 
  //To get Archive Member
  onInputChanged(searchString: string) {
    this.users = [];

    this.currentSearchKeyword = searchString;
    this._subject.next(this.currentSearchKeyword ? this.currentSearchKeyword.trim() : "");

    if (searchString.length >= 3) {
      this._subject.pipe(
        distinctUntilChanged(),
        debounceTime(500),
      ).subscribe(value => this.getPeople(value))
    }
    else{
      this.users = [];
      this.lastSearchKeyword = '';
    }
  }

  getPeople(searchString: string) {
    if (searchString.length >= 3 && this.lastSearchKeyword != searchString) {
      this.lastSearchKeyword = searchString;
      this.peoplePickerService.GetPeople(searchString).subscribe(
        (value) => {
          this.users = [];
          value.forEach(element => {
            if (this.currentSearchKeyword.length >= 3) {
              // if (element.isPPD)
              this.users = value;
            } else {
              this.users = [];
            }
          });
        },
        (err) => {
          console.log("error is ", err)
        }
      );
      this.SpinnerService.hide();
    }
  }
  //To store selected Archive member Details
  selectedManagerName(partner, index) {
    this.selectedManagerViewName = partner.source.viewValue;
    this.selectedManager = this.users[index].userAlias;
    this.selectedManagerDisplayName = this.users[index].displayName;
    this.selectedManagers.push({ alias: this.selectedManager, displayName: this.selectedManagerDisplayName });
    //change to useralias once lambda is changed.
    this.users = [];
    this.login_form.get('archivemanager').reset();

  }
  //To delete Archive Member
  deleteManager(memberName) {
    this.selectedManagers = this.selectedManagers.filter(e => e.displayName !== memberName.displayName);
  }

  applyHighlightByColumn(colname? : string) {
    debugger;
    if (this.eventService.finalSelectedJson.searchKeyword) {
      return this.eventService.finalSelectedJson.searchKeyword
    }
    else {
      if (colname == "ArchiveNumber") {
        return this.eventService.finalSelectedJson.rules.archiveNumber[0];
      }
      else if (colname == "ArchiveName") {
        return this.eventService.finalSelectedJson.rules.archiveName[0];
      }
     
      else if (colname == "Client") {
        return this.eventService.finalSelectedJson.rules.clientName;
      }
      else if (colname == "WBS") {
        return this.eventService.finalSelectedJson.rules.WBSNumber;
      }     
      else if (colname == "PeriodEndDate") {
        return this.eventService.finalSelectedJson.rules.periodEndDate;
      }      
    }  
  }

  isselectedcustomrules(nameKey){
    for (var i=0; i < this.eventService.selectedFields.length; i++) {
        if (this.eventService.selectedFields[i].id == nameKey) {
            return true;
        }
        
    }
    return false;
  }
}
