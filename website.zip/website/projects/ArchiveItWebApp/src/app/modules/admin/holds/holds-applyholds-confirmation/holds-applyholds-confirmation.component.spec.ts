import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HoldsApplyholdsConfirmationComponent } from './holds-applyholds-confirmation.component';

describe('HoldsApplyholdsConfirmationComponent', () => {
  let component: HoldsApplyholdsConfirmationComponent;
  let fixture: ComponentFixture<HoldsApplyholdsConfirmationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HoldsApplyholdsConfirmationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HoldsApplyholdsConfirmationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
