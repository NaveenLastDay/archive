﻿using Microsoft.Extensions.Logging;


namespace Deloitte.AIFA.Common.Logging
{
    public class CoreLoggerProvider : ILoggerProvider
    {
        private readonly string _logFilePath;
        public CoreLoggerProvider(string logFilePath)
        {
            _logFilePath = logFilePath;
        }
        public ILogger CreateLogger(string categoryName)
        {
            return new CoreFileLogger(categoryName, _logFilePath);
        }

        public void Dispose()
        {
            
        }
    }
}
