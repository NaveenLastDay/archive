import { TreeNode } from './tree-node';

export const NODES: TreeNode[] = [
    {
        name: '2014 Syndax Q3 Interim Review',
        showChildren: true,
        itemtype:1,
        children:[
            {
                name : '1310 Engagement Letter',
                showChildren: true,
                itemtype:1,
                children:[
                    {
                        name : '1310 Syndax Quaterly Review Engagement Letter',
                        showChildren: true,
                        itemtype:2,
                        children:[]
                    },
                    {
                        name : '1310 Syndax Signed Engagement Letter',
                        showChildren: true,
                        itemtype:2,
                        children:[
                            
                        ]
                    },
                ]
            },
            {
                name : 'Syndax Signed Tax Engagement Letter',
                showChildren: true,
                itemtype:2,
                children:[]
            },
            

        ]
     },
     {
        name: '1700 DETERMINE MATERIALITY',
        showChildren: true,
        itemtype:1,
        children:[
            {
                name : '1700 Determine Materiality Performance',
                showChildren: true,
                itemtype:2,
                children:[
                    
                ]
            },
            {
                name : '1701 Determine Materiality Letter',
                showChildren: true,
                itemtype:2,
                children:[]
            },
            {
                name : '1702 Determine Materiality Liability',
                showChildren: true,
                itemtype:2,
                children:[]
            },

        ]
     },
     {
        name: 'Report to Management',
        showChildren: true,
        itemtype:1,
        children:[
            {
                name : '2100 S-1 Document',
                showChildren: true,
                itemtype:1,
                children:[
                    {
                        name : 'Syndax form S1 Amendment',
                        showChildren: true,
                        itemtype:2,
                        children:[]
                    }
                ]
            },
            {
                name : 'Syndax form S2 Amendment',
                showChildren: true,
                itemtype:2,
                children:[]
            },
            {
                name : 'Syndax form S3 Amendment',
                showChildren: true,
                itemtype:2,
                children:[]
            },
        ]
     },
     {
        name: 'North America',
        showChildren: true,
        itemtype:2,
        children: []
     }


]