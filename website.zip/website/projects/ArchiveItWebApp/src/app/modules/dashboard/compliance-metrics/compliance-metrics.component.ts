import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { ArchiveService } from '../../../services/archive.service';
// import { NgxSpinnerService } from 'ngx-spinner';
import { NotifierService, NotifierModule, NotifierOptions } from "angular-notifier";
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { TrimSummaryLengthPipe } from '../../shared/Pipes/trim-summary-length.pipe';
import { HomePageService } from '../../../services/homepage.service';
import { SharedService } from '../../../services/shared.service';

@Component({
  selector: 'app-compliance-metrics',
  templateUrl: './compliance-metrics.component.html',
  styleUrls: ['./compliance-metrics.component.css']
})
export class ComplianceMetricsComponent implements OnInit {
  totalArchivesAssigned: number = 0;
  currentUrl: string;
  employeeUniqueIdentifier: string;
  filterText: string = "";
  displayingRecordsFrom: number = 0;
  displayingRecordsTo: number = 0;
  userConfig: any;
  myArchives: any[];
  currentPageNumber: number = 1;
  totalArchives: number = 0;
  pageSize: number = 10;
  archiveNumber: string = '';
  eventType: string = '';
  hoverIndex: number = -1;
  pageCount: number = 10;
  appendArchiveToGrid: boolean = false;
  archives: any[];
  pageArray = Array();
  archiveAccessRequestsForApprovalData: any;
  archiveIDForChild: any;
  exportExcelData: any;
  archiveAccessRequestID: string;
  countForAccessRequests: any;
  headerColumns: any = [];
  tooltipInfoAccessReq: any = 'Your Compliance metrics include archives initially approved during the current Talent year (March through February) where you are a member of the Archive team.';
  tooltipDueDateColumn: any = 'Archives are due for initial approval by the Expected Documentation Completion Date (EDCD).';
  redColor: any;
  orangeColor: any;
  yellowColor: any;
  complianceMetricData: any;
  isChecked: boolean = true;
  valuepast = true;
  valuelate = true;
  valueapproval = true;
  valueontime = true;
  // sortBy: number = 1;
  order: number = 16;
  filteredArray: any[] = []; countData: any;
  // checkedCount: any;
  onTimeCountNum: any;
  lateWithApprovalCountNum: any;
  lateCountNum: any;
  latePast45DaysCountNum: any;
  checkTileCount: any = [];
  ontimecountpercent: number;
  latewithapprovalpercent: number;
  latecountpercent: number;
  last45dayspercent: number;
  checkTileLength: any = [];
  selectedColValue: string = '';
  complianceMetricYearDataFrom: any;
  complianceMetricYearDataTo: any;

  constructor(private archiveService: ArchiveService, private homePageService: HomePageService, private adalSvc: MsAdalAngular6Service,
    private sharedService: SharedService, private notifier: NotifierService, private router: Router) {
    // this.SpinnerService.show();
  }

  ngOnInit() {
    let complianceMetricYearData = JSON.parse(localStorage.getItem('dashboardCountData'));
    complianceMetricYearData.complianceMetricsForUser.filter((x) => {
      if(x.category == 'ComplianceMetrics'){
        this.complianceMetricYearDataFrom = x.dateFromYear;
        this.complianceMetricYearDataTo = x.dateToYear;
      }
    })
    this.filterText = this.filteredArray.toString();
    this.employeeUniqueIdentifier = this.adalSvc.LoggedInUserEmail.split('@')[0];
    this.getArchives();
    this.getArchivesOnLoad();
    this.employeeUniqueIdentifier = this.adalSvc.LoggedInUserEmail.split('@')[0];
    this.homePageService.GetArchiveAccessRequestCountForDashboard().subscribe((data) => {
      data.complianceMetricsForUser.forEach((ele) => {
        if (ele.category == "ArchivesAwaitingApprovals") {
          if (ele.count == 0) {
            this.disableBack();
          } else {
            return false;
          }
        }
      })
      // if( this.countForAccessRequests.length == 0) {
      //   this.disableBack();
      // }
    });
  }
  getArchivesOnLoad() {
    // this.SpinnerService.show();
    this.archiveService.GetComplianceMetrics(this.currentPageNumber, this.pageSize, this.order, this.filterText).subscribe(
      data => {
        this.complianceMetricData = data;
        if(this.complianceMetricData.length == 0) {
          let element = document.getElementById("initialapproval_metric");
        element.classList.remove("selected-columnmetric");
        }
        if (this.complianceMetricData.length > 0) {
          this.onTimeCountNum = this.complianceMetricData[0].onTimeCount;
          this.lateWithApprovalCountNum = this.complianceMetricData[0].lateWithApprovalCount;
          this.lateCountNum = this.complianceMetricData[0].lateCount;
          this.latePast45DaysCountNum = this.complianceMetricData[0].latePast45DaysCount;
          this.ontimecountpercent = Math.round((this.complianceMetricData[0].onTimeCount / this.complianceMetricData[0].countBeforeFiltering) * 100);
          this.latewithapprovalpercent = Math.round((this.complianceMetricData[0].lateWithApprovalCount / this.complianceMetricData[0].countBeforeFiltering) * 100);
          this.latecountpercent = Math.round((this.complianceMetricData[0].lateCount / this.complianceMetricData[0].countBeforeFiltering) * 100);
          this.last45dayspercent = Math.round((this.complianceMetricData[0].latePast45DaysCount / this.complianceMetricData[0].countBeforeFiltering) * 100);
          if (this.onTimeCountNum !== 0) {
            this.checkTileCount.push(this.onTimeCountNum);
            this.checkTileLength.push(this.onTimeCountNum);
          }
          if (this.lateWithApprovalCountNum !== 0) {
            this.checkTileCount.push(this.lateWithApprovalCountNum);
            this.checkTileLength.push(this.lateWithApprovalCountNum);
          }
          if (this.lateCountNum !== 0) {
            this.checkTileCount.push(this.lateCountNum);
            this.checkTileLength.push(this.lateCountNum);
          }
          if (this.latePast45DaysCountNum !== 0) {
            this.checkTileCount.push(this.latePast45DaysCountNum);
            this.checkTileLength.push(this.latePast45DaysCountNum);
          }
          // this.SpinnerService.hide();
        }
      }
    );
  }

  showArchiveDetails(archiveAccessRequestID, index) {
    if (this.archiveAccessRequestID == archiveAccessRequestID) {
      this.archiveAccessRequestID = '';
    }
    else {
      this.archiveAccessRequestID = archiveAccessRequestID;
    }
  }
  getArchives() {
    // this.SpinnerService.show();
    this.archiveService.GetComplianceMetrics(this.currentPageNumber, this.pageSize, this.order, this.filterText).subscribe(
      data => {
        this.complianceMetricData = data;
        if (this.appendArchiveToGrid && data) {
          this.archives = this.archives.concat(data);
        }
        else {
          this.archives = data ? data : [];
        }
        if (this.complianceMetricData.length > 0) {
          this.totalArchives = this.archives[0]["count"];
          setTimeout(() => {
            this.columnSelection();
          }, 100)
        }
        // console.log('array length', this.totalArchives);
        // this.SpinnerService.hide();
      }
    );
  }
  columnSelection() {
    if (this.selectedColValue !== '') {
      if (this.selectedColValue == 'archiveNumber') {
        let element = document.getElementById("archive_numberMetric");
        element.classList.add("selected-columnmetric");
        let element2 = document.getElementById("client_metric");
        element2.classList.remove("selected-columnmetric");
        let element3 = document.getElementById("archiveName_metric");
        element3.classList.remove("selected-columnmetric");
        let element4 = document.getElementById("periodend_metric");
        element4.classList.remove("selected-columnmetric");
        let element5 = document.getElementById("duedate_metric");
        element5.classList.remove("selected-columnmetric");
        let element6 = document.getElementById("initialapproval_metric");
        element6.classList.remove("selected-columnmetric");
        let element7 = document.getElementById("wbs_metric");
        element7.classList.remove("selected-columnmetric");
        let element8 = document.getElementById("compliancestatus_metric");
        element8.classList.remove("selected-columnmetric");
      }
      if (this.selectedColValue == 'clientName') {
        let element1 = document.getElementById("archive_numberMetric");
        element1.classList.remove("selected-columnmetric");
        let element = document.getElementById("client_metric");
        element.classList.add("selected-columnmetric");
        let element3 = document.getElementById("archiveName_metric");
        element3.classList.remove("selected-columnmetric");
        let element4 = document.getElementById("periodend_metric");
        element4.classList.remove("selected-columnmetric");
        let element5 = document.getElementById("duedate_metric");
        element5.classList.remove("selected-columnmetric");
        let element6 = document.getElementById("initialapproval_metric");
        element6.classList.remove("selected-columnmetric");
        let element7 = document.getElementById("wbs_metric");
        element7.classList.remove("selected-columnmetric");
        let element8 = document.getElementById("compliancestatus_metric");
        element8.classList.remove("selected-columnmetric");
      }
      if (this.selectedColValue == 'archiveName') {
        let element = document.getElementById("archiveName_metric");
        element.classList.add("selected-columnmetric");
        let element1 = document.getElementById("archive_numberMetric");
        element1.classList.remove("selected-columnmetric");
        let element2 = document.getElementById("client_metric");
        element2.classList.remove("selected-columnmetric");
        let element4 = document.getElementById("periodend_metric");
        element4.classList.remove("selected-columnmetric");
        let element5 = document.getElementById("duedate_metric");
        element5.classList.remove("selected-columnmetric");
        let element6 = document.getElementById("initialapproval_metric");
        element6.classList.remove("selected-columnmetric");
        let element7 = document.getElementById("wbs_metric");
        element7.classList.remove("selected-columnmetric");
        let element8 = document.getElementById("compliancestatus_metric");
        element8.classList.remove("selected-columnmetric");
      }
      if (this.selectedColValue == 'periodEnd') {
        let element = document.getElementById("periodend_metric");
        element.classList.add("selected-columnmetric");
        let element1 = document.getElementById("archive_numberMetric");
        element1.classList.remove("selected-columnmetric");
        let element2 = document.getElementById("client_metric");
        element2.classList.remove("selected-columnmetric");
        let element3 = document.getElementById("archiveName_metric");
        element3.classList.remove("selected-columnmetric");
        let element5 = document.getElementById("duedate_metric");
        element5.classList.remove("selected-columnmetric");
        let element6 = document.getElementById("initialapproval_metric");
        element6.classList.remove("selected-columnmetric");
        let element7 = document.getElementById("wbs_metric");
        element7.classList.remove("selected-columnmetric");
        let element8 = document.getElementById("compliancestatus_metric");
        element8.classList.remove("selected-columnmetric");
      }
      if (this.selectedColValue == 'estimatedIssuanceReportDate') {
        let element = document.getElementById("duedate_metric");
        element.classList.add("selected-columnmetric");
        let element1 = document.getElementById("archive_numberMetric");
        element1.classList.remove("selected-columnmetric");
        let element2 = document.getElementById("client_metric");
        element2.classList.remove("selected-columnmetric");
        let element3 = document.getElementById("archiveName_metric");
        element3.classList.remove("selected-columnmetric");
        let element4 = document.getElementById("periodend_metric");
        element4.classList.remove("selected-columnmetric");
        let element6 = document.getElementById("initialapproval_metric");
        element6.classList.remove("selected-columnmetric");
        let element7 = document.getElementById("wbs_metric");
        element7.classList.remove("selected-columnmetric");
        let element8 = document.getElementById("compliancestatus_metric");
        element8.classList.remove("selected-columnmetric");
      }
      if (this.selectedColValue == 'initialApproval') {
        let element = document.getElementById("initialapproval_metric");
        element.classList.add("selected-columnmetric");
        let element1 = document.getElementById("archive_numberMetric");
        element1.classList.remove("selected-columnmetric");
        let element2 = document.getElementById("client_metric");
        element2.classList.remove("selected-columnmetric");
        let element3 = document.getElementById("archiveName_metric");
        element3.classList.remove("selected-columnmetric");
        let element4 = document.getElementById("periodend_metric");
        element4.classList.remove("selected-columnmetric");
        let element5 = document.getElementById("duedate_metric");
        element5.classList.remove("selected-columnmetric");
        let element7 = document.getElementById("wbs_metric");
        element7.classList.remove("selected-columnmetric");
        let element8 = document.getElementById("compliancestatus_metric");
        element8.classList.remove("selected-columnmetric");
      }
      if (this.selectedColValue == 'wbsNumber') {
        let element = document.getElementById("wbs_metric");
        element.classList.add("selected-columnmetric");
        let element1 = document.getElementById("archive_numberMetric");
        element1.classList.remove("selected-columnmetric");
        let element2 = document.getElementById("client_metric");
        element2.classList.remove("selected-columnmetric");
        let element3 = document.getElementById("archiveName_metric");
        element3.classList.remove("selected-columnmetric");
        let element4 = document.getElementById("periodend_metric");
        element4.classList.remove("selected-columnmetric");
        let element5 = document.getElementById("duedate_metric");
        element5.classList.remove("selected-columnmetric");
        let element6 = document.getElementById("initialapproval_metric");
        element6.classList.remove("selected-columnmetric");
        let element8 = document.getElementById("compliancestatus_metric");
        element8.classList.remove("selected-columnmetric");
      }
      if (this.selectedColValue == 'complianceStatus') {
        let element = document.getElementById("compliancestatus_metric");
        element.classList.add("selected-columnmetric");
        let element1 = document.getElementById("archive_numberMetric");
        element1.classList.remove("selected-columnmetric");
        let element2 = document.getElementById("client_metric");
        element2.classList.remove("selected-columnmetric");
        let element3 = document.getElementById("archiveName_metric");
        element3.classList.remove("selected-columnmetric");
        let element4 = document.getElementById("periodend_metric");
        element4.classList.remove("selected-columnmetric");
        let element5 = document.getElementById("duedate_metric");
        element5.classList.remove("selected-columnmetric");
        let element6 = document.getElementById("initialapproval_metric");
        element6.classList.remove("selected-columnmetric");
        let element7 = document.getElementById("wbs_metric");
        element7.classList.remove("selected-columnmetric");
      }
    }
  }
  disableBack() {
    window.history.forward();
  }
  setOrder(value: string) {
    if (this.complianceMetricData.length > 0) {
      this.selectedColValue = value;
      this.resetPage();
      if (value == 'archiveNumber') {
        if (this.order == 1) {
          this.order = 2;
          this.getArchives();
        }
        else {
          this.order = 1;
          this.getArchives();
        }
      }
      if (value == 'clientName') {
        if (this.order == 3) {
          this.order = 4;
          this.getArchives();
        }
        else {
          this.order = 3;
          this.getArchives();
        }
      }
      if (value == 'archiveName') {
        if (this.order == 5) {
          this.order = 6;
          this.getArchives();
        }
        else {
          this.order = 5;
          this.getArchives();
        }
      }
      if (value == 'periodEnd') {
        if (this.order == 11) {
          this.order = 12;
          this.getArchives();
        }
        else {
          this.order = 11;
          this.getArchives();
        }
      }
      if (value == 'estimatedIssuanceReportDate') {
        if (this.order == 13) {
          this.order = 14;
          this.getArchives();
        }
        else {
          this.order = 13;
          this.getArchives();
        }
      }
      if (value == 'initialApproval') {
        if (this.order == 15) {
          this.order = 16;
          this.getArchives();
        }
        else {
          this.order = 15;
          this.getArchives();
        }
      }
      if (value == 'wbsNumber') {
        if (this.order == 9) {
          this.order = 10;
          this.getArchives();
        }
        else {
          this.order = 9;
          this.getArchives();
        }
      }
      if (value == 'complianceStatus') {
        if (this.order == 7) {
          this.order = 8;
          this.getArchives();
        }
        else {
          this.order = 7;
          this.getArchives();
        }
      }
    }
  }
  resetPage() {
    this.appendArchiveToGrid = false;
    this.currentPageNumber = 1;
    this.pageSize = 10;
    this.totalArchives = 0;
  }
  exportToExcel() {
    // this.SpinnerService.show();
    let columns = [
      'Archive #',
      'Client',
      'Archive Name',
      'Period End',
      'Due Date',
      'Initial Approval',
      'WBS #',
      'Compliance Status',
      'Engagement Type',
      'EDCD',
      'RDCD',
      'ADCED',
      'Is Resubmission in Progress ?',
      'Archive Description',
      'Entity associated with archive',
      'Professional Standards Applied',
      'Reporting Entity',
      'Archive Partner',
      'Archive Manager',
      'Archive Field Senior',
      'Additional Archive Field Senior',
    ];
    this.archiveService.GetComplianceMetrics(0, this.pageSize, this.order, this.filterText).subscribe((data) => {
      data.forEach(elm => {
        delete elm.count;
        delete elm.rowNumber;
        delete elm.onTimeCount;
        delete elm.lateWithApprovalCount;
        delete elm.lateCount;
        delete elm.latePast45DaysCount;
        delete elm.countBeforeFiltering;
      });
      // this.SpinnerService.hide();
      var result = data.map(o => Object.keys(o).map(k => o[k]));
      if (data && data.length) {
        this.sharedService.generateExcel("Compliance metrics", "Compliance metrics", columns, result);
      }
    },
      error => {
        console.log('Exception occured ' + JSON.stringify(error));
        // this.SpinnerService.hide();
      });

  }
  clearPageCount() {
    this.currentPageNumber = 1;
    this.pageCount = 1;
    this.pageArray = Array();
  }
  accessArchive(archiveNumber: string) {
    // this.SpinnerService.show();
    this.router.navigate(['/archive/myarchives', archiveNumber]);
  }

  updateGridData(event) {
    this.appendArchiveToGrid = event.isLoadMoreClicked;
    this.currentPageNumber = event.pageNumber;
    this.getArchives();
  }
  archiveID(event) {
    this.archiveIDForChild = event;
  }
  onChange(event, val, selectedText) {
    if (event == false) {
      this.checkTileCount.length = this.checkTileCount.length - 1;
      this.filteredArray.push(selectedText);
    } else {
      this.checkTileCount.length = this.checkTileCount.length + 1;
      if (this.checkTileLength.length !== this.filteredArray.length) {
        let index = this.filteredArray.indexOf(selectedText);
        this.filteredArray.splice(index, 1);
      } else {
        let index = this.filteredArray.indexOf(selectedText);
        this.filteredArray.splice(index, 1);
        return false;
      }
    }
    if (this.checkTileCount.length > 0) {
      this.filterText = this.filteredArray.toString();
      console.log(this.filteredArray.toString());
      this.isChecked = event;
      if (val == 1) {
        if (this.isChecked) {
          let element = document.getElementById("Compliance_OnTimeMetric");
          element.classList.remove("unselect-metrics");
        } else {
          let element = document.getElementById("Compliance_OnTimeMetric");
          element.classList.add("unselect-metrics");
        }
      }
      if (val == 2) {
        if (this.isChecked) {
          let element = document.getElementById("Compliance_LateApprovalMetric");
          element.classList.remove("unselect-metrics");
        } else {
          let element = document.getElementById("Compliance_LateApprovalMetric");
          element.classList.add("unselect-metrics");
        }
      }
      if (val == 3) {
        if (this.isChecked) {
          let element = document.getElementById("Compliance_LateMetric");
          element.classList.remove("unselect-metrics");
        } else {
          let element = document.getElementById("Compliance_LateMetric");
          element.classList.add("unselect-metrics");
        }
      }
      if (val == 4) {
        if (this.isChecked) {
          let element = document.getElementById("Compliance_PastDaysMetric");
          element.classList.remove("unselect-metrics");
        } else {
          let element = document.getElementById("Compliance_PastDaysMetric");
          element.classList.add("unselect-metrics");
        }
      }
      if (this.checkTileLength.length !== this.filteredArray.length) {
        this.resetPage();
        this.getArchives();
      } else {
        let index = this.filteredArray.indexOf(selectedText);
        this.filteredArray.splice(index, 1);
      }
    } else {
      event = true;
      if (val == 1) {
        setTimeout(() => {
          document.getElementById('employeecheck_ontime').click();
        }, 100);
      } else if (val == 2) {
        setTimeout(() => {
          document.getElementById('employeecheck_lateapproval').click();
        }, 100);
      }
      else if (val == 3) {
        setTimeout(() => {
          document.getElementById('employeecheck_late').click();
        }, 100);
      }
      else if (val == 4) {
        setTimeout(() => {
          document.getElementById('employeechecklastpast').click();
        }, 100);
      }
      this.notifier.notify("error", "At least one tile should be selected.");
      return false;
    }
  }

}

