﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.Models
{
    public class ArchiveSearchBaseModel
    {
        public string ClientNumber { get; set; }
        public string ClientID { get; set; }
        public string ClientName { get; set; }

        public string ArchiveNumber { get; set; }

        public string ArchiveName { get; set; }

        public string ArchiveCategory { get; set; }
        public string WBSClientName { get; set; }

        public string WbsLevelOneNumber { get; set; }

        public string WBSLevelOneDescription { get; set; }

        public DateTime WBSLevelOneDateCreated { get; set; }

        public int Count { get; set; }

        public string ArchivePartner { get; set; }

        public string ArchivePartnerAlias { get; set; }
    }
}
