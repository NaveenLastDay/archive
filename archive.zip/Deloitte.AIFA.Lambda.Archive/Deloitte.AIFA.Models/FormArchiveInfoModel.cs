﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DataModels
{
    public class FormArchiveInfoModel
    {
        public string ArchivePartner { get; set; }
        public string TypeOfEntity { get; set; }
        public DateTime EDCDDate { get; set; }
        public DateTime RDCDDate { get; set; }
    }
}
