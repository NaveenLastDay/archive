import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { NotifierService } from 'angular-notifier';
import { NgxSpinnerService } from 'ngx-spinner';
import { BatchDetailsInfo, DestructionBatch, DestructionBatchDetail, DestructionBatchRecordDetail, DestructionClientDetail } from '../../../../../models/batch-details.model';
import { DestructionService } from '../../../../../services/destruction.service';
import { SharedService } from '../../../../../services/shared.service';
import { Workbook } from 'exceljs';
import * as fs from 'file-saver';
import { ModalService } from '../../../../shared/modal';
import { DateTime } from 'aws-sdk/clients/devicefarm';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-destruction-process-showdetails',
  templateUrl: './destruction-process-showdetails.component.html',
  styleUrls: ['./destruction-process-showdetails.component.css']
})
export class DestructionProcessShowdetailsComponent implements OnInit {
  myBatchAdvancedSearchForm: FormGroup;
  batchID: string;
  /*sorting */
  sortColumnDialog: number = -1;
  sortColumn: string = 'DestructionEligibleDate'
  sortascdesc: number = 0;
  sortBy: number = 0;
  currentPageNumber: number = 1;
  readonly pageSize: number = 100;
  IsSimpleSearch: number = 0;

  batchDetailInfoList = new BatchDetailsInfo();
  destructionBatch = new DestructionBatch();
  destructionClientDetail = new DestructionClientDetail();
  destructionBatchDetail = new DestructionBatchDetail();
  destructionRecordDetail = new DestructionBatchRecordDetail();
  batchArchiveObjects: any[];
  totalBatchsRecords: number = 0;
  hoverIndex: number = -1;
  archiveNumber: string;
  limitObjNumber: number = 5;
  limitBatchObjNumber: number = 10;
  ascUniqueIdSort = true;
  selectedArchives: any = [];
  masterSelected: boolean = false;
  inEligibleArchives: any[];
  batchSimpleText: string;
  showSearchContent: boolean = false;
  AddClientText: string = '';
  searchDistEligibleDateShow: boolean = false;
  DestrElgStartDate: string;
  DestrElgEndDate: string;
  DestructionEligibleFullDate: string;
  disableBtn: boolean = false;
  selectedRecordStatus: number[] = [];
  advSelectedHoldFlag: number = -1;
  advSelectedLinkedArchive: number = -1;
  advSelectedRetentionException: number = -1;
  selectedClient: string = '';
  selectedHolds: Array<any> = [];
  clients: Array<any> = [];
  index: number = 0;
  searchArchiveNumber: string = '';
  simpleSearch: string = '';
  showElgibleArchives: boolean = false;
  TileName: string = 'EPRTile';
  EligibleArchivesCount: number = 0;
  EligibleArchivesObjCount: number = 0;
  searchUniqueID: string = '';
  simpleSearchText: string = '';
  showInElgibleArchives: number = 0;
  destructionEligibleFromToDate: string;
  inEligibleArchivesCount: number = 0;
  showBulkRemoval: boolean = false;
  batchDetailsID: number;
  isUpdateGridData: boolean;
  removeArchive: string;
  removeTextMessage: string;
  archiveCheckAll: boolean = false;
  isERecordsClicked: boolean = true;
  isPRecordsClicked: boolean = true;
  columnByEnum: any = BatcheDetailColumnBy;
  isHRecordsClicked: boolean = true;
  showObjectsDestruction: boolean = false;
  count: number = 0;
  count1: number = 0;
  count2: number = 0;
  subBatchCount:number = 0;
  subBatchNumber:string='';
  isSubBatchCreateEnable:boolean=false;
  BatchProcessDetailsGridColumns: any = BatchProcessDetailsGridColumns;
  readonly emptyStringInExcel: string = " ";
  columnFilters: any[] =
    [
      {
        "displayName": "Client",
        "value": this.BatchProcessDetailsGridColumns.Client,
        "checked": true
      },
      {
        "displayName": "Archive #",
        "value": this.BatchProcessDetailsGridColumns.ArchiveNumber,
        "checked": true
      },
      {
        "displayName": "Destruction eligible date",
        "value": this.BatchProcessDetailsGridColumns.DestructionEligibleDate,
        "checked": true
      },
      {
        "displayName": "Retention exception triggered date",
        "value": this.BatchProcessDetailsGridColumns.RetentionExceptionTriggerDate,
        "checked": true
      },

      {
        "displayName": "Hold flag",
        "value": this.BatchProcessDetailsGridColumns.HoldFlag,
        "checked": true
      },
      {
        "displayName": "Unique ID",
        "value": this.BatchProcessDetailsGridColumns.UniqueID,
        "checked": true
      },
      {
        "displayName": "Barcode",
        "value": this.BatchProcessDetailsGridColumns.Barcode,
        "checked": true
      },
      {
        "displayName": "Hard copy record status",
        "value": this.BatchProcessDetailsGridColumns.Hardcopyrecordstatus,
        "checked": true
      },
      {
        "displayName": "Electronic record status",
        "value": this.BatchProcessDetailsGridColumns.Electronicrecordstatus,
        "checked": true
      },

    ]
  /* end of Export to Excel */
  constructor(private fb: FormBuilder, private sharedService: SharedService, private _datepipe: DatePipe, private _notifierService: NotifierService, private modalService: ModalService, private SpinnerService: NgxSpinnerService, private activatedRoute: ActivatedRoute, private _destService: DestructionService) {
    this.myBatchAdvancedSearchForm = fb.group({
      'inputClientName': [null, Validators.required],
      'inputUniqueID': [null, Validators.required],
      'DestEligibleDate': [null, Validators.required],
      'recordStatuscheckboxgroup': [null, Validators.required],
      'retentionExceptionRadioGroup': [-1, Validators.required],
      'holdRadioGroup': [-1, Validators.required],
      'linkedArchiveRadioGroup': [-1, Validators.required]
    });
  }

  ngOnInit() {
    this.batchID = this.activatedRoute.snapshot.paramMap.get('batchId');
    this.selectedRecordStatus = [1, 2, 3, 5, 6];
    localStorage.clear();
    this.getBatchData(this.TileName);
  }
  getBatchData(tileName) {
    this._destService.GetBatchDetailInfobybatchid(this.batchID, this.currentPageNumber, this.pageSize, this.sortBy, this.sortColumn, this.IsSimpleSearch, this.simpleSearch,
      this.searchArchiveNumber, this.selectedClient, this.searchUniqueID, "1/1/1111", this.selectedRecordStatus.toString(),
      this.advSelectedRetentionException, this.advSelectedHoldFlag, this.advSelectedLinkedArchive, this.showElgibleArchives, tileName).subscribe(
        data => {
          //debugger;
          if (data) {
            this.batchDetailInfoList = data ? data : [];
            this.destructionBatch = this.batchDetailInfoList.batch;
            this.destructionClientDetail = data["clientDetails"];
            this.destructionEligibleFromToDate = this._datepipe.transform(data.batch.destructionEligibleFromDate, 'MM/dd/yyyy') + " - " + this._datepipe.transform(data.batch.destructionEligibleToDate, 'MM/dd/yyyy');
            localStorage.setItem('batchInfoBarData', JSON.stringify(this.destructionBatch));
            this.EligibleArchivesCount = data["eligibleArchivesCount"];
            this.EligibleArchivesObjCount = data["eligibleArchivesObjCount"]
            this.totalBatchsRecords = data["totalRecords"];
            this.subBatchCount = data["subBatchCount"];
            this.isSubBatchCreateEnable = data["isSubBatchCreate"];

            this.batchDetailInfoList.clientDetails.forEach(eclient => {
              this.count = 0;
              eclient.clientRowSpan = eclient.batchDetails.length
              eclient.batchDetails.forEach(earchive => {
                this.count = this.count + earchive.destructionBatchRecordDetail.length

              })
              eclient.clientRowSpan = eclient.clientRowSpan + this.count;
            })
            // if (this.showSearchContent == true) {
            //   this.showSearchContent = false;
            // }
           // this.sortUniqueIDColumn();
            if(this.subBatchNumber){
            this._notifierService.notify(
              "success",
              "Sub-batch (" + this.subBatchNumber + ") created"
            );
            this.subBatchNumber = '';
          }
          }
          this.SpinnerService.hide();
        });
  }
  toggleAdvancedSearch() {
    this.showSearchContent = !this.showSearchContent;
  }
  userSelectedHoldStatus(value: number, SectionName: string) {
    if (SectionName == "Hold") {
      this.advSelectedHoldFlag = value;
    }
    else if (SectionName == "LinkedArchive") {
      this.advSelectedLinkedArchive = value;
    }

  }
  ResetAdvFields() {
  
    this.myBatchAdvancedSearchForm.controls.retentionExceptionRadioGroup.patchValue(-1);
    this.myBatchAdvancedSearchForm.controls.holdRadioGroup.patchValue(-1);
    this.myBatchAdvancedSearchForm.controls.linkedArchiveRadioGroup.patchValue(-1);
    this.myBatchAdvancedSearchForm.controls.recordStatuscheckboxgroup.patchValue(true);
    this.searchArchiveNumber = '';
    this.selectedClient = '';
    this.IsSimpleSearch = 0;
    this.selectedRecordStatus = [1, 2, 3, 5, 6];
    this.advSelectedLinkedArchive = -1;
    this.advSelectedRetentionException = -1;
    this.advSelectedHoldFlag = -1;
    this.currentPageNumber = 1;
    this.getBatchData(this.TileName);
  }
  UserSelectedRecordStatus(event) {
    if (event.target.checked == true) {
      this.selectedRecordStatus.push(parseInt(event.target.value));
    }
    else {
      var index = this.selectedRecordStatus.indexOf(parseInt(event.target.value));
      this.selectedRecordStatus.splice(index, 1);
    }
    console.log(this.selectedRecordStatus);
  }
  generateReportClicked(data1) {
    let BatchDetailsReport: any[] = [];
    let filterdColumns = (data1.filter(x => x.checked));
    if (!this.isPRecordsClicked) {
      let index = filterdColumns.findIndex(item => item.displayName == "Hard copy record status");
      filterdColumns.splice(index, 1);
    }
    if (!this.isERecordsClicked) {
      let index = filterdColumns.findIndex(item => item.displayName == "Electronic record status");
      filterdColumns.splice(index, 1);
    }

    this._destService.GetDestructionProcessExport(this.batchID, 0, 0, this.sortBy, this.sortColumn, this.IsSimpleSearch, this.simpleSearch,
      this.searchArchiveNumber, this.selectedClient, this.searchUniqueID, "1/1/1111", this.selectedRecordStatus.toString(),
      this.advSelectedRetentionException, this.advSelectedHoldFlag, this.advSelectedLinkedArchive, this.showElgibleArchives, 1, this.TileName).subscribe(
        data => {
          if (data) {
            if (data.length > 0) {
              data.forEach(element => {
                let Batch = {};
                filterdColumns.forEach(column => {

                  if (column["value"] == this.BatchProcessDetailsGridColumns.Client) { //Client
                    Batch[this.BatchProcessDetailsGridColumns[this.BatchProcessDetailsGridColumns.Client]] = element.clientName || this.emptyStringInExcel;
                  }
                  if (column["value"] == this.BatchProcessDetailsGridColumns.ArchiveNumber) { //Archive#
                    Batch[this.BatchProcessDetailsGridColumns[this.BatchProcessDetailsGridColumns.ArchiveNumber]] = element.archiveNumber || this.emptyStringInExcel;
                  }
                  if (column["value"] == this.BatchProcessDetailsGridColumns.DestructionEligibleDate) { //Destruction Eligible date
                    Batch[this.BatchProcessDetailsGridColumns[this.BatchProcessDetailsGridColumns.DestructionEligibleDate]] = this._datepipe.transform(element.destructionEligibleDate, 'MM/dd/yyyy') || this.emptyStringInExcel;
                  }
                  if (column["value"] == this.BatchProcessDetailsGridColumns.RetentionExceptionTriggerDate) { //Retention trigger date
                    Batch[this.BatchProcessDetailsGridColumns[this.BatchProcessDetailsGridColumns.RetentionExceptionTriggerDate]] = this._datepipe.transform(element.retentionExceptionTriggerDate, 'MM/dd/yyyy') || this.emptyStringInExcel;
                  }
                  if (column["value"] == this.BatchProcessDetailsGridColumns.HoldFlag) { //HoldFlag
                    Batch[this.BatchProcessDetailsGridColumns[this.BatchProcessDetailsGridColumns.HoldFlag]] = element.holdsApplied || this.emptyStringInExcel;
                  }
                  if (column["value"] == this.BatchProcessDetailsGridColumns.UniqueID) { //UniqueID
                    Batch[this.BatchProcessDetailsGridColumns[this.BatchProcessDetailsGridColumns.UniqueID]] = element.uniqueID || this.emptyStringInExcel;
                  }
                  if (column["value"] == this.BatchProcessDetailsGridColumns.Barcode) { //Barcode
                    Batch[this.BatchProcessDetailsGridColumns[this.BatchProcessDetailsGridColumns.Barcode]] = element.barCode || this.emptyStringInExcel;
                  }
                  if (column["value"] == this.BatchProcessDetailsGridColumns.Hardcopyrecordstatus) { //Hardcopyrecordstatus
                    Batch[this.BatchProcessDetailsGridColumns[this.BatchProcessDetailsGridColumns.Hardcopyrecordstatus]] = element.hardCopyRecordStatus || this.emptyStringInExcel;
                  }
                  if (column["value"] == this.BatchProcessDetailsGridColumns.Electronicrecordstatus) { //Electronicrecordstatus
                    Batch[this.BatchProcessDetailsGridColumns[this.BatchProcessDetailsGridColumns.Electronicrecordstatus]] = element.electronicRecordStatus || this.emptyStringInExcel;
                  }
                });
                BatchDetailsReport.push(Batch);
              });
              if (BatchDetailsReport && BatchDetailsReport.length) {
                this.sharedService.generateExcel(this.batchID + "_BatchProcess_Details", "BatchDetails", filterdColumns.map(x => x.displayName), BatchDetailsReport);
              }
            }
          }

        });
  }

  generateExcel(fileName: string, sheetName: string, columns: string[], data: any[]) {
    //debugger;
    let workbook = new Workbook();
    let worksheet = workbook.addWorksheet(sheetName, {
      views: [
        { state: 'frozen', ySplit: 1 }
      ]
    });
    let topRow = worksheet.addRow(columns);
    // topRow.font = {
    //   name: 'Calibri',
    //   size: 16,
    //   underline: 'single',
    //   bold: true,
    //   color: { argb: '0085A3' }
    // }
    topRow.font = {
      bold: true,
    }
    topRow.eachCell(
      cell => {
        cell.border = {
          top: { style: 'thin' },
          left: { style: 'thin' },
          bottom: { style: 'thin' },
          right: { style: 'thin' }
        };
        cell.alignment = {
          vertical: 'top',
          horizontal: 'left',
          wrapText: true
        }
      }
    );

    data.forEach(d => {
      //console.log(d);
      let row = worksheet.addRow(Object.values(d));
      row.alignment = { vertical: 'top', horizontal: 'left', wrapText: true };
      row.eachCell(
        cell => {
          cell.border = {
            top: { style: 'thin' },
            left: { style: 'thin' },
            bottom: { style: 'thin' },
            right: { style: 'thin' }
          };
          cell.alignment = {
            vertical: 'top',
            horizontal: 'left',
            wrapText: true
          }
        }
      )
    });

    workbook.xlsx.writeBuffer().then((x) => {
      let blob = new Blob([x], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      fs.saveAs(blob, fileName + '.xlsx');
      this.SpinnerService.hide();
    })

  }

  Onclicktile(tilename) {
    if (tilename == "ERTile") {
      this.isERecordsClicked = true;
      this.isPRecordsClicked = false;
      this.TileName = tilename;
      this.getBatchData(this.TileName);
    }
    else if (tilename == "PRTile") {
      this.isPRecordsClicked = true;
      this.isERecordsClicked = false;
      this.TileName = tilename;
      this.getBatchData(this.TileName);
    }
    else {
      this.isPRecordsClicked = true;
      this.isERecordsClicked = true;
      this.TileName = tilename;
      this.getBatchData(this.TileName);
    }
  }

  SearchByeligibleRecords(event) {
    this.currentPageNumber = 1;
    if (event.target.checked == true) {
      this.showElgibleArchives = true;
      this.showObjectsDestruction = true;
      this.getBatchData('EPRTile');
      this.isPRecordsClicked = true;
      this.isERecordsClicked = true;
    }

    else {
      this.showElgibleArchives = false;
      this.showObjectsDestruction = false;
      //this.getBatchData(this.TileName);
      this.Onclicktile(this.TileName)
    }
  }
  sortHeaderASCDESC(event, directionType?: string) {
    var clickedColumn: number = event;
    //  this.isClientSort = false;
    /*For ArchiveNumber*/
    if (clickedColumn == 1 && this.sortBy != 1) {
      this.sortBy = 1;
      this.sortColumn = "Client";
      this.sortascdesc = 1;
    }
    else if (clickedColumn == 1 && this.sortBy == 1) {
      this.sortBy = 0;
      this.sortColumn = "Client";
      this.sortascdesc = 0;
    }
    /*for  ArchiveNumber */
    else if (clickedColumn == 2 && this.sortBy != 2) {
      this.sortBy = 2;
      this.sortColumn = "ArchiveNumber";
      this.sortascdesc = 0;
    }
    else if (clickedColumn == 2 && this.sortBy == 2) {
      this.sortBy = 0;
      this.sortColumn = "ArchiveNumber";
      this.sortascdesc = 1;
    }
    /*for DestructionEligibleToDate */
    else if (clickedColumn == 3 && this.sortBy != 3) {
      this.sortBy = 3;
      this.sortColumn = "DestructionEligibleDate";
      this.sortascdesc = 0;
    }
    else if (clickedColumn == 3 && this.sortBy == 3) {
      this.sortBy = 0;
      this.sortColumn = "DestructionEligibleDate";
      this.sortascdesc = 1;
    }
    /*for RetentionExceptionTriggredDate */
    else if (clickedColumn == 4 && this.sortBy != 4) {
      this.sortBy = 4;
      this.sortColumn = "RetentionExceptionTriggeredDate";
      this.sortascdesc = 0;
    }
    else if (clickedColumn == 4 && this.sortBy == 4) {
      this.sortBy = 0;
      this.sortColumn = "RetentionExceptionTriggeredDate";
      this.sortascdesc = 1;
    }/*for HoldApplied */
    else if (clickedColumn == 5 && this.sortBy != 5) {
      this.sortBy = 5;
      this.sortColumn = "HoldApplied";
      this.sortascdesc = 1;
    }
    else if (clickedColumn == 5 && this.sortBy == 5) {
      this.sortBy = 0;
      this.sortColumn = "HoldApplied";
      this.sortascdesc = 0;
    }
    else if (clickedColumn == 6 && this.sortBy != 6) {
      this.sortBy = 6;
      this.sortColumn = "UniqueID";
      this.sortascdesc = 0;
    }
    else if (clickedColumn == 6 && this.sortBy == 6) {
      this.sortBy = 0;
      this.sortColumn = "UniqueID";
      this.sortascdesc = 1;
    }
    else if (clickedColumn == 7 && this.sortBy != 7) {
      this.sortBy = 7;
      this.sortColumn = "Barcode";
      this.sortascdesc = 0;
    }
    else if (clickedColumn == 7 && this.sortBy == 7) {
      this.sortBy = 0;
      this.sortColumn = "Barcode";
      this.sortascdesc = 1;
    }
    else if (clickedColumn == 8 && this.sortBy != 8) {
      this.sortBy = 8;
      this.sortColumn = "PRStatus";
      this.sortascdesc = 0;
    }
    else if (clickedColumn == 8 && this.sortBy == 8) {
      this.sortBy = 0;
      this.sortColumn = "PRStatus";
      this.sortascdesc = 1;
    }
    else if (clickedColumn == 9 && this.sortBy != 9) {
      this.sortBy = 9;
      this.sortColumn = "ERStatus";
      this.sortascdesc = 0;
    }
    else if (clickedColumn == 9 && this.sortBy == 9) {
      this.sortBy = 0;
      this.sortColumn = "ERStatus";
      this.sortascdesc = 1;
    }
    this.currentPageNumber = 1;
    this.getBatchData(this.TileName);
  }

  updateGridData(event, basicBatchData) {
    this.isUpdateGridData = event.isLoadMoreClicked;
    this.currentPageNumber = event.pageNumber;
    if (basicBatchData) {
      this._destService.GetBatchDetailInfobybatchid(this.batchID, this.currentPageNumber, this.pageSize, this.sortBy, this.sortColumn, this.IsSimpleSearch, this.simpleSearch,
        this.searchArchiveNumber, this.selectedClient, this.searchUniqueID, "1/1/1111", this.selectedRecordStatus.toString(),
        this.advSelectedRetentionException, this.advSelectedHoldFlag, this.advSelectedLinkedArchive, this.showElgibleArchives, this.TileName).subscribe(
          data => {
            if (this.isUpdateGridData && data) {
              for (var i = 0; i < data["clientDetails"].length; i++) {

                this.count = 0;
                this.batchDetailInfoList.clientDetails.forEach(element1 => {
                  if (data["clientDetails"][i].clientName == element1.clientName) {
                    this.count++;
                  }

                })
                if (this.count == 0) {
                  this.batchDetailInfoList.clientDetails.push(data["clientDetails"][i]);
                }
                else {
                  this.count1 = 0;
                  this.batchDetailInfoList.clientDetails.forEach(element2 => {
                    if (data["clientDetails"][i].clientName == element2.clientName) {

                      for (var j = 0; j < data["clientDetails"][i]["batchDetails"].length; j++) {
                        element2.batchDetails.forEach(element4 => {
                          if (data["clientDetails"][i]["batchDetails"][j].archiveNumber == element4.archiveNumber) {
                            this.count1++;
                          }
                        })
                        if (this.count1 == 0) {
                          element2.batchDetails.push(data["clientDetails"][i]["batchDetails"][j]);
                        }
                        else {
                          this.count2 = 0;
                          element2.batchDetails.forEach(element4 => {
                            if (data["clientDetails"][i]["batchDetails"][j].archiveNumber == element4.archiveNumber) {
                              for (var k = 0; k < data["clientDetails"][i]["batchDetails"][j]["destructionBatchRecordDetail"].length; k++) {
                                element4.destructionBatchRecordDetail.forEach(erecord => {
                                  if (erecord.uniqueID == data["clientDetails"][i]["batchDetails"][j]["destructionBatchRecordDetail"][k].uniqueID) {
                                    this.count2++;
                                  }
                                })
                                if (this.count2 == 0) {
                                  element4.destructionBatchRecordDetail.push(data["clientDetails"][i]["batchDetails"][j]["destructionBatchRecordDetail"][k]);
                                }
                              }
                            }
                          })

                        }

                      }
                    }
                  })

                }
              }
              this.batchDetailInfoList.clientDetails.forEach(eclient => {
                this.count = 0;
                eclient.clientRowSpan = eclient.batchDetails.length
                eclient.batchDetails.forEach(earchive => {
                  this.count = this.count + earchive.destructionBatchRecordDetail.length

                })
                eclient.clientRowSpan = eclient.clientRowSpan + this.count;
              })

              this.EligibleArchivesCount = data["EligibleArchivesCount"];
              this.totalBatchsRecords = data["totalRecords"];
              this.sortUniqueIDColumn();
            }
            else {
              document.getElementById('appRootScroll').scrollTop = 0;
              this.batchDetailInfoList.clientDetails = data["clientDetails"];
              this.EligibleArchivesCount = data["EligibleArchivesCount"];
              this.totalBatchsRecords = data["totalRecords"];
              this.batchDetailInfoList.clientDetails.forEach(eclient => {
                this.count = 0;
                eclient.clientRowSpan = eclient.batchDetails.length
                eclient.batchDetails.forEach(earchive => {
                  this.count = this.count + earchive.destructionBatchRecordDetail.length
                })
                eclient.clientRowSpan = eclient.clientRowSpan + this.count;
              })
              this.sortUniqueIDColumn();
            }
            this.SpinnerService.hide();
          });
    }
  }
  public sortUniqueIDColumn() {
    console.log("Sort calling.. " + this.index)
    this.ascUniqueIdSort = !this.ascUniqueIdSort;
    if (this.ascUniqueIdSort) {
      this.batchDetailInfoList.batchDetails[this.index].destructionBatchRecordDetail.sort((a, b) => a.uniqueID.localeCompare(b.uniqueID)); // For ascending sort
    } else {
      this.batchDetailInfoList.batchDetails[this.index].destructionBatchRecordDetail.sort((a, b) => b.uniqueID.localeCompare(a.uniqueID)); // For descending sort
    }
  }
  createSubBatch() {
    var parameters = {
      "BatchNumber": this.batchID,
      "DestructionEligibleFromDate": this.destructionBatch.destructionEligibleFromDate,
      "DestructionEligibleToDate": this.destructionBatch.destructionEligibleToDate,
      "BusinessID": this.destructionBatch.businessID
    }
    this._destService.createSubBatch(parameters).subscribe(data => {
      if (data) {
        this.currentPageNumber = 1;
        this.getBatchData(this.TileName);
        this.subBatchNumber = data[0].subBatchNumber;
      }
      else{
        this._notifierService.notify(
          "error",
          "Error occured while Sub-batch create"
        );
        this.SpinnerService.hide();
        }
    });
  }

  SelectedRetentionException(e) {
    console.log(e.target.id);
    if (e.target.id == 'showall')
      this.advSelectedRetentionException = BatchRetentionException.ShowAll;
    else if (e.target.id == 'applied')
      this.advSelectedRetentionException = BatchRetentionException.Applied;
    else
      this.advSelectedRetentionException = BatchRetentionException.NotApplied;
    this.myBatchAdvancedSearchForm.controls.retentionExceptionRadioGroup.patchValue(this.advSelectedRetentionException);
  }
  SelectedLinkedArchive(e) {
    console.log(e.target.id);
    if (e.target.id == 'showall')
      this.advSelectedLinkedArchive = BatchLinkedArchive.ShowAll;
    else if (e.target.id == 'linked')
      this.advSelectedLinkedArchive = BatchLinkedArchive.Linked;
    else
      this.advSelectedLinkedArchive = BatchLinkedArchive.NotLinked;
    this.myBatchAdvancedSearchForm.controls.linkedArchiveRadioGroup.patchValue(this.advSelectedLinkedArchive);
  }
  SelectedHoldFlag(e) {
    console.log(e.target.id);
    if (e.target.id == 'showall')
      this.advSelectedHoldFlag = BatchHoldFlag.ShowAll;
    else if (e.target.id == 'applied')
      this.advSelectedHoldFlag = BatchHoldFlag.Applied;
    else
      this.advSelectedHoldFlag = BatchHoldFlag.NotApplied;
    this.myBatchAdvancedSearchForm.controls.holdRadioGroup.patchValue(this.advSelectedHoldFlag);
  }
  onSimpleSearch(searchValue: string,) {
    this.currentPageNumber = 1;
    this.simpleSearch = searchValue;
    if (this.simpleSearch)
      this.IsSimpleSearch = 1;
    else
      this.IsSimpleSearch = 0;
    this.getBatchData(this.TileName);
  }
}
export enum BatchProcessDetailsGridColumns {
  Client = 1,
  ArchiveNumber = 2,
  DestructionEligibleDate = 3,
  RetentionExceptionTriggerDate = 4,
  HoldFlag = 5,
  UniqueID = 6,
  Barcode = 7,
  Hardcopyrecordstatus = 8,
  Electronicrecordstatus = 9
}
export enum BatcheDetailColumnBy {
  ColumnBy_Default = -1,
  ColumnBy_ClientName = 1,
  ColumnBy_ArchiveNumber = 2,
  ColumnBy_DestructionEligibleFromDate = 3,
  ColumnBy_RetentionExcTriggredDate = 4,
  ColumnBy_HoldApplied = 5,
  ColumnBy_UniqueID = 6,
  ColumnBy_Barcode = 7,
  ColumnBy_PRStatus = 8,
  ColumnBy_ERStatus = 9
}
export enum BatchLinkedArchive {
  ShowAll = -1,
  Linked = 1,
  NotLinked = 0
}
export enum BatchRetentionException {
  ShowAll = -1,
  Applied = 1,
  NotApplied = 0
}
export enum BatchHoldFlag {
  ShowAll = -1,
  Applied = 1,
  NotApplied = 0
}