﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DataModels
{
    public class BindersSectionStatusCheckModel
    {
        public string bindescription { get; set; }
        public string createdBy { get; set; }
    }
}
