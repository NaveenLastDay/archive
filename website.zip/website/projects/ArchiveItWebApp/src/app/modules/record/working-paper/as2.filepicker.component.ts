import { Component, OnInit, ElementRef, ViewChild } from "@angular/core";
import { HttpClient } from '@angular/common/http';
import xml2js from "xml2js";

declare const zip: any;

@Component({
  selector: "as2-filepicker",
  templateUrl: "./as2.filepicker.component.html"

})
export class As2FilepickerComponent implements OnInit {
  title = "read-xml-angular8";
  public xmlItems: any;
  folderTitle: string = "";
  lastEdit: string = "";
  fileName: string = "";
  fileNameArray = [];

  constructor(private _http: HttpClient) {
    zip.workerScriptsPath = "assets/zipjs/";
    // this.loadXML();
    //this.xmltojsonConvert();
  }
  @ViewChild("zipfile", { static: true }) zipfile: ElementRef;
  ngOnInit() {
    var self = this;
    function readEntries(entries) {
      for (var i = 0; i < entries.length; i++) {
        if (entries[i].filename == "INDEX.XML") {
          entries[i].getData(new zip.TextWriter(), function (text) {
            // text contains the entry data as a String

            

            var ft1 = text.indexOf('<FolderTitle>');
            var ft2 = text.indexOf("</FolderTitle>");
            var ft = text.substring(ft1, ft2)
            if (ft) ft = ft.replace('<FolderTitle>', '');

            var le1 = text.indexOf('<LastEdit>');
            var le2 = text.indexOf("</LastEdit>");
            var le = text.substring(le1, le2)
            if (le) le = le.replace('<LastEdit>', '');

            self.fileName = ft + " " + le;
            self.fileNameArray.push(self.fileName);
           
            // close the zip reader
          });
        }
      }
    }
    zip.workerScriptsPath = "assets/zipjs/";
    // zip.useWebWorkers = false; //explicitly include (required) zip-workers ['zip.js','zip-fs.js','z-worker.js','inflate.js','deflate.js']
    // zip.workerScriptsPath = "assets";
    //var fileInput = document.getElementById("zipfile"); //Input File
    this.zipfile.nativeElement.onchange = function (evt) {
      for (var i = 0; i < evt.target.files.length; i++) {
        zip.createReader(
          new zip.BlobReader(evt.target.files[i]),
          function (zipReader) {
            zipReader.getEntries(readEntries);
          },
          function (error) {
            console.log(error);
          }
        );
      }
    };
  }
}
