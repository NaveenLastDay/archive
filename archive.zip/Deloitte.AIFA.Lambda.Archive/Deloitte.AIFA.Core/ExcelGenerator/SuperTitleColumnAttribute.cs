﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.Helpers.ExcelGenerator
{
    public class SuperTitleColumnAttribute : Attribute
    {
        public SuperTitleColumnAttribute(string title, CellColor color)
        {
            Title = title;
            Color = color;
        }

        public string Title { get; set; }

        public CellColor Color { get; set; }
    }

}
