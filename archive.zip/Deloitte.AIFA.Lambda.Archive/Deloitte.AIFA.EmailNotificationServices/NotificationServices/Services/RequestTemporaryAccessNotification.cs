﻿using Deloitte.AIFA.DomainEntities;
using Deloitte.AIFA.DomainEntities.EmailEntities;
using Deloitte.AIFA.EmailNotificationServices.NotificationEntities;
using Deloitte.AIFA.EmailNotificationServices.NotificationServices.Interfaces;
using Deloitte.AIFA.IRepositories;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.EmailNotificationServices.NotificationServices.Services
{
    public class RequestTemporaryAccessNotification : IRequestTemporaryAccessNotification
    {
        IUserRepository _userRepository;
        ILogger _logger;        
       
        public RequestTemporaryAccessNotification(                              
                                )        {
           
        }
        public BaseEmailEntity GetTemporaryAceessGrantedNotification(string argOperationType,string argOperationDescription, string argTemplateId,string otherInfo)
        {
            BaseEmailEntity objTAG = new BaseEmailEntity();

           


            return objTAG;
        }

        public BaseEmailEntity GetTemporaryAceessRaisedNotification(string argOperationType, string argOperationDescription, string argTemplateId, RequestTemporaryArchiveAccess argRTA,InsertArchiveAccessRequest IA)
        {
            BaseEmailEntity objTAR = new BaseEmailEntity();
            //Build Tag Values
            objTAR.MinimumTagValues = new Dictionary<string, string>();
            //ArchiveNumber for Subject
            objTAR.MinimumTagValues.Add(EmailPlaceholders.ArchiveNumber, argRTA.ArchiveNumber);
            //Requestor FirstName for Body

           
            if (!string.IsNullOrEmpty(argRTA.RequestedBy) )
            {
                //if(IA.RequestedByName.Contains(","))
                //objTAR.MinimumTagValues.Add(EmailPlaceholders.RequestorFirstName, IA.RequestedByName.Split(',')[0]);
                //else
                    objTAR.MinimumTagValues.Add(EmailPlaceholders.RequestorFirstName, argRTA.RequestedBy);
            }

            //Requestee FirstName,lastname for Body

            if (!string.IsNullOrEmpty(argRTA.RequestedOf))
            {
                //if (IA.RequestedByName.Contains(","))
                //    objTAR.MinimumTagValues.Add(EmailPlaceholders.RequesteeName, IA.RequestedOfName);
                //else
                    objTAR.MinimumTagValues.Add(EmailPlaceholders.RequesteeName, argRTA.RequestedOf);
            }

            //Hyperlink to Access for Body
            objTAR.MinimumTagValues.Add(EmailPlaceholders.GrantDenyLink, "GrantDenyLink");

            //RequestReason for Body
            objTAR.MinimumTagValues.Add(EmailPlaceholders.RequestReasons, argRTA.Description);

            objTAR.TemplateId = argTemplateId;
            objTAR.OperationDescription = argOperationDescription;
            objTAR.OperationDescription = argOperationType;

            return objTAR;
        }

        public BaseEmailEntity GetTemporaryAceessRejectedNotification(string argOperationType, string argOperationDescription, string argTemplateId,GrantDenyTemporaryArchiveAccess argGrantDeny,string userAlias)
        {
            BaseEmailEntity objTAR = new BaseEmailEntity();
            //Build Tag Values
            objTAR.MinimumTagValues = new Dictionary<string, string>();
            //Rejector for Body
            objTAR.MinimumTagValues.Add(EmailPlaceholders.Rejecter, userAlias);
            //Requestor FirstName for Body
            objTAR.MinimumTagValues.Add(EmailPlaceholders.RejectionReasons, argGrantDeny.GrantDenyReason);

            
            objTAR.TemplateId = argTemplateId;
            objTAR.OperationDescription = argOperationDescription;
            objTAR.OperationDescription = argOperationType;

            return objTAR;
        }

        public BaseEmailEntity GetTemporaryAceessApprovedNotification(string argOperationType, string argOperationDescription, string argTemplateId, GrantDenyTemporaryArchiveAccess argGrantDenyAccess, string userAlias)
        {
            BaseEmailEntity objTAR = new BaseEmailEntity();
            //Build Tag Values
            objTAR.MinimumTagValues = new Dictionary<string, string>();
            //Approver for Body
            objTAR.MinimumTagValues.Add(EmailPlaceholders.Approver, userAlias);
            
            objTAR.TemplateId = argTemplateId;
            objTAR.OperationDescription = argOperationDescription;
            objTAR.OperationDescription = argOperationType;

            return objTAR;
        }
    }
}
