﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DataModels
{
    public class WBSDetailsModel
    {
        public string ClientName { get; set; }
        public string ClientNumber { get; set; }
        public string WBSLevelOne { get; set; }
        public string WBSLevelOneDescription { get; set; }
        public string PartnerName { get; set; }
        public string PartnerAlias { get; set; }
    }
}
