import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { DestructionBatch } from '../../../../../../models/batch-details.model';
import { DestructionService } from '../../../../../../services/destruction.service';

@Component({
  selector: 'app-sub-batch-info',
  templateUrl: './sub-batch-info.component.html',
  styleUrls: ['./sub-batch-info.component.css']
})

export class SubBatchInfoComponent implements OnInit {

  batchNumber: string;
  subBatchData:any=[];
  destructionBatch:any;
  newStateSubBatches:any=[];
  destroyedStateSubBatches:any=[];

  constructor( private destructionService: DestructionService, private SpinnerService: NgxSpinnerService, private activatedRoute: ActivatedRoute) { }

  ngOnInit() {
    this.batchNumber = this.activatedRoute.snapshot.paramMap.get('batchId');
    this.destructionBatch = JSON.parse(localStorage.getItem('batchInfoBarData'));
    console.log(this.destructionBatch)
    this.getSubBatchData();
  }

  RedirecttoManageBatch(){
    console.log("Navigate URL pending");
  }
  getSubBatchData() {
    this.destructionService.GetSubBatchInfo(this.batchNumber).subscribe(
      data => {
        if (data.length > 0)
        {
          this.subBatchData = data ? data : [];
          this.newStateSubBatches =this.subBatchData.filter(item => item.status != "Destroyed");
          this.destroyedStateSubBatches =this.subBatchData.filter(item => item.status == "Destroyed");
          this.SpinnerService.hide();
        }
        else{
          this.subBatchData = [];
          this.SpinnerService.hide();
        }
      });
  }
}