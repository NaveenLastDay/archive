﻿using Amazon;
using Amazon.S3;
using Amazon.S3.Model;
using Deloitte.AIFA.Common;
using Deloitte.AIFA.DomainEntities;
using Deloitte.AIFA.DomainEntities.Enums;
using Deloitte.AIFA.DomainServices.Common;
using Deloitte.AIFA.DomainServices.Contracts;
using Deloitte.AIFA.ICloudServices;
using Deloitte.AIFA.IRepositories;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Deloitte.AIFA.DomainServices
{
    public class S3BucketService : IS3BucketService
    {
        private readonly IAmazonS3 _s3Client;
        private readonly string _storagekmskey;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="Region"></param>
        public S3BucketService(string Region, string Storagekmskey)
        {
            AmazonS3Config config = new AmazonS3Config()
            {
                RegionEndpoint = RegionEndpoint.GetBySystemName(Region),
                SignatureVersion = "V4"
            };
            AWSConfigsS3.UseSignatureVersion4 = true;
            _s3Client = new AmazonS3Client(config);
            _storagekmskey = Storagekmskey;
        }

        /// <summary>
        /// CopyObjectAsync
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public Task<CopyObjectResponse> CopyObjectAsync(S3BucketModel model)
        {
            var request = new CopyObjectRequest()
            {
                SourceBucket = model.SourceBucket,
                SourceKey = model.SourceKey,
                DestinationKey = model.DestinationKey,
                DestinationBucket = model.DestinationBucket
            };
            if (!string.IsNullOrWhiteSpace(_storagekmskey))
            {
                request.ServerSideEncryptionMethod = ServerSideEncryptionMethod.AWSKMS;
                request.ServerSideEncryptionKeyManagementServiceKeyId = _storagekmskey;
            }
            return _s3Client.CopyObjectAsync(request);
        }

        /// <summary>
        /// DeleteObjectAsync
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public Task<DeleteObjectResponse> DeleteObjectAsync(S3BucketModel model)
        {
            var request = new DeleteObjectRequest()
            {
                BucketName = model.SourceBucket,
                Key = model.SourceKey
            };
            //request.ServerSideEncryptionMethod = ServerSideEncryptionMethod.AWSKMS;
            return _s3Client.DeleteObjectAsync(request);
        }
    }
}
