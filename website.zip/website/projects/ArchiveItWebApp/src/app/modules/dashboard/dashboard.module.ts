import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardHomeComponent } from './dashboard-home/dashboard-home.component';
import { DashboardTemporaryAccessComponent } from './dashboard-temporary-access/dashboard-temporary-access.component';
import { RouterModule, Route } from '@angular/router';
import { AuthenticationGuard } from 'microsoft-adal-angular6';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ArchivePendingAccessApprovalComponent } from './archive-pending-access-approval/archive-pending-access-approval.component';
import { MatTooltipModule } from '@angular/material/tooltip';
// import { MyArchviesListItemComponent } from '../archive/my-archvies-list-item/my-archvies-list-item.component';
import { PipeModule } from '../shared/Pipes/pipe.module';
import { TrimSummaryLengthPipe } from '../shared/Pipes/trim-summary-length.pipe';
import { NotifierModule, NotifierOptions } from "angular-notifier";
import { SharedComponentsModule } from '../shared/shared-components.module';
import { PaginationComponent } from '../shared/pagination/pagination.component';
import { PendingAccessSearchListComponent } from './pending-access-search-list/pending-access-search-list.component';
import { CustomModalModule } from '../shared/modal';
import { CKEditorModule } from 'ng2-ckeditor';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { NgbModule } from "@ng-bootstrap/ng-bootstrap";
import { Form3283Component } from './form3283/form3283.component';
import { Form3283ListComponent } from './form3283-list/form3283-list.component';
import { ArchivesAwaitingApprovalComponent } from './archives-awaiting-approval/archives-awaiting-approval.component';
import { ArchivesAwaitingApprovalListComponent } from './archives-awaiting-approval-list/archives-awaiting-approval-list.component';
import { ArchivesRequiringApprovalComponent } from './archives-requiring-approval/archives-requiring-approval.component';
import { ArchivesRequiringApprovalListComponent } from './archives-requiring-approval-list/archives-requiring-approval-list.component';
import { ArchivesPendingSubmissionComponent } from './archives-pending-submission/archives-pending-submission.component';
import { ArchivesPendingSubmissionListComponent } from './archives-pending-submission-list/archives-pending-submission-list.component';
import { ComplianceMetricsComponent } from './compliance-metrics/compliance-metrics.component';
import { ComplianceMetricsListComponent } from './compliance-metrics-list/compliance-metrics-list.component';
import { ArchiveDeletionsComponent } from './archive-deletions/archive-deletions.component';
import { ArchiveDeletionsListComponent } from './archive-deletions-list/archive-deletions-list.component';


const customNotifierOptions: NotifierOptions = {
  position: {
      horizontal: {
          position: 'right',
          distance: 12
      },
      vertical: {
          position: 'top',
          distance: 12, 
          gap: 10
      }
  },
  theme: 'material',
  behaviour: {
      autoHide: 500,
      onClick: 'hide',
      onMouseover: 'pauseAutoHide',
      showDismissButton: true,
      stacking: 1
  },
  animations: {
      enabled: true,
      show: {
          preset: 'slide',
          speed: 200,
          easing: 'ease'
      },
      hide: {
          preset: 'fade',
          speed: 3000,
          easing: 'ease-in',
          offset: 50
      },
      shift: {
          speed: 300,
          easing: 'ease'
      },
      overlap: 150
  }
};
let routes: Route[] = [
  {
    path: 'dashboardHome', component: DashboardHomeComponent, data: { title: 'Dashboard', showbreadcrumb: 'true' }, canActivate: [AuthenticationGuard], children: [
      { path: '', component: DashboardComponent, data: { title: '', showbreadcrumb: 'false' } },
      { path: 'pendingAccess', component: ArchivePendingAccessApprovalComponent, data: { title: 'Access requests', showbreadcrumb: 'true' } },
      { path: 'temporaryAccess/:aN', component: DashboardTemporaryAccessComponent, data: { title: 'Temporary access request', showbreadcrumb: 'true' } },
      { path: 'form3283', component: Form3283Component, data: { title: 'Forms 3283S', showbreadcrumb: 'true' } },
      { path: 'awaitingapproval', component: ArchivesAwaitingApprovalComponent, data: { title: 'Audit archives awaiting approval', showbreadcrumb: 'true' } },
      { path: 'requiringapproval', component: ArchivesRequiringApprovalComponent, data: { title: 'Archives requiring approval', showbreadcrumb: 'true' } },
      { path: 'pendingsubmission', component: ArchivesPendingSubmissionComponent, data: { title: 'Archives pending submission', showbreadcrumb: 'true' } },
      { path: 'compliancemetrics', component: ComplianceMetricsComponent, data: { title: 'Compliance metrics', showbreadcrumb: 'true' } },
      { path: 'archivedeletions', component: ArchiveDeletionsComponent, data: { title: 'Archive deletions', showbreadcrumb: 'true' } },
    ]
  }
];

@NgModule({
declarations: [DashboardHomeComponent,DashboardComponent,ArchivePendingAccessApprovalComponent,
     DashboardTemporaryAccessComponent,
     PendingAccessSearchListComponent,
     Form3283Component,
     Form3283ListComponent,
     ArchivesAwaitingApprovalComponent,
     ArchivesAwaitingApprovalListComponent,
     ArchivesRequiringApprovalComponent,
     ArchivesRequiringApprovalListComponent,
     ArchivesPendingSubmissionComponent,
     ArchivesPendingSubmissionListComponent,
     ComplianceMetricsComponent,
     ComplianceMetricsListComponent,
     ArchiveDeletionsComponent,
     ArchiveDeletionsListComponent
    //  PaginationComponent
    //  MyArchviesListItemComponent,
     
    ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    MatTooltipModule,
    FormsModule,
    ReactiveFormsModule,
    PipeModule,
    NotifierModule.withConfig(customNotifierOptions),
    SharedComponentsModule,
    CustomModalModule,
    CKEditorModule,
    NgbModule    
  ]
  // schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})
export class DashboardModule { }
