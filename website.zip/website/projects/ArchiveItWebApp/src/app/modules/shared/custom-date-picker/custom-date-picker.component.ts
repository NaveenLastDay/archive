import { Component, OnInit, Input, Output, EventEmitter, forwardRef } from '@angular/core';
import { Injectable, ElementRef, ViewChild } from "@angular/core";
import { NgbCalendar, NgbDateStruct, NgbDate, NgbDateParserFormatter, NgbDatepickerI18n, NgbDatepickerKeyboardService, NgbDatepicker } from "@ng-bootstrap/ng-bootstrap";
import { archiveInfoService } from '../../../services/archiveinfo.service';
import { ActivatedRoute, Params } from '@angular/router';
import { Console } from 'console';
import { FormControl, NG_VALUE_ACCESSOR, ControlValueAccessor } from "@angular/forms";

@Injectable()
export class CustomDateParserFormatter extends NgbDateParserFormatter {
  readonly DELIMITER = "/";

  parse(value: string): NgbDateStruct {
    if (value) {
      const dateParts = value.trim().split("/");
      if (dateParts.length === 1 && isNumber(dateParts[0])) {
        return { day: toInteger(dateParts[0]), month: null, year: null };
      } else if (dateParts.length === 2 && isNumber(dateParts[0]) && isNumber(dateParts[1])) {
        return {
          day: toInteger(dateParts[1]),
          month: toInteger(dateParts[0]),
          year: null
        };
      } else if (dateParts.length === 3 && isNumber(dateParts[0]) && isNumber(dateParts[1]) && isNumber(dateParts[2]) && parseInt(dateParts[0]) > 12) {
        return {
          day: toInteger(dateParts[0]),
          month: toInteger(dateParts[1]),
          year: toInteger(dateParts[2])
        };
      } else if (dateParts.length === 3 && isNumber(dateParts[0]) && isNumber(dateParts[1]) && isNumber(dateParts[2])) {
        return {
          day: toInteger(dateParts[1]),
          month: toInteger(dateParts[0]),
          year: toInteger(dateParts[2])
        };
      }
    }
    return null;
  }

  format(date: NgbDateStruct): string {
    return date
      ? `${isNumber(date.month) ? padNumber(date.month) : ""}/${isNumber(date.day) ? padNumber(date.day) : ""}/${date.year
      }`
      : "";
  }
}
export function toInteger(value: any): number {
  return parseInt(`${value}`, 10);
}

export function isNumber(value: any): value is number {
  return !isNaN(toInteger(value));
}

export function padNumber(value: number) {
  if (isNumber(value)) {
    return `0${value}`.slice(-2);
  } else {
    return "";
  }

}
@Injectable()
export class I18n {
  language = "en";
}
@Injectable()
export class CustomDatepickerI18n extends NgbDatepickerI18n {
  constructor(private _i18n: I18n) {
    super();
  }

  getWeekdayShortName(weekday: number): string {
    return I18N_VALUES[this._i18n.language].weekdays[weekday - 1];
  }
  getMonthShortName(month: number): string {
    return I18N_VALUES[this._i18n.language].months[month - 1];
  }
  getMonthFullName(month: number): string {
    return this.getMonthShortName(month);
  }

  getDayAriaLabel(date: NgbDateStruct): string {
    return `${date.month}-${date.day}-${date.year}`;
  }
}
const I18N_VALUES = {
  en: {
    weekdays: ["Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"],
    months: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec",],
  },
};


const Key = {
  PageUp: 'PageUp',
  PageDown: 'PageDown',
  End: 'End',
  Home: 'Home',
  Enter: 'Enter'
};

@Injectable()
export class CustomKeyboardService extends NgbDatepickerKeyboardService {
  processKey(event: KeyboardEvent, dp: NgbDatepicker) {

    const state = dp.state;
    switch (event.code) {

      case Key.Enter: {
        super.processKey(event, dp);
        let saveBtn = document.getElementById('Togglesave');
        if (saveBtn != undefined && saveBtn.classList.contains('enableEnter')) {
          saveBtn.click();
        }
      }
        break;
      default:
        super.processKey(event, dp);
        return;
    }
    event.preventDefault();
    event.stopPropagation();
  }
}


@Component({
  selector: 'app-custom-date-picker',
  templateUrl: './custom-date-picker.component.html',
  styleUrls: ['./custom-date-picker.component.css'],
  providers: [
    { provide: NgbDateParserFormatter, useClass: CustomDateParserFormatter },
    I18n,
    { provide: NgbDatepickerI18n, useClass: CustomDatepickerI18n },
    { provide: NgbDatepickerKeyboardService, useClass: CustomKeyboardService },
    { provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => CustomDatePickerComponent), multi: true }
  ],

  host: {
    "(document:click)": "onClick($event)",
  },
})
export class CustomDatePickerComponent implements OnInit, ControlValueAccessor {
  @Input('date') DisplayDate: NgbDateStruct;
  @Input('placeholdertext') placeholderText: string;
  @Output() DatePickerEvent: EventEmitter<any> = new EventEmitter();
  @Output() DatePickerKeyupEvent: EventEmitter<any> = new EventEmitter();
  @Input() advanceFilter?: boolean;
  @Input('labelText') labelText?: string;
  dbclick: boolean = false;
  @Input('enterKey') enterKey: boolean = false;
  @Input() isFooter: boolean = true;
  @Input() isAutoClose: boolean = false;
  @Input() placement: string = 'bottom';
  // @Input() position?: string = '';
  @Input() maxDate: NgbDateStruct;
  @Input() minDate: NgbDateStruct;
  @Input() valueText: any = '';
  public datepickerInput = new FormControl('');
  archiveNumber: string;
  date: NgbDateStruct;//=this.calendar.getToday();
  EstimatedDate: NgbDateStruct;
  placeholdertext: string;
  @Input() isArchiveDestroyed: number = 0;
  constructor(private calendar: NgbCalendar, private _eref: ElementRef, private archiveinfoSvc: archiveInfoService, private activatedRoute: ActivatedRoute) { }
  ResetDate(value) {
    this.date = this.EstimatedDate;
  }
  @ViewChild("d", { static: false }) datePicker;
  isDisabled = (date: NgbDate, current: { month: number; year: number }) =>
    date.month !== current.month;
  isWeekend = (date: NgbDate) => this.calendar.getWeekday(date) > 6;
  public onClick(event) {
    if (!this._eref.nativeElement.contains(event.target)) {
      this.datePicker.close();
    }
  }
  private onChange: (value: any) => void = () => { };
  onTouched: () => void;

  ngOnInit() {
    this.archiveNumber = this.activatedRoute.snapshot.paramMap.get('aN');
    console.log("Archive Number: " + this.archiveNumber);
  }
  writeValue(value: any): void {
    this.date = value;
  }
  registerOnChange(fn: any): void {
    this.onChange = fn;
  }
  registerOnTouched(fn: any): void {
    this.onTouched = fn;
  }

  setDisabledState?(isDisabled: boolean): void {
    if (isDisabled) {
      this.datepickerInput.disable();
    } else {
      this.datepickerInput.enable();
    }
  }
  doClick() {
    if (this.onTouched != undefined)
      this.onTouched();
  }
  doInput(date: NgbDate, datepicker: any) {
    this.DatePickerKeyupEvent.emit(datepicker._inputValue);
    this.onChange(datepicker._inputValue);
  }
  focusDate(event: any) {
    this.date = event;
    this.datePicker._model = event;
    this.datePicker._inputValue = event;
    this.valueText = event;
    this.datePicker._elRef.nativeElement.value = event;
  }
  doBlur(ele: any, datepicker: any) {
    if (this.onTouched != undefined) {
      this.onTouched();
    }
    var val = ele.target.value;
    var pattern = new RegExp("[0-9]{2}/[0-9]{2}/[0-9]{4}");
    if (val.length > 0 && pattern.test(val)) {
      let dateObj: NgbDateStruct = {
        "year": parseInt(val.split("/")[2]),
        "month": parseInt(val.split("/")[0]),
        "day": parseInt(val.split("/")[1])
      }
      if (this.isArchiveDestroyed == 0) {
        this.DatePickerEvent.emit(dateObj);
        this.onChange(val);
      }
    }
  }
  getselectdate() {
    console.log("Get Start date method:" + this.date);
  }
  filleddate(event) {
    if (event.length >= 10) {
      this.DisplayDate = this.EstimatedDate;
      // document.getElementById("ToggleID").click();
    }

  }
  SelectedDate(event) {
    if (this.isArchiveDestroyed == 0) {
      this.DisplayDate = this.date;
      this.placeholderText = this.date
        ? `${isNumber(this.date.month) ? padNumber(this.date.month) : ""}/${isNumber(this.date.day) ? padNumber(this.date.day) : ""}/${this.date.year
        }`
        : "";
      this.DatePickerEvent.emit({ selectDate: this.date.year + "-" + this.date.month + "-" + this.date.day })
      console.log(this.date.year + "-" + this.date.month + "-" + this.date.day);
      //document.getElementById("Togglecancel").click();
      this.datePicker.close();
    }
  }

  changeDate(date: NgbDate, datepicker: any) {
    if (this.isFooter) {
      if (this.enterKey) {
        if (this.dbclick) {
          this.SelectedDate(date);
        }
        if (date.equals(datepicker._model)) {
          this.dbclick = true;
          setTimeout(() => {
            this.dbclick = false;
          }, 300);
        }
      }
    } else {
      if (this.isArchiveDestroyed == 0) {
        this.DatePickerEvent.emit(date);
        this.onChange(datepicker._inputValue);
      }
    }

  }



}
