﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
    public class Utility
    {
        public string UserAlias { get; set; }
        public string DisplayName { get; set; }
        public string LastName { get; set; }
        public string EmailAddress { get; set; }
        public string Function { get; set; }
        public int ArchiveAccessRoleID { get; set; }
        public string ArchiveAccessRole { get; set; }
        public int ArchiveEmployeeArchiveAccessId { get; set; }
        public string FirstName { get; set; }
        public bool IsPPD { get; set; }
        public bool IsManager { get; set; }
        public int PersonnelNumber { get; set; }
        public int IsRco { get; set; }
        public string Office { get; set; }
        public string LegalEntity { get; set; }
        public string Title { get; set; }
        public string OfficeLocation { get; set; }
    }
}
