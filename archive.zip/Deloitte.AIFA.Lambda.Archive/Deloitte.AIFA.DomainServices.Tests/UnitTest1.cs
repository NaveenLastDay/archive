using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Deloitte.AIFA.DomainServices.Tests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
