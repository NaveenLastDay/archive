﻿using Amazon.Lambda.Core;
using Amazon.SimpleNotificationService.Util;
using Deloitte.AIFA.CloudServices;
using Deloitte.AIFA.DataModels;
using Deloitte.AIFA.DomainEntities;
using Deloitte.AIFA.DomainServices.Contracts;
using Deloitte.AIFA.ICloudServices;
using Deloitte.AIFA.PushMessageSNSHelper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Deloitte.AIFA.Lambda.Archive.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UtilityController : ControllerBase
    {
        IUtilityService _utilityService;
        ILogger _logger { get; set; }
        private readonly IHttpContextAccessor _contextAccessor;
        private string userAlias;
        private List<RoleFunction> roleFunctions;
        public UtilityController(IHttpContextAccessor contextAccessor, IUtilityService utilityServie, ILogger<UtilityController> logger, ICloudCacheService cloudCacheService)
        {
            _logger = logger;
            _utilityService = utilityServie;
            this._contextAccessor = contextAccessor;
            _logger.LogError("Utility Detail Controller Initiated");
            try
            {
                LambdaLogger.Log("Inside Utility Controller");
                var _context = this._contextAccessor.HttpContext;
                try
                {
                    if (_context?.User?.Claims.Any() == true)
                    {
                        LambdaLogger.Log("Has claims in Utility Controller");
                        foreach (var claim in _context?.User?.Claims)
                        {
                            //LambdaLogger.Log(claim.Type);
                            if (claim.Type == "UserAlias")
                            {
                                userAlias = claim.Value.Split('@')[0].ToString();
                            }
                            LambdaLogger.Log("User Alias from Utility Controller," + userAlias);
                        }
                    }
                    else
                    {
                        LambdaLogger.Log("Has No claims");
                    }
                }
                catch (Exception ex)
                {
                    LambdaLogger.Log("Error with Http context in Utility controller: " + ex.Message);
                }
            }
            catch (Exception e)
            {
                LambdaLogger.Log("Error in Utility controller: " + e.Message);
            }

            try
            {
                CacheRequestModel cacheRequestModel = new CacheRequestModel();
                
                cacheRequestModel.Key = "RoleFunctions";
                _logger.LogInformation("RoleFunctions Cache Model Key" + System.Web.HttpUtility.HtmlEncode(cacheRequestModel.Key));
                var data = cloudCacheService.GetValue(cacheRequestModel);
                
                if (data == null)
                {
                    roleFunctions = _utilityService.GetRoleFunctions();
                    cacheRequestModel.Value = JsonConvert.SerializeObject(roleFunctions);
                    _logger.LogInformation("RoleFunctions from Cache Model Value" + System.Web.HttpUtility.HtmlEncode(JsonConvert.SerializeObject(cacheRequestModel.Value)));
                    var val = cloudCacheService.SetValue(cacheRequestModel);
                    _logger.LogInformation("RoleFunctions from cloud Cache Service Response" + System.Web.HttpUtility.HtmlEncode(val.ToString()));
                }
                else
                {
                    roleFunctions = JsonConvert.DeserializeObject<List<RoleFunction>>(data);
                    _logger.LogInformation("RoleFunctions from Cache" + System.Web.HttpUtility.HtmlEncode(JsonConvert.SerializeObject(roleFunctions)));
                }

                //roleFunctions.Where(e => e.FunctionName == "").Select(x => x.Id);

            }
            catch (Exception e)
            {
                _logger.LogError("Exception in Utility controller:" + e.Message);
            }
        }

        [HttpGet]
        [Route("PeoplePickerFilter/{useralias}/{rolecode?}")]
        public IActionResult GetUtilityDetail(string useralias, string rolecode = "")
        {
            var utilityDetail = _utilityService.GetUtilityDetail(useralias, rolecode);
            _logger.LogInformation("GetUtilityDetail: " + System.Web.HttpUtility.HtmlEncode(useralias + "," + rolecode));
            return Ok(utilityDetail);

        }

        [HttpGet]
        [Route("indexutility/indexarchive/{archivenumber}/{optype}")]
        public IActionResult IndexArchive(string archivenumber, string optype)
        {
            string messageId = string.Empty;
            try
            {
                if (!string.IsNullOrEmpty(optype) && optype.ToLower() == "insert")
                {
                    IndexNewArchive(archivenumber);
                }
                else if (!string.IsNullOrEmpty(optype) && optype.ToLower() == "update")
                {
                    IndexOldArchive(archivenumber);
                }
                return Ok(messageId);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return BadRequest(messageId);
            }

        }

        private string IndexNewArchive(string archiveNumber)
        {
            _logger.LogInformation("Push Message To SNS");
            string input = archiveNumber;
            string jsonData = @"{""requestParameters"":{""OperationType"":""Insert"",""ArchiveNumber"":""" + input + @"""}}";
            _logger.LogInformation("Json Data : " + System.Web.HttpUtility.HtmlEncode(jsonData));
            PushMessageSNS obj = new PushMessageSNS("esindexingNotifyArn");
            var messageId = obj.PushMsgtoSNS(jsonData).Result;

            if (messageId != null || messageId != string.Empty || messageId != "")
            {
                _logger.LogInformation("SNS MessageId: " + System.Web.HttpUtility.HtmlEncode(messageId) + " for Archive: " + System.Web.HttpUtility.HtmlEncode(input));
            }
            else
            {
                _logger.LogInformation("MessageId is null");
            }
            return (messageId);
        }

        private string IndexOldArchive(string archiveNumber)
        {
            _logger.LogInformation("Push Message To SNS");
            string input = archiveNumber;
            string jsonData = @"{""requestParameters"":{""OperationType"":""Update"",""ArchiveNumber"":""" + input + @"""}}";
            _logger.LogInformation("Json Data : " + System.Web.HttpUtility.HtmlEncode(jsonData));
            PushMessageSNS obj = new PushMessageSNS("esindexingNotifyArn");
            var messageId = obj.PushMsgtoSNS(jsonData).Result;

            if (messageId != null || messageId != string.Empty || messageId != "")
            {
                _logger.LogInformation("SNS MessageId: " + System.Web.HttpUtility.HtmlEncode(messageId) + " for Archive: " + System.Web.HttpUtility.HtmlEncode(input));
            }
            else
            {
                _logger.LogInformation("MessageId is null");
            }
            return (messageId);
        }
    }
}