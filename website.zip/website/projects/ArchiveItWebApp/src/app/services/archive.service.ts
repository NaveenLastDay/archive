import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable, BehaviorSubject, of } from 'rxjs';
import { UserActions } from '../models/archive-role.model';
import { GrantDenyTemporaryArchiveAccess } from '../modules/dashboard/dashboard-temporary-access/grantDeny.model';
import { FooterConfigurationDataModel } from '../models/footer-configuration-data.model';
/* import * as FileSaver from 'file-saver';
import * as Excel from "exceljs/dist/exceljs.min.js";
import * as ExcelProper from "exceljs";
import { Workbook } from 'exceljs'; */

@Injectable({
  providedIn: 'root'
})
export class ArchiveService {

  data: any;
  apiData: any;
  create: any;
  useralias: string;
  result: string;
  wbsinfo: any;
  roles: any;
  success: Observable<any>;
  UpdateArchive: any;
  archiveIdChildVal: any;
  private archiveMessageSource = new BehaviorSubject("");
  archiveName = this.archiveMessageSource.asObservable();
  private PeriodEndDateSource = new BehaviorSubject("");
  PeriodEndDate = this.PeriodEndDateSource.asObservable();
  private archiveDescriptionSource = new BehaviorSubject("");
  archiveDescription = this.archiveDescriptionSource.asObservable();
  private archiveRolesAndActions = new BehaviorSubject("");
  archiveRolesInfo = this.archiveRolesAndActions.asObservable();

  roleMapping = new UserActions();


  constructor(private _http: HttpClient) { }
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'

    }),

  }


  public GetEngagementType(): Observable<any> {

    //return this._http.get<any>(this.restURL,this.httpOptions);
    this.apiData = this._http.get<any>("ArchiveMetaData/EngagementType", this.httpOptions);

    return this.apiData;
  }
  public GetEntity(): Observable<any> {

    this.apiData = this._http.get<any[]>("ArchiveMetaData/ProfessionalStandard", this.httpOptions);

    return this.apiData;
  }



  public GetEntityType(): Observable<any> {

    this.apiData = this._http.get<any[]>("ArchiveMetaData/EntityTypes", this.httpOptions);
    return this.apiData;
  }

  public GetArchiveType(): Observable<any> {

    this.apiData = this._http.get<any[]>("ArchiveMetaData/ArchiveTypes", this.httpOptions);
    return this.apiData;
  }


  public getwbsinfo(seacrhTerm: string): Observable<any[]> {
    return this._http.get<any[]>("archive/GetExistingArchivesDetails?wbsLevelOne=" + seacrhTerm);
  }

  public getwbsdetails(seacrhTerm: string): Observable<any[]> {
    return this._http.get<any[]>("archive/GetWBSDetails?wbsLevelOne=" + seacrhTerm);
  }

  public GetActiveRoles(archivenumber: any): Observable<any> {
    this.roles = this._http.get<any>('ArchiveMetaData/GetActiveRoles?ArchiveNumber=' + archivenumber, this.httpOptions);
    return this.roles;
  }

  public updateteamroles(parameters): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json; charset=utf-8');
    this.success = this._http.post("Archive/UpdateArchiveTeam", parameters, { headers, responseType: 'text' });
    return this.success;
  }

  public getassignmenthistory(archivenumber: string, pageNumber: number = 0, pageSize: number = 0, sortBy: number = 7): Observable<any> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    this.apiData = this._http.get<any[]>('ArchiveMetaData/GetArchiveTeamHistory?ArchiveNumber=' + archivenumber
      + '&PageNumber=' + pageNumber
      + '&PageSize=' + pageSize
      + '&SortBy=' + sortBy
      , httpOptions);
    return this.apiData;
  }
  public getArchiveHistory(archivenumber: string, pageNumber: number = 0, pageSize: number = 0, sortBy: number = 7): Observable<any> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    this.apiData = this._http.get<any[]>('archive/GetArchiveHistory?ArchiveNumber=' + archivenumber
      + '&PageNumber=' + pageNumber
      + '&PageSize=' + pageSize
      + '&SortBy=' + sortBy
      , httpOptions);
    return this.apiData;
  }
  /* public GetPersonnelNumber(par: any): Observable<any> {
     this.apiData = this._http.get<any[]>("https://5k2cgn28pf.execute-api.us-east-1.amazonaws.com/Prod/api/v1/actionitems/" + this.value, this.httpOptions);
     // //debugger;
     return this.apiData;
   }*/

  //   public CreateNewArchive(parameters:any):Observable<any[]>{
  //   // //debugger;
  //   this.apiData = this._http.post<any[]>("https://h7ieoy33h4.execute-api.us-east-1.amazonaws.com/Prod/api/archive",parameters,this.httpOptions);
  //   // //debugger;
  //   return this.apiData;
  // }


  public CreateArchive(parameters: any): Observable<any> {
    this.create = this._http.post<any>("archive/create", parameters, this.httpOptions);
    console.log("created archive is", this.create);
    return this.create;
  }

  public GetMyArchives(employeeUniqueIdentifier: string, pageNumber: number = 0, pageSize: number = 0, sortBy: number = 1, filterBy: number = 0, filterText: string = ""): Observable<any> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    this.apiData = this._http.get<any[]>('archive/getmyarchives?PageNumber=' + pageNumber
      + '&PageSize=' + pageSize
      + '&SortBy=' + sortBy
      + '&FilterBy=' + filterBy
      + '&FilterText=' + filterText + ''
      , httpOptions);
    return this.apiData;
  }

  public GetBinders(archiveNumber: string, pageNumber: number = 0, pageSize: number = 0, sortBy: number = 1): Observable<any> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    this.apiData = this._http.get<any[]>('archive/GetBinderDetails?archivenumber=' + archiveNumber
      + '&pageNumber=' + pageNumber
      + '&pageSize=' + pageSize
      + '&sortBy=' + sortBy
      , httpOptions);
    return this.apiData;
  }

  public GetMyArchivesFilterData(employeeUniqueIdentifier: string, filterBy: number = 0): Observable<any> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    this.apiData = this._http.get<any[]>('archive/getmyarchivesfilterdatabyfiltertype?FilterBy=' + filterBy
      , httpOptions);
    return this.apiData;
  }

  public GetMyArchiveDetails(archiveNumber: string): Observable<any> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    this.apiData = this._http.get<any[]>('archive/getmyarchivedetails?ArchiveNumber=' + archiveNumber, httpOptions);
    return this.apiData;
  }
  GetArchiveIdChildVal() {
    return this.archiveIdChildVal;
  }
  SetArchiveIdChildVal(archiveIdChildVal) {
    this.archiveIdChildVal = archiveIdChildVal;
  }

  public GetEditArchiveDetails(archiveNumber: string): Observable<any> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    this.apiData = this._http.get<any[]>('archive/GetEditArchiveDetails?archiveNumber=' + archiveNumber, httpOptions);
    return this.apiData;
  }

  // public UpdateArchiveDetails(parameters: any): Observable<any> {
  //   const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
  //   this.UpdateArchive = this._http.post<any>("archive/UpdateArchiveDetails", parameters, this.httpOptions);
  //   console.log("Updated archive is", this.UpdateArchive);
  //   return this.UpdateArchive;
  // }


  public UpdateArchiveDetails(parameters: any): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json; charset=utf-8');
    this.success = this._http.post("archive/UpdateArchiveDetails", parameters, { headers, responseType: 'text' });
    console.log("Updated archive is", this.success);
    return this.success;
  }

  public UpdateArchiveName(archiveDetails) {
    //debugger;
    this.archiveMessageSource.next(archiveDetails);
  }

  public UpdatePeriodEndDate(archiveDetails) {
    //debugger;
    this.PeriodEndDateSource.next(archiveDetails);
  }


  public UpdateArchiveDescription(archiveDetails) {
    //debugger;
    this.archiveDescriptionSource.next(archiveDetails);
  }

  public createTemporaryArchiveTeam(parameters: any): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json; charset=utf-8');
    this.success = this._http.post("archive/InsertTempArciveTeam", parameters, { headers, responseType: 'text' });
    return this.success;
  }

  public GetRoleMappingsForUser(UserAlias: string, ArchiveNumber: string): Observable<any> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    this.apiData = this._http.get<any[]>(`user/GetRoleMappingsForUser?ArchiveNumber=${ArchiveNumber}`, httpOptions);
    //debugger;
    this.archiveRolesAndActions.next(this.apiData);
    return this.apiData;
  }

  public setRoleMappingResult(roleMapping: UserActions) {
    this.roleMapping = roleMapping;
  }
  public getRoleMappingResult() {
    return this.roleMapping;
  }


  public GetArchiveAccessRequestsForApproval(pageNumber: number, pageSize: number): Observable<any> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    this.apiData = this._http.get<any[]>('archive/GetArchiveAccessRequestsForApproval?PageNumber=' + pageNumber
      + '&PageSize=' + pageSize, httpOptions);
    return this.apiData;
  }
  public GetForm3283S(pageNumber: number, pageSize: number): Observable<any> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    this.apiData = this._http.get<any[]>('dashboard/getmyform3283dashboarddata?PageNumber=' + pageNumber
      + '&PageSize=' + pageSize, httpOptions);
    return this.apiData;
  }
  public GetArchiveAwaitingApproval(pageNumber: number, pageSize: number): Observable<any> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    this.apiData = this._http.get<any[]>('dashboard/getmyawaitingapprovaldashboarddata?PageNumber=' + pageNumber
      + '&PageSize=' + pageSize, httpOptions);
    return this.apiData;
  }
  public GetComplianceMetrics(pageNumber: number, pageSize: number, sortBy: number, filterText:string): Observable<any> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    this.apiData = this._http.get<any[]>('dashboard/getmycompliancemetrics?PageNumber=' + pageNumber
      + '&PageSize=' + pageSize + '&sortBy=' + sortBy + '&filterText=' + filterText, httpOptions);
    return this.apiData;
  }
  public GetPendingSubmission(pageNumber: number, pageSize: number): Observable<any> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    this.apiData = this._http.get<any[]>('dashboard/getmyawaitingsubmissiondashboarddata?PageNumber=' + pageNumber
      + '&PageSize=' + pageSize, httpOptions);
    return this.apiData;
  } 
  public GetArchiveDeletions(pageNumber: number, pageSize: number): Observable<any> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    this.apiData = this._http.get<any[]>('dashboard/getarchivedeletionsdashboarddata?PageNumber=' + pageNumber
      + '&PageSize=' + pageSize, httpOptions);
    return this.apiData;
  } 
  public GetRequiringApproval(pageNumber: number, pageSize: number): Observable<any> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    this.apiData = this._http.get<any[]>('dashboard/getmyrequiringapprovaldashboarddata?PageNumber=' + pageNumber
      + '&PageSize=' + pageSize, httpOptions);
    return this.apiData;
  }
  public ExportToExcel(pageNumber: number, pageSize: number): Observable<any> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/octet-stream' }) };
    this.apiData = this._http.get<any[]>('archive/ArchiveAccessRequestsDetails?PageNumber=' + pageNumber
      + '&PageSize=' + pageSize, httpOptions);
    return this.apiData;
  }
  public awaitingApprovalExportToExcel(pageNumber: number, pageSize: number): Observable<any> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/octet-stream' }) };
    this.apiData = this._http.get<any[]>('archive/awaitingapprovalexporttoexcel?PageNumber=' + pageNumber
      + '&PageSize=' + pageSize, httpOptions);
    return this.apiData;
  }
  public requiringApprovalExportToExcel(pageNumber: number, pageSize: number): Observable<any> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/octet-stream' }) };
    this.apiData = this._http.get<any[]>('archive/requiringapprovalexporttoexcel?PageNumber=' + pageNumber
      + '&PageSize=' + pageSize, httpOptions);
    return this.apiData;
  }
  public pendingSubmissionExportToExcel(pageNumber: number, pageSize: number): Observable<any> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/octet-stream' }) };
    this.apiData = this._http.get<any[]>('archive/pendingsubmissionexporttoexcel?PageNumber=' + pageNumber
      + '&PageSize=' + pageSize, httpOptions);
    return this.apiData;
  }
  public archiveDeletionExportToExcel(pageNumber: number, pageSize: number): Observable<any> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/octet-stream' }) };
    this.apiData = this._http.get<any[]>('archive/archivedeletionrequestsexporttoexcel?PageNumber=' + pageNumber
      + '&PageSize=' + pageSize, httpOptions);
    return this.apiData;
  }
  public form3283ExportToExcel(pageNumber: number, pageSize: number): Observable<any> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/octet-stream' }) };
    this.apiData = this._http.get<any[]>('archive/Form3283ExportToExcel?PageNumber=' + pageNumber
      + '&PageSize=' + pageSize, httpOptions);
    return this.apiData;
  }
  public GrantDenyTempArchiveAccessRequest(obj: GrantDenyTemporaryArchiveAccess): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json; charset=utf-8');
    this.apiData = this._http.post("archive/GrantDenyTempArchiveAccessRequest", obj, { headers, responseType: 'text' });
    return this.apiData;
  }
  public GetTemporaryArchiveAccessRequest(obj: GrantDenyTemporaryArchiveAccess): Observable<any> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    this.success = this._http.post("archive/GetTemporaryArchiveAccessRequest", obj, httpOptions);
    return this.success;
  }

  public GetFooterConfigurationData(): Observable<FooterConfigurationDataModel[]> {
    if (!sessionStorage.getItem("footerConfigurationData")) {
      const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
      var footerConfigurationData = this._http.get<FooterConfigurationDataModel[]>("user/GetFooterConfigurationData", httpOptions);
      footerConfigurationData.subscribe(data => {
        sessionStorage.setItem("footerConfigurationData", JSON.stringify(data))
      });
      return footerConfigurationData;
    }
    else {
      var dataString = sessionStorage.getItem("footerConfigurationData");
      console.log(<FooterConfigurationDataModel[]>JSON.parse(dataString));
      return of(<FooterConfigurationDataModel[]>JSON.parse(dataString));
    }
  }
  public DeleteArchive(requestObject): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json; charset=utf-8');
    this.success = this._http.post('archive/DeleteArchiveRequest', requestObject, { headers, responseType: 'text' });
    return this.success;
  }
  public GetDeleteArchiveRequestStatus(archivenumber: any): Observable<any> {
    return this._http.get<any>('ArchiveMetaData/GetArchiveDeletionStatus?ArchiveNumber=' + archivenumber, this.httpOptions);
  }

  public CreateRequestImageAction(parameters): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json; charset=utf-8');
    this.success = this._http.post("archive/CreateRequestImageAction", parameters, { headers, responseType: 'text' });
    return this.success;
  }
  /*  public exportExcel(jsonData: any[], fileName: string): void {
     var headerData;
     if(jsonData.length > 0) {
       headerData =  Object.keys(jsonData[0]);
     }
     // console.log('header values',headerData);
     var result = jsonData.map(o => Object.keys(o).map(k => o[k]));
     // console.log('excel result', result);
     const title = 'ArchiveAccessDetails';
     let workbook = new Workbook();
     let worksheet = workbook.addWorksheet('ArchiveAccessDetails');
 
     let headerRow = worksheet.addRow(headerData);
     headerRow.eachCell((cell, number) => {
       cell.font = { bold: true },
         cell.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } }
     });
     // Add Data and Conditional Formatting
     result.forEach(d => {
       let row = worksheet.addRow(d);
       let qty = row.getCell(5);
       let color = 'FF99FF99';
       if (+qty.value < 500) {
         color = 'FF9999'
       }
     }
 
     );
     workbook.xlsx.writeBuffer().then((result) => {
       let blob = new Blob([result], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
       FileSaver.saveAs(blob, 'ArchiveAccessDetails.xlsx');
     });
   } */
}
