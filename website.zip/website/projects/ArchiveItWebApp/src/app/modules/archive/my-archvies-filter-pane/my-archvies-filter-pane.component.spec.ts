import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MyArchviesFilterPaneComponent } from './my-archvies-filter-pane.component';

describe('MyArchviesFilterPaneComponent', () => {
  let component: MyArchviesFilterPaneComponent;
  let fixture: ComponentFixture<MyArchviesFilterPaneComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MyArchviesFilterPaneComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyArchviesFilterPaneComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
