import { Injectable, Output, EventEmitter } from "@angular/core";
import { truncateSync } from 'fs';



@Injectable({
  providedIn: 'root'
})
export class SearchEventService {
  customRuleJsondata: any;
  enableSearch: boolean = false;
  searchText: string;
  customRuleJson = [];
  facesetJson = [];
  disableSearchBtn: boolean = true;
  selectedFields: Array<any> = [];
  enableCustomRuleBtn: boolean = true;
  showApplyAll: boolean = true;
  showApplied: boolean = false;
  customRules = [];
  finalSelectedJson = {
    "employeeAlias": "",
    "isKeywordbaseSearch": false,
    "searchKeyword": "",
    "from": 0,
    "pageSize": 10,
    "rules": {
      "archiveNumber": [],
      "archiveName": [],
      "archiveStatus": [],
      "archiveType": [],
      "archiveTeamMembers": [],
      "archiveDescription": [],
      "business": [],
      "clientName": [],
      "entityAssociatedwithArchives": [],
      "engagementType": [],
      "periodEndDate": [],
      "standardsApplied": [],
      "WBSNumber": []
    }
  };
  finalBackupJson = {
    "archiveNumber": [],
    "archiveName": [],
    "archiveStatus": [],
    "archiveType": [],
    "archiveTeamMembers": [],
    "archiveDescription": [],
    "business": [],
    "clientName": [],
    "entityAssociatedwithArchives": [],
    "engagementType": [],
    "periodEndDate": [],
    "standardsApplied": [],
    "WBSNumber": []
  };
  customRulesArray=[{name: 'Archive Name', value: 1, isActive:1}, {name: 'Archive Number', value: 2, isActive:1},
  {name: 'Client', value: 3 , isActive:1}, {name: 'Archive Member', value: 4, isActive:1},
  {name: 'Status', value: 5, isActive:1}, {name: 'WBS', value: 6, isActive:1},
  {name: 'Period End', value: 7, isActive:1}]
  clientDataArray = [];
  WBSDataArray = [];
  BusinessDataArray = [];
  TypeDataArray = [];
  ArchivedescriptionDataArray = [];
  TypeofentityDataArray = [];
  EngagementtypeDataArray = [];
  ProfessionalstandardsDataArray = [];
  PeriodendDataArray = [];
  ArchiveStatusDataArray = [];
  ArchiveManagerDataArray =[];
  ArchvieFieldSeniorDataArray=[];
  AddArchvieFieldSeniorDataArray=[];
  ArchivePartnerDataArray=[];

  ///Selected///
  selectedManagerList = [];
  selectedStatusList = [];
  selectedClientsList = [];
  selectedWbsList = [];
  customRuleCount: number;
  selectedFieldName = [];
  selectedFacetsCount: number = 0;
  bindCustomRules: boolean = false;
  //Facet period end and start date
  periodStartDate: string = "";
  periodEndDate: string = "";
  periodEndStartDateCustomRule: string = "";
  periodEndToDateCustomRule: string = "";
  startDate:string="";
  toDate:string="";
  facetcounter:number=0;
  errormessage:boolean=false;
  errormessagerange:boolean=false;
  //Notify Enable 
  enableNotifier: boolean = false;
  enableBindfacets: boolean = false;
  enablePageCount:boolean=true;
  @Output() deleteClickEvent: EventEmitter<any> = new EventEmitter();
  @Output() rebindFacetComponents: EventEmitter<any> = new EventEmitter();
  @Output() clearFacets: EventEmitter<any> = new EventEmitter();
  @Output() triggerAdvanceSearch: EventEmitter<any> = new EventEmitter();
  constructor() { }
  onDeleteClick(_index: number) {
    this.deleteClickEvent.emit(_index);
  }

  onRebindFacetComponents() {
    this.rebindFacetComponents.emit();
  }
  onClearFacetsSelection() {
    this.clearFacets.emit();
  }
  onTriggerAdvanceSearch() {
    this.triggerAdvanceSearch.emit();
  }
  cloneFinalJson(){
  var obj=this.finalSelectedJson.rules;
    for (var key in obj) {
     this.finalBackupJson[key]=obj[key]
    }
  }
}
