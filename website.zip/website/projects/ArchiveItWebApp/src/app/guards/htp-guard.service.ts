import { CanActivate } from "@angular/router";
import { Injectable } from "@angular/core";
import { Observable, of } from 'rxjs';
import { WorkingPaperService } from '../services/working-paper.service';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { Router } from '@angular/router';
import { map, catchError } from 'rxjs/operators';
import { UserConfigSettingService } from './user-role-guard.service';

@Injectable()
export class HTPGuardService implements CanActivate {

    userConfig: any;

    // constructor
    constructor(
        private _adalService: MsAdalAngular6Service,
        private _userConfig:UserConfigSettingService,
        private _router: Router) { }

    // canActivate
    public canActivate(): Observable<boolean> {
        debugger;
        let employeeUniqueIdentifier = this._adalService.LoggedInUserEmail.split('@')[0];
        this.userConfig = this._userConfig.FetchLoggedInUser(employeeUniqueIdentifier)
        if (!this.userConfig.value.isHPT) 
        {
            this._router.navigate(['/home']);
        }
        else {
            return  this.userConfig.value.isHPT;
        }     
    }
}
