import { Component, OnInit } from '@angular/core';
import { FileUploadEventService } from '../file-upload/fileupload.event.service';
import { ModalService } from '../../shared/modal';
import { FileUploadProcessService } from '../file-upload/fileupload.process.service';
import { FielUploadService } from '../../../services/fileupload.service';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-guard-modal',
  templateUrl: './guard-modal.component.html',
  styleUrls: ['./guard-modal.component.css']
})
export class GuardModalComponent implements OnInit {

  constructor(
    private modalService: ModalService,
    private _fuService: FielUploadService,
    private _fuEventService: FileUploadEventService,
    private _spinnerService: NgxSpinnerService) {
  }

  ngOnInit() {

    this._fuEventService.notifyUploadProgress.subscribe(showNotifier => {
      if (showNotifier) {
        this.modalService.open("workingPaperNavigationAwayAlertPopup");
      } else {
        this.abortFileUpload();
      }

    });

  }

  continueClick() {
    this.abortFileUpload();
    this._fuEventService.navigateAwaySelection$.next(true);
  }
  closeNavigationAwayAlertPopUp() {
    this.modalService.close("workingPaperNavigationAwayAlertPopup");
    this._fuEventService.navigateAwaySelection$.next(false);
  }
  abortFileUpload() {
    var self = this;
    var filearray = self._fuEventService.fileArray;

    for (var i = 0; i < filearray.length; i++) {

      if (filearray[i].uploadStatus === "started") {
        var s3FileName = filearray[i].metaData.ArchiveFileId + "_" + filearray[i].fileName;
        self._fuEventService.onAbortUpload(s3FileName, filearray[i].uploadId, true);
      }
      else{
        filearray[i].uploadStatus = "dismissed";
      }
    }
    this._fuEventService.onupdateUploadStatus(this._fuEventService.fileArray);
  
  }

}
