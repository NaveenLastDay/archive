﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities.Report
{
    public class ArchiveAccessRequestDetailsReport
    {
        
            public ArchiveAccessRequestDetailsReport()
            {
                List = new List<ArchiveAccessRequestDetails>();
            }

            public List<ArchiveAccessRequestDetails> List { get; set; }

            public bool IsDataTruncated { get; set; }
        

    }
}
