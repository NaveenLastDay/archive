import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WorkingPaperComponent } from './working-paper.component';

describe('WorkingPaperComponent', () => {
  let component: WorkingPaperComponent;
  let fixture: ComponentFixture<WorkingPaperComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WorkingPaperComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WorkingPaperComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
