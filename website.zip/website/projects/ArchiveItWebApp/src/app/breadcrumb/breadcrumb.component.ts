import { Component, OnInit, EventEmitter } from '@angular/core';
import {BreadcrumbService} from "./breadcrumb.service";
import {Router, ActivatedRoute, NavigationEnd, NavigationStart} from "@angular/router";
import {filter} from 'rxjs/operators';
import { Location } from '@angular/common';
import { Observable, Subscription, combineLatest } from 'rxjs';
import { LoginuserdetailsService } from '../services/loginuserdetails.service';
import { AnalyticsService } from '../services/analytics.service';



@Component({
  selector: 'app-breadcrumb',
  templateUrl: './breadcrumb.component.html',
  styleUrls: ['./breadcrumb.component.css']
})
export class BreadcrumbComponent implements OnInit {

  routes : Array<Object>=[];
  url:string;
  archiveNumber:string;
  // public settings$: Observable<AppSettings>;
  // public loggedUser$: Observable<User>;
  public logoTitle = 'AIFA';
  public image: string;
  navigationEndRouter$: Observable<NavigationEnd>;
  DTMSettings$: Subscription;
  title: string;
  userName: string;
  omnitureScriptSrc: string;


  //currentUrl:string;
//  _subject: EventEmitter<any> = new EventEmitter();
  constructor(private breadcrumbService : BreadcrumbService,private analyticsService: AnalyticsService, private userloginservice: LoginuserdetailsService,
     private router : Router, private route : ActivatedRoute,
     private location: Location) {
       // debugger;
      // this.router.events.subscribe((event: NavigationEnd) =>
      // {
      //   if(event instanceof NavigationStart){

      //     console.log(event.url);
      //   }
      //   if(event instanceof NavigationEnd){
      //     console.log(event.url);
      //     console.log("Flowtrack => I am loaded from if of constructor of Breadcrumb.component.ts")
      //     // var idx = this.routes.map((x:any)=>{return x.url}).indexOf(event.url);
      //     // this.breadcrumbService.kill(idx);
      //     // this.routes = this.breadcrumbService.get();
      //     // this.router.navigateByUrl(event.url);
      //   }
      // }
      //  );


       this.navigationEndRouter$ = this.router.events.pipe(filter((event: any) => event instanceof NavigationEnd));
       this.navigationEndRouter$.subscribe((end: NavigationEnd) => {
         let root = this.router.routerState.snapshot.root;
          let eleContent = document.getElementById('content');
           if(eleContent != undefined){
            eleContent.setAttribute('data-load-first','true');
            eleContent.removeAttribute("style");
            document.getElementById('appRootScroll').scroll({top:0,behavior:'smooth'});
           }
         console.log("Flowtrack => I am loaded from constructor of Breadcrumb.component.ts")
         while (root) {
          this.userName = this.userloginservice.GetUserAlias();
           if (root.children && root.children.length) {
             root = root.children[0];
             if (root.routeConfig.data && this.title !== root.routeConfig.data.title) {
               this.title = root.routeConfig.data && root.routeConfig.data.title || this.title;

                if(this.title== "Home")  // Only for main Home Visit
                {
                  console.log("Flowtrack => Page title is : "+ this.title);
                  console.log("Flowtrack => User Name is : "+ this.userName)
                  analyticsService.updateDTMPageInfo(this.title, this.userName);
                  return;
                }

                //only for main pages
                //Get the last main page here and come out of loop
               else if (root.routeConfig.data.showbreadcrumb=="true") {
                while (root)
                {
                  if (root.children && root.children.length) {
                  root = root.children[0];
                  this.title = root.routeConfig.data && root.routeConfig.data.title || this.title;
                  }

                  else
                  {
                    console.log("Flowtrack => Page title is : "+ this.title);
                    console.log("Flowtrack => User Name is : "+ this.userName)
                    analyticsService.updateDTMPageInfo(this.title, this.userName);
                    return;
                  }
                }

                return;

                }
             }
           } else {
             return;
           }
         }
       });

     }

  ngOnInit() {

    console.log("Flowtrack => I am ngonit from Breadcrumb.component.ts")

    this.initRoutes();


  }

  onBackPress(){
    this.location.subscribe((

      (value:PopStateEvent)=>{
        console.log(value);
        var url = this.location.path();
         var idx = this.routes.map((x:any)=>{return x.url}).indexOf(url);
         this.breadcrumbService.kill(idx);
         this.router.navigateByUrl(url);
      }),
      (ex =>{
        console.log("error occured popstateevent");
        console.log(ex);


      })
    )
  }

  goTo(url:string){

   // if(url=="/admintiles"){
   //   url="/admin/admintiles"
  //  }
  //  else if (url == '/maintainalerts'){
  //    url ='/admin/maintainalerts'
   // }
   // else if(url == '/sgfolders'){
   //   url ='/admin/sgfolders'
  //  }
  //  else if(url == '/existingArchives'){
  //    url ='/archive/existingArchives'
  //  }
  //  else if(url == '/searchwbs'){
  //    url='/archive/searchwbs'
 //   }
  //  else if(url = ''){
  //    url= '/home'
   // }
    //else url;
    var idx = this.routes.map((x:any)=>{return x.url}).indexOf(url);

    var length = this.routes.length;
    this.routes.splice(idx,length - idx);
    this.router.navigateByUrl(url);
  }

  private initRoutes = () => this.router.events.pipe(filter((event=>event instanceof NavigationEnd)))

    .subscribe(event=>{

      this.routes=[];
      let currentRoute = this.route.root;
      let label = '';

     this.routes.push({url:"/home",label:"Home"});

      while(currentRoute)
      {

        let childRoutes = currentRoute.children;
        let url = this.router.url;

      currentRoute = null;

      childRoutes.forEach(route=>{
         if(route.outlet === 'primary'){
           if(route.snapshot.data['showbreadcrumb']==='true')
           {
              label = route.snapshot.data['title'];
              if(label=="Auto archive"){
                this.routes.push({url:"/archive/myarchives",label:"My Archives"});
                this.archiveNumber =  route.snapshot.parent.paramMap.get('aN');
                this.routes.push({url:this.router.url,label:this.archiveNumber});
              }
              else if(label == "Existing Archives"){
                this.routes.push({url:"/archive/SearchWbs",label:"Create archive"});
                let selectedValue = route.snapshot.paramMap.get('optionSelectedvalue');
                this.routes.push({url:this.router.url,label:selectedValue});
              }
              else if(label == "Dashboard"){
                this.routes.push({url:"/dashboard/dashboardHome",label:label});
              }
              else if(label == "Admin panel"){
                this.routes.push({url:route.snapshot.data['url'], label:label});
              }
              else if(label == "Holds"){
                this.routes.push({url:route.snapshot.data['url'], label:label});
              }
              else if(label == "Search and manage holds"){
                this.routes.push({url:route.snapshot.data['url'], label:label});
              }
              else if(label == "Archive Details"){
                this.routes.push({url:this.router.url, label:route.snapshot.queryParams["archiveNumber"]});
              }
              else if(label == "HoldDetails"){
                this.routes.push({url:route.snapshot.data['url'] + route.snapshot.params["aN"], label:route.snapshot.params["aN"]});
              }
              else if(label == "Destruction"){
                this.routes.push({url:route.snapshot.data['url'], label:label});
              }
              else if(label == "Create or manage batches"){
                this.routes.push({url:route.snapshot.data['url'], label:label});
              }
              else if(label == "BatchDetails"){
                this.routes.push({url:route.snapshot.data['url'] + route.snapshot.params["batchId"], label:route.snapshot.params["batchId"]});
              }
              else if(label == "Desctruction process"){
                this.routes.push({url:route.snapshot.data['url'], label:label});
              }
              else if(label == "Desctruction Process Details"){
                this.routes.push({url:route.snapshot.data['url'] + route.snapshot.params["batchId"], label:route.snapshot.params["batchId"]});
              }
              else if(label == "subbatchinfo"){
                this.routes.push({url:route.snapshot.data['url'] + route.snapshot.params["batchId"], label:route.snapshot.params["batchId"]});
              }
              else if(label == "SubBatchDetails"){
                this.routes.push({url:route.snapshot.data['url'] + route.snapshot.params["subBatchId"], label:route.snapshot.params["subBatchId"]});
              }
              else
              this.routes.push({url:this.router.url,label:label});
           }
           currentRoute = route;
         }
        })
      }

   //   while(currentRoute);
     // {
        //this.routes = this.breadcrumbService.get();
     // }


   })



}
