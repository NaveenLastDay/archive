﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities.EmailEntities
{
    public class BaseEmailEntity
    {
        public string User { get; set; }
        public string OperationType { get; set; }
        public string OperationDescription { get; set; }
        public Dictionary<string, string> MinimumTagValues { get; set; }
        public string AdditionalInfo { get; set; }
        public string TemplateId { get; set; }
    }
}
