import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HoldArchiveDetailsComponent } from './hold-archive-details.component';

describe('HoldArchiveDetailsComponent', () => {
  let component: HoldArchiveDetailsComponent;
  let fixture: ComponentFixture<HoldArchiveDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HoldArchiveDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HoldArchiveDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
