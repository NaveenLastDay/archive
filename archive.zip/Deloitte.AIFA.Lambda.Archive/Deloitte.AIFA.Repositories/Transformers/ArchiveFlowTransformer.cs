﻿using Deloitte.AIFA.DataModels;
using Deloitte.AIFA.DBHelper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace Deloitte.AIFA.Repositories.Transformers
{
    public enum ArchiveFlowField
    {
        ArchiveNumber,
        ArchiveSectionId,
        ActionTypeId,
        Comments,
        CreatedBy,
        RejectedBy,
        RejectedDate,
        CreatedDate,
        IsSectionApproved
    }
    public enum ArchiveFlowFieldParameter
    {
        [CreateField(Name = "p_ArchiveNumber", Direction = ParameterDirection.Input, Type = DbType.String)]
        ArchiveNumber,
        [CreateField(Name = "p_SectionId", Direction = ParameterDirection.Input, Type = DbType.Int32)]
        ArchiveSectionId,
        [CreateField(Name = "p_ActiontypeId", Direction = ParameterDirection.Input, Type = DbType.Int32)]
        ActionTypeId,
        [CreateField(Name = "p_Comment", Direction = ParameterDirection.Input, Type = DbType.String)]
        Comments,
        [CreateField(Name = "p_CreatedBy", Direction = ParameterDirection.Input, Type = DbType.String)]
        CreatedBy
    }

    public class ArchiveFlowTransformer : BaseTransformer<ArchiveFlowDetailsModel>
    {
        internal override ArchiveFlowDetailsModel TransformElement(IDataReader dr, Func<IDataReader, ArchiveFlowDetailsModel, ArchiveFlowDetailsModel> bindExtraFields = null)
        {
            return new ArchiveFlowDetailsModel
            {
                ArchiveSectionId = (dr[ArchiveFlowField.ArchiveSectionId.ToString()] is DBNull) ? 0 : int.Parse(dr[ArchiveFlowField.ArchiveSectionId.ToString()].ToString()),
                Comments = (dr[ArchiveFlowField.Comments.ToString()] is DBNull) ? string.Empty : dr[ArchiveFlowField.Comments.ToString()].ToString(),
                RejectedBy = (dr[ArchiveFlowField.RejectedBy.ToString()] is DBNull) ? string.Empty : dr[ArchiveFlowField.RejectedBy.ToString()].ToString(),
                RejectedDate = (dr[ArchiveFlowField.RejectedDate.ToString()] is DBNull
                                             ? DateTime.MinValue
                                             : DateTime.Parse(dr[ArchiveFlowField.RejectedDate.ToString()].ToString())),
                IsSectionApproved = (dr[ArchiveFlowField.IsSectionApproved.ToString()] is DBNull) ? 0 : int.Parse(dr[ArchiveFlowField.IsSectionApproved.ToString()].ToString())
            };
        }
    }

    public class GetResubmissionReasonsTransformer : BaseTransformer<ArchiveFlowDetailsModel>
    {
        internal override ArchiveFlowDetailsModel TransformElement(IDataReader dr, Func<IDataReader, ArchiveFlowDetailsModel, ArchiveFlowDetailsModel> bindExtraFields = null)
        {
            return new ArchiveFlowDetailsModel
            {
                ArchiveSectionId = (dr[ArchiveFlowField.ArchiveSectionId.ToString()] is DBNull) ? 0 : int.Parse(dr[ArchiveFlowField.ArchiveSectionId.ToString()].ToString()),
                Comments = (dr[ArchiveFlowField.Comments.ToString()] is DBNull) ? string.Empty : dr[ArchiveFlowField.Comments.ToString()].ToString(),
                RejectedDate= (dr[ArchiveFlowField.CreatedDate.ToString()] is DBNull
                                             ? DateTime.MinValue
                                             : DateTime.Parse(dr[ArchiveFlowField.CreatedDate.ToString()].ToString())),
                ActionTypeId = (dr[ArchiveFlowField.ActionTypeId.ToString()] is DBNull) ? 0 : int.Parse(dr[ArchiveFlowField.ActionTypeId.ToString()].ToString())
            };
        }
    }
}
