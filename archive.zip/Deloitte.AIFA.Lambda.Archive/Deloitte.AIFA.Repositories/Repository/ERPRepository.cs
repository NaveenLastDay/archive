﻿using Deloitte.AIFA.DataModels;
using Deloitte.AIFA.DomainEntities;
using Deloitte.AIFA.IRepositories;
using Deloitte.AIFA.Models;
using Deloitte.AIFA.Repositories.Transformers;
using Microsoft.Extensions.Caching.Memory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using static Deloitte.AIFA.Repositories.Transformers.ERPTransformer;

namespace Deloitte.AIFA.Repositories.Repository
{
   public class ERPRepository : BaseRepository<ERPConfigurationField>, IERPRepository
    {
        IMemoryCache _cache;
        public ERPRepository(IMemoryCache cache) : base(cache)
        {
            _cache = cache;
        }

        public List<ERPConfigurationData> GetERPCpnfigurationData(string keys)
        {
           // List<ERPConfigurationData> lsteRPConfigurations= new List<ERPConfigurationData>();
            Exception e = new Exception();
            try
            {
                var parameters = GetBuilderInstance().Bind(ERPConfigurationFieldParameters.p_Keys).On(keys).Build();

                var result = DbHelper.ExecuteReader(
                    "pub_AIFA_GetERPConfigurationData",
                    parameters,
                        dr => new ERPTransformer().Transform(dr).ToList());

                return _mapper.Map<List<ERPConfigurationDataModel>, List<ERPConfigurationData>>(result);
            }
            catch (Exception ex)
            {
                throw ex;

            }

          //  return lsteRPConfigurations;
        }

        public List<EngagementPersonnelInfo> GetEngagementPersonnelInfo(string ArchiveNumber)
        {
            try
            {
                var parameters = GetBuilderInstance().Bind(EngagementPersonnelInfoParameter.ArchiveNumber).On(ArchiveNumber)
                      .Build();

                var result = DbHelper.ExecuteReader(
                    "pub_AIFA_GetEmployeePersonnelDetails",
                    parameters,
                        dr => new EngagementPersonnelInfoTransformer().Transform(dr).ToList());

                return _mapper.Map<List<EngagementPersonnelInfoModel>, List<EngagementPersonnelInfo>>(result);

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string GetPartnerAlias(string archiveNumber)
        {
            try
            {

                var parameters = GetBuilderInstance().Bind(EngagementPersonnelInfoParameter.ArchiveNumber).On(archiveNumber).Bind(EngagementPersonnelInfoParameter.PPDAlias).On(archiveNumber).
                                Build();

                var result = DbHelper.ExecuteNonQuery(
                    "pub_AIFA_GetPartnerAlias",
                    parameters,
                    cmd => cmd.Parameters["PPDAlias"].Value.ToString());

                return result;
            }
            catch (Exception ex)

            {
                throw ex;
            }
        }

        public List<ERPDetails> GetERPDetails(string searchquery)
        {
            try
            {
                var parameters = Builder
                    .Bind(ERPDetailFieldParameter.searchquery).On(searchquery).Build();



                var result = DbHelper.ExecuteReader(
                    "pub_AIFA_GetEmployeeDetails",
                    parameters,
                        dr => new ERPdetailTransformer().Transform(dr).ToList());

                return _mapper.Map<List<ERPmodel>, List<ERPDetails>>(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #region RemoveEngagementPersonnel
        public DistributionList RemoveEngagementPersonnel(DistributionList distributionList)
        {
            try
            {
                var parameters = Builder.Bind(RemoveEngagementPersonnelFieldParameter.ArchiveNumber).On(distributionList.ArchiveNumber)
                    .Bind(RemoveEngagementPersonnelFieldParameter.EngagementPersonnel).On(distributionList.EngagementPersonnel)
                    .Bind(RemoveEngagementPersonnelFieldParameter.DeletedBy).On(distributionList.DeletedBy)
                    .Bind(RemoveEngagementPersonnelFieldParameter.DeletedDate).On(distributionList.DeletedDate).Build();

                var result = DbHelper.ExecuteReader(
                    "pub_AIFA_UpdateDistributionList",
                    parameters,
                        dr => new RemoveEngagementPersonnelTransformer().Transform(dr).ToList());

                return _mapper.Map<DistributionListModel, DistributionList>(result.FirstOrDefault());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion RemoveEngagementPersonnel

        #region AddEngagementPersonnels
        public DistributionList AddEngagementPersonnels(DistributionList distributionList)
        {
            try
            {
                var parameters = Builder.Bind(AddEngagementPersonnelsFieldParameter.ArchiveNumber).On(distributionList.ArchiveNumber)
                    .Bind(AddEngagementPersonnelsFieldParameter.Personnels).On(distributionList.Personnels)
                    .Bind(AddEngagementPersonnelsFieldParameter.IsManualSubmission).On(distributionList.IsManualSubmission)
                    .Bind(AddEngagementPersonnelsFieldParameter.CreatedBy).On(distributionList.CreatedBy)
                    .Bind(AddEngagementPersonnelsFieldParameter.CreatedDate).On(distributionList.CreatedDate).Build();

                var result = DbHelper.ExecuteReader(
                    "pub_AIFA_InsertIntoDistributionList",
                    parameters,
                        dr => new AddEngagementPersonnelsTransformer().Transform(dr).ToList());

                return _mapper.Map<DistributionListModel, DistributionList>(result.FirstOrDefault());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion AddEngagementPersonnels
    }
}
