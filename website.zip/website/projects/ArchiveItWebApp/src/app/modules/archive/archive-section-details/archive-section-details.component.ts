import { Component, OnInit } from '@angular/core';
import { DeliverableService } from '../../../services/deliverable.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-archive-section-details',
  templateUrl: './archive-section-details.component.html',
  styleUrls: ['./archive-section-details.component.css']
})
export class ArchiveSectionDetailsComponent implements OnInit {

  CountofDeliverables : any;
  archiveNumber: any;

    constructor(private router: Router,private deliverableService: DeliverableService,private activatedRoute: ActivatedRoute) { }

  ngOnInit() {
    //  // debugger;
    this.archiveNumber = "AEA500034";
    this.deliverableService.GetDeliverablesCountByArchiveNumber(this.archiveNumber).subscribe(
      (info)=>{
        //  // debugger;
        if (info>0)
        this.CountofDeliverables = info.length; 
      }
    );
  }
  redirectToDeliverables(){
    //  // debugger;
     if(this.CountofDeliverables == 0){
       this.router.navigate(['archive/myarchives/AEA500271/deliverables']);
     }
     else{
      this.router.navigate(['archive/myarchives/AEA500271/existingdeliverables']);
     }
  }
}
