import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MaintainalertsComponent } from './maintainalerts.component';

describe('MaintainalertsComponent', () => {
  let component: MaintainalertsComponent;
  let fixture: ComponentFixture<MaintainalertsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MaintainalertsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MaintainalertsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
