import { Component, OnInit } from '@angular/core';
import { NotifierService } from 'angular-notifier';
import { NgxSpinnerService } from 'ngx-spinner';
import { ActivatedRoute } from '@angular/router';
import { ArchiveService } from '../../../services/archive.service';
import { ArchiveHomeService } from '../../../services/archive-home.service';

@Component({
  selector: 'app-archive-history',
  templateUrl: './archive-history.component.html',
  styleUrls: ['./archive-history.component.css']
})
export class ArchiveHistoryComponent implements OnInit {
  archiveNumber: string;
  currentPageNumber: number = 1;
  readonly pageSize: number = 10;
  archiveHistoryData: any;
  pageCount: number = 1;
  pageArray = Array();
  totalhistory: number = 0;
  displayinghistoryfrom: number = 0;
  displayinghistoryto: number = 0;
  sortDir: number = 1;
  expand: boolean[] = [];
  collapse: boolean[] = [];
  divsubstantiativereason: boolean[] = [];
  infoMessage:string="This is the initial approval date and time based on the time zone of the assigned office of the archive approver";
  ResubmissionReason: any;
  appendArchiveHistoryGrid:boolean=false;
  constructor(private archiveService: ArchiveService, private archiveHomeService: ArchiveHomeService ,private notifier: NotifierService, private spinnerService: NgxSpinnerService, private activatedRoute: ActivatedRoute) { }

  ngOnInit() {
    this.archiveNumber = this.activatedRoute.snapshot.parent.params.aN;
    this.archiveHomeService.SyncForm3283SStatus(this.archiveNumber);
    this.getArchiveHistory();
  }

  ExpansionCollapse(Action, id) {
    if (Action === 'plus') {
      this.expand[id] = true;
      this.collapse[id] = false;
      this.divsubstantiativereason[id] = true;
    }
    if (Action === 'minus') {
      this.expand[id] = false;
      this.collapse[id] = true;
      this.divsubstantiativereason[id] = false;
    }
  }

  getArchiveHistory() {
   // this.spinnerService.show();
    this.archiveService.getArchiveHistory(this.archiveNumber, this.currentPageNumber, this.pageSize, this.sortDir).subscribe(
      data => {
        if (this.appendArchiveHistoryGrid && data)
        this.archiveHistoryData = this.archiveHistoryData.concat(data);
        else
        this.archiveHistoryData = data ? data : [];
  
        console.log(this.archiveHistoryData);
        if (this.archiveHistoryData.length > 0) {
          this.calculatePageCount();
        }
        else {
          this.clearPageCount();
        }
       // this.spinnerService.hide();
      }
    );
  }
  calculatePageCount() {
    if (this.archiveHistoryData && this.archiveHistoryData.length > 0) {
      let possiblePages = Math.ceil(parseInt(this.archiveHistoryData[0]["count"]) / this.pageSize);
      this.pageCount = possiblePages;
      this.pageArray = Array(this.pageCount).fill(0).map((e, i) => i + 1);
      this.totalhistory = this.archiveHistoryData[0]["count"];
      this.displayinghistoryfrom = this.archiveHistoryData[0]["rowNumber"];
      this.displayinghistoryto = this.archiveHistoryData[this.archiveHistoryData.length - 1]["rowNumber"];
      //this.ResubmissionReason = this.archiveHistoryData[0]["resubmissionReason"];
    }
    else {
      this.clearPageCount();
    }
  }

  clearPageCount() {
    this.currentPageNumber = 1;
    this.pageCount = 1;
    this.pageArray = Array();
  }

  changePage(event, requestedPage: any) {
    if (isNaN(requestedPage) || requestedPage < 1 || requestedPage > this.pageCount) {
      this.notifier.notify("error", "Invalid page number.");
      return false;
    }
    this.currentPageNumber = parseInt(requestedPage);
    this.getArchiveHistory();

  }

  jumpToNextPage() {
    console.log('jumpToNextPage');
    if (this.currentPageNumber < this.pageArray.length) {
      this.currentPageNumber++;
      this.getArchiveHistory();
    }

  }

  jumpToPreviousPage() {
    console.log('jumpToPreviousPage');
    if (this.currentPageNumber > 1) {
      this.currentPageNumber--;
      this.getArchiveHistory();
    }
  }

  jumpToStartPage() {
    console.log('jumpToStartPage');
    this.currentPageNumber = 1;
    this.getArchiveHistory();
  }

  jumToEndPage() {
    console.log('jumToEndPage');
    this.currentPageNumber = this.pageArray[this.pageArray.length - 1];
    this.getArchiveHistory();
  }
  onSortClick(event) {
    let target = event.currentTarget,
      classList = target.classList;

    if (classList.contains('icon-Sort_amount_descending_SPECIAL')) {
      classList.remove('icon-Sort_amount_descending_SPECIAL');
      classList.add('icon-Sort_amount_ascending_SPECIAL');
      this.sortDir = 1;
      this.getArchiveHistory();
    } else {
      classList.add('icon-Sort_amount_descending_SPECIAL');
      classList.remove('icon-Sort_amount_ascending_SPECIAL');
      this.sortDir = 2;
      this.getArchiveHistory();
    }
  }
  updateGridData(event) {
    this.appendArchiveHistoryGrid = event.isLoadMoreClicked;
    this.currentPageNumber = event.pageNumber;
    this.getArchiveHistory();
  }
}
