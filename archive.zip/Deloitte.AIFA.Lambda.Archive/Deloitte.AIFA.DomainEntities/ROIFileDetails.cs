﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
    public class ROIFileDetails
    {

        public long RoiID { get; set; }
        public string RoiNumber { get; set; }
        public string S3FileName { get; set; }
        public string S3FilePath { get; set; }
        public long FileTransferId { get; set; }

    }

}
