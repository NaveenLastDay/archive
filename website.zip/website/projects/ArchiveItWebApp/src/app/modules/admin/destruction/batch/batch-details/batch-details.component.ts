import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { BatchDetailsInfo, BatchHistoryDetails, DestructionBatch, DestructionBatchDetail } from '../../../../../models/batch-details.model';
import { DestructionService } from '../../../../../services/destruction.service';
import { ModalService } from '../../../../shared/modal';
import { NotifierService} from "angular-notifier";
import { SharedService } from 'projects/ArchiveItWebApp/src/app/services/shared.service';
import { Workbook } from 'exceljs';
import * as fs from 'file-saver';
import { DatePipe } from '@angular/common';
import { formatDate } from '@angular/common';

@Component({
  selector: 'app-batch-details',
  templateUrl: './batch-details.component.html',
  styleUrls: ['./batch-details.component.css']
})
export class BatchDetailsComponent implements OnInit {
/*sorting */
sortColumnDialog: number = -1;
sortColumn : string ='DestructionEligibleDate'
sortascdesc: number=0;
sortBy: number = 3;
currentPageNumber: number=1;
columnByEnum: any = BatcheDetailColumnBy;
/*sorting*/

  batchID:string;
  batchDetailInfoList = new BatchDetailsInfo();
  destructionBatch = new DestructionBatch();
  archiveBatchDetails = new Array<DestructionBatchDetail>();
  batchArchiveObjects:any[];
  totalBatchsRecords:number = 0;
  totalBatchArchivesRecords:number = 0;
  readonly pageSize: number = 100;
  hoverIndex: number = -1;
  archiveNumber:string="";
  expandedArchiveNumber:string="";
  archiveNumberSearch:string="";
  limitObjNumber:number=5;
  ascUniqueIdSort = true;
  selectedArchives: any = [];
  unSelectedArchives: any = [];
  masterSelected : boolean =  false;
  addArchiveMasterSelected: boolean =  false;
  selectedAllArchives: boolean =  false;
  inEligibleArchives : any[];
  archiveSimpleSearch:string;
  addArchiveSimpleSearch:string;
  showSearchContent:boolean=false;
  ArchiveNumberForExportToExcel:string='';
  showAddArchiveSearchContent:boolean=false;
  myBatchAdvancedSearchForm:FormGroup;
  AddClientText : string = '';
  AddArchiveClientText : string = '';
  searchDistEligibleDateShow:boolean=false;
  DestrElgStartDate:string;
  DestrElgEndDate:string;
  DestructionEligibleFullDate:string;
  disableBtn:boolean=false;
  selectedRecordStatus: number[] = [];
  advSelectedHoldFlag:number=-1;
  advSelectedLinkedArchive:number=-1;
  advSelectedRetentionException:number=-1;
  selectedClientsList: Array<any> = [];
  selectedHolds: Array<any> = [];
  clients: Array<any> = [];
  index: number = 0;
  simpleSearch:string= '';
  showInElgibleArchives:number=0;
  inEligibleArchivesCount:number = 0;
  inEligibleArchivesToRemoveCnt:number=0;
  IsSimpleSearch:number = 0;
  showBulkRemoval:boolean=false;
  batchDetailsID:number;
  isUpdateGridData:boolean;
  removeArchive:string="";
  removeTextMessage:string;
  archiveCheckAll:boolean=false;
  isClientSort:boolean=false;
  addArchiveSuccess = false;
  addedArchivesCount:number = 0;
  filterarray: any = [];
  noOfSelectedObjects:number = 0;
  readonly searchParamEligibleDate: string = "Destruction eligible date:";
  readonly searchParamClient: string = "Client:";
  readonly searchParamArchiveNumber: string = "Archive Number:";
  BatchDetailsResultGridColumns: any =BatchDetailsResultGridColumns;
  BatchHistoryGridColumns:any = BatchHistoryGridColumns;
  readonly emptyStringInExcel : string = " ";
  batchHistoryDetails : BatchHistoryDetails[]=[];
  columnFilters:any[]=
  [
    {
      "displayName": "Archive #",
      "value": this.BatchDetailsResultGridColumns.ArchiveNumber,
      "checked": true
    },
    {
      "displayName": "Client",
      "value": this.BatchDetailsResultGridColumns.Client,
      "checked": true
    },
    {
      "displayName": "Destruction eligible date",
      "value": this.BatchDetailsResultGridColumns.DestructionEligibleDate,
      "checked": true
    },
    {
      "displayName": "Retention exception triggered date",
      "value": this.BatchDetailsResultGridColumns.RetentionExceptionTriggerDate,
      "checked": true
    },

    {
      "displayName": "Hold flag",
      "value": this.BatchDetailsResultGridColumns.HoldFlag,
      "checked": true
    },
    {
      "displayName": "Objects",
      "value": this.BatchDetailsResultGridColumns.Objects,
      "checked": true
    },
    {
      "displayName": "Unique Id",
      "value": this.BatchDetailsResultGridColumns.UniqueId,
      "checked": true
    },
    {
      "displayName": "Barcode",
      "value": this.BatchDetailsResultGridColumns.Barcode,
      "checked": true
    },
    {
      "displayName": "Hard Copy Record Status",
      "value": this.BatchDetailsResultGridColumns.HardCopyRecordStatus,
      "checked": true
    },
    {
      "displayName": "Electronic Record Status",
      "value": this.BatchDetailsResultGridColumns.ElectronicRecordStatus,
      "checked": true
    },  

  ]
  /* end of Export to Excel */
  columnHistoryFilters: any[] =
  [
    {
      "displayName": "Archive #",
      "value": this.BatchHistoryGridColumns.ArchiveNumber,
      "checked": true
    },
    {
      "displayName": "Action",
      "value": this.BatchHistoryGridColumns.Status,
      "checked": true
    },

    {
      "displayName": "Action by",
      "value": this.BatchHistoryGridColumns.CreatedBy,
      "checked": true
    },
    {
      "displayName": "Date",
      "value": this.BatchHistoryGridColumns.CreatedDate,
      "checked": true
    }
  ]


  constructor(private fb:FormBuilder,private activatedRoute: ActivatedRoute,private datapipe: DatePipe,private sharedService: SharedService, private modalService: ModalService, private _destService: DestructionService,private SpinnerService: NgxSpinnerService,private _notifierService:NotifierService,) {
    this.myBatchAdvancedSearchForm = fb.group({
      'inputClientName': [null, Validators.required],
      'inputArchiveName': [null, Validators.required],
      'DestEligibleDate': [null, Validators.required],
      'recordStatuscheckboxgroup' : [null, Validators.required],
      'retentionExceptionRadioGroup' : [-1, Validators.required],
      'holdRadioGroup' : [-1, Validators.required],
      'linkedArchiveRadioGroup' : [-1, Validators.required]
    });
  }

  ngOnInit() {
    this.batchID = this.activatedRoute.snapshot.paramMap.get('batchId');
    this.batchDetailsID=0;
    let todaydate = new Date();
    this.DestructionEligibleFullDate = this.convertToMMDDYYYY(todaydate.toString()) + ' - ' + this.convertToMMDDYYYY(todaydate.toString());
    this.advSelectedLinkedArchive=-1;
    this.advSelectedRetentionException=-1;
    this.advSelectedHoldFlag=-1;
    this.selectedRecordStatus=[1,2,3,5,6];
    this.SpinnerService.show();
    this.unSelectedArchives = [];
    this.selectedArchives = [];
    this.getBatchData();
  }
  ngDoCheck() {
    this.validations();
  }
  generateReportClicked(data1){
    let BatchDetailsReport: any[] = [];
    let filterdColumns = (data1.filter(x => x.checked));
    this._destService.GetBatchDetailInfoForExportToExcel(this.batchID,0, 0, this.sortascdesc, this.sortColumn, this.IsSimpleSearch,this.simpleSearch,
      this.ArchiveNumberForExportToExcel, this.AddClientText, this.selectedRecordStatus.toString(),
      this.advSelectedRetentionException, this.advSelectedHoldFlag, this.advSelectedLinkedArchive, this.showInElgibleArchives).subscribe(
        data => {
         if(data)
         {
          data.forEach(element => {
          let Batch = {};
            filterdColumns.forEach(column => {

              if (column["value"] == this.BatchDetailsResultGridColumns.ArchiveNumber) { //Archive#
                Batch[this.BatchDetailsResultGridColumns[this.BatchDetailsResultGridColumns.ArchiveNumber]] = element.archiveNumber || this.emptyStringInExcel;
              }
              if (column["value"] == this.BatchDetailsResultGridColumns.Client) { //Client
                Batch[this.BatchDetailsResultGridColumns[this.BatchDetailsResultGridColumns.Client]] = element.clientName || this.emptyStringInExcel;
              }
              if (column["value"] == this.BatchDetailsResultGridColumns.DestructionEligibleDate) { //Destruction Eligible date
                Batch[this.BatchDetailsResultGridColumns[this.BatchDetailsResultGridColumns.DestructionEligibleDate]] =this.datapipe.transform(element.destructionEligibleDate,'MM/dd/yyyy')  || this.emptyStringInExcel;
              }
              if (column["value"] == this.BatchDetailsResultGridColumns.RetentionExceptionTriggerDate) { //Retention trigger date
                Batch[this.BatchDetailsResultGridColumns[this.BatchDetailsResultGridColumns.RetentionExceptionTriggerDate]] = element.retentionExceptionTriggerDate || this.emptyStringInExcel;
              }
              if (column["value"] == this.BatchDetailsResultGridColumns.HoldFlag) { //HoldFlag
                Batch[this.BatchDetailsResultGridColumns[this.BatchDetailsResultGridColumns.HoldFlag]] = element.holdsApplied || this.emptyStringInExcel;
              }
              if (column["value"] == this.BatchDetailsResultGridColumns.Objects) { //Objects
                Batch[this.BatchDetailsResultGridColumns[this.BatchDetailsResultGridColumns.Objects]] = element.objectsCount || this.emptyStringInExcel;
              }
              if (column["value"] == this.BatchDetailsResultGridColumns.UniqueId) { //UniqueID
                Batch[this.BatchDetailsResultGridColumns[this.BatchDetailsResultGridColumns.UniqueId]] = element.uniqueID || this.emptyStringInExcel;
              }
              if (column["value"] == this.BatchDetailsResultGridColumns.Barcode) { //Barcode
                Batch[this.BatchDetailsResultGridColumns[this.BatchDetailsResultGridColumns.Barcode]] = element.barCode || this.emptyStringInExcel;
              }
              if (column["value"] == this.BatchDetailsResultGridColumns.HardCopyRecordStatus) { //HardCopyRecordStatus
                Batch[this.BatchDetailsResultGridColumns[this.BatchDetailsResultGridColumns.HardCopyRecordStatus]] = element.hardCopyRecordStatus || this.emptyStringInExcel;
              }
              if (column["value"] == this.BatchDetailsResultGridColumns.ElectronicRecordStatus) { //ElectronicRecordStatus
                Batch[this.BatchDetailsResultGridColumns[this.BatchDetailsResultGridColumns.ElectronicRecordStatus]] = element.electronicRecordStatus || this.emptyStringInExcel;
              }    
           });
           BatchDetailsReport.push(Batch);
          });
          if (BatchDetailsReport && BatchDetailsReport.length) {
            this.sharedService.generateExcel(this.batchID+"_Batch_Details","BatchDetails", filterdColumns.map(x => x.displayName), BatchDetailsReport);
          }
            }
          }
      )};


    generateExcel(fileName: string, sheetName: string, columns: string[], data: any[]) {
      //debugger;
      let workbook = new Workbook();
      let worksheet = workbook.addWorksheet(sheetName, {
        views: [
          { state: 'frozen', ySplit: 1 }
        ]
      });
      let topRow = worksheet.addRow(columns);
      // topRow.font = {
      //   name: 'Calibri',
      //   size: 16,
      //   underline: 'single',
      //   bold: true,
      //   color: { argb: '0085A3' }
      // }
      topRow.font = {
        bold: true,
      }
      topRow.eachCell(
        cell => {
          cell.border = {
            top: { style: 'thin' },
            left: { style: 'thin' },
            bottom: { style: 'thin' },
            right: { style: 'thin' }
          };
          cell.alignment = {
            vertical: 'top',
            horizontal: 'left',
            wrapText: true
          }
        }
      );

      data.forEach(d => {
        //console.log(d);
        let row = worksheet.addRow(Object.values(d));
        row.alignment = { vertical: 'top', horizontal: 'left', wrapText: true };
        row.eachCell(
          cell => {
            cell.border = {
              top: { style: 'thin' },
              left: { style: 'thin' },
              bottom: { style: 'thin' },
              right: { style: 'thin' }
            };
            cell.alignment = {
              vertical: 'top',
              horizontal: 'left',
              wrapText: true
            }
          }
        )
      });

      workbook.xlsx.writeBuffer().then((x) => {
        let blob = new Blob([x], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
        fs.saveAs(blob, fileName + '.xlsx');
        this.SpinnerService.hide();
      })

    }

  getBatchData() {
      this._destService.GetBatchDetailInfo(this.batchID,this.currentPageNumber, this.pageSize, this.sortascdesc, this.sortColumn, this.IsSimpleSearch,this.simpleSearch,
      this.archiveNumber, this.AddClientText, this.selectedRecordStatus.toString(),
      this.advSelectedRetentionException, this.advSelectedHoldFlag, this.advSelectedLinkedArchive, this.showInElgibleArchives).subscribe(
        data => {
          if (data){
            this.batchDetailInfoList =  data ? data : [];
            this.destructionBatch = this.batchDetailInfoList.batch;
            this.DestructionEligibleFullDate = this.convertToMMDDYYYY(this.destructionBatch.destructionEligibleFromDate)  + ' - ' + this.convertToMMDDYYYY(this.destructionBatch.destructionEligibleToDate);
            this.inEligibleArchivesCount = data["inEligibleArchivesCount"];
            this.totalBatchsRecords =  data["totalRecords"];
            if(this.inEligibleArchivesCount>0)
            if(this.archiveNumber !="" || this.AddClientText !="" || this.selectedRecordStatus.toString() != "1,2,3,5,6" ||
              this.advSelectedRetentionException != -1 || this.advSelectedHoldFlag !=-1 || this.advSelectedLinkedArchive !=-1)
              {
                this.inEligibleArchivesToRemoveCnt=this.totalBatchsRecords;
              }
            else
              {
                this.inEligibleArchivesToRemoveCnt=this.inEligibleArchivesCount;
              }
            this.sortUniqueIDColumn();
            
          }
          this.SpinnerService.hide();
          if(this.addArchiveSuccess){
            let successMessage = this.addedArchivesCount > 1 ? " archives added" :  " archive added";
            this._notifierService.notify("success", this.addedArchivesCount + successMessage);
            this.addArchiveSuccess = false;
          }
     });
    }

    sortByArchive() {
    this.sortascdesc == 0 ? this.sortascdesc = 1 : this.sortascdesc = 0;
    this.getBatchData();
    }
    SearchByIneligibleRecords(event){
      this.currentPageNumber=1;
      if(event.target.checked==true)
      this.showInElgibleArchives = 1;
      else
      this.showInElgibleArchives = 0;
      this.getBatchData();
    }
  OpenBatchHistorydetails(){
    this.batchHistoryDetails = [];
    this._destService.GetBatchHistoryDetails(this.batchID).subscribe(
      data => {
        if(data)
        {
          this.batchHistoryDetails = data;
        }
      });

    this.modalService.openWithCustomWidth("Batch_History_Modal", "600");
  }

  addEligibleArchies() {
    this.currentPageNumber = 1;
    this.addArchiveMasterSelected = false;
    this.selectedAllArchives = false;
    this.archiveBatchDetails=[];
    this.showSearchContent=false;
    this.showAddArchiveSearchContent = false;
    this.ResetSearchParameters(true);
    this.modalService.openWithCustomWidth("addArchiveFeature", "1280");
  }
  getEligibleArchiveData() {
    this._destService.GetBatchArchiveDetails(this.batchID,this.currentPageNumber, this.pageSize, this.sortascdesc, this.sortColumn, this.IsSimpleSearch,this.simpleSearch,
    this.archiveNumberSearch, this.AddArchiveClientText, this.selectedRecordStatus.toString(), this.advSelectedRetentionException, this.advSelectedHoldFlag, this.advSelectedLinkedArchive, this.showInElgibleArchives).subscribe(
      data => {
        if (data.length > 0){
          this.archiveBatchDetails =  data ? data : [];
          this.totalBatchArchivesRecords = data[0]["totalRecords"];
        }
        else
        {
          this.archiveBatchDetails = [];
          this.totalBatchArchivesRecords = 0;
          this.SpinnerService.hide();
        }
   });
  }

  closeModalDialog(Action:string) {
    this.unSelectedArchives = [];
    this.selectedArchives = [];
    this.resetAdvancedSearchFormData();
    this.modalService.close(Action);
  }
  mouseOver(event: any, index: number) {
    this.hoverIndex = index;
    //event.stopPropagation();
  }

  mouseOut(event: any) {
    let name: string = '';
    let present: number = -1;

    name = event.toElement ? event.toElement.getAttribute('name') : '';
    present = name ? name.search("AccessArchiveTop") : -1;

    if (event.toElement && present == -1 && (event.toElement["tagName"] != 'td' || event.toElement.className == 'trBatchGridHeaderFont')) {
      this.hoverIndex = -1;
    }
  }
  showArchiveDetails(archiveNumber : string, index : number){
    this.index = index;
    if (this.expandedArchiveNumber == archiveNumber) {
      this.expandedArchiveNumber = '';
    }
    else {
      this.limitObjNumber=5;
      this.expandedArchiveNumber = archiveNumber;
    }
  }
  show5MoreObjects(){
   this.limitObjNumber += 5;
   console.log(this.limitObjNumber + " Number of objects to load...");
  }
  public sortUniqueIDColumn() {
    console.log("Sort calling.. " + this.index)
    if(this.batchDetailInfoList.batchDetails.length>0){
      this.ascUniqueIdSort = !this.ascUniqueIdSort;
      if(this.ascUniqueIdSort) {
        this.batchDetailInfoList.batchDetails[this.index].destructionBatchRecordDetail.sort((a,b) => a.uniqueID.localeCompare(b.uniqueID)); // For ascending sort
      } else {
        this.batchDetailInfoList.batchDetails[this.index].destructionBatchRecordDetail.sort((a, b) => b.uniqueID.localeCompare(a.uniqueID)); // For descending sort
      }
    }
  }

  ApplyBatchCheckboxSelectAll(e: any) {
      if(e.target.checked === true){
        this.showBulkRemoval=true;
        this.archiveCheckAll=true;
        this.masterSelected = true;
        this.selectedArchives = [];
      }
      else{
        this.showBulkRemoval=false;
        this.archiveCheckAll=false;
        this.masterSelected = false;
        this.selectedArchives = [];
      }
    }
    updateGridData(event, basicBatchData) {
      this.isUpdateGridData = event.isLoadMoreClicked;
      this.currentPageNumber = event.pageNumber;
      if(basicBatchData){
      this._destService.GetBatchDetailInfo(this.batchID,this.currentPageNumber, this.pageSize, this.sortascdesc, this.sortColumn, this.IsSimpleSearch,this.simpleSearch,
        this.archiveNumber, this.AddClientText, this.selectedRecordStatus.toString(), this.advSelectedRetentionException, this.advSelectedHoldFlag, this.advSelectedLinkedArchive, this.showInElgibleArchives).subscribe(
          data => {
          if (this.isUpdateGridData && data){
            for(var i =0;i<data["batchDetails"].length;i++){
              this.batchDetailInfoList.batchDetails.push(data["batchDetails"][i]);
            }
            this.inEligibleArchivesCount = data["inEligibleArchivesCount"];
            this.totalBatchsRecords =  data["totalRecords"];
            this.sortUniqueIDColumn();
            }
            else{
              this.batchDetailInfoList.batchDetails =  data["batchDetails"];
              this.inEligibleArchivesCount = data["inEligibleArchivesCount"];
              this.totalBatchsRecords =  data["totalRecords"];
              this.sortUniqueIDColumn();
            }
        this.SpinnerService.hide();
       });
      }
      else{
        this._destService.GetBatchArchiveDetails(this.batchID,this.currentPageNumber, this.pageSize, this.sortascdesc, this.sortColumn, this.IsSimpleSearch,this.simpleSearch,
          this.archiveNumberSearch, this.AddArchiveClientText, this.selectedRecordStatus.toString(),
          this.advSelectedRetentionException, this.advSelectedHoldFlag, this.advSelectedLinkedArchive, this.showInElgibleArchives).subscribe(
            data => {
              if (this.isUpdateGridData && data){
                for(var i =0;i<data.length;i++){
                  if(this.addArchiveMasterSelected || this.selectedAllArchives)
                  data[i]["isSelectedArchive"]=true;
                  this.getArchiveSelection( data[i].isSelectedArchive, data[i].archiveNumber);
                  this.archiveBatchDetails.push(data[i]);
                }
              }
              else{
                console.log("page shifts unSelected archives :: ", this.unSelectedArchives);
                for(var i =0;i<data.length;i++){
                  if(this.addArchiveMasterSelected || this.selectedAllArchives){
                    data[i]["isSelectedArchive"]=true;
                    if(!this.selectedArchives.includes(data[i].archiveNumber)){
                    if(!this.unSelectedArchives.includes(data[i].archiveNumber))
                    this.getArchiveSelection(data[i].isSelectedArchive, data[i].archiveNumber);
                    else
                    data[i]["isSelectedArchive"]=false;
                    }
                  }
                }
                this.archiveBatchDetails =  data ? data : [];
              }
             this.totalBatchArchivesRecords = data[0]["totalRecords"];
          this.SpinnerService.hide();
         });
      }
    }
    onSimpleSearch(searchValue:string, isAddArchiveSearch){
      this.ArchiveNumberForExportToExcel=this.archiveNumber;
      this.expandedArchiveNumber = "";
      this.unSelectedArchives = [];
      this.selectedArchives = [];
      this.currentPageNumber=1;
      this.simpleSearch = searchValue;
      if(this.simpleSearch)
      this.IsSimpleSearch = 1;
      else
      this.IsSimpleSearch = 0;
      if(isAddArchiveSearch)
      this.getEligibleArchiveData();
      else
      this.getBatchData();
    }
    RedirecttoManageBatch(){
      console.log("Navigate URL pending");
    }
    toggleAdvancedSearch(isaddArchive:boolean){
      this.simpleSearch ="";
      this.archiveSimpleSearch = "";
      this.addArchiveSimpleSearch = "";
      this.IsSimpleSearch = 0;
      if(isaddArchive)
      this.showAddArchiveSearchContent = !this.showAddArchiveSearchContent;
      else
      this.showSearchContent = !this.showSearchContent;
    }

    onDestEligibleDateChange(event:any){
      console.log(event);
    }
    ResetSearchParameters(isaddArchive){
      this.resetAdvancedSearchFormData();
      if(isaddArchive)
      this.getEligibleArchiveData();
      else
      this.getBatchData();
    }
    resetAdvancedSearchFormData(){
      this.myBatchAdvancedSearchForm.controls.inputClientName.reset();
      this.myBatchAdvancedSearchForm.controls.inputArchiveName.reset();
      this.myBatchAdvancedSearchForm.controls.retentionExceptionRadioGroup.patchValue(-1);
      this.myBatchAdvancedSearchForm.controls.holdRadioGroup.patchValue(-1);
      this.myBatchAdvancedSearchForm.controls.linkedArchiveRadioGroup.patchValue(-1);
      this.myBatchAdvancedSearchForm.controls.recordStatuscheckboxgroup.patchValue(true);
      this.selectedClientsList = [];
      this.AddClientText = "";
      this.AddArchiveClientText = "";
      this.archiveNumber="";
      this.ArchiveNumberForExportToExcel="";
      this.archiveNumberSearch = "";
      this.simpleSearch = "";
      this.addArchiveSimpleSearch = "";
      this.IsSimpleSearch = 0;
      this.selectedRecordStatus=[1,2,3,5,6];
      this.advSelectedLinkedArchive=-1;
      this.advSelectedRetentionException=-1;
      this.advSelectedHoldFlag=-1;
      this.currentPageNumber =1;
      this.filterarray = [];
      this.unSelectedArchives = [];
      this.selectedArchives = [];
    }
    closeAdvanceSearchContent(){
      this.showSearchContent=false;
      this.showAddArchiveSearchContent=false;
      // this.resetAdvancedSearchFormData();
    }
    advSearchBatch(){
      this.expandedArchiveNumber = "";
      this.currentPageNumber=1;
      this.IsSimpleSearch=0;
      this.getBatchData();
      this.showSearchContent=false;
      this.ArchiveNumberForExportToExcel=this.archiveNumber;
    }
    eligibleDatePickerToggle(){
      this.searchDistEligibleDateShow = !this.searchDistEligibleDateShow;
     }
     selectDistEligibleDate(event) {
      if (event != undefined) {
        this.DestructionEligibleFullDate = "";
        if (event[0].fromdate != "" && event[1].todate != "") {
          this.DestrElgStartDate = this.getDateInMySQLFomat(event[0].fromdate);
          this.DestrElgEndDate = this.getDateInMySQLFomat(event[1].todate);
          this.DestructionEligibleFullDate = event[0].fromdate + " — " + event[1].todate;
          console.log("DestructionEligibleFullDate:" + this.DestructionEligibleFullDate);
        }
      }
    }
    getDateInMySQLFomat(date: string) {
      // current date format
      return date.split("/")[2] + "-" + date.split("/")[0] + "-" + date.split("/")[1];
    }

    onClientSearch(searchByValue, isAddArchiveSearch)
    {
      if(isAddArchiveSearch)
      this.AddClientText = searchByValue;
      else
      this.AddArchiveClientText = searchByValue;
    }

    AddClient(){
      if(this.AddClientText !=''){
        if (this.selectedClientsList.length > 0) {
          var statusExists = this.selectedClientsList.findIndex(x => x.Status == this.AddClientText)
          if (statusExists == -1) {
            this.selectedClientsList.push(this.AddClientText);
          }
        }
        else {
          this.selectedClientsList.push(this.AddClientText);
        }
      }
      this.AddClientText='';
    }


    deleteClientItem(deleteItem){
      this.selectedClientsList = this.selectedClientsList.filter(e => e !== deleteItem);
    }
    SearchBySelectedRetentionException(e){
      console.log(e.target.id);
      if(e.target.id=='showall')
      this.advSelectedRetentionException=BatchRetentionException.ShowAll;
      else if(e.target.id=='applied')
      this.advSelectedRetentionException=BatchRetentionException.Applied;
      else
      this.advSelectedRetentionException=BatchRetentionException.NotApplied;
      this.myBatchAdvancedSearchForm.controls.retentionExceptionRadioGroup.patchValue(this.advSelectedRetentionException);
   }
   SearchBySelectedLinkedArchive(e){
    console.log(e.target.id);
    if(e.target.id=='showall')
    this.advSelectedLinkedArchive=BatchLinkedArchive.ShowAll;
    else if(e.target.id=='linked')
    this.advSelectedLinkedArchive=BatchLinkedArchive.Linked;
    else
    this.advSelectedLinkedArchive=BatchLinkedArchive.NotLinked;
    this.myBatchAdvancedSearchForm.controls.linkedArchiveRadioGroup.patchValue(this.advSelectedLinkedArchive);
 }
 SearchBySelectedHoldFlag(e){
  console.log(e.target.id);
  if(e.target.id=='showall')
  this.advSelectedHoldFlag=BatchHoldFlag.ShowAll;
  else if(e.target.id=='applied')
  this.advSelectedHoldFlag=BatchHoldFlag.Applied;
  else
  this.advSelectedHoldFlag=BatchHoldFlag.NotApplied;
  this.myBatchAdvancedSearchForm.controls.holdRadioGroup.patchValue(this.advSelectedHoldFlag);
}
   SearchBySelectedRecordCheck(event) {
     if(event.target.checked==true){
     this.selectedRecordStatus.push(parseInt(event.target.value));
     }
     else{
       let index = this.selectedRecordStatus.indexOf(parseInt(event.target.value));
       this.selectedRecordStatus.splice(index, 1);
     }
     console.log(this.selectedRecordStatus);
   }
    validations() {
      let hasError: boolean = false;
      hasError = (this.DestructionEligibleFullDate != undefined || this.archiveNumber != undefined);
      if(hasError)
      this.disableBtn=false;
      else
      this.disableBtn=true;
    }
    convertToMMDDYYYY(toDate: string){
      console.log(toDate);
      let dateInput = new Date(toDate);
      return (dateInput.getMonth()+1) +'/'+dateInput.getDate()+'/'+dateInput.getFullYear();
    }

    openRemoveInEligibleRecordsModal(modalType: string,archiveNumber:string) {
      // If archivenumber is 0 then Bulk removal
      // If archivenumber is not 0 then Individual removal
      if(archiveNumber=="0")
      {
        this.removeTextMessage= this.inEligibleArchivesToRemoveCnt + " archives";
      }
      else
      {
        this.removeTextMessage= archiveNumber + " archive";
      }
      this.removeArchive=archiveNumber;
      this.modalService.openWithCustomWidth(modalType, "540");
    }
    removeIneligibleRecords(){
      var parameters={
        "BatchNumber" : this.batchID,
        "PageNumber" : this.currentPageNumber,
        "PageSize" : this.pageSize,
        "SortDirection" : this.sortascdesc,
        "Sort_By" : this.sortColumn,
        "IsSimpleSearch" : this.IsSimpleSearch,
        "FilterText" : this.simpleSearch,
        "ClientName" : this.AddClientText,
        "ArchiveNumber" : this.removeArchive=="0" ? this.archiveNumber : this.removeArchive,
        "PhysicalRecordStatus" : this.selectedRecordStatus.toString(),
        "RententionExceptionApplied" : this.advSelectedRetentionException,
        "HoldApplied" : this.advSelectedHoldFlag,
        "LinkedArchives" : this.advSelectedLinkedArchive,
        "ShowInEligibleArchives" : this.showInElgibleArchives,
        "SelectAll" : this.removeArchive=="0" ? 1 : 0
        };
      if(this.showBulkRemoval){
        this.showInElgibleArchives = 0;
      }
      this._destService.RemoveIneligibleRecords(parameters).subscribe(
        data => {
          this.modalService.close('remove-archive');
          this.showBulkRemoval=false;
          this.masterSelected=false;
          this.archiveCheckAll=false;
          this.removeArchive=="0";
          if (data=="Removal Successful")
          {
            this._notifierService.notify(
              "success",
              "Remove successful. Selected archive(s) have been removed"
            );
            this.getBatchData();
            this.SpinnerService.hide();
          }
          else
          {
            this._notifierService.notify(
              "error",
              "Remove unsuccessful"
            );
          }
        }
      );

    }

    sortHeaderASCDESC(event, directionType?:string){
      this.expandedArchiveNumber = "";
       var clickedColumn:number=event;
       this.isClientSort = false;
        /*For ArchiveNumber*/
        if(clickedColumn==1 && this.sortBy!=1){
        this.sortBy=1;
         this.sortColumn="ArchiveNumber";
         this.sortascdesc=1;
       }
       else if(clickedColumn==1 && this.sortBy==1){
        this.sortBy=0;
        this.sortColumn="ArchiveNumber";
        this.sortascdesc=0;
       }
     /*for Client */
       else if(clickedColumn==2 && this.sortBy!=2 && directionType == 'asc'){
        this.sortBy=2;
         this.sortColumn="Client";
         this.sortascdesc=0;
       }
       else if(clickedColumn==2 && this.sortBy==2 && directionType == 'dsc'){
        this.sortBy=0;
        this.sortColumn="Client";
        this.sortascdesc=1;
       }
       /*for DestructionEligibleToDate */
       else if(clickedColumn==3 && this.sortBy!=3){
        this.sortBy=3;
         this.sortColumn="DestructionEligibleDate";
         this.sortascdesc=0;
       }
       else if(clickedColumn==3 && this.sortBy==3){
        this.sortBy=0;
        this.sortColumn="DestructionEligibleDate";
        this.sortascdesc=1;
       }
       /*for RetentionExceptionTriggredDate */
       else if(clickedColumn==4 && this.sortBy!=4){
        this.sortBy=4;
         this.sortColumn="RetentionExceptionTriggeredDate";
         this.sortascdesc=0;
       }
       else if(clickedColumn==4 && this.sortBy==4){
        this.sortBy=0;
        this.sortColumn="RetentionExceptionTriggeredDate";
        this.sortascdesc=1;
       }/*for HoldApplied */
       else if(clickedColumn==5 && this.sortBy!=5){
        this.sortBy=5;
         this.sortColumn="HoldApplied";
         this.sortascdesc=1;
       }
       else if(clickedColumn==5 && this.sortBy==5){
        this.sortBy=0;
        this.sortColumn="HoldApplied";
        this.sortascdesc=0;
       }/*for ObjectsCount */
       else if(clickedColumn==6 && this.sortBy!=6){
        this.sortBy=6;
         this.sortColumn="ObjectsCount";
         this.sortascdesc=0;
       }
       else if(clickedColumn==6 && this.sortBy==6){
        this.sortBy=0;
        this.sortColumn="ObjectsCount";
        this.sortascdesc=1;
       }
       this.currentPageNumber=1;
       this.getBatchData();
      }
      sortAddArchiveHeaderASCDESC(event, directionType?:string){
        var clickedColumn:number=event;
        this.isClientSort = false;
         /*For ArchiveNumber*/
         if(clickedColumn==1 && this.sortBy!=1){
         this.sortBy=1;
          this.sortColumn="ArchiveNumber";
          this.sortascdesc=1;
        }
        else if(clickedColumn==1 && this.sortBy==1){
         this.sortBy=0;
         this.sortColumn="ArchiveNumber";
         this.sortascdesc=0;
        }
      /*for Client */
        else if(clickedColumn==2 && this.sortBy!=2 && directionType == 'asc'){
         this.sortBy=2;
          this.sortColumn="Client";
          this.sortascdesc=0;
        }
        else if(clickedColumn==2 && this.sortBy==2 && directionType == 'dsc'){
         this.sortBy=0;
         this.sortColumn="Client";
         this.sortascdesc=1;
        }
        /*for DestructionEligibleToDate */
        else if(clickedColumn==3 && this.sortBy!=3){
         this.sortBy=3;
          this.sortColumn="DestructionEligibleDate";
          this.sortascdesc=0;
        }
        else if(clickedColumn==3 && this.sortBy==3){
         this.sortBy=0;
         this.sortColumn="DestructionEligibleDate";
         this.sortascdesc=1;
        }
        /*for RetentionExceptionTriggredDate */
        else if(clickedColumn==4 && this.sortBy!=4){
         this.sortBy=4;
          this.sortColumn="RetentionExceptionTriggeredDate";
          this.sortascdesc=0;
        }
        else if(clickedColumn==4 && this.sortBy==4){
         this.sortBy=0;
         this.sortColumn="RetentionExceptionTriggeredDate";
         this.sortascdesc=1;
        }/*for HoldApplied */
        else if(clickedColumn==5 && this.sortBy!=5){
         this.sortBy=5;
          this.sortColumn="HoldApplied";
          this.sortascdesc=1;
        }
        else if(clickedColumn==5 && this.sortBy==5){
         this.sortBy=0;
         this.sortColumn="HoldApplied";
         this.sortascdesc=0;
        }/*for ObjectsCount */
        else if(clickedColumn==6 && this.sortBy!=6){
         this.sortBy=6;
          this.sortColumn="ObjectsCount";
          this.sortascdesc=0;
        }
        else if(clickedColumn==6 && this.sortBy==6){
         this.sortBy=0;
         this.sortColumn="ObjectsCount";
         this.sortascdesc=1;
        }
        this.currentPageNumber=1;
        this.getEligibleArchiveData();
       }

    addArchiveAdvSearch() {
    this.filterarray = [];

    if ((this.DestructionEligibleFullDate || this.AddArchiveClientText || this.archiveNumberSearch) && this.filterarray) {

      // eligible date
      if (this.DestructionEligibleFullDate != '' && !this.filterarray.includes(this.DestructionEligibleFullDate)) {
        this.filterList(true, this.DestructionEligibleFullDate, true, 0);
      }

      // clients
      if (this.AddArchiveClientText != '' && !this.filterarray.includes(this.AddArchiveClientText)) {
        this.filterList(true, this.AddArchiveClientText, true, 1);
      }

      // archive number
      if (this.archiveNumberSearch != '' && !this.filterarray.includes(this.archiveNumberSearch)) {
        this.filterList(true, this.archiveNumberSearch, true, 2);
      }
    }
    else {
      return false;
    }
    this.unSelectedArchives = [];
    this.selectedArchives = [];
    this.currentPageNumber=1;
    this.IsSimpleSearch=0;
    this.getEligibleArchiveData();
    this.showAddArchiveSearchContent=false;
  }

  filterList(isAddFilter: boolean, textToFilter: string, isCommitFilter: boolean = false, isFilterPrefix: number = 0) {

    if (isAddFilter) {
      if (isCommitFilter && this.filterarray) {
        if (textToFilter != undefined) {
          var filterPrefix = this.searchParamEligibleDate;
          var filterPrefixString = "";
          if (isFilterPrefix == 1) {
            filterPrefix = this.searchParamClient;
          }
          else if (isFilterPrefix == 2) {
            filterPrefix = this.searchParamArchiveNumber;
          }
          filterPrefixString = filterPrefix + textToFilter;
          this.deleteItemFromFilterArray(filterPrefix);
          this.filterarray.push(filterPrefixString);
        }
      }
    }
  }
  deleteItemFromFilterArray(msg: string) {
    if (this.filterarray && this.filterarray.length > 0) {
      this.filterarray.forEach(textToFilter => {
        if (textToFilter.includes(msg)) {
          const index: number = this.filterarray.indexOf(textToFilter);
          if (index !== -1) {
            this.filterarray.splice(index, 1);
          }
        }
      });
    }
  }

  removeparam(event, searchparam: any, index: any) {
    this.filterarray.splice(index, 1);
    if (searchparam.includes(this.searchParamClient)) {
      this.AddArchiveClientText = "";
    }
    if (searchparam.includes(this.searchParamArchiveNumber)) {
      this.archiveNumberSearch = "";
    }
    this.currentPageNumber = 1;
    this.addArchiveMasterSelected = false;
    this.selectedAllArchives = false;
    this.archiveBatchDetails=[];
    this.getEligibleArchiveData();
  }

  addArchivesToBatch(){
    var parameters={
      "BatchNumber" : this.batchID,
      "PageNumber" : this.currentPageNumber,
      "PageSize" : this.pageSize,
      "SortDirection" : this.sortascdesc,
      "Sort_By" : this.sortColumn,
      "IsSimpleSearch" : this.IsSimpleSearch,
      "FilterText" : this.simpleSearch,
      "ClientName" : this.AddArchiveClientText,
      "ArchiveNumber" : this.archiveNumberSearch,
      "PhysicalRecordStatus" : this.selectedRecordStatus.toString(),
      "RententionExceptionApplied" : this.advSelectedRetentionException,
      "HoldApplied" : this.advSelectedHoldFlag,
      "LinkedArchives" : this.advSelectedLinkedArchive,
      "ShowInEligibleArchives" : this.showInElgibleArchives,
      "CheckedArchivesList" : this.selectedAllArchives ? "" : this.selectedArchives.toString(),
      "UncheckedArchivesList" : this.selectedAllArchives ? this.unSelectedArchives.toString() : "",
      "SelectAll" : this.selectedAllArchives ? 1 : 0
      };
    this._destService.AddArchiveDetailsToBatch(parameters).subscribe(
        data => {
          if (data == "Add Successful")
          {
            this.addArchiveSuccess = true;
            this.addedArchivesCount = (this.addArchiveMasterSelected || this.selectedAllArchives ? (this.totalBatchArchivesRecords - this.unSelectedArchives.length) : this.selectedArchives.length).toString();
            this.ResetSearchParameters(false);
            this.getBatchData();
          }
          else
          {
            this.addArchiveSuccess = false;
            this.addedArchivesCount = 0;
            this._notifierService.notify(
              "error",
              "archives not added"
            );
          }
          this.closeModalDialog('addArchiveFeature');
     });
  }

  SelectAllBatchArchives(e: any) {
    if(e.target.checked === true){
      this.addArchiveMasterSelected = true;
      this.selectedAllArchives = true;
      this.selectedArchives = [];
      this.unSelectedArchives = [];
    }
    else{
      this.addArchiveMasterSelected = false;
      this.selectedAllArchives = false
      this.selectedArchives = [];
      this.unSelectedArchives = [];
    }
    for(let i=0; i < this.archiveBatchDetails.length; i++){
      (e.target.checked) ? this.archiveBatchDetails[i].isSelectedArchive =true : this.archiveBatchDetails[i].isSelectedArchive = false;
      this.getArchiveSelection(this.archiveBatchDetails[i].isSelectedArchive , this.archiveBatchDetails[i].archiveNumber);
    }
  }
  getArchiveSelection(isSelected, archiveNum){
    if(isSelected){
      let obj={archiveNumber : archiveNum}
      this.selectedArchives.push(archiveNum);
      let index = this.unSelectedArchives.indexOf(archiveNum);
      if(index != -1)
      this.unSelectedArchives.splice(index, 1);
      if(this.archiveBatchDetails.length > 0 && this.selectedArchives.length === this.totalBatchArchivesRecords)
      {
        this.addArchiveMasterSelected = true;
      }
    }
    else{
      this.addArchiveMasterSelected = false;
      if(this.selectedAllArchives){
        this.unSelectedArchives.push(this.selectedArchives.find((archive) => archive == archiveNum));
      }
      this.selectedArchives = this.selectedArchives.filter(item => item !== archiveNum);
    }
    this.noOfSelectedObjects = this.addArchiveMasterSelected || this.selectedAllArchives ? (this.totalBatchArchivesRecords - this.unSelectedArchives.length) : this.selectedArchives.length;
  }
  generateHistoryReportClicked(data1){
    //this.SpinnerService.show();
    let batchHistoryReport: any[] = [];
    let filterdColumns = (data1.filter(x => x.checked));
    if (this.batchHistoryDetails.length > 0 || this.batchHistoryDetails.length == 0) {
      // this.batchHistoryDetails.push({archiveId: 0,archiveNumber:'-',createdBy: this.createdBy,createdDate:this.createdDate,holdId: this.holdId,holdNumber: this.GetHoldNumberFromSearchScreen,status: "Hold Created"});
      this.batchHistoryDetails.forEach(element => {
        let archive = {};
        filterdColumns.forEach(column => {

          if (column["value"] == this.BatchHistoryGridColumns.ArchiveNumber) { //Archive#
            archive[this.BatchHistoryGridColumns[this.BatchHistoryGridColumns.ArchiveNumber]] = element.archiveNumber || this.emptyStringInExcel;
          }
          if (column["value"] == this.BatchHistoryGridColumns.Status) { //Status#
            archive[this.BatchHistoryGridColumns[this.BatchHistoryGridColumns.Status]] = element.status || this.emptyStringInExcel;
          }
          if (column["value"] == this.BatchHistoryGridColumns.CreatedBy) { //CreatedBy#
            archive[this.BatchHistoryGridColumns[this.BatchHistoryGridColumns.CreatedBy]] = element.createdBy || this.emptyStringInExcel;
          }
          if (column["value"] == this.BatchHistoryGridColumns.CreatedDate) { //CreatedDate#
            archive[this.BatchHistoryGridColumns[this.BatchHistoryGridColumns.CreatedDate]] = formatDate(element.createdDate,'short','en-US','UTC -6')  || this.emptyStringInExcel;
          }
        });
          batchHistoryReport.push(archive);
      });
      if (batchHistoryReport && batchHistoryReport.length) {
        this.sharedService.generateExcel(this.batchID + "_History_Details", "BatchHistory", filterdColumns.map(x => x.displayName), batchHistoryReport);
      }
    }
    }


}

export enum BatchLinkedArchive{
  ShowAll=-1,
  Linked=1,
  NotLinked=0
}
export enum BatchDetailsResultGridColumns
{
ArchiveNumber = 1,
Client = 2,
DestructionEligibleDate = 3,
RetentionExceptionTriggerDate = 4,
HoldFlag= 5,
Objects = 6,
UniqueId=7,
IsPhysicalRecord=8,
Barcode=9,
ElectronicRecordStatus=10,
HardCopyRecordStatus=11
}

export enum BatchRetentionException{
  ShowAll=-1,
  Applied=1,
  NotApplied=0
}
export enum BatchHoldFlag{
  ShowAll=-1,
  Applied=1,
  NotApplied=0
}
export enum BatcheDetailColumnBy {
  ColumnBy_Default = -1,
  ColumnBy_ArchiveNumber = 1,
  ColumnBy_ClientName = 2,
  ColumnBy_DestructionEligibleFromDate = 3,
  ColumnBy_RetentionExcTriggredDate = 4,
  ColumnBy_HoldApplied = 5,
  ColumnBy_Objects = 6
}
export enum BatchHistoryGridColumns
{
  ArchiveNumber=1,
  Status=2,
  CreatedBy=3,
  CreatedDate=4
}