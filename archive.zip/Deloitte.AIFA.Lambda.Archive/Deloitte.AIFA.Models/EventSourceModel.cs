﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.Models
{
    public class EventSourceModel
    {
        public long EventSourceID { get; set; }
        public int EventTypeID { get; set; }
        public string Metadata { get; set; }
        public bool IsProcessed { get; set; }
        public DateTime CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public DateTime ModifiedDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime DeletedDate { get; set; }
        public string DeletedBy { get; set; }
    }
}
