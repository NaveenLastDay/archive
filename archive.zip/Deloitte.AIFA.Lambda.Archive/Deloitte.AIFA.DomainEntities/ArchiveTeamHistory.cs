﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
    public class ArchiveTeamHistory
    {
        public string Role { get; set; }
        public string CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public string ChangedFrom { get; set; }
        public string ChangedTo { get; set; }
        public int RowNumber { get; set; }
        public int Count { get; set; }
    }
}
