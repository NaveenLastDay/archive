import { Component, OnInit, ElementRef, ViewChild,EventEmitter,Output } from "@angular/core";
import { FileUploadEventService } from "../file-upload/fileupload.event.service";
import { ModalService } from "../../shared/modal";
import { ArchiveService } from '../../../services/archive.service';
import { FileUploadRecordService } from '../../../services/fileupload.record.service';
import { NotifierService } from "angular-notifier";
import { FielUploadService } from '../../../services/fileupload.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { FileUploadProcessService } from '../file-upload/fileupload.process.service';
import { EmspackagesService } from '../../../services/emspackages.service';
import { FormGroup, FormBuilder, Validators, FormArray, FormControl } from '@angular/forms';
import { DeliverableService } from '../../../services/deliverable.service';
import { NativeDateAdapter } from '@angular/material';
import { MatDateFormats } from '@angular/material/core';
import { DateAdapter, MAT_DATE_FORMATS } from '@angular/material/core';
import { PeoplePickerService } from './../../../services/MDREmployeeeDetails.service';
//import { PaginationComponent } from '../../shared/pagination/pagination.component';
import { ArchiveHomeService } from '../../../services/archive-home.service';
import { async } from '@angular/core/testing';

declare const zip: any;
export class AppDateAdapter extends NativeDateAdapter {
  format(date: Date, displayFormat: Object): string {
    if (displayFormat === 'input') {
      let day: string = date.getDate().toString();
      day = +day < 10 ? '0' + day : day;
      let month: string = (date.getMonth() + 1).toString();
      month = +month < 10 ? '0' + month : month;
      let year = date.getFullYear();
      return `${month}/${day}/${year}`;
    }
    return date.toDateString().split(' ')[1] + " " + date.toDateString().split(' ')[3];
  }
}
export const APP_DATE_FORMATS: MatDateFormats = {
  parse: {
    dateInput: { month: 'short', year: 'numeric', day: 'numeric' },
  },
  display: {
    dateInput: 'input',
    monthYearLabel: { year: 'numeric', month: 'numeric' },
    dateA11yLabel: {
      year: 'numeric', month: 'long', day: 'numeric'
    },
    monthYearA11yLabel: { year: 'numeric', month: 'long' },
  }
};

@Component({
  selector: "fileupload-wp",
  templateUrl: "./fileupload.wp.modal.component.html",
  styleUrls: ["./fileupload.wp.modal.component.css"],
  providers: [
    { provide: DateAdapter, useClass: AppDateAdapter },
    { provide: MAT_DATE_FORMATS, useValue: APP_DATE_FORMATS }
  ]
})
export class FileUploadWpModalComponent implements OnInit {
  @Output() openStateReasonModal: EventEmitter<string> = new EventEmitter();
  selectedFilesForUpload: any[];
  popUpHeaderText: string = "";
  enableBypassSecurityCheck: boolean = false;
  isOtherClicked: boolean = false;
  isServerClicked: boolean = false;
  fileUploadObject: any;
  fileId: string = "";
  @ViewChild("btnOpenFileDialog", { static: true })
  //@ViewChild('paginationComp',null)paginationComp:PaginationComponent;
  btnOpenFileDialog: ElementRef;
  displaySelectedFiles: boolean = false;
  displayHeader: boolean = true;
  displayLoading: boolean = false;
  eMSArchiveSource: string = "";
  WPEditedInResubmit:boolean;
  WPProvidedInResubmit:string='';
  WPEditedDate:Date;

  showPopUp: number = 0;

  module: string = "";
  fileTypeId: number;
  fileTypeDescription: string = "";
  uploadSource: string = "";
  archiveNumber: string = "";
  createdBy: string;
  acceptedMIMETypes: any;
  archiveFileId: number = 0;
  fileTransferId: number = 0;
  s3FileName: string = "";
  personnelNumber: number = 0;
  currentArchiveStatus: string = '';

  fileName: string;
  //fileSize: string = "";
  fileSize: number = -1;
  sunits: string = "";
  disableUploadButton: boolean = true;
  appendArchiveToGrid: boolean = false;

  // EMS Packages
  filterarray: any = [];
  submittedUsers: Array<any> = [];
  clientdetails: Array<any> = [];
  etmUsers: Array<any> = [];
  approveUsers: Array<any> = [];
  paramindex: number = 0;
  sortByEnum: any = emsGridDataSortBy;
  dtPickerEnum: any = EMSDateRangePicker;
  emsGridData: any[] = [];
  totalEmsDatas: number = -1;
  isBasicShow: boolean = true;
  isDefaultResult: boolean = false;
  isLoadedResult: boolean = true;
  isNoResult: boolean = false;
  isInputSearchResult: boolean = true;
  emsFileInfo:string=''

  searchtextvalue: string = ''; //searchkeyword
  loginuserId: number = 0;
  userAlias = this.adalSvc.LoggedInUserEmail.substring(0, this.adalSvc.LoggedInUserEmail.lastIndexOf("@"));
  sortBy: number = this.sortByEnum.SortBy_EngagementFileName_Asc;
  pageSize: number = 10;
  currentPageNumber: number = 1;
  displayingRecordsFrom: number = 0;
  displayingRecordsTo: number = 0;
  EmsCheckboxid: boolean;
  FileSelectionFlag: boolean;
  myForm: FormGroup;
  /*Resubmission Popup's */
  ShowResubmissionAlert: boolean = false;
  ShowResubmissionReasonAlert: boolean = false;
  resubmissionNewRecord: any;
  resubmissionSelf: any;
  ResubmissionReason: any = "";
  /*End Resubmission Popup's */
  advanced_form: FormGroup;
  show: boolean = false;
  packagecreationDtShow: boolean = false;
  submittedDtShow: boolean = false;
  periodEndDtShow: boolean = false;
  approvedDtShow: boolean = false;
  emsFileNames: string = '';

  clientName: string;
  bindclientname: string;
  submitterName: string;
  bindsubmittername: string;
  submitterNumber: number;
  EngagementTypeId: number;
  OfficeEngagementTypeId: number;
  engagementteammember: string;
  etmNumber: number;
  bindetmname: string;
  approverName: string;
  approverNumber: number;
  bindapprovername: string;

  engagements: any;
  officeEngagements: any;

  //Assigning variable for Dropdown
  EngagementType: string;
  EngagementTypes: any;
  EMSEngagementTypes: any;
  EngagementTypeName: string

  OfficeEngagementType: string;
  OfficeEngagementTypes: any;
  EMSOfficeEngagementTypes: any;
  OfficeEngagementTypeName: string

  archivePackageCreationDate: string;
  submittedDate: string;
  periodEndDate: string;
  approvedDate: string;

  //from and to dates
  archivePackageCreationDateFrom: string;
  archivePackageCreationDateTo: string;
  submittedDateFrom: string;
  submittedDateTo: string;
  periodEndDateFrom: string;
  periodEndDateTo: string;
  approvedDateFrom: string;
  approvedDateTo: string;
  isIncludeETM: boolean = true;

  as2fileNameArray = [];
  folderTitle: string = "";
  lastEdit: string = "";
  as2FileObjects: any;
  as2FileObjectNames = [];
  as2SelectedFileIndex: number;
  as2TotalFile: number;
  isAS2InitialPopupShow:boolean=false;

  readonly searchParamCNPrefix: string = "Client name:";
  readonly searchParamSNPrefix: string = "Submitter name:";
  readonly searchParamETPrefix: string = "Engagement type:";
  readonly searchParamETMPrefix: string = "Engagement team member:";
  readonly searchParamANPrefix: string = "Approver name:";
  readonly searchParamOREPrefix: string = "Office responsible for engagement:";
  readonly searchParamAPCPrefix: string = "Archive package creation date:";
  readonly searchParamSDPrefix: string = "Submitted date:";
  readonly searchParamPEPrefix: string = "Period end:";
  readonly searchParamADPrefix: string = "Approved date:";
  readonly searchParamICPrefix: string = "Include:";
  readonly emsDateFormat: string = "MM/DD/YYYY";
  eventValueAPCD: any;
  eventValueSD: any;
  eventValuePE: any;
  eventValueAD: any;


  constructor(
    private modalService: ModalService,
    private _fileUploadRecordService: FileUploadRecordService,
    private notifier: NotifierService,
    private service: ArchiveService,
    private _fuService: FielUploadService,
    private _fuEventService: FileUploadEventService,
    private _spinnerService: NgxSpinnerService,
    private _emsPackagesService: EmspackagesService,
    private adalSvc: MsAdalAngular6Service,
    private deliverableservice: DeliverableService,
    private peoplePickerService: PeoplePickerService,
    private archiveHomeService: ArchiveHomeService,
    public fb: FormBuilder,
  ) {
    this.advanced_form = this.fb.group({
      emsCheckboxFormList: this.fb.array([], Validators.required),
      'formsubmittername': [null],
      'formetmname': [null],
      'formapprovername': [null],
      'formclientName': [null]
    });
  }

  ngOnInit() {
    var self = this;
    this.displaySelectedFiles = false;
    this.as2FileObjects=[];

    //FileUploadStep 2:
    //Get the selected file type, Archive number, Created By, MIME types from working papers component
    //This method is used to trigger the file upload popup
    this._fuEventService.showTriggerDialog.subscribe(data => {
     // debugger;
      self.module = data.module;
      self.as2fileNameArray = [];
      self.archiveNumber = data.fuMetaData.archiveNumber;
      self.createdBy = '';
      self.fileTypeId = data.fuMetaData.fileTypeId;
      self.fileTypeDescription = data.fuMetaData.fileTypeDescription;
      self.acceptedMIMETypes = data.fuMetaData.acceptedMIMETypes;
      self.personnelNumber = data.fuMetaData.employeePersonnelNumber;
      if (data.module == "workingpaper") {
        self.currentArchiveStatus = data.fuMetaData.currentArchiveStatus;
        this.currentArchiveStatus=data.fuMetaData.currentArchiveStatus;
        console.log("Archive Status" + this.currentArchiveStatus);
      }
      this.loginuserId = self.personnelNumber;

      self.showTriggerDialog();
    });

    this.emsGridData = [];
    //this.getEmsData();
    this.EmsCheckboxid = false;
  }

  /* ngAfterViewInit() {
    this.paginationComp.callfromEMSPackages();
} */

  // EMS Grid
  getEmsData() {
     this.FileSelectionFlag = false;
      if(this.isBasicShow)
      {
        this.getEmsInfo();
        //this.clearAllSelectionCheckbox();
      }
      else
      {
        this.getEMSAdvancedInfo();
      }
  }


  get checkBoxArray() {
    return this.advanced_form.get('emsCheckboxFormList') as FormArray;
  }

  getEmsInfo() {
    this._spinnerService.show();
    this._emsPackagesService.simpleSelectJson.keyword=this.searchtextvalue;
    this._emsPackagesService.simpleSelectJson.sortBy=this.sortBy;
    this._emsPackagesService.simpleSelectJson.from=this.currentPageNumber;
    this._emsPackagesService.simpleSelectJson.pageSize=this.pageSize;
      this._emsPackagesService.GetEmsInfo(this._emsPackagesService.simpleSelectJson)
      .subscribe(
        data => {
            let results = data ? data : [];
           debugger;
            if (!this.appendArchiveToGrid) {
              this.emsGridData = [];
            }
            let selectAllCb = (<HTMLInputElement>document.getElementById('checkboxHeader'));
            let emsAssignedData:emsDataObject = new emsDataObject();
            Object.assign(emsAssignedData , results);
            if (emsAssignedData.Total != 0) {
              this.totalEmsDatas = emsAssignedData.Total;
              emsAssignedData.EMSPackagesFound.forEach(element => {
                if(element[0].IsSubmitted == "YES")
                {
                  element[0]["Tooltip"]='The EMS archive package is already submitted to '+element[0].SubmittedArchiveNumber;
                }
                else if((','+element[0].ETMUsersPersonnelNo.trim().toLowerCase()+',').search(','+this.userAlias.toLowerCase()+',') ==-1)
                {
                  element[0].IsReadOnly="YES";
                  element[0]["Tooltip"]='You are not listed as an engagement team member on this EMS Archive package.  Only Engagement Team members are authorized to upload this archive package.  Please contact one of the team members below for further assistance.';
                }
                if (selectAllCb != null) {
                  if (selectAllCb.checked && element[0].IsSubmitted == "NO" && element[0].IsReadOnly == "No") {
                    element[0]["IsSelected"] = true;
                  }
                  else if (!selectAllCb.checked && this.checkBoxArray.length > 0) {
                    this.checkBoxArray.controls.forEach((item: FormControl) => {
                      if (item.value == element[0]["EMSId"]) {
                        element[0]["IsSelected"] = true;
                        return;
                      }
                    });
                  }
                  else {
                    element[0]["IsSelected"] = false;
                  }
                }
                else {
                  if (this.checkBoxArray.length > 0) {
                    this.checkBoxArray.controls.forEach((item: FormControl) => {
                      if (item.value == element[0]["EMSId"]) {
                        element[0]["IsSelected"] = true;
                        return;
                      }
                    });
                  }
                  else {
                    element[0]["IsSelected"] = false;
                  }
                }
                this.emsGridData.push(element);
              });
              this.isLoadedResult = true;
              this.isDefaultResult = false;
              this.isNoResult = false;
              // if(this.currentPageNumber==1)
              // {
              //   this.paginationComp.callfromEMSPackages(this.totalEmsDatas);
              // }
            }
            else {
              this.isLoadedResult = false;
              this.isDefaultResult = false;
              this.isNoResult = true;
              this.emsGridData=[];
              //this.paginationComp.callfromEMSPackages(this.totalEmsDatas);
              this.totalEmsDatas = 0;
            }
            this._spinnerService.hide();
        }
      );


    }

    selectCheckBoxCollection(){
      debugger;
      let elements = document.getElementsByClassName('emsCheckboxClass');
      let selectAllCb = (<HTMLInputElement>document.getElementById('checkboxHeader'));
      if (selectAllCb != undefined && selectAllCb.checked) {
        for (let i = 0; i < elements.length; i++) {
          if ((<HTMLInputElement>elements[i]).type == 'checkbox' && !(<HTMLInputElement>elements[i]).disabled) {
            (<HTMLInputElement>elements[i]).checked = true;
            if(!this.checkBoxArray.controls.some(x => x.value == (<HTMLInputElement>elements[i]).value))
            {
            this.checkBoxArray.push(new FormControl((<HTMLInputElement>elements[i]).value));
            }
          }
        }
        this.EmsCheckboxid = true;
      }
      else if(this.checkBoxArray.length > 0)
      {
        for (let i = 0; i < elements.length; i++) {
          if ((<HTMLInputElement>elements[i]).type == 'checkbox' && !(<HTMLInputElement>elements[i]).disabled) {
            if(this.checkBoxArray.controls.some(x => x.value == (<HTMLInputElement>elements[i]).value))
            {
              (<HTMLInputElement>elements[i]).checked = true;
            }
          }
        }
        //selectAllCb.checked = document.querySelectorAll('input[class=emsCheckboxClass]:not(:disabled)').length == document.querySelectorAll('input[class=emsCheckboxClass]:checked').length ? true:false;
      }
    }

  sortOrderChanged(event) {
      this.sortBy = parseInt(event.target.value);
      this.resetPaginationValues();
      this.getEmsData();
      this.clearAllSelectionCheckbox();
    }

    resetPaginationValues(){
      this.appendArchiveToGrid = false;
      this.currentPageNumber=1;
      this.totalEmsDatas=0;
      this.displayingRecordsFrom=0;
      this.displayingRecordsTo=0;
    }

    onKeyup(event) {
      this.isDefaultResult = true;
      this.isLoadedResult = false;
      this.appendArchiveToGrid=false;
      this.currentPageNumber=1;
      this.isNoResult = false;
      this.emsGridData = [];
      this.totalEmsDatas = 0;
      this.FileSelectionFlag = false;
      this.searchtextvalue = event.target.value;
      this.getDefaultState();

      if (this.searchtextvalue.trim() == '' || this.searchtextvalue.length >=3 ) {
        this.isInputSearchResult = false;
        this.resetPaginationValues();
        this.getEmsData();
        // console.log("*****************************Start*******");
        // console.log("this.isDefaultResult:  " + this.isDefaultResult);
        // console.log("this.isLoadedResult: "+this.isLoadedResult);
        // console.log("this.totalMATROIs:  " +this.totalMATROIs);
        // console.log("Condition: " + !this.isDefaultResult && this.isLoadedResult && this.totalMATROIs==0);
        // console.log("*****************************End*******");

    }
    else {
      return false;
    }
  }
  EmsCheckboxSelectedRow(e) {
    //this.EmsCheckboxid = true;
    //this.SelectedROI=true;
    //this.FileSelectionFlag = true;
    debugger;
    //var array = this.emsGridData[0];
    //const emsCheckboxFormList: FormArray = this.myForm.get('emsCheckboxFormList') as FormArray;
    let elements = document.getElementsByClassName('emsCheckboxClass');
    let selectAllCb = (<HTMLInputElement>document.getElementById('checkboxHeader'));
    //let checker = (arr, target) => target.every(v => arr.includes(v));

    if (e.target.checked) {
      this.checkBoxArray.push(new FormControl(e.target.value));
      if (this.checkBoxArray.length > 0) {
        this.EmsCheckboxid = true;
      }
      else {
        this.EmsCheckboxid = false;
      }
      //selectAllCb.checked = document.querySelectorAll('input[class=emsCheckboxClass]:not(:disabled)').length == document.querySelectorAll('input[class=emsCheckboxClass]:checked').length ? true:false;

    } else {
      let i: number = 0;
      this.checkBoxArray.controls.forEach((item: FormControl) => {
        if (item.value == e.target.value) {
          this.checkBoxArray.removeAt(i);
          return;
        }
        i++;
      });
      if (this.checkBoxArray.length > 0) {
        this.EmsCheckboxid = true;
      }
      else {
        this.EmsCheckboxid = false;
      }
      //selectAllCb.checked = document.querySelectorAll('input[class=emsCheckboxClass]:not(:disabled)').length == document.querySelectorAll('input[class=emsCheckboxClass]:checked').length ? true:false;
    }
  }

  EmsCheckboxSelectAll(e: any) {
    debugger;
    this.checkBoxArray.clear();
    let elements = document.getElementsByClassName('emsCheckboxClass');
    if (e.target.checked) {
      for (let i = 0; i < elements.length; i++) {
        if ((<HTMLInputElement>elements[i]).type == 'checkbox' && !(<HTMLInputElement>elements[i]).disabled) {
          (<HTMLInputElement>elements[i]).checked = true;
          this.checkBoxArray.push(new FormControl((<HTMLInputElement>elements[i]).value));
        }
      }
      this.EmsCheckboxid = true;
    } else {
      for (let i = 0; i < elements.length; i++) {
        if ((<HTMLInputElement>elements[i]).type == 'checkbox') {
          (<HTMLInputElement>elements[i]).checked = false;
          if(this.checkBoxArray.controls.some(x => x.value == (<HTMLInputElement>elements[i]).value))
            {
              this.checkBoxArray.controls.splice(this.checkBoxArray.controls.findIndex(x => x.value == (<HTMLInputElement>elements[i]).value),1)
            }
        }
      }
      if(this.checkBoxArray.length == 0)
      {
      this.EmsCheckboxid = false;
      }
    }
  }

  clearAllSelectionCheckbox() {
    //debugger;
    let elements = document.getElementsByClassName('emsCheckboxClass');
    for (let i = 0; i < elements.length; i++) {
      if ((<HTMLInputElement>elements[i]).type == 'checkbox') {
        (<HTMLInputElement>elements[i]).checked = false;
      }
    }
    this.checkBoxArray.clear()
    this.EmsCheckboxid = false;
  }

  /* getengagementtypes() {
    this.service.GetEngagementType().subscribe(
     (data) => {
       this.engagements = data;
     },
     (err) => {
       console.log("error is ", err)
     }
   );
 } */

  //FileUploadStep 3:
  //Open the file dialog and manage the dialog heading based on file type
  //Display popup based on file type EMS, AS2 and Other
  showTriggerDialog() {

    this.fileName = "";
    //this.fileSize = "";
    this.fileSize = -1;
    this.sunits = "";

    if (this.fileTypeId == 2) {
      this.showPopUp = 1;
      this.isOtherClicked = false;
      this.isServerClicked = true;
    }
    else if(this.fileTypeDescription=='AS/2')
    {
    this.fileTypeId=13;
    this.showPopUp=4;
    this.isAS2InitialPopupShow = false;
    }
    else this.showPopUp = 2;
    this.enableBypassSecurityCheck = false;
    this.displayPopupHeaderText();
    this.modalService.openWithCustomWidth("uploadWorkingPapers", "595");
  }

  //FileUploadStep 4:
  //Manage the dialog heading based on file type
  displayPopupHeaderText() {
    if (this.fileTypeDescription.indexOf('AS/2') >= 0)
      this.popUpHeaderText = "Select the AS/2 file";
    if (this.fileTypeDescription.indexOf('EMS') >= 0)
      this.popUpHeaderText = "Select the EMS archive package location";
    if (this.fileTypeDescription.indexOf('Other') >= 0)
      this.popUpHeaderText = "Select the Other file";
    if (this.fileTypeDescription.indexOf('PCAOB') >= 0)
      this.popUpHeaderText = "Select the Final PCAOB Form AP";

  }

  //FileUploadStep 5:
  //This method sets the Source selected
  selectEMSArchiveSource(source: string) {
    this.eMSArchiveSource = source;
    if (source === "server") {
      this.isServerClicked = true;
      this.isOtherClicked = false;
    } else {
      this.isServerClicked = false;
      this.isOtherClicked = true;
    }
  }

  //FileUploadStep 6:
  //Once source is selected click on Continue button, takes to file upload popup
  continueClick() {
    debugger;
    console.log(this.fileTypeId);
    if (!this.isServerClicked && !this.isOtherClicked) {
      return false;
    }
    else if (this.eMSArchiveSource == "local") {
      this.showPopUp = 2;
      this.enableBypassSecurityCheck = true;
    }
    else if (this.fileTypeId == 2 && this.isServerClicked) {
      this.showPopUp = 3;
      this.popUpHeaderText = "EMS Archive Packages";
      this.modalService.openWithCustomWidth("uploadWorkingPapers", "1232");
      this.getEmsData();
      this.getMasterData();
    }
  }

  //FileUploadStep 6:
  //Close the popup and cancels the upload process
  closeModalDialog(Action) {
    this.eMSArchiveSource = "";
    if (this.fileTypeId == 2 && this.isServerClicked) {
    this.clearAllSelectionCheckbox();
    this.resetfilter();
    }
    this.isAS2InitialPopupShow = false;
    this.modalService.close(Action);
  }

  //FileUploadStep 7:
  //Clicking on 'Select' button, triggers the input type file browse
  //on selecting the file, updates values file name and file size and enables upload button
  browseFileDialogClick() {

    var self = this;

    var fileIndex = self._fuEventService.fileIndex++;
    self.fileId = 'fileId-' + fileIndex;

    var fileElem = document.createElement('input');
    fileElem.setAttribute("id", self.fileId);
    fileElem.setAttribute("type", "file");
    fileElem.setAttribute("accept", this.acceptedMIMETypes);
    document.getElementById("div_fileupload").appendChild(fileElem);

    // debugger;
    fileElem.onchange = function (e: any) {
      var file = e.target.files[0];

      if (file.name) {
          self.fileName = file.name;
          self.fileSize = file.size;
          self.disableUploadButton = false;
      }

    };

    fileElem.click();
  }



  //FileUploadStep 8:
  //Clicking on 'Upload' button, validates the file extension
  //Create a record in DB and returns archiveFileId and fileTransferId
  //Triggers file upload process
  uploadClick() {
    if (!this.fileName) return false;
    var self = this;
    let newRecord = {
      ArchiveFileId: 0,
      FileName: self.fileName,
      //FileSize: Math.round(parseFloat(self.fileSize)),
      FileSize: Math.round(parseFloat(self.fileSize.toString())),
      CreatedBy: '',
      BypassIntegrityCheck: self.enableBypassSecurityCheck,
      FileTypeId: self.fileTypeId,
      ArchiveNumber: self.archiveNumber
    };


    var fileExtension = newRecord.FileName.split(".").pop().toLowerCase();
    var specialFileExtensionArray = ["abk", "zip", "da3rc", "darc", "da4rc", "omnia1", "omnia2"];

    if(self.fileTypeDescription == "Other File" && fileExtension=="abk"){
      self.notifier.notify(
        "error",
        "EMS backup files contain library content and cannot be uploaded to Archive it Audit Archives."
      );
      self.cancelSelectedFile();
      return false;

    }
    else if (self.fileTypeDescription != "Other File" && self.acceptedMIMETypes.indexOf(fileExtension) == -1) {
      self._spinnerService.show();
      this.notifier.notify(
        "error",
        "This file doesn't support the selected file type. Please select a valid file like " +
        self.acceptedMIMETypes
      );
      self._spinnerService.hide();
      self.cancelSelectedFile();
      return;
    }

    if(self.currentArchiveStatus=='Resubmitted – Open' || self.currentArchiveStatus=='Resubmitted - Ready for Approval'){
      this.modalService.close('uploadWorkingPapers');
      this.ShowResubmissionReasonAlert = true;
      this.resubmissionNewRecord = newRecord
      this.resubmissionSelf = self
      this.archiveHomeService.GetResubmissionReasonsforArchive(self.archiveNumber).subscribe(data=>{
        debugger;
        if(data){
         if(data.length>0)
         {
          this.WPEditedInResubmit=data[1].actionTypeId==3?true:false;
          this.WPProvidedInResubmit=data[1].comments!=""?data[1].comments:"";
          this.WPEditedDate=data[1].rejectedDate;
        }
       }
      });
      //Commenting this code as we need to show reasons popup in resubmit-open case
     // this.modalService.openWithCustomWidth('SaveChanges-AdministrativeResubmission-Modal', '632');
      this.fileUploadForRecords(self, newRecord);
      // this.OnApproveOrRejection("3");
    }
    else {
      this.fileUploadForRecords(self, newRecord);
    }
    localStorage['ArefilesAddedinWP'] = 1;
  }

  ShowEditedReasonPop() {
    debugger;
    if (!this.fileName) return false;
    var self = this;
    let newRecord = {
      ArchiveFileId: 0,
      FileName: self.fileName,
      //FileSize: Math.round(parseFloat(self.fileSize)),
      FileSize: Math.round(parseFloat(self.fileSize.toString())),
      CreatedBy: '',
      BypassIntegrityCheck: self.enableBypassSecurityCheck,
      FileTypeId: self.fileTypeId,
      ArchiveNumber: self.archiveNumber
    };


    var fileExtension = newRecord.FileName.split(".").pop().toLowerCase();
    var specialFileExtensionArray = ["abk", "zip", "da3rc", "darc", "da4rc", "omnia1", "omnia2"];

    if(self.fileTypeDescription == "Other File" && fileExtension=="abk"){
      self.notifier.notify(
        "error",
        "EMS backup files contain library content and cannot be uploaded to Archive it Audit Archives."
      );
      self.cancelSelectedFile();
      return false;

    }
    else if (self.fileTypeDescription != "Other File" && self.acceptedMIMETypes.indexOf(fileExtension) == -1) {
      self._spinnerService.show();
      this.notifier.notify(
        "error",
        "This file doesn't support the selected file type. Please select a valid file like " +
        self.acceptedMIMETypes
      );
      self._spinnerService.hide();
      self.cancelSelectedFile();
      return;
    }
    this.fileUploadForRecords(self, newRecord);
    this.OnApproveOrRejection("3");
    this.modalService.close('SaveChanges-AdministrativeResubmission-Modal');
  }

  OnApproveOrRejection(ActionType) {
    this._spinnerService.show();
    var parameters =
    {
      "ArchiveNumber": this.archiveNumber,
      "ArchiveSectionId": "2",
      "ActionTypeId": "3",
      "Comments": "",
      "CreatedBy": ''
    }
    var myobjstr = JSON.stringify(parameters);
    this.archiveHomeService.OnApproveOrRejection(myobjstr)
      .subscribe(
        data => {
          console.log("Working Papers Edited Flag updated");
        }
      );
    this._spinnerService.hide();
  }

  SaveCreateDeliverableandStateReason() {
    //debugger;
    this.modalService.close('SaveChanges-AdministrativeResubmission-Modal');
    this.fileUploadForRecords(this.resubmissionSelf, this.resubmissionNewRecord);
    this._spinnerService.show();
    var parameters =
    {
      "ArchiveNumber": this.archiveNumber,
      "ArchiveSectionId": "2",
      "ActionTypeId": "3",
      "Comments": "",
      "CreatedBy": ''
    }
    var myobjstr = JSON.stringify(parameters);
    this.deliverableservice.ApproveRejectDeliverable(myobjstr)
      .subscribe(
        data => {
          console.log("successfully done");
        }
      );
    this._spinnerService.hide();
  }

  /*Added for reusing in case of Resubmission Flow*/
  fileUploadForRecords(self, newRecord) {
    self._spinnerService.show();
    self._fileUploadRecordService.CreateOrUpdateWorkingPaper(newRecord).subscribe(
      (data) => {

        let filenameindex=self._fuEventService.fileArray.findIndex(x => x.fileName == newRecord.FileName && x.metaData.ArchiveNumber == newRecord.ArchiveNumber && x.uploadStatus=="started");
        if (data.responseMessage != null && data.responseMessage != '') {
          this.notifier.notify("error", data.responseMessage);
          self.cancelSelectedFile();
          self._spinnerService.hide();
          return;
        }
        else if(filenameindex!=-1)
        {
          this.notifier.notify("error", "A file with same name already exists in this archive.");
          self.cancelSelectedFile();
          self._spinnerService.hide();
          return;
        }
        self.archiveFileId = data.archiveFileId;
        self.fileTransferId = data.fileTransferId;
        self.s3FileName = data.s3FileName;

        self.closeModalDialog("uploadWorkingPapers");
        self.triggerFileUploadProcess();
      },

      err => {
        self._spinnerService.hide();
      });
    /*Added for Resubmission Reason
    if(self.currentArchiveStatus=='Resubmitted – Open'){
      this.modalService.openWithCustomWidth("Reasons-Adminstrativeresubmission-modal", "900");
    }
    End of Added for Resubmission Reason*/

  }
  //Added for Resubmission Reason
  SaveWPSectionReasons() {
    this.modalService.close("SaveChanges-AdministrativeResubmission-Modal");
    //debugger;
    var self = this;
    var parameter =
    {
      "ArchiveNumber": this.archiveNumber,
      "Comment": this.ResubmissionReason,
      "CreatedBy": '',
      "CommentCategoryId": 9,
    }
    var myobjstr = JSON.stringify(parameter);
    this.AddEditSubstantiation(this.ResubmissionReason, myobjstr)
  }

  ShowStateReasonModal() {
    // if (this.formdata.invalid) {
    //   this.formdata.get('description').markAsTouched();
    // }
    // else {
      this.openStateReasonModal.emit();
      this.closeModalDialog('substantiation-popup-modal');
    // }
  }

  AddEditSubstantiation(reason, myobjstr) {
    this._spinnerService.show();
    this.deliverableservice.AddEditSubstantiation(myobjstr).subscribe(
      data => {
        if (data == true) {
          // this.DisplayReason = reason;
          this.notifier.notify(
            "success",
            "Successfully added"
          );
          // this.displayNoDeliverableClick = false;
          // this.GetSubstantiation(this.archiveNumber, this.commentCategoryId);
        }
        else {
          this.notifier.notify(
            "error",
            "Error occured"
          );
        }
        this._spinnerService.hide();
      },
      err => {
        console.log("error is ", err);
      }
    );
    this.modalService.close("Reasons-Adminstrativeresubmission-modal");
  }
  //End of Added for Resubmission Reason

  uploadEmsClick() {
    //if (!this.fileName) return false;
    //debugger;
    var self = this;

    self._spinnerService.show();
    let fileElem = document.createElement('input');
    fileElem.setAttribute("id", "FileId-0");
    fileElem.setAttribute("type", "file");
    fileElem.setAttribute('webkitdirectory', '');
    fileElem.setAttribute('directory', '');
    fileElem.setAttribute('multiple', '');
    document.getElementById("div_fileupload").appendChild(fileElem);

    let selectAllCb = (<HTMLInputElement>document.getElementById('checkboxHeader'));
    if(selectAllCb.checked)
    {
      this.checkBoxArray.clear();
      this._emsPackagesService.simpleSelectJson.keyword=this.searchtextvalue;
      this._emsPackagesService.simpleSelectJson.sortBy=this.sortBy;
      this._emsPackagesService.simpleSelectJson.from=1;
      this._emsPackagesService.simpleSelectJson.pageSize=this.totalEmsDatas;
      this._emsPackagesService.GetEmsInfo(this._emsPackagesService.simpleSelectJson)
      .subscribe(
        data => {
            let results = data ? data : [];
           debugger;
            let emsAssignedData:emsDataObject = new emsDataObject();
            Object.assign(emsAssignedData , results);
            if (emsAssignedData.Total != 0) {
              emsAssignedData.EMSPackagesFound.forEach(element => {
                debugger;
                this.checkBoxArray.push(new FormControl(element[0].EMSId));
              });
            }
            let newRecord = {
              ArchiveFileId: 0,
              EMSFileIds: this.checkBoxArray.value.toString(),
              CreatedBy: '',
              FileTypeId: self.fileTypeId,
              ArchiveNumber: self.archiveNumber
            };

            self._fileUploadRecordService.CreateOrUpdateEmsPackages(newRecord).subscribe(
              (data) => {
                console.log("Ems files successfully uploaded");
                self.emsFileInfo = data;
                self.closeModalDialog("uploadWorkingPapers");
                this._fuEventService.onLoadEmsWorkingPapers("FileUploadWpModal", self.archiveNumber);
                this.triggerMoveEMSFileProcess(self.emsFileInfo);
              },

              err => {
                self._spinnerService.hide();
              });
          });
    }
    else{
    let newRecord = {
      ArchiveFileId: 0,
      EMSFileIds: this.checkBoxArray.value.toString(),
      CreatedBy: '',
      FileTypeId: self.fileTypeId,
      ArchiveNumber: self.archiveNumber
    };

     self._fileUploadRecordService.CreateOrUpdateEmsPackages(newRecord).subscribe(
      (data) => {
        console.log("Ems files successfully uploaded");
        self.emsFileInfo = data;
        self.closeModalDialog("uploadWorkingPapers");
        this._fuEventService.onLoadEmsWorkingPapers("FileUploadWpModal", self.archiveNumber);
        this.triggerMoveEMSFileProcess(self.emsFileInfo);
      },

      err => {
        self._spinnerService.hide();
      });
    }

  }

  //FileUploadStep 9:
  //Pass meta data fielId, archiveFileId and fileTransferId to upload process
  //Triggers file upload process using FileUploadProcessService service
  //For each upload new instance of FileUploadProcessService is created
  triggerFileUploadProcess() {

    var self = this;

    self._fuEventService.fileArray.push({
      module: self.module,
      fileId: self.fileId,
      fileName: self.fileName,
      s3FileName: self.s3FileName,
      fileSize: self.fileSize,
      eTag: "",
      uploadId: "",
      uploadPercentage: "",
      uploadStatus: "add",
      uploadMessage: "",
      errorMessage: "",
      uploadRemaingTime: "",
      sunits: "",
      tunits: "",
      metaData: {}
    });

    var metaData = {
      ArchiveFileId: self.archiveFileId.toString(),
      FileTransferId: self.fileTransferId.toString(),
      ArchiveNumber: self.archiveNumber
    }

    var fileUploadProcessService = new FileUploadProcessService(
      self._fuService,
      self._fuEventService,
      self._spinnerService,
      self.fileId,
      self.s3FileName,
      metaData
    );

    if (self.showPopUp == 4) {
      let fileElement = self.as2FileObjects[self.as2SelectedFileIndex];
      fileUploadProcessService.uploadFile(fileElement, true, self.fileName);
    } else {
      let fileElement = document.getElementById(self.fileId);
      fileUploadProcessService.uploadFile(fileElement);
    }

  }

  triggerMoveEMSFileProcess(lstEMSFiles){

    var self=this;
    var batchType = "association";
    self._fileUploadRecordService.IsBatchJobTriggeredAsync(batchType, lstEMSFiles).subscribe(
      (data) => {
        console.log("Ems files movement job triggered successfully");
      },
      err => {
        self._spinnerService.hide();
    });
    
    /*var metaData = {
       ArchiveFileId: self.archiveFileId.toString(),
       FileTransferId: self.fileTransferId.toString(),
        ArchiveNumber: self.archiveNumber
    }

       var fileUploadProcessService = new FileUploadProcessService(
        this._fuService,
        this._fuEventService,
        this._spinnerService,
        this.fileId,
       self.s3FileName,
       metaData
      );

    fileUploadProcessService.copyEMSFiles(lstEMSFiles);*/
  }

  //FileUploadStep 10:
  //To remove the current selected file
  cancelSelectedFile() {

    var fileElement = document.getElementById(this.fileId);
    document.getElementById("div_fileupload").removeChild(fileElement);

    this.fileId = "";
    this.fileName = "";
    //this.fileSize = "";
    this.fileSize = -1;
  }
  get submittedBy(): any { return this.advanced_form.get('formsubmittername'); }

  removeparam(event, searchparam: any, index: any) {
    //debugger;
    if(searchparam.includes('Approved date')) {
      this.eventValueAD = '';
    } 
    if(searchparam.includes('Archive package creation')) {
      this.eventValueAPCD = '';
    } 
    if(searchparam.includes('Period end')) {
      this.eventValuePE = '';
    } 
    if(searchparam.includes('Submitted date')) {
      this.eventValueSD = '';
    } 
    this.emsGridData = [];
    this.totalEmsDatas = 0;
    this.FileSelectionFlag = false;
    this.isDefaultResult = false;
    this.paramindex = index;
    this.filterarray.splice(this.paramindex, 1);

    if (searchparam.includes(this.searchParamCNPrefix)) {
      this.clientName = '';
      this.bindclientname = '';
    }
    if (searchparam.includes(this.searchParamSNPrefix)) {
      this.submitterName = '';
      this.submitterNumber = 0;
      this.bindsubmittername = '';
    }

    if (searchparam.includes(this.searchParamETPrefix)) {
      this.EngagementTypeName = '';
      this.EngagementType = '';
    }

    if (searchparam.includes(this.searchParamETMPrefix)) {
      this.engagementteammember = '';
      this.etmNumber = 0;
      this.bindetmname = '';
    }

    if (searchparam.includes(this.searchParamANPrefix)) {
      this.approverName = '';
      this.approverNumber = 0;
      this.bindapprovername = '';
    }

    if (searchparam.includes(this.searchParamOREPrefix)) {
      this.OfficeEngagementTypeName = '';
      this.OfficeEngagementType = '';
    }

    if (searchparam.includes(this.searchParamAPCPrefix)) {
      this.archivePackageCreationDate = '';
      this.archivePackageCreationDateFrom = '';
      this.archivePackageCreationDateTo = '';
    }

    if (searchparam.includes(this.searchParamPEPrefix)) {
      this.periodEndDate = '';
      this.periodEndDateFrom = '';
      this.periodEndDateTo = '';
    }

    if (searchparam.includes(this.searchParamSDPrefix)) {
      this.submittedDate = '';
      this.submittedDateFrom = '';
      this.submittedDateTo = '';
    }

    if (searchparam.includes(this.searchParamADPrefix)) {
      this.approvedDate = '';
      this.approvedDateFrom = '';
      this.approvedDateTo = '';
    }

    this.checkBasicSearch();

    //if (this.filterarray.length > 0) {
    this.getEmsData();
    //}

    //result set
    this.getDefaultState();
  }

  getDefaultState() {
    this.isDefaultResult = this.searchtextvalue.length < 3 && this.filterarray.length == 0;
  }

  checkBasicSearch() {
    if (this.filterarray && this.filterarray.length > 0) {
      this.filterarray.forEach(textToFilter => {
        if (textToFilter.includes(this.searchParamCNPrefix)
          || textToFilter.includes(this.searchParamSNPrefix)
          || textToFilter.includes(this.searchParamETPrefix)
          || textToFilter.includes(this.searchParamETMPrefix)
          || textToFilter.includes(this.searchParamANPrefix)
          || textToFilter.includes(this.searchParamOREPrefix)
          || textToFilter.includes(this.searchParamAPCPrefix)
          || textToFilter.includes(this.searchParamSDPrefix)
          || textToFilter.includes(this.searchParamPEPrefix)
          || textToFilter.includes(this.searchParamADPrefix)
        ) {
          this.isBasicShow = false;
        }
        else {
          this.isBasicShow = true;
        }
      });
    }
    else {
      this.isBasicShow = true;
    }
  }

  getEMSAdvancedInfo() {
    if (this.filterarray.length > 0) {
      this._spinnerService.show();
      this._emsPackagesService.finalSelectedJson.isMasterData=false;
      this._emsPackagesService.finalSelectedJson.clientName = this.clientName != undefined ? this.clientName :'';
      this._emsPackagesService.finalSelectedJson.submitterName=this.submitterName!= undefined ? this.submitterName :'';
      this._emsPackagesService.finalSelectedJson.engagementType = this.EngagementTypeName!= undefined ? this.EngagementTypeName :'';
      this._emsPackagesService.finalSelectedJson.officeEngagement = this.OfficeEngagementTypeName!= undefined ? this.OfficeEngagementTypeName :'';
      this._emsPackagesService.finalSelectedJson.etmName=this.engagementteammember!=undefined?this.engagementteammember:'';
      this._emsPackagesService.finalSelectedJson.approverName=this.approverName!= undefined ? this.approverName :'';
      this._emsPackagesService.finalSelectedJson.packagecreationDateFrom=this.archivePackageCreationDateFrom!= undefined ? this.archivePackageCreationDateFrom :'';
      this._emsPackagesService.finalSelectedJson.packagecreationDateTo=this.archivePackageCreationDateTo!= undefined ? this.archivePackageCreationDateTo :'';
      this._emsPackagesService.finalSelectedJson.submittedDateFrom=this.submittedDateFrom!= undefined ? this.submittedDateFrom :'';
      this._emsPackagesService.finalSelectedJson.submittedDateTo=this.submittedDateTo!= undefined ? this.submittedDateTo :'';
      this._emsPackagesService.finalSelectedJson.periodDateFrom=this.periodEndDateFrom!= undefined ? this.periodEndDateFrom :'';
      this._emsPackagesService.finalSelectedJson.periodDateTo=this.periodEndDateTo!= undefined ? this.periodEndDateTo :'';
      this._emsPackagesService.finalSelectedJson.approverDateFrom=this.approvedDateFrom!= undefined ? this.approvedDateFrom :'';
      this._emsPackagesService.finalSelectedJson.approverDateTo=this.approvedDateTo!= undefined ? this.approvedDateTo :'';
      this._emsPackagesService.finalSelectedJson.sortBy=this.sortBy;
      this._emsPackagesService.finalSelectedJson.includeTeammember=this.isIncludeETM?(this.userAlias!=undefined?true:false):false;
      this._emsPackagesService.finalSelectedJson.isAutoComplete=false;
      this._emsPackagesService.finalSelectedJson.clientautotext=this.clientName!= undefined ? this.clientName :'';
      this._emsPackagesService.finalSelectedJson.from= (this.pageSize * (this.currentPageNumber - 1));
      this._emsPackagesService.getEmsAdvancedSearch(this._emsPackagesService.finalSelectedJson)
     .subscribe(
        data => {
          let advancedResults = data ? data : [];
          debugger;
          if (!this.appendArchiveToGrid) {
            this.emsGridData = [];
          }
          let selectAllCb = (<HTMLInputElement>document.getElementById('checkboxHeader'));
          let emsAssignedData:emsDataObject = new emsDataObject();
          Object.assign(emsAssignedData , advancedResults);
          if (emsAssignedData.Total != 0) {
            this.totalEmsDatas = emsAssignedData.Total;
            emsAssignedData.EMSPackagesFound.forEach(element => {
              debugger;
              if(element[0].IsSubmitted == "YES")
              {
                element[0]["Tooltip"]='The EMS archive package is already submitted to '+element[0].SubmittedArchiveNumber;
              }
              else if((','+element[0].ETMUsersPersonnelNo.trim().toLowerCase()+',').search(','+this.userAlias.toLowerCase()+',') ==-1)
              {
                element[0].IsReadOnly="YES";
                element[0]["Tooltip"]='You are not listed as an engagement team member on this EMS Archive package.  Only Engagement Team members are authorized to upload this archive package.  Please contact one of the team members below for further assistance.';
              }
              if (selectAllCb != null) {
                if (selectAllCb.checked && element[0].IsSubmitted == "NO" && element[0].IsReadOnly == "No") {
                  element[0]["IsSelected"] = true;
                }
                else if (!selectAllCb.checked && this.checkBoxArray.length > 0) {
                  this.checkBoxArray.controls.forEach((item: FormControl) => {
                    if (item.value == element[0]["EMSId"]) {
                      element[0]["IsSelected"] = true;
                      return;
                    }
                  });
                }
                else {
                  element[0]["IsSelected"] = false;
                }
              }
              else {
                if (this.checkBoxArray.length > 0) {
                  this.checkBoxArray.controls.forEach((item: FormControl) => {
                    if (item.value == element[0]["EMSId"]) {
                      element[0]["IsSelected"] = true;
                      return;
                    }
                  });
                }
                else {
                  element[0]["IsSelected"] = false;
                }
              }
              this.emsGridData.push(element);
            });
            this.isLoadedResult = true;
            this.isDefaultResult = false;
            this.isNoResult = false;
            // if(this.currentPageNumber==1)
            // {
            //   this.paginationComp.callfromEMSPackages(this.totalEmsDatas);
            // }
          }
          else {
            this.isLoadedResult = false;
            this.isDefaultResult = false;
            this.isNoResult = true;
            //this.paginationComp.callfromEMSPackages(this.totalEmsDatas);
            this.totalEmsDatas = 0;
          }
          this._spinnerService.hide();
        },
        error => {
        });
    }

  }

  toggle() {
    this.show = !this.show;
    this.packagecreationDtShow = false;
    this.submittedDtShow = false;
    this.periodEndDtShow = false;
    this.approvedDtShow = false;
  }

  resetfilter() {
    //debugger;
    // mat grid
    this.emsGridData = [];
    this.eventValueAD = '';
    this.eventValueAPCD = '';
    this.eventValuePE = '';
    this.eventValueSD = '';
    this.totalEmsDatas = 0;
    this.FileSelectionFlag = false;
    this.isDefaultResult = false;
    this.appendArchiveToGrid = false;
    this.resetPaginationValues();

    // search param
    this.searchtextvalue = '';
    this.filterarray = [];

    // dropdown clear
    //this.engagements = null;
    this.EngagementTypeName = '';
    this.EngagementType = '';this.EngagementType = null;this.EngagementType = undefined;

    //this.officeEngagements = null;
    this.OfficeEngagementTypeName = '';
    this.OfficeEngagementType = '';this.OfficeEngagementType = null;this.OfficeEngagementType = undefined;

    this.clientName = '';
    this.submitterName = '';
    this.submitterNumber = 0;
    this.engagementteammember = '';
    this.etmNumber = 0;
    this.approverName = '';
    this.approverNumber = 0;

    this.bindclientname = '';
    this.bindsubmittername = '';
    this.bindetmname = '';
    this.bindapprovername = '';

    this.archivePackageCreationDate = '';
    this.archivePackageCreationDateFrom = '';
    this.archivePackageCreationDateTo = '';

    this.submittedDate = '';
    this.submittedDateFrom = '';
    this.submittedDateTo = '';

    this.periodEndDate = '';
    this.periodEndDateFrom = '';
    this.periodEndDateTo = '';

    this.approvedDate = '';
    this.approvedDateFrom = '';
    this.approvedDateTo = '';

    // call default and isBasic
    this.getDefaultState();
    this.checkBasicSearch();
    this.getMasterData();
    this.getEmsData();
  }

  selectedEngagementType(event: any) {
    this.EngagementTypeId = event.target.value;
    this.EngagementTypeName = event.target.options[event.target.selectedIndex].text;
  }

  selectedOfficeResposibleEngagementType(event: any) {
    this.OfficeEngagementTypeId = event.target.value;
    this.OfficeEngagementTypeName = event.target.options[event.target.selectedIndex].text;
  }

  SaveArchivePackageCreationDate(event) {
    // debugger;
    if (event != undefined) {
      this.archivePackageCreationDate = "";
      if (event[0].fromdate != "" && event[1].todate != "") {
        this.archivePackageCreationDateFrom = this.getDateInMySQLFomat(event[0].fromdate);
        this.archivePackageCreationDateTo = this.getDateInMySQLFomat(event[1].todate);
        this.archivePackageCreationDate = event[0].fromdate + " — " + event[1].todate;
        console.log("archivePackageCreationDate:" + this.archivePackageCreationDate);
      }
    }
  }

  SavePeriodEndDate(event) {
    // debugger;
    if (event != undefined) {
      this.periodEndDate = "";
      if (event[0].fromdate != "" && event[1].todate != "") {
        this.periodEndDateFrom = this.getDateInMySQLFomat(event[0].fromdate);
        this.periodEndDateTo = this.getDateInMySQLFomat(event[1].todate);
        this.periodEndDate = event[0].fromdate + " — " + event[1].todate;
        console.log("periodEndDate:" + this.periodEndDate);
      }
    }
  }

  SaveApprovedDate(event) {
    // debugger;
    if (event != undefined) {
      this.approvedDate = "";
      if (event[0].fromdate != "" && event[1].todate != "") {
        this.approvedDateFrom = this.getDateInMySQLFomat(event[0].fromdate);
        this.approvedDateTo = this.getDateInMySQLFomat(event[1].todate);
        this.approvedDate = event[0].fromdate + " — " + event[1].todate;
        console.log("approvedDate:" + this.approvedDate);
      }
    }
  }

  SaveSubmittedDate(event) {
    // debugger;
    if (event != undefined) {
      this.submittedDate = "";
      if (event[0].fromdate != "" && event[1].todate != "") {
        this.submittedDateFrom = this.getDateInMySQLFomat(event[0].fromdate);
        this.submittedDateTo = this.getDateInMySQLFomat(event[1].todate);
        this.submittedDate = event[0].fromdate + " — " + event[1].todate;
        console.log("submittedDate:" + this.submittedDate);
      }
    }
  }

  getDateInMySQLFomat(date: string) {
    return date.split("/")[2] + "-" + date.split("/")[0] + "-" + date.split("/")[1];
  }

  DatePickerToggle(pickerEnum: number) {
    if (this.dtPickerEnum.ArchivePackageCreationDtEnum == pickerEnum)
      this.ArchivePackageCreationDtToggle();
    else if (this.dtPickerEnum.SubmittedDtEnum == pickerEnum)
      this.SubmittedDtToggle();
    else if (this.dtPickerEnum.PeriodEndDtEnum == pickerEnum)
      this.PeriodEndDtToggle();
    else if (this.dtPickerEnum.ApprovedDtEnum == pickerEnum)
      this.ApprovedDtToggle();
  }

  ArchivePackageCreationDtToggle() {
    this.packagecreationDtShow = !this.packagecreationDtShow;
    this.submittedDtShow = false;
    this.periodEndDtShow = false;
    this.approvedDtShow = false;
  }

  SubmittedDtToggle() {
    this.packagecreationDtShow = false;
    this.submittedDtShow = !this.submittedDtShow;
    this.periodEndDtShow = false;
    this.approvedDtShow = false;
  }

  PeriodEndDtToggle() {
    this.packagecreationDtShow = false;
    this.submittedDtShow = false;
    this.periodEndDtShow = !this.periodEndDtShow;
    this.approvedDtShow = false;
  }

  ApprovedDtToggle() {
    this.packagecreationDtShow = false;
    this.submittedDtShow = false;
    this.periodEndDtShow = false;
    this.approvedDtShow = !this.approvedDtShow;
  }
  DtPickerFormatAPCD(event)
  {
    this.eventValueAPCD = event;
  }

  DtPickerFormatSD(event)
  {
    this.eventValueSD = event;
  }

  DtPickerFormatPE(event)
  {
    this.eventValuePE = event;
  }
  DtPickerFormatAD(event)
  {
    this.eventValueAD = event;
  }

  searchBtnClicked(event) {
    //debugger;
    this.filterarray = [];
    this.totalEmsDatas = 0;
    this.emsGridData = [];
    this.searchtextvalue = '';
    this.isLoadedResult = false;

    //// debugger;
    if ((this.clientName || this.submitterName || this.EngagementTypeName
      || this.engagementteammember || this.approverName || this.OfficeEngagementTypeName
      || this.archivePackageCreationDate || this.submittedDate || this.periodEndDate
      || this.approvedDate || this.isIncludeETM) && this.filterarray) {
      //this._spinnerService.show();

      // client name
      if (this.clientName != '' && !this.filterarray.includes(this.clientName)) {
        this.filterList(true, this.clientName, true, 0);
      }

      // submitted name
      if (this.submitterName != '' && !this.filterarray.includes(this.submitterName)) {
        this.filterList(true, this.bindsubmittername, true, 1);
      }

      // engagement type
      if (this.EngagementTypeName != '' && !this.filterarray.includes(this.EngagementTypeName)) {
        this.filterList(true, this.EngagementTypeName, true, 2);
      }

      // engagement team member
      if (this.engagementteammember != '' && !this.filterarray.includes(this.engagementteammember)) {
        this.filterList(true, this.bindetmname, true, 3);
      }

      //approver name
      if (this.approverName != '' && !this.filterarray.includes(this.approverName)) {
        this.filterList(true, this.bindapprovername, true, 4);
      }

      //office engagement
      if (this.OfficeEngagementTypeName != '' && !this.filterarray.includes(this.OfficeEngagementTypeName)) {
        this.filterList(true, this.OfficeEngagementTypeName, true, 5);
      }

      // approve package creation date
      if (this.archivePackageCreationDate != '' && !this.filterarray.includes(this.archivePackageCreationDate)) {
        this.filterList(true, this.archivePackageCreationDate, true, 6);
      }

      // submitted date
      if (this.submittedDate != '' && !this.filterarray.includes(this.submittedDate)) {
        this.filterList(true, this.submittedDate, true, 7);
      }

      // period end date
      if (this.periodEndDate != '' && !this.filterarray.includes(this.periodEndDate)) {
        this.filterList(true, this.periodEndDate, true, 8);
      }

      // period end date
      if (this.approvedDate != '' && !this.filterarray.includes(this.approvedDate)) {
        this.filterList(true, this.approvedDate, true, 9);
      }

      this.toggle();
      this.resetPaginationValues();
      this.getEmsData();
      //this.SpinnerService.hide();
    }
    else {
      return false;
    }
  }

  filterList(isAddFilter: boolean, textToFilter: string, isCommitFilter: boolean = false, isFilterPrefix: number = 0) {

    if (isAddFilter) {
      if (isCommitFilter && this.filterarray) {
        if (textToFilter != undefined) {
          var filterPrefix = this.searchParamCNPrefix;
          var filterPrefixString = "";
          if (isFilterPrefix == 1) {
            filterPrefix = this.searchParamSNPrefix;
          }
          else if (isFilterPrefix == 2) {
            filterPrefix = this.searchParamETPrefix;
          }
          else if (isFilterPrefix == 3) {
            filterPrefix = this.searchParamETMPrefix;
          }
          else if (isFilterPrefix == 4) {
            filterPrefix = this.searchParamANPrefix;
          }
          else if (isFilterPrefix == 5) {
            filterPrefix = this.searchParamOREPrefix;
          }
          else if (isFilterPrefix == 6) {
            filterPrefix = this.searchParamAPCPrefix;
          }
          else if (isFilterPrefix == 7) {
            filterPrefix = this.searchParamSDPrefix;
          }
          else if (isFilterPrefix == 8) {
            filterPrefix = this.searchParamPEPrefix;
          }
          else if (isFilterPrefix == 9) {
            filterPrefix = this.searchParamADPrefix;
          }
          filterPrefixString = filterPrefix + textToFilter;
          this.deleteItemFromFilterArray(filterPrefix);
          this.filterarray.push(filterPrefixString);
          this.checkBasicSearch();
        }
      }
    }
  }

  deleteItemFromFilterArray(msg: string) {
    if (this.filterarray && this.filterarray.length > 0) {
      this.filterarray.forEach(textToFilter => {
        if (textToFilter.includes(msg)) {
          const index: number = this.filterarray.indexOf(textToFilter);
          if (index !== -1) {
            this.filterarray.splice(index, 1);
          }
        }
      });
    }
  }

  onInputChanged(searchString: string) {
    debugger;
    if (searchString.length >= 3) {
     this.submittedUsers = [];
       this.peoplePickerService.GetPeople(searchString).subscribe(
         (value) => {
          debugger;
           this.submittedUsers = value;
         },
         (err) => {
           console.log("error is ", err)
         }
       );
     }
     else if (searchString.length == 0) {
       this.submittedUsers = [];
       this.submitterName = "";
       this.submitterNumber=0;
       this.bindsubmittername="";
     }
     else {
       this.submittedUsers = [];
       this.submitterName = "";
       this.submitterNumber=0;
       this.bindsubmittername="";
     }
     this._spinnerService.hide();
   }

   onClientInputChanged(searchString: string) {
    //debugger;
    if (searchString.length >= 3) {
     this.clientdetails = [];
     this._emsPackagesService.finalSelectedJson.isMasterData=true;
     this._emsPackagesService.finalSelectedJson.isAutoComplete=true;
     this._emsPackagesService.finalSelectedJson.clientautotext=searchString;
     this._emsPackagesService.getMasterDataResults(this._emsPackagesService.finalSelectedJson).subscribe(
       data => {
           this.clientdetails = data.suggest.clientnamesuggest[0].options.map(x => x.text);;
         },
         (err) => {
           console.log("error is ", err)
         }
       );
     }
     else if (searchString.length == 0) {
       this.clientdetails = [];
       this.clientName = "";
     }
     else {
       this.clientdetails = [];
       this.clientName = "";
     }
     this._spinnerService.hide();
   }

  onETMInputChanged(searchString: string) {
   //debugger;
   if (searchString.length >= 3) {
    this.etmUsers = [];
      this.peoplePickerService.GetPeople(searchString).subscribe(
        (value) => {
          this.etmUsers = value;
        },
        (err) => {
          console.log("error is ", err)
        }
      );
    }
    else if (searchString.length == 0) {
      this.etmUsers = [];
      this.engagementteammember = "";
      this.etmNumber = 0;
      this.bindetmname ="";
    }
    else {
      this.etmUsers = [];
      this.engagementteammember = "";
      this.etmNumber = 0;
      this.bindetmname ="";
    }
    this._spinnerService.hide();
  }

  onApproveInputChanged(searchString: string) {
    if (searchString.length >= 3) {
      this.approveUsers = [];
      this.peoplePickerService.GetPeople(searchString).subscribe(
        (value) => {
          this.approveUsers = value;
        },
        (err) => {
          console.log("error is ", err)
        }
      );
    }
    else if (searchString.length == 0) {
      this.approveUsers = [];
      this.approverName = "";
      this.approverNumber = 0;
      this.bindapprovername ="";
    }
    else {
      this.approveUsers = [];
      this.approverName = "";
      this.approverNumber = 0;
      this.bindapprovername ="";
    }
    this._spinnerService.hide();
  }


  selectedSubmitterName(submitter, index) {
    this.submitterNumber = this.submittedUsers[index].personnelNumber;
    this.submitterName = this.submittedUsers[index].userAlias;
    this.bindsubmittername =this.submittedUsers[index].displayName;
  }
  selectedETMName(member, index) {
    this.etmNumber = this.etmUsers[index].personnelNumber;
    this.engagementteammember = this.etmUsers[index].userAlias;
    this.bindetmname =this.etmUsers[index].displayName;
  }

  selectedApproveName(member, index) {
    this.approverNumber = this.approveUsers[index].personnelNumber;
    this.approverName = this.approveUsers[index].userAlias;
    this.bindapprovername = this.approveUsers[index].displayName;
  }

  selectedClientName(client, index) {
    this.clientName = client.source.viewValue;
  }

  getMasterData() {
    this._emsPackagesService.finalSelectedJson.isMasterData = true;
    this._emsPackagesService.finalSelectedJson.isAutoComplete = false;
    this._emsPackagesService.getMasterDataResults(this._emsPackagesService.finalSelectedJson).subscribe(

      data => {
        this.engagements = data.aggregations.agg_nested_EngagementType.agg_EngagementType.buckets.map(x => x.key);
        this.officeEngagements = data.aggregations.agg_nested_OfficeResponsibleForEngagement.agg_OfficeResponsibleForEngagement.buckets.map(x => x.key);
      },
      error => {
      });
  }

  updateGridData(event) {
    this.appendArchiveToGrid = event.isLoadMoreClicked;
    this.currentPageNumber = event.pageNumber;
    this.getEmsData();
  }
  browseAs2Files() {
    var self = this;

   var fileIndex = self._fuEventService.fileIndex++;
    self.fileId = 'fileId-' + fileIndex;

    let fileElem = document.createElement('input');
    fileElem.setAttribute("id", self.fileId);
    fileElem.setAttribute("type", "file");
    fileElem.setAttribute("accept", ".abk");
    fileElem.setAttribute('webkitdirectory', '');
    fileElem.setAttribute('directory', '');
    fileElem.setAttribute('multiple', '');
    document.getElementById("div_fileupload").appendChild(fileElem);

    fileElem.onchange = function (evt: any) {
      self.as2fileNameArray=[];
      self.as2FileObjectNames=[];
      self.as2TotalFile = evt.target.files.length;
      if(self.as2TotalFile>0) self.isAS2InitialPopupShow = true;
      else self.isAS2InitialPopupShow = false;
      self.as2FileObjects = evt.target.files;
      for(var i = 0;i<evt.target.files.length; i++)
      {
        self.as2FileObjectNames.push(evt.target.files[i].name);
        console.log("as2FileObjectNames: " + self.as2FileObjectNames[i]);
      }
      self._spinnerService.show();
      zip.workerScriptsPath = "assets/zipjs/";

      for(var i=0;i<self.as2TotalFile;i++)
      {
        console.log("as2FileObjects: " + self.as2FileObjects[i].name);
      }

      for (var i = 0; i < evt.target.files.length; i++) {
        zip.createReader(
          new zip.BlobReader(evt.target.files[i]),
          function (zipReader) {
            zipReader.getEntries(readEntries);
          },
          function (error) {
            console.log(error);
          },
          evt.target.files[i].name
        );
      }

    };

    function readEntries(entries, parentFileName) {

      for (var i = 0; i < entries.length; i++) {
        if (entries[i].filename == "INDEX.XML") {

           let date_ob = entries[i].lastModDate;

// adjust 0 before single digit date
let date = ("0" + date_ob.getDate()).slice(-2);

// current month
let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);

// current year
let year = date_ob.getFullYear();

// current hours
let hours = ("0" + (date_ob.getHours() + 1)).slice(-2);

// current minutes
let minutes = ("0" + (date_ob.getMinutes() + 1)).slice(-2);

// current seconds
let seconds = date_ob.getSeconds();
var bd = month + "/" + date + "/" + year;
var bt=  hours + ":" + minutes + ":" + seconds;
// prints date & time in YYYY-MM-DD HH:MM:SS format
          entries[i].getData(new zip.TextWriter(), function (text, parentFileName) {
            // text contains the entry data as a String



            var ft1 = text.indexOf('<FolderTitle>');
            var ft2 = text.indexOf("</FolderTitle>");
            var ft = text.substring(ft1, ft2)
            if (ft) ft = ft.replace('<FolderTitle>', '');

            var le1 = text.indexOf('<PeriodEnd>');
            var le2 = text.indexOf("</PeriodEnd>");
            var le = text.substring(le1, le2)
            if (le) le = le.replace('<PeriodEnd>', '');
            le = le.split("/");
            if (le[0].length != 2) {
            if (le[0].length == 1) {
            le[0] = "0" + le[0];
            }
            }
            if (le[1].length != 2) {
              if (le[1].length == 1) {
              le[1] = "0" + le[1];
              }
              }

            le=le.join('/');
            self.as2fileNameArray.push({
              folderTitle: ft,
              lastEdit: le,
              folderTiTleDateofBackup:ft +" "+bd+ " "+bt,
              pfilename: parentFileName
            });

            if (self.as2fileNameArray.length == self.as2TotalFile) {
              self._spinnerService.hide();
            }


          }); // close the zip reader
        }

      }

    }

    fileElem.click();
  }

  onas2FileSelect(filename: string) {

    var self = this;
var index1=self.as2fileNameArray.findIndex(x=>x.pfilename==filename);
    var index = -1;
    for(var i = 0; i<self.as2FileObjectNames.length; i++)
    {
      if(self.as2FileObjectNames[i] == filename)
      {
        index = i;
        break;
      }
    }
    self.as2SelectedFileIndex = index;

    let asfo = this.as2FileObjects[index];
    if (asfo.name) {
      self.fileName = self.as2fileNameArray[index1].folderTitle + " " + self.as2fileNameArray[index1].lastEdit + ".abk";
      self.fileSize = asfo.size;
      self.disableUploadButton = false;
    }

  }


}

export enum emsGridDataSortBy {
  SortBy_EngagementFileName_Asc = 1,
  SortBy_EngagementFileName_Desc = 2,

  SortBy_ClientName_Asc = 3,
  SortBy_ClientName_Desc = 4,

  SortBy_ArchivePackageCreationDt_Asc = 5,
  SortBy_ArchivePackageCreationDt_Desc = 6,

  SortBy_OfficeResponsibleForEngagement_Asc = 7,
  SortBy_OfficeResponsibleForEngagement_Desc = 8,

  SortBy_PeriodEndDt_Asc = 9,
  SortBy_PeriodEndDt_Desc = 10,

  SortBy_EngagementType_Asc = 11,
  SortBy_EngagementType_Desc = 12,

  SortBy_SubmittedBy_Asc = 13,
  SortBy_SubmittedBy_Desc = 14,

  SortBy_SubmittedDate_Asc = 15,
  SortBy_SubmittedDate_Desc = 16,

  SortBy_ApprovedBy_Asc = 17,
  SortBy_ApprovedBy_Desc = 18,

  SortBy_ApprovedDate_Asc = 19,
  SortBy_ApprovedDate_Desc = 20,
}

export enum EMSDateRangePicker {
  ArchivePackageCreationDtEnum = 1,
  SubmittedDtEnum = 2,
  PeriodEndDtEnum = 3,
  ApprovedDtEnum = 4
}

export class emsDataObject {
  Total: number;
  EMSPackagesFound: any[] = [];
}
