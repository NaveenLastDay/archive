﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DataModels
{
    public class ArchiveAccessRequestCountForApprovalModel
    {
        public int ActionItemCount { get; set; }
        public string Due { get; set; }

    }
}
