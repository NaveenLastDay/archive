﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
   public class ArchiveRetentionDetails
    {
        public int ArchiveId { get; set; }
        public string ArchiveNumber { get; set; }
        public string RetentionReasons { get; set; }
        public int RetentionTime { get; set; }
        public string Comments { get; set; }
    }
}
