﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DataModels
{
    public class LinkTypeModel
    {
        public int LinkTypeId { get; set; }

        public string Description { get; set; }
    }

}
