﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DataModels
{
    public class FormStatusModel
    {
        public bool IsFormEnabled { get; set; }
        public string FormStatusDescription { get; set; }
        public DateTime? ADCDDate { get; set; }
        public DateTime? FormStatusDate { get; set; }
    }
}
