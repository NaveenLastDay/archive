﻿
using System.Data;


using Deloitte.AIFA.DBHelper;

namespace Deloitte.AIFA.DomainEntities
{
    /// <summary>
    ///Request model for User Dashboard Data
    /// </summary>

   
    public enum UserDashboardDataInputFields
    {
        [CreateField(Direction = ParameterDirection.Input, Type = DbType.String, Name = "UserAlias")]
        UserAlias
    }
    
}
