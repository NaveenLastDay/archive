import { Component, OnInit, OnDestroy } from '@angular/core';
import { MatTable, MatSlideToggleChange } from '@angular/material';
import { HoldsService } from '../../../../services/holds-admin.service';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { Router, NavigationEnd, ActivatedRoute } from '@angular/router';
import { NotifierService, NotifierModule, NotifierOptions } from "angular-notifier";
import { ModalService } from '../../../shared/modal';
import { bool } from 'aws-sdk/clients/signer';
import { SharedService } from '../../../../services/shared.service';
import { formatDate } from '@angular/common';



@Component({
  selector: 'app-hold-details',
  templateUrl: './hold-details.component.html',
  styleUrls: ['./hold-details.component.css']
})
export class HoldDetailsComponent implements OnInit,OnDestroy {

  /*Header Details*/
  HoldName:string;
  ClientName:string;
  BusinessName:string;
  effStartDate:Date;
  effEndDate:Date;
  IsActive:string;
  Clientid:string;
  archivesCount:number;

  holdNumber:string;
  BuisnessId:number;
  ClientId:string;
  archiveHoldDetails:any[];
  archiveHoldDetailsList:any[];
  deleteItem:string;
  data: any;
  dataSource:any;
  
  currentUrl: string;
  hoverIndex: number = -1;
  totalHoldsAssigned: any = 0;
  holdCreationDate: any;
  holdStatus:any;
  holdName: string;
  holdId:number;
  dataSourceHold: any[];
  vBusinessId:number;
  sBusinessId:string;
  createdBy:string;
  createdDate:Date;
  HoldHistoryDetails:any[];
  GetHoldNumberFromSearchScreen:string;

  /*sorting */
  columnByEnum: any = HoldsDetailsColumnBy;
  sortColumnDialog: number = -1;
  sortColumn : string ='';
  sortascdesc: number=0;
  sortBy: number = 0;
  /*sorting*/

  /*Export to Excel */
  holdsResultGridColumns: any =HoldsResultGridColumns;
  holdsHistoryGridColumns: any =HoldsHistoryGridColumns;
  readonly emptyStringInReport : string = " ";
  columnFilters: any[] =
  [
    {
      "displayName": "ClientName",
      "value": this.holdsResultGridColumns.ClientName,
      "checked": true
    },
    {
      "displayName": "ArchiveName",
      "value": this.holdsResultGridColumns.ArchiveName,
      "checked": true
    },
    {
      "displayName": "Archive#",
      "value": this.holdsResultGridColumns.ArchiveNumber,
      "checked": true
    },
    {
      "displayName": "Business",
      "value": this.holdsResultGridColumns.Business,
      "checked": true
    },

    {
      "displayName": "PeriodEndDate",
      "value": this.holdsResultGridColumns.PeriodEndDate,
      "checked": true
    }
  ]
  /*Export to Excel */
  columnHistoryFilters: any[] =
  [
    {
      "displayName": "Archive#",
      "value": this.holdsHistoryGridColumns.ArchiveNumber,
      "checked": true
    },
    {
      "displayName": "Status",
      "value": this.holdsHistoryGridColumns.Status,
      "checked": true
    },

    {
      "displayName": "CreatedBy",
      "value": this.holdsHistoryGridColumns.CreatedBy,
      "checked": true
    },
    {
      "displayName": "CreatedDate",
      "value": this.holdsHistoryGridColumns.CreatedDate,
      "checked": true
    }
  ]
  
  constructor(private router: Router,private holdService: HoldsService, 
    private adalSvc: MsAdalAngular6Service,private notifier: NotifierService,
    private activatedRoute: ActivatedRoute,private modalService: ModalService,private sharedService: SharedService
    ) { }

  ngOnInit() {
    debugger;
    let element = document.getElementById("applicationFooter_ID");
    //element.classList.add("application-footer-b-0"); 
    this.GetHoldNumberFromSearchScreen=localStorage.getItem('HoldNumberForHistory');
    var retriveHoldObject = localStorage.getItem('holddetailsObject');
    if(localStorage.getItem('holddetailsObject')!='' && localStorage.getItem('holddetailsObject')!=undefined && localStorage.getItem('holddetailsObject')!=null)
    {
      debugger;
      console.log('',JSON.parse(retriveHoldObject))
      var parshedHoldObject =JSON.parse(retriveHoldObject)
      this.holdNumber =parshedHoldObject.holdName;
      this.holdId=parshedHoldObject.holdId;
      this.ClientName=parshedHoldObject.clientName;
      this.BusinessName=parshedHoldObject.business;
      this.effStartDate=parshedHoldObject.effectiveStartDate;
      this.effEndDate=parshedHoldObject.effectiveEndDate;
      this.IsActive=parshedHoldObject.status;
      this.archivesCount=parshedHoldObject.archivesCount;
      this.createdBy=parshedHoldObject.createdBy;
      this.createdDate=parshedHoldObject.createdDate;
      this.Clientid=parshedHoldObject.clientID ;
      this.vBusinessId= Number(parshedHoldObject.businessID) ;
      this.sBusinessId=parshedHoldObject.businessID;

    }
    

    if(localStorage.getItem('HoldFromArchiveDetails')!=undefined && localStorage.getItem('HoldFromArchiveDetails')!='' &&
    localStorage.getItem('HoldFromArchiveDetails')!=null)
    {
      var getobject=localStorage.getItem('HoldFromArchiveDetails');
      var GetParsedObject=JSON.parse(getobject);
      this.holdNumber =GetParsedObject[0].holdNumber;
      this.holdId=GetParsedObject[0].holdId;
      this.Clientid=GetParsedObject[0].clientId ;
      this.vBusinessId= Number(GetParsedObject[0].businessId);
      this.ClientName=GetParsedObject[0].clientName;
      this.BusinessName=GetParsedObject[0].business;
      this.effStartDate=GetParsedObject[0].effectiveStartDate;
      this.effEndDate=GetParsedObject[0].effectiveEndDate;
      this.IsActive=GetParsedObject[0].holdStatus==1?"Active":"Cancelled";
      this.archivesCount=GetParsedObject[0].count;
      this.createdBy='TestUser';
      this.createdDate=GetParsedObject[0].holdCreationDate;
    }
    this.GetHoldsAssociatedtoArchives(this.holdNumber,this.vBusinessId,this.Clientid,this.sortColumn,this.sortascdesc);   
    
    localStorage.setItem('HoldFromArchiveDetails','');
  }
  ngOnDestroy()
  {
    let element = document.getElementById("applicationFooter_ID");
    element.classList.remove("application-footer-b-0"); 
  }

openRemoveHold(modalType: string,ArchiveNumber:string) {
  this.deleteItem=ArchiveNumber;
  this.modalService.openWithCustomWidth(modalType, "480");
}

closeModalDialog(Action) {
  this.modalService.close(Action);
}
showArchiveDetails(archiveNumber : string, i : number){}

OpenHoldsHistorydetails()
{
  //Get the Archives details associated with Hold
  this.holdService.GetHoldDetailsHistoryForHold(this.holdId,this.GetHoldNumberFromSearchScreen,0).subscribe(
    data => {
      if(data)
      {
        this.HoldHistoryDetails = data.result;
        this.HoldHistoryDetails.push({archiveId: 0,archiveNumber:'-',createdBy: this.createdBy,createdDate:this.createdDate,holdId: this.holdId,holdNumber: this.GetHoldNumberFromSearchScreen,status: "Hold Created"});
        console.log(data.result);
      }
    });
  
  this.modalService.openWithCustomWidth("Holds_History_Modal", "600");    
}

GetHoldsAssociatedtoArchives(HoldNuber:string,pBusinessId:number,ClientId:string,FilterText:string,SortBy:number) {

 //this.SpinnerService.show();
    this.holdService.GetArchivesAssociatedtoHolds(HoldNuber,pBusinessId,ClientId,FilterText,SortBy).subscribe(
      data => {
        
        if(data!=undefined && data.length>0){
          if (data[0].lstholdsDetails.length > 0) {
            this.totalHoldsAssigned = data[0].lstholdsDetails.length;
            this.archiveHoldDetailsList = data[0].lstholdsDetails;
          }
        }
        else {
          if(this.IsActive=='Active')
          this.NaavigateToApplyHold(this.holdNumber,this.ClientName,this.BusinessName,this.effStartDate,this.effEndDate,this.IsActive,this.archivesCount,this.ClientId,this.sBusinessId);
        }
        //this.SpinnerService.hide();
      },
          err => {
           // this.SpinnerService.hide();
            console.log("failed to load archives");
            console.log(err);
          });   
  }

  mouseOver(event: any, index: number) {
    this.hoverIndex = index;
    //event.stopPropagation();
  }

  mouseOut(event: any) {
    let name: string = '';
    let present: number = -1;

    name = event.toElement ? event.toElement.getAttribute('name') : '';
    present = name ? name.search("AccessArchiveTop") : -1;

    if (event.toElement && present == -1 && (event.toElement["tagName"] != 'td' || event.toElement.className == 'trArchiveHoldsGridHeadFont')) {
      this.hoverIndex = -1;
    }
  }

  NaavigateToApplyHold(holdName:string,clientName:string,business:string,effectiveStartDate:Date,effectiveEndDate:Date,status:string,archivesCount:number,clientID:string,businessID:string){    
    var holdObject ={holdName:holdName, clientName:clientName,business:business,effectiveStartDate:effectiveStartDate,effectiveEndDate:effectiveEndDate,status:status,archivesCount:archivesCount,clientID:clientID,businessID:businessID};
    localStorage.setItem('holdObject', JSON.stringify(holdObject));
    this.router.navigate(["/admin/adminsidenavbar/holds/holdsearch/applyHold"]); 
  }

  Editholds(){
    this.router.navigate(["admin/adminsidenavbar/holds"]);
  }

  Returntoholds(){
    this.router.navigate(["admin/adminsidenavbar/holds"]);
  }
  GoToApplyHoldScreen(){
    this.NaavigateToApplyHold(this.holdNumber,this.ClientName,this.BusinessName,this.effStartDate,this.effEndDate,this.IsActive,this.archivesCount,this.ClientId,this.sBusinessId);
  }

  RedirecttoApplyholds(){
    this.router.navigate(["admin/adminsidenavbar/holds/holdsearch"]);
  }
  
  NavigateToArchiveDetailsPage(clientName:string,archiveName:string,archiveNumber:string,businessName:string,periodEnd:Date)
  {
  var ArchiveDetailsJson={clientName:clientName,archiveName:archiveName,archiveNumber:archiveNumber,businessName:businessName,periodEnd:periodEnd};
  localStorage.setItem('ArchiveDetailsInfo',JSON.stringify(ArchiveDetailsJson));
  this.router.navigate(["/admin/adminsidenavbar/holds/holdsearch/archivedetails"], { queryParams: { archiveNumber : archiveNumber } });
  }


  NavigateToCreateHoldPage()
  {
    console.log('Navigating to Create Hold page');
    localStorage.setItem('HoldNumber',this.holdNumber);
    this.router.navigate(["/admin/adminsidenavbar/holds/holdsearch/"+ this.holdNumber +"/EditHold"]); 
  }

  deleteFile(archivenumber:string) 
  {
    var self = this;
   // self.SpinnerService.show();
    self.holdService.RemoveArchivesFromHold(this.holdId,archivenumber).subscribe(
      res => {
        console.log("apidatares:"+res);
        if (res.result == 1) {
          self.notifier.notify(
            "success",
            archivenumber+" successfully removed"
          );
          this.archivesCount=this.archivesCount-1;
          
          this.archiveHoldDetailsList = this.archiveHoldDetailsList.filter(item => item.archiveNumber !== archivenumber);
          this.totalHoldsAssigned=this.archiveHoldDetailsList.length;
          self.closeModalDialog('remove-hold');
       }
        //self.SpinnerService.hide();
      },
      err => {
       /// self.SpinnerService.hide();
        self.closeModalDialog('remove-hold');
        self.notifier.notify(
          "error",
          this.holdNumber+ " deletion failed"
        );
      }
    );
  //   setTimeout(() => {
  //   self.GetHoldsAssociatedtoArchives(this.holdNumber,this.vBusinessId,this.Clientid,this.sortColumn,this.sortascdesc);  
  // }, 200);
  }
  memberSortDialog(event) {
    if (this.sortColumnDialog == event) this.sortColumnDialog = -1;
    else
    this.sortColumnDialog = event;
    console.log("memberSortDialog",this.sortColumnDialog);
  }
  sortOrderChanged(event) {
    console.log("sortOrderChanged"+true);
    this.sortBy = event;
    if(this.sortBy==1 || this.sortBy==3 || this.sortBy==5)
    {
      this.sortascdesc=1;
    }
    else if(this.sortBy==2 || this.sortBy==4 || this.sortBy==6)
    {
      this.sortascdesc=0;
    }
    if(this.sortColumnDialog==1)
    {
      this.sortColumn='ClientName';
    }
    else if(this.sortColumnDialog==2){
      this.sortColumn='ArchiveName';
    }
    else if(this.sortColumnDialog==3)
    {
      this.sortColumn='ArchiveNumber';
    }
    else if(this.sortColumnDialog==4){
      this.sortColumn='Business';
    }
    else if(this.sortColumnDialog==5)
    {
      this.sortColumn='PeriodEndDate';
    }
    
    this.getHoldsDetailsforSort();
  }
  getHoldsDetailsforSort(){
    //this.SpinnerService.show();
    this.holdService.GetArchivesAssociatedtoHolds(this.holdNumber,this.vBusinessId,this.Clientid,this.sortColumn,this.sortascdesc).subscribe(
      data => {
        if(data!=undefined && data.length>0){
          if (data[0].lstholdsDetails.length > 0) {
            this.totalHoldsAssigned = data[0].lstholdsDetails.length;
            this.archiveHoldDetailsList = data[0].lstholdsDetails;
          }
        }
       // this.SpinnerService.hide();
      },
          err => {
           // this.SpinnerService.hide();
            console.log("failed to load archives");
            console.log(err);
          });  

  }
  memberSortDialogASCDESC(event){

    var clickedColumn:number=event;
      /*For HoldName*/
      if(clickedColumn==3 && this.sortBy!=7){
      this.sortBy=7;
       this.sortColumn="ArchiveNumber";
       this.sortascdesc=1;
     }
     else if(clickedColumn==3 && this.sortBy==7){
      this.sortBy=0;
      this.sortColumn="ArchiveNumber";
      this.sortascdesc=0;
     }
     /*For HoldName*/
     /*for EffectiveStartDate */
     else if(clickedColumn==5 && this.sortBy!=8){
      this.sortBy=8;
       this.sortColumn="PeriodEndDate";
       this.sortascdesc=1;
     }
     else if(clickedColumn==5 && this.sortBy==8){
      this.sortBy=0;
      this.sortColumn="PeriodEndDate";
      this.sortascdesc=0;
     }
     /*FoR Effective Start Date */
     this.getHoldsDetailsforSort();
  }
  generateReportClicked(data1){
    //this.SpinnerService.show();
    let archiveForReport: any[] = [];
    let filterdColumns = (data1.filter(x => x.checked));
    this.holdService.GetArchivesAssociatedtoHolds(this.holdNumber,this.vBusinessId,this.Clientid,this.sortColumn,this.sortascdesc).subscribe(
     
      data => {
        if (data[0].lstholdsDetails.length > 0) {
          data[0].lstholdsDetails.forEach(element => {
            let archive = {};
            filterdColumns.forEach(column => {

              if (column["value"] == this.holdsResultGridColumns.ClientName) { //Archive#
                archive[this.holdsResultGridColumns[this.holdsResultGridColumns.ClientName]] = element.clientName || this.emptyStringInReport;
              }
              if (column["value"] == this.holdsResultGridColumns.ArchiveName) { //Archive#
                archive[this.holdsResultGridColumns[this.holdsResultGridColumns.ArchiveName]] = element.archiveName || this.emptyStringInReport;
              }
              if (column["value"] == this.holdsResultGridColumns.ArchiveNumber) { //Archive#
                archive[this.holdsResultGridColumns[this.holdsResultGridColumns.ArchiveNumber]] = element.archiveNumber || this.emptyStringInReport;
              }
              if (column["value"] == this.holdsResultGridColumns.Business) { //Archive#
                archive[this.holdsResultGridColumns[this.holdsResultGridColumns.Business]] = element.businessName || this.emptyStringInReport;
              }
              if (column["value"] == this.holdsResultGridColumns.PeriodEndDate) { //Archive#
                archive[this.holdsResultGridColumns[this.holdsResultGridColumns.PeriodEndDate]] = element.periodEndDate || this.emptyStringInReport;
              }
              
            });
            archiveForReport.push(archive);
          });
          if (archiveForReport && archiveForReport.length) {
            this.sharedService.generateExcel("Holdsfor"+this.HoldName, "Holds", filterdColumns.map(x => x.displayName), archiveForReport);
          }
        }
      });
    }


    generateHistoryReportClicked(data1){
      //this.SpinnerService.show();
      let archiveForReport: any[] = [];
      let filterdColumns = (data1.filter(x => x.checked));
      this.holdService.GetHoldDetailsHistoryForHold(this.holdId,this.GetHoldNumberFromSearchScreen,0).subscribe(
       data => {
          if (data.result.length > 0 || data.result.length == 0) {
            data.result.push({archiveId: 0,archiveNumber:'-',createdBy: this.createdBy,createdDate:this.createdDate,holdId: this.holdId,holdNumber: this.GetHoldNumberFromSearchScreen,status: "Hold Created"});
            data.result.forEach(element => {
              let archive = {};
              filterdColumns.forEach(column => {
                
                if (column["value"] == this.holdsHistoryGridColumns.ArchiveNumber) { //Archive#
                  archive[this.holdsHistoryGridColumns[this.holdsHistoryGridColumns.ArchiveNumber]] = element.archiveNumber || this.emptyStringInReport;
                }
                if (column["value"] == this.holdsHistoryGridColumns.Status) { //Archive#
                  archive[this.holdsHistoryGridColumns[this.holdsHistoryGridColumns.Status]] = element.status || this.emptyStringInReport;
                }
                if (column["value"] == this.holdsHistoryGridColumns.CreatedBy) { //Archive#
                  archive[this.holdsHistoryGridColumns[this.holdsHistoryGridColumns.CreatedBy]] = element.createdBy || this.emptyStringInReport;
                }
                if (column["value"] == this.holdsHistoryGridColumns.CreatedDate) { //Archive#
                  archive[this.holdsHistoryGridColumns[this.holdsHistoryGridColumns.CreatedDate]] = formatDate(element.createdDate,'short','en-US','UTC -6')  || this.emptyStringInReport;
                }
              });
                archiveForReport.push(archive);
            });
            if (archiveForReport && archiveForReport.length) {
              this.sharedService.generateExcel("Holdsfor"+this.HoldName, "Holds", filterdColumns.map(x => x.displayName), archiveForReport);
            }
          }
        });
      }

}

export enum HoldsDetailsColumnBy {
  ColumnBy_Default = -1,
  ColumnBy_ClientName = 1,
  ColumnBy_ArchiveName = 2,
  ColumnBy_ArchiveNumber = 3,
  ColumnBy_Business = 4,
  ColumnBy_PeriodEndDate = 5,
}

export enum HoldsResultGridColumns
{
ClientName = 1,
ArchiveName = 2,
ArchiveNumber = 3,
Business = 4,
PeriodEndDate= 5,
}
export enum HoldsHistoryGridColumns
{
  ArchiveNumber=1,
  Status=2,
  CreatedBy=3,
  CreatedDate=4
}