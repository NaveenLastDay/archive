import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeleteArchiveComponent } from './delete-archive.component';

describe('DeleteArchiveComponent', () => {
  let component: DeleteArchiveComponent;
  let fixture: ComponentFixture<DeleteArchiveComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeleteArchiveComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeleteArchiveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
