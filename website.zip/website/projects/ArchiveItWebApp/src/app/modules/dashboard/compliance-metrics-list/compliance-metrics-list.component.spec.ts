import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ComplianceMetricsListComponent } from './compliance-metrics-list.component';

describe('ComplianceMetricsListComponent', () => {
  let component: ComplianceMetricsListComponent;
  let fixture: ComponentFixture<ComplianceMetricsListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ComplianceMetricsListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ComplianceMetricsListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
