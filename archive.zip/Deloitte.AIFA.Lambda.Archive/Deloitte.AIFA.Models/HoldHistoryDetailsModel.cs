﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.Models
{
   public class HoldHistoryDetailsModel
    {
        public int HoldId { get; set; }
        public string HoldNumber { get; set; }
        public int ArchiveId { get; set; }
        public string ArchiveNumber { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string Status { get; set; }
    }
}
