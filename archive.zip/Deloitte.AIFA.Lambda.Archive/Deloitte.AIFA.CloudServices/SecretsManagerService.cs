﻿using Amazon;
using Amazon.Lambda.Core;
using Amazon.SecretsManager;
using Amazon.SecretsManager.Model;
using Deloitte.AIFA.Common;
using Deloitte.AIFA.ICloudServices;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.IO;

namespace Deloitte.AIFA.CloudServices
{
    public class SecretsManagerService : IConfigManager
    {
        #region Properties
        IConfiguration _configManager;
        IMemoryCache _cache;
        string decodedBinarySecret = "";
        private readonly AmazonSecretsManagerClient managerClient;
        #endregion Properties

        #region Constructor
        public SecretsManagerService(IConfiguration configuration, IMemoryCache cache)
        {
            _cache = cache;
            this._configManager = configuration;
            // InitializeDBConnection();
            try
            {
                string regionkey = _configManager["region-key"];
                //configManager = new ConfigurationManager();
                var secretsManagerConfig = new AmazonSecretsManagerConfig
                {

                    RegionEndpoint = RegionEndpoint.GetBySystemName(
                        Environment.GetEnvironmentVariable(regionkey))
                };
                managerClient = new AmazonSecretsManagerClient(secretsManagerConfig);

                _cache.Set(Constants.DBConnectionstring, GetDBConString());
                _cache.Set(Constants.DBConnectionstringReader, GetDBConStringReader());

            }
            catch (Exception ex)
            {
                throw ex;
                //Console.WriteLine("Exception in Secretmanager ctor:" + ex.InnerException.ToString() + ex.Message + ex.StackTrace);
            }

        }

        #endregion Constructor

        private void InitializeDBConnection()
        {
            var dbConnectionString = _cache.Get<string>(Constants.DBConnectionstring);
            if (string.IsNullOrEmpty(dbConnectionString))
            {
                var DBConnectionString = "Server=aifa-dasmysqlcluster-dev.cluster-cspjkoibmxoh.us-east-1.rds.amazonaws.com;Port=3306;database = AIFA; User Id = dassql1_dcd_user;Password = IggTb860mECTghZ7gySQ;sslmode=none;convert zero datetime=True";
                var DBConnectionStringReader = "Server=aifa-dasmysqlcluster-dev.cluster-ro-cspjkoibmxoh.us-east-1.rds.amazonaws.com;Port=3306;database = AIFA; User Id = dassql1_dcd_user;Password = IggTb860mECTghZ7gySQ;sslmode=none;convert zero datetime=True";
                //var DBConnectionString = GetConfigValueByKey(Constants.DBConnectionstring);
                _cache.Set(Constants.DBConnectionstring, DBConnectionString);
               _cache.Set(Constants.DBConnectionstringReader, DBConnectionStringReader);
            }
        }

        public string GetDBConString()
        {
            return GetConfig(_configManager["secret-key"]);

        }
        public string GetDBConStringReader()
        {
            return GetConfigReader(_configManager["secret-key"]);

        }

        public string GetConfigReader(string secretName)
        {
            string connString = string.Empty;
            string dbName = _configManager["database-name"];
            var request = new GetSecretValueRequest
            {
                SecretId = Environment.GetEnvironmentVariable(secretName)
            };

            GetSecretValueResponse response = null;

            try
            {
                response = managerClient.GetSecretValueAsync(request).GetAwaiter().GetResult();
            }
            catch (ResourceNotFoundException)
            {
                Console.WriteLine("The requested secret " + secretName + " was not found");
            }
            catch (InvalidRequestException e)
            {
                Console.WriteLine("The request was invalid due to: " + e.Message);
            }
            catch (InvalidParameterException e)
            {
                Console.WriteLine("The request had invalid params: " + e.Message);
            }

            //response = ""
            if (response != null)
            {
                var secretVarialbles = JsonConvert.DeserializeObject<SecretManager>(response.SecretString);
                connString = $"Server={secretVarialbles.readerhost};Port={secretVarialbles.port};database={dbName};User Id={secretVarialbles.username};Password={secretVarialbles.password};convert zero datetime=True";

            }

            return connString;
        }
        public string GetConfig(string secretName)
        {
            string connString = string.Empty;
            string dbName = _configManager["database-name"];
            var request = new GetSecretValueRequest
            {
                SecretId = Environment.GetEnvironmentVariable(secretName)
            };

            GetSecretValueResponse response = null;

            try
            {
                response = managerClient.GetSecretValueAsync(request).GetAwaiter().GetResult();
            }
            catch (ResourceNotFoundException)
            {
                Console.WriteLine("The requested secret " + secretName + " was not found");
            }
            catch (InvalidRequestException e)
            {
                Console.WriteLine("The request was invalid due to: " + e.Message);
            }
            catch (InvalidParameterException e)
            {
                Console.WriteLine("The request had invalid params: " + e.Message);
            }

            //response = ""
            if (response != null)
            {
                var secretVarialbles = JsonConvert.DeserializeObject<SecretManager>(response.SecretString);
                 connString = $"Server={secretVarialbles.host};Port={secretVarialbles.port};database={dbName};User Id={secretVarialbles.username};Password={secretVarialbles.password};convert zero datetime=True";

            }

            return connString;
        }

        #region GetSecretByKey        
        public string GetConfigValueByKey(string secretName)
        {
            #region Properties
            string region = string.Empty;
            string secret = string.Empty;
            #endregion Properties

            #region Logic

            if (_configManager["Region"] != null && _configManager["Region"] != string.Empty)
            {
                region = _configManager["Region"];
            }
            var aws_access_key_id = "";
            var aws_secret_access_key = "";
            MemoryStream memoryStream = new MemoryStream();
            IAmazonSecretsManager client = new 
                AmazonSecretsManagerClient(RegionEndpoint.GetBySystemName(region));


            GetSecretValueRequest request = new GetSecretValueRequest();
            request.SecretId = secretName;
            request.VersionStage = "AWSCURRENT"; // VersionStage defaults to AWSCURRENT if unspecified.

            GetSecretValueResponse response = null;

            try
            {
                response = client.GetSecretValueAsync(request).Result;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            if (response.SecretString != null)
            {
                secret = response.SecretString;
            }
            else
            {
                memoryStream = response.SecretBinary;
                StreamReader reader = new StreamReader(memoryStream);
                decodedBinarySecret = System.Text.Encoding.UTF8.GetString(Convert.FromBase64String(reader.ReadToEnd()));
            }

            var jsonKey = !string.IsNullOrEmpty(secret) ? secret : decodedBinarySecret;
            JObject obj = JObject.Parse(jsonKey);
            string SecretKey = (string)obj[Constants.DBConnectionstring];
       
            return SecretKey;
            #endregion Logic
        }
        #endregion GetSecretByKey

        public string GetCacheSecretValueByKey(string secretName)
        {
            var request = new GetSecretValueRequest
            {
                SecretId = Environment.GetEnvironmentVariable(secretName)
            };
            LambdaLogger.Log("SecretsManagerService: SecretId " + request.SecretId);

            GetSecretValueResponse response = null;
            try
            {
                response = managerClient.GetSecretValueAsync(request).GetAwaiter().GetResult();
                LambdaLogger.Log("SecretsManagerService: got result ");
            }
            catch (Exception ex)
            {
                LambdaLogger.Log("SecretsManagerService: error message: " + ex.Message);
            }

            if (response != null)
            {
                var secretVarialbles = JsonConvert.DeserializeObject<SecretManager>(response.SecretString);
                LambdaLogger.Log("SecretsManagerService: DeserializeObject done: ");
                return secretVarialbles.cacheauthtoken;
            }
            else
            {
                return string.Empty;
            }
        }
    }
}
