﻿using Deloitte.AIFA.DomainEntities.EmailEntities;
using System;

namespace Deloitte.AIFA.EmailNotificationServices.NotificationServices.Interfaces
{
    interface IForm3283SNotification
    {
       
        BaseEmailEntity Form3283S_Fully_Approved_Notification(string argOperationType, string argOperationDescription, string argTemplateId, string ArchiveNumber, string ApprovedBy, string ADCED, string ActionItemId);
        BaseEmailEntity Form3283S_AP_Awaiting_Approval_Notification(string argOperationType, string argOperationDescription, string argTemplateId, string ArchiveNumber, string ApprovedBy, string ActionItemId);
        BaseEmailEntity Form3283S_PIC_Awaiting_Approval_Notification(string argOperationType, string argOperationDescription, string argTemplateId, string ArchiveNumber, string ApprovedBy, string ActionItemId);
        BaseEmailEntity Form3283S_PPD_Awaiting_Approval_Notification(string argOperationType, string argOperationDescription, string argTemplateId, string ArchiveNumber, string ApprovedBy, string ActionItemId);

    }
}
