import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'formatTime'
})
export class FormatTimePipe implements PipeTransform {

  transform(timeinsec: number, longForm: boolean): string {
    let value = "";
    let type = "";

    if (timeinsec >= 1 * 60 * 60) {
      type = "Hrs";
      value = Math.ceil(timeinsec / (60 * 60)).toString();
    }
    else if (timeinsec >= 1 * 60) {
      type = "Mins";
      value = Math.ceil(timeinsec / 60).toString();
    } else {
      type = "Secs";
      value = Math.ceil(timeinsec).toString();
    }

    return `${value} ${type}`;
  }
}