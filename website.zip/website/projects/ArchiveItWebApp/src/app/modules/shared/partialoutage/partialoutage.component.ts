import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-partialoutage',
  templateUrl: './partialoutage.component.html',
  styleUrls: ['./partialoutage.component.css']
})
export class PartialoutageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
