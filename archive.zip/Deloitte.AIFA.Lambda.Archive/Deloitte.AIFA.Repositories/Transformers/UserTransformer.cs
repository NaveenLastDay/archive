﻿using Deloitte.AIFA.DataModels;
using Deloitte.AIFA.DBHelper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace Deloitte.AIFA.Repositories.Transformers
{
    public enum UserField
    {
        userAlias,
        EmployeeRoleId,
        FirstName,
        LastName,
       IsManager,
        IsPPD,
        Title,
        PreferredFirstName
    }

    public enum UserParameter
    {
        [CreateField(Name = "userAlias", Direction = ParameterDirection.Input, Type = DbType.String)]
        userAlias,
        [CreateField(Name = "EmployeeRoleId", Direction = ParameterDirection.Input, Type = DbType.Int16)]
        EmployeeRoleId,

    }
    public class UserTransformer : BaseTransformer<UserModel>
    {
        internal override UserModel TransformElement(IDataReader dr, Func<IDataReader, UserModel, UserModel> bindExtraFields = null)
        {
            var users = new UserModel
            {
                userAlias = dr[UserField.userAlias.ToString()].ToString(),
                employeeRoleId = Convert.ToInt32(dr[UserField.EmployeeRoleId.ToString()].ToString())
            };
            return users;
        }
    }

    public class UserDetailsTransformer : BaseTransformer<UserDetailsModel>
    {
        internal override UserDetailsModel TransformElement(IDataReader dr, Func<IDataReader, UserDetailsModel, UserDetailsModel> bindExtraFields = null)
        {
            var users = new UserDetailsModel
            {
                userAlias = dr[UserField.userAlias.ToString()].ToString(),
                firstName = dr[UserField.FirstName.ToString()].ToString(),
                lastName = dr[UserField.LastName.ToString()].ToString(),
                employeeRoleId = Convert.ToInt32(dr[UserField.EmployeeRoleId.ToString()].ToString()),
                isManager = Convert.ToInt32(dr[UserField.IsManager.ToString()].ToString()),
                isPPD = Convert.ToInt32(dr[UserField.IsPPD.ToString()].ToString()),
                title = dr[UserField.Title.ToString()].ToString(),
                preferredFirstName=dr[UserField.PreferredFirstName.ToString()].ToString()
            };
            return users;
        }
    }
}
