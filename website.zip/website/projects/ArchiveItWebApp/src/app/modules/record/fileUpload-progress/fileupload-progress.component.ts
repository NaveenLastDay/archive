import { Component, OnInit } from "@angular/core";
import { FileUploadEventService } from "../file-upload/fileupload.event.service";
import { ResizeEvent } from "angular-resizable-element";
import { NgxSpinnerService } from 'ngx-spinner';
import { FileUploadProcessService } from '../file-upload/fileupload.process.service';
import { FielUploadService } from '../../../services/fileupload.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: "app-fileupload-progress",
  templateUrl: "./fileupload-progress.component.html",
  styleUrls: ["./fileupload-progress.component.css"]
})
export class FileuploadProgressComponent implements OnInit {
  uploadPercentage: number;
  uploadedFilesPercentage: number;
  toggleText: string = "";
  hideFileSection: boolean = false;
  isSuccess: boolean = true;
  uploadingInfoText: string = "";
  uploadingIcon: string = "";
  headerColor: string = "";
  displayFileArray = [];
  filesInProgress = [];
  uploadBarcontentHeight: number = 0;
  resizedStyles: {};
  uploadBarContentMaxHeight: number = 220;
  uploadBarHeaderHeight: number = 56;

  constructor(private _fuService: FielUploadService,
    private _fuEventService: FileUploadEventService,
    private _spinnerService: NgxSpinnerService,
    private _activatedRoute: ActivatedRoute) { }

  ngOnInit() {

    this.toggleText = "Collapse";

    this.showUploadInsurance();
    this._fuEventService.updateUploadStatus.subscribe(fileArray => {
      this.showUploadInsurance();
    });
  }

  showUploadInsurance() {
    var archiveNumber = this._activatedRoute.snapshot.paramMap.get("aN");
    // this.displayFileArray = this._fuEventService.fileArray.filter(
    //   x => x.fileName != "" && x.uploadStatus != "add" && x.uploadStatus != "dismissed" &&
    //     x.metaData.ArchiveNumber == archiveNumber  && x.module==this._fuEventService.currentModule
    // );
    this.displayFileArray = this._fuEventService.fileArray.filter(
      x => x.fileName != "" && x.uploadStatus != "add" && x.uploadStatus != "dismissed"        
    );
    this.calculateOverAllPercentage();
    this.buildOverallUploadStatus();
  }

  buildOverallUploadStatus() {
    let uploadStatusStr = "";

    let startedLength = this.displayFileArray.filter(
      x => x.uploadStatus === "started"
    ).length;
    let successLength = this.displayFileArray.filter(
      x => x.uploadStatus === "success"
    ).length;
    let failedLength = this.displayFileArray.filter(
      x => x.uploadStatus === "failed"
    ).length;
    let cancelledLength = this.displayFileArray.filter(
      x => x.uploadStatus === "aborted"
    ).length;

    if (startedLength > 0) {
      var fustatusStr = "";

      if (startedLength > 0) {
        fustatusStr += "Uploading " + startedLength + " item(s)";
        this.uploadingIcon = "Upload";
        this.headerColor = "Upload";
      }
      if (failedLength > 0) {
        fustatusStr += ", " + failedLength + " failed";
        this.uploadingIcon = "Failed";
        this.headerColor = "Completed";
      }

      if (fustatusStr.indexOf(',') == 0) {
        fustatusStr = fustatusStr.substring(1, fustatusStr.length);
      }
      if (this.hideFileSection) {
        this.toggleText = "Expand";
      }
      else {
        this.toggleText = "Collapse";
      }
      uploadStatusStr = fustatusStr;
    }
    else {
      var statusStr = "";

      if (successLength > 0) {
        statusStr += successLength + " completed";
        this.uploadingIcon = "Completed";
        this.headerColor = "Completed";
      }
      if (failedLength > 0) {
        statusStr += ", " + failedLength + " failed";
        this.uploadingIcon = "Failed";
        this.headerColor = "Completed";
      }
      if (cancelledLength > 0) {
        statusStr += ", " + cancelledLength + " cancelled";
        this.uploadingIcon = "Failed";
        this.headerColor = "Completed";
      }


      if (statusStr.indexOf(',') == 0)
        statusStr = statusStr.substring(1, statusStr.length);

      uploadStatusStr = statusStr;

      if (this.displayFileArray.length > 0 && startedLength == 0 && !this.hideFileSection) {
        this.toggleText = "Close"
      }
    }
    this.uploadingInfoText = uploadStatusStr;
  }

  calculateOverAllPercentage() {
    let sum = 0;

    this.filesInProgress = this.displayFileArray.filter(x => x.uploadStatus == 'started');
    this.filesInProgress.forEach(file => {
      sum += +file.uploadPercentage;
    });
    if (this.filesInProgress.length > 0) {
      let percentage = sum / this.filesInProgress.length;
      this.uploadedFilesPercentage = percentage;
    }
    else {
      this.uploadedFilesPercentage = 0;
    }
  }

  toggleSection() {

    let startedLength = this.displayFileArray.filter(
      x => x.uploadStatus === "started"
    ).length;

    if (this.toggleText == 'Close') {
      var archiveNumber = this._activatedRoute.snapshot.paramMap.get("aN");

      this._fuEventService.fileArray = this._fuEventService.fileArray.filter(
        x => this.displayFileArray.findIndex(x => x.fileName == x.fileName) == -1 && x.uploadStatus != "add" && x.uploadStatus != "dismissed" &&
          x.metaData.ArchiveNumber == archiveNumber
      );
      this.displayFileArray = [];
      console.log(this._fuEventService.fileArray);
      return;
    }

    this.hideFileSection = !this.hideFileSection;
    if (this.hideFileSection) {
      this.toggleText = "Expand";
      this.resizedStyles = {
        height: 'auto'
      };
    } else {
      if (startedLength == 0) {
        this.toggleText = "Close"

      } else {
        this.toggleText = "Collapse";
      }
    }


  }

  //FileUploadStep 17:
  //To abort the current uploading and update the status in DB
  crossIconClick(fileId, archiveFileId, fileTransferId, s3FileName, uploadId) {

    var self = this;

    if (!uploadId) return false;

    self._fuEventService.onAbortUpload(s3FileName, uploadId);
  }

  dismissClick(fileId: string) {
    this._fuEventService.fileArray = this._fuEventService.fileArray.filter(
      x => x.fileId != fileId
    );

    var fileElement = document.getElementById(fileId);
    document.getElementById("div_fileupload").removeChild(fileElement);

    this._fuEventService.onupdateUploadStatus(this._fuEventService.fileArray);
  }

  onResizeEnd(event: ResizeEvent): void {
    this.resizedStyles = {
      width: `${event.rectangle.width}px`,
      height: `${event.rectangle.height}px`
    };

    this.uploadBarContentMaxHeight =
      event.rectangle.height - this.uploadBarHeaderHeight;
  }
}
