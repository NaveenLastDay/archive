import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
    providedIn: 'root'
})
export class ManageElasticIndexService {

  apiData: any;
  
  constructor(private _http: HttpClient) { }
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    }),
  }

    public indexArchive(indexValues:any):Observable<any>{
        //debugger;
        this.apiData = this._http.post<any[]>('/v1/indexrecord',indexValues,  this.httpOptions);
        return this.apiData;
      }

}