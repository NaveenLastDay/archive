﻿using Deloitte.AIFA.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using Deloitte.AIFA.DomainEntities;
using Deloitte.AIFA.DBHelper;
using Deloitte.AIFA.DataModels;

namespace Deloitte.AIFA.Repositories.Transformers
{

    public class ArchiveMetaDataTransformer : BaseTransformer<EngagementTypeModel>
    {
        internal override EngagementTypeModel TransformElement(IDataReader dr, Func<IDataReader, EngagementTypeModel, EngagementTypeModel> bindExtraFields = null)
        {
            return new EngagementTypeModel
            {
                EngagementTypeId = (dr[EngagementTypeOutputFields.EngagementTypeId.ToString()] is DBNull) ? 0 : int.Parse(dr[EngagementTypeOutputFields.EngagementTypeId.ToString()].ToString()),
                EngagementTypeDescription = (dr[EngagementTypeOutputFields.EngagementTypeDescription.ToString()] is DBNull ? string.Empty : dr[EngagementTypeOutputFields.EngagementTypeDescription.ToString()].ToString())
               
            };
        }

    }

    public enum EngagementTypeOutputFields
    {
        EngagementTypeId,
        EngagementTypeDescription
       

    }

    public enum ArchiveTypeOutputFields
    {
        ArchiveTypeID,
        Description
   
    }


    public class ArchiveMetaDataArchiveTypeTransformer : BaseTransformer<ArchiveTypeModel>
    {
        internal override ArchiveTypeModel TransformElement(IDataReader dr, Func<IDataReader, ArchiveTypeModel, ArchiveTypeModel> bindExtraFields = null)
        {
            return new ArchiveTypeModel
            {
                ArchiveTypeID = (dr[ArchiveTypeOutputFields.ArchiveTypeID.ToString()] is DBNull) ? 0 : int.Parse(dr[ArchiveTypeOutputFields.ArchiveTypeID.ToString()].ToString()),
                Description = (dr[ArchiveTypeOutputFields.Description.ToString()] is DBNull) ? string.Empty : dr[ArchiveTypeOutputFields.Description.ToString()].ToString(),
             };
        }
    }


    public enum EntityTypeOutputFields
    {
        EntityTypeId,
        EntityTypeDescription
    
    }


    public class ArchiveMetaDataEntityTypeTransformer : BaseTransformer<EntityTypeModel>
    {
        internal override EntityTypeModel TransformElement(IDataReader dr, Func<IDataReader, EntityTypeModel, EntityTypeModel> bindExtraFields = null)
        {
            return new EntityTypeModel
            {
                EntityTypeId = (dr[EntityTypeOutputFields.EntityTypeId.ToString()] is DBNull) ? 0 : int.Parse(dr[EntityTypeOutputFields.EntityTypeId.ToString()].ToString()),
                EntityTypeDescription = (dr[EntityTypeOutputFields.EntityTypeDescription.ToString()] is DBNull) ? string.Empty : dr[EntityTypeOutputFields.EntityTypeDescription.ToString()].ToString(),
               
            };
        }

    }

    public enum ProfessionalStandardsOutputFields
    {
        ProfessionalStandardID,
        Description
       

    }

    public class ArchiveMetaDataProfessionalStandardTransformer : BaseTransformer<ProfessionalStandardsModel>
    {
        internal override ProfessionalStandardsModel TransformElement(IDataReader dr, Func<IDataReader, ProfessionalStandardsModel, ProfessionalStandardsModel> bindExtraFields = null)
        {
            return new ProfessionalStandardsModel
            {
                ProfessionalStandardID = (dr[ProfessionalStandardsOutputFields.ProfessionalStandardID.ToString()] is DBNull) ? 0 : int.Parse(dr[ProfessionalStandardsOutputFields.ProfessionalStandardID.ToString()].ToString()),
                Description = (dr[ProfessionalStandardsOutputFields.Description.ToString()] is DBNull) ? string.Empty : dr[ProfessionalStandardsOutputFields.Description.ToString()].ToString()
     
            };
        }
    }

    public enum RetentionReasonOutputFields
    {
        RetentionReasonID,
        Description,
    }

    public class ArchiveMetaDataRetentionReasonTransformer : BaseTransformer<RetentionReasonModel>
    {
        internal override RetentionReasonModel TransformElement(IDataReader dr, Func<IDataReader, RetentionReasonModel, RetentionReasonModel> bindExtraFields = null)
        {
            return new RetentionReasonModel
            {
                RetentionReasonID = (dr[RetentionReasonOutputFields.RetentionReasonID.ToString()] is DBNull) ? 0 : int.Parse(dr[RetentionReasonOutputFields.RetentionReasonID.ToString()].ToString()),
                Description = (dr[RetentionReasonOutputFields.Description.ToString()] is DBNull) ? string.Empty : dr[RetentionReasonOutputFields.Description.ToString()].ToString(),

            };
        }
    }

    public enum ArchiveRetentionReasonInputFields
    {
        ArchiveID,
        RetentionReasonID,
        ExtendRetention,
        RetentionExtentionReason,
        RetentionTime
    }





    public enum ArchiveSearchBaseOutputFields
    {
        ClientID,
        ClientName,
        ClientNumber,
        WBSClientName,
        WbsLevelOneNumber,
        WBSLevelOneDescription,
        WBSLevelOneDateCreated,
        Archivecount,
        ArchivePartner,
        ArchivePartnerAlias,
        Count
        // ResponseMessage

    }
    public class ArchiveMetaDataSearchBaseTransformer : BaseTransformer<ArchiveSearchBaseModel>
    {
        internal override ArchiveSearchBaseModel TransformElement(IDataReader dr, Func<IDataReader, ArchiveSearchBaseModel, ArchiveSearchBaseModel> bindExtraFields = null)
        {
            return new ArchiveSearchBaseModel
            {
                ClientID = (dr[ArchiveSearchBaseOutputFields.ClientID.ToString()] is DBNull) ? string.Empty : dr[ArchiveSearchBaseOutputFields.ClientID.ToString()].ToString(),
                ClientName = (dr[ArchiveSearchBaseOutputFields.ClientName.ToString()] is DBNull) ? string.Empty : dr[ArchiveSearchBaseOutputFields.ClientName.ToString()].ToString(),
                ClientNumber = (dr[ArchiveSearchBaseOutputFields.ClientNumber.ToString()] is DBNull) ? string.Empty : dr[ArchiveSearchBaseOutputFields.ClientNumber.ToString()].ToString(),
                WbsLevelOneNumber = (dr[ArchiveSearchBaseOutputFields.WbsLevelOneNumber.ToString()] is DBNull) ? string.Empty : dr[ArchiveSearchBaseOutputFields.WbsLevelOneNumber.ToString()].ToString(),
                WBSLevelOneDescription = (dr[ArchiveSearchBaseOutputFields.WBSLevelOneDescription.ToString()] is DBNull) ? string.Empty : dr[ArchiveSearchBaseOutputFields.WBSLevelOneDescription.ToString()].ToString(),
                WBSLevelOneDateCreated = (dr[ArchiveSearchBaseOutputFields.WBSLevelOneDateCreated.ToString()] is DBNull) ? DateTime.MinValue : DateTime.Parse(dr[ArchiveSearchBaseOutputFields.WBSLevelOneDateCreated.ToString()].ToString()),
                Count = (dr[ArchiveSearchBaseOutputFields.Archivecount.ToString()] is DBNull) ? 0 : int.Parse(dr[ArchiveSearchBaseOutputFields.Archivecount.ToString()].ToString())

                //  ResponseMessage = (dr[EngagementTypeOutputFields.ResponseMessage.ToString()] is DBNull ? string.Empty : dr[EngagementTypeOutputFields.ResponseMessage.ToString()].ToString()),
            };
        }
    }

    public enum ExistingArchivesInfoFieldParameter
    {
        [CreateField(Name = "WbsLevelOne_In", Direction = ParameterDirection.Input, Type = DbType.String)]
        WbsLevelOne,
        [CreateField(Name = "UserAlias_In", Direction = ParameterDirection.Input, Type = DbType.String)]
        UserAlias,
        [CreateField(Name = "p_PageNumber", Direction = ParameterDirection.Input, Type = DbType.Int32)]
        p_PageNumber,
        [CreateField(Name = "p_PageSize", Direction = ParameterDirection.Input, Type = DbType.Int32)]
        p_PageSize

    }
    public enum ResubmissionApprovalFlow
    {
        [CreateField(Name = "p_ArchiveNumber", Direction = ParameterDirection.Input, Type = DbType.String)]
        ArchiveNumber,
        [CreateField(Name = "p_UserAlias", Direction = ParameterDirection.Input, Type = DbType.String)]
        UserAlias,
        [CreateField(Name = "p_roleId", Direction = ParameterDirection.Input, Type = DbType.Int32)]
        RoleID,
        [CreateField(Name = "p_ArchiveStatus_Out", Direction = ParameterDirection.Output, Type = DbType.String)]
        ArchiveStatus,
        [CreateField(Name = "p_CreatedDateAndZoneName_Out", Direction = ParameterDirection.Output, Type = DbType.String)]
        CreatedDateAndZoneName,
    }
    public enum ROIMetadataFieldParameter
    {
        [CreateField(Name = "p_ArchiveNumber", Direction = ParameterDirection.Input, Type = DbType.String)]
        ArchiveNumber,
        [CreateField(Name = "p_RoiNumber", Direction = ParameterDirection.Input, Type = DbType.String)]
        RoiNumber,
        [CreateField(Name = "p_ETag", Direction = ParameterDirection.Input, Type = DbType.String)]
        ETag,
        [CreateField(Name = "p_FileTransferID", Direction = ParameterDirection.Input, Type = DbType.Int32)]
        FileTransferID,
        [CreateField(Name = "p_S3FilePath", Direction = ParameterDirection.Input, Type = DbType.String)]
        S3FilePath,
        [CreateField(Name = "p_CreatedBy", Direction = ParameterDirection.Input, Type = DbType.String)]
        CreatedBy,

    }
    public class ExistingArchivesTransformer : BaseTransformer<ExistingArchivesModel>
    {
        internal override ExistingArchivesModel TransformElement(IDataReader dr, Func<IDataReader, ExistingArchivesModel, ExistingArchivesModel> bindExtraFields = null)
        {
            return new ExistingArchivesModel
            {
                ArchiveID = (dr[ExistingArchivesInfoOutputFields.ArchiveID.ToString()] is DBNull) ? 0 : int.Parse(dr[ExistingArchivesInfoOutputFields.ArchiveID.ToString()].ToString()),
                ArchiveNumber = (dr[ExistingArchivesInfoOutputFields.ArchiveNumber.ToString()] is DBNull) ? string.Empty : dr[ExistingArchivesInfoOutputFields.ArchiveNumber.ToString()].ToString(),
                Description = (dr[ExistingArchivesInfoOutputFields.Description.ToString()] is DBNull) ? string.Empty : dr[ExistingArchivesInfoOutputFields.Description.ToString()].ToString(),
                PeriodEndDate = (dr[ExistingArchivesInfoOutputFields.PeriodEndDate.ToString()] is DBNull) ? DateTime.MinValue : DateTime.Parse(dr[ExistingArchivesInfoOutputFields.PeriodEndDate.ToString()].ToString()),
                EngagementDescription = (dr[ExistingArchivesInfoOutputFields.EngagementDescription.ToString()] is DBNull) ? string.Empty : dr[ExistingArchivesInfoOutputFields.EngagementDescription.ToString()].ToString(),
                ClientName = (dr[ExistingArchivesInfoOutputFields.ClientName.ToString()] is DBNull) ? string.Empty : dr[ExistingArchivesInfoOutputFields.ClientName.ToString()].ToString(),
                WBSLevelOne = (dr[ExistingArchivesInfoOutputFields.WBSLevelOne.ToString()] is DBNull) ? string.Empty : dr[ExistingArchivesInfoOutputFields.WBSLevelOne.ToString()].ToString(),
                WBSLevelOneName = (dr[ExistingArchivesInfoOutputFields.WBSLevelOneName.ToString()] is DBNull) ? string.Empty : dr[ExistingArchivesInfoOutputFields.WBSLevelOneName.ToString()].ToString(),
                EDCD = (dr[ExistingArchivesInfoOutputFields.EstimatedIssuanceReportDate.ToString()] is DBNull) ? DateTime.MinValue : DateTime.Parse(dr[ExistingArchivesInfoOutputFields.EstimatedIssuanceReportDate.ToString()].ToString()),
                WBSLevelOneNumber = (dr[ExistingArchivesInfoOutputFields.WBSLevelOneNumber.ToString()] is DBNull) ? string.Empty : dr[ExistingArchivesInfoOutputFields.WBSLevelOneNumber.ToString()].ToString(),
                EngagementTypeDescription = (dr[ExistingArchivesInfoOutputFields.EngagementTypeDescription.ToString()] is DBNull) ? string.Empty : dr[ExistingArchivesInfoOutputFields.EngagementTypeDescription.ToString()].ToString(),
                ArchiveDueDate = (dr[ExistingArchivesInfoOutputFields.ArchiveDueDate.ToString()] is DBNull) ? DateTime.MinValue : DateTime.Parse(dr[ExistingArchivesInfoOutputFields.ArchiveDueDate.ToString()].ToString()),
                IsResubmissionInProgress = (dr[ExistingArchivesInfoOutputFields.IsResubmissionInProgress.ToString()] is DBNull) ? string.Empty : dr[ExistingArchivesInfoOutputFields.IsResubmissionInProgress.ToString()].ToString(),
                ReportingEntity = (dr[ExistingArchivesInfoOutputFields.ReportingEntity.ToString()] is DBNull) ? string.Empty : dr[ExistingArchivesInfoOutputFields.ReportingEntity.ToString()].ToString(),
                ArchivePartner = (dr[ExistingArchivesInfoOutputFields.ArchivePartner.ToString()] is DBNull) ? string.Empty : dr[ExistingArchivesInfoOutputFields.ArchivePartner.ToString()].ToString(),
                ArchvieManger = (dr[ExistingArchivesInfoOutputFields.ArchvieManger.ToString()] is DBNull) ? string.Empty : dr[ExistingArchivesInfoOutputFields.ArchvieManger.ToString()].ToString(),
                ArchvieFieldSenior = (dr[ExistingArchivesInfoOutputFields.ArchvieFieldSenior.ToString()] is DBNull) ? string.Empty : dr[ExistingArchivesInfoOutputFields.ArchvieFieldSenior.ToString()].ToString(),
                AddArchiveFieldSenior = (dr[ExistingArchivesInfoOutputFields.AddArchvieFieldSenior.ToString()] is DBNull) ? string.Empty : dr[ExistingArchivesInfoOutputFields.AddArchvieFieldSenior.ToString()].ToString()

                //  ResponseMessage = (dr[EngagementTypeOutputFields.ResponseMessage.ToString()] is DBNull ? string.Empty : dr[EngagementTypeOutputFields.ResponseMessage.ToString()].ToString()),
            };
        }
    }

    public enum ArchiveInfoOutputFields
    {
        ArchiveID,
        WBSLevelOneNumber,
        EngagementTypeDescription,
        ArchiveDueDate,
        EstimatedIssuanceReportDate,
        IsResubmissionInProgress,
        ReportingEntity,
        ArchivePartner,
        ArchvieManger,
        ArchvieFieldSenior,
        AddArchvieFieldSenior
    }
    public class ArchiveInfoTransformer : BaseTransformer<ArchiveInfoModel>
    {
        internal override ArchiveInfoModel TransformElement(IDataReader dr, Func<IDataReader, ArchiveInfoModel, ArchiveInfoModel> bindExtraFields = null)
        {
            return new ArchiveInfoModel
            {
                ArchiveID = (dr[ArchiveInfoOutputFields.ArchiveID.ToString()] is DBNull) ? 0 : int.Parse(dr[ArchiveInfoOutputFields.ArchiveID.ToString()].ToString()),
                WBSLevelOneNumber = (dr[ArchiveInfoOutputFields.WBSLevelOneNumber.ToString()] is DBNull) ? string.Empty : dr[ArchiveInfoOutputFields.WBSLevelOneNumber.ToString()].ToString(),
                EngagementTypeDescription = (dr[ArchiveInfoOutputFields.EngagementTypeDescription.ToString()] is DBNull) ? string.Empty : dr[ArchiveInfoOutputFields.EngagementTypeDescription.ToString()].ToString(),
                ArchiveDueDate = (dr[ArchiveInfoOutputFields.ArchiveDueDate.ToString()] is DBNull) ? DateTime.MinValue : DateTime.Parse(dr[ArchiveInfoOutputFields.ArchiveDueDate.ToString()].ToString()),
                EDCD = (dr[ArchiveInfoOutputFields.EstimatedIssuanceReportDate.ToString()] is DBNull) ? DateTime.MinValue : DateTime.Parse(dr[ArchiveInfoOutputFields.EstimatedIssuanceReportDate.ToString()].ToString()),
                IsResubmissionInProgress = (dr[ArchiveInfoOutputFields.IsResubmissionInProgress.ToString()] is DBNull) ? string.Empty : dr[ArchiveInfoOutputFields.IsResubmissionInProgress.ToString()].ToString(),
                ReportingEntity = (dr[ArchiveInfoOutputFields.ReportingEntity.ToString()] is DBNull) ? string.Empty : dr[ArchiveInfoOutputFields.ReportingEntity.ToString()].ToString(),
                ArchivePartner = (dr[ArchiveInfoOutputFields.ArchivePartner.ToString()] is DBNull) ? string.Empty : dr[ArchiveInfoOutputFields.ArchivePartner.ToString()].ToString(),
                ArchvieManger = (dr[ArchiveInfoOutputFields.ArchvieManger.ToString()] is DBNull) ? string.Empty : dr[ArchiveInfoOutputFields.ArchvieManger.ToString()].ToString(),
                ArchvieFieldSenior = (dr[ArchiveInfoOutputFields.ArchvieFieldSenior.ToString()] is DBNull) ? string.Empty : dr[ArchiveInfoOutputFields.ArchvieFieldSenior.ToString()].ToString(),
                AddArchiveFieldSenior = (dr[ArchiveInfoOutputFields.AddArchvieFieldSenior.ToString()] is DBNull) ? string.Empty : dr[ArchiveInfoOutputFields.AddArchvieFieldSenior.ToString()].ToString()

                //  ResponseMessage = (dr[EngagementTypeOutputFields.ResponseMessage.ToString()] is DBNull ? string.Empty : dr[EngagementTypeOutputFields.ResponseMessage.ToString()].ToString()),
            };
        }
    }

    public enum ExistingArchivesInfoOutputFields
    {
        ArchiveID,
        ArchiveNumber,
        WBSLevelOneNumber,
        WBSLevelOne,
        WBSLevelOneName,
        ClientName,
        EngagementTypeDescription,
        ArchiveDueDate,
        EstimatedIssuanceReportDate,
        IsResubmissionInProgress,
        ReportingEntity,
        ArchivePartner,
        ArchvieManger,
        ArchvieFieldSenior,
        AddArchvieFieldSenior,
        Description,
        PeriodEndDate,
        EngagementDescription,
        ArchiveStatus,
        IsAcessAllowed,
        RowNumber
    }





    public class ExistingArchivesInfoTransformer : BaseTransformer<ExistingArchivesInfoModel>
    {
        internal override ExistingArchivesInfoModel TransformElement(IDataReader dr, Func<IDataReader, ExistingArchivesInfoModel, ExistingArchivesInfoModel> bindExtraFields = null)
        {
            ExistingArchivesInfoModel existingArchivesInfoModel = new ExistingArchivesInfoModel();
            ArchiveSearchBaseModel objarchivesearchbase = new ArchiveSearchBaseModel();
            existingArchivesInfoModel.lstExistingArchives = new List<ExistingArchivesModel>();

            existingArchivesInfoModel.archiveSearchBase = new ArchiveSearchBaseModel
            {

                ClientName = (dr[ArchiveSearchBaseOutputFields.ClientName.ToString()] is DBNull) ? string.Empty : dr[ArchiveSearchBaseOutputFields.ClientName.ToString()].ToString(),
                ClientNumber = (dr[ArchiveSearchBaseOutputFields.ClientNumber.ToString()] is DBNull) ? string.Empty : dr[ArchiveSearchBaseOutputFields.ClientNumber.ToString()].ToString(),
                WbsLevelOneNumber = (dr[ArchiveSearchBaseOutputFields.WbsLevelOneNumber.ToString()] is DBNull) ? string.Empty : dr[ArchiveSearchBaseOutputFields.WbsLevelOneNumber.ToString()].ToString(),
                WBSLevelOneDescription = (dr[ArchiveSearchBaseOutputFields.WBSLevelOneDescription.ToString()] is DBNull) ? string.Empty : dr[ArchiveSearchBaseOutputFields.WBSLevelOneDescription.ToString()].ToString(),
                ArchivePartner = (dr[ArchiveSearchBaseOutputFields.ArchivePartner.ToString()] is DBNull) ? string.Empty : dr[ArchiveSearchBaseOutputFields.ArchivePartner.ToString()].ToString(),
                ArchivePartnerAlias = (dr[ArchiveSearchBaseOutputFields.ArchivePartnerAlias.ToString()] is DBNull) ? string.Empty : dr[ArchiveSearchBaseOutputFields.ArchivePartnerAlias.ToString()].ToString(),
                Count = (dr[ArchiveSearchBaseOutputFields.Count.ToString()] is DBNull) ? 0 : int.Parse(dr[ArchiveSearchBaseOutputFields.Count.ToString()].ToString()),
            };


            if (dr.NextResult())
            {
                while (dr.Read())
                {
                    existingArchivesInfoModel.lstExistingArchives.Add(new ExistingArchivesModel
                    {
                        ArchiveID = (dr[ExistingArchivesInfoOutputFields.ArchiveID.ToString()] is DBNull) ? 0 : int.Parse(dr[ExistingArchivesInfoOutputFields.ArchiveID.ToString()].ToString()),
                        ArchiveNumber = (dr[ExistingArchivesInfoOutputFields.ArchiveNumber.ToString()] is DBNull) ? string.Empty : dr[ExistingArchivesInfoOutputFields.ArchiveNumber.ToString()].ToString(),
                        Description = (dr[ExistingArchivesInfoOutputFields.Description.ToString()] is DBNull) ? string.Empty : dr[ExistingArchivesInfoOutputFields.Description.ToString()].ToString(),
                        PeriodEndDate = (dr[ExistingArchivesInfoOutputFields.PeriodEndDate.ToString()] is DBNull) ? DateTime.MinValue : DateTime.Parse(dr[ExistingArchivesInfoOutputFields.PeriodEndDate.ToString()].ToString()),
                        EngagementDescription = (dr[ExistingArchivesInfoOutputFields.EngagementDescription.ToString()] is DBNull) ? string.Empty : dr[ExistingArchivesInfoOutputFields.EngagementDescription.ToString()].ToString(),
                        EDCD = (dr[ExistingArchivesInfoOutputFields.EstimatedIssuanceReportDate.ToString()] is DBNull) ? DateTime.MinValue : DateTime.Parse(dr[ExistingArchivesInfoOutputFields.EstimatedIssuanceReportDate.ToString()].ToString()),
                        Status = (dr[ExistingArchivesInfoOutputFields.ArchiveStatus.ToString()] is DBNull) ? string.Empty : dr[ExistingArchivesInfoOutputFields.ArchiveStatus.ToString()].ToString(),
                        IsAccessible = (dr[ExistingArchivesInfoOutputFields.IsAcessAllowed.ToString()] is DBNull) ? 0 : int.Parse(dr[ExistingArchivesInfoOutputFields.IsAcessAllowed.ToString()].ToString()),
                        RowNumber = (dr[ExistingArchivesInfoOutputFields.RowNumber.ToString()] is DBNull) ? 0 : int.Parse(dr[ExistingArchivesInfoOutputFields.RowNumber.ToString()].ToString()),

                    });

                }
            }
            return existingArchivesInfoModel;
        }
    }

    public enum EditArchiveDetailsOutputFields
    {
        EngagementDescription,
        PeriodEndDate,
        EngagementTypeDescription,
        EntityTypeDescription,
        StandardsApplied,
        ArchiveNameForWBSLevel1Number,
        AdditionalDescription,
        EngagementPartner,
        BusinessName,
        ServiceArea
    }
    public class EditArchiveDetailsTransformer : BaseTransformer<EditArchiveDetailsModel>
    {
        internal override EditArchiveDetailsModel TransformElement(IDataReader dr, Func<IDataReader, EditArchiveDetailsModel, EditArchiveDetailsModel> bindExtraFields = null)
        {
            return new EditArchiveDetailsModel
            {
                EngagementDescription = (dr[EditArchiveDetailsOutputFields.EngagementDescription.ToString()] is DBNull) ? string.Empty : dr[EditArchiveDetailsOutputFields.EngagementDescription.ToString()].ToString(),
                PeriodEndDate = (dr[EditArchiveDetailsOutputFields.PeriodEndDate.ToString()] is DBNull) ? DateTime.MinValue : DateTime.Parse(dr[EditArchiveDetailsOutputFields.PeriodEndDate.ToString()].ToString()),
                EngagementTypeDescription = (dr[EditArchiveDetailsOutputFields.EngagementTypeDescription.ToString()] is DBNull) ? string.Empty : dr[EditArchiveDetailsOutputFields.EngagementTypeDescription.ToString()].ToString(),
                EntityTypeDescription = (dr[EditArchiveDetailsOutputFields.EntityTypeDescription.ToString()] is DBNull) ? string.Empty : dr[EditArchiveDetailsOutputFields.EntityTypeDescription.ToString()].ToString(),
                StandardsApplied = (dr[EditArchiveDetailsOutputFields.StandardsApplied.ToString()] is DBNull) ? string.Empty : dr[EditArchiveDetailsOutputFields.StandardsApplied.ToString()].ToString(),
                ArchiveNameForWBSLevel1Number = (dr[EditArchiveDetailsOutputFields.ArchiveNameForWBSLevel1Number.ToString()] is DBNull) ? string.Empty : dr[EditArchiveDetailsOutputFields.ArchiveNameForWBSLevel1Number.ToString()].ToString(),
                AdditionalDescription = (dr[EditArchiveDetailsOutputFields.AdditionalDescription.ToString()] is DBNull) ? string.Empty : dr[EditArchiveDetailsOutputFields.AdditionalDescription.ToString()].ToString(),
                EngagementPartner = (dr[EditArchiveDetailsOutputFields.EngagementPartner.ToString()] is DBNull) ? string.Empty : dr[EditArchiveDetailsOutputFields.EngagementPartner.ToString()].ToString(),
                BusinessName = (dr[EditArchiveDetailsOutputFields.BusinessName.ToString()] is DBNull) ? string.Empty : dr[EditArchiveDetailsOutputFields.BusinessName.ToString()].ToString(),
                ServiceArea = (dr[EditArchiveDetailsOutputFields.ServiceArea.ToString()] is DBNull) ? string.Empty : dr[EditArchiveDetailsOutputFields.ServiceArea.ToString()].ToString()
            };
        }
    }

    public enum AutoCreateArchiveOutputFields
    {
        ArchiveNumber,
        EstimatedIssuanceReportDate,
        IsArchiveCompleted,
        Archivepartneralias,
        ArchivepartnerName,
        Archivemanageralias,
        Archivemanagername,
        WBSLevelOne,
        WBSLevelOneName,
        ClientName
}

    public class AutoCreateArchiveDetailsTransformer : BaseTransformer<AutoCreateArchiveDetailsModel>
    {
        internal override AutoCreateArchiveDetailsModel TransformElement(IDataReader dr, Func<IDataReader, AutoCreateArchiveDetailsModel, AutoCreateArchiveDetailsModel> bindExtraFields = null)
        {
            return new AutoCreateArchiveDetailsModel
            {
                ArchiveNumber = (dr[AutoCreateArchiveOutputFields.ArchiveNumber.ToString()] is DBNull) ? string.Empty : dr[AutoCreateArchiveOutputFields.ArchiveNumber.ToString()].ToString(),
                EstimatedIssuanceReportDate = (dr[AutoCreateArchiveOutputFields.EstimatedIssuanceReportDate.ToString()] is DBNull) ? DateTime.MinValue : DateTime.Parse(dr[AutoCreateArchiveOutputFields.EstimatedIssuanceReportDate.ToString()].ToString()),
                IsArchiveCompleted = (dr[AutoCreateArchiveOutputFields.IsArchiveCompleted.ToString()] is DBNull) ? false : Convert.ToBoolean(dr[AutoCreateArchiveOutputFields.IsArchiveCompleted.ToString()]),
                Archivepartneralias = (dr[AutoCreateArchiveOutputFields.Archivepartneralias.ToString()] is DBNull) ? string.Empty : dr[AutoCreateArchiveOutputFields.Archivepartneralias.ToString()].ToString(),
                ArchivepartnerName = (dr[AutoCreateArchiveOutputFields.ArchivepartnerName.ToString()] is DBNull) ? string.Empty : dr[AutoCreateArchiveOutputFields.ArchivepartnerName.ToString()].ToString(),
                Archivemanageralias = (dr[AutoCreateArchiveOutputFields.Archivemanageralias.ToString()] is DBNull) ? string.Empty : dr[AutoCreateArchiveOutputFields.Archivemanageralias.ToString()].ToString(),
                Archivemanagername = (dr[AutoCreateArchiveOutputFields.Archivemanagername.ToString()] is DBNull) ? string.Empty : dr[AutoCreateArchiveOutputFields.Archivemanagername.ToString()].ToString(),
                WBSLevelOne = (dr[AutoCreateArchiveOutputFields.WBSLevelOne.ToString()] is DBNull) ? string.Empty : dr[AutoCreateArchiveOutputFields.WBSLevelOne.ToString()].ToString(),
                WBSLevelOneName = (dr[AutoCreateArchiveOutputFields.Archivemanageralias.ToString()] is DBNull) ? string.Empty : dr[AutoCreateArchiveOutputFields.WBSLevelOneName.ToString()].ToString(),
                ClientName = (dr[AutoCreateArchiveOutputFields.ClientName.ToString()] is DBNull) ? string.Empty : dr[AutoCreateArchiveOutputFields.ClientName.ToString()].ToString(),
            };
        }
    }

    public enum AutocreateArchiveinputparameter
    {
        [CreateField(Name = "ArchiveNumber_In", Direction = ParameterDirection.Input, Type = DbType.String)]
        ArchiveNumber_In
    }

    public enum ArchiveDeletionStatusOutputFields
    {
        ArchiveDeletionReason,
        CompletedByPersonnelNumber,
        RejectionReason,
        ArchiveDeletionActionStatus,
        CreatedDate,
        CreatedBy,
        IsActiveAction,
        IsRequestcancelled
    }

    public class ArchiveDeletionStatusTransformer : BaseTransformer<ArchiveDeletionStatusModel>
    {
        internal override ArchiveDeletionStatusModel TransformElement(IDataReader dr, Func<IDataReader, ArchiveDeletionStatusModel, ArchiveDeletionStatusModel> bindExtraFields = null)
        {
            return new ArchiveDeletionStatusModel
            {
                ArchiveDeletionReason = (dr[ArchiveDeletionStatusOutputFields.ArchiveDeletionReason.ToString()] is DBNull) ? string.Empty : dr[ArchiveDeletionStatusOutputFields.ArchiveDeletionReason.ToString()].ToString(),
                CompletedByPersonnelNumber = (dr[ArchiveDeletionStatusOutputFields.CompletedByPersonnelNumber.ToString()] is DBNull) ? 0 : int.Parse(dr[ArchiveDeletionStatusOutputFields.CompletedByPersonnelNumber.ToString()].ToString()),
                RejectionReason = (dr[ArchiveDeletionStatusOutputFields.RejectionReason.ToString()] is DBNull) ? string.Empty : dr[ArchiveDeletionStatusOutputFields.RejectionReason.ToString()].ToString(),
                ArchiveDeletionActionStatus = (dr[ArchiveDeletionStatusOutputFields.ArchiveDeletionActionStatus.ToString()] is DBNull) ? string.Empty : dr[ArchiveDeletionStatusOutputFields.ArchiveDeletionActionStatus.ToString()].ToString(),
                CreatedDate = (dr[ArchiveDeletionStatusOutputFields.CreatedDate.ToString()] is DBNull) ? DateTime.MinValue : DateTime.Parse(dr[ArchiveDeletionStatusOutputFields.CreatedDate.ToString()].ToString()),
                CreatedBy = (dr[ArchiveDeletionStatusOutputFields.CreatedBy.ToString()] is DBNull) ? string.Empty : dr[ArchiveDeletionStatusOutputFields.CreatedBy.ToString()].ToString(),
                IsActiveAction = (dr[ArchiveDeletionStatusOutputFields.IsActiveAction.ToString()] is DBNull) ? false : Convert.ToBoolean(dr[ArchiveDeletionStatusOutputFields.IsActiveAction.ToString()]),
                IsRequestcancelled = (dr[ArchiveDeletionStatusOutputFields.IsRequestcancelled.ToString()] is DBNull) ? false : Convert.ToBoolean(dr[ArchiveDeletionStatusOutputFields.IsRequestcancelled.ToString()]),
            };
        }
    }

    public class ResubmissionApprovalTrasformer : BaseTransformer<ResubmissionApproverModel>
    {
        internal override ResubmissionApproverModel TransformElement(IDataReader dr, Func<IDataReader, ResubmissionApproverModel, ResubmissionApproverModel> bindExtraFields = null)
        {
            ResubmissionApproverModel resubmissionApproverModel = new ResubmissionApproverModel();
            resubmissionApproverModel.lstResubmissionApprover = new List<ResubmissionApproverListModel>();

            resubmissionApproverModel.TotalLevelofApproval = Convert.ToInt32(dr[ResubmissionOpenFieldParameter.TotalApprover.ToString()]);

            if (dr.NextResult())
            {
                while (dr.Read())
                {
                    resubmissionApproverModel.lstResubmissionApprover.Add(new ResubmissionApproverListModel
                    {
                        FirstName = (dr[ResubmissionOpenFieldParameter.FirstName.ToString()] is DBNull) ? string.Empty : dr[ResubmissionOpenFieldParameter.FirstName.ToString()].ToString(),
                        LastName = (dr[ResubmissionOpenFieldParameter.LastName.ToString()] is DBNull) ? string.Empty : dr[ResubmissionOpenFieldParameter.LastName.ToString()].ToString(),
                        RoleID = Convert.ToInt32(dr[ResubmissionOpenFieldParameter.RoleID.ToString()]),
                        Type = (dr[ResubmissionOpenFieldParameter.Type.ToString()] is DBNull) ? string.Empty : dr[ResubmissionOpenFieldParameter.Type.ToString()].ToString()
                    });
                }
            }
            if (dr.NextResult())
            {
                while (dr.Read())
                {
                    resubmissionApproverModel.CompletedApprovel = (dr[ResubmissionOpenFieldParameter.CompletedApproval.ToString()] is DBNull) ? string.Empty : dr[ResubmissionOpenFieldParameter.CompletedApproval.ToString()].ToString();

                }
            }
            if (dr.NextResult())
            {
                while (dr.Read())
                {
                    resubmissionApproverModel.CanApprove = Convert.ToBoolean(dr[ResubmissionOpenFieldParameter.CanAccess.ToString()]);
                }
            }
            return resubmissionApproverModel;
        }
    }

    public class MemoTrasformer : BaseTransformer<MemoModel>
    {
        internal override MemoModel TransformElement(IDataReader dr, Func<IDataReader, MemoModel, MemoModel> bindExtraFields = null)
        {
            return new MemoModel
            {
                ArchiveFileIdOut = (dr[ArchiveMemoFieldParameter.ArchiveFileID.ToString()] is DBNull) ? 0 : int.Parse(dr[ArchiveMemoFieldParameter.ArchiveFileID.ToString()].ToString()),
                FileName = (dr[ArchiveMemoFieldParameter.FileName.ToString()] is DBNull ? string.Empty : dr[ArchiveMemoFieldParameter.FileName.ToString()].ToString()),
                FileTransferIdOut = Convert.ToInt32((dr[ArchiveMemoFieldParameter.FileTransferId.ToString()])),
            };
        }
    }
    public class CreateMemoTrasformer : BaseTransformer<MemoModel>
    {
        internal override MemoModel TransformElement(IDataReader dr, Func<IDataReader, MemoModel, MemoModel> bindExtraFields = null)
        {
            return new MemoModel
            {
                ArchiveFileIdOut = (dr[MemoOutputFields.ArchiveFileID.ToString()] is DBNull) ? 0 : int.Parse(dr[MemoOutputFields.ArchiveFileID.ToString()].ToString()),
                S3FileNameOut = (dr[MemoOutputFields.S3FileNameOut.ToString()] is DBNull ? string.Empty : dr[MemoOutputFields.S3FileNameOut.ToString()].ToString()),
                FileTransferIdOut = (dr[MemoOutputFields.FileTransferId.ToString()] is DBNull) ? 0 : int.Parse(dr[MemoOutputFields.FileTransferId.ToString()].ToString())
            };
        }
    }
    public class GetMemoTrasformer : BaseTransformer<MemoModel>
    {
        internal override MemoModel TransformElement(IDataReader dr, Func<IDataReader, MemoModel, MemoModel> bindExtraFields = null)
        {
            return new MemoModel
            {
                ArchiveFileIdOut = (dr[MemoOutputFields.ArchiveFileID.ToString()] is DBNull) ? 0 : int.Parse(dr[MemoOutputFields.ArchiveFileID.ToString()].ToString()),
                FileName = (dr[MemoOutputFields.FileName.ToString()] is DBNull ? string.Empty : dr[MemoOutputFields.FileName.ToString()].ToString()),
                FileTransferIdOut = (dr[MemoOutputFields.FileTransferId.ToString()] is DBNull) ? 0 : int.Parse(dr[MemoOutputFields.FileTransferId.ToString()].ToString()),
                FileVerificationStatusID = (dr[MemoOutputFields.FileVerificationStatusID.ToString()] is DBNull) ? 0 : int.Parse(dr[MemoOutputFields.FileVerificationStatusID.ToString()].ToString()),
                FileVerificationStatusDescription = (dr[MemoOutputFields.FileVerificationStatusDescription.ToString()] is DBNull ? string.Empty : dr[MemoOutputFields.FileVerificationStatusDescription.ToString()].ToString()),
                S3FileNameOut= (dr[MemoOutputFields.S3FileNameOut.ToString()] is DBNull ? string.Empty : dr[MemoOutputFields.S3FileNameOut.ToString()].ToString())
            };
        }
    }

    public enum MemoOutputFields
    {
        ArchiveFileID,
        S3FileNameOut,
        FileTransferId,
        FileVerificationStatusID,
        FileVerificationStatusDescription,
        FileName
    }
    public enum WBSDetailOutputFields
    {
        WbsLevelOneNumber,
        WbsLevelOneDescription,
        ClientNumber,
        ClientName,
        ArchivePartner,
        ArchivePartnerAlias

    }
    public class WBSDetailsTransformer : BaseTransformer<WBSDetailsModel>
    {
        internal override WBSDetailsModel TransformElement(IDataReader dr, Func<IDataReader, WBSDetailsModel, WBSDetailsModel> bindExtraFields = null)
        {
            return new WBSDetailsModel
            {

                ClientName = (dr[WBSDetailOutputFields.ClientName.ToString()] is DBNull) ? string.Empty : dr[WBSDetailOutputFields.ClientName.ToString()].ToString(),
                ClientNumber = (dr[WBSDetailOutputFields.ClientNumber.ToString()] is DBNull) ? string.Empty : dr[WBSDetailOutputFields.ClientNumber.ToString()].ToString(),
                WBSLevelOne = (dr[WBSDetailOutputFields.WbsLevelOneNumber.ToString()] is DBNull) ? string.Empty : dr[WBSDetailOutputFields.WbsLevelOneNumber.ToString()].ToString(),
                WBSLevelOneDescription = (dr[WBSDetailOutputFields.WbsLevelOneDescription.ToString()] is DBNull) ? string.Empty : dr[WBSDetailOutputFields.WbsLevelOneDescription.ToString()].ToString(),
                PartnerName = (dr[WBSDetailOutputFields.ArchivePartner.ToString()] is DBNull) ? string.Empty : dr[WBSDetailOutputFields.ArchivePartner.ToString()].ToString(),
                PartnerAlias = (dr[WBSDetailOutputFields.ArchivePartnerAlias.ToString()] is DBNull) ? string.Empty : dr[WBSDetailOutputFields.ArchivePartnerAlias.ToString()].ToString()

            };
        }
    }
}
