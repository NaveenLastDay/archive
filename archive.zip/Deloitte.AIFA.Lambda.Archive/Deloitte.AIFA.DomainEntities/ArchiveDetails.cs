﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
    public class ArchiveDetails
    {
        public string EngagementDescription { get; set; }
        public string ArchiveDescription { get; set; }
        public string WBSNumber { get; set; }
        public string ArchiveNumber { get; set; }
        public string ClientName { get; set; }
        public DateTime PeriodEnd { get; set; }
        public string LegalHoldStatus { get; set; }
        public string ArchiveStatus { get; set; }
        public string CreatedBy { get; set; }
        public string LastSubmittedBy { get; set; }
        public DateTime EstimatedReleaseDate { get; set; }
        public DateTime PrivacyPeriodEndDate { get; set; }
        public string LastModifiedBy { get; set; }
        public string ResubmissionType { get; set; }
        public string IsApprovalEdited { get; set; }
    }

}
