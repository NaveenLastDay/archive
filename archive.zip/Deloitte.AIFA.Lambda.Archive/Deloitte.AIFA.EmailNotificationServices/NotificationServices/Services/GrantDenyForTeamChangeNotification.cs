﻿using Deloitte.AIFA.DomainEntities;
using Deloitte.AIFA.DomainEntities.EmailEntities;
using Deloitte.AIFA.EmailNotificationServices.NotificationEntities;
using Deloitte.AIFA.EmailNotificationServices.NotificationServices.Interfaces;
using Deloitte.AIFA.IRepositories;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.EmailNotificationServices.NotificationServices.Services
{
    public class GrantDenyForTeamChangeNotification : IGrantDenyForTeamChangeNotification
    {
        IUserRepository _userRepository;
        ILogger _logger;        
       
        public GrantDenyForTeamChangeNotification(                              
                                )        {
           
        }
     
       
        public BaseEmailEntity TeamChange_Grant_Notification(string argOperationType, string argOperationDescription, string argTemplateId, string ArchiveNumber, string userAlias, string Role, string TeamMemberName, string TeamChangedBy,string TeamMemberAlias)
        {
            BaseEmailEntity objTAR = new BaseEmailEntity();
            //Build Tag Values
            objTAR.MinimumTagValues = new Dictionary<string, string>();
            //ArchiveNumber for Subject
            objTAR.MinimumTagValues.Add(EmailPlaceholders.ArchiveNumber, ArchiveNumber);
            //Requestor FirstName for Body


            if (!string.IsNullOrEmpty(userAlias))
            {
                objTAR.MinimumTagValues.Add(EmailPlaceholders.RequestorFirstName, userAlias);
            }

            objTAR.MinimumTagValues.Add(EmailPlaceholders.Role, Role);
            objTAR.MinimumTagValues.Add(EmailPlaceholders.TeamMemberName, TeamMemberName);
            objTAR.MinimumTagValues.Add(EmailPlaceholders.TeamChangedBy, TeamChangedBy);
            objTAR.MinimumTagValues.Add(EmailPlaceholders.TeamMemberAlias, TeamMemberAlias);

            objTAR.MinimumTagValues.Add(EmailPlaceholders.SubmissionDate, DateTime.Now.Date.ToString());

            //Hyperlink to Access for Body
            objTAR.MinimumTagValues.Add(EmailPlaceholders.GrantDenyLink, "GrantDenyLink");


            objTAR.TemplateId = argTemplateId;
            objTAR.OperationDescription = argOperationDescription;
            objTAR.OperationType = argOperationType;

            return objTAR;
        }


        public BaseEmailEntity TeamChange_Deny_Notification(string argOperationType, string argOperationDescription, string argTemplateId, string ArchiveNumber, string userAlias, string Role, string TeamMemberName, string TeamChangedBy,string TeamMemberAlias)
        {
            BaseEmailEntity objTAR = new BaseEmailEntity();
            //Build Tag Values
            objTAR.MinimumTagValues = new Dictionary<string, string>();
            //ArchiveNumber for Subject
            objTAR.MinimumTagValues.Add(EmailPlaceholders.ArchiveNumber, ArchiveNumber);
            //Requestor FirstName for Body


            if (!string.IsNullOrEmpty(userAlias))
            {
                objTAR.MinimumTagValues.Add(EmailPlaceholders.RequestorFirstName, userAlias);
            }

            objTAR.MinimumTagValues.Add(EmailPlaceholders.Role, Role);
            objTAR.MinimumTagValues.Add(EmailPlaceholders.TeamMemberName, TeamMemberName);
            objTAR.MinimumTagValues.Add(EmailPlaceholders.TeamChangedBy, TeamChangedBy);
            objTAR.MinimumTagValues.Add(EmailPlaceholders.TeamMemberAlias, TeamMemberAlias);
            objTAR.MinimumTagValues.Add(EmailPlaceholders.SubmissionDate, DateTime.Now.Date.ToString());

            //Hyperlink to Access for Body
            objTAR.MinimumTagValues.Add(EmailPlaceholders.GrantDenyLink, "GrantDenyLink");


            objTAR.TemplateId = argTemplateId;
            objTAR.OperationDescription = argOperationDescription;
            objTAR.OperationType = argOperationType;

            return objTAR;
        }

       
    }
}
