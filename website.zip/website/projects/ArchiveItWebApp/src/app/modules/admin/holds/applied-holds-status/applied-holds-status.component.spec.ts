import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AppliedHoldsStatusComponent } from './applied-holds-status.component';

describe('AppliedHoldsStatusComponent', () => {
  let component: AppliedHoldsStatusComponent;
  let fixture: ComponentFixture<AppliedHoldsStatusComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AppliedHoldsStatusComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppliedHoldsStatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
