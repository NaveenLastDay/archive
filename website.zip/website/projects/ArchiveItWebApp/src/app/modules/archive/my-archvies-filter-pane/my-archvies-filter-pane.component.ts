import { Component, OnInit,Output, EventEmitter } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { ArchiveService } from '../../../services/archive.service';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { Router } from '@angular/router';
import { UserConfigSettingService } from '../../../guards/user-role-guard.service';

@Component({
  selector: 'app-my-archvies-filter-pane',
  templateUrl: './my-archvies-filter-pane.component.html',
  styleUrls: ['./my-archvies-filter-pane.component.css']
})
export class MyArchviesFilterPaneComponent implements OnInit {

  sortByEnum : any = MyArchivesSortBy;
  filterByEnum : any = MyArchivesFilterBy;
  filterBy: number = this.filterByEnum.FilterBy_ArchiveType;
  // sortBy: number = this.sortByEnum.SortBy_EmployeeLastArchive;
  sortBy: number = this.sortByEnum.SortBy_ArchiveName_Asc;
  filterText: string = "";
  employeeUniqueIdentifier: string;
  myArchivesFilterData: any[];
  userConfig: any;
  cancreate: boolean;

  @Output() sortOrderChangeEvent: EventEmitter<any> = new EventEmitter();
  @Output() filterChangeEvent: EventEmitter<any> = new EventEmitter();
 

  constructor(private router: Router, private archiveService: ArchiveService,private _userConfig: UserConfigSettingService,
    private adalSvc: MsAdalAngular6Service,private SpinnerService: NgxSpinnerService) { }

  ngOnInit() {
    this.employeeUniqueIdentifier = this.adalSvc.LoggedInUserEmail.split('@')[0];
    this.userConfig = this._userConfig.FetchLoggedInUser(this.employeeUniqueIdentifier);
    if(this.userConfig.value.IsManager||this.userConfig.value.IsPPD||this.userConfig.value.isAdmin){
      this.cancreate = true;
    }
    else{
      this.cancreate = false;
    }
    this.GetMyArchivesFilterData();
  }
  GetMyArchivesFilterData() {
    this.archiveService.GetMyArchivesFilterData(this.employeeUniqueIdentifier,this.filterBy).subscribe(
      data => {
        this.myArchivesFilterData = data ? data : [];
      }
    );
  }

  sortOrderChanged(event){
    //// debugger;
    this.sortBy = parseInt(event.target.value);
    this.sortOrderChangeEvent.emit({sortBy:this.sortBy})
  }
  onFilterTypeChanged(event) {
    //// debugger;
    this.filterBy = parseInt(event.target.value);
    this.GetMyArchivesFilterData();
  } 

  onFilterChangeEvent(event) {
    //// debugger;
    this.filterText = event.target.value;
    this.filterChangeEvent.emit({filterBy:this.filterBy, filterText:this.filterText})
  }

  redirectToCreatArchive(PageUrl: string) {
    this.router.navigate(["/" + PageUrl + ""]);
  }
}



export enum MyArchivesSortBy {
  SortBy_EmployeeLastArchive = 1,
  SortBy_ArchiveName_Asc = 2,
  SortBy_ArchiveName_Desc = 3,
  SortBy_ClientName_Asc = 4,
  SortBy_ClientName_Desc = 5,
  SortBy_PeriodEnd_Asc = 6,
  SortBy_PeriodEnd_Desc = 7,
  SortBy_ArchiveStatus_Asc = 8,
  SortBy_ArchiveStatus_Desc = 9,
  SortBy_WBSNumber_Asc = 10,
  SortBy_WBSNumber_Desc = 11,
  SortBy_ArchiveNumber_Asc = 12,
  SortBy_ArchiveNumber_Desc = 13,
}

export enum MyArchivesFilterBy {
  FilterBy_Business = 1,
  FilterBy_ClientName = 2,
  FilterBy_WBS = 3,
  FilterBy_Status = 4,
  FilterBy_ArchiveType = 5,
}
