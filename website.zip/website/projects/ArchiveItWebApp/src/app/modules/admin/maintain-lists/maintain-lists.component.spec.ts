import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MaintainlistsComponent } from './maintain-lists.component';

describe('MaintainlistsComponent', () => {
  let component: MaintainlistsComponent;
  let fixture: ComponentFixture<MaintainlistsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MaintainlistsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MaintainlistsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
