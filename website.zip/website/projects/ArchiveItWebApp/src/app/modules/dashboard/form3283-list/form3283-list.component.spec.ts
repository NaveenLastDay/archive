import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Form3283ListComponent } from './form3283-list.component';

describe('Form3283ListComponent', () => {
  let component: Form3283ListComponent;
  let fixture: ComponentFixture<Form3283ListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Form3283ListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Form3283ListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
