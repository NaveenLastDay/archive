import { Injectable } from '@angular/core';
import * as AWS from 'aws-sdk';
import { FileUploadEventService } from './fileupload.event.service';
import { FielUploadService } from '../../../services/fileupload.service';
import { NgxSpinnerService } from 'ngx-spinner';

@Injectable()
export class FileUploadProcessService {

    bucketName: string = "";
    chunkSize = 5 * 1024 * 1024;
    threadCount = 5;
    maxUploadPartRetries = 5;
    eTag = "";
    fileId: string = "";
    uploadFileObject: any;
    uploadFileName: string = "";
    uploadFileSize: number = 0;
    s3FileName: string = "";
    IsEMSFile: boolean;

    uploadStartDate = new Date();
    uploadRemaingTime = 0;
    uploadPercentage = 0;
    uploadStatus = null;
    uploadMessage = "";
    errorMessage = "";
    uploadStatusEnum: any;
    uploadId: string;
    s3object: any;
    partsArray = [];
    totalPartsTriggered = 0;
    totalParts = 0;
    sunits = "bytes";
    tunits = "";
    uploadTime = 0;
    isAbortedManually = false;

    //EMS Copy Object params
    isCopied: boolean = false;
    copyStatusArray = [];
    copyfilename: string = "";
    soucepath: string = "";
    destinationpath: string = "";
    lstEMSFiles: any;
    emsFileIndex: number;

    constructor(
        private _fuService: FielUploadService,
        private _fuEventService: FileUploadEventService,
        private _spinnerService: NgxSpinnerService,
        private _fileId: string,
        private _s3FileName: string,
        private _metaData: any

    ) {
        var self = this;

        self.fileId = self._metaData.fileId;
        self.uploadStatusEnum = {
            init: "init",
            started: "started",
            success: "success",
            failed: "failed",
            aborted: "aborted",
            deleted: "deleted",
            copied: "copied"
        };

        //this method is abort upload when cross icon is clicked
        self._fuEventService.abortUpload.subscribe(
            data => {
                if (self.s3FileName == data.fileName && self.uploadId == data.uploadId) {
                    self.uploadAbort(data.fileName, data.uploadId, data.stopSpinner);
                    self.isAbortedManually = true;
                }
            },
            err => {
                console.log(err);
            });

    }

    //this method is executed when we upload a file
    //_uploadfile :  upload file object
    uploadFile(_uploadfile: any, isas2?: boolean, asfrfilename?: string) {

        this._spinnerService.show();

        if (isas2) {
            this.uploadFileObject = _uploadfile;
            this.uploadFileName = asfrfilename;
        }
        else {
            this.uploadFileObject = _uploadfile.files[0];
            this.uploadFileName = this.uploadFileObject.name;
        }

        this.uploadFileSize = this.uploadFileObject.size;


        this.fileId = this._fileId;
        this.s3FileName = this._s3FileName;

        this.initiateUpload();
    }

    //Initiates the Upload Process
    //Get S3 Object and start Multipart upload
    initiateUpload = function () {

        var self = this;

        self.uploadStartDate = new Date();
        self.uploadPercentage = 0;
        self.uploadTime = 0;
        self.totalParts = 0;
        self.uploadMessage = "";
        self.totalParts = Math.ceil(self.uploadFileObject.size / self.chunkSize);

        console.log("uploadFileName: " + self.uploadFileName);
        console.log("Total parts: " + self.totalParts);

        self.getS3Object(function (s3obj) {
            self.s3object = s3obj;
            self.uploadStatus = self.uploadStatusEnum.init;
            self.multiPartUpload();
        });

    }

    //Creates multipart upload and gets the Upload Id in response
    multiPartUpload = function () {
        var self = this;

        var params = {
            Bucket: self.bucketName,
            Key: self.s3FileName,
            Metadata: self._metaData
        }

        self.s3object.createMultipartUpload(params, function (err, data) {

            if (err) {
                console.log("Error in createMultipartUpload:");
                console.log(err);
                self.uploadStatus = self.uploadStatusEnum.failed;
                self.uploadMessage = "Upload Failed, please try again";
                self.errorMessage = err.message;
                self.updateUploadFileStatusArray(true);
                self._spinnerService.hide();
            } else {

                if (data.UploadId) {
                    self.uploadStatus = self.uploadStatusEnum.started;
                    self.updateUploadFileStatusArray();
                    self._spinnerService.hide();
                }

                self.uploadId = data.UploadId;
                self.threadCount = self.totalParts <= self.threadCount ? self.totalParts : self.threadCount;

                //Triggers parallel multipart upload, no of threads deponds on threadCount
                for (var i = 0; i <= self.threadCount; i++) {
                    self.uploadMultipleParts(i, 0);
                }

            }

        });

    }

    //This method uploads each chunk and get ETag of each part and Save in array along with part number
    //This method is triggered for each chunk till chunk size > 0
    uploadMultipleParts = function (partIndex: number, retryCount: number) {

        var self = this;
        var offsett = partIndex * self.chunkSize;
        let partChunk = self.uploadFileObject.slice(offsett, offsett + self.chunkSize);

        if (partChunk.size > 0) {

            var params = {
                Bucket: self.bucketName,
                Key: self.s3FileName,
                UploadId: self.uploadId,
                PartNumber: partIndex + 1
            }

            if (retryCount == 0) {
                self.totalPartsTriggered = self.totalPartsTriggered + 1;
            }

            self.s3object.getSignedUrl('uploadPart', params, function (urlerr, url) {

                if (urlerr) {
                    console.log(urlerr);
                }
                else {

                    self._fuService.uploadPartUsingSignedURL(url, partIndex, partChunk, function (err, prtIndex, eTag) {

                        if (self.uploadStatus !== self.uploadStatusEnum.started) return;

                        if (err) {

                            if (retryCount <= self.maxUploadPartRetries) {
                                console.log("Retrying failed part: " + (partIndex + 1));
                                self.uploadMultipleParts(prtIndex, retryCount + 1);
                            } else {
                                console.log("Failed to upload part: " + (prtIndex + 1) + ", retryCount: " + retryCount);
                                self.errorMessage = err.message;
                                self.uploadAbort(params.Key, params.UploadId);
                            }
                        }
                        else {

                            if (self.partsArray.findIndex(obj => obj.PartNumber == params.PartNumber) == -1) {
                                self.partsArray.push({
                                    ETag: eTag,
                                    PartNumber: params.PartNumber
                                });
                            }

                            if (self.totalPartsTriggered < self.totalParts) {
                                self.uploadMultipleParts(self.totalPartsTriggered, 0);
                            }
                            else if (self.partsArray.length == self.totalParts) {
                                self.completeMultiPartUpload();
                            }

                            if (self.uploadStatus == self.uploadStatusEnum.started) {

                                var endDate = new Date();
                                var seconds = (endDate.getTime() - self.uploadStartDate.getTime()) / 1000;
                                var remaingParts = self.totalParts - self.partsArray.length

                                self.uploadRemaingTime = (seconds * remaingParts) / self.partsArray.length;
                                self.uploadPercentage = Math.ceil((self.partsArray.length / self.totalParts) * 100);
                                self.uploadPercentage = self.uploadPercentage;

                                self.updateUploadFileStatusArray();
                            }

                        }
                    });
                }
            });

        }

    }

    //Complete multipart upload using upload Id and parts array and return ETag of finally combined file
    completeMultiPartUpload = function () {

        var self = this;

        self.partsArray = self.partsArray.sort(function (p1, p2) {
            if (p1.PartNumber < p2.PartNumber) return -1;
            if (p1.PartNumber > p2.PartNumber) return 1;
            return 0;
        });

        let params = {
            Bucket: self.bucketName,
            Key: self.s3FileName,
            UploadId: self.uploadId,
            MultipartUpload: {
                Parts: self.partsArray
            }
        };

        self.s3object.completeMultipartUpload(params, function (err, data) {

            if (err) {
                console.log("error: completeMultipartUpload");
                console.log(err.message);

                self.uploadStatus = self.uploadStatusEnum.failed;
                self.uploadMessage = "Upload Failed, please try again";
                self.errorMessage = err.message;
                self.uploadAbort(params.Key, params.UploadId);
                self.updateUploadFileStatusArray(true);
            }
            else {
                var uploadEndDate = new Date();
                self.uploadTime = (uploadEndDate.getTime() - self.uploadStartDate.getTime()) / 1000;

                self.eTag = data.ETag;
                self.uploadStatus = self.uploadStatusEnum.success;
                self.uploadMessage = "Verification in progress...";
                self.partsArray = [];
                self.totalParts = 0;
                self.totalPartsTriggered = 0;

                console.log(self.uploadFileName + ": " + data.ETag);
                console.log("uploadTime: " + self.uploadTime);

                self.updateUploadFileStatusArray(true);
            }
        });
    }

    //This method is used to get upload file status, percentage and update in fileArray
    //This fileArray is used in UI to show progress bar
    updateUploadFileStatusArray(isfinal?: boolean) {
        debugger;
        var self = this;
        var fileObjIndex = self._fuEventService.fileArray.findIndex(x => x.fileId == self.fileId);
        if (fileObjIndex >= 0) {
            self._fuEventService.fileArray[fileObjIndex].uploadPercentage = self.uploadPercentage;
            self._fuEventService.fileArray[fileObjIndex].uploadStatus = self.uploadStatus;
            self._fuEventService.fileArray[fileObjIndex].uploadMessage = self.uploadMessage;
            self._fuEventService.fileArray[fileObjIndex].errorMessage = self.errorMessage;
            self._fuEventService.fileArray[fileObjIndex].fileName = self.uploadFileName;
            self._fuEventService.fileArray[fileObjIndex].s3FileName = self.s3FileName;
            self._fuEventService.fileArray[fileObjIndex].uploadRemaingTime = self.uploadRemaingTime;
            self._fuEventService.fileArray[fileObjIndex].sunits = self.sunits
            self._fuEventService.fileArray[fileObjIndex].tunits = self.tunits;
            self._fuEventService.fileArray[fileObjIndex].fileSize = self.uploadFileSize;
            self._fuEventService.fileArray[fileObjIndex].eTag = self.eTag;
            self._fuEventService.fileArray[fileObjIndex].uploadId = self.uploadId;
            self._fuEventService.fileArray[fileObjIndex].metaData = self._metaData;

        }
        self._fuEventService.onupdateUploadStatus(self._fuEventService.fileArray);

        if (isfinal) {

            var dismissedFileId = "";
            if (self._fuEventService.fileArray[fileObjIndex].uploadStatus == "dismissed") {
                self._fuEventService.fileArray[fileObjIndex].uploadStatus = self.uploadStatusEnum.aborted;
                dismissedFileId = self._fuEventService.fileArray[fileObjIndex].fileId;
            }

            self.displaylog(self._fuEventService.fileArray[fileObjIndex]);

            if (!self.IsEMSFile) {
                self._fuEventService.ongetfileUploadStatus(self._fuEventService.fileArray[fileObjIndex]);
            }


            self._fuEventService.fileArray = self._fuEventService.fileArray.filter(
                x => x.fileId != dismissedFileId
            );
        }
    }

    //This method is used to abort the file upload using Upload Id, file name and bucket name
    uploadAbort(fileName, uploadId, stopSpinner) {

        var self = this;

        if (!stopSpinner) {
            self._spinnerService.show();
        }

        console.log("Aborting file: " + fileName);

        self.getS3Object(function (s3obj) {

            var params = {
                Bucket: self.bucketName,
                Key: fileName,
                UploadId: uploadId
            };

            s3obj.abortMultipartUpload(params, function (err, data) {

                console.log("Aborted upload for file: " + fileName);

                if (err) {
                    console.log("Error in aborting:");
                    console.log(err);
                    self.errorMessage = err.message;
                    self.uploadStatus = self.uploadStatusEnum.failed;
                    self.uploadMessage = "Upload Failed, please try again";
                }
                else {
                    if (self.isAbortedManually) {
                        self.uploadStatus = self.uploadStatusEnum.aborted;
                        self.uploadMessage = "Upload cancelled";
                    } else {
                        self.uploadStatus = self.uploadStatusEnum.failed;
                        self.uploadMessage = "Something went wrong, please try again";
                    }
                }
                if (stopSpinner) {
                    self.uploadStatus = "dismissed";
                }
                self.updateUploadFileStatusArray(true);

            });

        });
    }

    //This method is used to delete file from S3 bucket using upload file name
    deleteFile(fileName: string, callback) {

        var self = this;

        self.getS3Object(function (s3obj) {

            var params = { Bucket: self.bucketName, Key: fileName };

            s3obj.deleteObject(params, function (err, data) {

                var isDeleted = false;

                if (err) {
                    console.log("Error in deleting object:");
                    console.log(err);
                    self.uploadStatus = self.uploadStatusEnum.failed;
                    self.uploadMessage = "Something went wrong, please try again";
                    self.errorMessage = err.message;
                    isDeleted = false;
                }
                else {
                    self.uploadPercentage = 0;
                    self.uploadStatus = self.uploadStatusEnum.deleted;
                    self.uploadMessage = self.uploadFileName + " deleted successfully.";
                    isDeleted = true;
                }
                callback(isDeleted);
            });
        });
    }

    CopyFiletoS3EMS(engFilePath: string, fileName: string,deletedCallback:any) {
        var self = this;
        var sourcekey = engFilePath;
        var S3FileName;
        if(String(sourcekey.toUpperCase()).split('/')[1]=="ENGAGEMENT"){
          S3FileName = sourcekey.split('/')[3].split("_")[1];
        }
        else{
            S3FileName = sourcekey.split('/')[2];
        }
        
        var destinationkey = "Audit/EMS/" + S3FileName;
        var isDeleted=false;

        self.getS3Object(function (s3obj) {

            const copyemsparams = {
                Bucket: self.bucketName,
                CopySource: encodeURI(self.bucketName + "/" + sourcekey),
                Key: destinationkey 
            };
            // const copyparams = {
            //     Bucket: self.bucketName,
            //     CopySource: encodeURI(self.bucketName + "/" + sourcekey),
            //     Key: destinationkey
            // };
            
        s3obj.copyObject(copyemsparams, function (err, data) {

                if (err) {
                    console.log("Error in copying object:");
                    console.log(err);
                    deletedCallback(isDeleted);
                }
                else {
                    //Database update in Filetransfer
                    //UpdateS3PathsAtDeleteEms(ArchiveFileId,sourcekey, destinationkey + fileName);
                    isDeleted=true;
                    deletedCallback(isDeleted);
                }
            });
        });
    }

    //This method is used to open file from S3 bucket
    OpenDocument(s3fileName: string) {
        var self = this;

        self.getS3Object(function (s3obj) {
            var params = {
                Bucket: self.bucketName,
                Key: s3fileName,
                Expires: 3600
            };
            s3obj.getSignedUrl('getObject', params, function (err, url) {
                if (err) {
                    self.errorMessage = err.message;
                }
                else {
                    console.log("======(getSignedUrl)=======");
                    console.log("self.bucketName    : " + self.bucketName);
                    console.log(url);
                    window.open(url + '#page=' + 1, '_blank', '', true);
                }
            });
        });
    };

    //This method is used to download file from S3 bucket
    downloadFile(s3fileName: string, fileName: string) {
        this._fuEventService.guardflag=1;
        debugger;
        this._spinnerService.show();
        var self = this; 

        self.getS3Object(function (s3obj) {


            if(['DARC', 'DA3RC', 'DA4RC', 'DA5RC'].includes(String(s3fileName.toUpperCase()).split('.').pop()))
            {
                var emsFileName = s3fileName.split("/", 4)[3];
                var filename = emsFileName.indexOf('_') > -1 ? String(emsFileName).split('_').pop() : String(emsFileName);
                var params = {
                    Bucket: self.bucketName,
                    Key: s3fileName,
                    Expires: 3600,
                    ResponseContentDisposition: 'attachment; filename ="' + filename + '"'
                };
            }
            else{
                var params = {
                    Bucket: self.bucketName,
                    Key: s3fileName,
                    Expires: 3600,
                    ResponseContentDisposition: 'attachment; filename ="' + fileName + '"'
                };
            }


       


            s3obj.getSignedUrl('getObject', params, function (err, url) {
                if (err) {
                    self.errorMessage = err.message;
                }

                if (['pdf', 'jpeg', 'jpg', 'png', 'mp4'].includes(String(fileName).split('.').pop())) {

                    const xhr = new XMLHttpRequest();
                    xhr.responseType = 'blob';

                    xhr.onload = (event) => {
                        /* Create a new Blob object using the response
                        *  data of the onload object.
                        */
                        const blob = new Blob([xhr.response], { type: 'application/octet-stream' });
                        const a: any = document.createElement('a');
                        a.style = 'display: none';
                        document.body.appendChild(a);
                        const url = window.URL.createObjectURL(blob);
                        a.href = url;
                        a.download = fileName;
                        self._spinnerService.hide();
                        a.click();
                        window.URL.revokeObjectURL(url);
                    };
                    xhr.open('GET', url);
                    xhr.send();
                }
                else {
                    self._spinnerService.hide();
                    const atag: any = document.createElement('a');
                    atag.href = url;
                    atag.click();
                }
            });

        });
    };

    //This method get file upload configs and provide to cognito to get Temporary token
    //Creates S3 object and returned where ever this method is called
    getS3Object = function (callback: any) {

        var token = sessionStorage.getItem('adalToken');
        this._fuService.getFileUploadConfig().subscribe(
            (response) => {
                AWS.config.region = response.region
                AWS.config.credentials = new AWS.CognitoIdentityCredentials({
                    IdentityPoolId:  response.identityPoolId,  
                    Logins: {
                        'sts.windows.net/36da45f1-dd2c-4d1f-af13-5abe46b99921': token
                    }
                });

                const s3obj = new AWS.S3({
                    apiVersion: response.apiVersion,
                    signatureVersion: response.signatureVersion,
                    params: {
                        Bucket: response.bucketName,
                        SSEKMSKeyId: response.kmsKey,
                        ServerSideEncryption: response.serverSideEncryption
                    }
                });

                this.bucketName = response.bucketName;
                callback(s3obj);
            },
            (err) => {
                console.log(err);
            });
    }

    displaylog(fileArrayObject: any) {
        console.log("==========Upload Details==================");
        console.log("Start Date: ");
        console.log(this.uploadStartDate);
        console.log(fileArrayObject);

    }

    copyS3EMSObject = function (filename, soucekey, destinationkey, lstEMSFiles, index,ArchiveFileId) {
        var self = this;

        self._spinnerService.hide();
        if (self.uploadStatus == self.uploadStatusEnum.started) {

            var endDate = new Date();
            var seconds = (endDate.getTime() - self.uploadStartDate.getTime()) / 1000;
            var remaingParts = self.totalParts - (index + 1)

            self.uploadRemaingTime = (seconds * remaingParts) / (index + 1);
            self.uploadPercentage = Math.ceil(((index + 1) / self.totalParts) * 100);
            debugger;
            //self.uploadPercentage = 50;
            console.log(self.uploadPercentage);
            self.updateUploadFileStatusArray();
        }
        console.log("EMS Archive File ID : " + ArchiveFileId);
        console.log("EMS FileTransferId : " + self._metaData.FileTransferId.toString());
        const copyparams = {
            Bucket: self.bucketName,
            CopySource: encodeURI(self.bucketName + "/" + soucekey + filename),
            Key: destinationkey + ArchiveFileId +"_" + filename,
            Metadata: {
                'archivefileid': ArchiveFileId,
                'filetransferid': self._metaData.FileTransferId.toString()
              },
            MetadataDirective: 'REPLACE'
        };

        self.s3object.copyObject(copyparams, function (err, data) {

            if (err) {
                console.log("Error in copying object:");
                console.log(err);
                self.fileName = filename;
                self.uploadFileName = filename;
                self.s3FileName = soucekey + filename;
                self.uploadStatus = self.uploadStatusEnum.failed;
                self.uploadMessage = "Something went wrong, please try again";
                self.errorMessage = err.message;
                self.isCopied = false;
                lstEMSFiles[index].isCopied = self.isCopied;
                lstEMSFiles[index].failedDescription = self.errorMessage;
                self.updateUploadFileStatusArray(true);
                self.copyStatusArray.push({ "Filename": filename, "IsCopied": self.isCopied, "index": index });
                if (self.copyStatusArray != undefined && self.copyStatusArray != null) {
                    if (self.copyStatusArray.length == lstEMSFiles.length)
                        self.updateCopyFileStatus();
                }
            }
            else {
                //self.uploadPercentage = 100;
                // var uploadEndDate = new Date();
                // self.uploadTime = (uploadEndDate.getTime() - self.uploadStartDate.getTime()) / 1000;
                self.fileName = filename;
                self.uploadFileName = filename;
                self.eTag = data;
                self.uploadStatus = self.uploadStatusEnum.success;
                self.uploadMessage = "Verification in progress...";
                self.s3FileName = destinationkey + filename;
                self.isCopied = true;
                lstEMSFiles[index].isCopied = self.isCopied;
                lstEMSFiles[index].failedDescription = "";
                self.updateUploadFileStatusArray(true);
                self.copyStatusArray.push({ "Filename": filename, "IsCopied": self.isCopied, "index": index });
                if (self.copyStatusArray != undefined && self.copyStatusArray != null) {
                    if (self.copyStatusArray.length == lstEMSFiles.length)
                        self.updateCopyFileStatus();
                }
            }
        });
    }

    updateCopyFileStatus = function () {
        var self = this;
        console.log("emsFileIndex" + self.emsFileIndex);
        if ((self.lstEMSFiles.length - 1) == self.emsFileIndex) {
            self._fuEventService.lstEMSFiles = self.lstEMSFiles;
            /*self._fuEventService.onUpdateMoveEMSFileStatus(self._fuEventService.lstEMSFiles);*/
        }
    }


    initiateCopy = function () {
        debugger;
        var self = this;

        console.log("copyFileName: " + self.copyfilename);



        self.getS3Object(function (s3obj) {

            self.s3object = s3obj;

            const todaysDate = new Date()
            const currentYear = todaysDate.getFullYear();

            for (var emsIndex = 0; emsIndex < self.lstEMSFiles.length; emsIndex++) {

                //allowing multiple uploads
                //setTimeout(() => { }, 3000);

                self.uploadStatus = self.uploadStatusEnum.started;
                self.uploadStartDate = new Date();
                self.uploadPercentage = 0;
                self.uploadTime = 0;
                self.totalParts = 0;
                self.uploadMessage = "";
                self.totalParts = self.lstEMSFiles.length;

                var emsInfo = self.lstEMSFiles[emsIndex];

                var SourceKey = emsInfo.s3EmsSourcePath.replace('{Year}/', '');
                self.lstEMSFiles[emsIndex].s3EmsSourcePath = SourceKey;
                var DestinationKey = emsInfo.s3EmsDestinationPath.replace('{Year}', currentYear);
                self.lstEMSFiles[emsIndex].s3EmsDestinationPath = DestinationKey;

                self.copyfilename = emsInfo.emsFileName;
                self.soucepath = SourceKey;
                self.destinationpath = DestinationKey;
                self.lstEMSFiles = self.lstEMSFiles;
                self.emsFileIndex = emsIndex;
                
                self.fileId = "FileId-0";
                self.uploadFileName = emsInfo.emsFileName;
                self.uploadFileSize = self.lstEMSFiles[emsIndex].emsFileSize;
                self.module = "workingpaper";
                self.fileName = emsInfo.emsFileName;
                self.s3FileName = SourceKey + emsInfo.emsFileName


                self._fuEventService.fileArray.push({
                    module: self.module,
                    fileId: self.fileId,
                    fileName: emsInfo.emsFileName,
                    s3FileName: SourceKey + emsInfo.emsFileName,
                    fileSize: self.lstEMSFiles[emsIndex].emsFileSize,
                    eTag: "",
                    uploadId: "",
                    uploadPercentage: "",
                    uploadStatus: "copy",
                    uploadMessage: "",
                    errorMessage: "",
                    uploadRemaingTime: "",
                    sunits: "",
                    tunits: "",
                    metaData: {}
                });


                self._metaData.ArchiveFileId = self.lstEMSFiles[emsIndex].archiveFileId.toString();
                self._metaData.FileTransferId = self.lstEMSFiles[emsIndex].fileTransferId.toString();

                self.updateUploadFileStatusArray();
                self.copyS3EMSObject(self.copyfilename,self.soucepath,self.destinationpath,self.lstEMSFiles,emsIndex,self._metaData.ArchiveFileId);
            }
        });

    }

    copyEMSFiles = (lstEMSFiles) => {
        var self = this;
        this._spinnerService.show();
        self.lstEMSFiles = lstEMSFiles;
        self.IsEMSFile = true;
        self.initiateCopy();
    }
}
