﻿using Deloitte.AIFA.DataModels;
using Deloitte.AIFA.DomainEntities;
using Deloitte.AIFA.IRepositories;
using Deloitte.AIFA.Repositories.Transformers;
using Microsoft.Extensions.Caching.Memory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Deloitte.AIFA.Repositories.Repository
{
    public class ArchiveFlowRepository : BaseRepository<ArchiveFlowField>, IArchiveFlowRepository
    {
        IMemoryCache _cache;
        public ArchiveFlowRepository(IMemoryCache cache) : base(cache)
        {
            _cache = cache;
        }

        public string CreateOrUpdateArchiveActions(ArchiveFlowDetails aFlowdetails)
        {
            try
            {

                var parameters = Builder.Bind(ArchiveFlowFieldParameter.ArchiveNumber).On(aFlowdetails.ArchiveNumber)
                                .Bind(ArchiveFlowFieldParameter.ArchiveSectionId).On(aFlowdetails.ArchiveSectionId)
                                .Bind(ArchiveFlowFieldParameter.ActionTypeId).On(aFlowdetails.ActionTypeId)
                                .Bind(ArchiveFlowFieldParameter.Comments).On(aFlowdetails.Comments)
                                .Bind(ArchiveFlowFieldParameter.CreatedBy).On(aFlowdetails.CreatedBy).Build();

                DbHelper.ExecuteNonQuery(
                   "pub_AIFA_InsertOrUpdateArchiveActions",
                   parameters);


                return "success";
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<ArchiveFlowDetails> GetResubmissionReasonsforArchive(string ArchiveNumber)
        {
            try
            {
                var parameters = Builder.Bind(ArchiveFlowFieldParameter.ArchiveNumber).On(ArchiveNumber)
                                        .Build();
                var result = DbHelper.ExecuteReader(
                    "Pub_AIFA_GetResubmissionReasonsforallSections",
                    parameters,
                        dr => new GetResubmissionReasonsTransformer().Transform(dr).ToList());

                return _mapper.Map<List<ArchiveFlowDetailsModel>, List<ArchiveFlowDetails>>(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public ArchiveFlowDetails GetArchiveSectionComments(string ArchiveNumber, int sectionId, int ActionTypeId)
        {
            try
            {
                var parameters = Builder.Bind(ArchiveFlowFieldParameter.ArchiveNumber).On(ArchiveNumber)
                                        .Bind(ArchiveFlowFieldParameter.ArchiveSectionId).On(sectionId)
                                        .Bind(ArchiveFlowFieldParameter.ActionTypeId).On(ActionTypeId)
                                        .Build();
                var result = DbHelper.ExecuteReader(
                    "pub_AIFA_GetSectionComments",
                    parameters,
                        dr => new ArchiveFlowTransformer().Transform(dr).ToList());

                return _mapper.Map<ArchiveFlowDetailsModel, ArchiveFlowDetails>(result.FirstOrDefault());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}