﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
    public class RetentionExceptionStatus
    {
        public string retentiondescription { get; set; }
        public string createdBy { get; set; }
    }
}
