﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
    public class MyArchiveDetails
    {
        #region Commented        
        //public int ArchiveID { get; set; }
        //public string ArchiveNumber { get; set; }
        //public string WBSLevelOneNumber { get; set; }
        //public string EngagementTypeDescription { get; set; }
        //public DateTime ArchiveDueDate { get; set; }
        //public int SubmissionStatusID { get; set; }
        //public string SubmissionStatus { get; set; }
        //public int ReportingEntityID { get; set; }
        //public string ReportingEntity { get; set; }
        //public int EmployeeRoleID { get; set; }
        //public int EmployeeRoleDisplayOrder { get; set; }
        //public int EmployeePersonnelNumber { get; set; }
        //public int EmployeeRoleRoleID { get; set; }
        //public string RoleName { get; set; }
        //public string FirstName { get; set; }
        //public string LastName { get; set; }
        #endregion Commented

        public int ArchiveID { get; set; }
        public string WBSLevelOneNumber { get; set; }
        public string EngagementTypeDescription { get; set; }
        public DateTime ArchiveDueDate { get; set; }
        public DateTime EstimatedIssuanceReportDate { get; set; }
        public bool IsResubmissionInProgress { get; set; }
        public string ReportingEntity { get; set; }
        public string ArchivePartner { get; set; }
        public string ArchvieManger { get; set; }
        public string ArchvieFieldSenior { get; set; }
        public string AddArchvieFieldSenior { get; set; }
        public string Description { get; set; }
    }
}
