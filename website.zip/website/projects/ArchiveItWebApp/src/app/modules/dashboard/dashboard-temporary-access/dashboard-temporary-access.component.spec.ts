import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DashboardTemporaryAccessComponent } from './dashboard-temporary-access.component';

describe('DashboardTemporaryAccessComponent', () => {
  let component: DashboardTemporaryAccessComponent;
  let fixture: ComponentFixture<DashboardTemporaryAccessComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DashboardTemporaryAccessComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DashboardTemporaryAccessComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
