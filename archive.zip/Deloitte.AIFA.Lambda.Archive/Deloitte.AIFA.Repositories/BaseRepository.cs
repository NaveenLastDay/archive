﻿using AutoMapper;
using Deloitte.AIFA.Common;
using Deloitte.AIFA.DBHelper;
using Deloitte.AIFA.DBHelper.Interfaces;
using Microsoft.Extensions.Caching.Memory;
using Deloitte.AIFA.Repositories.Automapper;
using Deloitte.AIFA.DomainServices.Common;

namespace Deloitte.AIFA.Repositories
{
    public abstract class BaseRepository<TCreateParameter> where TCreateParameter : struct
    {
        IMemoryCache _cache;
        protected IMapper _mapper;
        protected IDataAccessHelper DbHelper { get; set; }
        protected IDataAccessHelper DbReaderHelper { get; set; }

        protected MySqlCreateParameterBuilder<TCreateParameter> Builder { get; set; }
        public BaseRepository(IMemoryCache cache)
        {
            _cache = cache;
            _mapper = ConfigureMapping.InitializeMapping();
            if(Temp.IsMigrationTest)
            {
                InitializeDBForDev2();
            }
            else
            {
                InitializeDB();
            }
        }

        private void InitializeDB()
        {
           // var dbConnectionString = _cache.Get<string>(Constants.DBConnectionstring);
            var dbConnectionString = _cache.Get<string>(Constants.DBConnectionstring);
            DbHelper = new DataAccessHelper(dbConnectionString);

            var dbConnectionStringReader = _cache.Get<string>(Constants.DBConnectionstringReader);
            DbReaderHelper = new DataAccessHelper(dbConnectionStringReader);

            Builder = new MySqlCreateParameterBuilder<TCreateParameter>();
        }

        public void InitializeDBForDev2()
        {
            var DBConnectionString = "Server=aifa-dasmysqlcluster-stg.cluster-cusapzv7g1nx.us-east-1.rds.amazonaws.com;Port=3306;database = AIFA_Migration; User Id = mysql1_aifa_user;Password = GA4dO9rWjhjlmARCBNaA;sslmode=none;convert zero datetime=True";
            DbHelper = new DataAccessHelper(DBConnectionString);
            Builder = new MySqlCreateParameterBuilder<TCreateParameter>();
        }

        public MySqlCreateParameterBuilder<TCreateParameter> GetBuilderInstance()
        {
            return new MySqlCreateParameterBuilder<TCreateParameter>();
        }
    }
}
