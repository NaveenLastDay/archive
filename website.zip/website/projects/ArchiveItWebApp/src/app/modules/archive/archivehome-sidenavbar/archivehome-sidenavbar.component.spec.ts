import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ArchivehomeSidenavbarComponent } from './archivehome-sidenavbar.component';

describe('ArchivehomeSidenavbarComponent', () => {
  let component: ArchivehomeSidenavbarComponent;
  let fixture: ComponentFixture<ArchivehomeSidenavbarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ArchivehomeSidenavbarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ArchivehomeSidenavbarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
