import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { ArchiveService } from '../../../services/archive.service';
// import { NgxSpinnerService } from 'ngx-spinner';
import { NotifierService, NotifierModule, NotifierOptions } from "angular-notifier";
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { TrimSummaryLengthPipe } from '../../shared/Pipes/trim-summary-length.pipe';
import { HomePageService } from '../../../services/homepage.service';
import { SharedService } from '../../../services/shared.service';


@Component({
  selector: 'app-archives-pending-submission',
  templateUrl: './archives-pending-submission.component.html',
  styleUrls: ['./archives-pending-submission.component.css']
})
export class ArchivesPendingSubmissionComponent implements OnInit {
  totalArchivesAssigned: number = 0;
  currentUrl: string;
  employeeUniqueIdentifier: string;
  filterText: string = "";
  displayingRecordsFrom: number = 0;
  displayingRecordsTo: number = 0;
  userConfig: any;
  myArchives: any[];
  currentPageNumber: number = 1;
  totalArchives: number = 0;
  pageSize: number = 10;
  archiveNumber: string = '';
  eventType: string = '';
  hoverIndex: number = -1;
  pageCount: number = 10;
  appendArchiveToGrid: boolean = false;
  archives: any[];
  pageArray = Array();
  archiveAccessRequestsForApprovalData: any;
  archiveIDForChild: any;
  exportExcelData: any;
  archiveAccessRequestID: string;
  countForAccessRequests: any;
  headerColumns: any = [];
  redColor: any;
  orangeColor: any;
  yellowColor: any;
  pendingSubData: any;


  constructor(private archiveService: ArchiveService,private homePageService: HomePageService, private adalSvc: MsAdalAngular6Service,
    private sharedService: SharedService, private notifier: NotifierService, private router: Router) {
      // this.SpinnerService.show();
  }

  ngOnInit() {
    this.employeeUniqueIdentifier = this.adalSvc.LoggedInUserEmail.split('@')[0];   
    this.getArchives();
    this.employeeUniqueIdentifier = this.adalSvc.LoggedInUserEmail.split('@')[0];
    // this.homePageService.GetArchiveAccessRequestCountForApproval(this.employeeUniqueIdentifier).subscribe((data) => {
    //   this.countForAccessRequests = data;
    //   if( this.countForAccessRequests.length == 0) {
    //     this.disableBack();
    //   }
    // });
  }

  showArchiveDetails(archiveAccessRequestID, index) {
    if (this.archiveAccessRequestID == archiveAccessRequestID) {
      this.archiveAccessRequestID = '';
    }
    else {
      this.archiveAccessRequestID = archiveAccessRequestID;
    }
  }
  getArchives() {
    this.archiveService.GetPendingSubmission(this.currentPageNumber, this.pageSize).subscribe(
      data => {
        this.pendingSubData = data;
        // this.SpinnerService.hide();
        // this.redColor = data.filter((ele) => ele.due == 'Red');
        // this.orangeColor = data.filter((ele) => ele.due == 'Orange');
        // this.yellowColor = data.filter((ele) => ele.due == 'Yellow');
        if(this.pendingSubData.length > 0) {
        this.redColor = data[0].countRed;
        this.orangeColor = data[0].countOrange;
        this.yellowColor = data[0].countYellow;
      }
        if (this.appendArchiveToGrid && data) {
          this.archives = this.archives.concat(data);
        }
        else {
          this.archives = data ? data : [];
        }
        if(this.pendingSubData.length > 0) {
        this.totalArchives = this.archives[0]["count"];
        }
      }
    );
  }
    disableBack() {
    window.history.forward();
  }
  exportToExcel() {
    // this.SpinnerService.show();
            let columns = [
          'Archive #',
          'Client',
          'Archive Name',
          'Period End',
          'WBS #',
          'EDCD',
          'Archive Status',
          'Engagement Type',
          'RDCD',
          'Is Resubmission in Progress ?',
          'Archive Description',
          'Entity associated with archive',
          'Professional Standards Applied',
          'Reporting Entity',
          'Archive Partner',
          'Archive Manager',
          'Archive Field Senior',
          'Additional Archive Field Senior',
      ];
    this.archiveService.pendingSubmissionExportToExcel(0, this.totalArchives).subscribe((data) => {
          data.forEach(elm=> {
        delete elm.count;
        delete elm.rowNumber;
        delete elm.due;
        delete elm.countOrange;
        delete elm.countRed;
        delete elm.countYellow;
        delete elm.isArchiveCompleted;
      });
      // this.SpinnerService.hide();
      var result = data.map(o => Object.keys(o).map(k => o[k]));
      if (data && data.length) {
        this.sharedService.generateExcel("Archives pending submission", "Archives pending submission", columns,result);
      }
     },
     error => {
       console.log('Exception occured ' + JSON.stringify(error));
      //  this.SpinnerService.hide();
     });
   
  } 
  clearPageCount() {
    this.currentPageNumber = 1;
    this.pageCount = 1;
    this.pageArray = Array();
  }
  // accessArchive(archiveNumber: string) {
  //   this.router.navigate(['/archive/myarchives', archiveNumber]);
  // }
  redirectToAppropriatePage(archiveNumber:string, wbsNumber?:string, isArchiveCompleted?:any){
    localStorage.setItem('WBS_Number', wbsNumber);
    localStorage.setItem('isAutoCreatedArchive', isArchiveCompleted);
    if(isArchiveCompleted != 0)
    this.router.navigate(["/archive/myarchives/"+ archiveNumber]);
    else{
    this.router.navigate(["/archive/myarchives/"+ archiveNumber +"/createarchive/"+ wbsNumber]);
    }
  }
  updateGridData(event) {
    this.appendArchiveToGrid = event.isLoadMoreClicked;
    this.currentPageNumber = event.pageNumber;
    this.getArchives();
  }
  archiveID(event) {
    this.archiveIDForChild = event;
    console.log('from child', event);
  }
}

