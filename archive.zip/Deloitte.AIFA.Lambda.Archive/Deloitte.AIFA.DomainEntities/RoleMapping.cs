﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
   public class RoleMapping
    {
        public int RoleId { get; set; }

        public string RoleDescription { get; set; }

        public IList<string> ArchivePermissions { get; set; }

       
    }
}
