import { TestBed } from '@angular/core/testing';

import { ArchiveHomeService } from './archive-home.service';

describe('ArchiveHomeService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ArchiveHomeService = TestBed.get(ArchiveHomeService);
    expect(service).toBeTruthy();
  });
});
