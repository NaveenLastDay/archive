import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { Input, Component, OnInit } from '@angular/core';
import { Router, NavigationEnd, ActivatedRoute, ParamMap } from '@angular/router';
import { EdcdModel } from '../../../models/edcd.model';
import * as moment from 'moment';

@Component({
  selector: 'edcd-widget',
  templateUrl: './edcdwidget.component.html',
  styleUrls: ['./edcdwidget.component.css']
})
export class EDCDWidgetComponent implements OnInit {
  @Input() edcdDetails: EdcdModel;
  percentage: number;
  colorOuter: string;
  colorInner: string;
  days: any;
  date: any;
  time: any;
  infoMsg: string = '';
  isDaysOverdue:boolean;
  isApproved:boolean;
  onTimeApproved:boolean=false;
  isLateApproved:boolean=false;
  isLateWithApproved:boolean=false;
  isLatePastApproved:boolean=false;
  curre
  archiveOverrideStatus: any;
  constructor(private router: Router, private activatedRoute: ActivatedRoute) {
    router.events.subscribe((_: NavigationEnd) => this.days = this.days);
  }

  ngOnInit() {
    debugger;
    this.archiveOverrideStatus = JSON.parse(localStorage.getItem('archiveOverrideStatus'));
   
    this.setEDCDWidget();
    this.setInfoMsg();
  }

  setEDCDWidget(){
    this.days = this.edcdDetails.days;
    this.isApproved=this.edcdDetails.isArchiveApprove;
    this.colorOuter = "#" + this.edcdDetails.colorOuter;
    this.colorInner = "#" + this.edcdDetails.colorInner;
    this.date = this.edcdDetails.date;
    this.time = this.edcdDetails.time;
    this.isDaysOverdue=this.edcdDetails.daysOverdue;
    let edcdDate:any =  this.getOnlyDate(this.edcdDetails.date);
    let approvedDate = this.getOnlyDate(this.edcdDetails.archiveApprovedDate);
    let archiveRDCDDate:any =  this.getOnlyDate(this.edcdDetails.archiveDueDate);
    let adceddate:any =  this.getOnlyDate(this.edcdDetails.adceddate);


    // this.edcdDetails.formStatus ="";
    if(approvedDate<=edcdDate)
    this.onTimeApproved=true;
    else if(approvedDate>edcdDate && ((approvedDate<archiveRDCDDate && this.edcdDetails.formStatus == "Approved") || (approvedDate.getTime() == archiveRDCDDate.getTime() && this.edcdDetails.formStatus == "Approved" && adceddate.getTime() == approvedDate.getTime())))
    this.isLateWithApproved=true;
    else if(approvedDate>edcdDate && approvedDate<=archiveRDCDDate)
    this.isLateApproved=true;
    //else if(new Date().setHours(0,0,0,0)>archiveRDCDDate)
    else
    this.isLatePastApproved=true;
    if(this.archiveOverrideStatus != '' && this.archiveOverrideStatus !='Compliance exemption'){
      this.onTimeApproved=false;
       this.isLateApproved = false;
       this.isLateWithApproved = false;
       this.isLatePastApproved = false;
     }
  }

  getOnlyDate(convertDate){
    let date = new Date(convertDate);
     date.setHours(0,0,0,0);
     console.log(date);
    return date;
  }

  ngOnChanges() {
    this.setInfoMsg();
  }

  setInfoMsg() {
    var date = moment(this.edcdDetails.originalDate).format("MM/DD/YYYY");
    if (this.edcdDetails.archiveDueDateCriteria == 'DateEngagementCeased') {
      this.infoMsg = `The calculated documentation completion date for this archive is 30 days past the Date Engagement Ceased of ${date}`;
    }
    else if (this.edcdDetails.archiveDueDateCriteria == 'EarlyDeliverableReleaseDate') {
      this.infoMsg = `The expected documentation completion date for this archive is calculated as 30 days past the earliest deliverable release date or group audit report release date of ${this.edcdDetails.deliverableType} : ${date}.`;
    }
    else if (this.edcdDetails.archiveDueDateCriteria == 'DateFieldworkWasSubstantiallyCompleted') {
      this.infoMsg = `The calculated expected documentation completion date for this archive is 30 days past the Date Fieldwork Related to this Archive was Substantially Completed, Date of Other issued Communications or Letters or Group Audit Report Release Date of ${date}.`;
    }
    else if (this.edcdDetails.archiveDueDateCriteria == 'EstimatedReportReleaseDate') {
      this.infoMsg = `The calculated expected documentation completion date for this archive is 30 days past the Estimated Date of ${date}.`
              
    }
  }
  /*this.days = this.activatedRoute.snapshot.params.days;
   this.colorOuter = "#"+this.activatedRoute.snapshot.params.colorOuter;
   this.colorInner = "#"+this.activatedRoute.snapshot.params.colorInner;*/
}
