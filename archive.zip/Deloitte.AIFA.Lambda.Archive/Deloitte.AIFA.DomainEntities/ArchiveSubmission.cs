﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
    public class ArchiveSubmission
    {
        public string ArchiveNumber { get; set; }

        public string CreatedBy { get; set; }

        public string PPDUserAlias { get; set; }

        public DateTime? EstimatedDate { get; set; }

        public string ArchiveStatus { get; set; }

        public int? RoleID { get; set; }

        public string OfficeTimeZone { get; set; }

        public string ArchiveApprovedDate { get; set; }
    }
} 
