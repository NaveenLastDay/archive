﻿using Deloitte.AIFA.DataModels;
using Deloitte.AIFA.DomainEntities;
using Deloitte.AIFA.DomainEntities.Report;
using Deloitte.AIFA.IRepositories;
using Deloitte.AIFA.Models;
using Deloitte.AIFA.Repositories.Transformers;
using Microsoft.Extensions.Caching.Memory;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Deloitte.AIFA.Repositories
{
    public class UserDashBoardRepository : BaseRepository<ArchiveField>, IUserDashBoardRepository
    {
        IMemoryCache _cache;
        
        public UserDashBoardRepository(IMemoryCache cache) : base(cache)
        {
            _cache = cache;
        }

        public List<MyForm3283Data> GetForm3283DashBoardData(string employeeUniqueIdentifier, int pageNumber, int pageSize)
        {
            try
            {
                var parameters = Builder
                    .Bind(ArchiveAccessRequestForApprovalParameter.EmployeeUniqueIdentifier).On(employeeUniqueIdentifier)
                    .Bind(ArchiveAccessRequestForApprovalParameter.PageNumber).On(pageNumber)
                    .Bind(ArchiveAccessRequestForApprovalParameter.PageSize).On(pageSize)
                    .Build();

                var result = DbHelper.ExecuteReader(
                    "pub_AIFA_GetMyForm3283sRequests",
                    parameters,
                        dr => new MyForm3283DetailsTransformer().Transform(dr).ToList());

                return _mapper.Map<List<MyForm3283DataModel>, List<MyForm3283Data>>(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<ComplianceMetricsDetails> GetComplianceMetricsData(string employeeUniqueIdentifier, int pageNumber, int pageSize,int sortBy,string filterText)
        {
            try
            {
                var parameters = Builder
                    .Bind(ComplianceMetricsParameter.EmployeeUniqueIdentifier).On(employeeUniqueIdentifier)
                    .Bind(ComplianceMetricsParameter.PageNumber).On(pageNumber)
                    .Bind(ComplianceMetricsParameter.PageSize).On(pageSize)
                    .Bind(ComplianceMetricsParameter.SortBy).On(sortBy)
                    .Bind(ComplianceMetricsParameter.FilterText).On(filterText)

                    .Build();

                var result = DbHelper.ExecuteReader(
                    "pub_AIFA_GetMyComplianceMetrics",
                    parameters,
                        dr => new ComplianceMetricsTransformer().Transform(dr).ToList());

                return _mapper.Map<List<ComplianceMetricsModel>, List<ComplianceMetricsDetails>>(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public UserDashboardResponse GetUserDashboardData(string userAlias, int requestId)
        {
            var userDashboardData = new UserDashboardResponse();
            try
            {
            

                userDashboardData.ComplianceMetricsForUser = new List<NonComplianceMetrics>();

                NonComplianceMetrics AccessRequests = new NonComplianceMetrics();
                RequestCountForApproval TempAccessReq = GetArchiveAccessRequestCountForApproval(userAlias);
                AccessRequests.Category = Enum.GetName(typeof(DashboardComponent), DashboardComponent.AccessRequests);
                AccessRequests.NonComplianceDetails = new List<ComplianceMetrics>();
                AccessRequests.Count = TempAccessReq.ActionItemCount;
                AccessRequests.Color= TempAccessReq != null ? TempAccessReq.Due : "Red";
                userDashboardData.ComplianceMetricsForUser.Add(AccessRequests);



                NonComplianceMetrics ArchiveDeletions = new NonComplianceMetrics();
                RequestCountForApproval ArchivesDeletionsCount = GetArchivesCountForDeletionRequests(userAlias);
                ArchiveDeletions.Category = Enum.GetName(typeof(DashboardComponent), DashboardComponent.ArchiveDeletions); ;
                ArchiveDeletions.NonComplianceDetails = new List<ComplianceMetrics>();
                ArchiveDeletions.Count =  ArchivesDeletionsCount.ActionItemCount;
                ArchiveDeletions.Color = ArchivesDeletionsCount != null ? ArchivesDeletionsCount.Due : "Red";
                userDashboardData.ComplianceMetricsForUser.Add(ArchiveDeletions);



                NonComplianceMetrics ArchivesAwaitingApprovals = new NonComplianceMetrics();
                RequestCountForApproval ArchivesAwaitingApprovalsCount = GetArchivesCountForAwaitingApproval(userAlias);

                ArchivesAwaitingApprovals.Category = Enum.GetName(typeof(DashboardComponent), DashboardComponent.ArchivesAwaitingApprovals); ;
                ArchivesAwaitingApprovals.NonComplianceDetails = new List<ComplianceMetrics>();
                ArchivesAwaitingApprovals.Count = ArchivesAwaitingApprovalsCount.ActionItemCount ;
                ArchivesAwaitingApprovals.Color = ArchivesAwaitingApprovalsCount != null ? ArchivesAwaitingApprovalsCount.Due : "Red";
                userDashboardData.ComplianceMetricsForUser.Add(ArchivesAwaitingApprovals);



                NonComplianceMetrics complianceScore = new NonComplianceMetrics();
                ComplianceScoreForDashboard complianceScoreForDashboard = GetComplianceScore(userAlias);
                complianceScore.Category = Enum.GetName(typeof(DashboardComponent), DashboardComponent.ComplianceMetrics); ;
                complianceScore.NonComplianceDetails = new List<ComplianceMetrics>();
                if(complianceScoreForDashboard!=null)
                    complianceScore.Count = complianceScoreForDashboard.ComplianceMetricsScore;
                else
                {
                    complianceScore.Count = 0;
                }
                complianceScore.Color = "Red";
                userDashboardData.ComplianceMetricsForUser.Add(complianceScore);

                NonComplianceMetrics Form3283SApprovals = new NonComplianceMetrics();
                RequestCountForApproval Form3283SApprovalsCount = GetForm3283sCountForApproval(userAlias);
                Form3283SApprovals.Category = Enum.GetName(typeof(DashboardComponent), DashboardComponent.Form3283SApprovals);
                Form3283SApprovals.NonComplianceDetails = new List<ComplianceMetrics>();
                Form3283SApprovals.Count = Form3283SApprovalsCount.ActionItemCount;
                Form3283SApprovals.Color = Form3283SApprovalsCount != null ? Form3283SApprovalsCount.Due : "Red";

                userDashboardData.ComplianceMetricsForUser.Add(Form3283SApprovals);



                NonComplianceMetrics ArchivesRequiringApprovals = new NonComplianceMetrics();
                RequestCountForApproval ArchivesRequiringApprovalCount= GetArchivesCountForRequiringApprovals(userAlias);

                ArchivesRequiringApprovals.Category = Enum.GetName(typeof(DashboardComponent), DashboardComponent.ArchivesRequiringApprovals); ;
                ArchivesRequiringApprovals.NonComplianceDetails = new List<ComplianceMetrics>();
                ArchivesRequiringApprovals.Count = ArchivesRequiringApprovalCount.ActionItemCount;
                ArchivesRequiringApprovals.Color = ArchivesRequiringApprovalCount != null ? ArchivesRequiringApprovalCount.Due : "Red";

                userDashboardData.ComplianceMetricsForUser.Add(ArchivesRequiringApprovals);



                NonComplianceMetrics PendingSubmissions = new NonComplianceMetrics();
                RequestCountForApproval PendingSubmissionsCount = GetPendingSubmissionsCountForApproval(userAlias);
                PendingSubmissions.Category = Enum.GetName(typeof(DashboardComponent), DashboardComponent.PendingSubmissions); ;
                PendingSubmissions.NonComplianceDetails = new List<ComplianceMetrics>();
                PendingSubmissions.Count = PendingSubmissionsCount.ActionItemCount;
                PendingSubmissions.Color = PendingSubmissionsCount != null ? PendingSubmissionsCount.Due : "Red";
                userDashboardData.ComplianceMetricsForUser.Add(PendingSubmissions);



                NonComplianceMetrics RetensionExceptions = new NonComplianceMetrics();
                RetensionExceptions.Category = Enum.GetName(typeof(DashboardComponent), DashboardComponent.RetensionExceptions); ;
                RetensionExceptions.NonComplianceDetails = new List<ComplianceMetrics>();
                RetensionExceptions.Count = 0;
                RetensionExceptions.Color = "Red";
                userDashboardData.ComplianceMetricsForUser.Add(RetensionExceptions);
            }
            catch(Exception ex)
            {
                throw ex;
            }
           
            return userDashboardData;
        }

        public RequestCountForApproval GetArchiveAccessRequestCountForApproval(string EmployeeUniqueIdentifier)
        {
            try
            {
                var parameters = Builder
                    .Bind(ArchiveAccessRequestCountForApprovalParameter.EmployeeUniqueIdentifier).On(EmployeeUniqueIdentifier)
                    .Build();

                var result = DbHelper.ExecuteReader(
                    "pub_AIFA_GetActionItemCountForRequestTempArchiveAccess",
                    parameters,
                        dr => new ArchiveAccessRequestCountForApprovalTransformer().Transform(dr).ToList().FirstOrDefault());

                return _mapper.Map<ArchiveAccessRequestCountForApprovalModel, RequestCountForApproval>(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public RequestCountForApproval GetForm3283sCountForApproval(string EmployeeUniqueIdentifier)
        {
            try
            {
                var parameters = Builder
                    .Bind(Form3283sCountForApprovalParameter.EmployeeUniqueIdentifier).On(EmployeeUniqueIdentifier)
                    .Build();

                var result = DbHelper.ExecuteReader(
                    "pub_AIFA_GetActionItemCountForForm3283sRequest",
                    parameters,
                        dr => new ArchiveAccessRequestCountForApprovalTransformer().Transform(dr).ToList().FirstOrDefault());

                return _mapper.Map<ArchiveAccessRequestCountForApprovalModel, RequestCountForApproval>(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public RequestCountForApproval GetPendingSubmissionsCountForApproval(string EmployeeUniqueIdentifier)
        {
            try
            {
                var parameters = Builder
                    .Bind(Form3283sCountForApprovalParameter.EmployeeUniqueIdentifier).On(EmployeeUniqueIdentifier)
                    .Build();

                var result = DbHelper.ExecuteReader(
                    "pub_AIFA_GetActionItemCountForSubmissionPending",
                    parameters,
                        dr => new ArchiveAccessRequestCountForApprovalTransformer().Transform(dr).ToList().FirstOrDefault());

                return _mapper.Map<ArchiveAccessRequestCountForApprovalModel, RequestCountForApproval>(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public RequestCountForApproval GetArchivesCountForRequiringApprovals(string EmployeeUniqueIdentifier)
        {
            try
            {
                var parameters = Builder
                    .Bind(Form3283sCountForApprovalParameter.EmployeeUniqueIdentifier).On(EmployeeUniqueIdentifier)
                    .Build();

                var result = DbHelper.ExecuteReader(
                    "pub_AIFA_GetActionItemCountForApprovalPending",
                    parameters,
                        dr => new ArchiveAccessRequestCountForApprovalTransformer().Transform(dr).ToList().FirstOrDefault());

                return _mapper.Map<ArchiveAccessRequestCountForApprovalModel, RequestCountForApproval>(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public RequestCountForApproval GetArchivesCountForAwaitingApproval(string EmployeeUniqueIdentifier)
        {
            try
            {
                var parameters = Builder
                    .Bind(Form3283sCountForApprovalParameter.EmployeeUniqueIdentifier).On(EmployeeUniqueIdentifier)
                    .Build();

                var result = DbHelper.ExecuteReader(
                    "pub_AIFA_GetActionItemCountForAwaitingApproal",
                    parameters,
                        dr => new ArchiveAccessRequestCountForApprovalTransformer().Transform(dr).ToList().FirstOrDefault());

                return _mapper.Map<ArchiveAccessRequestCountForApprovalModel, RequestCountForApproval>(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public RequestCountForApproval GetArchivesCountForDeletionRequests(string EmployeeUniqueIdentifier)
        {
            try
            {
                var parameters = Builder
                    .Bind(Form3283sCountForApprovalParameter.EmployeeUniqueIdentifier).On(EmployeeUniqueIdentifier)
                    .Build();

                var result = DbHelper.ExecuteReader(
                    "pub_AIFA_GetActionItemCountForArchiveDeletionRequests",
                    parameters,
                        dr => new ArchiveAccessRequestCountForApprovalTransformer().Transform(dr).ToList().FirstOrDefault());

                return _mapper.Map<ArchiveAccessRequestCountForApprovalModel, RequestCountForApproval>(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public ComplianceScoreForDashboard GetComplianceScore(string EmployeeUniqueIdentifier)
        {
            try
            {
                var parameters = Builder
                    .Bind(ComplianceScoreForDashboardParameter.EmployeeUniqueIdentifier).On(EmployeeUniqueIdentifier)
                    .Build();

                var result = DbHelper.ExecuteReader(
                    "pub_AIFA_GetCountForComplianceMetrics",
                    parameters,
                        dr => new ComplianceScoreTransformer().Transform(dr).ToList().FirstOrDefault());

                return _mapper.Map<ComplianceScoreForDashboardModel, ComplianceScoreForDashboard>(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }


        public IDictionary<string, string> ValidateUserForDashboardDetails(string userAlias)
        {
            throw new NotImplementedException();
        }

        public List<MyComplianceData> GetMyAwaitingApprovalDashBoardData(string employeeUniqueIdentifier, int pageNumber, object pageSize)
        {
            try
            {
                var parameters = Builder
                    .Bind(ArchiveAccessRequestForApprovalParameter.EmployeeUniqueIdentifier).On(employeeUniqueIdentifier)
                    .Bind(ArchiveAccessRequestForApprovalParameter.PageNumber).On(pageNumber)
                    .Bind(ArchiveAccessRequestForApprovalParameter.PageSize).On(pageSize)
                    .Build();

                var result = DbHelper.ExecuteReader(
                    "pub_AIFA_GetMyAwaitingApprovalDashBoardData",
                    parameters,
                        dr => new MyComplianceDetailsTransformer().Transform(dr).ToList());

                return _mapper.Map<List<MyComplianceDataModel>, List<MyComplianceData>>(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<MyComplianceData> GetArchiveDeletionsDashBoardData(string employeeUniqueIdentifier, int pageNumber, object pageSize)
        {
            try
            {
                var parameters = Builder
                    .Bind(ArchiveAccessRequestForApprovalParameter.EmployeeUniqueIdentifier).On(employeeUniqueIdentifier)
                    .Bind(ArchiveAccessRequestForApprovalParameter.PageNumber).On(pageNumber)
                    .Bind(ArchiveAccessRequestForApprovalParameter.PageSize).On(pageSize)
                    .Build();

                var result = DbHelper.ExecuteReader(
                    "pub_AIFA_GetArchiveDeletionsDashBoardData",
                    parameters,
                        dr => new MyComplianceDetailsTransformer().Transform(dr).ToList());

                return _mapper.Map<List<MyComplianceDataModel>, List<MyComplianceData>>(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<MyPendingSubmissionData> GetMyAwaitingSubmissionDashBoardData(string employeeUniqueIdentifier, int pageNumber, object pageSize)
        {
            try
            {
                var parameters = Builder
                    .Bind(ArchiveAccessRequestForApprovalParameter.EmployeeUniqueIdentifier).On(employeeUniqueIdentifier)
                    .Bind(ArchiveAccessRequestForApprovalParameter.PageNumber).On(pageNumber)
                    .Bind(ArchiveAccessRequestForApprovalParameter.PageSize).On(pageSize)
                    .Build();

                var result = DbHelper.ExecuteReader(
                    "pub_AIFA_GetMyAwaitingSubmissionDashBoardData",
                    parameters,
                        dr => new MyPendingSubmissionDetailsTransformer().Transform(dr).ToList());

                return _mapper.Map<List<MyPendingSubmissionDataModel>, List<MyPendingSubmissionData>>(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<MyComplianceData> GetMyRequiringApprovalDashBoardData(string userAlias, int pageNumber, int pagesize)
        {
            try
            {
                var parameters = Builder
                    .Bind(ArchiveAccessRequestForApprovalParameter.EmployeeUniqueIdentifier).On(userAlias)
                    .Bind(ArchiveAccessRequestForApprovalParameter.PageNumber).On(pageNumber)
                    .Bind(ArchiveAccessRequestForApprovalParameter.PageSize).On(pagesize)
                    .Build();

                var result = DbHelper.ExecuteReader(
                    "pub_AIFA_GetMyRequiringApprovalDashBoardData",
                    parameters,
                        dr => new MyComplianceDetailsTransformer().Transform(dr).ToList());

                return _mapper.Map<List<MyComplianceDataModel>, List<MyComplianceData>>(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
