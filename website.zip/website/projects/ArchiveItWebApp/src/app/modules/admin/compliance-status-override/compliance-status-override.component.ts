import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { NgxSpinnerService } from 'ngx-spinner';
import { ArchiveService } from '../../../services/archive.service';
import { CsoService } from '../../../services/cso.service';
import { SharedService } from '../../../services/shared.service';
import { FileUploadEventService } from "../../record/file-upload/fileupload.event.service";
import { FielUploadService } from '../../../services/fileupload.service';
import { FileUploadProcessService } from '../../record/file-upload/fileupload.process.service';
import { NotifierService } from "angular-notifier";
import { WorkingPaperService } from "../../../services/working-paper.service";
import { FormControl, FormGroup, FormBuilder, Validators, FormArray,NgForm, Form } from '@angular/forms';
import { Directive, HostBinding, Optional, Input } from '@angular/core';
import { ControlContainer} from '@angular/forms';
import { int } from 'aws-sdk/clients/datapipeline';
import { ModalService } from "../../shared/modal";
import { MatAutocompleteSelectedEvent } from '@angular/material';


@Component({
  selector: 'app-compliance-status-override',
  templateUrl: './compliance-status-override.component.html',
  styleUrls: ['./compliance-status-override.component.css']
})
export class ComplianceStatusOverrideComponent implements OnInit {
  employeeUniqueIdentifier: string;
  appendArchiveToGrid: boolean = false;
  archives: any[];
  totalArchives: number = 0;
  currentPageNumber: number = 1;
  archiveNumber: string;
  pageSize: number = 10;
  archiveIDForChild: any;
  pageCount: number = 10;
  redColor: any;
  orangeColor: any;
  yellowColor: any;
  csoData: any;
  searchText = '';
  showDropdownMenu: boolean;
  popUpHeaderText:string;
  isTypeEdit:boolean = true;
  crossicon: boolean = false;
  searchedtext: string = "";
  fileName: string='';
  fileSize: number;
  csoTypes: any[];
  fileId: string = "";
  disableUploadButton: boolean = true;
  archivenumber: string = "";
  addEdit: string = "";
  Issearched : boolean = false;
  isBtnEnabled : boolean = false;
  ArchiveName : string;
  Client : string;
  WBS : string;
  Status : string;
  createEditform:FormGroup;
  SelectedArchiveNumber : string;
  selectedStatusId : int;
  selectedStatusValue : string;
  module: string = "CSO";
  archiveFileId : string;
  fileTransferId : string;
  S3FileNameOut : string;
  sortVal: string = 'ArchiveNumber';
  sortValOrder: string = 'DESC';
  showUploadOverrideForm: any = true;
  valueCount: number = 0;
  showGridHeader: boolean = false;
  enableRemoveButton: boolean = false;
  FileUploadList : any = [];
  verificationInProgressStatus = [0, 1, 2, 5];
  verifiedFiles: any = [];
  unverifiedFiles: any = [];
  getFileName : string ="";
  archiveInfo:any;
  fileArrayObject: any;
  fuparams: { ArchiveFileId: any; FileTransferId: any; FileUploadStatusCode: any; ETag: string; UploadId: any; FailedDescription: any; ArchiveNumber: string; };
  message :  string ="";
  editFile : boolean = false;
  freeTextValidate:boolean = true;
  seachArchiveVal: any;
  showErrorFreeText: boolean = false;
  selectedType: any;
  csoTypesData: any;
  complianceStatusIdVal: any;
  overrideStatusForCso: any;

  constructor(private archiveService: ArchiveService,private sharedService: SharedService, private router: Router, private adalSvc: MsAdalAngular6Service,private _fuService: FielUploadService,
    private modalService: ModalService,private csoService: CsoService, private _fuEventService: FileUploadEventService, private fb: FormBuilder,private SpinnerService: NgxSpinnerService,
    private _uploadEventService: FileUploadEventService, private notifier: NotifierService,  private _wservice: WorkingPaperService) { 
    // this.SpinnerService.show();
    this.createEditform = fb.group({
      'archiveNumberControl': [null, [Validators.required]],
      'statusControl': [null, [Validators.required]],
      'businessPurpose': [null]
    });
  }

  ngOnInit() {
    this.showGridHeader = false;
    this.employeeUniqueIdentifier = this.adalSvc.LoggedInUserEmail.split('@')[0];
    this.getCSOData();
    this.module="CSO";
    this._fuEventService.getfileUploadStatus.subscribe(fileArrayObject => {
      this.fileArrayObject = fileArrayObject;
      var self=this;
      if(fileArrayObject.module!=self.module)
      return;
      if (fileArrayObject) {

        let etag = "";

        if (fileArrayObject.eTag) {
          etag = fileArrayObject.eTag.substr(1, fileArrayObject.eTag.length - 2);
        }

        let fuparams = {
          ArchiveFileId: fileArrayObject.metaData.ArchiveFileId,
          FileTransferId: fileArrayObject.metaData.FileTransferId,
          FileUploadStatusCode: fileArrayObject.uploadStatus,
          ETag: etag,
          UploadId: fileArrayObject.uploadId,
          FailedDescription: fileArrayObject.errorMessage,
          ArchiveNumber:this.archiveNumber
        };
        console.log("CSO get" + this.archiveFileId);
        console.log("updating in DB");
        console.log(fuparams);
        debugger;
        this.fuparams = fuparams;
        this.createOrUpdateWorkingPaper(fuparams,fileArrayObject);
      }
    });
  }

  createOrUpdateWorkingPaper(fuparams,fileArrayObject) {

    this._wservice.CreateOrUpdateWorkingPaper(fuparams).subscribe(response => {
      console.log("updated in DB");
      console.log(response);
      
        if (this.message !== undefined && this.message !== "") {
        this.notifier.notify("success", this.message);
        this.message = "";
        this.fileId = "";
        this.fileName = "";
        this.getCSOData();
        this.resetForm();
      }
    },
      err => {
        console.log("failed to update CSO File in DB");
        console.log(err);
      });
  }
  searchArchive() {
    this.totalArchives = 0;
    this.showGridHeader = true;
    this.currentPageNumber = 1;
    this.getCSOData();
  }
  getCSOData() {
    this.SpinnerService.show();
    this.csoService.getArchiveCSODetails('',this.currentPageNumber, this.pageSize, this.sortVal,this.sortValOrder,0, this.searchText).subscribe((data) => {
      this.csoData = data;
        if (this.appendArchiveToGrid && data) {
          this.archives = this.archives.concat(data);
        }
        else {
          this.archives = data ? data : [];
        }
        if(this.csoData.length > 0) {
          this.showGridHeader = true;
        this.totalArchives = this.archives[0]["count"];
        setTimeout(() => {
          this.columnSelection();
        }, 100)
        }
        this.SpinnerService.hide();
      });
  }

  disableBack() {
    window.history.forward();
  }
  archiveID(event) {
    this.archiveIDForChild = event;
  }
  updateGridData(event) {
    this.appendArchiveToGrid = event.isLoadMoreClicked;
    this.currentPageNumber = event.pageNumber;
    this.getCSOData();
  }
  exportToExcel() {
            let columns = [
          'Archive #',
          'Archive Name',
          'Client',  
          'WBS #',
          'Compliance status',
          'Override status'        
      ];
      this.csoService.getArchiveCSODetails('', 0, 0, this.sortVal,this.sortValOrder,0, '').subscribe((data) => {
          data.forEach(elm=> {
        delete elm.archiveFileId;
        delete elm.fileName;
        delete elm.fileSize;
        delete elm.s3FileName;
        delete elm.count;
      });
      var result = data.map(o => Object.keys(o).map(k => o[k]));
      if (data && data.length) {
        this.sharedService.generateExcel("Compliance status override", "Compliance status override", columns,result );
      }
     },
     error => {
       console.log('Exception occured ' + JSON.stringify(error));
     });
   
  }
  showDropdown() {
    this.showDropdownMenu = true;
  }
  editOverride(event) {
    event.stopPropagation();
    console.log('edit');
  }
  removeOverride(event) {
    event.stopPropagation();
    console.log('remove');
  }
  
  downloadFile(s3fileName: string, fileName: string) {
    if (!s3fileName && !fileName) return false;
    var metaData = {};
    var fileUploadProcessService = new FileUploadProcessService(
      this._fuService,
      this._uploadEventService,
      this.SpinnerService,
      null,
      null,
      metaData
    );
    fileUploadProcessService.downloadFile(s3fileName, fileName);
  }
  addcolour() {
    document.getElementById('colordiv').classList.add('bordercolorchange');
    this.crossicon = true;
    if(this.crossicon = true) {
      document.getElementById('type_archive_infotext').classList.add('type-archive-text');
    }

  }

  removecolour(event: any) {
    document.getElementById('colordiv').classList.remove('bordercolorchange');
    if(this.Issearched == false) {
      if(document.getElementById('type_archive_infotext').classList.contains('type-archive-text')) {
        document.getElementById('type_archive_infotext').classList.remove('type-archive-text');
        }
           }
    if (event.target.value === '') {
      this.crossicon = false;
    }
  }
  onKeyUp(event) {
    debugger;
    this.valueCount = event.target.value.length;
    if((this.selectedStatusId == 5) && (this.valueCount !== 0)) {
      this.freeTextValidate = true;
      this.isBtnEnabled = true;
      this.showErrorFreeText = false;
    } else if(this.valueCount == 0) {
      this.freeTextValidate = false;
      this.isBtnEnabled = false;
      this.showErrorFreeText = true;
    }
    else {
      this.freeTextValidate = false;
      this.isBtnEnabled = false;
      this.showErrorFreeText = false;
    }
  }

  OnReset() {
    // if(this.crossicon = true) {
      // }
      this.crossicon = false;
      this.Issearched = false;
      this.searchedtext = '';
      this.createEditform.controls.archiveNumberControl.setValue('');
  }
  setOrder(value: string) {
    this.sortVal = value;
    this.resetPage();
    if(this.sortValOrder == 'DESC'){
      this.sortValOrder = 'ASC';
      this.getCSOData();
    }
    else{
      this.sortValOrder = 'DESC';
      this.getCSOData();
    }

  }
  resetPage() {
    this.appendArchiveToGrid = false;
    this.currentPageNumber = 1;
    this.pageSize = 10;
    this.totalArchives = 0;
  }

  openModalDialog(Action, archiveNumber, overrideStatus) {
    this.selectedType = Action;
    this.overrideStatusForCso = overrideStatus;
    this.GetCSOTypes();
    if (Action == "Add" ) {
      this.createEditform.patchValue({ "statusControl": null });
    //        if(document.getElementById('edit_archive_cso').classList.contains('mt-0')) {
    //         document.getElementById('edit_archive_cso').classList.remove('mt-0');
    // }
      this.popUpHeaderText="Add override";
      this.isTypeEdit=false;
      this.message = "Override details saved successfully";
      this.fileId = "";
      this.fileName = "";
      this.modalService.openWithCustomWidth('cso-popup-modal', "650");
    }
    else if (Action == "Edit" ||  Action == "Remove")
    { 
      debugger;
      this.crossicon = true;
      this.SelectedArchiveNumber = archiveNumber;
      if(Action == "Remove")
      {
        this.enableRemoveButton = true;
      }
        else 
        {
        this.enableRemoveButton = false;
        this.message = "Override details saved successfully";
        }
        this.GetArchiveDetails("EditRemove");
        // setTimeout(() => {
        //   document.getElementById('edit_archive_cso').classList.add('mt-0');
        // }, 100)
        
    }
  }

    closeModalDialog(Action:string) {
      this.modalService.close(Action);
      this.resetForm();
    }
     
    closePopUp(Action:string) {
      this.modalService.close(Action);
    }

    resetForm(){
     this.createEditform.reset();
     this.showUploadOverrideForm = true;
     this.crossicon = false;
     this.createEditform.get('archiveNumberControl').reset();
     this.createEditform.get('statusControl').reset();
    //  if(document.getElementById('archive_details_cso').classList.contains('type-archive-text')) {
    //    document.getElementById('archive_details_cso').classList.remove('type-archive-text');
    // }
     this.Issearched = false;
     this.enableRemoveButton = false;
     this.editFile = false;
     //this.cancelSelectedFile();
    }


    GetCSOTypes(){
      this.csoService.GetComplianceStatusTypes().subscribe(
        data => {
          this.csoTypesData = data;
          if (data)
          this.csoTypes = data ? data : [];
        }
      );
    }

    selectedStatusType(event:any){
        this.selectedStatusId=event.target.value;
      console.log('event',this.selectedStatusId);
      this.selectedStatusValue = event.target.options[event.target.selectedIndex].text;
      if(this.selectedStatusId == 5) {
        this.showUploadOverrideForm = false;
      } else {
        this.showUploadOverrideForm = true;
      }
     }
    
    browseFileDialogClick() {
      var self = this;
      this.editFile = true;
      var fileIndex = self._fuEventService.fileIndex++;
      self.fileId = 'fileId-' + fileIndex;
      //test
      var fileElem = document.createElement('input');
      fileElem.setAttribute("id", self.fileId);
      fileElem.setAttribute("type", "file");
      document.getElementById("div_fileupload").appendChild(fileElem);
      fileElem.onchange = function (e: any) {
        var file = e.target.files[0];
  
        if (file.name) {
            self.fileName = file.name;
            self.fileSize = file.size;
             self.disableUploadButton = false;
             self.isBtnEnabled=true;
        }
      };
      fileElem.click();
    }
 
  cancelSelectedFile() {
    this.isBtnEnabled=false;

    let div_fileupload = document.getElementById("div_fileupload")
    var fileElement = document.getElementById(this.fileId);
    if (div_fileupload && fileElement) div_fileupload.removeChild(fileElement); 
    
    this.fileId = "";
    this.fileName = "";
    this.editFile = false;
  }

  columnSelection() {
    if (this.sortVal !== '') {
      if (this.sortVal == 'ArchiveNumber') {
        let element = document.getElementById("archive_number_cso");
        element.classList.add("selected-columnmetric");
        let element2 = document.getElementById("archive_name_cso");
        element2.classList.remove("selected-columnmetric");
        let element3 = document.getElementById("client_cso");
        element3.classList.remove("selected-columnmetric");
        let element4 = document.getElementById("wbs_number_cso");
        element4.classList.remove("selected-columnmetric");
        let element5 = document.getElementById("compliance_status_cso");
        element5.classList.remove("selected-columnmetric");
        let element6 = document.getElementById("override_status_cso");
        element6.classList.remove("selected-columnmetric");
      }
      if (this.sortVal == 'ArchiveName') {
        let element1 = document.getElementById("archive_number_cso");
        element1.classList.remove("selected-columnmetric");
        let element = document.getElementById("archive_name_cso");
        element.classList.add("selected-columnmetric");
        let element3 = document.getElementById("client_cso");
        element3.classList.remove("selected-columnmetric");
        let element4 = document.getElementById("wbs_number_cso");
        element4.classList.remove("selected-columnmetric");
        let element5 = document.getElementById("compliance_status_cso");
        element5.classList.remove("selected-columnmetric");
        let element6 = document.getElementById("override_status_cso");
        element6.classList.remove("selected-columnmetric");
      }
      if (this.sortVal == 'ClientName') {
        let element = document.getElementById("client_cso");
        element.classList.add("selected-columnmetric");
        let element1 = document.getElementById("archive_number_cso");
        element1.classList.remove("selected-columnmetric");
        let element2 = document.getElementById("archive_name_cso");
        element2.classList.remove("selected-columnmetric");
        let element4 = document.getElementById("wbs_number_cso");
        element4.classList.remove("selected-columnmetric");
        let element5 = document.getElementById("compliance_status_cso");
        element5.classList.remove("selected-columnmetric");
        let element6 = document.getElementById("override_status_cso");
        element6.classList.remove("selected-columnmetric");
      }
      if (this.sortVal == 'WBSNumber') {
        let element = document.getElementById("wbs_number_cso");
        element.classList.add("selected-columnmetric");
        let element1 = document.getElementById("archive_number_cso");
        element1.classList.remove("selected-columnmetric");
        let element2 = document.getElementById("archive_name_cso");
        element2.classList.remove("selected-columnmetric");
        let element3 = document.getElementById("client_cso");
        element3.classList.remove("selected-columnmetric");
        let element5 = document.getElementById("compliance_status_cso");
        element5.classList.remove("selected-columnmetric");
        let element6 = document.getElementById("override_status_cso");
        element6.classList.remove("selected-columnmetric");
      }
      if (this.sortVal == 'ComplianceStatus') {
        let element = document.getElementById("compliance_status_cso");
        element.classList.add("selected-columnmetric");
        let element1 = document.getElementById("archive_number_cso");
        element1.classList.remove("selected-columnmetric");
        let element2 = document.getElementById("archive_name_cso");
        element2.classList.remove("selected-columnmetric");
        let element3 = document.getElementById("client_cso");
        element3.classList.remove("selected-columnmetric");
        let element4 = document.getElementById("wbs_number_cso");
        element4.classList.remove("selected-columnmetric");
        let element6 = document.getElementById("override_status_cso");
        element6.classList.remove("selected-columnmetric");
      }
      if (this.sortVal == 'OverrideStatus') {
        let element = document.getElementById("override_status_cso");
        element.classList.add("selected-columnmetric");
        let element1 = document.getElementById("archive_number_cso");
        element1.classList.remove("selected-columnmetric");
        let element2 = document.getElementById("archive_name_cso");
        element2.classList.remove("selected-columnmetric");
        let element3 = document.getElementById("client_cso");
        element3.classList.remove("selected-columnmetric");
        let element4 = document.getElementById("wbs_number_cso");
        element4.classList.remove("selected-columnmetric");
        let element5 = document.getElementById("compliance_status_cso");
        element5.classList.remove("selected-columnmetric");
      }
    }
  }

  AddOverride()
  {
    // this.createEditform.value.businessPurpose
    var commentVal
    if(this.selectedStatusId == 5) {
     commentVal =  this.selectedStatusValue+','+this.createEditform.value.businessPurpose
     this.fileName = "";
     this.fileSize = 0;
    } else {
      commentVal = this.selectedStatusValue
    }
    var parameters = {
      "ArchiveNumber": this.SelectedArchiveNumber
    , "Comment": commentVal
    , "CreatedBy" : this.employeeUniqueIdentifier
    , "FileName" :this.fileName
    , "FileSize" : this.fileSize
    , "OperationType" : 'ADD'
    } 
    this.csoService.AddEditCSO(parameters).subscribe(
      data => {
        if (data)
        this.addEdit = data ? data : [];
        this.archiveFileId = data.archiveFileIdOut;
        this.fileTransferId = data.fileTransferIdOut;
        this.S3FileNameOut = data.s3FileNameOut;
        if (+this.archiveFileId>0 && this.editFile)
        {
        this.triggerFileUploadProcess();
        this.editFile= false;
        }
        else{
          if (this.message !== undefined && this.message !== "") {
            this.notifier.notify("success", this.message);
            this.message = "";
            this.getCSOData();
            this.resetForm();
            this.fileId = "";
            this.fileName = "";
        }
      }
      }
    );
  }

  triggerFileUploadProcess() {
    var self = this;

    self._fuEventService.fileArray.push({
      module: self.module,
      fileId: this.fileId,
      fileName:this.fileName,
      s3FileName: this.S3FileNameOut,
      fileSize: this.fileSize,
      eTag: "",
      uploadId: "",
      uploadPercentage: "",
      uploadStatus: "add",
      uploadMessage: "",
      errorMessage: "",
      uploadRemaingTime: "",
      sunits: "",
      tunits: "",
      metaData: {}
    });

    var metaData = {
      archiveFileId: this.archiveFileId.toString(),
      fileTransferId: this.fileTransferId.toString()
    }

    var fileUploadProcessService = new FileUploadProcessService(
      self._fuService,
      self._fuEventService,
      self.SpinnerService,
      this.fileId,
      this.S3FileNameOut,
      metaData
    );

    var fileElement = document.getElementById(this.fileId);
    fileUploadProcessService.uploadFile(fileElement);
  }

  SearchArchivesforCSO(event: any){
    this.seachArchiveVal = event.target.value;
    if(this.seachArchiveVal == '') {
      this.Issearched = false;
    }
    this.csoService.GetArchivesforCSO(event.target.value,10).subscribe(
      data => {
        if (data.length > 0) {
          this.archivenumber = data;
        }
        else {
          this.archivenumber = null;
        }
      }
    );
  }

  optionArchiveSelected(event: MatAutocompleteSelectedEvent) {
    if(event.option.value!="")
    {
      this.Issearched= true;
      // document.getElementById('archive_details_cso').classList.add('type-archive-text');
      this.SelectedArchiveNumber =  event.option.value;
      this.GetArchiveDetails("Select");
    }
  }
  
  deleteFile() 
  {
    var parameters = {
      "ArchiveNumber": this.SelectedArchiveNumber
    , "Comment": this.selectedStatusValue
    , "CreatedBy" : this.employeeUniqueIdentifier
    , "FileName" :this.fileName
    , "FileSize" : this.fileSize
    , "OperationType" : "REMOVE"
    } 
    this.csoService.AddEditCSO(parameters).subscribe(
      data => {
        if (data)
        this.addEdit = data ? data : [];
        this.getCSOData();
      }
    );
    this.notifier.notify("success", "Removed override successfully");
  }

  GetArchiveDetails(resetForm : any)
  {
    this.csoService.getArchiveCSODetails(this.SelectedArchiveNumber,1,10,'','',0,'').subscribe(
      data => {
        if (data)
        this.ArchiveName = data[0].archiveName;
        this.Client = data[0].clientName;
        this.WBS = data[0].wbsNumber;
        this.Status = data[0].complianceStatus;
        this.getFileName = data[0].fileName;
        if(this.selectedType == 'Edit') {
          if(this.overrideStatusForCso.toLowerCase() == 'compliance exemption') {
            this.showUploadOverrideForm = false;
          } else {
            this.showUploadOverrideForm = true;
          }
          if(this.csoTypesData) {
            this.csoTypesData.filter((x) => {
              if(x.description.toLowerCase() == this.overrideStatusForCso.toLowerCase()) {
                this.complianceStatusIdVal = x.complianceStatusID;
                this.createEditform.controls.statusControl.setValue(this.complianceStatusIdVal);
              }
            })
          }
          this.createEditform.patchValue({ "businessPurpose": data[0].overrideStatus });
          // this.createEditform.patchValue({ "statusControl": data[0].complianceStatus });
        }

        if(resetForm === "EditRemove")
        {
          if(this.overrideStatusForCso.toLowerCase() == 'compliance exemption') {
            this.showUploadOverrideForm = false;
          } else {
            this.showUploadOverrideForm = true;
          }
          if(this.csoTypesData) {
            this.csoTypesData.filter((x) => {
              if(x.description.toLowerCase() == this.overrideStatusForCso.toLowerCase()) {
                this.complianceStatusIdVal = x.complianceStatusID;
                this.createEditform.controls.statusControl.setValue(this.complianceStatusIdVal);
              }
            })
          }
          this.createEditform.patchValue({ "businessPurpose": data[0].overrideStatus });
        this.popUpHeaderText="Change the status";
        this.isTypeEdit=true;
        this.Issearched= true;
        this.editFile = false;
        // document.getElementById('archive_details_cso').classList.add('type-archive-text');
        this.isBtnEnabled=true;       
        this.createEditform.controls.archiveNumberControl.setValue(this.SelectedArchiveNumber);
        this.fileName = data[0].fileName;
        this.modalService.openWithCustomWidth('cso-popup-modal', "650");
        }
      }
    );
  }
}
