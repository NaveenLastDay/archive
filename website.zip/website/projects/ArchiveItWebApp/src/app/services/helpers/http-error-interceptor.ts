import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpHandler, HttpRequest, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { mergeMap, catchError } from 'rxjs/operators';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { AppConfig } from '../appconfig.service';
import { PubsubService } from '../pubsub.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { NotifierService } from 'angular-notifier';

@Injectable()
export class HttpErrorInterceptor implements HttpInterceptor {

    notifier: NotifierService;
    constructor(private SpinnerService : NgxSpinnerService, private config:AppConfig, private _notifier: NotifierService) {
        this.notifier = _notifier;
    }

    intercept(req: HttpRequest<any>, next: HttpHandler) {
        return next.handle(req).pipe(catchError(error => {
            this.handlehttpException(error);
            throw error;
        }));
    }

    handlehttpException(error: any) {
        this.SpinnerService.hide();
        console.log("Error while calling API - 403 forbidden");
        if (error.status === 403) {
            if(!this.notifier['queueService']['isActionInProgress'])
            this.notifier.notify(
                "error", "Request failing - 403 forbidden. please check your input"
            );
        }
        else {
            return "";
        }
    }
}
