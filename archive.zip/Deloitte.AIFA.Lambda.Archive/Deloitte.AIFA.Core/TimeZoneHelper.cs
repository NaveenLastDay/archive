﻿using System;
using System.Linq;

namespace Deloitte.AIFA.Repositories.UtilityHelper
{
    public class TimeZoneHelper
    {
        private static readonly TimeZoneInfo CentralTimeZone = TimeZoneInfo.FindSystemTimeZoneById("Central Standard Time");

        public static DateTime? ConvertToServerTimeZone(DateTime? value)
        {
            var serverTimeZone = //ConfigurationManager.AppSettings["ServerTimeZone"] ?? 
                TimeZoneInfo.Utc.Id;
            if (value != null)
                return TimeZoneInfo.ConvertTimeFromUtc(((DateTime)value).ToUniversalTime(), TimeZoneInfo.FindSystemTimeZoneById(serverTimeZone));
            return null;
        }

        public static DateTime ConvertCentralTimeToUtc(DateTime value)
        {
            if (string.IsNullOrEmpty(Convert.ToString(value)))
                return value;

            return TimeZoneInfo.ConvertTimeToUtc(GetAdjustedDateTimeByTimeZone(TimeZoneInfo.Local, value), CentralTimeZone);
        }

        public static DateTime ConvertOtDateToCentralTimeZone(DateTime value)
        {
            if (string.IsNullOrEmpty(Convert.ToString(value)))
                return value;

            var serverTimeZone = //ConfigurationManager.AppSettings["TimeZoneOT"] ?? 
                "Central Standard Time";
            var timeZone = TimeZoneInfo.FindSystemTimeZoneById(serverTimeZone);

            return TimeZoneInfo.ConvertTime(GetAdjustedDateTimeByTimeZone(TimeZoneInfo.Local, value), timeZone, CentralTimeZone);
        }

        private static DateTime GetAdjustedDateTimeByTimeZone(TimeZoneInfo timeZone, DateTime date)
        {
            TimeZoneInfo.AdjustmentRule adjustment;
            if (timeZone.IsInvalidTime(date) &&
                (adjustment = timeZone.GetAdjustmentRules().FirstOrDefault(x => date >= x.DateStart && date <= x.DateEnd)) != null)
            {
                date += adjustment.DaylightDelta;
            }
            return DateTime.SpecifyKind(Convert.ToDateTime(date), DateTimeKind.Unspecified);
        }
    }
}
