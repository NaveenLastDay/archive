import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdvancedSearchCustomRuleComponent } from './advanced-search-custom-rule.component';

describe('AdvancedSearchCustomRuleComponent', () => {
  let component: AdvancedSearchCustomRuleComponent;
  let fixture: ComponentFixture<AdvancedSearchCustomRuleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdvancedSearchCustomRuleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdvancedSearchCustomRuleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
