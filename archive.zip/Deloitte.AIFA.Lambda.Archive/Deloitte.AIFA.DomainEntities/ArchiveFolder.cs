﻿
namespace Deloitte.AIFA.DomainEntities
{
    public class ArchiveFolder
    {
        public int ArchiveFolderId { get; set; }
        public int ArchiveId { get; set; }
        public int ParentFolderId { get; set; }
        public string ArchiveFolderName { get; set; }
    }
}
