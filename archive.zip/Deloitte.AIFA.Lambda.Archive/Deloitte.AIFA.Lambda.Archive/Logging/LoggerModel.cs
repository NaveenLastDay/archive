﻿using Microsoft.Extensions.Logging;
using System;

namespace Deloitte.AIFA.Lambda.Logging
{
    public class LoggerModel
    {
        public string Source { get; set; }
        public string LogLevel { get; set; }
        public string LogDate { get; set; }
        public string User { get; set; }
        public string CorrelationId { get; set; }
        public string Message { get; set; }
        public int StatusCode { get; set; }
        public string Path { get; set; }
    }
}
