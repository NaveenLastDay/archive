import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ArchiveService } from '../../../services/archive.service';
// import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-archives-requiring-approval-list',
  templateUrl: './archives-requiring-approval-list.component.html',
  styleUrls: ['./archives-requiring-approval-list.component.css']
})
export class ArchivesRequiringApprovalListComponent implements OnInit {
  archiveDetails:any;
  @Input('archiveNumber') archiveNumber : string;
  @Input('entityTypeDescription') entityTypeDescription : string;
  @Input('professionalStandardDescription') professionalStandardDescription : string;
  @Output() archiveID = new EventEmitter();
  @Input('archiveAccessRequestID') archiveAccessRequestID : string;
  @Input('estimatedIssuanceReportDate') estimatedIssuanceReportDate : any;
  constructor(private archiveService : ArchiveService) { }

  ngOnInit() {
    // this.SpinnerService.show();
    this.archiveService.GetMyArchiveDetails(this.archiveNumber).subscribe(
      data => {
        this.archiveDetails = data;
        this.archiveService.SetArchiveIdChildVal(this.archiveAccessRequestID);
        this.archiveID.emit(this.archiveAccessRequestID);
        // this.SpinnerService.hide();
      });
  }


}
