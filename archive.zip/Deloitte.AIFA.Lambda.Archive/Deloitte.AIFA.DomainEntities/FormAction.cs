﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
    public class FormAction
    {
        public int EntityId { get; set; }
        public int ActionItemId { get; set; }
        public string ActionItemIdentifier { get; set; }
        public string ActionItemAssignedTo { get; set; }
        public string ActionItemAssignedToFullName { get; set; }
        public string ActionItemStatusDescription { get; set; }
        public DateTime? CompletedDate { get; set; }
    }

    public class FormActionResponse
    {
        public bool IsSuccessful { get; set; }
        public string ResponseMessage { get; set; }
        public string ApprovedBy { get; set; }
        public DateTime ADCED { get; set; }
        public string FormStatus { get; set; }
        public string SubmittedBy { get; set; }
    }
}
