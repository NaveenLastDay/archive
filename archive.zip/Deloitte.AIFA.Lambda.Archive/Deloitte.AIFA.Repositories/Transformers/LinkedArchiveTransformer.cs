﻿using Deloitte.AIFA.DataModels;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace Deloitte.AIFA.Repositories.Transformers
{
    public enum LinkedArchiveField
    {
        ArchiveNumber,
        ArchiveName,
        ArchiveStatus,
        ClientName,
        PeriodEndDate,
        WBSClosedDate,
        WBSNumber,
        WBSName,
        WBSStatus,
        WBSProjectType,
        WBSEngagementPPMD,
        EngagementManager,
        WBSClientNumber,
        WBSClientName,
        EngagementController,
        WBSLBP,
        WBSLCP
    }
    public enum LinkedArchiveTypeOutputFields
    {
        LinkTypeId,
        Description
    }
    public class LinkedArchiveTypeTransformer : BaseTransformer<LinkTypeModel>
    {
        internal override LinkTypeModel TransformElement(IDataReader dr, Func<IDataReader, LinkTypeModel, LinkTypeModel> bindExtraFields = null)
        {
            return new LinkTypeModel
            {
                LinkTypeId = (dr[LinkedArchiveTypeOutputFields.LinkTypeId.ToString()] is DBNull) ? 0 : int.Parse(dr[LinkedArchiveTypeOutputFields.LinkTypeId.ToString()].ToString()),
                Description = (dr[LinkedArchiveTypeOutputFields.Description.ToString()] is DBNull ? string.Empty : dr[LinkedArchiveTypeOutputFields.Description.ToString()].ToString()),
            };
        }

    }
    public class LinkedArchiveTransformer : BaseTransformer<LinkedArchivesModel>
    {
        internal override LinkedArchivesModel TransformElement(IDataReader dr, Func<IDataReader, LinkedArchivesModel, LinkedArchivesModel> bindExtraFields = null)
        {
            return new LinkedArchivesModel
            {
                UniqueID = (dr[LinkedArchivesOutputFields.UniqueID.ToString()] is DBNull) ? 0 : int.Parse(dr[LinkedArchivesOutputFields.UniqueID.ToString()].ToString()),
                ArchiveID = (dr[LinkedArchivesOutputFields.ArchiveID.ToString()] is DBNull) ? 0 : int.Parse(dr[LinkedArchivesOutputFields.ArchiveID.ToString()].ToString()),
                ArchiveNumber = (dr[LinkedArchivesOutputFields.ArchiveNumber.ToString()] is DBNull) ? string.Empty : dr[LinkedArchivesOutputFields.ArchiveNumber.ToString()].ToString(),
                ReportingEntity = (dr[LinkedArchivesOutputFields.ReportingEntity.ToString()] is DBNull) ? string.Empty : dr[LinkedArchivesOutputFields.ReportingEntity.ToString()].ToString(),
                ArchiveDescription = (dr[LinkedArchivesOutputFields.ArchiveDescription.ToString()] is DBNull) ? string.Empty : dr[LinkedArchivesOutputFields.ArchiveDescription.ToString()].ToString(),
                // IsActive = (dr[LinkedArchivesOutputFields.IsActive.ToString()] is DBNull) ? false : Convert.ToBoolean(dr[LinkedArchivesOutputFields.IsActive.ToString()].ToString()),
                PeriodEndDate = (dr[LinkedArchivesOutputFields.PeriodEndDate.ToString()] is DBNull) ? DateTime.MinValue : DateTime.Parse(dr[LinkedArchivesOutputFields.PeriodEndDate.ToString()].ToString()),
                DueDate = (dr[LinkedArchivesOutputFields.DueDate.ToString()] is DBNull) ? DateTime.MinValue : DateTime.Parse(dr[LinkedArchivesOutputFields.DueDate.ToString()].ToString()),
                LinkTypeID = (dr[LinkedArchivesOutputFields.LinkTypeID.ToString()] is DBNull) ? 0 : int.Parse(dr[LinkedArchivesOutputFields.LinkTypeID.ToString()].ToString()),
                LinkedArchiveID = (dr[LinkedArchivesOutputFields.LinkedArchiveID.ToString()] is DBNull) ? 0 : int.Parse(dr[LinkedArchivesOutputFields.LinkedArchiveID.ToString()].ToString()),
                LinkedArchive = (dr[LinkedArchivesOutputFields.LinkedArchive.ToString()] is DBNull) ? string.Empty : dr[LinkedArchivesOutputFields.LinkedArchive.ToString()].ToString(),
                ExpectedDocumentationCompletionDate = (dr[LinkedArchivesOutputFields.EDCD.ToString()] is DBNull) ? DateTime.MinValue : DateTime.Parse(dr[LinkedArchivesOutputFields.EDCD.ToString()].ToString()),
                SubmissionStatusID = (dr[LinkedArchivesOutputFields.SubmissionStatusID.ToString()] is DBNull) ? string.Empty : dr[LinkedArchivesOutputFields.SubmissionStatusID.ToString()].ToString(),
                LinkLevel = (dr[LinkedArchivesOutputFields.LinkLevel.ToString()] is DBNull) ? 0 : int.Parse(dr[LinkedArchivesOutputFields.LinkLevel.ToString()].ToString()),
                IsDirectLink = (dr[LinkedArchivesOutputFields.IsDirectLink.ToString()] is DBNull) ? 0 : int.Parse(dr[LinkedArchivesOutputFields.IsDirectLink.ToString()].ToString()),                
                ParentHierarchy = (dr[LinkedArchivesOutputFields.ParentHierarchy.ToString()] is DBNull) ? 0 : int.Parse(dr[LinkedArchivesOutputFields.ParentHierarchy.ToString()].ToString()),
                ChildCount = (dr[LinkedArchivesOutputFields.ChildCount.ToString()] is DBNull) ? 0 : int.Parse(dr[LinkedArchivesOutputFields.ChildCount.ToString()].ToString()),
                LinkedArchiveName = (dr[LinkedArchivesOutputFields.LinkedArchiveName.ToString()] is DBNull) ? string.Empty : dr[LinkedArchivesOutputFields.LinkedArchiveName.ToString()].ToString(),
                LinkTypeDescription = (dr[LinkedArchivesOutputFields.LinkTypeDesc.ToString()] is DBNull) ? string.Empty : dr[LinkedArchivesOutputFields.LinkTypeDesc.ToString()].ToString(),
                RowNumber = (dr[LinkedArchivesOutputFields.RowNumber.ToString()] is DBNull) ? 0 : int.Parse(dr[LinkedArchivesOutputFields.RowNumber.ToString()].ToString()),
                Count = (dr[LinkedArchivesOutputFields.Count.ToString()] is DBNull) ? 0 : int.Parse(dr[LinkedArchivesOutputFields.Count.ToString()].ToString()),
                IsAcessible = (dr[LinkedArchivesOutputFields.IsAcessAllowed.ToString()] is DBNull) ? 0 : int.Parse(dr[LinkedArchivesOutputFields.IsAcessAllowed.ToString()].ToString()),

                //TemporaryId = (dr[LinkedArchivesOutputFields.TemporaryId.ToString()] is DBNull) ? string.Empty : dr[LinkedArchivesOutputFields.TemporaryId.ToString()].ToString(),
                //CreatedDate = (dr[LinkedArchivesOutputFields.CreatedDate.ToString()] is DBNull) ? DateTime.MinValue : DateTime.Parse(dr[LinkedArchivesOutputFields.CreatedDate.ToString()].ToString()),
                //CreatedBy = (dr[LinkedArchivesOutputFields.CreatedBy.ToString()] is DBNull) ? 0 : int.Parse(dr[LinkedArchivesOutputFields.CreatedBy.ToString()].ToString()),
                //ModifiedDate = (dr[LinkedArchivesOutputFields.ModifiedDate.ToString()] is DBNull) ? DateTime.MinValue : DateTime.Parse(dr[LinkedArchivesOutputFields.ModifiedDate.ToString()].ToString()),
                //ModifiedBy = (dr[LinkedArchivesOutputFields.ModifiedBy.ToString()] is DBNull) ? 0 : int.Parse(dr[LinkedArchivesOutputFields.ModifiedBy.ToString()].ToString()),
                //DeletedDate = (dr[LinkedArchivesOutputFields.DeletedDate.ToString()] is DBNull) ? DateTime.MinValue : DateTime.Parse(dr[LinkedArchivesOutputFields.DeletedDate.ToString()].ToString()),
                //DeletedBy = (dr[LinkedArchivesOutputFields.DeletedBy.ToString()] is DBNull) ? 0 : int.Parse(dr[LinkedArchivesOutputFields.DeletedBy.ToString()].ToString()),
            };
        }

    }
    public enum LinkedArchivesOutputFields
    {
        UniqueID
    , ArchiveID
    , ArchiveNumber
    , ReportingEntity
    , ArchiveDescription
    , PeriodEndDate
    , DueDate
    , LinkTypeID
    , LinkedArchiveID
    , LinkedArchive
    , EDCD
    , SubmissionStatusID
    , TemporaryId
    , CreatedBy
    , CreatedDate
    , ModifiedBy
    , ModifiedDate
    , DeletedBy
    , DeletedDate
    , LinkLevel
    , IsDirectLink
    , ParentHierarchy
    , ChildCount
    , LinkedArchiveName
    , LinkTypeDesc
    , RowNumber
    , Count
    , IsAcessAllowed
    }
}
