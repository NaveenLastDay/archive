export class archiveInfo {
    constructor(public archiveNumber: string,
        public archiveName: string,
        public archiveDescription: string,
        public wbsNumber: string,
        public clientName: string,
        public periodEndDate: string,
        public legalHoldStatus: string,
        public archiveStatus: string) { }

}