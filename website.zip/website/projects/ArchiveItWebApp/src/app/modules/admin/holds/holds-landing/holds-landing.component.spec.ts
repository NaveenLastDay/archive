import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HoldsLandingComponent } from './holds-landing.component';

describe('HoldsLandingComponent', () => {
  let component: HoldsLandingComponent;
  let fixture: ComponentFixture<HoldsLandingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HoldsLandingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HoldsLandingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
