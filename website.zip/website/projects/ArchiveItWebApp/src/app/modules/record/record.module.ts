import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { WorkingPaperComponent } from "./working-paper/working-paper.component";
import { FileuploadProgressComponent } from "./fileUpload-progress/fileupload-progress.component";
import { FormBuilder, FormsModule, ReactiveFormsModule } from "@angular/forms";
import { PaginationComponent } from './../shared/pagination/pagination.component';
import { NotifierModule, NotifierOptions } from "angular-notifier";
import { RouterModule } from "@angular/router";
import { FormatFileSizePipe } from "./../shared/Pipes/format-file-size.pipe";
import { ResizableModule } from "angular-resizable-element";
import { FormatTimePipe } from './../shared/Pipes/format-time.pipe';

import {
  MatMenuModule,
  MatButtonModule,
  MatButtonToggleModule,
  MatTooltipModule
} from "@angular/material";
import { WorkingPaperService } from "../../services/working-paper.service";
import { FileUploadWpModalComponent } from "./working-paper/fileupload.wp.modal.component";
import { CustomModalModule } from "../shared/modal";
import { AngularEditorModule } from '@kolkov/angular-editor';
import { SubstantiationPopupComponent } from './substantiation-popup/substantiation-popup.component';
import { NgxSpinnerModule } from "ngx-spinner"; 

const customNotifierOptions: NotifierOptions = {
  position: {
    horizontal: {
      position: "right",
      distance: 12
    },
    vertical: {
      position: "top",
      distance: 12,
      gap: 10
    }
  },
  theme: "material",
  behaviour: {
    autoHide: 500,
    onClick: "hide",
    onMouseover: "pauseAutoHide",
    showDismissButton: true,
    stacking: 1
  },
  animations: {
    enabled: true,
    show: {
      preset: "slide",
      speed: 200,
      easing: "ease"
    },
    hide: {
      preset: "fade",
      speed: 3000,
      easing: "ease-in",
      offset: 50
    },
    shift: {
      speed: 300,
      easing: "ease"
    },
    overlap: 150
  }
};

@NgModule({
  declarations: [
     //WorkingPaperComponent,
    // FileuploadProgressComponent,
    // FileUploadWpModalComponent,
    // FormatFileSizePipe,
    // FormatTimePipe,
    // SubstantiationPopupComponent
  ],
  imports: [
    CommonModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatMenuModule,
    MatTooltipModule,
    FormsModule,
    ReactiveFormsModule,
    ResizableModule,AngularEditorModule,
    NotifierModule.withConfig(customNotifierOptions),
    RouterModule.forChild([
      {
        path: "workingpapers/:aN",
        component: WorkingPaperComponent,
        data: { title: "Working Papers", showbreadcrumb: "true" }
      }
      
    ]),
    CustomModalModule,
    NgxSpinnerModule
  ],
  providers: [FormBuilder, WorkingPaperService]
})
export class RecordModule {}
