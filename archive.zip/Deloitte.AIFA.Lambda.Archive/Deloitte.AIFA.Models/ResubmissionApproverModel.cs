﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.Models
{
    public class ResubmissionApproverModel
    {
        public int TotalLevelofApproval { get; set; }
        public List<ResubmissionApproverListModel> lstResubmissionApprover { get; set; }
        public string CompletedApprovel  { get; set; }
        public bool CanApprove { get; set; }
    }
}
