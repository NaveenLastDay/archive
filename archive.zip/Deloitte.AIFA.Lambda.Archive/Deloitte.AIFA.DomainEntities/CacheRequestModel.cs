﻿using System.Collections.Generic;

namespace Deloitte.AIFA.DomainEntities
{
    public class CacheRequestModel
    {
        public string Key { get; set; }
        public string Value { get; set; }
        public string ListId { get; set; }
        public List<string> ListItems { get; set; }
        public string ListItem { get; set; }
        public string ListItemNew { get; set; }
    }
}
