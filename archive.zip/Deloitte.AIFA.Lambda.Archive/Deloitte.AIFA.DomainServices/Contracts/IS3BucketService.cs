﻿using Amazon.S3.Model;
using Deloitte.AIFA.DomainEntities;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Deloitte.AIFA.DomainServices.Contracts
{
    public interface IS3BucketService
    {

        Task<DeleteObjectResponse> DeleteObjectAsync(S3BucketModel model);
        Task<CopyObjectResponse> CopyObjectAsync(S3BucketModel model);
    }
}
