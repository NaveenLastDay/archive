import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LinkedArchivesService {
  success: Observable<any>;
  constructor(private _http: HttpClient) { }
  apiData: any;

  httpOptions = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json'
          })
        } 

  public insertLinkedArchives(archiveNumber: string, linkedArchiveNumber: string, createdBy: string): Observable<any> {
    debugger;
    this.success = this._http.post('linkedarchives/InsertLinkedArchiveDetails?archiveNumber=' + archiveNumber
      + '&linkedArchiveNumber=' + linkedArchiveNumber
      + '&createdBy=' + createdBy
      ,this.httpOptions,{responseType: 'text'});
      return this.success;
  }

  public getLinkedArchives(userAlias: string, archiveNumber: string,currentPageNumber:any,pageSize:any,sortBy:any): Observable<any> {
    debugger;
    this.apiData = this._http.get<any>('linkedarchives/GetLinkedArchiveDetails?archivenumber=' + archiveNumber
    + '&userAlias='+userAlias
    + '&pageNumber='+currentPageNumber
    + '&pageSize='+pageSize
    + '&sortBy='+sortBy
   , this.httpOptions);
   return this.apiData;
 }
 public getLinktypes(): Observable<any> {
  this.apiData = this._http.get<any>("linkedarchives/GetLinkingTypes", this.httpOptions);
 return this.apiData;
  }
  
  public UpdateLinkedArchiveDetails(archiveNumber: string, linkedArchiveNumber: string, 
    createdBy: string,linkTypeId:number,OpertaionType:string): Observable<any> {
    this.apiData = this._http.post('linkedarchives/UpdateLinkedArchiveDetails?archiveNumber=' + archiveNumber
    + '&linkedArchiveNumber=' + linkedArchiveNumber
    + '&linkTypeId=' + linkTypeId
    + '&OpertaionType=' + OpertaionType
    + '&createdBy=' + createdBy
    ,this.httpOptions);
    return this.apiData;
  }

}
