import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { AngularEditorConfig } from '@kolkov/angular-editor';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { ModalService } from "../../shared/modal";
import { NgxSpinnerService } from "ngx-spinner";

@Component({
  selector: 'app-substantiation-popup',
  templateUrl: './substantiation-popup.component.html',
  styleUrls: ['./substantiation-popup.component.css']
})
export class SubstantiationPopupComponent implements OnInit {
  @Output() addReason: EventEmitter<string> = new EventEmitter();
  BodyCount: number = 0;
  commentsRemTextLength: number = 0;
  Reason: string = '';
  SubstantiationTitle: string = '';
  SubstantiationDesc: string = '';
  formdata;

  constructor(
    private modalService: ModalService,
    private SpinnerService: NgxSpinnerService,
    private formBuilder: FormBuilder) { }

  /*text editor config*/
  editorConfig: AngularEditorConfig = {

    editable: true,
    spellcheck: true,
    height: 'auto',
    minHeight: '120',
    maxHeight: 'auto',
    width: 'auto',
    minWidth: '0',
    translate: 'yes',
    enableToolbar: true,
    showToolbar: true,
    placeholder: 'Please enter the reason',
    defaultParagraphSeparator: '',
    defaultFontName: '',
    defaultFontSize: '',
    fonts: [
      { class: 'arial', name: 'Arial' },
      { class: 'times-new-roman', name: 'Times New Roman' },
      { class: 'calibri', name: 'Calibri' },
      { class: 'comic-sans-ms', name: 'Comic Sans MS' }
    ],

    customClasses: [
      {
        name: 'quote',
        class: 'quote',
      },
      {
        name: 'redText',
        class: 'redText'
      },
      {
        name: 'titleText',
        class: 'titleText',
        tag: 'h1',
      },
    ],
    uploadUrl: '',
    uploadWithCredentials: false,
    sanitize: true,
    toolbarPosition: 'top',
    toolbarHiddenButtons: [
      [
        'undo',
        'redo',
        'subscript',
        'superscript',
        'justifyFull',
        'indent',
        'outdent',
        'insertOrderedList',
        'heading',
        //'fontName'
      ],
      [
        'textColor',
        'backgroundColor',
        'customClasses',
        'link',
        'unlink',
        'insertImage',
        'insertVideo',
        'insertHorizontalRule',
        'removeFormat',
        'toggleEditorMode'
      ]
    ]
  };
  ngOnInit() {
    this.SubstantiationValidation();
  }
  SubstantiationValidation() {
    this.formdata = this.formBuilder.group({
      description: ['', [Validators.required,
      Validators.maxLength(600), Validators.minLength(5)]]
    });
  }
  openModalDialog(Action, reason) {
    debugger;
    if (Action == "Add" || Action == "Edit") {
      this.SubstantiationTitle = 'Substantiation for no working papers';
      this.SubstantiationDesc=" Document the circumstances under which no working papers are required to be archived and click Save or Cancel to return to the current section.";
      if (Action == "Add") {
        this.Reason = "";
        this.BodyCount = 0;
      }
      else {
        this.Reason = reason;
        this.BodyCount = 600 - reason.length;
      }
      this.modalService.openWithCustomWidth('substantiation-popup-modal', "600");
    }
    else if(Action == "AddDel" || Action == "EditNoDel") {
      this.SubstantiationTitle = 'Substantiation for no deliverables';
      this.SubstantiationDesc=" Document the circumstances under which no deliverables are required to be archived and click Save or Cancel to return to the current section.  DPM 3610C.29 requires that all deliverables are imported into the Deliverables section of Archive It Audit.";
      if (Action == "AddDel") {
        this.Reason = "";
        this.BodyCount = 0;
      }
      else {
        this.SubstantiationTitle = 'Edit Substantiation';
        this.Reason = reason;
        this.BodyCount = 600 - reason.length;
      }
      this.modalService.openWithCustomWidth('substantiation-popup-modal', "600");
    }    
    else if(Action=="ArchiveRejectReasonsAdd")
    {
      //ArchiveRejectReasonsAdd

      this.SubstantiationTitle="Reject";     
      this.SubstantiationDesc="Provide the reason";
       this.Reason = "";
        this.BodyCount = 0;
      this.modalService.openWithCustomWidth('substantiation-popup-modal', "600");

    }



  }

  stripHtml(html: string) {
    // Create a new div element
    var temporalDivElement = document.createElement("div");
    // Set the HTML content with the providen
    temporalDivElement.innerHTML = html;
    // Retrieve the text property of the element (cross-browser support)
    return temporalDivElement.textContent || temporalDivElement.innerText || "";
  }

  closeModalDialog(Action) {
    this.modalService.close(Action);
  }


  onKeyUpBody(boxInput, keyCode) {
    //this.rejectionDiscrption = this.rejectionDiscrption.replace(/<\/?[^>]+(>|$)/g, "").trim('');
      if (this.Reason.length >=600 )  // 32=> Space Bar,  Enter => 13, Tab=> 9
   {

     if(keyCode > 47 || keyCode == 32 || keyCode == 9 || keyCode == 13)
    { event.preventDefault();

    }
     
   }
 }


  onPaste(previousdData, event: ClipboardEvent) {
    // debugger;
  
     let previousdDataCount = this.stripHtml(previousdData).length;
    let clipboardData = event.clipboardData;
    let pastedText = clipboardData.getData('text');
    let PastedTextCount = this.stripHtml(pastedText).length;
    let totTextCount = previousdDataCount + PastedTextCount;

    var concatenatedText = previousdData + pastedText;
    if (totTextCount > 600) {
      event.preventDefault();
      this.Reason = concatenatedText.substring(0, 600)
      this.BodyCount = 0;

    }
    
  }




  ResetForm() {
    this.Reason = "";
    this.BodyCount = 0;
    this.SubstantiationValidation();
  }
  SaveSubstantiation() {
    if (this.formdata.invalid) {
      this.formdata.get('description').markAsTouched();
    }
    else {
      this.addReason.emit(this.Reason);
      this.closeModalDialog('substantiation-popup-modal');
    }
  }
}
