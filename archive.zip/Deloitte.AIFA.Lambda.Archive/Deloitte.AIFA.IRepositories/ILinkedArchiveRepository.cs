﻿using Deloitte.AIFA.DomainEntities;
using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.IRepositories
{
    public interface ILinkedArchiveRepository
    {
        List<LinkedArchives> GetListofLinkedArchiveDetails(string userAlias, string archiveNumber, int pageNumber, int pageSize, int sortBy);
        List<LinkTypes> GetLinkingTypes();
        string InsertLinkedArchiveDetails(string archiveNumber, string linkedArchiveNumber, string createdBy);
        bool UpdateLinkedArchiveDetails(string archiveNumber, string linkedArchiveNumber, int? linkTypeId, string opertaionType, string createdBy);
    }
}
