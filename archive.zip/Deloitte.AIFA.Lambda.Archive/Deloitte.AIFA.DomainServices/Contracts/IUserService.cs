﻿using Deloitte.AIFA.DataModels;
using Deloitte.AIFA.DomainEntities;
using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainServices.Contracts
{
    public interface IUserService
    {
        List<UserDetail> FetchLoggedInUser(string userName);

        RoleMapping GetRoleMappingsForUser(string UserAlias, string ArchiveNumber);
		List<FooterConfigurationDataModel> GetFooterConfigurationData();

        UserOfflinePermissions FetchUserofflinePermissions(string userAlias);
    }
}
