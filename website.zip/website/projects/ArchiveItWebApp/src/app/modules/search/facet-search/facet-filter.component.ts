import { Component, OnInit, Input, OnChanges, SimpleChanges } from '@angular/core';
import { FormGroup, FormBuilder, FormArray, Validators } from '@angular/forms';
import { NgbDateStruct } from "@ng-bootstrap/ng-bootstrap";
import { SearchEventService } from '../search.event.service';

@Component({
    selector: 'facet-filter',
    templateUrl: './facet-filter.component.html',
    styleUrls: ['./facet-filter.component.css']
})
export class FacetFilterComponent implements OnInit, OnChanges {

    selectedItems = [];
    pageindex = 0;
    pagesize = 5;
    search = "";
    endDate: NgbDateStruct;
    estimatedate: any;
    advancefilter: boolean = true;
    labeltextfrom: string = 'From';
    labeltextto: string = 'To';
    enableShowMore: boolean = false;
    enableBack:boolean=false;


    @Input() dataSource = [];
    @Input() filterTitle?: string;
    @Input() filterId?: string;

    constructor(private fb: FormBuilder, private searchEventService: SearchEventService) {
    }

    filterFormGroup: FormGroup = this.fb.group({
        searchtext: this.fb.control(''),
        list: this.fb.array([])
    });
    searchFormGroup: FormGroup = this.fb.group({
        list: this.fb.array([])
    });

    ngOnInit() {

        this.filterFormGroup.get('searchtext').valueChanges.subscribe(val => {
            this.pageindex = 0;
            this.search = val;
            this.bindSearchControl();
        });
        this.searchEventService.clearFacets.subscribe(data => {
            this.bindData();
            this.loadlistArray();

        });
    }

    ngOnChanges(changes: SimpleChanges): void {
        this.bindData();
        this.loadlistArray();
    }

    get listArray() {
        return this.filterFormGroup.get('list') as FormArray;
    }

    get searchlistArray() {
        return this.searchFormGroup.get('list') as FormArray;
    }

    bindData() {
        this.searchlistArray.clear();
        if (this.dataSource) {
            for (var j = 0; j < this.dataSource.length; j++) {
                if (this.dataSource[j] && this.dataSource[j] != "none") {
                    this.searchlistArray.push(
                        this.fb.group({
                            key: [''],
                            value: [this.dataSource[j]]
                        })
                    )
                }

            }
        }
    }

    loadlistArray() {
        this.pageindex = 0;
        this.bindSearchControl();
    }

    show5more() {
        this.pageindex = this.pageindex + 1;
        this.bindSearchControl();
    }

    previousitems() {
        if (this.pageindex > 0) {
            this.pageindex = this.pageindex - 1;
            this.bindSearchControl();
        }
    }

    bindSearchControl() {
        var start = this.pageindex * this.pagesize;
        var end = start + this.pagesize;
        
        

        if (this.search) {
            var sr = this.searchlistArray.controls.filter(x => x.value.value.toLowerCase().indexOf(this.search.toLowerCase()) != -1);
            this.enableBack= this.pageindex!=0 ? true: false;
            this.enableShowMore = sr.length > 5 && (this.pageindex+1)!=Math.ceil(sr.length/5) ? true : false;
            this.listArray.controls = this.searchlistArray.controls.filter(x => x.value.value.toLowerCase().indexOf(this.search.toLowerCase()) != -1).slice(start, end);
        }
        else {
            var r = this.searchlistArray.controls;
        
            this.enableBack= this.pageindex!=0 ? true: false;
           
            this.enableShowMore = r.length > 5 && (this.pageindex+1)!=Math.ceil(r.length/5) ? true : false;
            this.listArray.controls = this.searchlistArray.controls.slice(start, end);
        }
    }

    onselect($event, selectedItem) {
        this.searchEventService.enablePageCount=false;
        this.searchEventService.finalSelectedJson.isKeywordbaseSearch = true;
        
        if ($event.target.checked) {
            this.searchEventService.facesetJson.push({
                field: this.filterId,
                value: selectedItem
            });
            this.searchEventService.selectedFacetsCount++;
        } else {
            this.selectedItems = this.selectedItems.filter(x => x != selectedItem);
            this.searchEventService.facesetJson = this.searchEventService.facesetJson.filter(x => !(x.field == this.filterId && x.value == selectedItem))
            this.searchEventService.selectedFacetsCount--;

        }
        this.searchEventService.finalSelectedJson.rules[this.filterId] =
            this.searchEventService.facesetJson.filter(x => x.field == this.filterId).map(y => y.value);
        var facetSelectedItems = this.searchEventService.facesetJson.filter(x => x.field == this.filterId);
        if (facetSelectedItems.length == 0) {
            this.searchEventService.finalSelectedJson.rules[this.filterId] = this.searchEventService.finalBackupJson[this.filterId];
        }
        
        this.searchEventService.onTriggerAdvanceSearch();
        // console.log(this.searchEventService.finalSelectedJson);
    }

}
