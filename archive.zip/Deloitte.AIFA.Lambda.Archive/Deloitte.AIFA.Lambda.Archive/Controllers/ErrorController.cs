﻿using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Deloitte.AIFA.Lambda.Archive.Controllers
{
    [Route("error")]
    [ApiController]
    public class ErrorController : ControllerBase
    {
        ILogger _logger;
        public ErrorController(ILogger<ErrorController> logger)
        {
            _logger = logger;
        }

        [Route("log")]
        public IActionResult LogError()
        {
            var exceptionFeature = HttpContext.Features.Get<IExceptionHandlerPathFeature>();
            if (exceptionFeature != null)
            {
                _logger.LogError(((ExceptionHandlerFeature)exceptionFeature).Error.StackTrace.ToString());
                return StatusCode(StatusCodes.Status500InternalServerError, ((ExceptionHandlerFeature)exceptionFeature).Error.Message);
            }
            else
            {
                return Ok();
            }
        }
    }
}