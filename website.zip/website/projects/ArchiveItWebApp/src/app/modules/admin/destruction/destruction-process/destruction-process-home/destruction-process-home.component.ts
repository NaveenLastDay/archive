import { Component, OnInit } from '@angular/core';
import { NotifierService } from 'angular-notifier';
import { NgxSpinnerService } from 'ngx-spinner';
import { DestructionService } from '../../../../../services/destruction.service';

@Component({
  selector: 'app-destruction-process-home',
  templateUrl: './destruction-process-home.component.html',
  styleUrls: ['./destruction-process-home.component.css']
})
export class DestructionProcessHomeComponent implements OnInit {
batchID:string;
currentPageNumber: number = 1;
readonly pageSize: number = 4;
sortdesc: number;
filterBy: number = 0;
sortColumn : string ='';
searchBatchNumber : string ='';
isDTScreen: number=1;
  /*Pagination Param's*/
  appendWPtoGrid : boolean = false;
  showDetailsGrid : boolean= true;
  /* */
batchData : any[];
totalBatches: number = 0;
  constructor(private destructionService: DestructionService, private SpinnerService: NgxSpinnerService, private notifier: NotifierService) { }

  ngOnInit() {
    this.getBatchData();
  }
  getBatchData() {
    this.destructionService.GetBatchInfo(this.currentPageNumber, this.pageSize, this.sortdesc, this.filterBy, this.sortColumn,this.searchBatchNumber,this.isDTScreen).subscribe(
      data => {
        if (data.length > 0)
        {
          this.showDetailsGrid=true;
          this.batchData = data ? data : [];
          this.totalBatches = data[0]['recordsCount'];
          this.SpinnerService.hide();
        }
        else{
          this.showDetailsGrid=false;
          this.SpinnerService.hide();
        }
      },
        err => {
          this.notifier.notify("error", "Error occurred while fetching destruction batch");
          this.showDetailsGrid=false;
          this.SpinnerService.hide();
        }

    );
  }
  updateGridData(event) {
    //this.SpinnerService.show();
    this.appendWPtoGrid = event.isLoadMoreClicked;
    this.currentPageNumber = event.pageNumber;
    this.destructionService.GetBatchInfo(this.currentPageNumber, this.pageSize, this.sortdesc, this.filterBy, this.sortColumn,this.searchBatchNumber,this.isDTScreen).subscribe(
      data => {
        if (this.appendWPtoGrid && data) {
            for(var i =0;i<data.length;i++){
              this.batchData.push(data[i]);
            }
          }
          else{
              this.batchData = data ? data : [];
          }

      }
    );
  }
}
