import { Component, OnInit} from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ArchiveService } from '../../../services/archive.service';
import { FormControl, FormGroup, FormBuilder, Validators, FormArray, NgForm } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
import { ModalService } from '../../shared/modal';
import { ArchiveHomeService } from '../../../services/archive-home.service';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { AngularEditorConfig } from '@kolkov/angular-editor';
import { NotifierService } from 'angular-notifier';
import { UserActions } from '../../../models/archive-role.model';
import { Console } from 'console';
import { PubsubService } from '../../../services/pubsub.service';
import { truncate } from 'fs';

@Component({
  selector: 'app-engagement-info',
  templateUrl: './engagement-info.component.html',
  styleUrls: ['./engagement-info.component.css']
})
export class EngagementInfoComponent implements OnInit {
  login_form: FormGroup;
  archiveNumber: string;
  archiveDetailsData: any;
  TitleCount: number = 0;
  AdditionalDescriptorcount: number = 0;


  //Assigning variable for Dropdown
  EngagementType: number = 0;
  engagements: any;
  entitytype: number;
  entities: any;
  archivenames: any;

  IsSectionVisited: any;

  //Variables get selected values
  selectedEngagementType: string;
  selectedEntityType: string;
  selectedEntity: string;
  selectedArchiveType: string;

  // Assigning Variable
  EngagementDescription: string = "";
  AdditionalDescriptor: string = "";
  engagementtype: string = "";
  wbsLevelOneNumberValue: string = "";
  EngagementTypeValue: string = "";
  entityAssociatedValue: string = "";
  standardsAppliedValue: string = "";

  ShowContentForEdit: number = 0;
  popUpHeaderText: string = "";
  result: any;

  toDate: Date = undefined;
  BodyCount: number = 0;
  success: any;
  sectionid: number = 1;
  commentsRemTextLength: number = 0
  rejectionDiscrption: any = "";
  hideRejectedMessage: boolean = false;
  ApproveDisabled: boolean = true;
  showEdit: boolean = false;
  ApprovedisabledColor: any;
  ArchiveDetailsEditedDate:Date;
  ArchiveDetailsEditedInResubmit:boolean;
  ArchiveDetailsProvidedInResubmit:string="";
  rejectedBy: any;
  isSectionApproved: boolean = false;
  isSectionRejected: boolean = false;
  topCss: any;
  FooterCss:any;
  Popupcss:any;
  IsApproved: number = 0;
  comments: string = "";
  changeDecision: boolean = false;
  rejectedDate: any = "";
  RejectdisabledColor: any;
  userAlias =this.adalSvc.LoggedInUserEmail.substring(0, this.adalSvc.LoggedInUserEmail.lastIndexOf("@"));
  isApprover: boolean = false;
  indArchiveDetailStatus: number = 3;
  archiveFlowIndividualActions: any[];
  RejectedReasonForm: FormGroup;
  EditEnable:boolean=true;
  enableSave:boolean=false;
  showAdditionalDescriptor: boolean=false;
  AdditionalDescriptorOrig :string="";
  AdditionalDescriptorFlag :boolean=false;


  roleMapping = new UserActions();
  //Added below variables for enabling & disabling the controls during edit & view only mode.
  EditArchiveDetailsForm: boolean;
  ReadOnlyArchiveDetails: boolean;
  CurrentArchiveStatusforArchiveDetails: any;
  SaveChangestoArchiveDetailsForm: boolean;
  ShowApproveRejectButtons: boolean;
  ResubmissionReasonForArchiveDetailsSection: any = "";
  IsChangeDecissionClicked: boolean=false;

  constructor(
    private pubsub: PubsubService,
    private activatedRoute: ActivatedRoute,
    private SpinnerService: NgxSpinnerService,
    private service: ArchiveService,
    private router: Router,
    private modalService: ModalService,
    private archiveHomeService: ArchiveHomeService,
    private adalSvc: MsAdalAngular6Service,
    private notifier: NotifierService,
    public fb: FormBuilder
  ) {
    this.login_form = fb.group({
      'engagementDes': ['', Validators.compose([Validators.required, Validators.minLength(5)])],
      'EngagementType': [null, Validators.required],
      'entityAssociated': [null, Validators.required],
      'standardsApplied': [null, Validators.required],
      'WBSlevelOneNumber': [null, Validators.required],
      'PeriodEndDate': [null, Validators.required],
      'terms': [false]
    });
    this.roleMapping = this.pubsub.getRoleMappingResult();


  }



  editorConfig: AngularEditorConfig = {

    editable: true,
    spellcheck: true,
    height: '276px',
    minHeight: '0',
    maxHeight: '100px',
    width: 'auto',
    minWidth: '0',
    translate: 'yes',
    enableToolbar: true,
    showToolbar: true,
    placeholder: 'Please enter the reason',
    defaultParagraphSeparator: '',
    defaultFontName: '',
    defaultFontSize: '',
    fonts: [
      { class: 'arial', name: 'Arial' },
      { class: 'times-new-roman', name: 'Times New Roman' },
      { class: 'calibri', name: 'Calibri' },
      { class: 'comic-sans-ms', name: 'Comic Sans MS' }
    ],

    customClasses: [
      {
        name: 'quote',
        class: 'quote',
      },
      {
        name: 'redText',
        class: 'redText'
      },
      {
        name: 'titleText',
        class: 'titleText',
        tag: 'h1',
      },
    ],
    uploadUrl: '',
    uploadWithCredentials: false,
    sanitize: true,
    toolbarPosition: 'top',
    toolbarHiddenButtons: [
      [
        'undo',
        'redo',
        'subscript',
        'superscript',
        'justifyFull',
        'indent',
        'outdent',
        'insertOrderedList',
        'heading',
        //'fontName'
      ],
      [
        'textColor',
        'backgroundColor',
        'customClasses',
        //'link',
        'unlink',
        'insertImage',
        'insertVideo',
        'insertHorizontalRule',
        'removeFormat',
        'toggleEditorMode'
      ]
    ]
  };

  ngOnInit() {
    this.enableSave=false;
    this.Initialize();
    // this.login_form.valueChanges.subscribe(selectedValue  => {
    //   console.log('I am ngonit')
    //  // console.log(selectedValue)
    //   this.enableSave=true;
    //   console.log("enablesave in onit" + this.enableSave);
    //   //alert('form value changed')
    // });

    // this.login_form.get("WBSlevelOneNumber").valueChanges.subscribe(selectedValue  => {
    //   console.log('descrption changed');
    //   console.log(selectedValue)
    // })


  }



  ngAfterViewInit() {
    console.log('I am ngafterviewinit')
    this.enableSave=false;
    console.log("enablesave in ngAfterViewInit" + this.enableSave);

  }
  ngDoCheck() {

    this.roleMapping = this.pubsub.getRoleMappingResult();
    if(this.login_form.dirty || this.AdditionalDescriptorFlag )
    {

     this.enableSave =true;

     console.log('ng do check')
    }

  }

  Initialize() {
    //this.SpinnerService.show();

    this.geteditArchiveDetail();
    this.IsUserApprover(this.archiveNumber, this.userAlias);
    this.TitleCount = 250;
    this.AdditionalDescriptorcount = 20;
    localStorage['IsSectionVisited'] = '0';
    console.log("LocalStorage ReSet to 0 in AD for AR (248):",localStorage['IsSectionVisited']);
  //  this.SpinnerService.hide();
  }


  IsUserApprover(archivenumber, userlias) {

    //this.SpinnerService.show();

    var data = JSON.parse(localStorage.getItem('archiveSubmissionStatusData'));
        console.log('ArchiveDetailsarchiveSubmissionStatusData',data);
    // this.archiveHomeService.IsUserApprover(archivenumber, userlias).subscribe(
    //   (data) => {

        if (data != undefined) {
          this.isApprover = data.canApprove;
          this.CurrentArchiveStatusforArchiveDetails = data.archiveInfo.archiveStatus;

          // this.archiveFlowIndividualActions = data.archiveAtcionsForIndividualSections;
          // //Assigning Individual Section Statuses//
          // if(this.archiveFlowIndividualActions.length > 0){
          //     this.indArchiveDetailStatus = this.archiveFlowIndividualActions[0].actionsTypeId;
          // }
              //Section Rejected. Get comments only when the section is rejected
          //1. Approved
          //2. Rejected
          //3. Edited
          this.Getsectioncomments(1,2);
          this.indArchiveDetailStatus =  localStorage['indArchiveDetailStatus'];
          // if (this.indArchiveDetailStatus == 2) {
          //   this.Getsectioncomments(1,2);
          // }

          // else {
          //   this.HideorShowlogic();
          // }


          //Added newly to Enable/Disable Controls
          //ShowContentForEditDeliverables will hide
          //DisableSelectCheckboxes will disable the Select all & individual checkboxes for each deliverable added.
          // debugger;

          // if(this.CurrentArchiveStatusforArchiveDetails=="Ready For Approval")
          // {
          //  if(this.isApprover ===false)
          //   {
          //     this.showEdit=false;
          //     this.ReadOnlyArchiveDetails=true;
          //   }
          //   else if(this.isApprover===true && this.isSectionRejected==false)
          //   {
          //     this.showEdit=true;
          //     this.ShowApproveRejectButtons=true;
          //     // this.ShowContentForEdit=1;  // Conflict why both are true
          //     // this.ReadOnlyArchiveDetails=true;
          //     this.geteditArchiveDetail();
          //   }
          //   else if(this.isApprover===true && this.isSectionRejected==true)
          //   {
          //     this.showEdit=true;
          //     this.ShowApproveRejectButtons=true;
          //     this.ShowContentForEdit=1;
          //     this.ReadOnlyArchiveDetails=true;
          //     this.geteditArchiveDetail();
          //     if (this.comments !== "") {
          //       this.topCss = {
          //         'top': '165px',
          //        'height': '50%'
          //      }
          //     }
          //   }
          // }
          // else if(this.CurrentArchiveStatusforArchiveDetails=="Approved"){
          //   this.showEdit=false;
          //   this.ReadOnlyArchiveDetails=true;
          // }
          // // else if(this.CurrentArchiveStatusforArchiveDetails=="Open")
          // // {
          // //   this.ShowContentForEdit=1;
          // //   this.EditArchiveDetailsForm=true;
          // //   this.SaveChangestoArchiveDetailsForm=true;
          // //   this.SetSection(this.comments, this.IsApproved);
          // //   this.geteditArchiveDetail();
          // // }
          // else if(this.CurrentArchiveStatusforArchiveDetails=="Rejected")
          // {
          //   this.ShowContentForEdit=1;
          //   this.EditArchiveDetailsForm=true;
          //   this.SaveChangestoArchiveDetailsForm=true;
          //   this.geteditArchiveDetail();
          //   if (this.comments !== "") {
          //     this.topCss = {
          //       'top': '165px',
          //      'height': '50%'
          //    }
          //   }
          // }
          // //  else if((this.CurrentArchiveStatusforArchiveDetails==="Resubmitted – Open"))
          // //  {
          // //   this.ShowContentForEdit=1;
          // //   this.EditArchiveDetailsForm=true;
          // //   this.SaveChangestoArchiveDetailsForm=true;
          // //   // this.isSectionRejected = false;  // Conflict with open status. Why the setsection itself is not called
          // //   // this.isSectionApproved = false;
          // //   this.geteditArchiveDetail();
          // // }
          // else if((this.CurrentArchiveStatusforArchiveDetails==="Resubmitted - Ready for Approval")){
          //   this.GetResubmissionApprovalFlow();
          // }
        }
      // });

     // this.SpinnerService.hide();
  }




  GetResubmissionApprovalFlow() {
    //debugger;
    var inparameters = {
      "ArchiveNumber": this.archiveNumber,
      "UserAlias": ''
    }
    var parameters = JSON.stringify(inparameters);
    this.archiveHomeService.GetResubmissionApprovalFlowStatuses(parameters).subscribe(
      (obj) => {
        this.isApprover = obj[0].canApprove;

        //2nd and 3rd level
        if(obj[0].completedApprovel>=1){
          this.isApprover=false;
        }

        //  //1st level by default read only view (After clicking it will be in edit modw)
        // else if(obj[0].completedApprovel==0){
        //               if(localStorage['isFirstLevelEdited']=="null" || localStorage['isFirstLevelEdited']==0)
        //               this.isApprover=false;
        // }

        if (this.isApprover) {
          this.specificViewToApprover();
          this.archiveHomeService.GetResubmissionReasonsforArchive(this.archiveNumber).subscribe(data=>{

            if(data){
             if(data.length>0)
             {
              this.ArchiveDetailsEditedInResubmit=data[0].actionTypeId==3?true:false;
              this.ArchiveDetailsProvidedInResubmit=data[0].comments!=""?data[0].comments:"";
              this.ArchiveDetailsEditedDate=data[0].rejectedDate;
             }
            //  if(this.indArchiveDetailStatus == 1 && this.ArchiveDetailsProvidedInResubmit!="")  {
            //   this.topCss = {
            //     'top': '220px'
            //   }
            //   this.FooterCss={
            //     'top':'817px'
            //   }
            // }
            // if(this.indArchiveDetailStatus == 2 && this.ArchiveDetailsProvidedInResubmit!="")  {
            //   this.topCss = {
            //     'top': '330px'
            //   }
            //   this.Popupcss={
            //     'top':'6px'
            //   }
            //   this.FooterCss={
            //     'top':'817px'
            //   }
            // }
            // if(this.ArchiveDetailsProvidedInResubmit!="" && (this.indArchiveDetailStatus != 1 && this.indArchiveDetailStatus != 2))
            // {
            //   this.topCss = {
            //     'top': '220px'
            //   }
            //   this.FooterCss={
            //     'top':'817px'
            //   }
            // }
          }
          });
        }

        else {
          this.CommonViewForReadonly();
          this.archiveHomeService.GetResubmissionReasonsforArchive(this.archiveNumber).subscribe(data=>{

            if(data){
             if(data.length>0)
             {
              this.ArchiveDetailsEditedInResubmit=data[0].actionTypeId==3?true:false;
              this.ArchiveDetailsProvidedInResubmit=data[0].comments!=""?data[0].comments:"";
              this.ArchiveDetailsEditedDate=data[0].rejectedDate;
             }
            //  if(this.indArchiveDetailStatus == 1 && this.ArchiveDetailsProvidedInResubmit!="")  {
            //   this.topCss = {
            //     'top': '220px'
            //   }
            // }
            // if(this.indArchiveDetailStatus == 2 && this.ArchiveDetailsProvidedInResubmit!="")  {
            //   this.topCss = {
            //     'top': '220px'
            //   }
            //   this.Popupcss={
            //     'top':'65px'
            //   }
            // }
            // if(this.ArchiveDetailsProvidedInResubmit!="" && (this.indArchiveDetailStatus != 1 && this.indArchiveDetailStatus != 2))
            // {
            //   this.topCss = {
            //     'top': '220px'
            //   }
            // }
          }
          });
        }

        //
        // if (this.isApprover === true && this.isSectionRejected == false) {
        //   this.showEdit = true;
        //   this.EditEnable=true;
        //   this.ShowApproveRejectButtons = true;
        //   this.ShowContentForEdit = 1;
        //   this.ReadOnlyArchiveDetails = true;
        //   this.geteditArchiveDetail();
        //   this.topCss = {
        //     'top': '75px'
        //   }
        // }
        // else if (this.isApprover === true && this.isSectionRejected == true) {
        //   this.showEdit = true;
        //   this.EditEnable=true;
        //   this.ShowApproveRejectButtons = false;
        //   this.ShowContentForEdit = 1;
        //   this.ReadOnlyArchiveDetails = true;
        //   this.geteditArchiveDetail();
        //   if (this.comments !== "") {
        //     this.topCss = {
        //       'top': '165px',
        //       'height': '50%'
        //     }
        //   }
        // }
        // else {
        //   this.ShowContentForEdit = 0;
        //   this.ReadOnlyArchiveDetails = true;
        // }
        // this.geteditArchiveDetail();
        //
      },
      (err) => {
        console.log("error is ", err)
      }
    );


  }
  // onKeyUpBody(boxInput) {
  //   var bodytext = boxInput.replace(/<\/?[^>]+(>|$)/g, "").trim('');
  //   if(bodytext.length<=250){
  //     // this.BodyCount = 250 - bodytext.length;
  //     this.rejectionDiscrption=boxInput;
  //   }
  //   // if (bodytext.length <= 250) {
  //   //   this.BodyCount = 250 - bodytext.length;
  //   //   this.rejectionDiscrption = boxInput;
  //   // }
  //   // else if (bodytext.length > 250) {
  //   //   let comments = boxInput;
  //   //   this.rejectionDiscrption = comments.slice(0, 250);
  //   //   this.rejectionDiscrption = this.rejectionDiscrption;
  //   // }


  // }

  stripHtml(html: string) {
    // Create a new div element
    var temporalDivElement = document.createElement("div");
    // Set the HTML content with the providen
    temporalDivElement.innerHTML = html;
    // Retrieve the text property of the element (cross-browser support)
    return temporalDivElement.textContent || temporalDivElement.innerText || "";
  }


  onKeyUpBody(boxInput, keyCode) {
    //this.rejectionDiscrption = this.rejectionDiscrption.replace(/<\/?[^>]+(>|$)/g, "").trim('');
    if (this.rejectionDiscrption.length >= 250)  // 32=> Space Bar,  Enter => 13, Tab=> 9
    {

      if (keyCode > 47 || keyCode == 32 || keyCode == 9 || keyCode == 13) {
        event.preventDefault();

      }

    }
  }


  onPaste(previousdData, event: ClipboardEvent) {
    // debugger;
    //this.rejectionDiscrption = this.rejectionDiscrption.replace(/<\/?[^>]+(>|$)/g, "").trim('');
    let previousdDataCount = this.stripHtml(previousdData).length;
    let clipboardData = event.clipboardData;
    let pastedText = clipboardData.getData('text');
    let PastedTextCount = this.stripHtml(pastedText).length;
    let totTextCount = previousdDataCount + PastedTextCount;
    var concatenatedText = previousdData + pastedText;
    if (totTextCount > 250) {
      event.preventDefault();
      this.rejectionDiscrption = concatenatedText.substring(0, 250)
      this.BodyCount = 0;
    }


  }

  showModelDialog(Action) {
    // debugger;
    //this.rejectionDiscrption = this.rejectionDiscrption.replace(/<\/?[^>]+(>|$)/g, "").trim('');
    this.popUpHeaderText = "Edit rejectionReason";
    if ((Action === "Reject" && this.rejectionDiscrption != "") || Action === "Edit") {
      this.BodyCount = 250 - this.rejectionDiscrption.length;
      this.rejectionDiscrption = this.comments;
    }
    else if (Action === "Reject" && this.rejectionDiscrption == "") {
      this.rejectionDiscrption = "";
      this.BodyCount = 250;
    }

    if(Action === "Edit")
    {
      localStorage['IsRejectionCommentsEdited']=1;
    }
    this.modalService.openWithCustomWidth("reject-retention-modal", "640");

  }

  closeModalDialog(Action) {
    if(Action=='reject-retention-modal' ||Action=='savechange-details-modal')
    {
      this.modalService.close(Action);
      this.Getsectioncomments(1,2);
    }
    else {
      this.modalService.close(Action);

      //this.rejectionDiscrption = "";
    }

  }
  //This method is to save the reasons related to archive section
  SaveArchiveDetailSectionReason() {
   // this.SpinnerService.show();
    var reasonparameters =
    {
      "ArchiveNumber": this.archiveNumber,
      "Comment": this.ResubmissionReasonForArchiveDetailsSection,
      "CreatedBy": '',
      "CommentCategoryId": 7,
    }
    this.archiveHomeService.SavereasonsForArchiveDetails(reasonparameters).subscribe(data => {
      if (data == false) {
        this.notifier.notify("error", "Reasons are not saves successfully");
      }
      else {
        console.log("Archive Details Reasons are saved successfully");
        // this.router.navigate(['/archive/myarchives/' + this.archiveNumber + '/archivehome'])
        // .then(() => {
        //   location.reload();
        // });
        setTimeout(() => { this.router.navigate(["archive/myarchives/" + this.archiveNumber + '/archivehome']) }, 5000);
      }
    })
   // this.SpinnerService.hide();

  }

  OnApproveOrRejection(ActionType) {

    //this.rejectionDiscrption = this.rejectionDiscrption.replace(/<\/?[^>]+(>|$)/g, "").trim('');
    var parameters =
    {
      "ArchiveNumber": this.archiveNumber,
      "ArchiveSectionId": this.sectionid,
      "ActionTypeId": ActionType,
      "Comments": this.rejectionDiscrption,
      "CreatedBy": ''
    }
    // debugger;
    if (this.rejectionDiscrption === "" && ActionType === 2) {
      this.notifier.notify("error", "Please write down the reason for Rejection");
    }
    else if (this.rejectionDiscrption.length < 5 && ActionType === 2) {
      this.notifier.notify("error", "Rejection Comments must be 5 characters");
    }
    else if (this.rejectionDiscrption.length > 250 && ActionType === 2) {
      this.notifier.notify("error", "Rejection Comments cannot exceed 250 characters");
    }
    else {
      //debugger;
      var myobjstr = JSON.stringify(parameters);
     // this.SpinnerService.show();
      this.archiveHomeService.OnApproveOrRejection(myobjstr)
        .subscribe(
          data => {
            // debugger;
            if (data == "success" && ActionType == 1) {
              // setTimeout(() => { this.notifier.notify("success", "Approvel Successfully") }, 500);
            }
            else if (data == "success" && ActionType == 2) {
              if(localStorage['IsRejectionCommentsEdited']==1)
              {
                setTimeout(() => { this.notifier.notify("success", "Updated Successfully") }, 500);
                localStorage['IsRejectionCommentsEdited']=0;
              }
// else{
//   setTimeout(() => { this.notifier.notify("success", "Rejected Successfully") }, 500);
// }


            }
            this.success = data;
            this.ApproveDisabled = true;
            console.log(this.success);
           // this.SpinnerService.hide();
            let CurrentURL = this.router.url;
            let urlList = CurrentURL.split("/");
            this.archiveNumber = urlList[urlList.length - 2];
            if(!this.IsChangeDecissionClicked)
            {
            localStorage['IsSectionVisited'] = '1';
            console.log("LocalStorage Set to 1 in AD for AR (676):",localStorage['IsSectionVisited']);
            }

            if (ActionType != "3") {
              // this.router.navigate(['/archive/myarchives/' + this.archiveNumber + '/archivehome']).then(() => {
              //   location.reload();
              // });
              setTimeout(() => { this.router.navigate(["archive/myarchives/" + this.archiveNumber + '/archivehome']) }, 50);
              this.closeModalDialog('reject-retention-modal');
            }
          }

        );
    }
  }

  SetSection(comments, IsApproved) {
    var comments = comments.replace(/<\/?[^>]+(>|$)/g, "").trim('');
    //This If condition will execute when the Archive Details section is not Approved/Rejected
    //Open,Resubmit-Open,Initial RFA, Initial Resubmit-RFA
    // Section is not approved or Rejected
    if ((comments === "" && IsApproved === 0)) {

      this.isSectionRejected = false;
      this.isSectionApproved = false;

      // this.ApprovedisabledColor = {
      //   'background': '#007CB0'
      // };
      // this.RejectdisabledColor = {
      //   'background': '#F8F8FA'
      // }
      //this.ApproveDisabled = false;


      // this.topCss = {
      //   'top': '50px'
      // }
    }

    //Section is already Approved
    else if (IsApproved === 1) {
      this.isSectionRejected = false;
      this.isSectionApproved = true;


      // this.changeDecision = true; // Move it to Centric
      // this.ApproveDisabled = true;
      // this.showEdit = false;

      // this.ApprovedisabledColor = {
      //   'background': '#959494',
      //   'color': '#1C1B1B'
      // };
      // this.RejectdisabledColor = {
      //   'background': '#959494',
      //   'color': '#1C1B1B'
      // }
      // this.topCss = {
      //   'top': '30px'
      // }
    }

    //Section is Rejected
    else if (comments != "") {
      this.isSectionRejected = true;
      this.isSectionApproved = false;
      // this.rejectionDiscrption = comments;
      // this.rejectedBy = this.userAlias;
      // this.changeDecision = true;


      // this.ApproveDisabled = true;
      // // this.showEdit = false;
      // this.ApprovedisabledColor = {
      //   'background': '#959494',
      //   'color': '#1C1B1B'
      // };
      // this.RejectdisabledColor = {
      //   'background': '#959494',
      //   'color': '#1C1B1B'
      // }
    }

    this.HideorShowlogic();

  }

  Getsectioncomments(sectionId: number,ActionTypeId: number) {

    let currentURL = this.router.url;
    let url = currentURL.split("/");
    this.archiveNumber = url[url.length - 2];

    this.archiveHomeService.Getsectioncomments(this.archiveNumber, sectionId, ActionTypeId)
      .subscribe(
        data => {
          this.IsApproved = data.isSectionApproved;
          this.isSectionApproved = this.IsApproved == 1 ? true : false;
          this.comments = data.comments;
          this.rejectedDate = data.rejectedDate;
          this.rejectedBy= data.rejectedBy;
          console.log('hi', data.comments, this.IsApproved);
          this.rejectionDiscrption=this.comments;
          //this.SetSection(data.comments, this.IsApproved);
          this.HideorShowlogic();
        }
      );
  }

  geteditArchiveDetail() {
   // this.SpinnerService.show();

    console.log(this.router.url);

    // Getting Data first
    let currentURL = this.router.url;
    let url = currentURL.split("/");
    this.archiveNumber = url[url.length - 2];
    if (this.ShowContentForEdit === 0) {
      this.service.GetEditArchiveDetails(this.archiveNumber).subscribe(
        data => this.BindResult(data)
      );
    } else {
      this.service.GetEditArchiveDetails(this.archiveNumber).subscribe(
        data => this.BindData(data)

      );
    }

    //Getting comments after that
    // this.Getsectioncomments( 1);
   // this.SpinnerService.hide();
  }

  //Read only mode
  BindResult(ResultData) {
    this.archiveDetailsData = ResultData;
   // this.SpinnerService.hide();
  }


  // Edit mode
  BindData(ResultData) {
    //These should be binded only in Edit mode

    this.getengagementtypes();
    this.getentities();
    this.getentitytypes();
    this.getarchivetypes(ResultData);

    this.EngagementDescription = ResultData.engagementDescription;
    this.AdditionalDescriptor = ResultData.additionalDescription;
    this.AdditionalDescriptorOrig=ResultData.additionalDescription;
    this.TitleCount = 250 - ResultData.engagementDescription.length;
    this.AdditionalDescriptorcount = 20 - ResultData.additionalDescription.length;
    this.toDate = ResultData.periodEndDate;
    //this.wbsLevelOneNumberValue = ResultData.archiveNameForWBSLevel1Number;
    this.EngagementTypeValue = ResultData.engagementTypeDescription;
    this.entityAssociatedValue = ResultData.entityTypeDescription;
    this.standardsAppliedValue = ResultData.standardsApplied;
    //this.SpinnerService.hide();
  }

  getengagementtypes() {
    this.service.GetEngagementType().subscribe(
      (data) => {
        this.engagements = data;
      },
      (err) => {
        console.log("error is ", err)
      }
    );
  }

  //Get Selected Engagement
  selectEngagement(engagementtype: string) {
    this.selectedEngagementType = engagementtype;
  }

  //Get Entity

  getentities() {

    this.service.GetEntity().subscribe(
      data => {
        this.entities = data;
      }
    );
  }
  // Get Selected Entity

  selectEntity(entity: string) {
    this.selectedEntity = entity;
  }

  //Get Entity Type
  getentitytypes() {

    this.service.GetEntityType().subscribe(
      data => {
        this.entitytype = data;
      }
    );
  }
  // Get Selected Entitity Type

  selectEntityType(entitytype: string) {
    this.selectedEntityType = entitytype;

  }
  //Get ArchvieType
  getarchivetypes(ResultData: any) {
    this.service.GetArchiveType().subscribe(
      data => {
        this.archivenames = data;

        // Selected others
        if(this.archivenames.find(x=> x.description==ResultData.archiveNameForWBSLevel1Number)==undefined)
        {
          this.wbsLevelOneNumberValue="Other";
        }

        //if selected any
        else

        {
          this.wbsLevelOneNumberValue = ResultData.archiveNameForWBSLevel1Number;

        }
      }
    );
  }

  // Get Selected ArchiveType
  // selectArchiveType(args) {
  //   this.myarchive_description = args.target.options[args.target.selectedIndex].text;
  //   this.selectedArchiveType = args.target.value;
  //   if (this.myarchive_description == "Other") {
  //     this.displaytextbox = true;

  //   }
  //   else {
  //     this.displaytextbox = false;
  //     this.AdditionalDescriptor = "";
  //   }
  // }

  onKeyUp(event) {
    this.TitleCount = 250 - event.target.value.length;
  }

  onDescriptionChange(event)
  {
    if(event=== "Other")
    {
    this.showAdditionalDescriptor=true;
    }

    else
    {
      this.showAdditionalDescriptor=false;
    }

  //  alert("dropdown change"+ event);
  }

  onKey(event) {
    if(this.AdditionalDescriptorOrig !== this.AdditionalDescriptor)
    {
      if(this.AdditionalDescriptor.length < 5)
      {
       this.enableSave =false;
      }
      else
      {
       this.enableSave =true;
      }

      this.AdditionalDescriptorFlag=true;
    }
    this.AdditionalDescriptorcount = 20 - event.target.value.length;
  }

  //Save
  UpdateArchiveDetail(IsSubOrResub : number) {
   // this.SpinnerService.show();
    this.markFormTouched(this.login_form);
    if (this.login_form.valid) {
      let currentURL = this.router.url;
      let url = currentURL.split("/");
      this.archiveNumber = url[url.length - 2];
      var parameters = {
        "ArchiveNumber": this.archiveNumber,
        "EngagementDescription": this.EngagementDescription,
        "PeriodEndDate": this.toDate,
        "EngagementTypeDescription": this.EngagementTypeValue,
        "EntityTypeDescription": this.entityAssociatedValue,
        "StandardsApplied": this.standardsAppliedValue,
        "ArchiveNameForWBSLevel1Number": this.wbsLevelOneNumberValue,
        "AdditionalDescription": this.AdditionalDescriptor,
        "ModifiedBy": this.userAlias
      }
      /*var myobjstr = JSON.stringify(parameters);*/
      this.service.UpdateArchiveDetails(parameters).subscribe(
        data => {
          this.AfterUpdateArchivedetails(IsSubOrResub);
          // if(data === "Success"){
          //   this.router.navigate(['../archivehome']);
          // }
        }
      );

      // let CurrentURL = this.router.url;
      // let urlList = CurrentURL.split("/");
      // this.archiveNumber = urlList[urlList.length-2];
      // this.router.navigate(['/archive/myarchives/' + this.archiveNumber + '/archivehome']);

      /*Commenting below If condition as its causing problem while saving the Archive Info.

      if (this.comments !== "") {
        this.topCss = {
        'top': '50px'
       }
     }*/

      //this.SetSection(this.comments,this.IsApproved);

    } else {
      this.login_form.controls['terms'].setValue(false);
     // this.SpinnerService.hide();
      return;
    }
    // if (this.isApprover === false) {
    //   this.router.navigate(['/archive/myarchives/' + this.archiveNumber + '/archivehome']);
    // }
    // else {
    //   this.Initialize();
    // }

   // this.SpinnerService.hide();
  }

  AfterUpdateArchivedetails(IsSubOrResub: number) {
    //debugger;
//this.SpinnerService.show();
    this.service.UpdateArchiveName(this.EngagementDescription);
    this.service.UpdateArchiveDescription(this.wbsLevelOneNumberValue);
    this.service.UpdatePeriodEndDate(this.toDate);
    if (this.isApprover === false) {

      // Redirect to home in submission. Else nothing for resubmission
      if(IsSubOrResub==1)
      {
      this.router.navigate(['/archive/myarchives/' + this.archiveNumber + '/archivehome']);
      }

     //this.SpinnerService.hide();
    }
    else {
      //To track whether approved edited or not
      localStorage['ApproverEdited'] = '1';

      this.Initialize();
     // this.SpinnerService.hide();
    }
  }

  // UpdateArchiveSuccess(Result){
  //   // debugger;
  //   this.SpinnerService.hide();
  //   if(Result === "Success"){
  //     this.router.navigate(['../archivehome']);
  //   }
  // }

  markFormTouched(group: FormGroup | FormArray) {
    Object.keys(group.controls).forEach((key: string) => {
      const control = group.controls[key];
      if (control instanceof FormGroup || control instanceof FormArray) { control.markAsTouched(); this.markFormTouched(control); }
      else { control.markAsTouched(); };
    });
  };

  //Edit button functionality
  EditArchiveDetail() {
    //debugger;
   // this.SpinnerService.show();
    this.ShowContentForEdit = 1;
    //this.EditArchiveDetailsForm=true;
    this.ReadOnlyArchiveDetails = false;
    //this.SaveChangestoArchiveDetailsForm=true;
    this.ShowApproveRejectButtons = false;
    this.showEdit = true;
    this.EditEnable= false;
    this.hideRejectedMessage = true;
    this.changeDecision = false;
    this.geteditArchiveDetail();
    this.ApprovedisabledColor = {
      'background': '#007CB0'
    };
    this.RejectdisabledColor = {
      'background': '#F8F8FA'
    }
    //this.isSectionRejected = false;
    //this.isSectionApproved = true;
    this.ApproveDisabled = false;
    if (this.comments !== "") {
      // this.topCss = {
      //   'top': '165px',
      //   'height': '50%'
      // }
    }
  }

  // On clicking change decision Edit,Approve,Reject should be enabled.
  //Content should be in readonly mode
  //Change decission
  changedecisionbtnClick() {
    // debugger;
    this.showEdit = true;
    this.EditEnable=true;
    this.ReadOnlyArchiveDetails = true;
    this.ShowContentForEdit = 0;
    this.changeDecision=false;
    this.ShowApproveRejectButtons = true;
    this.ApproveDisabled = false;
    this.IsChangeDecissionClicked=true;
    this.ApprovedisabledColor = {
      'background': '#007CB0'
    };
    this.RejectdisabledColor = {
      'background': '#F8F8FA'
    }
  }
  OpenReasonspopupforResubmission() {
    //debugger;

    if (this.CurrentArchiveStatusforArchiveDetails == "Resubmitted – Open" || this.CurrentArchiveStatusforArchiveDetails == "Resubmitted - Ready for Approval"
    ||this.CurrentArchiveStatusforArchiveDetails == "Resubmitted - Rejected") {
      this.UpdateArchiveDetail(2);
      // if (this.login_form.dirty) {

      //   this.modalService.openWithCustomWidth('SaveChanges-AdministrativeResubmission-Modal', "544");
      // }
    }

    else
    {
      if (this.login_form.dirty || this.AdditionalDescriptorFlag) {
        this.modalService.openWithCustomWidth('savechange-details-modal', "544");
        }
    }

  }
  ShowEditedReasonPop() {
    //this.SpinnerService.show();
    this.modalService.close('SaveChanges-AdministrativeResubmission-Modal');
    var parameters = {
      "ArchiveNumber": this.archiveNumber,
      "EngagementDescription": this.EngagementDescription,
      "PeriodEndDate": this.toDate,
      "EngagementTypeDescription": this.EngagementTypeValue,
      "EntityTypeDescription": this.entityAssociatedValue,
      "StandardsApplied": this.standardsAppliedValue,
      "ArchiveNameForWBSLevel1Number": this.wbsLevelOneNumberValue,
      "AdditionalDescription": this.AdditionalDescriptor,
      "ModifiedBy": this.userAlias
    }
    this.service.UpdateArchiveDetails(parameters).subscribe(
      data => {
        console.log('updated in DB');
      });
    this.OnApproveOrRejection(3);
   // this.SpinnerService.hide();
    this.BodyCount=250;
    this.ResubmissionReasonForArchiveDetailsSection="";
    //Commenting this line as we placed the reasons pop up in different folder
    //this.modalService.openWithCustomWidth('Reasons-Adminstrativeresubmission-modal', "500");
  }

  ConfirmCancel() {
    if (this.login_form.dirty || this.AdditionalDescriptorFlag) {
      this.modalService.openWithCustomWidth('Confirmation-alert-modal', "500");
    }
    else{
      this.onReset();
    }
    this.rejectionDiscrption = this.comments;
    if (this.changeDecision === true) {
      this.ShowContentForEdit = 1;
      this.EditArchiveDetailsForm = true;
    }
  }

  onReset() {
    this.router.navigate(['/archive/myarchives/' + this.archiveNumber + '/archivehome']);
    /*this.toDate = undefined;
    this.AdditionalDescriptor = "";
    this.login_form.get('engagementDes').reset();
    this.login_form.get('PeriodEndDate').reset();
    this.login_form.get('EngagementType').reset();
    this.login_form.get('entityAssociated').reset();
    this.login_form.get('standardsApplied').reset();
    this.login_form.get('WBSlevelOneNumber').reset();
    this.ShowContentForEdit = 0;
    this.SetSection(this.rejectionDiscrption, this.IsApproved);*/
  }

  //Flags and its Use:

  // UI flags
  // this.showEdit=true;  // It is for enabling edit button
  // this.ShowApproveRejectButtons=true;  // It is for showing approve/Reject button
  // this.ShowContentForEdit=1;  // It is to show content in edit mode
  // this.ReadOnlyArchiveDetails=true;  // It is to show content in readonly mode
  // this.isSectionRejected // to know whether the section is rejected or not

  // this.hideRejectedMessage = true;  // It is not required
  // this.changeDecision = false;  // Showing or hiding change decision
  // this. IsSectionVisited // To know whether the user visited the section or not
  //DB Flags
  // this.CurrentArchiveStatusforArchiveDetails  Using this for Archive status
  // this.isApprover  // To know whether he/She can approve it or not
  // this.isSectionRejected // to know whether the section is rejected or not

  // Removed after analysis
  // this.SaveChangestoArchiveDetailsForm=true;  // Using this flag to show  Save/Cancel button



  HideorShowlogic() {
    var archiveStatusHome: string = this.CurrentArchiveStatusforArchiveDetails;

    switch (archiveStatusHome) {

      /* ====== Edit mode for Archive team All the times ======*/
      /* common for Open, Resubmitted – Open*/
      case 'Open': {
        this.commonViewForEdit();
        break;
      }
      case "Resubmitted – Open": {
        this.commonViewForEdit();
        this.archiveHomeService.GetResubmissionReasonsforArchive(this.archiveNumber).subscribe(data=>
        {

          if(data){
           if(data.length>0)
           {
            this.ArchiveDetailsEditedInResubmit=data[0].actionTypeId==3?true:false;
            this.ArchiveDetailsProvidedInResubmit=data[0].comments!=""?data[0].comments:"";
            this.ArchiveDetailsEditedDate=data[0].rejectedDate;
           }
          //  if(this.ArchiveDetailsProvidedInResubmit!="")
          //  {
          //   this.topCss = {
          //     'top': '220px'
          //     }
          //   this.FooterCss={
          //     'top':'817px'
          //   }
          //   }
          //   else{
          //     this.topCss = {
          //       'top': '30px'
          //     }
          //   }
           }
        });
        break;
      }

      /*End common for Open, Resubmitted – Open*/


      /* common for Rejected, Resubmitted – Rejected*/
      case "Rejected":
        {
          this.commonViewForEdit();

          //Rejected comments should be shown here
          this.rejectedCommentsDesign();
          break;
        }

      case "Resubmitted - Rejected": {
        if(this.roleMapping.roleId==11 || this.roleMapping.roleId==12)
        {
          this.CommonViewForReadonly();
        }
        else{
        this.commonViewForEdit();}
        //Rejected Comments should be shown here
        //this.rejectedCommentsDesign();
        debugger;
        this.archiveHomeService.Getsectioncomments(this.archiveNumber, 1, 2)
        .subscribe(
        data => {
          if(data.comments!="")
          {
            this.isSectionRejected=true;
            this.IsApproved = data.isSectionApproved;
            this.comments = data.comments;
            this.rejectedDate = data.rejectedDate;
            this.rejectedBy= data.rejectedBy;
            this.rejectionDiscrption= data.comments;
          }
          else{
            this.IsApproved = data.isSectionApproved;
          }
          this.isSectionApproved = this.IsApproved == 1 ? true : false;
        }
      );
        break;
      }

      /*End common for Rejected, Resubmitted – Rejected*/

      /* ====== Edit mode for Archive team All the times ======*/

      case 'Ready For Approval': {
        this.archiveHomeService.GetArchiveApproverForArchiveSubmission(this.archiveNumber,this.roleMapping.roleId).subscribe(data =>
        {
          debugger;
          if(data){
              console.log('GetArchiveApproverForArchiveSubmission-ArchiveDetails',data.canApprove);
              this.isApprover=data.canApprove;
          }
          if (this.isApprover) {
          this.specificViewToApprover();
          }
          else {
          this.CommonViewForReadonly();
          }
        });
        break;
      }
      case "Resubmitted - Ready for Approval": {
        this.GetResubmissionApprovalFlow();




        break;
      }


      /*Common for Approved, Resubmitted – Approved */
      case "Approved": {
        this.CommonViewForReadonly();
        break;
      }
      case "Resubmitted – Approved": {
        this.CommonViewForReadonly();
        break;
      }

      /*End Common for Approved, Resubmitted – Approved and Resubmitted - Rejected */

    }




  }


  //This will have the common view for Archive team. Remaining should be handled in cases.
  // Don't keep any conditions here
  commonViewForEdit() {

    //Content view / Edit
    this.ShowContentForEdit = 1;
    this.ReadOnlyArchiveDetails = false;


    // Buttons
    this.showEdit = false;
    this.changeDecision = false;

    // this.topCss = {
    //   'top': '30px'
    // }

    //Getting Archive details
    this.geteditArchiveDetail();
  }



  rejectedCommentsDesign()
  {
    if(this.IsApproved === 0)
    {
    this.isSectionRejected=true;
    }
    //Rejected
    // if (this.indArchiveDetailStatus == 2) {
    //   this.topCss = {
    //     'top': '165px',
    //    'height': '50%'
    //  }

    // }

  }

  //Read only view
  CommonViewForReadonly() {
    //Content view / Edit
    this.ShowContentForEdit = 0;
    this.ReadOnlyArchiveDetails = true;

    // Buttons
    this.showEdit = false;
    this.changeDecision = false;

    // this.topCss = {
    //   'top': '30px'
    // }

    //Getting Archive details
    this.geteditArchiveDetail();
  }

  // Approver Readonly with actions enabled
  specificViewToApprover() {

     // If approver saves the details by editing, giving him the option to approve/Reject/Edit again
     //Default without giving change decission
     if (localStorage['ApproverEdited'] == 1) {

      // this.topCss = {
      //   'top': '30px'
      // }
      this.ShowApproveRejectButtons = true;
      this.ApproveDisabled = false;
      this.changeDecision = false;
      this.showEdit = true;
      this.EditEnable=true;
      localStorage['ApproverEdited'] = 0;
    }

    else
    {


    // Section is Already Approved
    if (this.indArchiveDetailStatus == 1) {
      //Approve reject labels and reject box
      this.isSectionApproved = true;
      this.isSectionRejected = false;

      //Change decision
      this.changeDecision = true;

      //Approve rejected button flags
      this.ShowApproveRejectButtons = true;
      this.ApproveDisabled = true;

      //Edit button flags
      this.showEdit = true;
      this.EditEnable=false;

      // Design to show Archive header in Approver case
      // this.topCss = {
      //   'top': '30px'
      // }

      this.ApprovedisabledColor = {
        'background': '#959494',
        'color': '#1C1B1B'
      };
      this.RejectdisabledColor = {
        'background': '#959494',
        'color': '#1C1B1B'
      }

    }

    //Rejected
    else if (this.indArchiveDetailStatus == 2) {

      this.isSectionRejected = true;
      this.isSectionApproved = false;
      this.rejectionDiscrption = this.comments;
     // this.rejectedBy = this.userAlias;

      //Change decision, edit button and Approve reject buttons
      this.changeDecision = true;
      this.ShowApproveRejectButtons = true;
      this.ApproveDisabled = true;
      this.showEdit = true;
      this.EditEnable=false;

      // Design to show Archive header in Approver case
    //   this.topCss = {
    //     'top': '165px',
    //    'height': '50%'
    //  }


      this.ApprovedisabledColor = {
        'background': '#959494',
        'color': '#1C1B1B'
      };
      this.RejectdisabledColor = {
        'background': '#959494',
        'color': '#1C1B1B'
      }

    }

    //No action taken yet. Enable Edit/Approve/Reject for first time
    else {
      // this.topCss = {
      //   'top': '30px'
      // }
      this.showEdit = true;
      this.EditEnable=true;
      this.changeDecision = false;
      this.ShowApproveRejectButtons = true;
      this.ApproveDisabled = false;

    }
  }

    //Common
    this.ShowContentForEdit = 0;
    this.ReadOnlyArchiveDetails = true;
    this.geteditArchiveDetail();
  }


  onChange(value){
    let newDate= new Date(value);
    newDate.setMinutes(newDate.getMinutes() - newDate.getTimezoneOffset());
    this.toDate = newDate;

  }

  SaveDefaultView()
  {

  }


  // Order of events at present

  // 1. Get Archive details  (It should be removed later)

  // 2. Isapprover and status API (Show hide logic)

  // 3. Show hide logic (Get Archive details)

  // 4. Get Archive details (Get section comments, Set section comments)

  // 5. Get section comments

  // 6. Set section comments





  // Order should be as below

  // Isapprover and status from API

  //Get section comments. API => It is not dependendent on centric logic flags and any other

  // Set section for flag issectionrejected/ issection approved

  // Centric logic  It uses the above flags and set the default view

  //Finally archive details


  // Edit and change decision should come only when the section is approved and

  // Get Arcive details

  //================Rejected Comments ============
  //Rejected comments should come only in the below statuses

  // Rejected, Resubmitted-rejected only, RFA, RRFA

  // Not Applicable in below statuses

  //Approved, Resubmitted-Approved, Open, Resubmitted-open
  // ==============


}


