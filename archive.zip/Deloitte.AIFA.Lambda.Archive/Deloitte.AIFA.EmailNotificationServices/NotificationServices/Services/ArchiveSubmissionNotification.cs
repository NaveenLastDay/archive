﻿using Deloitte.AIFA.DomainEntities;
using Deloitte.AIFA.DomainEntities.EmailEntities;
using Deloitte.AIFA.EmailNotificationServices.NotificationEntities;
using Deloitte.AIFA.EmailNotificationServices.NotificationServices.Interfaces;
using Deloitte.AIFA.IRepositories;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.EmailNotificationServices.NotificationServices.Services
{
    public class ArchiveSubmissionNotification : IArchiveSubmissionNotification
    {
        IUserRepository _userRepository;
        ILogger _logger;        
       
        public ArchiveSubmissionNotification(                              
                                )        {
           
        }
     
        public BaseEmailEntity Submission_ForApproval_Notification(string argOperationType, string argOperationDescription, string argTemplateId, string ArchiveNumber, string userAlias)
        {
            BaseEmailEntity objTAR = new BaseEmailEntity();
            //Build Tag Values
            objTAR.MinimumTagValues = new Dictionary<string, string>();
            //ArchiveNumber for Subject
            objTAR.MinimumTagValues.Add(EmailPlaceholders.ArchiveNumber, ArchiveNumber);
            //Requestor FirstName for Body

           
            if (!string.IsNullOrEmpty(userAlias) )
            {
                objTAR.MinimumTagValues.Add(EmailPlaceholders.RequestorFirstName, userAlias); // Submitter or Resubmitter
            }

            objTAR.MinimumTagValues.Add(EmailPlaceholders.SubmissionDate, DateTime.Now.ToString("MM/dd/yyyy HH:mm"));

            //Hyperlink to Access for Body
            objTAR.MinimumTagValues.Add(EmailPlaceholders.GrantDenyLink, "GrantDenyLink");

           
            objTAR.TemplateId = argTemplateId;
            objTAR.OperationDescription = argOperationDescription;
            objTAR.OperationType = argOperationType;

            return objTAR;
        }

        public BaseEmailEntity Submission_Approved_Notification(string argOperationType, string argOperationDescription, string argTemplateId, string ArchiveNumber, string userAlias, string approvedDate, string timeZone)
        {
            BaseEmailEntity objTAR = new BaseEmailEntity();
            //Build Tag Values
            objTAR.MinimumTagValues = new Dictionary<string, string>();
            //ArchiveNumber for Subject
            objTAR.MinimumTagValues.Add(EmailPlaceholders.ArchiveNumber, ArchiveNumber);
            //Requestor FirstName for Body


            if (!string.IsNullOrEmpty(userAlias))
            {
                objTAR.MinimumTagValues.Add(EmailPlaceholders.Approver, userAlias); //Approver for Submission flow
            }

            objTAR.MinimumTagValues.Add(EmailPlaceholders.SubmissionDate, approvedDate + " " + timeZone);

            //Hyperlink to Access for Body
            objTAR.MinimumTagValues.Add(EmailPlaceholders.GrantDenyLink, "GrantDenyLink");


            objTAR.TemplateId = argTemplateId;
            objTAR.OperationDescription = argOperationDescription;
            objTAR.OperationType = argOperationType;

            return objTAR;
        }

        public BaseEmailEntity Submission_Rejected_Notification(string argOperationType, string argOperationDescription, string argTemplateId, string ArchiveNumber, string userAlias)
        {
            BaseEmailEntity objTAR = new BaseEmailEntity();
            //Build Tag Values
            objTAR.MinimumTagValues = new Dictionary<string, string>();
            //ArchiveNumber for Subject
            objTAR.MinimumTagValues.Add(EmailPlaceholders.ArchiveNumber, ArchiveNumber);
            //Requestor FirstName for Body


            if (!string.IsNullOrEmpty(userAlias))
            {
                objTAR.MinimumTagValues.Add(EmailPlaceholders.Rejecter, userAlias);
            }

            objTAR.MinimumTagValues.Add(EmailPlaceholders.SubmissionDate, DateTime.Now.Date.ToString()); // Rejected Date

            //Hyperlink to Access for Body
            objTAR.MinimumTagValues.Add(EmailPlaceholders.GrantDenyLink, "GrantDenyLink");


            objTAR.TemplateId = argTemplateId;
            objTAR.OperationDescription = argOperationDescription;
            objTAR.OperationType = argOperationType;

            return objTAR;
        }

    }
}
