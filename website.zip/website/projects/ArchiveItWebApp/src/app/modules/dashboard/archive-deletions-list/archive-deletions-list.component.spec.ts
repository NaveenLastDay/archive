import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ArchiveDeletionsListComponent } from './archive-deletions-list.component';

describe('ArchiveDeletionsListComponent', () => {
  let component: ArchiveDeletionsListComponent;
  let fixture: ComponentFixture<ArchiveDeletionsListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ArchiveDeletionsListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ArchiveDeletionsListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
