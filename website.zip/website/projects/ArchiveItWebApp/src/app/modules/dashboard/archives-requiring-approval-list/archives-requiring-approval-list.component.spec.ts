import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ArchivesRequiringApprovalListComponent } from './archives-requiring-approval-list.component';

describe('ArchivesRequiringApprovalListComponent', () => {
  let component: ArchivesRequiringApprovalListComponent;
  let fixture: ComponentFixture<ArchivesRequiringApprovalListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ArchivesRequiringApprovalListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ArchivesRequiringApprovalListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
