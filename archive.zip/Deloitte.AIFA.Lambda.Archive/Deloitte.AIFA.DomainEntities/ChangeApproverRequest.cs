﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
    public class ChangeApproverRequest
    {
        public int FormId { get; set; }
        public string Identifier { get; set; }
        public string ChangedTo { get; set; }
        public string ChangedBy { get; set; }
        public string ArchiveNumber { get; set; }
    }
}
