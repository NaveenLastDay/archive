﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.Models
{
    public class EntityTypeModel
    {
        public string EntityTypeDescription { get; set; }
        public int EntityTypeId { get; set; }
       


    }
}
