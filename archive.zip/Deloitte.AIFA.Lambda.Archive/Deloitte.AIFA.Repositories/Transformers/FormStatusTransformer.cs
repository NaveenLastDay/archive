﻿using Deloitte.AIFA.DataModels;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace Deloitte.AIFA.Repositories.Transformers
{
    public class FormStatusTransformer : BaseTransformer<FormStatusModel>
    {

        public enum FormStatusOutputField
        {
            IsFormEnabled,
            FormStatusDescription,
            ADCDDate,
            FormStatusDate
        }
        internal override FormStatusModel TransformElement(IDataReader dr, Func<IDataReader, FormStatusModel, FormStatusModel> bindExtraFields = null)
        {
            var formStatus = new FormStatusModel();
            while (dr.Read())
            {
                formStatus = new FormStatusModel()
                {
                    IsFormEnabled = dr[FormStatusOutputField.IsFormEnabled.ToString()] is DBNull ? false : Convert.ToBoolean(dr[FormStatusOutputField.IsFormEnabled.ToString()]),
                    FormStatusDescription = (dr[FormStatusOutputField.FormStatusDescription.ToString()] is DBNull) ? string.Empty : dr[FormStatusOutputField.FormStatusDescription.ToString()].ToString(),
                    ADCDDate = (dr[FormStatusOutputField.ADCDDate.ToString()] is DBNull) ? (DateTime?)null : DateTime.Parse(dr[FormStatusOutputField.ADCDDate.ToString()].ToString()),
                    FormStatusDate = (dr[FormStatusOutputField.FormStatusDate.ToString()] is DBNull) ? (DateTime?)null : DateTime.Parse(dr[FormStatusOutputField.FormStatusDate.ToString()].ToString()),
                };
            }
            return formStatus;
        }
    }
}
