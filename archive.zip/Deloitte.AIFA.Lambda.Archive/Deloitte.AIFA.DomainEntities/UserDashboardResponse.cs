﻿using System.Collections.Generic;
using System;

namespace Deloitte.AIFA.DomainEntities
{
    public class UserDashboardResponse
    {
        public List<NonComplianceMetrics> ComplianceMetricsForUser { get; set; }

    }

    public enum DashboardComponent
    {
        ComplianceMetrics,
        AccessRequests,
        Form3283SApprovals,
        ArchivesAwaitingApprovals,
        PendingSubmissions,
        ArchiveDeletions,
        ArchivesRequiringApprovals,
        RetensionExceptions
    }

    public class NonComplianceMetrics
    {
        public string Category { get; set; }
        public List<ComplianceMetrics> NonComplianceDetails { get; set; }

        public int Count { get; set; }
        public string Color { get; set; }

    }
       
    public class ComplianceMetrics
    {
        public string ClientName { get; set; }
        public string ArchiveName { get; set; }
        public string ArchiveNumber { get; set; }
        public string WBSNumber { get; set; }
        public string Status { get; set; }
        public DateTime? DueDate { get; set; }
        public DateTime? ArchiveClosed { get; set; }
        public string Performance { get; set; }
    }
}
