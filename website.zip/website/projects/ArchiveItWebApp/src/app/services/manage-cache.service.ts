import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
    providedIn: 'root'
})
export class ManageCacheService {

    httpOptions = {
        headers: new HttpHeaders({
            'Content-Type': 'application/json',
        }),
    }

    constructor(private _http: HttpClient) {

    }

    getAllItems(request: any) {
        var apiData = this._http.post<any>("cache/get/all", request, this.httpOptions);
        return apiData;
    }

    addItem(request: any) {
        var apiData = this._http.post<any>("cache/add/value", request, this.httpOptions);
        return apiData;
    }

    removeItem(request: any) {
        var apiData = this._http.post<any>("cache/remove/value", request, this.httpOptions);
        return apiData;
    }

    removeAllItems(request: any) {
        var apiData = this._http.post<any>("cache/remove/all", request, this.httpOptions);
        return apiData;
    }

}