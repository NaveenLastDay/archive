﻿using System;

namespace Deloitte.AIFA.DomainEntities
{
    public class Archive
    {
        public string ArchiveNumber { get; set; }
        public string ArchiveName { get; set; }
        public string WBSLevelOneNumber { get; set; }
        public string ClientName { get; set; }
        public DateTime PeriodEndDate { get; set; }
        public DateTime WBSClosedDate { get; set; }
        public string ArchiveStatus { get; set; }
        public ProjectMetaData WBSInfo { get; set; }
        public ArchiveMetaData ArchiveInfo { get; set; }
        public int IsAccessAllowed { get; set; }
    }
}
