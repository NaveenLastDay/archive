﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
    public class ExistingArchivesInfo
    {
        public ArchiveSearchBase archiveSearchBase { get; set; }
        public List<ExistingArchives> lstExistingArchives { get; set; }
    
    }
}
