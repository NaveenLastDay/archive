﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.Helpers.ExcelGenerator
{
    public interface IXlsxGenerator
    {
        List<IDataForSheet> GetIDataSheetList<T>(IEnumerable<T> entityList);

        byte[] GenerateExcelFile(string excelFileName, List<XlsxSheetToGenerate> sheets, string folderPath);
    }
}
