﻿using Deloitte.AIFA.DataModels;
using Deloitte.AIFA.DBHelper;
using System;
using System.Data;

namespace Deloitte.AIFA.Repositories.Transformers
{

    public enum ArchiveSearchFields
    {
        ItemId,
        ItemName
    }
    public enum ArchiveSearchParameter
    {
        [CreateField(Name = "In_searchquery", Direction = ParameterDirection.Input, Type = DbType.String)]
        Search,
        [CreateField(Name = "In_Category", Direction = ParameterDirection.Input, Type = DbType.String)]
        Category
    }
    public class ArchiveSearchTransformer : BaseTransformer<SearchOptionsModel>
    {
        internal override SearchOptionsModel TransformElement(IDataReader dr, Func<IDataReader, SearchOptionsModel, SearchOptionsModel> bindExtraFields = null)
        {
            return new SearchOptionsModel
            {
                ItemId = long.Parse(dr[ArchiveSearchFields.ItemId.ToString()].ToString()),
                ItemName = (dr[ArchiveSearchFields.ItemName.ToString()] is DBNull) ? null : dr[ArchiveSearchFields.ItemName.ToString()].ToString()

            };
        }
    }

}
