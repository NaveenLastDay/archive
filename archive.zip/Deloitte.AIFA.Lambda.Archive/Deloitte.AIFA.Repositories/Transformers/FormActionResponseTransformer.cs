﻿using Deloitte.AIFA.DataModels;
using Deloitte.AIFA.DBHelper;
using System;
using System.Collections.Generic;
using System.Data;

namespace Deloitte.AIFA.Repositories.Transformers
{
    public class FormActionResponseTransformer : BaseTransformer<FormActionResponseModel>
    {
        internal override FormActionResponseModel TransformElement(IDataReader dr, Func<IDataReader, FormActionResponseModel, FormActionResponseModel> bindExtraFields = null)
        {
            FormActionResponseModel response = new FormActionResponseModel();
            while (dr.Read())
            {
                response.IsSuccessful = Convert.ToBoolean(dr[FormOutputFields.IsSuccessful.ToString()]);
                response.ResponseMessage = (dr[FormOutputFields.ResponseMessage.ToString()] is DBNull) ? string.Empty : dr[FormOutputFields.ResponseMessage.ToString()].ToString();
                response.ApprovedBy = (dr[FormOutputFields.ApprovedBy.ToString()] is DBNull) ? string.Empty : dr[FormOutputFields.ApprovedBy.ToString()].ToString();
                response.SubmittedBy = (dr[FormOutputFields.SubmittedBy.ToString()] is DBNull) ? string.Empty : dr[FormOutputFields.SubmittedBy.ToString()].ToString();
                response.FormStatus = (dr[FormOutputFields.FormStatus.ToString()] is DBNull) ? string.Empty : dr[FormOutputFields.FormStatus.ToString()].ToString();
                response.ADCED = (dr[FormOutputFields.ADCED.ToString()] is DBNull) ? DateTime.MinValue : DateTime.Parse(dr[FormOutputFields.ADCED.ToString()].ToString());
            };
            return response;
        }
    }
}
