﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
    public class MyArchivesFilterData
    {
        public int RowNumber { get; set; }
        public string FilterData { get; set; }
    }
}
