﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
    public class RequestTemporaryArchiveAccess
    {
        public string RequestedBy { get; set; }
        public string RequestedOf { get; set; }
        public int DispositionTypeId { get; set; }
        public string ArchiveNumber { get; set; }
        public string Description { get; set; }
    }
}
