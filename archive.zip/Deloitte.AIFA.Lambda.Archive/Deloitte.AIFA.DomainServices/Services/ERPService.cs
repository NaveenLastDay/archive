﻿using Deloitte.AIFA.DomainServices.Contracts;
using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using System.Net;
using System.IO;
using Microsoft.Extensions.Configuration;
using Deloitte.AIFA.ICloudServices;
using Deloitte.AIFA.IRepositories;
using Newtonsoft.Json;
using Deloitte.AIFA.DomainEntities;
using System.Xml.Linq;
using System.Linq;
using Deloitte.AIFA.Helpers;

namespace Deloitte.AIFA.DomainServices.Services
{
    public class ERPService : BaseService, IERPService
    {
        ILogger _logger;
        IMemoryCache _cache;
        IConfigManager _configManager;
        IERPRepository _eRPRepository;
        IConfiguration _cofiguration;
        public ERPService(IMemoryCache cache, IConfigManager configManager, IConfiguration config,
                               IERPRepository eRPRepository,
                                 ILogger<ERPService> logger) : base(cache, configManager)
        {
            _cache = cache;
            _logger = logger;
            _configManager = configManager;
            _eRPRepository = eRPRepository;
            _cofiguration = config;
        }
        public (bool, List<EngagementPersonnelInfo>) GetPersonnelForWBSNumber(string wbsNumber, string ArchiveNumber)
        {
            try
            {
                _logger.LogInformation(string.Format("the GetPartnerAlias() started {0:HH:mm:ss.fff}", DateTime.UtcNow));
                string userAlias = GetPartnerAlias(ArchiveNumber);
                _logger.LogInformation(string.Format("the GetPartnerAlias() ended {0:HH:mm:ss.fff}", DateTime.UtcNow));

                //string userAlias = "T_WIP_USER";
                string EmpAliasList = string.Empty;
                List<EngagementPersonnelInfo> engagementPersonnelInfo = null;
                //Tuple<bool, List<SAPEmployeeWBSTimeAllocation>> SAPResponse = null;
                (bool hasError, List<SAPEmployeeWBSTimeAllocation> response) SAPResponse = (false, new List<SAPEmployeeWBSTimeAllocation>());

                _logger.LogInformation(string.Format("the GetTimeAllocationForWbsNumber() started {0:HH:mm:ss.fff}", DateTime.UtcNow));
                SAPResponse = GetTimeAllocationForWbsNumber(wbsNumber, userAlias);
                _logger.LogInformation(string.Format("the GetTimeAllocationForWbsNumber() ended {0:HH:mm:ss.fff}", DateTime.UtcNow));
                if (SAPResponse.hasError == false)
                {

                    foreach (SAPEmployeeWBSTimeAllocation emp in SAPResponse.response)
                    {
                        EmpAliasList = EmpAliasList + "" + emp.EmployeeEmailAddress.Split('@').First() + ",";
                    }
                    var dstributionList = new DistributionList
                    {
                        ArchiveNumber = ArchiveNumber,
                        Personnels = EmpAliasList,
                        IsManualSubmission = false,
                        CreatedBy = "-1",
                        CreatedDate = DateTime.Now

                    };
                    _logger.LogInformation(string.Format("IF=the AddEngagementPersonnels() started {0:HH:mm:ss.fff}", DateTime.UtcNow));
                    AddEngagementPersonnels(dstributionList);
                    _logger.LogInformation(string.Format("IF=the AddEngagementPersonnels() ended {0:HH:mm:ss.fff}", DateTime.UtcNow));

                    if (EmpAliasList.Length > 0)
                    {
                        EmpAliasList = EmpAliasList.Substring(0, EmpAliasList.Length - 1);
                    }
                    _logger.LogInformation(string.Format("the GetEngagementPersonnelInfo() started {0:HH:mm:ss.fff}", DateTime.UtcNow));
                    engagementPersonnelInfo = _eRPRepository.GetEngagementPersonnelInfo(ArchiveNumber);
                    _logger.LogInformation(string.Format("the GetEngagementPersonnelInfo() started {0:HH:mm:ss.fff}", DateTime.UtcNow));
                    return (SAPResponse.hasError, engagementPersonnelInfo);
                }
                else
                {
                    _logger.LogInformation(string.Format("ELSE=the GetEngagementPersonnelInfo() started {0:HH:mm:ss.fff}", DateTime.UtcNow));
                    return (SAPResponse.hasError, _eRPRepository.GetEngagementPersonnelInfo(ArchiveNumber));
                }
            }

            catch (Exception ex)
            {
                _logger.LogInformation("There was an error retrieving personnel from SAP for WBS Code " + System.Web.HttpUtility.HtmlEncode(wbsNumber));
                _logger.LogInformation("Error: " + ex.Message);
                throw ex;
            }
        }
        private (bool, List<SAPEmployeeWBSTimeAllocation>) GetTimeAllocationForWbsNumber(string WbsNumber, string UserAlias)
        {

            string BearerToekn = string.Empty;
            string keys = "sapTokenUrl,sapAccessUrl,sapClientID,sapClientSecret,sapGrantType,sapCache";
            List<ERPConfigurationData> lstConfigData = new List<ERPConfigurationData>();
            var returnValue = "";
            try
            {
                lstConfigData = _eRPRepository.GetERPCpnfigurationData(keys);
                BearerToekn = GetToken(lstConfigData);
                string sapAccess = lstConfigData.Where(p => p.ERPDataKey == "sapAccessUrl").FirstOrDefault().ERPDataValue;
                string WBSLevelOne = "'" + System.Web.HttpUtility.HtmlEncode(WbsNumber).ToUpper() + "'";
                string Login = "'" + System.Web.HttpUtility.HtmlEncode(UserAlias) + "'";
                Login = Login.Trim().ToUpper();

                sapAccess = string.Format(sapAccess, WBSLevelOne, Login);
                var request2 = (HttpWebRequest)WebRequest.Create(sapAccess);

                request2.Method = "GET";
                request2.Headers.Add("Authorization", "Bearer " + BearerToekn);
                using (var response2 = (HttpWebResponse)request2.GetResponse())
                {
                    if (response2.StatusCode != HttpStatusCode.OK)
                    {
                        returnValue = String.Format("Attempt to retrieve data from SAP failed with response code {0}", response2.StatusCode);
                        throw new ApplicationException(returnValue + sapAccess);
                    }

                    using (var responseStream = response2.GetResponseStream())
                    {
                        using (var reader = new StreamReader(responseStream))
                        {
                            returnValue = reader.ReadToEnd();
                            _logger.LogInformation(string.Format("RETURN VAL==the results received {0:HH:mm:ss.fff}", DateTime.UtcNow));

                        }
                    }
                }
                return (false, Map(returnValue));
            }
            catch (Exception ex)
            {
                return (true, new List<SAPEmployeeWBSTimeAllocation>());
            }
        }


        private string GetToken(List<ERPConfigurationData> lstConfigData)
        {
            var returnValue = "";
            //   string BearerToken = string.Empty;
            var inputstringRegex = _cofiguration["ValidInputStringRegex"];
            var result=HtmlSanitizerHelper.validateProperties(lstConfigData, inputstringRegex);
            if (result == "invalid") {
                returnValue= "Input validation failed";
                return returnValue;
            }
            string sapTokenUrl = lstConfigData.Where(p => p.ERPDataKey == "sapTokenUrl").FirstOrDefault().ERPDataValue;
            string sapClientID = lstConfigData.Where(p => p.ERPDataKey == "sapClientID").FirstOrDefault().ERPDataValue;
            string sapClientSecret = lstConfigData.Where(p => p.ERPDataKey == "sapClientSecret").FirstOrDefault().ERPDataValue;
            string sapGrantType = lstConfigData.Where(p => p.ERPDataKey == "sapGrantType").FirstOrDefault().ERPDataValue;
            string sapCache = lstConfigData.Where(p => p.ERPDataKey == "sapCache").FirstOrDefault().ERPDataValue;
            try
            {
                var request = (HttpWebRequest)WebRequest.Create(sapTokenUrl);
                var postData = sapClientID + "&" + sapClientSecret + "&" + sapCache + "&" + sapGrantType;
                var data = Encoding.ASCII.GetBytes(postData);
                request.Method = "POST";
                request.ContentType = "application/x-www-form-urlencoded";
                request.ContentLength = data.Length;
                using (var stream = request.GetRequestStream())
                {
                    stream.Write(data, 0, data.Length);
                }
                using (var response = (HttpWebResponse)request.GetResponse())
                {
                    if (response.StatusCode != HttpStatusCode.OK)
                    {
                        returnValue = String.Format("Attempt to retrieve bearer token failed with response code {0}", response.StatusCode);
                        throw new ApplicationException(returnValue);
                    }

                    using (var responseString = response.GetResponseStream())
                    {
                        using (var reader = new StreamReader(responseString))
                        {
                            returnValue = reader.ReadToEnd();

                        }
                    }
                }
               
                var secretVarialbles = JsonConvert.DeserializeObject<ERPToken>(returnValue);
                var BearerToken = secretVarialbles.access_token;
                return BearerToken;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        private List<SAPEmployeeWBSTimeAllocation> Map(string response)
        {
            var result = new List<SAPEmployeeWBSTimeAllocation>();
            try
            {
                if (response.Length > 0)
                {

                    XDocument wbsdata = JsonConvert.DeserializeXNode(response);
                    var responseXml = XDocument.Parse(Convert.ToString(wbsdata));

                    foreach (XElement element in responseXml.Descendants("results"))
                    {
                        var items = new SAPEmployeeWBSTimeAllocation()
                        {
                            EmployeeEmailAddress = element.Element("EMP_EMAIL_ADDRESS").Value,
                            EmployeeFullName = element.Element("EMP_NAME_COMBINED").Value,
                            CsHours = element.Element("CS_HRS").Value
                        };
                        result.Add(items);
                    }

                }
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            //return result;
        }
        public List<ERPDetails> GetERPDetails(string searchquery)
        {
            _logger.LogInformation(string.Format("Processing {0} service method.", System.Reflection.MethodBase.GetCurrentMethod()));
            List<ERPDetails> eRPDetails = null;
            eRPDetails = _eRPRepository.GetERPDetails(searchquery);
            return eRPDetails;
        }

        private string GetPartnerAlias(string archiveNumber)
        {

            _logger.LogInformation("GetPartnerAlias: " + System.Web.HttpUtility.HtmlEncode(archiveNumber));
            string partnerAlias = "";
            try
            {
                partnerAlias = _eRPRepository.GetPartnerAlias(archiveNumber);
                return partnerAlias;
            }
            catch (Exception ex)
            {
                _logger.LogInformation("There was an error retrieving PartnerAlias from DB for archiveNumber "+ System.Web.HttpUtility.HtmlEncode(archiveNumber));
                _logger.LogInformation("Error: " + ex.Message);
                throw ex;
            }
        }

        #region RemoveEngagementPersonnel
        public DistributionList RemoveEngagementPersonnel(DistributionList distributionList)
        {
            _logger.LogInformation(string.Format("Processing {0} service method.", System.Reflection.MethodBase.GetCurrentMethod()));
            DistributionList distributionListOutput = null;
            distributionListOutput = _eRPRepository.RemoveEngagementPersonnel(distributionList);
            return distributionListOutput;
        }
        #endregion RemoveEngagementPersonnel

        #region AddEngagementPersonnels        
        public DistributionList AddEngagementPersonnels(DistributionList distributionList)
        {
            _logger.LogInformation(string.Format("Processing {0} service method.", System.Reflection.MethodBase.GetCurrentMethod()));
            DistributionList distributionListOutput = null;
            distributionListOutput = _eRPRepository.AddEngagementPersonnels(distributionList);
            return distributionListOutput;
        }
        #endregion AddEngagementPersonnels
    }
}
