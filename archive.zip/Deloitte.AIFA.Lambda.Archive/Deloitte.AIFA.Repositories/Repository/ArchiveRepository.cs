﻿using Deloitte.AIFA.Common;
using Deloitte.AIFA.DataModels;
using Deloitte.AIFA.DBHelper;
using Deloitte.AIFA.DomainEntities;
using Deloitte.AIFA.DomainEntities.Report;
using Deloitte.AIFA.IRepositories;
using Deloitte.AIFA.Models;
using Deloitte.AIFA.Repositories.Transformers;
using Microsoft.Extensions.Caching.Memory;
using MySqlConnector;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Deloitte.AIFA.Repositories
{
    public class ArchiveRepository : BaseRepository<ArchiveField>, IArchiveRepository
    {
        IMemoryCache _cache;
        public ArchiveRepository(IMemoryCache cache) : base(cache)
        {
            _cache = cache;
        }

        public Archive GetArchiveDetail(int ArchiveId)
        {

            Exception e = new Exception();
            try
            {
                var parameters = Builder.Bind(ArchiveFieldParameter.ArchiveId).On(ArchiveId)
                                 .Build();
                return DbHelper.ExecuteReader(
                    "pub_GetArchiveByArchiveId",
                    parameters,
                        dr =>
                        {
                            var archiveEntity = new ArchiveTransformer().Transform(dr, ArchiveTransformer.BindForGetArchiveByArchiveId).FirstOrDefault();

                            var archive = _mapper.Map<ArchiveModel, Archive>(archiveEntity);

                            return archive;
                            //return null;


                        }
                    );
            }
            catch (Exception ex)
            {
                e = ex;
                return null;
            }
        }


        public List<EngagementType> GetEngagementType()
        {
            try
            {
                var result = DbReaderHelper.ExecuteReader(
                    "pub_AIFA_GetEngagementTypes",
                    null,
                        dr => new ArchiveMetaDataTransformer().Transform(dr).ToList());

                return _mapper.Map<List<EngagementTypeModel>, List<EngagementType>>(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public List<ArchiveType> GetArchiveType()
        {
            try
            {
                var result = DbReaderHelper.ExecuteReader(
                    "pub_AIFA_GetArchiveTypes",
                    null,
                        dr => new ArchiveMetaDataArchiveTypeTransformer().Transform(dr).ToList());

                return _mapper.Map<List<ArchiveTypeModel>, List<ArchiveType>>(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<EntityType> GetEntityType()
        {
            try
            {
                var result = DbReaderHelper.ExecuteReader(
                    "pub_AIFA_GetEntityTypes",
                    null,
                        dr => new ArchiveMetaDataEntityTypeTransformer().Transform(dr).ToList());

                return _mapper.Map<List<EntityTypeModel>, List<EntityType>>(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<ProfessionalStandards> GetProfessionalStandard()
        {
            try
            {
                var result = DbReaderHelper.ExecuteReader(
                    "pub_AIFA_GetProfessionalStandards",
                    null,
                        dr => new ArchiveMetaDataProfessionalStandardTransformer().Transform(dr).ToList());

                return _mapper.Map<List<ProfessionalStandardsModel>, List<ProfessionalStandards>>(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<RetentionReason> GetRetentionReasons()
        {
            try
            {
                var result = DbHelper.ExecuteReader(
                    "pub_AIFA_GetRetentionReasons",
                    null,
                        dr => new ArchiveMetaDataRetentionReasonTransformer().Transform(dr).ToList());

                return _mapper.Map<List<RetentionReasonModel>, List<RetentionReason>>(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string CreateArchiveLegalHold(ArchiveLegalHold archiveLegalHold)
        {
            try
            {
                var parameters = Builder.Bind(ArchiveLegalHoldFieldParameter.ArchiveNumber).On(archiveLegalHold.ArchiveNumber)
                                .Bind(ArchiveLegalHoldFieldParameter.OGCHoldNumber).On(archiveLegalHold.OGCHoldNumber)
                                .Bind(ArchiveLegalHoldFieldParameter.OGCPreservationNoticeDate).On(archiveLegalHold.OGCPreservationNoticeDate)
                                .Bind(ArchiveLegalHoldFieldParameter.OGCAttorneyName).On(archiveLegalHold.OGCAttorneyName)
                                .Bind(ArchiveLegalHoldFieldParameter.Description).On(archiveLegalHold.Description)
                                .Bind(ArchiveLegalHoldFieldParameter.CreatedBy).On(archiveLegalHold.CreatedBy).Build();

                DbHelper.ExecuteNonQuery(
                   "pub_AIFA_InsertArchiveLegalHold",
                   parameters);


                return "success";
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public string CreateArchiveRetention(ArchiveRetention archiveRetention)
        {
            try
            {
                var retentionIds = string.Join(",", archiveRetention.RetentionExtentionReasonId);
                var parameters = Builder.Bind(ArchiveRetentionFieldParameter.ArchiveNumber).On(archiveRetention.ArchiveNumber)
                                .Bind(ArchiveRetentionFieldParameter.RetentionReasonId).On(retentionIds)
                                .Bind(ArchiveRetentionFieldParameter.Createdby).On(archiveRetention.CreatedBy)
                                .Bind(ArchiveRetentionFieldParameter.Comment).On(archiveRetention.Comments)
                                .Bind(ArchiveRetentionFieldParameter.RetentionTime).On(archiveRetention.RetentionTime).Build();

                DbHelper.ExecuteNonQuery(
                   "pub_AIFA_InsertRetentionException",
                   parameters);


                return "success";
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<ActiveRoles> GetActiveRoles(string ArchiveNumber)
        {
            try
            {
                var parameters = GetBuilderInstance().Bind(ActiveRoleFieldParameter.ArchiveNumber).On(ArchiveNumber).Build();

                var result = DbReaderHelper.ExecuteReader(
                    "pub_AIFA_GetActiveRoles",
                    parameters,
                        dr => new ArchiveActiveRoleTransformer().Transform(dr).ToList());

                return _mapper.Map<List<ActiveRolesModel>, List<ActiveRoles>>(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<ActiveRoles> GetActiveRolesForRequestTemporaryAccess(string ArchiveNumber)
        {
            try
            {
                var parameters = GetBuilderInstance().Bind(ActiveRoleFieldParameter.ArchiveNumber).On(ArchiveNumber).Build();

                var result = DbHelper.ExecuteReader(
                    "pub_AIFA_GetActiveRolesForRequestTemporaryAccess",
                    parameters,
                        dr => new ArchiveActiveRoleTransformer().Transform(dr).ToList());

                return _mapper.Map<List<ActiveRolesModel>, List<ActiveRoles>>(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<ArchiveTeamHistory> GetArchiveTeamHistory(string ArchiveNumber, int pageNumber, int pageSize, int sortBy)
        {
            try
            {
                var parameters = Builder
                    .Bind(ArchiveTeamHistoryFieldParameter.ArchiveNumber).On(ArchiveNumber)
                    .Bind(ArchiveTeamHistoryFieldParameter.PageNumber).On(pageNumber)
                    .Bind(ArchiveTeamHistoryFieldParameter.PageSize).On(pageSize)
                    .Bind(ArchiveTeamHistoryFieldParameter.SortBy).On(sortBy)
                    .Build();

                var result = DbHelper.ExecuteReader(
                    "pub_AIFA_GetArchiveTeamHistory",
                    parameters,
                        dr => new ArchiveTeamHistoryTransformer().Transform(dr).ToList());

                return _mapper.Map<List<ArchiveTeamHistoryModel>, List<ArchiveTeamHistory>>(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public List<ArchiveSearchBase> GetWBSSerchResults(string term, int rowcount)
        {
            try
            {
                var parameters = new MySqlParameter[]
                {
                    new MySqlParameter("@Term", MySqlDbType.VarChar) {Value = term},
                    new MySqlParameter("@rowcount", MySqlDbType.Int32) {Value = rowcount},
                };
                var result = DbReaderHelper.ExecuteReader(
                    "pub_GetWBSSearchResults",
                    parameters,
                        dr => new ArchiveMetaDataSearchBaseTransformer().Transform(dr).ToList());

                return _mapper.Map<List<ArchiveSearchBaseModel>, List<ArchiveSearchBase>>(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public WBSDetails GetWBSDetails(string wbsLevelOne)
        {
            try
            {
                var parameters = new MySqlParameter[]
                {
                    new MySqlParameter("WbsLevelOne_In", MySqlDbType.VarChar) {Value = wbsLevelOne}
                }; ;
                var result = DbReaderHelper.ExecuteReader(
                    "pub_AIFA_GetWbsInfo",
                    parameters,
                        dr => new WBSDetailsTransformer().Transform(dr).FirstOrDefault());

                return _mapper.Map<WBSDetailsModel, WBSDetails>(result);


            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public Archive CreateArchive(Archive createArchiveRequest)
        {
            Exception e = new Exception();
            try
            {
                //string ArchiveNumber = "";

                var parameters = Builder.Bind(CreateArchiveFieldParameter.WBSLevelOneNumber).On(createArchiveRequest.WBSLevelOneNumber) //createArchiveRequest.WBSNumber
                                        .Bind(CreateArchiveFieldParameter.Description).On(createArchiveRequest.ArchiveInfo.Description) //createArchiveRequest.ArchiveInfo.EngagementDesc
                                        .Bind(CreateArchiveFieldParameter.AdditionalDescription).On(createArchiveRequest.ArchiveInfo.AdditionalDescription)//createArchiveRequest.ArchiveInfo.AdditionalDescriptor
                                        .Bind(CreateArchiveFieldParameter.EngagementDescription).On(createArchiveRequest.ArchiveInfo.EngagementDesc)//createArchiveRequest.ArchiveInfo.EngagementDesc
                                        .Bind(CreateArchiveFieldParameter.PeriodEndDate).On(createArchiveRequest.ArchiveInfo.PeriodEnd)//createArchiveRequest.PeriodEndDate
                                        .Bind(CreateArchiveFieldParameter.EngagementType).On(createArchiveRequest.ArchiveInfo.EngagementType)//createArchiveRequest.ArchiveInfo.EngagementType
                                        .Bind(CreateArchiveFieldParameter.Estimatedissuancedate).On(createArchiveRequest.ArchiveInfo.EstimatedDate)//createArchiveRequest.ArchiveInfo.EstimatedDate
                                        .Bind(CreateArchiveFieldParameter.ArchiveType).On(createArchiveRequest.ArchiveInfo.ArchiveType)//createArchiveRequest.ArchiveInfo.ArchiveType
                                        .Bind(CreateArchiveFieldParameter.EntityType).On(createArchiveRequest.ArchiveInfo.EntityType)//createArchiveRequest.ArchiveInfo.EntityType
                                        .Bind(CreateArchiveFieldParameter.ArchivePartner).On(createArchiveRequest.WBSInfo.WBSEngagementPPMD) //createArchiveRequest.WBSInfo.WBSEngagementPPMD
                                        .Bind(CreateArchiveFieldParameter.ArchiveManager).On(createArchiveRequest.WBSInfo.EngagementManager)//createArchiveRequest.WBSInfo.EngagementManager
                                        .Bind(CreateArchiveFieldParameter.ArchiveFieldSenior).On(createArchiveRequest.ArchiveInfo.ArchiveFieldSenior)//recheck
                                        .Bind(CreateArchiveFieldParameter.AdditionalArchiveFieldSenior).On(createArchiveRequest.ArchiveInfo.AdditionalArchiveFieldSenior)
                                        .Bind(CreateArchiveFieldParameter.createdby).On(createArchiveRequest.ArchiveInfo.Createdby)
                                        .Bind(CreateArchiveFieldParameter.RoleId).On(createArchiveRequest.ArchiveInfo.RoleID)
                                        .Bind(CreateArchiveFieldParameter.ProfessionalStandard).On(createArchiveRequest.ArchiveInfo.ProfessionalStandard)
                                        .Bind(CreateArchiveFieldParameter.ArchiveNum).On(createArchiveRequest.ArchiveInfo.ArchiveNum)
                                        .Bind(CreateArchiveFieldParameter.SigningPartners).On(createArchiveRequest.WBSInfo.SigningPartners)
                                        .Build();

                return DbHelper.ExecuteReader(
                  "pub_AIFA_CreateArchiveForAudit",
                  parameters,
                      dr =>
                      {
                          var archiveEntity = new CreateArchiveTransformer().Transform(dr).FirstOrDefault();

                          var archive = _mapper.Map<ArchiveModel, Archive>(archiveEntity);

                          return archive;



                      });


            }
            catch (Exception ex)
            {
                e = ex;
                throw e;
            }
        }


        //public List<MyArchive> GetMyArchives(int personnelNumber, int pageNumber, int pageSize, string sortDirection, string orderBy, string search)
        public List<MyArchive> GetMyArchives(string employeeUniqueIdentifier, int pageNumber, int pageSize, int sortBy, int filterBy, string filterText)
        {
            try
            {
                var parameters = Builder
                    .Bind(MyArchiveFieldParameter.EmployeeUniqueIdentifier).On(employeeUniqueIdentifier)
                    .Bind(MyArchiveFieldParameter.PageNumber).On(pageNumber)
                    .Bind(MyArchiveFieldParameter.PageSize).On(pageSize)
                    .Bind(MyArchiveFieldParameter.SortBy).On(sortBy)
                    .Bind(MyArchiveFieldParameter.FilterBy).On(filterBy)
                    .Bind(MyArchiveFieldParameter.FilterText).On(filterText)
                    .Build();

                var result = DbHelper.ExecuteReader(
                    "pub_AIFA_GetMyArchives",
                    parameters,
                        dr => new MyArchiveTransformer().Transform(dr).ToList());

                return _mapper.Map<List<MyArchiveModel>, List<MyArchive>>(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<ArchiveAccessRequestForApproval> GetArchiveAccessRequestsForApproval(string employeeUniqueIdentifier, int pageNumber, int pageSize)
        {
            try
            {
                var parameters = Builder
                    .Bind(ArchiveAccessRequestForApprovalParameter.EmployeeUniqueIdentifier).On(employeeUniqueIdentifier)
                    .Bind(ArchiveAccessRequestForApprovalParameter.PageNumber).On(pageNumber)
                    .Bind(ArchiveAccessRequestForApprovalParameter.PageSize).On(pageSize)
                    .Build();

                var result = DbHelper.ExecuteReader(
                    "pub_AIFA_GetMyArchiveAccessRequests",
                    parameters,
                        dr => new ArchiveAccessRequestForApprovalTransformer().Transform(dr).ToList());

                return _mapper.Map<List<ArchiveAccessRequestsForApprovalModel>, List<ArchiveAccessRequestForApproval>>(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public ArchiveAccessRequestDetailsReport GetArchiveAccessRequestDetailsReport(string employeeUniqueIdentifier, int pageNumber, int pageSize)
        {
            var parameters = Builder
                    .Bind(ArchiveAccessRequestForApprovalParameter.EmployeeUniqueIdentifier).On(employeeUniqueIdentifier)
                    .Bind(ArchiveAccessRequestForApprovalParameter.PageNumber).On(pageNumber)
                    .Bind(ArchiveAccessRequestForApprovalParameter.PageSize).On(pageSize)
                    .Build();
            var storageReport = new ArchiveAccessRequestDetailsReport();
            var result = DbHelper.ExecuteReader(
                "pub_AIFA_GetMyArchiveAccessRequests_test1",
                parameters,
                    dr =>
                    {
                        //var storageReport = new ArchiveAccessRequestDetailsReport();
                        //dr.Read();
                        //storageReport.IsDataTruncated = bool.Parse(dr[0].ToString());
                        //dr.NextResult();
                        //storageReport.List = new ArchiveAccessRequestDetailsTransformer().Transform(dr).ToList();
                        return storageReport;
                    });
            return storageReport;
        }

        public List<ArchiveAccessRequestDetails> GetArchiveAccessRequestsDetailsReport(string employeeUniqueIdentifier, int pageNumber, int pageSize)
        {
            var parameters = Builder
                    .Bind(ArchiveAccessRequestForApprovalParameter.EmployeeUniqueIdentifier).On(employeeUniqueIdentifier)
                    .Bind(ArchiveAccessRequestForApprovalParameter.PageNumber).On(pageNumber)
                    .Bind(ArchiveAccessRequestForApprovalParameter.PageSize).On(pageSize)
                    .Build();
            var storageReport = new ArchiveAccessRequestDetailsReport();
            var result = DbHelper.ExecuteReader(
                "pub_AIFA_GetMyArchiveAccessRequestsExportToExcel",
                parameters,
                    dr => new ArchiveAccessRequestDetailsTransformer().Transform(dr).ToList());
            return _mapper.Map<List<ArchiveAccessRequestDetailsModel>, List<ArchiveAccessRequestDetails>>(result);
        }
        public List<MyForm3283Data> GetForm3283RequestDetailsToExportToExcel(string employeeUniqueIdentifier, int pageNumber, int pageSize)
        {
            var parameters = Builder
                    .Bind(ArchiveAccessRequestForApprovalParameter.EmployeeUniqueIdentifier).On(employeeUniqueIdentifier)
                    .Bind(ArchiveAccessRequestForApprovalParameter.PageNumber).On(pageNumber)
                    .Bind(ArchiveAccessRequestForApprovalParameter.PageSize).On(pageSize)
                    .Build();

            var result = DbHelper.ExecuteReader(
                "pub_AIFA_GetMyForm3283sRequestsExportToExcel",
                parameters,
                    dr => new MyForm3283DetailsExportToExcelTransformer().Transform(dr).ToList());

            return _mapper.Map<List<MyForm3283DataModel>, List<MyForm3283Data>>(result);
        }

        public List<MyPendingSubmissionData> GetMyPendingSubmissionDashBoardDataToExcel(string employeeUniqueIdentifier, int pageNumber, int pageSize)
        {
            var parameters = Builder
                    .Bind(ArchiveAccessRequestForApprovalParameter.EmployeeUniqueIdentifier).On(employeeUniqueIdentifier)
                    .Bind(ArchiveAccessRequestForApprovalParameter.PageNumber).On(pageNumber)
                    .Bind(ArchiveAccessRequestForApprovalParameter.PageSize).On(pageSize)
                    .Build();

            var result = DbHelper.ExecuteReader(
                "pub_AIFA_GetMyPendingSubmissionDashBoardDataToExcel",
                parameters,
                    dr => new MyPendingSubmissionExportToExcelTransformer().Transform(dr).ToList());

            return _mapper.Map<List<MyPendingSubmissionDataModel>, List<MyPendingSubmissionData>>(result);
        }

        public MyArchiveDetails GetMyArchiveDetails(string archiveNumber)
        {
            try
            {
                var parameters = Builder.Bind(MyArchiveDetailsFieldParameter.ArchiveNumber).On(archiveNumber).Build();

                var result = DbHelper.ExecuteReader(
                    "pub_AIFA_GetMyArchiveDetails",
                    parameters,
                        dr => new MyArchiveDetailsTransformer().Transform(dr).ToList());

                return _mapper.Map<MyArchiveDetailsModel, MyArchiveDetails>(result.FirstOrDefault());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<ExistingArchivesInfo> GetExistingArchivesDetails(string wbsLevelOne, string userAlias, int PageNumber, int PageSize)
        {
            try
            {

                var parameters = Builder.Bind(ExistingArchivesInfoFieldParameter.WbsLevelOne).On(wbsLevelOne)
                                .Bind(ExistingArchivesInfoFieldParameter.UserAlias).On(userAlias)
                                .Bind(ExistingArchivesInfoFieldParameter.p_PageNumber).On(PageNumber)
                                 .Bind(ExistingArchivesInfoFieldParameter.p_PageSize).On(PageSize).Build();

                var result = DbHelper.ExecuteReader(
                    "pub_AIFA_GetWbsArchiveDetails",
                    parameters,
                    dr => new ExistingArchivesInfoTransformer().Transform(dr).ToList());

                return _mapper.Map<List<ExistingArchivesInfoModel>, List<ExistingArchivesInfo>>(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public ProjectMetaData GetSwiftEngagementInfo(string wbsLevelOne)
        {
            try
            {
                var parameters = new MySqlParameter[]
                {
                    new MySqlParameter("p_WbsLevelOne", MySqlDbType.VarChar) {Value = wbsLevelOne}
                };
                var result = DbHelper.ExecuteReader(
                    "pub_AIFA_GetSwiftEngagementInfo",
                    parameters,
                    dr => new ProjectDetailsTransformer().Transform(dr).FirstOrDefault());

                return _mapper.Map<ProjectMetaDataModel, ProjectMetaData>(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int GetMatRoiUpdates(string archiveNumber)
        {
            try
            {
                var parameters = GetBuilderInstance().Bind(ArchiveDetailsInfoParameter.ArchiveNumber).On(archiveNumber)
                     .Bind(ArchiveDetailsInfoParameter.UpdateROIResult_Out).On()
                    .Build();

                var result = DbReaderHelper.ExecuteNonQuery("pub_AIFA_GetMatROIUpdates", parameters, cmd => Convert.ToInt32(cmd.Parameters["@UpdateROIResult_Out"].Value.ToString()));
                return result;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public ArchiveDetails GetArchiveDetailsInfo(string archiveNumber, string employeeUniqueIdentifier)
        {
            try
            {
                var parameters = GetBuilderInstance().Bind(ArchiveDetailsInfoParameter.ArchiveNumber).On(archiveNumber)
                    .Bind(ArchiveDetailsInfoParameter.EmployeeUniqueIdentifier).On(employeeUniqueIdentifier)
                    .Build();

                var result = DbHelper.ExecuteReader(
                    "pub_AIFA_GetArchiveInfo",
                    parameters,
                        dr => new ArchiveDetailsInfoTransformer().Transform(dr).ToList());

                return _mapper.Map<ArchiveDetailsModel, ArchiveDetails>(result.FirstOrDefault());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public ArchiveTeamChangeDetailsData UpdateArchiveTeam(ArchiveTeam archiveTeam,string argUserAlias)
        {
            try
            {
                var parameters = Builder.Bind(ArchiveTeamFieldParameter.ArchiveNumber).On(archiveTeam.ArchiveNumber)
                                        .Bind(ArchiveTeamFieldParameter.Createdby).On(archiveTeam.CreatedBy)
                                        .Bind(ArchiveTeamFieldParameter.ArchiveManager).On(archiveTeam.ArchiveManager)
                                        .Bind(ArchiveTeamFieldParameter.ArchivePartner).On(archiveTeam.ArchivePartner)
                                        .Bind(ArchiveTeamFieldParameter.ArchiveFieldSenior).On(archiveTeam.ArchiveFieldSenior)
                                        .Bind(ArchiveTeamFieldParameter.AddArchiveFieldSenior).On(archiveTeam.AdditionalArchiveFieldSenior)
                                        .Bind(ArchiveTeamFieldParameter.SigningPartners).On(archiveTeam.SigningPartners)
                                        .Bind(ArchiveTeamFieldParameter.TeamChangedBy).On(argUserAlias)
                                        .Build();

                /* DbHelper.ExecuteNonQuery(
                     "pub_AIFA_InsertAndUpdateRoles",
                     parameters);

               */
                var result = DbHelper.ExecuteReader(
                    "pub_AIFA_InsertAndUpdateRoles",
                    parameters,
                        dr => new ArchiveTeamChangeDetailsTransformer().TransformElement(dr));

                return _mapper.Map<ArchiveTeamChangeDetailsModel, ArchiveTeamChangeDetailsData>(result);
                //return "Success";
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public EditArchiveDetails GetEditArchiveDetails(string archiveNumber)
        {
            try
            {
                var parameters = new MySqlParameter[]
                {
                        new MySqlParameter("@ArchiveNumber_In",MySqlDbType.VarChar){Value=archiveNumber}
                };
                var result = DbHelper.ExecuteReader(
                "pub_AIFA_GetArchiveDetailsByArchiveNumber",
                parameters,
                dr => new EditArchiveDetailsTransformer().Transform(dr).ToList());

                return _mapper.Map<EditArchiveDetailsModel, EditArchiveDetails>(result.FirstOrDefault());

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public AutoCreateArchiveDetails GetAutoCreateArchiveDetails(string archiveNumber)
        {
            try
            {
                var parameters = Builder.Bind(AutocreateArchiveinputparameter.ArchiveNumber_In).On(archiveNumber)
                                .Build();

                var result = DbReaderHelper.ExecuteReader(
                "pub_AIFA_GetDetailsOfAutoCreateAchive",
                parameters,
                dr => new AutoCreateArchiveDetailsTransformer().Transform(dr).ToList());

                return _mapper.Map<AutoCreateArchiveDetailsModel, AutoCreateArchiveDetails>(result.FirstOrDefault());

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string UpdateArchiveDetails(UpdateArchive updateArchive)
        {
            try
            {
                var parameters = Builder.Bind(EditArchiveDetailsFieldParameter.ArchiveNumber).On(updateArchive.ArchiveNumber)
                                        .Bind(EditArchiveDetailsFieldParameter.EngagementDescription).On(updateArchive.EngagementDescription)
                                        .Bind(EditArchiveDetailsFieldParameter.PeriodEndDate).On(updateArchive.PeriodEndDate)
                                        .Bind(EditArchiveDetailsFieldParameter.EngagementTypeDescription).On(updateArchive.EngagementTypeDescription)
                                        .Bind(EditArchiveDetailsFieldParameter.EntityTypeDescription).On(updateArchive.EntityTypeDescription)
                                        .Bind(EditArchiveDetailsFieldParameter.StandardsApplied).On(updateArchive.StandardsApplied)
                                        .Bind(EditArchiveDetailsFieldParameter.ArchiveNameForWBSLevel1Number).On(updateArchive.ArchiveNameForWBSLevel1Number)
                                        .Bind(EditArchiveDetailsFieldParameter.AdditionalDescription).On(updateArchive.AdditionalDescription)
                                        .Bind(EditArchiveDetailsFieldParameter.ModifiedBy).On(updateArchive.ModifiedBy)
                                        .Build();
                DbHelper.ExecuteNonQuery(
                    "pub_AIFA_UpdateArchiveDetails",
                    parameters);

                return "Success";
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<MyArchivesFilterData> GetMyArchivesFilterDataByType(string employeeUniqueIdentifier, int filterBy)
        {
            try
            {
                var parameters = Builder
                    .Bind(MyArchivesFilterDataParameter.EmployeeUniqueIdentifier).On(employeeUniqueIdentifier)
                    .Bind(MyArchivesFilterDataParameter.FilterBy).On(filterBy)
                    .Build();

                var result = DbHelper.ExecuteReader(
                    "pub_AIFA_GetMyArchivesFilterDataByFilterType",
                    parameters,
                        dr => new MyArchivesFilterDataTransformer().Transform(dr).ToList());

                return _mapper.Map<List<MyArchivesFilterDataModel>, List<MyArchivesFilterData>>(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void LogMessageId(string messageId)
        {
            try
            {
                var parameters = Builder.Bind(CreateArchiveFieldParameter.MessageId).On(messageId)
                                        .Build();
                DbHelper.ExecuteNonQuery(
                    "pub_AIFA_LogMessageId",
                    parameters);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public LinkedArchivesStatus GetLinkedArchiveStatus(string archiveNumber, string userAlias)
        {
            try
            {
                LinkedArchivesStatus linkedArchivesStatus = new LinkedArchivesStatus();

                var parameters = GetBuilderInstance().Bind(ArchiveSubmissionCheckInputParameter.ArchiveNumber).On(archiveNumber)
                                .Bind(ArchiveSubmissionCheckInputParameter.UserAlias).On(userAlias).Build();

                var result = DbHelper.ExecuteReader(
                    "pub_AIFA_GetLinkedArchiveSectionStatus",
                    parameters,
                    dr =>
                    {
                        var las = new LinkedArchivesStatusTransformer().Transform(dr);
                        linkedArchivesStatus = _mapper.Map<LinkedArchivesSectionStatusCheckModel, LinkedArchivesStatus>(las.FirstOrDefault());
                        return linkedArchivesStatus;
                    }
                    );

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public ArchiveSubmissionStatus GetDateAndPeoplePickerStatus(string archiveNumber, string userAlias)
        {
            try
            {

                var parameters = GetBuilderInstance().Bind(ArchiveSubmissionCheckInputParameter.ArchiveNumber).On(archiveNumber)
                                .Bind(ArchiveSubmissionCheckInputParameter.UserAlias).On(userAlias).Build();

                var result = DbHelper.ExecuteReader(
                    "pub_AIFA_GetDateAndPeoplePickerStatus",
                    parameters,
                    dr =>
                    {
                        ArchiveSubmissionStatus archiveSubmissionStatus = new ArchiveSubmissionStatus();
                        var wps = new WorkingPapersStatusTransformer().Transform(dr);
                        dr.NextResult();
                        var dps = new DeliverablesStatusTransformer().Transform(dr);
                        dr.NextResult();
                        var bins = new BindersStatusTransformer().Transform(dr);
                        archiveSubmissionStatus.BinderStatus = _mapper.Map<BindersSectionStatusCheckModel, BindersStatus>(bins.FirstOrDefault());
                        dr.NextResult();

                        var pps = new ArchiveDateAndPeoplePickerDetailsTransformer().Transform(dr);
                        archiveSubmissionStatus = _mapper.Map<ArchiveSubmissionCheckModel, ArchiveSubmissionStatus>(pps.FirstOrDefault());
                        archiveSubmissionStatus.WorkingPaperStatus = _mapper.Map<WorkingPaperSectionStatusCheckModel, WorkingPapersStatus>(wps.FirstOrDefault());
                        archiveSubmissionStatus.DeliverableStatus = _mapper.Map<DeliverablesStatusCheckModel, DeliverablesStatus>(dps.FirstOrDefault());
                        archiveSubmissionStatus.BinderStatus = _mapper.Map<BindersSectionStatusCheckModel, BindersStatus>(bins.FirstOrDefault());
                        return archiveSubmissionStatus;

                    }
                    //new ArchiveDateAndPeoplePickerDetailsTransformer().Transform(dr)
                    );

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public WorkingPapersStatus GetWorkingPapersStatus(string archiveNumber, string userAlias)
        {
            try
            {

                var parameters = GetBuilderInstance().Bind(ArchiveSubmissionCheckInputParameter.ArchiveNumber).On(archiveNumber)
                                .Bind(ArchiveSubmissionCheckInputParameter.UserAlias).On(userAlias)
                                .Build();

                var result = DbHelper.ExecuteReader(
                    "pub_AIFA_GetWorkingPaperSectionStatus",
                    parameters,
                    dr => new WorkingPapersStatusTransformer().Transform(dr));

                return _mapper.Map<WorkingPaperSectionStatusCheckModel, WorkingPapersStatus>(result.FirstOrDefault());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DeliverablesStatus GetDeliverablesStatus(string archiveNumber, string userAlias)
        {
            try
            {

                var parameters = GetBuilderInstance().Bind(ArchiveSubmissionCheckInputParameter.ArchiveNumber).On(archiveNumber)
                                .Bind(ArchiveSubmissionCheckInputParameter.UserAlias).On(userAlias)
                                .Build();

                var result = DbHelper.ExecuteReader(
                    "pub_AIFA_GetDeliverablesSectionStatus",
                    parameters,
                    dr => new DeliverablesStatusTransformer().Transform(dr));

                return _mapper.Map<DeliverablesStatusCheckModel, DeliverablesStatus>(result.FirstOrDefault());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public RetentionExceptionStatus GetRetentionExceptionStatus(string archiveNumber, string userAlias)
        {
            try
            {

                var parameters = GetBuilderInstance().Bind(ArchiveSubmissionCheckInputParameter.ArchiveNumber).On(archiveNumber)
                                .Bind(ArchiveSubmissionCheckInputParameter.UserAlias).On(userAlias)
                                .Build();

                var result = DbReaderHelper.ExecuteReader(
                    "pub_AIFA_GetRetentionExceptionSectionStatus",
                    parameters,
                    dr => new RetentionExceptionStatusTransformer().Transform(dr));

                return _mapper.Map<RetentionExceptionStatusCheckModel, RetentionExceptionStatus>(result.FirstOrDefault());

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public EngagementRelatedPersonalStatus GetEngagementRelatedPersonalStatus(string archiveNumber)
        {
            try
            {

                var parameters = GetBuilderInstance().Bind(ArchiveSubmissionCheckInputParameter.ArchiveNumber).On(archiveNumber)
                                .Build();

                var result = DbReaderHelper.ExecuteReader(
                    "pub_AIFA_GetEngagementRelatedPersonalStatus",
                    parameters,
                    dr => new EngagementRelatedPersonalStatusTransformer().Transform(dr));

                return _mapper.Map<EngagementRelatedPersonalStatusCheckModel, EngagementRelatedPersonalStatus>(result.FirstOrDefault());

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public ArchiveSubmission CreateArchiveSubmission(ArchiveSubmission archiveSubmission)
        {
            try
            {
                var parameters = Builder.Bind(ArchiveSubmissionParameter.ArchiveNumber).On(archiveSubmission.ArchiveNumber)
                                        .Bind(ArchiveSubmissionParameter.PPDUserAlias).On(archiveSubmission.PPDUserAlias)
                                        .Bind(ArchiveSubmissionParameter.EstimatedDate).On(archiveSubmission.EstimatedDate)
                                        .Bind(ArchiveSubmissionParameter.CreatedBy).On(archiveSubmission.CreatedBy)
                                        .Bind(ArchiveSubmissionParameter.RoleId).On(archiveSubmission.RoleID)
                                        .Build();

                return DbHelper.ExecuteReader(
                     "pub_AIFA_UpdateAfterSubmission",
                     parameters,
                         dr =>
                         {
                             var archivesubEntity = new ArchiveSubmissionTransformer().Transform(dr).ToList().FirstOrDefault();

                             var archiveSubmissionResult = _mapper.Map<ArchiveSubmissionModel, ArchiveSubmission>(archivesubEntity);

                             return archiveSubmissionResult;

                         });

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public ArchiveRetentionDetails GetArchiveRetentionDetails(string archiveNumber)
        {
            try
            {
                var parameters = new MySqlParameter[]
               {
                        new MySqlParameter("p_ArchiveNumber",MySqlDbType.VarChar){Value=archiveNumber}
               };

                var result = DbHelper.ExecuteReader(
                    "pub_GetArchiveRetentionDetails",
                    parameters,
                        dr => new ArchiveRetentionTransformer().Transform(dr).ToList().FirstOrDefault());

                return _mapper.Map<ArchiveRetentionDetailsModel, ArchiveRetentionDetails>(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public string UpdateEstimatedReleaseDate(string ArchiveNumber, DateTime EstimatedReleaseDate)
        {
            try
            {
                var parameters = Builder.Bind(ArchiveEstimatedReleaseDateFieldParameter.ArchiveNumber).On(ArchiveNumber)
                                        .Bind(ArchiveEstimatedReleaseDateFieldParameter.EstimatedReleaseDate).On(EstimatedReleaseDate)

                                        .Build();
                DbHelper.ExecuteNonQuery(
                    "pub_AIFA_UpdateEstimatedReleaseDate",
                    parameters);
                return "Success";
            }
            catch (Exception ex)
            { throw ex; }
        }

        public string SubtantiveResubmissionUpdatePPDorNPPD(string ArchiveNumber, string CreatedBy, string PPDUserAlias, int IsPPD)
        {

            try
            {

                var parameters = Builder.Bind(ResubmissionUpdatePPDORNPPDParameter.ArchiveNumber).On(ArchiveNumber)
                                        .Bind(ResubmissionUpdatePPDORNPPDParameter.CreatedBy).On(CreatedBy)
                                        .Bind(ResubmissionUpdatePPDORNPPDParameter.PPDUserAlias).On(PPDUserAlias)
                                        .Bind(ResubmissionUpdatePPDORNPPDParameter.IsPPD).On(IsPPD)

                                        .Build();
                DbHelper.ExecuteNonQuery(
                     "pub_AIFA_UpdateSubstantivePPDandNPPD",
                     parameters);
                return "Success";
            }
            catch (Exception ex)
            { throw ex; }
        }

        public List<ResubmissionApproverList> SubtantiveResubmissionGetPPDorNPPD(string ArchiveNumber)
        {
            try
            {

                var parameters = Builder.Bind(ResubmissionUpdatePPDORNPPDParameter.ArchiveNumber).On(ArchiveNumber)
                                        .Build();
                var result = DbHelper.ExecuteReader(
                   "pub_AIFA_GetSubstantivePPDandNPPD",
                   parameters,
                   dr => new ResubmissionApproverListTransformer().Transform(dr));

                return _mapper.Map<List<ResubmissionApproverListModel>, List<ResubmissionApproverList>>(result.ToList());
            }
            catch (Exception ex)
            { throw ex; }
        }

        public IList<ArchiveAction> GetArchiveActions(string archiveNumber)
        {
            try
            {

                var parameters = GetBuilderInstance().Bind(ArchiveActionsInputParameter.ArchiveNumber).On(archiveNumber)
                                 .Build();

                var result = DbReaderHelper.ExecuteReader(
                        "pub_AIFA_GetArchiveActions",
                        parameters,
                        dr => new ArchiveActionsTransformer().Transform(dr));

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public IList<ArchiveAtcionsForIndividualSections> GetArchiveAtcionsForIndividualSections(string archiveNumber)
        {
            try
            {

                var parameters = GetBuilderInstance().Bind(ArchiveActionsInputParameter.ArchiveNumber).On(archiveNumber)
                                 .Build();

                var result = DbReaderHelper.ExecuteReader(
                        "pub_AIFA_GetArchiveFlowIndividualActions",
                        parameters,
                        dr => new ArchiveActionsIndividualSectionTransformer().Transform(dr));

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public EarlyTerminationCeasedDate AddEarlyTerminationDate(EarlyTerminationCeasedDate EarlyTerminationValues)
        {
            try
            {
                var parameters = Builder.Bind(ArchiveEarlyTerminationDateFieldParameter.ArchiveNumber).On(EarlyTerminationValues.ArchiveNumber)
                                        .Bind(ArchiveEarlyTerminationDateFieldParameter.EarlyTerminationDate).On(EarlyTerminationValues.EarlyTerminationDate)
                                        .Bind(ArchiveEarlyTerminationDateFieldParameter.EarlyTerminated).On(EarlyTerminationValues.EarlyTerminated)
                                        .Bind(ArchiveEarlyTerminationDateFieldParameter.ModifiedBy).On(EarlyTerminationValues.ModifiedBy)

                                        .Build();
                return DbHelper.ExecuteReader(
                        "pub_AIFA_InsertEarlyTerminationDate",
                        parameters,
                        dr =>
                        {
                            var archivesubEntity = new ArchiveEarlyTerminationDateTransformer().Transform(dr).ToList().FirstOrDefault();

                            var archiveSubmissionResult = _mapper.Map<EarlyTerminationDataModel, EarlyTerminationCeasedDate>(archivesubEntity);

                            return archiveSubmissionResult;

                        });



            }
            catch (Exception ex)
            { throw ex; }
        }
        public EarlyTerminationCeasedDate getEarlyTerminationDate(EarlyTerminationCeasedDate fetchEarlyTerminationValues)
        {
            try
            {
                var parameters = Builder.Bind(ArchiveEarlyTerminationDateFieldParameter.ArchiveNumber).On(fetchEarlyTerminationValues.ArchiveNumber)
                                        .Bind(ArchiveEarlyTerminationDateFieldParameter.EarlyTerminationDate).On(fetchEarlyTerminationValues.EarlyTerminationDate)
                                        .Bind(ArchiveEarlyTerminationDateFieldParameter.EarlyTerminated).On(fetchEarlyTerminationValues.EarlyTerminated)

                                        .Build();
                return DbHelper.ExecuteReader(
                        "pub_AIFA_FetchEarlyTerminationDate",
                        parameters,
                        dr =>
                        {
                            var archivesubEntity = new ArchiveEarlyTerminationDateTransformer().Transform(dr).ToList().FirstOrDefault();

                            var archiveSubmissionResult = _mapper.Map<EarlyTerminationDataModel, EarlyTerminationCeasedDate>(archivesubEntity);

                            return archiveSubmissionResult;

                        });



            }
            catch (Exception ex)
            { throw ex; }
        }


        public string InsertTempArciveTeam(TemporaryArchiveTeam archiveTeam)
        {
            try
            {
                var parameters = Builder.Bind(TempArchiveTeamFieldParameter.ArchiveNumber).On(archiveTeam.ArchiveNumber)
                                        .Bind(TempArchiveTeamFieldParameter.Createdby).On(archiveTeam.CreatedBy)
                                        .Bind(TempArchiveTeamFieldParameter.TempArchiveManager).On(archiveTeam.TempArchiveManager)
                                        .Bind(TempArchiveTeamFieldParameter.TempArchiveManagerExpDate).On(archiveTeam.TempArchiveManagerExpDate)
                                        .Bind(TempArchiveTeamFieldParameter.TempArchiveFieldSenior).On(archiveTeam.TempArchiveFieldSenior)
                                        .Bind(TempArchiveTeamFieldParameter.TempArchiveFieldSeniorExpDate).On(archiveTeam.TempArchiveFieldSeniorExpDate)
                                        .Bind(TempArchiveTeamFieldParameter.TempArchivePartner).On(archiveTeam.TempArchivePartner)
                                        .Bind(TempArchiveTeamFieldParameter.TempArchivePartnerExpDate).On(archiveTeam.TempArchivePartnerExpDate)
                                        .Build();
                DbHelper.ExecuteNonQuery(
                    "pub_AIFA_InsertTemporaryRoles",
                    parameters);

                return "Success";
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public InsertArchiveAccessRequest CreateTempArchiveAccessRequest(RequestTemporaryArchiveAccess requestAccess)
        {
            try
            {
                var parameters = Builder.Bind(TempRequestArchiveAccessFieldParameter.ArchiveNumber).On(requestAccess.ArchiveNumber)
                                        .Bind(TempRequestArchiveAccessFieldParameter.Description).On(requestAccess.Description)
                                        .Bind(TempRequestArchiveAccessFieldParameter.DispositionTypeId).On(requestAccess.DispositionTypeId)
                                        .Bind(TempRequestArchiveAccessFieldParameter.RequestedBy).On(requestAccess.RequestedBy)
                                        .Bind(TempRequestArchiveAccessFieldParameter.RequestedOf).On(requestAccess.RequestedOf)
                                        .Build();

                var result = DbHelper.ExecuteReader(
                    "pub_AIFA_InsertArchiveAccessRequestDetails_WithRepeatCheck",
                    parameters,
                        dr => new InsertArchiveAccessRequestTransformer().Transform(dr).ToList().FirstOrDefault());

                return _mapper.Map<InsertArchiveAccessRequestModel, InsertArchiveAccessRequest>(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public RequestCountForApproval GetArchiveAccessRequestCountForApproval(string EmployeeUniqueIdentifier)
        {
            try
            {
                var parameters = Builder
                    .Bind(ArchiveAccessRequestCountForApprovalParameter.EmployeeUniqueIdentifier).On(EmployeeUniqueIdentifier)
                    .Build();

                var result = DbHelper.ExecuteReader(
                    "pub_AIFA_GetActionItemCountForRequestTempArchiveAccess",
                    parameters,
                        dr => new ArchiveAccessRequestCountForApprovalTransformer().Transform(dr).ToList().FirstOrDefault());

                return _mapper.Map<ArchiveAccessRequestCountForApprovalModel, RequestCountForApproval>(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public RequestCountForApproval GetForm3283sCountForApproval(string EmployeeUniqueIdentifier)
        {
            try
            {
                var parameters = Builder
                    .Bind(Form3283sCountForApprovalParameter.EmployeeUniqueIdentifier).On(EmployeeUniqueIdentifier)
                    .Build();

                var result = DbHelper.ExecuteReader(
                    "pub_AIFA_GetActionItemCountForForm3283sRequest",
                    parameters,
                        dr => new ArchiveAccessRequestCountForApprovalTransformer().Transform(dr).ToList().FirstOrDefault());

                return _mapper.Map<ArchiveAccessRequestCountForApprovalModel, RequestCountForApproval>(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public FormStatus GetFormStatus(string archiveNumber, int timeOffset = 0)
        {
            try
            {
                var parameters = Builder.Bind(FormFieldParameter.ArchiveNumber).On(archiveNumber)
                                        .Bind(FormFieldParameter.TimeOffset).On(timeOffset)
                                 .Build();
                var result = DbHelper.ExecuteReader(
                    "pub_AIFA_GetForm3283Status",
                    parameters,
                dr => new FormStatusTransformer().TransformElement(dr));
                return _mapper.Map<FormStatusModel, FormStatus>(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string GrantDenyTempArchiveAccessRequest(GrantDenyTemporaryArchiveAccess argGrantDenyAccess)
        {
            string ReturnMessage = "Grant/Deny action Failure";
            try
            {
                var parameters = Builder.Bind(GrantDenyTempArchiveAccessFieldParameter.ArchiveAccessRequestId).On(argGrantDenyAccess.ArchiveAccessRequestId)
                                        .Bind(GrantDenyTempArchiveAccessFieldParameter.GrantDenyReason).On(argGrantDenyAccess.GrantDenyReason)
                                        .Bind(GrantDenyTempArchiveAccessFieldParameter.GrantOrDeny).On(argGrantDenyAccess.GrantOrDeny)
                                        .Build();
                Console.WriteLine("ReqId:" + argGrantDenyAccess.ArchiveAccessRequestId + "Reason : " + argGrantDenyAccess.GrantDenyReason + " GrantOrDeny :" + argGrantDenyAccess.GrantOrDeny);
                DbHelper.ExecuteNonQuery("pub_AIA_GrantTemporaryArchiveAccess", parameters);
                Console.WriteLine("Executed pub_AIA_GrantTemporaryArchiveAccess");
                ReturnMessage = "Grant/Deny action Success";
                Console.WriteLine(ReturnMessage);
                return ReturnMessage;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Message : " + ex.Message + Environment.NewLine + " Stacktrac : " + ex.StackTrace);
                Console.WriteLine(ReturnMessage);
                ReturnMessage = "Action Unsuccessful";
                throw ex;
            }
            return ReturnMessage;
        }

        public Object GetTemporaryArchiveAccessRequest(GrantDenyTemporaryArchiveAccess argGrantDenyAccess)
        {
            string ReturnMessage = "getting details";
            try
            {
                var parameters = Builder.Bind(GrantDenyTempArchiveAccessFieldParameter.ArchiveAccessRequestId).On(argGrantDenyAccess.ArchiveAccessRequestId)
                                        //.Bind(GrantDenyTempArchiveAccessFieldParameter.Message).On(ReturnMessage)
                                        .Build();

                Console.WriteLine("Received req id :" + argGrantDenyAccess.ArchiveAccessRequestId);
                Console.WriteLine("Parameter " + parameters[0].ParameterName + ": " + "Value is" + parameters[0].Value.ToString());
                Console.WriteLine("Executed pub_AIA_GetTempAccessRequestDetails");

                Console.WriteLine(ReturnMessage);

                var result = DbHelper.ExecuteReader(
                        "pub_AIA_GetTempAccessRequestDetails",
                        parameters,
                         dr => new TemporaryArchiveAccessRequestTransformer().Transform(dr).ToList().FirstOrDefault());


                return _mapper.Map<TemporaryArchiveAccessRequestModel, TempArchiveAccessRequest>(result);


            }
            catch (Exception ex)
            {
                Console.WriteLine("Message : " + ex.Message + Environment.NewLine + " Stacktrac : " + ex.StackTrace);
                Console.WriteLine(ReturnMessage);
                throw ex;
            }
        }

        public ArchiveDueDateEngine GetArchiveDueDateCriteria(string ArchiveNumber, string UserAlias)
        {

            try
            {
                var parameters = Builder.Bind(ArchiveDueDateParameter.ArchiveNumber).On(ArchiveNumber)
                                        .Bind(ArchiveDueDateParameter.UserAlias).On(UserAlias)
                                        .Build();
                var result = DbHelper.ExecuteReader(
                     "pub_AIFA_GetArchiveDueDateCriteria",
                     parameters,
                 dr => new ArchiveDueDateTransformer().TransformElement(dr));
                return _mapper.Map<ArchiveDueDateEngineModel, ArchiveDueDateEngine>(result);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Message : " + ex.Message + Environment.NewLine + " Stacktrac : " + ex.StackTrace);
                throw ex;
            }
        }

        public List<ArchiveDeletionStatus> GetArchiveDeletionStatus(string ArchiveNumber)
        {

            try
            {
                var parameters = Builder.Bind(AutocreateArchiveinputparameter.ArchiveNumber_In).On(ArchiveNumber)
                                        .Build();
                var result = DbReaderHelper.ExecuteReader(
                    "pub_AIFA_GetArchiveDeletionStatus",
                    parameters,
                    dr => new ArchiveDeletionStatusTransformer().Transform(dr).ToList());

                return _mapper.Map<List<ArchiveDeletionStatusModel>, List<ArchiveDeletionStatus>>(result);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Message : " + ex.Message + Environment.NewLine + " Stacktrac : " + ex.StackTrace);
                throw ex;
            }
        }

        public string ArchiveResubmissionOpen(ArchiveSubmission archiveSubmission)
        {
            try
            {
                var parameters = Builder.Bind(ArchiveSubmissionParameter.ArchiveNumber).On(archiveSubmission.ArchiveNumber)
                                .Bind(ArchiveSubmissionParameter.RoleId).On(archiveSubmission.RoleID)
                                .Bind(ArchiveSubmissionParameter.CreatedBy).On(archiveSubmission.CreatedBy)
                                .Build();

                DbHelper.ExecuteNonQuery(
                    "pub_AIFA_InitiateResubmitArchiveChanges",
                    parameters);
                return "Success";
            }
            catch (Exception ex)
            { throw ex; }
        }
        public List<ResubmissionApprover> GetResubmissionApproverDetails(string ArchiveNumber, string userAlias)
        {
            try
            {
                var parameters = Builder.Bind(ResubmissionApprovalFlow.ArchiveNumber).On(ArchiveNumber)
                                .Bind(ResubmissionApprovalFlow.UserAlias).On(userAlias).Build();

                var result = DbReaderHelper.ExecuteReader(
                    "pri_AIFA_GetResubmissionApprovalFlow",
                    parameters,
                    dr => new ResubmissionApprovalTrasformer().Transform(dr).ToList());

                return _mapper.Map<List<ResubmissionApproverModel>, List<ResubmissionApprover>>(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public (string successMessage, string archiveStatus, string officeZoneName) InsertResubmissionApprover(string UserAlias, string ArchiveNumber, int? RoleID)
        {
            try
            {
                string archiveStatus = null; 
                string officeZoneName = null;
                var parameters = Builder.Bind(ResubmissionApprovalFlow.ArchiveNumber).On(ArchiveNumber)
                                .Bind(ResubmissionApprovalFlow.RoleID).On(RoleID)
                                .Bind(ResubmissionApprovalFlow.UserAlias).On(UserAlias)
                                .Bind(ResubmissionApprovalFlow.ArchiveStatus).On()
                                .Bind(ResubmissionApprovalFlow.CreatedDateAndZoneName).On()
                                .Build();

                return DbHelper.ExecuteNonQuery(
                 "pri_AIFA_ResubmitInsertApprovalFlow", parameters, cmd =>
                 {
                     archiveStatus = cmd.Parameters["@p_ArchiveStatus_Out"].Value.ToString();
                     officeZoneName = cmd.Parameters["@p_CreatedDateAndZoneName_Out"].Value.ToString();
                     return ("Success", archiveStatus, officeZoneName);
                 });
            }
            catch (Exception ex)
            {
                return ("error", "","");
                throw ex;
            }
        }

        public IList<string> GetROINumbers(string archiveNumber)
        {
            var parameters = Builder.Bind(ResubmissionApprovalFlow.ArchiveNumber).On(archiveNumber)
                              .Build();

            IList<string> roiNumbers = new List<string>();
            var result = DbHelper.ExecuteReader(
                    "pub_AIFA_GetRoiNumbersByArchiveNumber",
                    parameters,
                    dr =>
                    {
                        while (dr.Read())
                        {
                            roiNumbers.Add(dr["RoiNumber"] is DBNull ? null : dr["RoiNumber"].ToString());
                        }
                        return roiNumbers;
                    });

            return result;

        }

        public bool UpdateRoiFilePath(string archiveNumber, string roiNumber, string eTag, long fileTransferId, string s3FilePath, string createdBy)
        {
            try
            {
                var parameters = Builder.Bind(ROIMetadataFieldParameter.ArchiveNumber).On(archiveNumber)
                                   .Bind(ROIMetadataFieldParameter.FileTransferID).On(fileTransferId)
                                   .Bind(ROIMetadataFieldParameter.RoiNumber).On(roiNumber)
                                   .Bind(ROIMetadataFieldParameter.ETag).On(eTag)
                                   .Bind(ROIMetadataFieldParameter.CreatedBy).On(createdBy)
                                   .Bind(ROIMetadataFieldParameter.S3FilePath).On(s3FilePath)
                            .Build();
                var result = DbHelper.ExecuteNonQuery(
                        "pub_AIFA_UpdateRoiFilePath",
                        parameters,
                        dr => true);
                return result;
            }
            catch (Exception ex)
            {
                return false;
            }

        }

        //public List<DeliverableType> GetDeliverableTypes()
        //{
        //    try
        //    {
        //        var result = DbHelper.ExecuteReader(
        //            "pub_AIFA_GetDeliverableTypes",
        //            null,
        //            dr => new DeliverableTypeTransformer().Transform(dr).ToList());
        //        return _mapper.Map<List<DeliverableTypeModel>, List<DeliverableType>>(result);
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}

        public string GetUserAlias(string employeeUniqueIdentifier)
        {
            try
            {
                //var parameters = Builder
                //    .Bind(MyArchiveFieldParameter.EmployeeUniqueIdentifier).On(employeeUniqueIdentifier)
                //    .Bind(MyArchiveFieldParameter.PageNumber).On(pageNumber)
                //    .Bind(MyArchiveFieldParameter.PageSize).On(pageSize)
                //    .Bind(MyArchiveFieldParameter.SortBy).On(sortBy)
                //    .Bind(MyArchiveFieldParameter.FilterBy).On(filterBy)
                //    .Bind(MyArchiveFieldParameter.FilterText).On(filterText)
                //    .Build();

                //var result = DbHelper.ExecuteReader(
                //    "pub_AIFA_GetMyArchives",
                //    parameters,
                //        dr => new MyArchiveTransformer().Transform(dr).ToList());
                string result = employeeUniqueIdentifier;

                //return _mapper.Map<List<MyArchiveModel>, List<MyArchive>>(result);
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public Memo CreateOrUpdateMemo(Memo memovar)
        {
            try
            {
                var parameters = Builder.Bind(ArchiveMemoFieldParameter.FileName).On(memovar.FileName)
                                        .Bind(ArchiveMemoFieldParameter.FileSize).On(memovar.FileSize)
                                        .Bind(ArchiveMemoFieldParameter.FileTypeID).On(memovar.FileTypeID)
                                        .Bind(ArchiveMemoFieldParameter.ETag).On(memovar.ETag)
                                        .Bind(ArchiveMemoFieldParameter.ArchiveNumber).On(memovar.ArchiveNumber)
                                        .Bind(ArchiveMemoFieldParameter.CreatedBy).On(memovar.CreatedBy)
                                        .Build();
                var result = DbHelper.ExecuteReader(
                   "pub_AIFA_CreateOrUpdateUploadMemo",
                   parameters,
                   dr => new CreateMemoTrasformer().Transform(dr).ToList());

                return _mapper.Map<MemoModel, Memo>(result.FirstOrDefault());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public List<Memo> GetUploadedMemo(string ArchiveNumber)
        {
            try
            {

                var parameters = Builder.Bind(ResubmissionApprovalFlow.ArchiveNumber).On(ArchiveNumber)
                                .Build();

                var result = DbHelper.ExecuteReader(
                    "pub_AIFA_GetUploadedMemo",
                    parameters,
                    dr => new GetMemoTrasformer().Transform(dr).ToList());

                return _mapper.Map<List<MemoModel>, List<Memo>>(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public string InsertUpdateArchiveSubmissionFlow(string ArchiveNumber, string UserAlias)
        {
            try
            {
                var parameters = Builder.Bind(ArchiveSubmissionFlowSubmitter.UserAlias).On(UserAlias)
                                        .Bind(ArchiveSubmissionFlowSubmitter.ArchiveNumber).On(ArchiveNumber)
                                        .Bind(ArchiveSubmissionFlowSubmitter.OutputResult).On()
                                        .Build();

                return DbHelper.ExecuteNonQuery("Pub_AIFA_InsertUpdateArchiveSubmissionTransactions", parameters, cmd => cmd.Parameters["@OutputResult"].Value.ToString());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
     
        public GetArchiveApproverFromSubmitter GetArchiveApproverforArchiveSubmission(string ArchiveNumber, string UserAlias, int RoleID)
        {
            try
            {
                var parameters = Builder.Bind(ArchiveSubmissionFlowSubmitter.ArchiveNumber).On(ArchiveNumber)
                                        .Bind(ArchiveSubmissionFlowSubmitter.UserAlias).On(UserAlias)
                                        .Bind(ArchiveSubmissionFlowSubmitter.RoleId).On(RoleID)
                                        .Build();

                var result = DbReaderHelper.ExecuteReader(
                    "Pub_AIFA_GetArchiveApproverForSubmissionFlow",
                    parameters, dr => new GetArchiveApproverTransformer().Transform(dr).ToList());

                return _mapper.Map<GetApproverFromSubmitterModel, GetArchiveApproverFromSubmitter>(result.FirstOrDefault());

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public GetArchiveApproverFromSubmitter CheckAPSubmitterInactive(string ArchiveNumber, string UserAlias, int CheckType)
        {
            try
            {
                var parameters = Builder.Bind(CheckIfAPSubmitterInactive.ArchiveNumber).On(ArchiveNumber)
                                        .Bind(CheckIfAPSubmitterInactive.UserAlias).On(UserAlias)
                                        .Bind(CheckIfAPSubmitterInactive.CheckType).On(CheckType)
                                        .Build();
                var result = DbHelper.ExecuteReader(
                    "Pub_AIFA_CheckforInactiveAP",
                    parameters, dr => new GetArchiveApproverTransformer().Transform(dr).ToList());

                return _mapper.Map<GetApproverFromSubmitterModel, GetArchiveApproverFromSubmitter>(result.FirstOrDefault());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<HoldDetailsMetadata> GetArchivesAssociatedtoHolds(string HoldNumber, int BusinessId, string ClientId, string FilterText, int SortBy)
        {
            var parameters = Builder.Bind(HoldDetailMetadataInputParameter.HoldNumber).On(HoldNumber)
                                    .Bind(HoldDetailMetadataInputParameter.BusinessId).On(BusinessId)
                                    .Bind(HoldDetailMetadataInputParameter.ClientId).On(ClientId)
                                    .Bind(HoldDetailMetadataInputParameter.FilterText).On(FilterText)
                                    .Bind(HoldDetailMetadataInputParameter.SortBy).On(SortBy)
                                        .Build();
            var result = DbHelper.ExecuteReader(
                 "pub_AIFA_GetHoldDetails",
                 parameters,
                     dr => new HoldsMeatadataDetailTransformer().Transform(dr).ToList());
            return _mapper.Map<List<HoldDetailsMetadataModel>, List<HoldDetailsMetadata>>(result);
        }
        public List<AppliedArchiveHoldsInformation> ApplyArchiveHolds(ApplyArchiveHolds applyArchiveHolds)
        {
            var parameters = Builder.Bind(ApplyArchiveHoldsParams.ArchiveNumber).On(applyArchiveHolds.ArchiveNumber)
                              .Bind(ApplyArchiveHoldsParams.HoldNumber).On(applyArchiveHolds.HoldNumber)
                              .Bind(ApplyArchiveHoldsParams.CreatedBy).On(applyArchiveHolds.CreatedBy)
                              .Bind(ApplyArchiveHoldsParams.SortBy).On(applyArchiveHolds.SortBy)
                              .Bind(ApplyArchiveHoldsParams.SortOrder).On(applyArchiveHolds.SortOrder)
                              .Bind(ApplyArchiveHoldsParams.PageNumber).On(applyArchiveHolds.PageNumber)
                              .Bind(ApplyArchiveHoldsParams.PageSize).On(applyArchiveHolds.PageSize)
                                .Build();

            var result = DbHelper.ExecuteReader(
                 "pub_AIFA_ApplyHoldsonArchives",
                 parameters,
                     dr => new ApplyArchiveHoldsTransformer().Transform(dr).ToList());
            return _mapper.Map<List<AppliedArchiveHoldsInformationModel>, List<AppliedArchiveHoldsInformation>>(result);
        }
        public List<AppliedArchiveHoldsInformation> GetArchivesForApplyingHold(string SearchBy, string SearchByValue, string IncludeOrExclude, string HoldName, string Business, string PeriodStart, string PeriodEnd, string SortBy, string SortOrder, int PageNumber, int PageSize)
        {
            var parameters = Builder.Bind(ApplyArchiveHoldsParams.SearchBy).On(SearchBy)
                              .Bind(ApplyArchiveHoldsParams.SearchByValue).On(SearchByValue)
                              .Bind(ApplyArchiveHoldsParams.IncludeOrExclude).On(IncludeOrExclude)
                              .Bind(ApplyArchiveHoldsParams.HoldNumber).On(HoldName)
                              .Bind(ApplyArchiveHoldsParams.Business).On(Business)
                              .Bind(ApplyArchiveHoldsParams.PeriodStart).On(PeriodStart)
                              .Bind(ApplyArchiveHoldsParams.PeriodEnd).On(PeriodEnd)
                              .Bind(ApplyArchiveHoldsParams.SortBy).On(SortBy)
                              .Bind(ApplyArchiveHoldsParams.SortOrder).On(SortOrder)
                              .Bind(ApplyArchiveHoldsParams.PageNumber).On(PageNumber)
                              .Bind(ApplyArchiveHoldsParams.PageSize).On(PageSize)
                                .Build();

            var result = DbHelper.ExecuteReader(
                 "pub_AIFA_GetArchivesForApplyingHold",
                 parameters,
                     dr => new ApplyArchiveHoldsTransformer().Transform(dr).ToList());
            return _mapper.Map<List<AppliedArchiveHoldsInformationModel>, List<AppliedArchiveHoldsInformation>>(result);
        }
        public List<HoldHistoryDetails> GetHoldHistoryDetails(int HoldId,string HoldNumber, int ArchiveHoldHistoryId)
        {
            try
            {
                var parameters = Builder.Bind(GetHoldInfoInputParameter.HoldId).On(HoldId)
                                        .Bind(GetHoldInfoInputParameter.HoldNumber).On(HoldNumber)
                                        .Bind(GetHoldInfoInputParameter.ArchiveHoldHistoryId).On(ArchiveHoldHistoryId)
                                        .Build();
                var result = DbHelper.ExecuteReader(
                    "Pub_AIFA_Holds_GetHoldDetailsHistory",
                    parameters,
                    dr => new GetHoldsDetailsHistoryTransformer().Transform(dr).ToList());
                return _mapper.Map<List<HoldHistoryDetailsModel>, List<HoldHistoryDetails>>(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public string RemoveHoldFromArchive(string ArchiveNumber,string HoldNumber, string userAlias)
        {
            var parameters = Builder.Bind(CreateUpdateHoldInfoParameters.HoldNumber).On(HoldNumber)
                                    .Bind(CreateUpdateHoldInfoParameters.ArchiveNumber).On(ArchiveNumber)
                                    .Bind(CreateUpdateHoldInfoParameters.CreatedBy).On(userAlias)
                                    .Bind(CreateUpdateHoldInfoParameters.Result).On()
                                     .Build();
            var result = DbHelper.ExecuteNonQuery("pub_AIFA_DeleteHoldFromArchive", parameters, cmd => Convert.ToInt32(cmd.Parameters["@p_Result"].Value.ToString()));
            return result.ToString(); ;
        }
        public string RemoveArchiveFromHold(int HoldId, string ArchiveNumber, string userAlias)
        {
            var parameters = Builder.Bind(CreateUpdateHoldInfoParameters.ArchiveNumber).On(ArchiveNumber)
                                    .Bind(CreateUpdateHoldInfoParameters.HoldId).On(HoldId)
                                    .Bind(CreateUpdateHoldInfoParameters.CreatedBy).On(userAlias)
                                    .Bind(CreateUpdateHoldInfoParameters.Result).On()
                                     .Build();
            var result = DbHelper.ExecuteNonQuery("pub_AIFA_DeleteArchiveFromHold", parameters, cmd => Convert.ToInt32(cmd.Parameters["@p_Result"].Value.ToString()));
            return result.ToString(); ;
        }
        public OmniaArchiveSubmissionStatus CheckOmniaSubmissionAllowed(string ArchiveNumber)
        {
            try
            {
                var parameters = Builder.Bind(CheckIfAPSubmitterInactive.ArchiveNumber).On(ArchiveNumber)
                                        .Build();
                var result = DbReaderHelper.ExecuteReader(
                    "pub_AIFA_CheckOmniaSubmissionAllowed",
                    parameters, dr => new OmniaArchiveSubmissionStatusTransformer().Transform(dr).ToList());

                return _mapper.Map<OmniaArchiveSubmissionStatusModel, OmniaArchiveSubmissionStatus>(result.FirstOrDefault());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public string DeleteUploadedMemo(string ArchiveFileID, string userAlias)
        {
            try
            {
                var parameters = Builder.Bind(ArchiveMemoFieldParameter.ArchiveFileID).On(ArchiveFileID)
                                        .Bind(ArchiveMemoFieldParameter.UserAlias).On(userAlias)
                                              .Build();

                DbHelper.ExecuteNonQuery(
                  "pub_AIFA_DeleteUploadedMemo",
                  parameters);

                return "Success";
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public List<ResubmissionReason> GetResubmissionReasons()
        {
            try
            {
                var result = DbHelper.ExecuteReader(
                    "pub_AIFA_GetResubmissionReasons",
                    null,
                    dr => new ResubmissionReasonTransformer().Transform(dr).ToList());
                return _mapper.Map<List<ResubmissionReasonModel>, List<ResubmissionReason>>(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<ArchiveHistory> GetArchiveHistory(string ArchiveNumber, int pageNumber, int pageSize, int sortBy)
        {
            try
            {
                var parameters = Builder
                    .Bind(ArchiveHistoryFieldParameter.ArchiveNumber).On(ArchiveNumber)
                    .Bind(ArchiveHistoryFieldParameter.PageNumber).On(pageNumber)
                    .Bind(ArchiveHistoryFieldParameter.PageSize).On(pageSize)
                    .Bind(ArchiveHistoryFieldParameter.SortBy).On(sortBy)
                    .Build();

                var result = DbHelper.ExecuteReader(
                    "pub_AIFA_GetArchiveHistory",
                    parameters,
                        dr => new ArchiveHistoryTransformer().Transform(dr).ToList());

                return _mapper.Map<List<ArchiveHistoryModel>, List<ArchiveHistory>>(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public string UpdateFirstLevelResubmissionApprovalFlagSet(string ArchiveNumber, string UserAlias)
        {
            try
            {

                var parameters = Builder.Bind(ResubmissionApprovalFlow.ArchiveNumber).On(ArchiveNumber)
                                .Bind(ResubmissionApprovalFlow.UserAlias).On(UserAlias).Build();

                DbHelper.ExecuteNonQuery(
                   "UpdateFirstLevelResubmissionApprovalFlag",
                   parameters);

                return "Success";
            }
            catch (Exception ex)
            {
                return "error";
                throw ex;
            }
        }

        public List<MyPendingSubmissionData> GetMyRequiringApprovalDashBoardDataToExcel(object employeeUniqueIdentifier, object pageNumber, object pageSize)
        {
            var parameters = Builder
                   .Bind(ArchiveAccessRequestForApprovalParameter.EmployeeUniqueIdentifier).On(employeeUniqueIdentifier)
                   .Bind(ArchiveAccessRequestForApprovalParameter.PageNumber).On(pageNumber)
                   .Bind(ArchiveAccessRequestForApprovalParameter.PageSize).On(pageSize)
                   .Build();

            var result = DbHelper.ExecuteReader(
                "pub_AIFA_GetMyRequiringApprovalDashBoardDataToExcel",
                parameters,
                    dr => new MyPendingSubmissionExportToExcelTransformer().Transform(dr).ToList());

            return _mapper.Map<List<MyPendingSubmissionDataModel>, List<MyPendingSubmissionData>>(result);
        }


        public List<MyPendingSubmissionData> GetMyAwaitingApprovalDashBoardDataToExcel(string userAlias, int pageNumber, int pageSize)
        {
            var parameters = Builder
                 .Bind(ArchiveAccessRequestForApprovalParameter.EmployeeUniqueIdentifier).On(userAlias)
                 .Bind(ArchiveAccessRequestForApprovalParameter.PageNumber).On(pageNumber)
                 .Bind(ArchiveAccessRequestForApprovalParameter.PageSize).On(pageSize)
                 .Build();

            var result = DbHelper.ExecuteReader(
                "pub_AIFA_GetMyAwaitingApprovalDashBoardDataToExcel",
                parameters,
                    dr => new MyPendingSubmissionExportToExcelTransformer().Transform(dr).ToList());

            return _mapper.Map<List<MyPendingSubmissionDataModel>, List<MyPendingSubmissionData>>(result);
        }

        public List<MyPendingSubmissionData> GetDeletionRequestsDashBoardDataToExcel(string userAlias, int pageNumber, int pageSize)
        {
            var parameters = Builder
                 .Bind(ArchiveAccessRequestForApprovalParameter.EmployeeUniqueIdentifier).On(userAlias)
                 .Bind(ArchiveAccessRequestForApprovalParameter.PageNumber).On(pageNumber)
                 .Bind(ArchiveAccessRequestForApprovalParameter.PageSize).On(pageSize)
                 .Build();

            var result = DbHelper.ExecuteReader(
                "pub_AIFA_GetDeletionRequestsDashBoardDataToExcel",
                parameters,
                    dr => new MyPendingSubmissionExportToExcelTransformer().Transform(dr).ToList());

            return _mapper.Map<List<MyPendingSubmissionDataModel>, List<MyPendingSubmissionData>>(result);
        }
        public string DeleteArchive(ArchiveDeletionAction deletionrequest)
        {
            try
            {
                var parameters = Builder.Bind(DeleteArchiveParameters.ArchiveNumber).On(deletionrequest.ArchiveNumber)
                                .Bind(DeleteArchiveParameters.DeleteReason).On(deletionrequest.DeleteReason)
                                .Bind(DeleteArchiveParameters.CreatedBy).On(deletionrequest.CreatedBy)
                                .Bind(DeleteArchiveParameters.ActionTypeId).On(deletionrequest.ActionTypeID)
                                .Bind(DeleteArchiveParameters.RejectionReason).On(deletionrequest.RejectionReason)
                                .Build();

                var response = "";
                var AMLogin = "";
                var AMName = "";
                var APLogin = "";
                var APName = "";

                DbHelper.ExecuteReader(
                    "pub_AIFA_DeleteArchiveAction",
                     parameters,
                    dr =>
                    {
                        while (dr.Read())
                        {
                            response = dr["Response"] is DBNull ? string.Empty: (dr["Response"].ToString());
                            AMLogin = dr["AMLogin"] is DBNull ? string.Empty : (dr["AMLogin"].ToString());
                            AMName = dr["AMName"] is DBNull ? string.Empty : (dr["AMName"].ToString());
                            APLogin = dr["APLogin"] is DBNull ? string.Empty : (dr["APLogin"].ToString());
                            APName = dr["APName"] is DBNull ? string.Empty : (dr["APName"].ToString());

                        }

                        response = response + ";" + AMLogin + ";" + APLogin + ";" + AMName + ";"  + APName;
                        return response;
                    });

                return response;
            }
            catch (Exception ex)
            { throw ex; }
        }

        public List<Binders> GetBinderDetails(string archiveNumber, int pageNumber, int pageSize, int sortBy)
        {
            try
            {
                var parameters = new MySqlParameter[]
                {
                    new MySqlParameter("@p_ArchiveNumber", MySqlDbType.VarChar) {Value = archiveNumber},
                    new MySqlParameter("@In_PageNumber", MySqlDbType.Int32) {Value = pageNumber},
                    new MySqlParameter("@In_PageSize", MySqlDbType.Int32) {Value = pageSize},
                    new MySqlParameter("@p_SortBy", MySqlDbType.Int32) {Value = sortBy},
                };
                var result = DbHelper.ExecuteReader(
                    "pub_AIFA_GetBindersByArchiveNumber",
                    parameters,
                        dr => new BinderTransformer().Transform(dr).ToList());

                return _mapper.Map<List<BindersModel>, List<Binders>>(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public string CreateRequestImageAction(RMIntegrationActions requestImage)
        {
            try
            {
                var parameters = Builder.Bind(RMIntegrationParameters.ArchiveNumber).On(requestImage.ArchiveNumber)
                                .Bind(RMIntegrationParameters.BinderID).On(requestImage.BinderID)
                                .Bind(RMIntegrationParameters.RequestedBy).On(requestImage.RequestedBy)
                                .Bind(RMIntegrationParameters.RequestTypeID).On(requestImage.RequestTypeID)
                                .Bind(RMIntegrationParameters.IsBinderOrDeliverable).On(requestImage.IsBinderOrDeliverable)
                                .Build();

                DbHelper.ExecuteNonQuery(
                    "pub_AIFA_CreateRequestImageAction",
                    parameters);
                return "Success";
            }
            catch (Exception ex)
            { throw ex; }
        }
    }
}
