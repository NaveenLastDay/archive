﻿
using Deloitte.AIFA.DomainEntities;

using Deloitte.AIFA.DomainServices.Contracts;

using Deloitte.AIFA.ICloudServices;
using Deloitte.AIFA.IRepositories;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;


namespace Deloitte.AIFA.DomainServices
{
    public class DashBoardService : BaseService, IDashBoardService
    {
        IUserDashBoardRepository _dashboardRepository;
        ILogger _logger;
        IMemoryCache _cache;
        public DashBoardService(IMemoryCache cache, IConfigManager configManager,
                              IUserDashBoardRepository dashboardRepository,
                                ILogger<DashBoardService> logger) : base(cache, configManager)
        {
            _cache = cache;
            _logger = logger;
            _dashboardRepository = dashboardRepository;
        }


        public List<MyForm3283Data> GetForm3283DashBoardData(string EmployeeUniqueIdentifier, int pageNumber, int pageSize)
        {
            _logger.LogInformation(string.Format("Processing {0} service method.", System.Reflection.MethodBase.GetCurrentMethod()));
            List<MyForm3283Data> objForm3283RequestForApproval = null;
            try
            {
                objForm3283RequestForApproval = _dashboardRepository.GetForm3283DashBoardData(EmployeeUniqueIdentifier, pageNumber, pageSize);
                //return objForm3283RequestForApproval;
            }
            catch (Exception ex)
            {
                string validationMessage = "Internal Server Error.Please check the logs.";

                _logger.LogInformation(validationMessage + ex.Message);

                return objForm3283RequestForApproval;
            }
            return objForm3283RequestForApproval;
        }

        public List<ComplianceMetricsDetails> GetComplianceMetrics(string EmployeeUniqueIdentifier, int pageNumber, int pageSize,int sortBy,string filterText)
        {
            _logger.LogInformation(string.Format("Processing {0} service method.", System.Reflection.MethodBase.GetCurrentMethod()));
            List<ComplianceMetricsDetails> objComplianceMetricsDetails = null;
            try
            {
                objComplianceMetricsDetails = _dashboardRepository.GetComplianceMetricsData(EmployeeUniqueIdentifier, pageNumber, pageSize,sortBy,filterText);
                //return objForm3283RequestForApproval;
            }
            catch (Exception ex)
            {
                string validationMessage = "Internal Server Error.Please check the logs.";

                _logger.LogInformation(validationMessage + ex.Message);

                return objComplianceMetricsDetails;
            }
            return objComplianceMetricsDetails;
        }

        public List<MyComplianceData> GetMyAwaitingApprovalDashBoardData(string EmployeeUniqueIdentifier, int pageNumber, int pagesize)
        {
            _logger.LogInformation(string.Format("Processing {0} service method.", System.Reflection.MethodBase.GetCurrentMethod()));
            List<MyComplianceData> objForm3283RequestForApproval = null;
            try
            {
                objForm3283RequestForApproval = _dashboardRepository.GetMyAwaitingApprovalDashBoardData(EmployeeUniqueIdentifier, pageNumber, pagesize);
                //return objForm3283RequestForApproval;
            }
            catch (Exception ex)
            {
                string validationMessage = "Internal Server Error.Please check the logs.";

                _logger.LogInformation(validationMessage + ex.Message);

                return objForm3283RequestForApproval;
            }
            return objForm3283RequestForApproval;
        }

        public List<MyComplianceData> GetArchiveDeletionsDashBoardData(string EmployeeUniqueIdentifier, int pageNumber, int pagesize)
        {
            _logger.LogInformation(string.Format("Processing {0} service method.", System.Reflection.MethodBase.GetCurrentMethod()));
            List<MyComplianceData> archivedeletionapproval = null;
            try
            {
                archivedeletionapproval = _dashboardRepository.GetArchiveDeletionsDashBoardData(EmployeeUniqueIdentifier, pageNumber, pagesize);
                //return objForm3283RequestForApproval;
            }
            catch (Exception ex)
            {
                string validationMessage = "Internal Server Error.Please check the logs.";

                _logger.LogInformation(validationMessage + ex.Message);

                return archivedeletionapproval;
            }
            return archivedeletionapproval;
        }

        public List<MyPendingSubmissionData> GetMyAwaitingSubmissionDashBoardData(string EmployeeUniqueIdentifier, int pageNumber, int pagesize)
        {
            _logger.LogInformation(string.Format("Processing {0} service method.", System.Reflection.MethodBase.GetCurrentMethod()));
            List<MyPendingSubmissionData> objForm3283RequestForApproval = null;
            try
            {
                objForm3283RequestForApproval = _dashboardRepository.GetMyAwaitingSubmissionDashBoardData(EmployeeUniqueIdentifier, pageNumber, pagesize);
                //return objForm3283RequestForApproval;
            }
            catch (Exception ex)
            {
                string validationMessage = "Internal Server Error.Please check the logs.";

                _logger.LogInformation(validationMessage + ex.Message);

                return objForm3283RequestForApproval;
            }
            return objForm3283RequestForApproval;
        }

        public List<MyComplianceData> GetMyRequiringApprovalDashBoardData(string userAlias, int pageNumber, int pagesize)
        {
            _logger.LogInformation(string.Format("Processing {0} service method.", System.Reflection.MethodBase.GetCurrentMethod()));
            List<MyComplianceData> objRequiringSubmission = null;
            try
            {
                objRequiringSubmission = _dashboardRepository.GetMyRequiringApprovalDashBoardData(userAlias, pageNumber, pagesize);
                //return objForm3283RequestForApproval;
            }
            catch (Exception ex)
            {
                string validationMessage = "Internal Server Error.Please check the logs.";

                _logger.LogInformation(validationMessage + ex.Message);

                return objRequiringSubmission;
            }
            return objRequiringSubmission;
        }

        public UserDashboardResponse GetUserDashboardData(string userAlias)
        {
            int requestId = 0;
            string sourceApp = "DashboardService.GetUserDashboardData";
            //Logging Request
            _logger.LogInformation(System.Web.HttpUtility.HtmlEncode(sourceApp) + " initiated");

            //Initialization
            UserDashboardResponse dashboardDetails = null;
            try
            {
                IDictionary<string, string> validationMessages = null;

                //Validate the input request
                //validationMessages = _dashboardRepository.ValidateUserForDashboardDetails(userAlias);
                validationMessages = new Dictionary<string, string>();
                //If no validation error exists
                if (validationMessages.Count <= 0)
                {
                    //Call the search service to get archive details by archive number
                    dashboardDetails = _dashboardRepository.GetUserDashboardData(userAlias, requestId);

                    //If search does not return any result
                    if (dashboardDetails.ComplianceMetricsForUser != null && dashboardDetails.ComplianceMetricsForUser.Count <= 0)
                    {
                        //Create result not found response

                        var validationMessage = "No Metrics found";

                        _logger.LogInformation(validationMessage + "for" + System.Web.HttpUtility.HtmlEncode(userAlias));
                        return new UserDashboardResponse() { };
                    }
                    else if (dashboardDetails.ComplianceMetricsForUser.Any(e => e.Category == "Error"))
                    {

                        _logger.LogInformation("error in fetching information - DashBoardData -" + System.Web.HttpUtility.HtmlEncode(userAlias));

                        return new UserDashboardResponse();
                    }

                }
                else
                {
                    //Create response with all validation error messages

                    _logger.LogInformation("ValidationMessages: " + System.Web.HttpUtility.HtmlEncode(userAlias));

                    return new UserDashboardResponse();

                }
                //Return search results if any

                return dashboardDetails;
            }

            catch (Exception ex)
            {
                string validationMessage = "Internal Server Error.Please check the logs.";

                _logger.LogInformation(validationMessage + ex.Message);
                _logger.LogInformation(validationMessage + ex.StackTrace.ToString());

                return dashboardDetails;
            }
        }

        
        
    }
}
