import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SubstantiationPopupComponent } from './substantiation-popup.component';

describe('SubstantiationPopupComponent', () => {
  let component: SubstantiationPopupComponent;
  let fixture: ComponentFixture<SubstantiationPopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SubstantiationPopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SubstantiationPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
