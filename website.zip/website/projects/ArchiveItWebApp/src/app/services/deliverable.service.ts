import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class DeliverableService {
  data = [];
  apiData: any;
  APIData : any;
  constructor(private _http: HttpClient) { }
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'

    }),
  }



  public GetDeliverableTypes(): Observable<any> {
    // // debugger;
    this.apiData = this._http.get<any>("deliverable/GetDeliverableTypes", this.httpOptions);
    return this.apiData;
  }

  public GetDeliverablesByArchiveNumber(archiveNumber: string, pageNumber : number = 0, pageSize : number = 0): Observable<any> {
      this.apiData = this._http.get<any>("deliverable/GetDeliverablesByArchiveNumber?ArchiveNumber=" + archiveNumber+'&PageNumber='+pageNumber
    +'&PageSize='+ pageSize
    , this.httpOptions);
    return this.apiData;
  }

  public GetDeliverablesCountByArchiveNumber(archiveNumber: string): Observable<any> {
    this.apiData = this._http.get<any>("deliverable/GetDeliverablesCountByArchiveNumber?ArchiveNumber=" + archiveNumber, this.httpOptions);
    return this.apiData;
  }

  public CreateOrUpdateDeliverable(parameters: any): Observable<any> {
    this.apiData = this._http.post<any>("deliverable/CreateOrUpdateDeliverable",parameters , this.httpOptions);
    console.log("created archive is", this.apiData);
    return this.apiData;
  }

  public RefreshROI(parameters: any): Observable<any> {
    this.apiData = this._http.post<any>("deliverable/RefreshRoi",parameters , this.httpOptions);
    console.log("RefreshRoi data==", this.apiData);
    return this.apiData;
  }

  public GetDeliverableByDeliverableID(deliverableId:any, archiveNumber: string){
    this.apiData = this._http.get<any>("deliverable/GetDeliverableDetailsByID?DeliverableID="+deliverableId+"&ArchiveNumber="+archiveNumber, this.httpOptions);
    console.log("created archive is", this.apiData);
    return this.apiData;
  }
  public ApproveRejectDeliverable(parameters: any): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'text/plain; charset=utf-8');
    //return this._http.post<any>("archiveflow/createOrUpdateArchiveActions", parameters, this.httpOptions);
    return this._http.post(
      'archiveflow/createOrUpdateArchiveActions',
      parameters,
      { headers, responseType: 'text'}
    )
  }

  public GetDeliverablesDetails(parameters1:string){
    this.apiData = this._http.get<any>("archiveflow/getarchivesectioncomments?ArchiveNumber="+parameters1+"&sectionId=3", this.httpOptions);
    return this.apiData;
  }
  public IsUserApprover(parameters:string,parameters1:string){
    this.apiData = this._http.get<any>("archive/getarchivesubmissionstatus?archivenumber="+parameters, this.httpOptions);
    return this.apiData;
  }


  public GetMatROIInfo(pageNumber : number = 0, pageSize : number = 0, sortBy : number = 1, reportingEntity : string = "", engagementName : string = "", clientName : string = "", matProfileNumber : string = "", roiNumber : string = "",deliverableType : string = ""): Observable<any> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    this.apiData = this._http.get<any[]>('deliverable/GetMatROIInfo?PageNumber='+pageNumber
    +'&PageSize='+ pageSize
    +'&SortBy='+ sortBy
    +'&SearchQuery='+reportingEntity
    , httpOptions);
    return this.apiData;
  }

  public GetMatROIAdvancedInfo(pageNumber : number = 0, pageSize : number = 0, sortBy : number = 1, deliverableTypeName : string = "", deliverableReleaseDateFrom : string = "", deliverableReleaseDateTo : string = "", deliverableDateFrom : string = "", deliverableDateTo : string = "",lastUpdatedDateFrom : string = "", lastUpdatedDateTo : string = ""): Observable<any> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    this.apiData = this._http.get<any[]>('deliverable/GetMatROIAdvancedInfo?PageNumber='+pageNumber
    +'&PageSize='+ pageSize
    +'&SortBy='+ sortBy
    +'&DeliverableTypeName='+deliverableTypeName
    +'&DeliverableReleaseDateFrom='+deliverableReleaseDateFrom
    +'&DeliverableReleaseDateTo='+deliverableReleaseDateTo
    +'&DeliverableDateFrom='+deliverableDateFrom
    +'&DeliverableDateTo='+deliverableDateTo
    +'&LastUpdatedDateFrom='+lastUpdatedDateFrom
    +'&LastUpdatedDateTo='+lastUpdatedDateTo+''
    , httpOptions);
    return this.apiData;
  }

  public AddEditSubstantiation(parameters:any):Observable<any>
  {
    // debugger;
    this.apiData = this._http.post<any>("record/AddEditSubstantiation", parameters, this.httpOptions);
    return this.apiData;
  }

  public GetSubstantiationByArchiveNumber(archiveNumber: string, commentCategoryId:number, showLoader:boolean = true): Observable<string> {
    this.apiData = this._http.get("record/GetSubstantiationByArchiveNumber?ArchiveNumber=" + archiveNumber+"&CommentCategoryId="+commentCategoryId +'&showLoader='+showLoader, {responseType: 'text' });
    return this.apiData;
  }

  public SaveEngagementCeasedDate(parameters:any): Observable<any>{
    debugger;
    this.apiData = this._http.post<any>("archive/UpdateEarlyTerminationDate",parameters , this.httpOptions);
    console.log("Save engagement ceased date is", this.apiData);
    return this.apiData;
  }


  public GetEngagementCeasedDateByArchiveNumber(parameters:any): Observable<any>{
    this.apiData = this._http.post<any>("archive/FetchEarlyTerminationDate",parameters , this.httpOptions);
    console.log("Engagement Ceased Date is", this.apiData);
    return this.apiData;
  }





}
