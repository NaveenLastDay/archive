import { Component, OnInit } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { SharedService } from '../../../../services/shared.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { HoldsService } from 'projects/ArchiveItWebApp/src/app/services/holds-admin.service';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';

@Component({
  selector: 'app-holds-applyholds-confirmation',
  templateUrl: './holds-applyholds-confirmation.component.html',
  styleUrls: ['./holds-applyholds-confirmation.component.css']
})
export class HoldsApplyholdsConfirmationComponent implements OnInit {
  dataSource : any;
  HoldAppliedonArchives : any[];
  HoldAppliedonArchivesBatch : any[];
  holdName : string;
   /*sorting */
 columnByEnum: any = HoldsColumnBy;
 sortColumnDialog: number = -1;
 sortColumn : string ='';
 HoldNumbertobedeleted:string;
 sortascdesc: string='0';
 sortBy: number = 0;
 /*sorting*/
  /*Export to Excel */
  holdsResultGridColumns: any =HoldsResultGridColumns;
  readonly emptyStringInReport : string = " ";
  SortBy : string = '0';
  SortOrder : string = '0';
  PageNumber : number = 1;
  readonly PageSize : number = 10;
  appendtoGrid : boolean = false;
  totalArchives : number = 0;
  StartDate : string = '';
  EndDate : string = '';
  employeeUniqueIdentifier: string = "";
  totalList : number = 0;
  updatedList : number = 0;
  progressPercentage : number = 0;
  ConfigBatchValue : number = 500;
  sortedData : any[];

  columnFilters: any[] =
  [
    {
      "displayName": "ClientName#",
      "value": this.holdsResultGridColumns.ClientName,
      "checked": true
    },
    {
      "displayName": "ArchiveNumber#",
      "value": this.holdsResultGridColumns.ArchiveNumber,
      "checked": true
    },
    {
      "displayName": "Business#",
      "value": this.holdsResultGridColumns.Business,
      "checked": true
    },
    {
      "displayName": "PeriodEndDate#",
      "value": this.holdsResultGridColumns.PeriodEndDate,
      "checked": true
    },

    {
      "displayName": "EffectiveStartDate#",
      "value": this.holdsResultGridColumns.EffectiveStartDate,
      "checked": true
    },
    {
      "displayName": "EffectiveEndDate#",
      "value": this.holdsResultGridColumns.EffectiveEndDate,
      "checked": true
    },

    {
      "displayName": "Status#",
      "value": this.holdsResultGridColumns.Status,
      "checked": true
    },

  ]
  /* end of Export to Excel */

  constructor(private router: Router,private sharedService: SharedService,
    private SpinnerService: NgxSpinnerService,private _HoldsService : HoldsService,private adalSvc: MsAdalAngular6Service) { }

  ngOnInit() {
    this.employeeUniqueIdentifier = this.adalSvc.LoggedInUserEmail.split('@')[0];
    this.GetHoldDetailsData();
  }

  GetHoldDetailsData() {
    debugger;
    //var retriveAppliedHoldObject = localStorage.getItem('archiveHoldsInfo');
    var retriveHoldObject = localStorage.getItem('holdObject');
    console.log('',JSON.parse(retriveHoldObject))
    var parshedHoldObject =JSON.parse(retriveHoldObject)
    //console.log('',JSON.parse(parshedHoldObject))
       this.holdName=parshedHoldObject.holdName;
       this.StartDate=parshedHoldObject.effectiveStartDate;
       this.EndDate = parshedHoldObject.effectiveEndDate;
    
       var retriveAppliedHoldObject =JSON.parse(localStorage.getItem('archiveHoldsInfo')); 
       console.log('',retriveAppliedHoldObject);

       var first = 0;

       var selectedArchivesList = retriveAppliedHoldObject.ArchiveNumber.slice(first,this.ConfigBatchValue);

       this.totalList = retriveAppliedHoldObject.ArchiveNumber.length;

       let archiveCollection: string="";
       selectedArchivesList.forEach(function (value) {
      if(archiveCollection!='')
      archiveCollection= archiveCollection.concat(","+value.archiveNumber.toString());
      else
      archiveCollection=value.archiveNumber
    });

   
    let archiveHoldsInfo = {
      HoldNumber:this.holdName,
      ArchiveNumber:archiveCollection,
      CreatedBy: this.employeeUniqueIdentifier,
      SortBy : this.SortBy,
      SortOrder : this.SortOrder,
      PageNumber : this.PageNumber,
      PageSize : this.ConfigBatchValue
    };
    this._HoldsService.ApplyArchiveHolds(archiveHoldsInfo).subscribe(response => {
      if (this.appendtoGrid && response) {
        for(var i =0;i<response.length;i++){
          if(this.ConfigBatchValue < this.HoldAppliedonArchives.length)
          {
          this.HoldAppliedonArchives.push(response[i]);
          }
          else{
            this.HoldAppliedonArchivesBatch.push(response[i]);
          }
        }
      }
      else{

        var sliceNumber = this.PageSize < response.length ? (this.PageSize + 1 ) : this.PageSize;

        this.HoldAppliedonArchives = response ? response.slice(0,sliceNumber) : [];
        this.HoldAppliedonArchivesBatch = response.map(obj => ({...obj}));
        
      }
      if(response.length>0){
        this.totalArchives = this.totalList;
        this.updatedList = response.length;

        this.progressPercentage = Math.round((this.updatedList/this.totalList)*100);
      }
      var value = this.ConfigBatchValue > this.PageSize ? this.PageSize : this.ConfigBatchValue
      if(this.totalList > this.updatedList ){
        this.ApplyHoldsOnBatch(this.ConfigBatchValue,this.ConfigBatchValue+this.ConfigBatchValue);
      }
     // this.SpinnerService.hide();
    });

    
  }

  ApplyHoldsOnBatch(first : number, second : number){

    var retriveAppliedHoldObject =JSON.parse(localStorage.getItem('archiveHoldsInfo')); 

    var selectedArchivesList = retriveAppliedHoldObject.ArchiveNumber.slice(first,second);

    let archiveCollection: string="";
    selectedArchivesList.forEach(function (value) {
   if(archiveCollection!='')
   archiveCollection= archiveCollection.concat(","+value.archiveNumber.toString());
   else
   archiveCollection=value.archiveNumber
 });


 let archiveHoldsInfo = {
   HoldNumber:this.holdName,
   ArchiveNumber:archiveCollection,
   CreatedBy: this.employeeUniqueIdentifier,
   SortBy : this.SortBy,
   SortOrder : this.SortOrder,
   PageNumber : this.PageNumber,
   PageSize : this.ConfigBatchValue
 };

 this._HoldsService.ApplyArchiveHolds(archiveHoldsInfo).subscribe(response => {
  if(response.length>0){
    for(var i =0;i<response.length;i++){

        this.HoldAppliedonArchivesBatch.push(response[i]);
    }
    this.totalArchives = this.totalList;
  
    this.updatedList = this.updatedList + response.length;
    this.progressPercentage = Math.round((this.updatedList/this.totalList)*100);
  if(this.totalList > this.updatedList && response.length !==0 ){
    this.ApplyHoldsOnBatch(second,second+this.ConfigBatchValue);
  }
}
  //this.SpinnerService.hide();
});

  }
  navigatetoHoldScreen(){
    this.router.navigate(["admin/adminsidenavbar/holds"]);
  }
  updateGridData(event) {
    debugger;
    this.SpinnerService.show();
    this.appendtoGrid = event.isLoadMoreClicked;
    this.PageNumber = event.pageNumber;
    this.Pagination();
  }

  Pagination(){
    if(this.appendtoGrid){
      var item = this.HoldAppliedonArchivesBatch.slice((this.PageNumber-1)*this.PageSize,(((this.PageNumber -1) *this.PageSize) +this.PageSize));
      for(var i =0;i<item.length;i++){
      this.HoldAppliedonArchives.push(item[i]);
      }
    }
    else{
      this.HoldAppliedonArchives = [];
      this.HoldAppliedonArchives =this.HoldAppliedonArchivesBatch.slice((this.PageNumber-1)*this.PageSize,(((this.PageNumber -1) *this.PageSize) +this.PageSize)).map(obj => ({...obj}));
    }
    this.SpinnerService.hide();
  }
  ngOnDestroy(){
    // localStorage.removeItem('appliedHoldObject');
    // localStorage.removeItem('holdObject');
  }
  generateReportClicked(data1){
   // this.SpinnerService.show();
    let archiveForReport: any[] = [];
    let filterdColumns = (data1.filter(x => x.checked));

        if (this.HoldAppliedonArchivesBatch.length > 0) {
          this.HoldAppliedonArchivesBatch.forEach(element => {
            let archive = {};
            filterdColumns.forEach(column => {
  
              if (column["value"] == this.holdsResultGridColumns.ClientName) { //Archive#
                archive[this.holdsResultGridColumns[this.holdsResultGridColumns.ClientName]] = element.clientName || this.emptyStringInReport;
              }
              if (column["value"] == this.holdsResultGridColumns.ArchiveNumber) { //Archive#
                archive[this.holdsResultGridColumns[this.holdsResultGridColumns.ArchiveNumber]] = element.archiveNumber || this.emptyStringInReport;
              }
              if (column["value"] == this.holdsResultGridColumns.Business) { //Archive#
                archive[this.holdsResultGridColumns[this.holdsResultGridColumns.Business]] = element.business || this.emptyStringInReport;
              }
              if (column["value"] == this.holdsResultGridColumns.PeriodEndDate) { //Archive#
                archive[this.holdsResultGridColumns[this.holdsResultGridColumns.PeriodEndDate]] = element.periodEndDate || this.emptyStringInReport;
              }
              if (column["value"] == this.holdsResultGridColumns.EffectiveStartDate) { //Archive#
                archive[this.holdsResultGridColumns[this.holdsResultGridColumns.EffectiveStartDate]] = element.effectiveStartDate || this.emptyStringInReport;
              }
              if (column["value"] == this.holdsResultGridColumns.EffectiveEndDate) { //Archive#
                archive[this.holdsResultGridColumns[this.holdsResultGridColumns.EffectiveEndDate]] = element.effectiveEndDate || this.emptyStringInReport;
              }
              if (column["value"] == this.holdsResultGridColumns.Status) { //Archive#
                archive[this.holdsResultGridColumns[this.holdsResultGridColumns.Status]] = element.status || this.emptyStringInReport;
              }
                          
            });
            archiveForReport.push(archive);
          });
          if (archiveForReport && archiveForReport.length) {
            this.sharedService.generateExcel("HoldAppliedfor"+this.holdName, "Holds", filterdColumns.map(x => x.displayName), archiveForReport);
          }
        }    
  }

  sortOrderChanged(event) {
    debugger;
    this.sortBy = event;
  
    console.log("sortOrderChanged ",this.sortColumnDialog +"Before"+this.sortBy)
    if(this.sortBy==1 || this.sortBy==3 || this.sortBy== 5 )
    {
      this.sortascdesc='asc';
    }
    else if(this.sortBy==2 || this.sortBy==4 || this.sortBy==6)
    {
      this.sortascdesc='desc';
    }
    if(this.sortColumnDialog==1)
    {
      this.sortColumn='ClientName';
    }
    else if(this.sortColumnDialog==2){
      this.sortColumn='ArchiveNumber';
    }
    else if(this.sortColumnDialog==3)
    {
      this.sortColumn='PeriodEndDate';
    }
    else if(this.sortColumnDialog==4){
      this.sortColumn='EffectiveStartDate';
    }
    else if(this.sortColumnDialog==5)
    {
      this.sortColumn='EffectiveEndDate';
    }
    else if(this.sortColumnDialog==6){
      this.sortColumn='Status';
    }
    else{
      this.sortColumn='';
    }
    console.log("sortColumn",this.sortColumn);
    console.log("sortascdesc",this.sortascdesc);
   /* this.currentPageNumber=1;*/
    this.getHoldsDataforSort(this.sortColumn);
    console.log("sortOrderChanged ",this.sortColumnDialog +"After"+this.sortBy)
  }
  getHoldsDataforSort(sort : string){

    this.sortedData = this.HoldAppliedonArchivesBatch.slice();
    this.HoldAppliedonArchives = [];
    this.HoldAppliedonArchivesBatch = this.sortedData.sort((a, b) => {
      const isAsc = this.sortascdesc === 'asc';
      switch (sort) {
        case 'ClientName': return this.compare(a.clientName, b.clientName, isAsc);
        case 'ArchiveNumber': return this.compare(a.archiveNumber, b.archiveNumber, isAsc);
        case 'PeriodEndDate': return this.compare(a.periodEndDate, b.periodEndDate, isAsc);
        case 'EffectiveStartDate': return this.compare(this.StartDate, this.StartDate, isAsc);
        case 'EffectiveEndDate': return this.compare(this.EndDate, this.EndDate, isAsc);
        case 'Status': return this.compare(a.status, b.status, isAsc);
        default: return 0;
      }
    });
    var sliceNumber = this.PageSize < this.totalArchives ? (this.PageSize + 1 ) : this.PageSize;

    this.HoldAppliedonArchives = this.HoldAppliedonArchivesBatch ? this.HoldAppliedonArchivesBatch.slice(0,sliceNumber) : [];
    this.Pagination();
  
  }

   compare(a: number | string, b: number | string, isAsc: boolean) {
    return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
  }
  
  memberSortDialog(event) {
    debugger;
    if (this.sortColumnDialog == event) this.sortColumnDialog = -1;
    else
    this.sortColumnDialog = event;
    console.log("memberSortDialog",this.sortColumnDialog);
    //this.getHoldsDataforSort(this.sortColumn);
  }
  memberSortDialogASCDESC(event){
    debugger;
   var clickedColumn:number=event;
    /*For HoldName*/
    if(clickedColumn==2 && this.sortBy!=5){
    this.sortBy=5;
     this.sortColumn="ArchiveNumber";
     this.sortascdesc='asc';
   }
   else if(clickedColumn==2 && this.sortBy==5){
    this.sortBy=0;
    this.sortColumn="ArchiveNumber";
    this.sortascdesc='desc';
   }
   /*For HoldName*/
   /*for EffectiveStartDate */
   else if(clickedColumn==3 && this.sortBy!=6){
    this.sortBy=6;
     this.sortColumn="PeriodEndDate";
     this.sortascdesc='asc';
   }
   else if(clickedColumn==3 && this.sortBy==6){
    this.sortBy=0;
    this.sortColumn="PeriodEndDate";
    this.sortascdesc='desc';
   }

   else if(clickedColumn==4 && this.sortBy!=7){
    this.sortBy=7;
     this.sortColumn="EffectiveStartDate";
     this.sortascdesc='asc';
   }
   else if(clickedColumn==4 && this.sortBy==7){
    this.sortBy=0;
    this.sortColumn="EffectiveStartDate";
    this.sortascdesc='desc';
   }
   /*FoR Effective Start Date */
   /*for EffectiveStartDate */
   else if(clickedColumn==5 && this.sortBy!=8){
    this.sortBy=8;
     this.sortColumn="EffectiveEndDate";
     this.sortascdesc='asc';
   }
   else if(clickedColumn==5 && this.sortBy==8){
    this.sortBy=0;
    this.sortColumn="EffectiveEndDate";
    this.sortascdesc='desc';
   }
   /*FoR Effective Start Date */
  
   /*this.currentPageNumber=1;*/
   this.SpinnerService.show();
   this.getHoldsDataforSort(this.sortColumn);
   this.SpinnerService.hide();
  
  }

}
export enum HoldsResultGridColumns
{
ClientName = 1, 
ArchiveNumber = 2, 
Business = 3, 
PeriodEndDate = 4, 
EffectiveStartDate= 5, 
EffectiveEndDate = 6, 
Status = 7, 
}
export enum HoldsColumnBy {
  ColumnBy_Default = -1,
  ColumnBy_ClientName = 1,
  ColumnBy_ArchiveNumber = 2,
  ColumnBy_PeriodEndDate = 3,
  ColumnBy_EffectiveStartDate = 4,
  ColumnBy_EffectiveEndDate = 5,
  ColumnBy_Status = 6,
}