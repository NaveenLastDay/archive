import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-destruction',
  templateUrl: './destruction.component.html',
  styleUrls: ['./destruction.component.css']
})
export class DestructionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
