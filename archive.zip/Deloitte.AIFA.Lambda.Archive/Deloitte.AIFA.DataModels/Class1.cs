﻿using System;

namespace Deloitte.AIFA.DataModels
{
    public class Class1
    {
    }
}
