import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EDCDWidgetComponent } from './edcdwidget.component';

describe('EDCDWidgetComponent', () => {
  let component: EDCDWidgetComponent;
  let fixture: ComponentFixture<EDCDWidgetComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EDCDWidgetComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EDCDWidgetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
