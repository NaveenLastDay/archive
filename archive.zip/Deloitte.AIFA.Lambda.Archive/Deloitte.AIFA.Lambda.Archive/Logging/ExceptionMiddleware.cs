﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Net;
using System.Threading.Tasks;

namespace Deloitte.AIFA.Lambda.Logging
{
    public class ExceptionMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogger _logger;

        public ExceptionMiddleware(RequestDelegate next, ILogger logger)
        {
            _next = next;
            _logger = logger;
        }

        public async Task InvokeAsync(HttpContext httpContext)
        {
            try
            {
                await _next(httpContext);
            }
            catch (Exception ex)
            {
                _logger.LogError($"something went wrong: {ex}");
                await HandleExceptionAsync(httpContext, ex);
            }
        }

        private Task HandleExceptionAsync(HttpContext httpContext, Exception ex)
        {
            string CorrelationId = string.Empty;

            httpContext.Response.ContentType = "application/json";
            httpContext.Response.StatusCode = (int)HttpStatusCode.InternalServerError;

            if (httpContext.Request.Headers != null)
            {
                CorrelationId = httpContext.Request.Headers["X-Amzn-Trace-Id"];
            }

            ErrorModel logModel = new ErrorModel();
            logModel.StatusCode = httpContext.Response.StatusCode;
            logModel.CorrelationId = CorrelationId;
            logModel.Message = ex.Message;
            logModel.StackTrace = ex.StackTrace;

            var jsonLogModel = JsonConvert.SerializeObject(logModel);

            return httpContext.Response.WriteAsync(jsonLogModel);
        }
    }
}
