﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DataModels
{
    public class RoleMappingModel
    {
        public int RoleId { get; set; }

        public string RoleDescription { get; set; }

        public IList<string> ArchivePermissions { get; set; }

        
    }

    public class RoleFunction
    {
        public int Id { get; set; }
        public string FunctionName { get; set; }
    }

    public class RoleFunctionModel
    {
        public int Id { get; set; }
        public string FunctionName { get; set; }
    }
}
