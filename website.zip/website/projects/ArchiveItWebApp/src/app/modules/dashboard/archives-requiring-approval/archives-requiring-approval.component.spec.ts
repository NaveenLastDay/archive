import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ArchivesRequiringApprovalComponent } from './archives-requiring-approval.component';

describe('ArchivesRequiringApprovalComponent', () => {
  let component: ArchivesRequiringApprovalComponent;
  let fixture: ComponentFixture<ArchivesRequiringApprovalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ArchivesRequiringApprovalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ArchivesRequiringApprovalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
