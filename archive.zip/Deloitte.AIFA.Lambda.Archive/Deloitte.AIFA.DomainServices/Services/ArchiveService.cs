﻿using Deloitte.AIFA.DataModels;
using Deloitte.AIFA.DomainEntities;
using Deloitte.AIFA.DomainEntities.EmailEntities;
using Deloitte.AIFA.DomainEntities.Enums;
using Deloitte.AIFA.DomainEntities.Report;
using Deloitte.AIFA.DomainServices.Common;
using Deloitte.AIFA.DomainServices.Contracts;
using Deloitte.AIFA.EmailNotificationServices;
using Deloitte.AIFA.EmailNotificationServices.NotificationServices.Services;
using Deloitte.AIFA.Helpers;
using Deloitte.AIFA.Helpers.ExcelGenerator;
using Deloitte.AIFA.ICloudServices;
using Deloitte.AIFA.IRepositories;
using Deloitte.AIFA.Models;
using Deloitte.AIFA.PushMessageSNSHelper;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Deloitte.AIFA.DomainServices
{
    public class ArchiveService : BaseService, IArchiveService
    {
        IArchiveRepository _archiveRepository;
        ILogger _logger;
        IMemoryCache _cache;
        IConfiguration _configManager;
        IEmailNotificationService _emailNotificationService;
        public ArchiveService(IMemoryCache cache, IConfigManager configManager,
                              IArchiveRepository archiveRepository,
                                ILogger<ArchiveService> logger, IEmailNotificationService emailNotificationService,IConfiguration config) : base(cache, configManager)
        {
            _cache = cache;
            _logger = logger;
            this._configManager = config;
            _archiveRepository = archiveRepository;
            _emailNotificationService = emailNotificationService;

        }
        public Archive GetArchiveDetail(int archiveId)
        {
            _logger.LogInformation("This is from ArchiveService: GetArchiveDetail");
            var archives = _archiveRepository.GetArchiveDetail(archiveId);
            return archives;
        }

        public List<EngagementType> GetEngagementType()
        {
            var engagementTypes = _archiveRepository.GetEngagementType();
            return engagementTypes;
        }

        public List<ArchiveType> GetArchiveType()
        {
            var archiveType = _archiveRepository.GetArchiveType();
            return archiveType;
        }

        public List<EntityType> GetEntityType()
        {
            var entityType = _archiveRepository.GetEntityType();
            return entityType;
        }


        public List<ProfessionalStandards> GetProfessionalStandard()
        {
            var professionalstandard = _archiveRepository.GetProfessionalStandard();
            return professionalstandard;
        }

        public List<RetentionReason> GetRetentionReasons()
        {

            var RetentionReasons = _archiveRepository.GetRetentionReasons();
            return RetentionReasons;
        }

        public string CreateArchiveRetention(ArchiveRetention archiveRetention)
        {

            var result = _archiveRepository.CreateArchiveRetention(archiveRetention);
            return result;
        }

        public string CreateArchiveLegalHold(ArchiveLegalHold archiveLegalHold)
        {
            var result = _archiveRepository.CreateArchiveLegalHold(archiveLegalHold);
            return result;
        }

        public List<ActiveRoles> GetActiveRoles(string ArchiveNumber)
        {

            var activeroles = _archiveRepository.GetActiveRoles(ArchiveNumber);
            return activeroles;

        }
        public List<ActiveRoles> GetActiveRolesForRequestTemporaryAccess(string ArchiveNumber)
        {

            var activeroles = _archiveRepository.GetActiveRolesForRequestTemporaryAccess(ArchiveNumber);
            return activeroles;

        }

        public List<ArchiveTeamHistory> GetArchiveTeamHistory(string ArchiveNumber, int PageNumber, int PageSize, int SortBy)
        {

            var archiveteam = _archiveRepository.GetArchiveTeamHistory(ArchiveNumber, PageNumber, PageSize, SortBy);
            return archiveteam;

        }

        public List<ArchiveSearchBase> GetWBSSerchResults(string term, int rowcount)
        {

            var wbsSearchResults = _archiveRepository.GetWBSSerchResults(term, rowcount);
            return wbsSearchResults;
        }
        public WBSDetails GetWBSDetails(string wbsLevelOne)
        {

            var wbsResults = _archiveRepository.GetWBSDetails(wbsLevelOne);
            return wbsResults;
        }

        public Archive CreateArchive(Archive archive)
        {
            var archiveDetails = _archiveRepository.CreateArchive(archive);

            #region Email

            // For Archive Submission - For Approval [Immediate]
            if (archiveDetails.ArchiveNumber != "")
            {
                Console.WriteLine("Pushing Message to Email SNS Starts for Archive Creation for Archive Number " + archiveDetails.ArchiveNumber);
                CreateArchiveNotification rtn = new CreateArchiveNotification();
                BaseEmailEntity be = new BaseEmailEntity();
                be = rtn.CreateArchiveManual_Notification("CreateArchive", "CreateArchive", "1", archiveDetails.ArchiveNumber, archive.WBSLevelOneNumber, archive.ArchiveInfo.Createdby);

                be.TemplateId = "1";
                be.AdditionalInfo = archive.WBSInfo.WBSEngagementPPMD + ";" + archive.WBSInfo.EngagementManager + ";" + archive.ArchiveInfo.ArchiveFieldSenior + ";" + archive.ArchiveInfo.AdditionalArchiveFieldSenior;

                _emailNotificationService.PublishEmailNotification(be);

            }
            #endregion
            return archiveDetails;
        }

        //public List<MyArchive> GetMyArchives(int personnelNumber, int pageNumber, int pageSize, string sortDirection, string orderBy, string search)
        public List<MyArchive> GetMyArchives(string employeeUniqueIdentifier, int pageNumber, int pageSize, int sortBy, int filterBy, string filterText)
        {
            _logger.LogInformation(string.Format("Processing {0} service method.", System.Reflection.MethodBase.GetCurrentMethod()));
            //var myArchives = _archiveRepository.GetMyArchives(personnelNumber, pageNumber, pageSize, sortDirection, orderBy, search);
            List<MyArchive> myArchives = null;
            myArchives = _archiveRepository.GetMyArchives(employeeUniqueIdentifier, pageNumber, pageSize, sortBy, filterBy, filterText);
            return myArchives;
        }


        public MyArchiveDetails GetMyArchiveDetails(string archiveNumber)
        {
            _logger.LogInformation(string.Format("Processing {0} service method.", System.Reflection.MethodBase.GetCurrentMethod()));
            //var myArchives = _archiveRepository.GetMyArchives(personnelNumber, pageNumber, pageSize, sortDirection, orderBy, search);
            MyArchiveDetails myArchiveDetails = null;
            myArchiveDetails = _archiveRepository.GetMyArchiveDetails(archiveNumber);
            return myArchiveDetails;
        }
        public List<ExistingArchivesInfo> GetExistingArchivesDetails(string wbsLevelOne, string userAlias, int PageNumber, int PageSize)
        {

            var existingArchivesDetails = _archiveRepository.GetExistingArchivesDetails(wbsLevelOne, userAlias, PageNumber, PageSize);
            return existingArchivesDetails;
        }

        public List<ResubmissionApprover> GetResubmissionApproverDetails(string ArchiveNumber, string userAlias)
        {
            var existingArchivesDetails = _archiveRepository.GetResubmissionApproverDetails(ArchiveNumber, userAlias);
            return existingArchivesDetails;
        }

        public ProjectMetaData GetSwiftEngagementInfo(string wbsLevelOne)
        {
            _logger.LogInformation("Swift Engagement Info for: " + System.Web.HttpUtility.HtmlEncode(wbsLevelOne));
            var engagementInfo = _archiveRepository.GetSwiftEngagementInfo(wbsLevelOne);
            return engagementInfo;


        }

        public ArchiveDetails GetArchiveDetailsInfo(string archiveNumber, string employeeUniqueIdentifier)
        {
            _logger.LogInformation(string.Format("Processing {0} service method.", "GetArchiveDetailsInfo"));
            //var myArchives = _archiveRepository.GetMyArchives(personnelNumber, pageNumber, pageSize, sortDirection, orderBy, search);
            ArchiveDetails archiveDetails = _archiveRepository.GetArchiveDetailsInfo(archiveNumber, employeeUniqueIdentifier);
            return archiveDetails;
        }

        public int GetMatRoiUpdates(string archiveNumber)
        {
            _logger.LogInformation(string.Format("Processing {0} service method.", "GetMatRoiUpdates"));
            var roiUpdateResult = _archiveRepository.GetMatRoiUpdates(archiveNumber);
            return roiUpdateResult;
        }

        public string UpdateArchiveTeam(ArchiveTeam archiveTeam, string UserAlias)
        {
            _logger.LogInformation("Manage Archive Team for " + System.Web.HttpUtility.HtmlEncode(archiveTeam.ArchiveNumber));
            var result = _archiveRepository.UpdateArchiveTeam(archiveTeam, UserAlias);

            #region Email

            ArchiveSubmissionNotification rtn = new ArchiveSubmissionNotification();
            BaseEmailEntity be = new BaseEmailEntity();


            ArchiveResubmissionNotification rtns = new ArchiveResubmissionNotification();
            BaseEmailEntity bes = new BaseEmailEntity();

            //  Archive Submission - For awaiting Approval [Immediate] & Change of approvers from Manage Team [AM/AP]
            if (result.ArchiveStatus == 6 )
            {
                Console.WriteLine("Pushing Message to Email SNS Starts for Archive submission awaiting Approval for Archive Number " + archiveTeam.ArchiveNumber);

                be = rtn.Submission_ForApproval_Notification("UpdateArchiveTeam", "UpdateArchiveTeam", "15", archiveTeam.ArchiveNumber, UserAlias);

                be.TemplateId = "15";

                _emailNotificationService.PublishEmailNotification(be);

            }
            else if(result.ArchiveStatus == 9) // Re-Submission
            {
                Console.WriteLine("Pushing Message to Email SNS Starts for Archive submission awaiting Approval for Archive Number " + archiveTeam.ArchiveNumber);

                bes = rtns.Resubmission_ForApproval_Notification("UpdateArchiveTeam", "UpdateArchiveTeam", "21", archiveTeam.ArchiveNumber, UserAlias);

                bes.TemplateId = "21";

                _emailNotificationService.PublishEmailNotification(bes);
            }
            //For Archive Core - Team Change[AP/AM/AFS/AAFS] - Grant or Deny

            Console.WriteLine("Pushing Message to Email SNS Starts for Grant Deny Archive Team Change Access  for Archive Number " + archiveTeam.ArchiveNumber);

            GrantDenyForTeamChangeNotification rtn1 = new GrantDenyForTeamChangeNotification();
            BaseEmailEntity be1 = new BaseEmailEntity();

            if (result.NewPartnerAlias != "")
            {
                be1.TemplateId = "9";
                be1 = rtn1.TeamChange_Grant_Notification("UpdateArchiveTeam", "UpdateArchiveTeam", "9", archiveTeam.ArchiveNumber, UserAlias, result.RolePartner, result.NewPartnerName, result.TeamChangedBy, result.NewPartnerAlias);
                _emailNotificationService.PublishEmailNotification(be1);

                if(result.FormID != null && result.FormID != 0 )
                {
                    Form3283SNotification fns = new Form3283SNotification();
                    BaseEmailEntity bee = new BaseEmailEntity();
                    var ActionItemID = "FormId-" + result.FormID.ToString();
                    bee = fns.Form3283S_AP_Awaiting_Approval_Notification("Form3283SAPAwaitingApproval", "Form3283SAPAwaitingApproval", "63", archiveTeam.ArchiveNumber, "", (ActionItemID + "-AP"));

                    _emailNotificationService.PublishEmailNotification(bee);
                }

            }
            if (result.NewManagerAlias != "")
            {
                be1.TemplateId = "9";
                be1 = rtn1.TeamChange_Grant_Notification("UpdateArchiveTeam", "UpdateArchiveTeam", "9", archiveTeam.ArchiveNumber, UserAlias, result.RoleManager, result.NewManagerName, result.TeamChangedBy, result.NewManagerAlias);
                _emailNotificationService.PublishEmailNotification(be1);
            }
            if (result.NewFieldSeniorAlias != "")
            {
                be1.TemplateId = "9";
                be1 = rtn1.TeamChange_Grant_Notification("UpdateArchiveTeam", "UpdateArchiveTeam", "9", archiveTeam.ArchiveNumber, UserAlias, result.RoleFieldSenior, result.NewFieldSeniorName, result.TeamChangedBy, result.NewFieldSeniorAlias);
                _emailNotificationService.PublishEmailNotification(be1);
            }
            if (result.NewAddFieldSeniorAlias != "")
            {
                be1.TemplateId = "9";
                be1 = rtn1.TeamChange_Grant_Notification("UpdateArchiveTeam", "UpdateArchiveTeam", "9", archiveTeam.ArchiveNumber, UserAlias, result.RoleAddFieldSenior, result.NewAddFieldSeniorName, result.TeamChangedBy, result.NewAddFieldSeniorAlias);
                _emailNotificationService.PublishEmailNotification(be1);
            }
            if (result.OldPartnerAlias != "")
            {
                be1.TemplateId = "51";
                be1 = rtn1.TeamChange_Deny_Notification("UpdateArchiveTeam", "UpdateArchiveTeam", "51", archiveTeam.ArchiveNumber, UserAlias, result.RolePartner, result.OldPartnerName, result.TeamChangedBy, result.OldPartnerAlias);
                _emailNotificationService.PublishEmailNotification(be1);
            }
            if (result.OldManagerAlias != "")
            {
                be1.TemplateId = "51";
                be1 = rtn1.TeamChange_Deny_Notification("UpdateArchiveTeam", "UpdateArchiveTeam", "51", archiveTeam.ArchiveNumber, UserAlias, result.RoleManager, result.OldManagerName, result.TeamChangedBy, result.OldManagerAlias);
                _emailNotificationService.PublishEmailNotification(be1);
            }
            if (result.OldFieldSeniorAlias != "")
            {
                be1.TemplateId = "51";
                be1 = rtn1.TeamChange_Deny_Notification("UpdateArchiveTeam", "UpdateArchiveTeam", "51", archiveTeam.ArchiveNumber, UserAlias, result.RoleFieldSenior, result.OldFieldSeniorName, result.TeamChangedBy, result.OldFieldSeniorAlias);
                _emailNotificationService.PublishEmailNotification(be1);
            }
            if (result.OldAddFieldSeniorAlias != "")
            {
                be1.TemplateId = "51";
                be1 = rtn1.TeamChange_Deny_Notification("UpdateArchiveTeam", "UpdateArchiveTeam", "51", archiveTeam.ArchiveNumber, UserAlias, result.RoleAddFieldSenior, result.OldAddFieldSeniorName, result.TeamChangedBy, result.OldAddFieldSeniorAlias);
                _emailNotificationService.PublishEmailNotification(be1);
            }

            #endregion
            return "Success";

        }

        public EditArchiveDetails GetEditArchiveDetails(string archiveNumber)
        {
            _logger.LogInformation("GetEngagementDetails: " + System.Web.HttpUtility.HtmlEncode(archiveNumber));
            var EngagementDetails = _archiveRepository.GetEditArchiveDetails(archiveNumber);
            return EngagementDetails;
        }

        public AutoCreateArchiveDetails GetAutoCreateArchiveDetails(string archiveNumber)
        {
            _logger.LogInformation("GetAutoCreateArchiveDetails: " + System.Web.HttpUtility.HtmlEncode(archiveNumber));
            var Autocreatearchivedetails = _archiveRepository.GetAutoCreateArchiveDetails(archiveNumber);
            return Autocreatearchivedetails;
        }

        public string UpdateArchiveDetails(UpdateArchive updateArchive)
        {
            _logger.LogInformation("Manage edit Archive for " + System.Web.HttpUtility.HtmlEncode(updateArchive.ArchiveNumber));
            var result = _archiveRepository.UpdateArchiveDetails(updateArchive);
            return result;
        }

        #region GetMyArchivesFilterDataByType        
        public List<MyArchivesFilterData> GetMyArchivesFilterDataByType(string employeeUniqueIdentifier, int filterBy)
        {
            //_logger.LogInformation(string.Format("Processing {0} service method.", System.Reflection.MethodBase.GetCurrentMethod()));
            _logger.LogInformation("Processing GetMyArchivesFilterDataByType service method.");
            List<MyArchivesFilterData> myArchivesFilterData = null;
            myArchivesFilterData = _archiveRepository.GetMyArchivesFilterDataByType(employeeUniqueIdentifier, filterBy);
            return myArchivesFilterData;
        }
        #endregion GetMyArchivesFilterDataByType

        public void LogMessageId(string messageId)
        {
            _logger.LogInformation("PushMessageId Service call for : " + System.Web.HttpUtility.HtmlEncode(messageId));
            _archiveRepository.LogMessageId(messageId);
        }

        public ArchiveSubmission CreateArchiveSubmission(ArchiveSubmission archiveSubmission, string userAlias = "")
        {

            var archiveSubmissionResult = _archiveRepository.CreateArchiveSubmission(archiveSubmission);

            #region Email

            //For Archive submission - Approved Action
            if (archiveSubmissionResult.ArchiveStatus == "Approved")
            {
                Console.WriteLine("Pushing Message to Email SNS Starts for Status Approved for Archive Number " + archiveSubmissionResult.ArchiveNumber);
                ArchiveSubmissionNotification rtn = new ArchiveSubmissionNotification();
                BaseEmailEntity be = new BaseEmailEntity();
                be = rtn.Submission_Approved_Notification("CreateArchiveSubmission", "CreateArchiveSubmission", "44", archiveSubmissionResult.ArchiveNumber, userAlias, archiveSubmissionResult.ArchiveApprovedDate, archiveSubmissionResult.OfficeTimeZone);

                be.TemplateId = "44";

                _emailNotificationService.PublishEmailNotification(be);

            }
            else if (archiveSubmissionResult.ArchiveStatus == "Rejected")
            {
                Console.WriteLine("Pushing Message to Email SNS Starts for Status Rejected for Archive Number " + archiveSubmissionResult.ArchiveNumber);
                ArchiveSubmissionNotification rtn = new ArchiveSubmissionNotification();
                BaseEmailEntity be = new BaseEmailEntity();
                be = rtn.Submission_Rejected_Notification("CreateArchiveSubmission", "CreateArchiveSubmission", "20", archiveSubmissionResult.ArchiveNumber, userAlias);

                be.TemplateId = "20";

                _emailNotificationService.PublishEmailNotification(be);

            }
            #endregion


            return archiveSubmissionResult;
        }

        public ArchiveRetentionDetails GetArchiveRetentionDetails(string archiveNumber)
        {
            _logger.LogInformation("GetEngagementDetails: " + System.Web.HttpUtility.HtmlEncode(archiveNumber));
            var retentionDetails = _archiveRepository.GetArchiveRetentionDetails(archiveNumber);
            return retentionDetails;
        }

        public string UpdateEstimatedReleaseDate(string ArchiveNumber, DateTime EstimatedReleaseDate)
        {
            _logger.LogInformation("UpdateEstimatedReleaseDate ArchiveNumber : " + System.Web.HttpUtility.HtmlEncode(ArchiveNumber));
            var result = _archiveRepository.UpdateEstimatedReleaseDate(ArchiveNumber, EstimatedReleaseDate);
            return result;
        }

        public string SubtantiveResubmissionUpdatePPDorNPPD(string ArchiveNumber, string CreatedBy, string PPDUserAlias, int IsPPD)
        {
            _logger.LogInformation("SubtantiveResubmissionUpdatePPDorNPPD : " + System.Web.HttpUtility.HtmlEncode(ArchiveNumber));
            var result = _archiveRepository.SubtantiveResubmissionUpdatePPDorNPPD(ArchiveNumber, CreatedBy, PPDUserAlias, IsPPD);

            #region Email

            
            // Archive Re-submission - Change of approvers [PPD/NPPD] only trigger when PPD is not null - For Approval 
            //if (ArchiveNumber != "" && !String.IsNullOrEmpty(PPDUserAlias))
            //{
            //    Console.WriteLine("Pushing Message to Email SNS Starts for Archive Re-submission - Change of approvers [PPD/NPPD] Approval for Archive Number " + ArchiveNumber);
            //    ArchiveResubmissionNotification rtn = new ArchiveResubmissionNotification();
            //    BaseEmailEntity be = new BaseEmailEntity();
            //    be = rtn.Resubmission_PPDOrNPPDChange_ForApproval_Notification("SubtantiveResubmissionUpdatePPDorNPPD", "SubtantiveResubmissionUpdatePPDorNPPD", "15", ArchiveNumber, CreatedBy, PPDUserAlias, IsPPD);

            //    be.TemplateId = "56";

            //    _emailNotificationService.PublishEmailNotification(be);

            //}
            #endregion
            return result;
        }
        public List<ResubmissionApproverList> SubtantiveResubmissionGetPPDorNPPD(string ArchiveNumber)
        {
            _logger.LogInformation("SubtantiveResubmissionGetPPDorNPPD : " + System.Web.HttpUtility.HtmlEncode(ArchiveNumber));
            var result = _archiveRepository.SubtantiveResubmissionGetPPDorNPPD(ArchiveNumber);
            return result;
        }
        public ArchiveSubmissionStatus GetDateAndPeoplePickerStatus(string archiveNumber, string userAlias)
        {
            _logger.LogInformation("GetDateAndPeoplePickerStatus: " + System.Web.HttpUtility.HtmlEncode(archiveNumber + userAlias));
            var dateandPeoplerPickerStatus = _archiveRepository.GetDateAndPeoplePickerStatus(archiveNumber, userAlias);
            return dateandPeoplerPickerStatus;
        }

        public LinkedArchivesStatus GetLinkedArchiveStatus(string archiveNumber, string userAlias)
        {
            _logger.LogInformation("GetLinkedArchiveStatus: " + System.Web.HttpUtility.HtmlEncode(archiveNumber + userAlias));
            var linkedArchiveStatus = _archiveRepository.GetLinkedArchiveStatus(archiveNumber, userAlias);
            return linkedArchiveStatus;
        }

        public WorkingPapersStatus GetWorkingPapersStatus(string archiveNumber, string userAlias)
        {
            _logger.LogInformation("GetWorkingPapersStatus: " + System.Web.HttpUtility.HtmlEncode(archiveNumber + userAlias));

            WorkingPapersStatus workingpapersStatus = _archiveRepository.GetWorkingPapersStatus(archiveNumber, userAlias);
            return workingpapersStatus;
        }
        public DeliverablesStatus GetDeliverablesStatus(string archiveNumber, string userAlias)
        {
            _logger.LogInformation("GetDeliverablesStatus: " + System.Web.HttpUtility.HtmlEncode(archiveNumber + userAlias));
            DeliverablesStatus deliverableStatus = _archiveRepository.GetDeliverablesStatus(archiveNumber, userAlias);
            return deliverableStatus;
        }
        public RetentionExceptionStatus GetRetentionExceptionStatus(string archiveNumber, string userAlias)
        {
            _logger.LogInformation("GetRetentionExceptionStatus: " + System.Web.HttpUtility.HtmlEncode(archiveNumber + userAlias));
            RetentionExceptionStatus retentionexcepStatus = _archiveRepository.GetRetentionExceptionStatus(archiveNumber, userAlias);
            return retentionexcepStatus;
        }

        public List<ArchiveAction> GetArchiveActions(string archiveNumber)
        {
            return _archiveRepository.GetArchiveActions(archiveNumber).ToList();
        }

        public EngagementRelatedPersonalStatus GetEngagementRelatedPersonalStatus(string archiveNumber)
        {
            return _archiveRepository.GetEngagementRelatedPersonalStatus(archiveNumber);
        }

        public List<ArchiveAtcionsForIndividualSections> GetArchiveAtcionsForIndividualSections(string archiveNumber)
        {
            return _archiveRepository.GetArchiveAtcionsForIndividualSections(archiveNumber).ToList();
        }

        public ArchiveSubmissionStatus GetArchiveSubmissionStatus(string archiveNumber, string userAlias)
        {
            ArchiveSubmissionStatus archiveStatus = null;
            ArchiveDetails archiveInfo = null;
            List<ActiveRoles> archiveRoles = null;
            List<ArchiveAction> archiveActions = null;
            //WorkingPapersStatus workingPapersMessage = null;
            //DeliverablesStatus deliverablesMessage = null;
            //RetentionExceptionStatus retentionExceptionMessage = null;
            //LinkedArchivesStatus linkedArchivesStatus = null;
            //List<ArchiveAtcionsForIndividualSections> archiveAtcionsForIndividualSections = null;
            //EngagementRelatedPersonalStatus ERPS = null;
            //bool omniaArchiveSubmissionStatus = true;
            //int matRoiUpdates = 0;


            Parallel.Invoke(
                () => archiveStatus = GetDateAndPeoplePickerStatus(archiveNumber, userAlias),
                () => archiveInfo = GetArchiveDetailsInfo(archiveNumber, userAlias),
                () => archiveRoles = GetActiveRoles(archiveNumber),
                () => archiveActions = GetArchiveActions(archiveNumber));

               // () => retentionExceptionMessage = GetRetentionExceptionStatus(archiveNumber, userAlias), //Remove it
                //() => linkedArchivesStatus = GetLinkedArchiveStatus(archiveNumber, userAlias), // NRH New API
                //() => matRoiUpdates = GetMatRoiUpdates(archiveNumber), // NRH Existing API
                //() => archiveAtcionsForIndividualSections = GetArchiveAtcionsForIndividualSections(archiveNumber), // NRH New API
                //() => omniaArchiveSubmissionStatus = CheckOmniaSubmissionAllowed(archiveNumber).IsAllowed, // NRH Existing API
                //() => ERPS = GetEngagementRelatedPersonalStatus(archiveNumber)); // NRH New API

            // Determine whether logged in user can approve the archive sections or not
            if (archiveInfo.ArchiveStatus == ArchiveStatus.ReadyForApproval.GetDescription() || archiveInfo.ArchiveStatus == ArchiveStatus.ResubmittedReadyForApproval.GetDescription()) // Archive should be in ready for approval state
            {
                if (archiveInfo.LastSubmittedBy != userAlias && archiveRoles.Any(role => role.EmployeeAlias.Contains(userAlias))) //Logged in user is not submitter and logged in user is part of the archive team
                {
                    if (!archiveActions.Any() || archiveActions.Any(action => action.ActionBy == userAlias)) // Not appoved any section yet or approved by logged in user
                    {
                        var submitterRole = archiveRoles.Where(role => role.EmployeeAlias.Contains(archiveInfo.LastSubmittedBy)).FirstOrDefault();
                        var loggedInUserRole = archiveRoles.Where(role => role.EmployeeAlias.Contains(userAlias)).FirstOrDefault();

                        if (submitterRole != null && loggedInUserRole != null && archiveInfo.LastSubmittedBy != userAlias)
                        {
                            if (submitterRole.RoleId == (int)Role.ArchiveFieldSenior && (loggedInUserRole.RoleId == (int)Role.ArchiveManager || loggedInUserRole.RoleId == (int)Role.ArchivePartner || loggedInUserRole.RoleId == (int)Role.Admin))
                                archiveStatus.CanApprove = true;
                            else if (submitterRole.RoleId == (int)Role.ArchiveManager && (loggedInUserRole.RoleId == (int)Role.ArchivePartner || loggedInUserRole.RoleId == (int)Role.Admin))
                                archiveStatus.CanApprove = true;
                            else if (submitterRole.RoleId == (int)Role.ArchivePartner && (loggedInUserRole.RoleId == (int)Role.PPD || loggedInUserRole.RoleId == (int)Role.Admin))
                                archiveStatus.CanApprove = true;
                        }
                    }
                }
            }

            //archiveStatus.WorkingPaperStatus = workingPapersMessage;
            //archiveStatus.DeliverableStatus = deliverablesMessage;
            archiveStatus.ArchiveInfo = archiveInfo;
            //archiveStatus.MatRoiUpdates = matRoiUpdates;// NRH
           // archiveStatus.RetentionExceptionStatus = retentionExceptionMessage; // Remove it
            //archiveStatus.LinkedArchiveStatus = linkedArchivesStatus; // NRH
            //archiveStatus.ArchiveAtcionsForIndividualSections = archiveAtcionsForIndividualSections; // NRH
            //archiveStatus.EngagementRelatedPersonalStatus = ERPS; // NRH
            //archiveStatus.OmniaTransferPending = omniaArchiveSubmissionStatus; // NRH
            //Omnia changes
            //archiveStatus.ReadyToSubmit = archiveStatus.ReadyToSubmit && CheckOmniaSubmissionAllowed(archiveNumber).IsAllowed;

            return archiveStatus;
        }


        public string InsertTempArciveTeam(TemporaryArchiveTeam archiveTeam)
        {
            _logger.LogInformation("Manage Temporary Archive Team for " + System.Web.HttpUtility.HtmlEncode(archiveTeam.ArchiveNumber));
            var result = _archiveRepository.InsertTempArciveTeam(archiveTeam);
            return result;
        }

        public InsertArchiveAccessRequest CreateTempArchiveAccessRequest(RequestTemporaryArchiveAccess requestAccess)
        {
            _logger.LogInformation("Create Temporary Archive Access for Archive ID : " + System.Web.HttpUtility.HtmlEncode(requestAccess.ArchiveNumber) + " for " + System.Web.HttpUtility.HtmlEncode(requestAccess.RequestedBy));
            var result = _archiveRepository.CreateTempArchiveAccessRequest(requestAccess);

            #region Email
            if (result.Message == "Request Raised successfully")
            {
                Console.WriteLine("Pushing Message to Email SNS Starts for Archive " + requestAccess.ArchiveNumber);
                RequestTemporaryAccessNotification rtn = new RequestTemporaryAccessNotification();
                BaseEmailEntity be = new BaseEmailEntity();
                be = rtn.GetTemporaryAceessRaisedNotification("CreateTempArchiveAccessRequest", "", "4", requestAccess, result);
                _emailNotificationService.PublishEmailNotification(be);
            }
            //email.OperationDescription = " Access request —";
            //email.OperationType = "ACTION REQUIRED";
            //email.TemplateId = "1";
            //email.TagValues = new Dictionary<string, string>();
            //email.TagValues.Add("ArchiveNumber", requestAccess.ArchiveNumber);
            //email.TagValues.Add("RequestedBy", result.RequestedByName);
            //email.TagValues.Add("RequestedOf", result.RequestedOfName);
            //email.TagValues.Add("RequestReasons", requestAccess.Description);

            //string JSONData = JsonConvert.SerializeObject(email);
            //_logger.LogInformation("Json Data : " + JSONData);
            //var messageIdEmail = objEmail.PushMsgtoSNS(JSONData).Result;
            //Console.WriteLine("Message Pushed with Id" + messageIdEmail);

            //_logger.LogInformation("SNS MessageId: " + messageIdEmail + " for Email Archive Temp Access: " + requestAccess.ArchiveNumber);
            #endregion

            return result;
        }

        public List<ArchiveAccessRequestForApproval> GetArchiveAccessRequestsForApproval(string EmployeeUniqueIdentifier, int PageNumber = 0, int PageSize = 0)
        {
            _logger.LogInformation(string.Format("Processing {0} service method.", System.Reflection.MethodBase.GetCurrentMethod()));
            List<ArchiveAccessRequestForApproval> archiveAccessRequestForApproval = null;
            archiveAccessRequestForApproval = _archiveRepository.GetArchiveAccessRequestsForApproval(EmployeeUniqueIdentifier, PageNumber, PageSize);
            return archiveAccessRequestForApproval;
        }

        public List<ArchiveAccessRequestDetails> GetArchiveAccessRequestsDetailsReport(string EmployeeUniqueIdentifier, int PageNumber = 0, int PageSize = 0)
        {
            _logger.LogInformation(string.Format("Processing {0} service method.", System.Reflection.MethodBase.GetCurrentMethod()));
            // ArchiveAccessRequestDetailsReport archiveAccessRequestForApproval = null;
            var archiveAccessRequestForApproval = _archiveRepository.GetArchiveAccessRequestsDetailsReport(EmployeeUniqueIdentifier, PageNumber, PageSize);
            return archiveAccessRequestForApproval;
        }
        public List<MyForm3283Data> GetForm3283RequestDetailsToExportToExcel(string EmployeeUniqueIdentifier, int PageNumber = 0, int PageSize = 0)
        {
            _logger.LogInformation(string.Format("Processing {0} service method.", System.Reflection.MethodBase.GetCurrentMethod()));
            // ArchiveAccessRequestDetailsReport archiveAccessRequestForApproval = null;
            var archiveAccessRequestForApproval = _archiveRepository.GetForm3283RequestDetailsToExportToExcel(EmployeeUniqueIdentifier, PageNumber, PageSize);
            return archiveAccessRequestForApproval;
        }

        public List<MyPendingSubmissionData> GetMyPendingSubmissionDashBoardDataToExcel(string EmployeeUniqueIdentifier, int PageNumber = 0, int PageSize = 0)
        {
            _logger.LogInformation(string.Format("Processing {0} service method.", System.Reflection.MethodBase.GetCurrentMethod()));
            // ArchiveAccessRequestDetailsReport archiveAccessRequestForApproval = null;
            var archiveAccessRequestForApproval = _archiveRepository.GetMyPendingSubmissionDashBoardDataToExcel(EmployeeUniqueIdentifier, PageNumber, PageSize);
            return archiveAccessRequestForApproval;
        }

        public ArchiveAccessRequestDetailsReport GetArchiveAccessRequestDetailsReport(string EmployeeUniqueIdentifier, int PageNumber = 0, int PageSize = 0)
        {
            _logger.LogInformation(string.Format("Processing {0} service method.", System.Reflection.MethodBase.GetCurrentMethod()));
            ArchiveAccessRequestDetailsReport archiveAccessRequestForApproval = null;
            archiveAccessRequestForApproval = _archiveRepository.GetArchiveAccessRequestDetailsReport(EmployeeUniqueIdentifier, PageNumber, PageSize);
            return archiveAccessRequestForApproval;
        }

        public List<XlsxSheetToGenerate> GetBoxListingReportSheets(ArchiveAccessRequestDetailsReport boxListingReportSheets)
        {
            XlsxGenerator _xlsxGenerator = new XlsxGenerator();
            return new List<XlsxSheetToGenerate>
                {
                    new XlsxSheetToGenerate
                    {
                        Properties = typeof(ArchiveAccessRequestDetails).GetProperties(),
                        SheetName = "ArchiveAccessDetailsReport",
                        DataSource = _xlsxGenerator.GetIDataSheetList(boxListingReportSheets.List)
                    }
                };
        }

        public RequestCountForApproval GetArchiveAccessRequestCountForApproval(string EmployeeUniqueIdentifier)
        {
            _logger.LogInformation(string.Format("Processing {0} service method.", System.Reflection.MethodBase.GetCurrentMethod()));
            var result = _archiveRepository.GetArchiveAccessRequestCountForApproval(EmployeeUniqueIdentifier);
            return result;
        }

        public RequestCountForApproval GetForm3283sCountForApproval(string EmployeeUniqueIdentifier)
        {
            _logger.LogInformation(string.Format("Processing {0} service method.", System.Reflection.MethodBase.GetCurrentMethod()));
            var result = _archiveRepository.GetForm3283sCountForApproval(EmployeeUniqueIdentifier);
            return result;
        }

        public EarlyTerminationCeasedDate UpdateEarlyTerminationDate(EarlyTerminationCeasedDate EarlyTerminationValues)
        {
            _logger.LogInformation("UpdateEarlyTerminationDate ArchiveNumber : " + System.Web.HttpUtility.HtmlEncode(EarlyTerminationValues.ArchiveNumber));
            var result = _archiveRepository.AddEarlyTerminationDate(EarlyTerminationValues);
            return result;
        }

        public EarlyTerminationCeasedDate FetchEarlyTerminationDate(EarlyTerminationCeasedDate FetchEarlyTerminationValues)
        {
            _logger.LogInformation("FetchEarlyTerminationDate ArchiveNumber : " + System.Web.HttpUtility.HtmlEncode(FetchEarlyTerminationValues.ArchiveNumber));
            var result = _archiveRepository.getEarlyTerminationDate(FetchEarlyTerminationValues);
            return result;
        }
        public FormStatus GetFormStatus(string archiveNumber, int timeOffSet = 0)
        {
            var result = _archiveRepository.GetFormStatus(archiveNumber, timeOffSet);
            return result;
        }

        public string GrantDenyTempArchiveAccessRequest(GrantDenyTemporaryArchiveAccess argGrantDenyAccess, string userAlias)
        {
            //_logger.LogInformation("Create Temporary Archive Access for Archive ID : " + requestAccess.ArchiveNumber + " for " + requestAccess.RequestedBy);

            Console.WriteLine("Grant/Deny action is being performed for ArchiveAccessRequestID:" + argGrantDenyAccess.ArchiveAccessRequestId + " at service level");

            var result = _archiveRepository.GrantDenyTempArchiveAccessRequest(argGrantDenyAccess);

            #region Email
            //Deny
            if (argGrantDenyAccess.GrantOrDeny == "0")
            {
                Console.WriteLine("Pushing Message to Email SNS Starts for Archive AccessRequestId" + argGrantDenyAccess.ArchiveAccessRequestId);
                RequestTemporaryAccessNotification rtn = new RequestTemporaryAccessNotification();
                BaseEmailEntity be = new BaseEmailEntity();

                be = rtn.GetTemporaryAceessRejectedNotification("GrantDenyTempArchiveAccessRequest", "", "7", argGrantDenyAccess, userAlias);

                be.AdditionalInfo = argGrantDenyAccess.ArchiveAccessRequestId.ToString();
                _emailNotificationService.PublishEmailNotification(be);
            }
            else// Grant
            {
                Console.WriteLine("Pushing Message to Email SNS Starts for Archive AccessRequestId" + argGrantDenyAccess.ArchiveAccessRequestId);
                RequestTemporaryAccessNotification rtn = new RequestTemporaryAccessNotification();
                BaseEmailEntity be = new BaseEmailEntity();

                be = rtn.GetTemporaryAceessApprovedNotification("GrantDenyTempArchiveAccessRequest", "", "6", argGrantDenyAccess, userAlias);

                be.AdditionalInfo = argGrantDenyAccess.ArchiveAccessRequestId.ToString();
                _emailNotificationService.PublishEmailNotification(be);
            }
            #endregion

            return result;
        }

        public Object GetTemporaryArchiveAccessRequest(GrantDenyTemporaryArchiveAccess requestAccess)
        {
            _logger.LogInformation("Get Temporary Archive Access details for Archive ID : " + System.Web.HttpUtility.HtmlEncode(requestAccess.ArchiveAccessRequestId));

            Console.WriteLine("Get Temporary Archive Access details for Archive ID : " + requestAccess.ArchiveAccessRequestId);

            var result = _archiveRepository.GetTemporaryArchiveAccessRequest(requestAccess);
            return result;

        }
        public List<ArchiveDeletionStatus> GetArchiveDeletionStatus(string ArchiveNumber)
        {

            var result = _archiveRepository.GetArchiveDeletionStatus(ArchiveNumber);
            return result;
        }

        #region

        public ArchiveDueDateEngine GetArchiveDueDateCriteria(string ArchiveNumber, string UserAlias)
        {

            var result = _archiveRepository.GetArchiveDueDateCriteria(ArchiveNumber, UserAlias);
            return result;
        }

        #endregion

        public string ArchiveResubmissionOpen(ArchiveSubmission archiveSubmission)
        {
            _logger.LogInformation("ArchiveResubmissionOpen ArchiveNumber : " + System.Web.HttpUtility.HtmlEncode(archiveSubmission));
            var result = _archiveRepository.ArchiveResubmissionOpen(archiveSubmission);
            return result;
        }


        public (string successMessage, string archiveStatus, string zoneName) InsertResubmissionApprover(string UserAlias, string ArchiveNumber, int? RoleID)
        {
            _logger.LogInformation("Manage  InsertResubmissionApprover for " + System.Web.HttpUtility.HtmlEncode(ArchiveNumber));
            var result = _archiveRepository.InsertResubmissionApprover(UserAlias, ArchiveNumber, RoleID);

            #region Email

            // For Archive ReSubmission - For Approval 
            if (ArchiveNumber != "" && result.archiveStatus == "Resubmitted - Ready for Approval")
            {
                Console.WriteLine("Pushing Message to Email SNS Starts for Archive Resubmission Approval from AM/AP/PPD/NPPD for Archive Number " + ArchiveNumber);
                ArchiveResubmissionNotification rtn = new ArchiveResubmissionNotification();
                BaseEmailEntity be = new BaseEmailEntity();
                be = rtn.Resubmission_ForApproval_Notification("InsertResubmissionApprover", "InsertResubmissionApprover", "21", ArchiveNumber, UserAlias);

                be.TemplateId = "21";

                _emailNotificationService.PublishEmailNotification(be);

            }
            // For Archive ReSubmission - Approved 
            if (ArchiveNumber != "" && result.archiveStatus == "Resubmitted – Approved") //Resubmitted – Approved

            {
                Console.WriteLine("Pushing Message to Email SNS Starts for Archive Resubmission Approved for Archive Number " + ArchiveNumber);
                ArchiveResubmissionNotification rtn = new ArchiveResubmissionNotification();
                BaseEmailEntity be = new BaseEmailEntity();
                be = rtn.Resubmission_Approved_Immediate_Notification("InsertResubmissionApprover", "InsertResubmissionApprover", "25", ArchiveNumber, UserAlias, result.officeZoneName);

                be.TemplateId = "25";

                _emailNotificationService.PublishEmailNotification(be);

            }
            // For Archive ReSubmission - Approved 
            if (ArchiveNumber != "" && result.archiveStatus == "Resubmitted - Rejected")
            {
                Console.WriteLine("Pushing Message to Email SNS Starts for Archive Resubmission Rejected First Level for Archive Number " + ArchiveNumber);
                ArchiveResubmissionNotification rtn = new ArchiveResubmissionNotification();
                BaseEmailEntity be = new BaseEmailEntity();
                be = rtn.Resubmission_Rejected_Immediate_Notification("InsertResubmissionApprover", "InsertResubmissionApprover", "25", ArchiveNumber, UserAlias);

                be.TemplateId = "61";

                _emailNotificationService.PublishEmailNotification(be);

            }
            #endregion
            return result;
        }

        public string GetUserAlias(string employeeUniqueIdentifier)
        {
            _logger.LogInformation(string.Format("Processing {0} service method.", System.Reflection.MethodBase.GetCurrentMethod()));
            //var myArchives = _archiveRepository.GetMyArchives(personnelNumber, pageNumber, pageSize, sortDirection, orderBy, search);
            string myArchives = null;
            myArchives = _archiveRepository.GetUserAlias(employeeUniqueIdentifier);
            return myArchives;
        }

        public Memo CreateOrUpdateMemo(Memo memoModel)
        {
            try
            {
                _logger.LogError("CreateOrUpdateMemo method initiated");
                var memoresult = _archiveRepository.CreateOrUpdateMemo(memoModel);
                return memoresult;
            }
            catch (Exception ex)
            {
                _logger.LogError("Error occured", ex.Message);
                throw;
            }
        }
        public List<ResubmissionReason> GetResubmissionReasons()
        {
            try
            {
                _logger.LogError("Fetch Resubmission Reasons initiated");
                return _archiveRepository.GetResubmissionReasons();
            }
            catch (Exception ex)
            {
                _logger.LogError("Error occured", ex.Message);
                throw ex;
            }
        }


        public IList<string> GetROINumbers(string archiveNumber)
        {
            return _archiveRepository.GetROINumbers(archiveNumber);
        }

        public IList<string> GetPendingOmniaEngagements(string archiveNumber)
        {
            return new List<string>();
        }

        public bool UpdateRoiFilePath(string archiveNumber, string roiNumber, string eTag, long fileTransferId, string s3FilePath, string createdBy)
        {
            return _archiveRepository.UpdateRoiFilePath(archiveNumber, roiNumber, eTag, fileTransferId, s3FilePath, createdBy);
        }
        public List<Memo> GetUploadedMemo(string ArchiveNumber)
        {
            try
            {
                _logger.LogError("GetUploadedMemo method initiated");
                var memoresult = _archiveRepository.GetUploadedMemo(ArchiveNumber);
                return memoresult;
            }
            catch (Exception ex)
            {
                _logger.LogError("Error occured", ex.Message);
                throw;
            }
        }

        public string DeleteUploadedMemo(string ArchiveFileID, string userAlias)
        {
            _logger.LogInformation("Manage  DeleteUploadedMemo for " + System.Web.HttpUtility.HtmlEncode(ArchiveFileID));
            var result = _archiveRepository.DeleteUploadedMemo(ArchiveFileID, userAlias);
            return result;
        }

        public string InsertUpdateArchiveSubmissionFlow(string ArchiveNumber, string UserAlias)
        {
            _logger.LogInformation("Insert Archive submitter in open case" + System.Web.HttpUtility.HtmlEncode(UserAlias));
            var result = _archiveRepository.InsertUpdateArchiveSubmissionFlow(ArchiveNumber, UserAlias);

            #region Email

            // For Archive Submission - For Approval [Immediate]
            if (ArchiveNumber != "")
            {
                Console.WriteLine("Pushing Message to Email SNS Starts for Archive Approval for Archive Number " + ArchiveNumber);
                ArchiveSubmissionNotification rtn = new ArchiveSubmissionNotification();
                BaseEmailEntity be = new BaseEmailEntity();
                be = rtn.Submission_ForApproval_Notification("InsertUpdateArchiveSubmissionFlow", "InsertUpdateArchiveSubmissionFlow", "15", ArchiveNumber, UserAlias);

                be.TemplateId = "15";

                _emailNotificationService.PublishEmailNotification(be);

            }
            #endregion

            return result;
        }

        public GetArchiveApproverFromSubmitter GetArchiveApproverforArchiveSubmission(string ArchiveNumber, string UserAlias, int RoleID)
        {
            _logger.LogInformation("Fetch Archive approver based on submitter in submission case" + System.Web.HttpUtility.HtmlEncode(UserAlias));
            return _archiveRepository.GetArchiveApproverforArchiveSubmission(ArchiveNumber, UserAlias, RoleID);
        }
        public GetArchiveApproverFromSubmitter CheckAPSubmitterInactive(string ArchiveNumber, string UserAlias, int CheckType)
        {
            _logger.LogInformation("Method to check if the AP is submitter or Inactive." + System.Web.HttpUtility.HtmlEncode(UserAlias));
            return _archiveRepository.CheckAPSubmitterInactive(ArchiveNumber, UserAlias, CheckType);
        }

        public OmniaArchiveSubmissionStatus CheckOmniaSubmissionAllowed(string ArchiveNumber)
        {
            _logger.LogInformation("Method to check if the AP is submitter or Inactive." + System.Web.HttpUtility.HtmlEncode(ArchiveNumber));
            return _archiveRepository.CheckOmniaSubmissionAllowed(ArchiveNumber);
        }



        public List<ArchiveHistory> GetArchiveHistory(string ArchiveNumber, int PageNumber, int PageSize, int SortBy)
        {
            var archivehistory = _archiveRepository.GetArchiveHistory(ArchiveNumber, PageNumber, PageSize, SortBy);
            return archivehistory;

        }

        //UpdateFirstLevelResubmissionApprovalFlagSet
        public string UpdateFirstLevelResubmissionApprovalFlag(string ArchiveNumber, string UserAlias)
        {
            _logger.LogInformation("Manage  UpdateFirstLevelResubmissionApprovalFlag for " + System.Web.HttpUtility.HtmlEncode(ArchiveNumber));
            var result = _archiveRepository.UpdateFirstLevelResubmissionApprovalFlagSet(ArchiveNumber, UserAlias);
            return result;
        }

        public List<MyPendingSubmissionData> GetMyRequiringApprovalDashBoardDataToExcel(string userAlias, int pageNumber, int pageSize)
        {
            _logger.LogInformation(string.Format("Processing {0} service method.", System.Reflection.MethodBase.GetCurrentMethod()));
            // ArchiveAccessRequestDetailsReport archiveAccessRequestForApproval = null;
            var archiveAccessRequestForApproval = _archiveRepository.GetMyRequiringApprovalDashBoardDataToExcel(userAlias, pageNumber, pageSize);
            return archiveAccessRequestForApproval;
        }
        public List<MyPendingSubmissionData> GetMyAwaitingApprovalDashBoardDataToExcel(string userAlias, int pageNumber, int pageSize)
        {
            _logger.LogInformation(string.Format("Processing {0} service method.", System.Reflection.MethodBase.GetCurrentMethod()));
            // ArchiveAccessRequestDetailsReport archiveAccessRequestForApproval = null;
            var archiveAccessRequestForApproval = _archiveRepository.GetMyAwaitingApprovalDashBoardDataToExcel(userAlias, pageNumber, pageSize);
            return archiveAccessRequestForApproval;
        }

        public List<MyPendingSubmissionData> GetDeletionRequestsDashBoardDataToExcel(string userAlias, int pageNumber, int pageSize)
        {
            _logger.LogInformation(string.Format("Processing {0} service method.", System.Reflection.MethodBase.GetCurrentMethod()));
            var archivedeletionrequests = _archiveRepository.GetDeletionRequestsDashBoardDataToExcel(userAlias, pageNumber, pageSize);
            return archivedeletionrequests;
        }
        public string DeleteArchive(ArchiveDeletionAction deletionrequest)
        {
            _logger.LogInformation("Delete Archive Requesr For " + System.Web.HttpUtility.HtmlEncode(deletionrequest.ArchiveNumber));
            var result = _archiveRepository.DeleteArchive(deletionrequest);
            var result_values = result.Split(";");


            #region Email

            ArchiveDeletionNotification rtn = new ArchiveDeletionNotification();
            BaseEmailEntity be = new BaseEmailEntity();

            // For archive deletion request sent action 
            if (deletionrequest.ArchiveNumber != "" && deletionrequest.ActionTypeID == 1)
            {
                Console.WriteLine("Pushing Message to Email SNS Starts for Archive Deletion Request for Archive Number " + deletionrequest.ArchiveNumber);

                be = rtn.ArchiveDeletionRequest_Notification("DeleteArchive", "DeleteArchive", "57", deletionrequest.ArchiveNumber, result_values[3], result_values[4]);

                be.TemplateId = "57";
                be.AdditionalInfo = result_values[1] + ";" + result_values[2];

                _emailNotificationService.PublishEmailNotification(be);

            }
            //For archive deletion approve action
            else if (deletionrequest.ArchiveNumber != "" && deletionrequest.ActionTypeID == 2)
            {
                Console.WriteLine("Pushing Message to Email SNS Starts for Archive Deletion Request for Archive Number " + deletionrequest.ArchiveNumber);

                be = rtn.ArchiveDeletionRequest_ApproveNotification("DeleteArchive", "DeleteArchive", "58", deletionrequest.ArchiveNumber, result_values[3], result_values[4]);

                be.TemplateId = "58";
                be.AdditionalInfo = result_values[1] + ";" + result_values[2];

                _emailNotificationService.PublishEmailNotification(be);
            }
            //For archive deletion reject action
            else if (deletionrequest.ArchiveNumber != "" && deletionrequest.ActionTypeID == 3)
            {
                Console.WriteLine("Pushing Message to Email SNS Starts for Archive Deletion Request for Archive Number " + deletionrequest.ArchiveNumber);

                be = rtn.ArchiveDeletionRequest_RejectNotification("DeleteArchive", "DeleteArchive", "59", deletionrequest.ArchiveNumber, result_values[3], result_values[4]);

                be.TemplateId = "59";
                be.AdditionalInfo = result_values[1] + ";" + result_values[2];
                _emailNotificationService.PublishEmailNotification(be);
            }
            #endregion

            return result_values[0];
        }
        public List<AppliedArchiveHoldsInformation> ApplyArchiveHolds(ApplyArchiveHolds applyArchiveHolds)
        {
            _logger.LogInformation("Apply Holds Screen- Archive Service");
            return _archiveRepository.ApplyArchiveHolds(applyArchiveHolds);

        }
        public List<HoldHistoryDetails> GetHoldHistoryDetails(int HoldId, string HoldNumber, int ArchiveHoldHistoryId)
        {
            _logger.LogInformation("Get Hold History Details- ArchiveService");
            return _archiveRepository.GetHoldHistoryDetails(HoldId, HoldNumber, ArchiveHoldHistoryId);
        }
        public List<HoldDetailsMetadata> GetArchivesAssociatedtoHolds(string HoldNumber, int BusinessId, string ClientId, string FilterText, int SortBy)
        {
            var HoldInfo = _archiveRepository.GetArchivesAssociatedtoHolds(HoldNumber, BusinessId, ClientId, FilterText, SortBy);
            return HoldInfo;
        }

        public List<Binders> GetBinderDetails(string archiveNumber, int pageNumber, int pageSize, int sortBy)
        {
            return _archiveRepository.GetBinderDetails(archiveNumber, pageNumber, pageSize, sortBy);
        }

        public string RemoveArchiveFromHold(int HoldId, string ArchiveNumber, string userAlias)
        {
            var result = _archiveRepository.RemoveArchiveFromHold(HoldId, ArchiveNumber, userAlias);
            return result.ToString();
        }
        public string RemoveHoldFromArchive(string ArchiveNumber, string HoldNumber, string userAlias)
        {
            var result = _archiveRepository.RemoveHoldFromArchive(ArchiveNumber, HoldNumber, userAlias);
            return result.ToString();
        }

        public List<AppliedArchiveHoldsInformation> GetArchivesForApplyingHold(string SearchBy, string SearchByValue, string IncludeOrExclude, string HoldName, string Business, string PeriodStart, string PeriodEnd, string SortBy, string SortOrder, int PageNumber, int PageSize)
        {
            _logger.LogInformation("GetArchivesForApplyingHold- Archive Service");
            return _archiveRepository.GetArchivesForApplyingHold(SearchBy, SearchByValue, IncludeOrExclude, HoldName, Business, PeriodStart, PeriodEnd, SortBy, SortOrder, PageNumber, PageSize);

        }

        public string CreateRequestImageAction(RMIntegrationActions requestImage)
        {
            _logger.LogInformation("Request Image Action raised For " + System.Web.HttpUtility.HtmlEncode(requestImage.BinderID));
            var result = _archiveRepository.CreateRequestImageAction(requestImage);
            return result;
        }
    }
}
