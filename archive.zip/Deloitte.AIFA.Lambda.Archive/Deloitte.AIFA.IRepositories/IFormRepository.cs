﻿using Deloitte.AIFA.DomainEntities;
using Deloitte.AIFA.Models;
using System;
using System.Collections.Generic;

namespace Deloitte.AIFA.IRepositories
{
    public interface IFormRepository
    {
        FormActionResponse CreateOrUpdateForm(FormSubmitInfo submitForm);
        Form3283PrepopulatedData GetForm3283PrepopulatedData(string archiveNumber, string loggedInUser);
        FormActionResponse ApproveForm(ApproveOrRejectFormRequest request);
        FormActionResponse RejectForm(ApproveOrRejectFormRequest request);
        FormActionResponse ChangeApprover(ChangeApproverRequest request);
    }
}
