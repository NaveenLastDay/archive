﻿using HtmlAgilityPack;
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using System.Xml;

namespace Deloitte.AIFA.Helpers
{
    public class HtmlSanitizerHelper
    {
        private static  HashSet<string> BlackList;
  

        public static string validateProperties(object t,string inputstringRegex)
        {
            foreach (PropertyInfo prop in t.GetType().GetProperties())
            {

                var type = Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType;

               
                if (type == typeof(List<char>))
                {
                    var list = prop.GetValue(t, null) as List<char>;
                    foreach (var value in list)
                    {
                        char character = 'a';
                        if (value == null)
                            continue;
                        if (char.TryParse(prop.GetValue(t, null).ToString(), out character))
                        {

                        }
                        else
                        {
                            return "invalid";
                        }

                    }

                }
                else if (type == typeof(List<string>))
                {
                    var list = prop.GetValue(t, null) as List<string>;
                    foreach (var value in list)
                    {
                        if ((value == null) || (value == string.Empty))
                            continue;
                        var match = value.IndexOfAny(inputstringRegex.ToCharArray()) != -1;
                        if (!match)
                        {
                        }
                        else
                            return "invalid";
                    }
                }
                else if (type == typeof(List<DateTime>))
                {
                    var list = prop.GetValue(t, null) as List<DateTime>;
                    foreach (var value in list)
                    {
                       string[] formats = {"M/d/yyyy h:mm:ss tt","M/d/yy h:mm:ss tt", "M/d/yyyy h:mm tt",
                                 "MM/dd/yyyy hh:mm:ss", "M/d/yyyy h:mm:ss",
                                  "M/d/yyyy hh:mm tt", "M/d/yyyy hh tt",
                                  "M/d/yyyy h:mm", "M/d/yyyy h:mm",
                                   "MM/dd/yyyy hh:mm", "M/dd/yyyy hh:mm",
                                   "MM/d/yyyy HH:mm:ss.ffffff" };
                            DateTime dt;
                            if (value == null)
                                continue;
                            if (DateTime.TryParseExact(value.ToString(), formats, null, System.Globalization.DateTimeStyles.None, out dt))
                            {
                                //parsed correctly
                            }
                            else
                            {
                                return "invalid";
                            }
                                            
                    }

                }
                else if (type == typeof(List<int>))
                {
                    var list = prop.GetValue(t, null) as List<int>;
                    foreach (var value in list)
                    {
                        int ab = 0;
                        if (value == null)
                            continue;
                        if (int.TryParse(value.ToString(), out ab))
                        {

                        }
                        else
                            return "invalid";
                    }

                }
                else if (type == typeof(List<long>))
                {
                    var list = prop.GetValue(t, null) as List<long>;
                    foreach (var value in list)
                    {
                        if (value == null)
                            continue;
                        long ab = 0;
                        if (long.TryParse(value.ToString(), out ab))
                        {

                        }
                        else
                            return "invalid";
                    }

                }
                else if (type == typeof(List<float>))
                {
                    var list = prop.GetValue(t, null) as List<float>;
                    foreach (var value in list)
                    {
                        if (value == null)
                            continue;
                        float ab = 0;
                        if (float.TryParse(value.ToString(), out ab))
                        {

                        }
                        else
                            return "invalid";
                    }

                }
                else if (type == typeof(List<double>))
                {
                    var list = prop.GetValue(t, null) as List<double>;
                    foreach (var value in list)
                    {
                        if (value == null)
                            continue;
                        double ab = 0;
                        if (double.TryParse(value.ToString(), out ab))
                        {

                        }
                        else
                            return "invalid";
                    }

                }
                else if (type == typeof(List<bool>))
                {
                    var list = prop.GetValue(t, null) as List<bool>;
                    foreach (var value in list)
                    {
                        if (value == null)
                            continue;
                        bool ab = false;
                        if (bool.TryParse(value.ToString(), out ab))
                        {

                        }
                        else
                            return "invalid";
                    }

                }
                else if (type == typeof(char))
                {
                    char character = 'a';
                    if (prop.GetValue(t, null) == null)
                        continue;
                    if (char.TryParse(prop.GetValue(t, null).ToString(), out character))
                    {

                    }
                    else
                    {
                        Console.WriteLine("Character is Invalid " + prop.GetValue(t, null));

                        return "invalid";
                    }

                }
                else if (type == typeof(DateTime))
                {
                    string[] formats = {"M/d/yyyy h:mm:ss tt","M/d/yy h:mm:ss tt", "M/d/yyyy h:mm tt",
                   "MM/dd/yyyy hh:mm:ss", "M/d/yyyy h:mm:ss",
                   "M/d/yyyy hh:mm tt", "M/d/yyyy hh tt",
                   "M/d/yyyy h:mm", "M/d/yyyy h:mm",
                   "MM/dd/yyyy hh:mm", "M/dd/yyyy hh:mm",
                   "MM/d/yyyy HH:mm:ss.ffffff" };
                    DateTime dt;
                    if (prop.GetValue(t, null) == null)
                        continue;
                    if (DateTime.TryParseExact(prop.GetValue(t, null).ToString(), formats, null, System.Globalization.DateTimeStyles.None, out dt))
                    {
                        //parsed correctly
                    }
                    else
                    {
                        Console.WriteLine("DateTime is Invalid " + prop.GetValue(t, null));

                        return "invalid";
                    }
                }
                else if (type == typeof(string))
                {
                    if ((prop.GetValue(t, null) == null) || (prop.GetValue(t, null).ToString()==string.Empty))
                        continue;
                    
                    var match = prop.GetValue(t, null).ToString().IndexOfAny(inputstringRegex.ToCharArray()) != -1;
                    if (!match)
                    {
                        Console.WriteLine("Alphanumeric String");
                    }
                    else
                    {
                        Console.WriteLine("String is Invalid " + prop.GetValue(t, null));

                        return "invalid";
                    }
                }
                else if (type == typeof(int))
                {
                    int ab = 0;
                    if (prop.GetValue(t, null) == null)
                        continue;
                    if (int.TryParse(prop.GetValue(t, null).ToString(), out ab))
                    {

                    }
                    else
                        return "invalid";
                }
                else if (type == typeof(long))
                {
                    if (prop.GetValue(t, null) == null)
                        continue;
                    long ab = 0;
                    if (long.TryParse(prop.GetValue(t, null).ToString(), out ab))
                    {

                    }
                    else
                        return "invalid";
                }
                else if (type == typeof(float))
                {
                    if (prop.GetValue(t, null) == null)
                        continue;
                    float ab = 0;
                    if (float.TryParse(prop.GetValue(t, null).ToString(), out ab))
                    {

                    }
                    else
                        return "invalid";

                }
                else if (type == typeof(double))
                {
                    if (prop.GetValue(t, null) == null)
                        continue;
                    double ab = 0;
                    if (double.TryParse(prop.GetValue(t, null).ToString(), out ab))
                    {

                    }
                    else
                        return "invalid";
                }
                else if (type == typeof(bool))
                {
                    if (prop.GetValue(t, null) == null)
                        continue;
                    bool ab = false;
                    if (bool.TryParse(prop.GetValue(t, null).ToString(), out ab))
                    {

                    }
                    else
                        return "invalid";

                }
                else
                {
                    var value = prop.GetValue(t, null);
                    var valuetype = value.GetType();
                    if (valuetype.BaseType == typeof(object))
                    {
                        var a = validateProperties(value,inputstringRegex);
                        if (a == "invalid")
                            return a;
                    }

                }
            }
            return "valid";
        }


        /// <summary>
        /// Cleans up an HTML string by removing elements
        /// on the blacklist and all elements that start
        /// with onXXX .
        /// </summary>
        /// <param name="html"></param>
        /// <returns></returns>
        public static string Sanitize(string html,HashSet<string> blacklistedTag)
        {
            BlackList = blacklistedTag;
            var doc = new HtmlDocument();
            string result = string.Empty;
            doc.LoadHtml(html);
            var blaclistedtags = SanitizeHtmlNode(doc.DocumentNode);

            string output = null;

            // Use an XmlTextWriter to create self-closing tags
            using (StringWriter sw = new StringWriter())
            {
                XmlWriter writer = new XmlTextWriter(sw);
                doc.DocumentNode.WriteTo(writer);
                output = sw.ToString();

                // strip off XML doc header
                if (!string.IsNullOrEmpty(output))
                {
                    int at = output.IndexOf("?>");
                    output = output.Substring(at + 2);
                }

                writer.Close();
            }
            doc = null;

            result = HttpUtility.HtmlDecode(output);
            return result;
        }

        private static string SanitizeHtmlNode(HtmlNode node)
        {
            if (node.NodeType == HtmlNodeType.Element)
            {
                // check for blacklist items and remove
                if (BlackList.Contains(node.Name))
                {
                    node.Remove();
                    return node.Name;
                }

                // remove CSS Expressions and embedded script links
                if (node.Name == "style")
                {
                    if (string.IsNullOrEmpty(node.InnerText))
                    {
                        if (node.InnerHtml.Contains("expression") || node.InnerHtml.Contains("javascript:"))
                            node.ParentNode.RemoveChild(node);
                        return node.InnerText;
                    }
                }

                // remove script attributes
                if (node.HasAttributes)
                {
                    for (int i = node.Attributes.Count - 1; i >= 0; i--)
                    {
                        HtmlAttribute currentAttribute = node.Attributes[i];

                        var attr = currentAttribute.Name.ToLower();
                        var val = currentAttribute.Value.ToLower();

                        //Span style = "background: white; color: green" >// remove event handlers
                        if (attr.StartsWith("on"))
                            node.Attributes.Remove(currentAttribute);

                        // remove script links
                        else if (
                                 //(attr == "href" || attr== "src" || attr == "dynsrc" || attr == "lowsrc") &&
                                 val != null &&
                                 val.Contains("javascript:"))
                            node.Attributes.Remove(currentAttribute);

                        // Remove CSS Expressions
                        else if (attr == "style" &&
                                 val != null &&
                                 val.Contains("expression") || val.Contains("javascript:") || val.Contains("vbscript:"))
                            node.Attributes.Remove(currentAttribute);
                        return null;
                    }
                }
            }
            string blacklistedtags = string.Empty;
            // Look through child nodes recursively
            if (node.HasChildNodes)
            {
                for (int i = node.ChildNodes.Count - 1; i >= 0; i--)
                {
                    var a = SanitizeHtmlNode(node.ChildNodes[i]);
                    if (a != null && blacklistedtags != string.Empty)
                        blacklistedtags = blacklistedtags + " ," + a;
                    else if (a != null)
                        blacklistedtags = a;

                }
                return blacklistedtags;
            }
            return null;
        }

    }
}
