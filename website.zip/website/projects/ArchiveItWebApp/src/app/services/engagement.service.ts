import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EngagementService {
  constructor(private _http: HttpClient) { }

  apiData: any;

  httpOptions = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json'
          })
        }

public getEngagementDetails(seacrhTerm:string,archiveNumber:string):Observable<any[]>{
  return this._http.get<any[]>("ArchiveMetaData/getswiftengagementinfo?wbsLevelOne=" + seacrhTerm + "&ArchiveNumber=" + archiveNumber);
 }

 public GetEngagementDetailsInfo(archiveId: number): Observable<any> {
  const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
  this.apiData = this._http.get<any[]>('archive/GetEngagementDetails?ArchiveId=' + archiveId, httpOptions);
  return this.apiData;
}

}
