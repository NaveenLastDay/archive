﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
    public class ApproveOrRejectFormRequest
    {
        public int ActionItemId { get; set; }
        public string ApprovedBy { get; set; }
        public string RejectedBy { get; set; }
        public bool IsEditRequired { get; set; }
        public string RejectionReason { get; set; }
        public string ArchiveNumber { get; set; }
        public string ArchiveDueDateCriteria { get; set; }
        public string DeliverableType { get; set; }
        public DateTime? DateThatDrivesEDCD { get; set; }
        public DateTime? RDCDDate { get; set; }
    }
}