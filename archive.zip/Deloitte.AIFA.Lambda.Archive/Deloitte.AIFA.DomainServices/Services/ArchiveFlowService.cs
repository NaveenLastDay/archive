﻿using Deloitte.AIFA.DomainEntities;
using Deloitte.AIFA.DomainServices.Contracts;
using Deloitte.AIFA.ICloudServices;
using Deloitte.AIFA.IRepositories;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainServices.Services
{
    public class ArchiveFlowService : BaseService, IArchiveFlowService
    {

        IArchiveFlowRepository _archiveFlowRepository;
        ILogger _logger;
        IMemoryCache _cache;
        public ArchiveFlowService(IMemoryCache cache, IConfigManager configManager,
                              IArchiveFlowRepository archiveFlowRepository,
                                ILogger<ArchiveFlowService> logger) : base(cache, configManager)
        {
            _cache = cache;
            _logger = logger;
            _archiveFlowRepository = archiveFlowRepository;
        }

        public string CreateOrUpdateArchiveActions(ArchiveFlowDetails aFlowdetails)
        {
            _logger.LogInformation("This is from ArchiveFlowService: GetArchiveSectionComments");
            var archives = _archiveFlowRepository.CreateOrUpdateArchiveActions(aFlowdetails);
            return archives;
        }

        public ArchiveFlowDetails GetArchiveSectionComments(string ArchiveNumber, int sectionId,int ActionTypeId)
        {
            _logger.LogInformation("This is from ArchiveFlowService: GetArchiveSectionComments");
            var archives = _archiveFlowRepository.GetArchiveSectionComments(ArchiveNumber, sectionId, ActionTypeId);
            return archives;
        }

        public List<ArchiveFlowDetails> GetResubmissionReasonsforArchive(string ArchiveNumber)
        {
            _logger.LogInformation("This is from ArchiveFlowService: GetResubmissionReasonsforArchive");
            return _archiveFlowRepository.GetResubmissionReasonsforArchive(ArchiveNumber);
        }
    }
}
