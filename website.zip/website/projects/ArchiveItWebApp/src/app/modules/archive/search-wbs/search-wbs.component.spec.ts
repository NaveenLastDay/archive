import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchWbsComponent } from './search-wbs.component';

describe('SearchWbsComponent', () => {
  let component: SearchWbsComponent;
  let fixture: ComponentFixture<SearchWbsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchWbsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchWbsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
