﻿using Deloitte.AIFA.DomainEntities.EmailEntities;
using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.EmailNotificationServices
{
    public interface IEmailNotificationService
    {
        bool PublishEmailNotification(BaseEmailEntity argBE);
    }
}
