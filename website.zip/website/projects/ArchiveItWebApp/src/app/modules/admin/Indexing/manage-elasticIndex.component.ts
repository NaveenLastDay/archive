
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormArray, Validators } from '@angular/forms';
import { NotifierService } from "angular-notifier";
import { UserConfigSettingService } from '../../../guards/user-role-guard.service';
import { ManageElasticIndexService } from '../../../services/manage-elasticindex.service';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { Router } from '@angular/router';

@Component({
    selector: "manage-elasticindex",
    templateUrl: './manage-elasticIndex.component.html',
    styleUrls: ['./manage-elasticIndex.component.css']
})
export class ManageElasticIndexComponent implements OnInit {

    title = 'Manage Elastic Index';
    userConfig: any;

    elasticFormGroup: FormGroup;

    constructor(private fb: FormBuilder, private _manageElasticIndexService: ManageElasticIndexService,
        private _adalService: MsAdalAngular6Service,
        private _userConfig: UserConfigSettingService,
        private _router: Router,
        private _notifier: NotifierService) {
    }

    ngOnInit() {

        let employeeUniqueIdentifier = this._adalService.LoggedInUserEmail.split('@')[0];
        this.userConfig = this._userConfig.FetchLoggedInUser(employeeUniqueIdentifier)
        
        if (!this.userConfig.value.isITS) {
            this._router.navigate(['/home']);
            return;
        }
        else {
            this.elasticFormGroup = this.fb.group({
                archiveNum: [''],
                Index: [''],
                Delete: [''],
                GetRecords: ['']
            });
        }
    }

    indexArchive(indexType) {
        //debugger;
        var inputValue = this.elasticFormGroup.get('archiveNum').value;
        //var indexType = this.elasticFormGroup.get('Index').value;
        var operationType = "insert";

        var request = {
            "inputValue": inputValue,
            "Indextype": indexType,
            "operationType": operationType,
        };

        this._manageElasticIndexService.indexArchive(request).subscribe(
            data => {
                if (data) {
                    // self._notifier.notify(
                    //     "success",
                    //     "Item added successfully"
                    // );
                    console.log("Index Success");
                }
            },
            err => {
                console.log(err);
            }
        );

        this.elasticFormGroup.reset();
    }

}
