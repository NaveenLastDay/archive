export * from './modal.module';
export * from './modal.service';

console.log("Flow Track => index.ts is loaded")