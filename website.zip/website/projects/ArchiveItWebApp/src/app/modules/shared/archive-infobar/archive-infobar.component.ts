import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { archiveInfo } from '../../../models/archive-info';
import { archiveInfoService } from '../../../services/archiveinfo.service'
import { ActivatedRoute, Params } from '@angular/router';
// import { Router, NavigationEnd } from '@angular/router';
import { Router, NavigationEnd } from '@angular/router';
import { EdcdModel } from '../../../models/edcd.model';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { ArchiveHomeService } from '../../../services/archive-home.service';
import { Subscription } from 'rxjs';
import { PubsubService } from '../../../services/pubsub.service';
import { NgbTooltip } from '@ng-bootstrap/ng-bootstrap';
import { Form3283SService } from '../../../services/form3283-s.service';
import { UserActions } from '../../../models/archive-role.model';
import { ArchiveService } from '../../../services/archive.service';
import { HomePageService } from '../../../services/homepage.service';
import { UserConfigSettingService } from '../../../guards/user-role-guard.service';
import * as moment from 'moment';
import { NgbDateStruct } from "@ng-bootstrap/ng-bootstrap";
import { CsoService } from '../../../services/cso.service';

@Component({
  selector: 'app-archive-infobar',
  templateUrl: './archive-infobar.component.html',
  styleUrls: ['./archive-infobar.component.css']
})
export class ArchiveInfobarComponent implements OnInit {
  @Output() archiveinfoEvent: EventEmitter<any> = new EventEmitter();
  // @Output() ViewSwiftEngagementDetailsEvent: EventEmitter<any> = new EventEmitter();
  @Output() EstimatedDateEvent: EventEmitter<any> = new EventEmitter();
  @Output() WBSNumberEvent: EventEmitter<any> = new EventEmitter();
  archiveinfo: any;
  archiveNumber: any;
  wbsNumber: string;
  engDescToolTip: string;
  employeeUniqueIdentifier: string;
  form3283Subscription: Subscription;
  EDCDSubscription: Subscription;
  EnableStatusbox: boolean;
  EnableSubStyle: boolean;
  EnableApproveStyle: boolean;
  FormStatus: string = "";
  EnableApproveDatebox: boolean = false;
  EnableRejectStatusbox: boolean = false;
  FormStatusDate: Date | null = null;
  IsFormEnabled: boolean;
  ADCEDDate: Date | null = null;
  IsReject: boolean = false;
  IsOpen: boolean = false;
  IsApproved: boolean = false;
  IsArchiveResubmitted: boolean = false;
  apidata: any;
  expecteddate: string;
  edcdDetails: EdcdModel[] = [];
  // roleMapping = new UserActions();
  infoStatus: boolean = false;
  userConfig: any;
  innerColor: any;
  outerColor: any;
  diffDays: any;
  isDaysOverdue: boolean;
  archiveDueDateData: any;
  infoMsg: string = '';
  formstatusCSS: { 'height':any };
  ArchiveResubmissionType:string='';
  labeltextfrom = "ESTIMATED DATE";
  selectDate: string;
  updateedcd: boolean;
  estimatedate: any;
  Displaydate: NgbDateStruct;
  userAlias = this.adalSvc.LoggedInUserEmail.substring(0, this.adalSvc.LoggedInUserEmail.lastIndexOf("@"));
  archivestatus: any;
  archiveOverrideStatus : any;

  constructor(private router: Router, private adalSvc: MsAdalAngular6Service,
    private archiveService: ArchiveService,
    private archiveinfoSvc: archiveInfoService,
    private homepageService: HomePageService,
    private _userConfig: UserConfigSettingService,
    private csoService: CsoService,
    private activatedRoute: ActivatedRoute, private pubsub: PubsubService, private formsvc: Form3283SService,
    private archiveHomeService: ArchiveHomeService) {
    // activatedRoute.params.subscribe(val => {
    //   //debugger;
    // })
  }
  
  getFormSubmissionStatus() {
    this.form3283Subscription = this.pubsub.getForm3283SStatus().subscribe(
      message => {
        this.FormStatus = message.text.formStatusDescription;
        this.FormStatusDate = message.text.formStatusDate;
        this.IsFormEnabled = message.text.isFormEnabled;
        this.ADCEDDate = message.text.adcdDate;
        if (this.FormStatus == "Submitted") {
          this.EnableStatusbox = true;
          this.EnableSubStyle = true;
          this.EnableApproveDatebox = false;
          this.EnableRejectStatusbox = false;
          this.formstatusCSS= {
            'height':'68px'
          }
        }
        else if (this.FormStatus == "Approved") {
          this.EnableStatusbox = true;
          this.EnableSubStyle = false;
          this.EnableApproveDatebox = true;
          this.EnableRejectStatusbox = false;
          this.formstatusCSS= {
            'height':'90px'
          }

        }
        else if (this.FormStatus == "Rejected") {
          this.EnableStatusbox = false;
          this.EnableRejectStatusbox = true;
          this.EnableApproveDatebox = false;
          this.formstatusCSS= {
            'height':'68px'
          }
        }
        else {
          this.EnableStatusbox = false;
          this.EnableRejectStatusbox = false;
          this.EnableApproveDatebox = false;
          this.formstatusCSS= {
            'height':'40px'
          }
        }
        this.archiveinfoEvent.emit({ EnableSubStyle: this.EnableSubStyle, EnableApproveDatebox: this.EnableApproveDatebox, EnableRejectStatusbox: this.EnableRejectStatusbox, EnableStatusbox: this.EnableStatusbox, ADCEDDate: this.ADCEDDate, FormStatus: this.FormStatus, formstatusCSS: this.formstatusCSS, IsFormEnabled: this.IsFormEnabled });
      }
    );

  }

  ngOnInit() {
    // this.archiveinfoSvc.getArchiveInfo(this.archiveNumber, this.userAlias).subscribe(data => {
    // this.archiveHomeService.GetArchiveStatus(this.archiveNumber, this.userAlias).subscribe(data => {
    // });
    this.archiveNumber = this.activatedRoute.snapshot.paramMap.get('aN');
    console.log(this.activatedRoute.snapshot.params.aN);
    this.employeeUniqueIdentifier = this.adalSvc.LoggedInUserEmail.split('@')[0];
    this.userConfig = this._userConfig.FetchLoggedInUser(this.employeeUniqueIdentifier);
    // this.homepageService.getActiveRoles(this.archiveNumber).subscribe(x => {
    //   if (x) {
    //     let data = x.find(obj => obj.employeeAlias.toLowerCase() === this.employeeUniqueIdentifier.toLowerCase());
    //     if ((data == null && !this.userConfig.value.isAdmin) || (data != null && data.roleId ==27  && !this.userConfig.value.isAdmin)) {
    //       this.router.navigate(['/archive/myarchives']);
    //     }
    //   }
    // });
    // this.pubsub.setRoleMappingResult(this.roleMapping);
    // // localStorage.setItem('roleMapping', JSON.stringify(this.roleMapping));
    // this.roleMappingResult();
    this.getFormSubmissionStatus();
    //this.GetArchiveDueDate();
    //debugger;
   
    this.GetExpectedDocumentationCompletionDate();
    this.archiveHomeService.SyncForm3283SStatus(this.archiveNumber);
    // var info = JSON.parse(localStorage.getItem('archiveInfoData'));
    // if (info) {}
    // console.log('infobarOninitarchiveInfoData',info); 
    this.archiveinfo = this.archiveinfoSvc.getArchiveInfo(this.archiveNumber, this.employeeUniqueIdentifier).subscribe(
      (info) => {
        //debugger;
        // localStorage.setItem('archiveInfoData', JSON.stringify(info));
        console.log('InfoBararchiveInfoData',info);
        this.archiveinfo = info
        this.estimatedate = info.estimatedReleaseDate.split("T")[0];
        this.Displaydate = {
          "year": parseInt(this.estimatedate.split("-")[0]),
          "month": parseInt(this.estimatedate.split("-")[1]),
          "day": parseInt(this.estimatedate.split("-")[2])
        }
        this.EstimatedDateEvent.emit({ Displaydate: this.Displaydate, estimatedate: this.estimatedate });
        this.wbsNumber = info.wbsNumber;
        this.archivestatus = info.archiveStatus;
        this.WBSNumberEvent.emit({ archiveNumber: this.archiveNumber, wbsNumber: this.wbsNumber, archiveStatus: this.archivestatus })
        this.engDescToolTip = this.archiveinfo.engagementDescription;
        if (this.archiveinfo.archiveStatus == 'Rejected') {
          this.infoStatus = true;
          this.IsReject = true;
        }
        if (this.archiveinfo.archiveStatus == 'Resubmitted - Rejected') {
          this.infoStatus = true;
          this.IsReject = true;
          this.IsArchiveResubmitted = true;
          this.ArchiveResubmissionType = info.resubmissionType;
        }
        if (this.archiveinfo.archiveStatus == 'Approved' || this.archiveinfo.archiveStatus == 'Resubmitted – Approved') {
          this.infoStatus = true;
          this.IsApproved = true;
          this.IsArchiveResubmitted = true;
        }
        if (this.archiveinfo.archiveStatus == 'Open' || this.archiveinfo.archiveStatus == 'Ready For Approval') {
          this.infoStatus = true;
          this.IsOpen = true;
        }
        if (this.archiveinfo.archiveStatus == 'Resubmitted – Open' || this.archiveinfo.archiveStatus == 'Resubmitted - Ready for Approval') {
          this.IsOpen = true;
          this.IsArchiveResubmitted = true;
          this.archiveHomeService.archiveSubstantiveStatus.subscribe(message => this.ArchiveResubmissionType = message);
          if (info.resubmissionType == 'Administrative') {
            this.ArchiveResubmissionType = info.resubmissionType;
          }
        }
        this.GetArchiveDueDate();
      }); 
  
      this.csoService.getArchiveCSODetails(this.archiveNumber,1, 10, '','',1,'').subscribe((data) => {
        this.archiveOverrideStatus = data[0].overrideStatus;
        debugger;
        localStorage.setItem('archiveOverrideStatus', JSON.stringify(this.archiveOverrideStatus));
        });

    //debugger;
    this.archiveHomeService.archiveSubmitStatus.subscribe(message => this.archiveinfo.archiveStatus = message);
    this.archiveService.archiveName.subscribe(message => this.archiveinfo.engagementDescription = message);
    this.archiveService.PeriodEndDate.subscribe(message => this.archiveinfo.periodEnd = message);
    this.archiveService.archiveDescription.subscribe(message => this.archiveinfo.archiveDescription = message);
    console.log("Archvie Info: " + this.archiveinfo.engagementDescription);
    console.log("archive number: " + this.archiveinfo.archiveNumber);
    console.log("archive Status: " + this.archiveinfo.archiveStatus);
  }

  
  GetArchiveDueDate() {
    this.archiveHomeService.GetArchiveDueDate(this.archiveNumber, this.employeeUniqueIdentifier).subscribe(
      data => {
        this.expecteddate = data.expectedDocumentationCompletionDate;
        this.archiveDueDateData = data;
        this.infoMsg = "Initial approval: " + moment(data.archiveApprovedDate).format("MM/DD/YYYY hh:mm A") + " " + data.officeZone;
        this.getApprovalDays();
      }
    );
  }


  getApprovalDays() {
    let currentDate: any = new Date();
    currentDate.setHours(0, 0, 0, 0);
    let dueDate: any = new Date(this.expecteddate);
    dueDate.setHours(0, 0, 0, 0);
    if (dueDate >= currentDate) {
      this.isDaysOverdue = false;
      this.diffDays = Math.ceil(Math.abs(dueDate - currentDate) / (1000 * 60 * 60 * 24)) + 1;
      if (this.diffDays > 30) {
        this.innerColor = "43B02A";
        this.outerColor = "43B02A";
      }
      else if (this.diffDays <= 30 && this.diffDays >= 16) {
        this.innerColor = "FFCD00";
        this.outerColor = "FFCD00";
      }
      else if (this.diffDays <= 15 && this.diffDays >= 5) {
        this.innerColor = "ED8B00";
        this.outerColor = "ED8B00";
      }
      else{
        this.innerColor = "DA291C";
        this.outerColor = "DA291C";
      }
    }
    else {
      this.isDaysOverdue = true;
      this.diffDays = Math.ceil(Math.abs(dueDate - currentDate) / (1000 * 60 * 60 * 24));
    }
    this.edcdDetails = [{
      days: this.diffDays,
      colorInner: this.innerColor,  // case statement to Change color as per the number of days
      colorOuter: this.outerColor,  // case statement to Change color as per the number of days
      date: this.expecteddate,
      time: "1:59",
      daysOverdue: this.isDaysOverdue,
      formStatus: this.FormStatus,
      adceddate : this.ADCEDDate,
      isArchiveApprove: this.IsApproved,
      archiveDueDateCriteria: this.archiveDueDateData.archiveDueDateCriteria,
      archiveDueDate: this.archiveDueDateData.archiveDueDate,
      deliverableType: this.archiveDueDateData.deliverableType,
      originalDate: this.archiveDueDateData.originalDate,
      archiveApprovedDate: this.archiveDueDateData.archiveApprovedDate,
      isArchiveResubmitted: this.IsArchiveResubmitted
    }];
  }

  GetExpectedDocumentationCompletionDate() {
        //debugger;
        this.EDCDSubscription = this.pubsub.getduedate().subscribe(
          message => {
            if (message.text == true) {
              //this.clearedcd();
              this.GetArchiveDueDate();
              this.archiveHomeService.SyncForm3283SStatus(this.archiveNumber);
            }
          }
        );
      } 
    
 



  redirectToCreatArchive() {
    this.router.navigate(["/record/workingpapers/AEA500269"]);
  }
  redirectToDeliverables() {
    console.log("redirectToDeliverables clicked");

    this.router.navigate(['/archive/myarchives/AEA500271/deliverables'])
  }
  goToEngagementPage(PageUrl) {
    this.router.navigate(["/" + PageUrl + "/"]);
  }
  // roleMappingResult() {
  //   this.archiveService.GetRoleMappingsForUser(this.employeeUniqueIdentifier, this.archiveNumber).subscribe(x => {
  //     // //debugger;
  //     if (x) {
  //       this.roleMapping.roleId = x.roleId;
  //       this.roleMapping.roleDescription = x.roleDescription;
  //       this.roleMapping.canSearchArchives = x.archivePermissions.includes('Search Archives');
  //       this.roleMapping.canAccessArchives = x.archivePermissions.includes('Access Archive');
  //       this.roleMapping.canCreateArchive = x.archivePermissions.includes('Manual Archive Creation');
  //       this.roleMapping.canManageArchiveInfo = x.archivePermissions.includes('Manage Archive Info');
  //       this.roleMapping.canManageAccess = x.archivePermissions.includes('Manage Access');
  //       this.roleMapping.canSubmit = x.archivePermissions.includes('Submission');
  //       this.roleMapping.canUpload = x.archivePermissions.includes('Upload Record');
  //       this.roleMapping.canDownload = x.archivePermissions.includes('Download Record');
  //       this.roleMapping.canDelete = x.archivePermissions.includes('Delete Record');
  //       this.roleMapping.canMarkAsInactive = x.archivePermissions.includes('Mark as Inactive');
  //       this.roleMapping.canManageERP = x.archivePermissions.includes('Manage ERP');
  //       this.roleMapping.canRequestRetentionException = x.archivePermissions.includes('Request Retention Exception');
  //       this.roleMapping.canRequestAccess = x.archivePermissions.includes('Request Access');
  //       this.roleMapping.canApproveTemporaryAccess = x.archivePermissions.includes('Approve Temporary Access');
  //       this.roleMapping.canViewArchiveHistory = x.archivePermissions.includes('View Archive History');
  //       this.roleMapping.canPrintBinderReportCovers = x.archivePermissions.includes('Print Binder & Report Covers');
  //       this.roleMapping.canRequestImage = x.archivePermissions.includes('Request Image');
  //       this.roleMapping.canLinkArchives = x.archivePermissions.includes('Archive Linking');
  //       this.roleMapping.canApprove = x.archivePermissions.includes('Approval');
  //       this.roleMapping.canResubmit = x.archivePermissions.includes('Resubmission (Substantive or Adminstrative)');
  //       // this.roleMapping.canResubmitAdminApproval = x.archivePermissions.includes('Resubmission (Substantive or Adminstrative)');
  //       this.roleMapping.canResubmitAdminApproval = x.archivePermissions.includes('Administrative Resubmission Approval');
  //       this.roleMapping.canRequestArchiveDeletion = x.archivePermissions.includes('Request Archive Deletion');
  //       this.roleMapping.canRequestForm3283S = x.archivePermissions.includes('Request Form 3283S');
  //       this.roleMapping.canApproveForm3283S = x.archivePermissions.includes('Approve Form 3283S');
  //       this.roleMapping.canRequestLegalHold = x.archivePermissions.includes('Request Legal Hold');
  //       this.roleMapping.canTempArchiveAccess = x.archivePermissions.includes('Temporary Archive Access');
  //       this.roleMapping.canViewSwiftEngagementDetails = x.archivePermissions.includes('View Swift EngagementDetails');
  //       this.roleMapping.canMarkRestrictedAccess = x.archivePermissions.includes('Mark with restricted access');
  //       this.roleMapping.canChangeEstimatedReleaseDate = x.archivePermissions.includes('Change Estimated Release Date');
  //     }
  //     console.log(this.roleMapping);
  //     this.ViewSwiftEngagementDetailsEvent.emit({
  //       canChangeEstimatedReleaseDate: this.roleMapping.canChangeEstimatedReleaseDate, canViewSwiftEngagementDetails: this.roleMapping.canViewSwiftEngagementDetails,
  //       canRequestLegalHold: this.roleMapping.canRequestLegalHold, canRequestArchiveDeletion: this.roleMapping.canRequestArchiveDeletion, canRequestForm3283S: this.roleMapping.canRequestForm3283S, canApproveForm3283S: this.roleMapping.canApproveForm3283S
  //     });
  //     // localStorage.setItem('roleMapping', JSON.stringify(this.roleMapping));
  //     this.pubsub.setRoleMappingResult(this.roleMapping);
  //   });
  // }
  SaveDate(event) {
    this.selectDate = event["selectDate"];
    this.archiveinfoSvc.updateEDCDDate(this.archiveNumber, this.selectDate).subscribe(
      (info) => {
        console.log("Success" + info);

      }
    );
    setTimeout(() => { this.updateedcd = true; this.sendArchiveDueDate(); }, 1000);
  }
  sendArchiveDueDate() {
    this.pubsub.sendduedate(this.updateedcd);
  }
}
