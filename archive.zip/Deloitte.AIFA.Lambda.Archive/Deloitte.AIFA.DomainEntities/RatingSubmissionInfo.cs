﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
    public class RatingSubmissionInfo
    {
        public int Rating { get; set; }

        public string Comment { get; set; }

        public string UserAlias { get; set; }

        public string Url { get; set; }
        public int ApplicationId { get; set; }
    }
}
