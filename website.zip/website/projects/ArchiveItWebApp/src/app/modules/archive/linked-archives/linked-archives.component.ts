import { Component, OnInit,Output, EventEmitter  } from '@angular/core';
import { Router, NavigationEnd, ActivatedRoute } from '@angular/router';
import { ArchiveService } from '../../../services/archive.service';
import { ModalService } from "../../shared/modal";
import { NotifierService } from 'angular-notifier';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { Observable, of } from 'rxjs';
import { SearchWbsService } from '../../../services/searchwbs.service';
import { PeoplePickerService } from '../../../services/MDREmployeeeDetails.service';
import { FormControl, FormGroup, FormBuilder, Validators, FormArray } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
import { LinkedArchivesService } from '../../../services/linked-archives.service';
import { HomePageService } from '../../../services/homepage.service';
import { UserConfigSettingService } from '../../../guards/user-role-guard.service';
import { SharedService } from '../../../services/shared.service';
import { ArchiveHomeService } from '../../../services/archive-home.service';
import { DeliverableService } from '../../../services/deliverable.service';
import { AngularEditorConfig } from '@kolkov/angular-editor';
import { PubsubService } from '../../../services/pubsub.service';
import { UserActions } from '../../../models/archive-role.model';

@Component({
  selector: 'app-linked-archives',
  templateUrl: './linked-archives.component.html',
  styleUrls: ['./linked-archives.component.css']
})

export class LinkedArchivesComponent implements OnInit {
  archiveNumber = "";
  linkedArchives: any = [];
  totalLinkedArchives: number = -1;
  readonly pageSize: number = 10;
  currentPageNumber: number = 1;
  appendArchiveToGrid: boolean = false;
  showMoreFlag: number = 1;
  rowIndex: number = -1;
  linkingtypes:any;
  LinkType: number;
  LinkTypeID:number;
  LinkTypeDescription:string;

  employeeUniqueIdentifier:any;
  UserName = this.adalSvc.LoggedInUserName;
  userEmail = this.adalSvc.LoggedInUserEmail;
  euserAlias = this.userEmail.replace("@deloitte.com", "");
  CreatedBy:any;


  sortByEnum : any = LinkedArchivesSortBy;
  columnByEnum: any = LinkedArchivesColumnBy;
  sortColumnDialog: number = -1;
  // sortBy: number = this.sortByEnum.SortBy_EmployeeLastArchive;
  sortBy: number = 11;
  columnToBeSorted:any;

  isApprover: boolean = false;
  CurrentArchiveStatusforLinkedArchives: any;
  ShowContentForLinkedArchives = 1;
  hideAddBotton = false;
  ApproveDisabled: boolean;
  RejectDisabled: boolean;
  LinkedArchivesEditedInResubmit: boolean;
  LinkedArchivesProvidedInResubmit: string;
  LinkedArchivesEditedDate:Date;
  IsSectionVisited: any;
  roleMapping = new UserActions();
  hideRejectedLabel: boolean = false;
  hidechangeDecision: boolean = true;
  hideRejectedMessage: boolean;
  rejectionDescription: any;
  rejectedBy: string;
  rejectedComments: any;
  originalComments: any;
  disabledColor: any;
  rejectDisabledColor: any;
  topCss: any;
  rejectedDate: Date;
  popUpHeaderText: string = "";
  BodyCount:number=250;
  isSectionApproved : boolean = false;
  linktypeDisabled: boolean = false;
  IsChangeDecissionClicked: boolean=false;

    //Substantive Resubmission
    ResubmissionReason: any = "";
    ResubmissionDeliverableActionType: any = "";
    IsEngagementDecisions: boolean = true;

     ArchiveNumber:any="";
     LinkedArchiveNumber:any="";
     EventlinkType:any="";

    //Substantive Resubmission

  @Output() sortOrderChangeEvent: EventEmitter<any> = new EventEmitter();

  workingPapersResultGridColumns: any =WorkingPapersResultGridColumns;
  readonly emptyStringInReport : string = " ";

  columnFilters: any[] =
  [
    {
      "displayName": "Archive #",
      "value": this.workingPapersResultGridColumns.ArchiveNumber,
      "checked": true
    },
    {
      "displayName": "Created In",
      "value": this.workingPapersResultGridColumns.CreatedIn,
      "checked": true
    },
    {
      "displayName": "Type",
      "value": this.workingPapersResultGridColumns.Type,
      "checked": true
    },
    {
      "displayName": "Reporting entity",
      "value": this.workingPapersResultGridColumns.ReportingEntity,
      "checked": true
    },
    {
      "displayName": "Archive description",
      "value": this.workingPapersResultGridColumns.ArchiveDescription,
      "checked": true
    },
    {
      "displayName": "Period end",
      "value": this.workingPapersResultGridColumns.PeriodEndDate,
      "checked": true
    },
    {
      "displayName": "EDCD",
      "value": this.workingPapersResultGridColumns.EDCD,
      "checked": true
    }
  ]

  // constructor
  constructor(  
    private SpinnerService: NgxSpinnerService,
    private linkedArchivesService: LinkedArchivesService,
    private activatedRoute: ActivatedRoute,
    private sharedService: SharedService,
    private adalSvc: MsAdalAngular6Service,
    private notifier: NotifierService,
    private archiveHomeService : ArchiveHomeService,
    private deliverableservice : DeliverableService,
    private pubsub: PubsubService,
    private modalService: ModalService,private router: Router
    
  ) {
    this.roleMapping = this.pubsub.getRoleMappingResult();
  }


  editorConfig: AngularEditorConfig = {

    editable: true,
    spellcheck: true,
    height: '276px',
    minHeight: '0',
    maxHeight: '100px',
    width: 'auto',
    minWidth: '0',
    translate: 'yes',
    enableToolbar: true,
    showToolbar: true,
    placeholder: 'Please enter the reason',
    defaultParagraphSeparator: '',
    defaultFontName: '',
    defaultFontSize: '',
    fonts: [
      { class: 'arial', name: 'Arial' },
      { class: 'times-new-roman', name: 'Times New Roman' },
      { class: 'calibri', name: 'Calibri' },
      { class: 'comic-sans-ms', name: 'Comic Sans MS' }
    ],

    customClasses: [
      {
        name: 'quote',
        class: 'quote',
      },
      {
        name: 'redText',
        class: 'redText'
      },
      {
        name: 'titleText',
        class: 'titleText',
        tag: 'h1',
      },
    ],
    uploadUrl: '',
    uploadWithCredentials: false,
    sanitize: true,
    toolbarPosition: 'top',
    toolbarHiddenButtons: [
      [
        'undo',
        'redo',
        'subscript',
        'superscript',
        'justifyFull',
        'indent',
        'outdent',
        'insertOrderedList',
        'heading',
        //'fontName'
      ],
      [
        'textColor',
        'backgroundColor',
        'customClasses',
        //'link',
        'unlink',
        'insertImage',
        'insertVideo',
        'insertHorizontalRule',
        'removeFormat',
        'toggleEditorMode'
      ]
    ]
  };



    ngOnInit() {
      var self = this;
      this.archiveNumber = this.activatedRoute.snapshot.parent.paramMap.get('aN');
      this.employeeUniqueIdentifier = this.adalSvc.LoggedInUserEmail.split('@')[0];
      this.CreatedBy = this.euserAlias;
      localStorage['IsSectionVisited'] = '0';
      console.log("LocalStorage ReSet to 0 in LA for AR (234):",localStorage['IsSectionVisited']);
      
      self.GetLinkedArchiveDetails(self.archiveNumber);
      self.GetLinkTypes();
      this.initialize();
      }
      ngDoCheck() {
        this.roleMapping = this.pubsub.getRoleMappingResult();
      }
      NavigateShowReasonsPopup() {
        this.router.navigate(["archive/myarchives/" + this.archiveNumber + '/archivehome'])
      }
      GetLinkTypes(){
        this.linkedArchivesService.getLinktypes().subscribe(
          data => {
              this.linkingtypes = data;
          },
          err => {
            console.log("error is ", err);
          }
        );
      }
      OnClick(PageUrl) {
        if(PageUrl.type != 'click')
        this.router.navigate(["/" + PageUrl + ""]);
      }

      initialize() {
        var self = this;
        this.hideRejectedLabel = true;
        this.hideRejectedMessage = true;
        this.hidechangeDecision = true;
        this.originalComments = undefined;
        this.IsUserApprover(this.archiveNumber, this.euserAlias)
        // this.Descriptiontextareacount = 180;
        this.CreatedBy = this.adalSvc.LoggedInUserEmail.split('@')[0];
      }

      selectedLinkType(event:any,archiveNumber:any,linkedArchive:any){
        this.LinkTypeID = event.target.value;
        this.LinkTypeDescription = event.target.options[event.target.selectedIndex].text;
        this.linkedArchivesService.UpdateLinkedArchiveDetails(archiveNumber,
          linkedArchive,this.CreatedBy,this.LinkTypeID,"Update").subscribe(
          data => {
            if (data==true) {
              this.notifier.notify("success", "Link type added successfully");
              this.ngOnInit();
            }
            else{
              this.notifier.notify("error", "Error while adding Link type.");
            }
          });
      }
      deleteLinkedArchive(archiveNumber:any,linkedArchive:any){
        this.linkedArchivesService.UpdateLinkedArchiveDetails(archiveNumber,
          linkedArchive,this.CreatedBy,0,"Delete").subscribe(
          data => {
            if (data==true) {
              this.notifier.notify("success", "Archive Link deleted successfully");
              this.ngOnInit();
            }
            else{
              this.notifier.notify("error", "Error while deleting archive link.");
            }
          });
      }
      closeModalDialog(Action) {
        this.modalService.close(Action);
        this.rejectedComments = this.rejectedComments;
      }
      ShowEditedReasonPop(ActionType,archiveNumber,linkedArchiveNumber,eventlinkType)
      { 
        // if(this.CurrentArchiveStatusforLinkedArchives=="Resubmitted – Open" || this.CurrentArchiveStatusforLinkedArchives=="Resubmitted - Ready for Approval")
        // {
         
        //   // Upon click on Save & State changes button from above popup below popup will be called
        //   if(ActionType==='Delete')
        //     {
        //     this.ArchiveNumber=archiveNumber;
        //     this.EventlinkType=eventlinkType;
        //     this.LinkedArchiveNumber=linkedArchiveNumber;
        //     this.deleteLinkedArchive(archiveNumber,linkedArchiveNumber);
           
        //     }

        //     else
        //     {
        //       this.selectedLinkType(this.EventlinkType,this.ArchiveNumber,this.LinkedArchiveNumber);

        //     }
           
        // }
        // else
        
         if(ActionType==='Delete')
        {
          this.deleteLinkedArchive(archiveNumber,linkedArchiveNumber);
        }
        else if(ActionType==='linktype'){
          this.selectedLinkType(eventlinkType,archiveNumber,linkedArchiveNumber);
        }
      }
    GetLinkedArchiveDetails(archiveNumber: string) {
      this.linkedArchivesService.getLinkedArchives(this.euserAlias,archiveNumber,this.currentPageNumber,this.pageSize,this.sortBy).subscribe(
        data => {
          debugger;
          
          if (this.appendArchiveToGrid && data) {
            this.linkedArchives = this.linkedArchives.concat(data);
          }
          else {
            this.linkedArchives = data ? data : [];
          }

          var copyLinkedArchives = this.linkedArchives;
          copyLinkedArchives.forEach(function(element,index){
            var curdate =new Date();
            var periodendDate = new Date(element.periodEndDate);
            copyLinkedArchives[index].isPeriodendCrossed=false;
            if(curdate > periodendDate)
            {
              var diffMonth = (curdate.getFullYear() - periodendDate.getFullYear())*12 + (curdate.getMonth() - periodendDate.getMonth())
              copyLinkedArchives[index].isPeriodendCrossed = diffMonth > 48 ? true: false;
              //copyLinkedArchives[index].isPeriodendCrossed = true;
            }
          });
            this.linkedArchives=copyLinkedArchives;
            console.log(this.linkedArchives);
            this.totalLinkedArchives = this.linkedArchives.length >0 ? this.linkedArchives[0].count:0;
            console.log("linked archives length" + this.totalLinkedArchives);
        },
        err => {
          console.log("error is ", err);
        }
      );
    }

    updateGridData(event) {
      this.appendArchiveToGrid = event.isLoadMoreClicked;
      this.currentPageNumber = event.pageNumber;
      this.GetLinkedArchiveDetails(this.archiveNumber);
    }

    showmoreToggle(action:number, index:number) {
      if(this.rowIndex == index)
      {
        this.rowIndex = -1;
      }
      else
      {
        this.rowIndex = index;
      }
    }


    redirectToAppropriatePage(archiveNumber:string){
      this.router.navigate(["/archive/myarchives/"+ archiveNumber]).then(() => {
             location.reload();
      });
    }

    generateReportClicked(data1)
    {
        let archiveForReport: any[] = [];
        let filterdColumns = (data1.filter(x => x.checked));
        this.archiveNumber = this.activatedRoute.snapshot.parent.paramMap.get('aN');
        
        this.linkedArchivesService.getLinkedArchives(this.euserAlias,this.archiveNumber,this.currentPageNumber,this.pageSize,this.sortBy).subscribe(
          data => {
            if (data.length > 0) {
              data.forEach(element => {
                let archive = {};
                filterdColumns.forEach(column => {
                  if (column["value"] == this.workingPapersResultGridColumns.ArchiveNumber) { //Archive#
                    archive[this.workingPapersResultGridColumns[this.workingPapersResultGridColumns.ArchiveFileId]] = element.linkedArchive || this.emptyStringInReport;
                  }
                  
                  if (column["value"] == this.workingPapersResultGridColumns.CreatedIn) { //Archive#
                    archive[this.workingPapersResultGridColumns[this.workingPapersResultGridColumns.CreatedIn]] = element.archiveNumber || this.emptyStringInReport;
                  }
      
                  if (column["value"] == this.workingPapersResultGridColumns.Type) { //Archive#
                    archive[this.workingPapersResultGridColumns[this.workingPapersResultGridColumns.Type]] = element.linkTypeDescription || this.emptyStringInReport;
                  }
      
                  if (column["value"] == this.workingPapersResultGridColumns.ReportingEntity) { //Archive#
                    archive[this.workingPapersResultGridColumns[this.workingPapersResultGridColumns.ReportingEntity]] = element.linkedArchiveName || this.emptyStringInReport;
                  }
                  
                  if (column["value"] == this.workingPapersResultGridColumns.ArchiveDescription) { //Archive#
                    archive[this.workingPapersResultGridColumns[this.workingPapersResultGridColumns.ArchiveDescription]] = element.archiveDescription || this.emptyStringInReport;
                  }
                  
                  if (column["value"] == this.workingPapersResultGridColumns.PeriodEndDate) { //Archive#
                    archive[this.workingPapersResultGridColumns[this.workingPapersResultGridColumns.PeriodEndDate]] = element.periodEndDate || this.emptyStringInReport;
                  }
                  
                  if (column["value"] == this.workingPapersResultGridColumns.EDCD) { //Archive#
                    archive[this.workingPapersResultGridColumns[this.workingPapersResultGridColumns.EDCD]] = element.expectedDocumentationCompletionDate || this.emptyStringInReport;
                  }
                              
                });
                archiveForReport.push(archive);
              });
              if (archiveForReport && archiveForReport.length) {
                // fileName: string, sheetName: string, columns: string[], data: any[]
                this.sharedService.generateExcel("LinkedArchivesFor"+this.archiveNumber, "linked-archives", filterdColumns.map(x => x.displayName), archiveForReport);
              }
            }
          });
      
      }

      sortOrderChanged(event) {
        this.sortBy = event;
        this.GetLinkedArchiveDetails(this.archiveNumber);
      }
      memberSortDialog(event) {
        if (this.sortColumnDialog == event) this.sortColumnDialog = -1;
        else this.sortColumnDialog = event;
      }
        //Method For Open and Resubmitted – Open
        commonViewForEdit() {
          debugger;
          this.ShowContentForLinkedArchives = 1;
          this.hideAddBotton = false;
          this.linktypeDisabled=false;
          //this.hideRefreshROIBotton = false;
        }
        specificViewToApprover() {
          this.ApproveDisabled = false;
          this.RejectDisabled = false;
          this.hideAddBotton = false;
          this.linktypeDisabled=false;
          //this.hideRefreshROIBotton = false;
        }
        commonViewForReadonly() {
          this.ShowContentForLinkedArchives = 0;
          //this.DisableSelectCheckboxes = true;
          this.hideAddBotton = true;
          this.linktypeDisabled=true;
          //this.hideRefreshROIBotton = true;
        }
        showModelDialog(Action) {
         if (Action === 'Rejected') {
            console.log("Rejection" + this.rejectedComments);
            this.popUpHeaderText = "Edit Rejection Reason";
            this.modalService.openWithCustomWidth("RejectedReasonPopup", "640");
          }
        }
        LinkedArchiveDetails(archivenumber: string) {
          this.disabledColor = {
            'background': '#007CB0'
          };
          this.archiveHomeService.Getsectioncomments(archivenumber, 4,2).subscribe(
         //this.deliverableservice.GetDeliverablesDetails(archivenumber).subscribe(
            (data) => {
              //if(this.CurrentArchiveStatusforDeliverables != "Resubmitted - Ready for Approval"){
              if (data.comments != "") {
                this.rejectedComments = data.comments;
                this.originalComments = data.comments;
                // this.BodyCount=250-data.comments.length;
                this.RejectDisabled = true;
                this.ApproveDisabled = true;
                this.rejectedBy = data.rejectedBy;
                this.rejectedDate = data.rejectedDate;
                this.hideRejectedLabel = false;
                this.hideRejectedMessage = false;
                if(this.isApprover){
                this.hidechangeDecision = false;
                }
                this.topCss = {
                  'top': '145px'
                };
              }
              else {
                this.topCss = {
                  'top': '0px'
                };
                if (data.isSectionApproved === 1) {
                  this.hideRejectedLabel = true;
                  this.hideRejectedMessage = true;
                  this.isSectionApproved = true;
                  if(this.isApprover){
                  this.hidechangeDecision = false;
                  }
                  this.RejectDisabled = true;
                  this.ApproveDisabled = true;
                }
                else{
                  this.isSectionApproved = false;
                }
              }
              //}
              if(this.CurrentArchiveStatusforLinkedArchives == "Approved" || this.CurrentArchiveStatusforLinkedArchives == "Resubmitted – Approved" || this.CurrentArchiveStatusforLinkedArchives == "Resubmitted - Rejected")
              {
                  this.hidechangeDecision = true;
              }
      
            });
      
          this.CreatedBy = this.euserAlias;
      
          //this.GetClientNameDetails(this.ArchiveNumber);
        }
        IsUserApprover(archivenumber, userlias) {
          this.deliverableservice.IsUserApprover(archivenumber, userlias).subscribe(
            (data) => {
              if (data != undefined) {
                this.isApprover = data.canApprove;
                console.log("Is Approver" , this.isApprover);
                this.CurrentArchiveStatusforLinkedArchives = data.archiveInfo.archiveStatus;
                //Added newly to diable editing the deiverable to archive team except for the archive approver
                //ShowContentForEditDeliverables will hide 
                //DisableSelectCheckboxes will disable the Select all & individual checkboxes for each deliverable added.
                this.HideorShowlogic();
      
              }
              setTimeout(() => { this.LinkedArchiveDetails(archivenumber)}, 1000);
            });
        }
        GetResubmissionApprovalFlow() {
          var inparameters = {
            "ArchiveNumber": this.archiveNumber,
            "UserAlias": ''
          }
          var parameters = JSON.stringify(inparameters);
          this.archiveHomeService.GetResubmissionApprovalFlowStatuses(parameters).subscribe(
            (obj) => {
              this.isApprover = obj[0].canApprove;
              if (obj[0].completedApprovel >= 1) {
                this.isApprover = false;
              }
              // else if (obj[0].completedApprovel == 0) {
              //   if (localStorage['isFirstLevelEdited'] == "null" || localStorage['isFirstLevelEdited'] == 0)
              //     this.isApprover = false;
              // }
              this.archiveHomeService.GetResubmissionReasonsforArchive(this.archiveNumber).subscribe(data => {
                if (data) {
                  if (data.length > 0) {
                    this.LinkedArchivesEditedInResubmit = data[3].actionTypeId == 3 ? true : false;
                    this.LinkedArchivesProvidedInResubmit = data[3].comments != "" ? data[3].comments : "";
                    this.LinkedArchivesEditedDate=data[3].rejectedDate;
                  }
                }
              });
              //Added from outside of the method to inside
              if (this.isApprover) {
                this.commonViewForEdit();
                this.specificViewToApprover();         
              }
              else {
                this.commonViewForReadonly();
              }
              // this.ShowContentForEditDeliverables = 1;
              // this.DisableSelectCheckboxes = false;
            },
            (err) => {
              console.log("error is ", err)
            }
          );
        }
      HideorShowlogic() {
        var archiveStatusHome: string = this.CurrentArchiveStatusforLinkedArchives;
        switch (archiveStatusHome) {
          case 'Ready For Approval': {
            this.archiveHomeService.GetArchiveApproverForArchiveSubmission(this.archiveNumber,this.roleMapping.roleId).subscribe(data =>
            {
                if(data){
                    console.log('GetArchiveApproverForArchiveSubmission-LinkedArchives',data.canApprove);
                    this.isApprover=data.canApprove;
                }
              if (this.isApprover) {
              this.commonViewForEdit();
              this.specificViewToApprover();
              }
              else {
              this.commonViewForReadonly();
              }
            });
            break;
          }
          case "Resubmitted - Ready for Approval": {
            this.GetResubmissionApprovalFlow();
    
            break;
          }
    
          /* common for Open, Resubmitted – Open*/
          case 'Open': {
            this.commonViewForEdit();
            break;
          }
          case "Resubmitted – Open": {
            this.commonViewForEdit();
            this.archiveHomeService.GetResubmissionReasonsforArchive(this.archiveNumber).subscribe(data=>
              { 
                if(data){
                 if(data.length>0)
                 {
                   debugger;
                  this.LinkedArchivesEditedInResubmit=data[3].actionTypeId==3?true:false;
                  this.LinkedArchivesProvidedInResubmit= data[3].comments!=""?data[3].comments:"";
                  this.LinkedArchivesEditedDate=data[3].rejectedDate;
                 }
                }
              });
            break;
          }
          /*End common for Open, Resubmitted – Open*/
    
          /*Common for Approved, Resubmitted – Approved and Resubmitted - Rejected */
          case "Approved": {
            this.commonViewForReadonly();
            break;
          }
          case "Resubmitted – Approved": {
            this.commonViewForReadonly();
            break;
          }
          case "Resubmitted - Rejected": {
            if(this.roleMapping.roleId==11 || this.roleMapping.roleId==12)
            {
              this.commonViewForReadonly();
            }
            else
            {
              this.commonViewForEdit();
            }
            break;
          }
          /*End Common for Approved, Resubmitted – Approved and Resubmitted - Rejected */
    
          case "Rejected":
            {
              this.commonViewForEdit();
              break;
            }
    
        }
    
    
      }

      AproveArchive(ActionType) {

        var parameters = {
          "ArchiveNumber": this.archiveNumber,
          "ArchiveSectionId": "4",
          "ActionTypeId": ActionType,
          "Comments": "",
          "CreatedBy": ''
        }
        this.deliverableservice.ApproveRejectDeliverable(parameters).subscribe(data => {
          if (data == "success") {
            if(!this.IsChangeDecissionClicked)
            {
            localStorage['IsSectionVisited'] = '1';
            console.log("LocalStorage Set to 1 in LA for aR (688):",localStorage['IsSectionVisited']);
            }
            if (ActionType != "3") {
                // setTimeout(() => { this.notifier.notify("success", "Approvel Successfull!!") }, 500);
                setTimeout(() => { this.router.navigate(["archive/myarchives/" + this.archiveNumber + '/archivehome']) }, 50);
              }
          }
        });
      }
    
      closeRejectModalDialog(Action) {
        this.rejectedComments = this.originalComments;
        // this.BodyCount = 250 - this.originalComments.length;
        this.modalService.close(Action);
      }
    
      closeRejectDialog(Action) {
        this.modalService.close(Action);
      }
    
      onchangeBody(e: any) {
        if (this.rejectedCommentsPlainText && this.rejectedCommentsPlainText.length >= 250) {
          if (!(e.ctrlKey && (e.keyCode >= 65 || e.keyCode <= 90)) && (e.keyCode > 47 || e.keyCode == 32 || e.keyCode == 9 || e.keyCode == 13)) {
            event.preventDefault();
          }
        }
      }
    
      get rejectedCommentsPlainText(): string {
        return this.rejectedComments ? this.stripHtml(this.rejectedComments) : null;
      }
      private stripHtml(html: string): string {
        var temporalDivElement = document.createElement("div");
        temporalDivElement.innerHTML = html;
        return temporalDivElement.textContent || temporalDivElement.innerText || "";
      }
    
      public onPaste(prevData: string, el): void {
        let clipboardData = el.clipboardData;
        let pastedText: string = clipboardData.getData('text');
        let PastedTextCount = this.stripHtml(pastedText.trim()).length;
        let prevDataCount = prevData ? this.stripHtml(prevData).length : 0;
        pastedText = pastedText.substring(0, 250 - prevDataCount);
        let concatedText = (prevData + pastedText)
        if (prevDataCount >= 250) el.preventDefault();
        else if ((prevDataCount + PastedTextCount) > 250) {
          el.preventDefault();
          this.rejectedComments = concatedText
        }
      }
      changedecisionbtnClick() {
        this.hideAddBotton = false;
        this.ApproveDisabled = false;
        this.RejectDisabled = false;
        this.IsChangeDecissionClicked=true;
        // this.disabledColor = {
        //   'background': '#007CB0'
        // };
      }
      SaveRejectLinkedArchives(ActionType) {
        var parameters = {
          "ArchiveNumber": this.archiveNumber,
          "ArchiveSectionId": "4",
          "ActionTypeId": ActionType,
          "Comments": this.rejectedComments,
          "CreatedBy": ''
        }
        this.deliverableservice.ApproveRejectDeliverable(parameters).subscribe(data => {
          if (data == "success") {
            this.originalComments = this.rejectedComments;
            if(!this.IsChangeDecissionClicked)
            {
            localStorage['IsSectionVisited'] = '1';
            console.log("LocalStorage Set to 1 in LA for aR (762):",localStorage['IsSectionVisited']);
            }
            setTimeout(() => { this.notifier.notify("success", "Comments Saved Succesfully!!") }, 500);
            setTimeout(() => { this.router.navigate(["archive/myarchives/" + this.archiveNumber + '/archivehome']) }, 5000);
          }
        });
      }
}

export enum WorkingPapersResultGridColumns
{
ArchiveNumber = 1, 
CreatedIn = 2, 
Type = 3, 
ReportingEntity = 4, 
ArchiveDescription = 5, 
PeriodEndDate = 6, 
EDCD = 7
}

export enum LinkedArchivesSortBy {
  SortBy_ArchiveNumber_Asc = 1,
  SortBy_ArchiveNumber_Desc = 2,
  SortBy_CreatedIn_Asc = 3,
  SortBy_CreatedIn_Desc = 4,
  SortBy_Type_Asc = 5,
  SortBy_Type_Desc = 6,
  SortBy_ReportingEntity_Asc = 7,
  SortBy_ReportingEntity_Desc = 8,
  SortBy_ArchiveDescription_Asc = 9,
  SortBy_ArchiveDescription_Desc = 10,
  SortBy_PeriodEndDate_Asc = 11,
  SortBy_PeriodEndDate_Desc = 12,
  SortBy_EDCD_Asc = 13,
  SortBy_EDCD_Desc = 14,
}

export enum LinkedArchivesColumnBy {
  ColumnBy_Default = -1,
  ColumnBy_ArchiveNumber = 1,
  ColumnBy_CreatedIn = 2,
  ColumnBy_Type = 3,
  ColumnBy_ReportingEntity = 4,
  ColumnBy_ArchiveDescription = 5,
  ColumnBy_PeriodEndDate = 6,
  ColumnBy_EDCD = 7,
}
