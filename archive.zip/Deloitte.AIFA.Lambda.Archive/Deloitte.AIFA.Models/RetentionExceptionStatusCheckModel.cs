﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DataModels
{
    public class RetentionExceptionStatusCheckModel
    {
        public string retentiondescription { get; set; }
        public string createdBy { get; set; }

    }
    public class EngagementRelatedPersonalStatusCheckModel
    {
        public string ERPCount { get; set; }
        public string createdBy { get; set; }
    }
}
