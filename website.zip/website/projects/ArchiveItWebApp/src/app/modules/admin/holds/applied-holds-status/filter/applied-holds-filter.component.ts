import { Component, OnInit, ViewChild, ElementRef, Input, Output, EventEmitter } from '@angular/core';


@Component({
  selector: 'app-applied-holds-filter',
  templateUrl: './applied-holds-filter.component.html',
  styleUrls: ['./applied-holds-filter.component.css']
})
export class AppliedHoldsFilterComponent implements OnInit {

 @Input() filterArray:Array<any> =[];
 @Output() CancelFilter = new EventEmitter<string>();
 @Output() applyFilter = new EventEmitter<any[]>();
 searchText:string ='';
 isSelectAll:boolean = true;
 @Input() isloader:boolean = true;
  constructor() {
   
   }

  ngOnInit() {
     
  }
  sortObj(val:string){

  }
  cancel(){
    this.CancelFilter.emit('cancel');
  }
  archiveChanged(checked:boolean){
    var check = this.filterArray.find(item => item.isSelected == false);    
      check ? this.isSelectAll = false : this.isSelectAll = true;   
  }
  apply(){
    var newValue = this.filterArray.filter(item => item.isSelected === true);
    this.applyFilter.emit(newValue);
  }

  selectAll(){
     if(this.isSelectAll){
      this.filterArray.map(obj => obj.isSelected = true );
     }else{
      this.filterArray.map(obj => obj.isSelected = false );
     }
  }
  
  
}
