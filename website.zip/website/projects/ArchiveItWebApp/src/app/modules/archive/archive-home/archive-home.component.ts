import { Component, OnInit, ViewEncapsulation, TemplateRef, AfterViewInit, OnDestroy } from '@angular/core';
import { Router, NavigationEnd, ActivatedRoute } from '@angular/router';
import { ModalService } from '../../shared/modal';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { PeoplePickerService } from '../../../services/MDREmployeeeDetails.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { archiveInfoService } from '../../../services/archiveinfo.service'
import { ArchiveHomeService } from '../../../services/archive-home.service';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { NotifierService } from 'angular-notifier';
import { RetentionexceptionService } from '../../../services/retentionexception.service';
import { NgbDateStruct } from "@ng-bootstrap/ng-bootstrap";
import { UserActions } from '../../../models/archive-role.model';
import { PubsubService } from '../../../services/pubsub.service';
import { EdcdModel } from '../../../models/edcd.model';
import { FileUploadEventService } from '../../record/file-upload/fileupload.event.service';
import { FielUploadService } from '../../../services/fileupload.service';
import { FileUploadProcessService } from '../../record/file-upload/fileupload.process.service';
import { WorkingPaperService } from '../../../services/working-paper.service';
import { DeliverableService } from '../../../services/deliverable.service';
import { distinctUntilChanged, debounceTime } from 'rxjs/operators';
import { BehaviorSubject } from 'rxjs';

@Component({
  selector: 'app-archive-home',
  templateUrl: './archive-home.component.html',
  styleUrls: ['./archive-home.component.css'],
  host: {
    "(document:click)": "OnClick($event)",
  },
})
export class ArchiveHomeComponent implements OnInit, AfterViewInit {
  canChangePPDNPPDReasons:boolean=true;
  isAgreeChecked:boolean=true;showAgreeBanner:boolean=false;
  MemofileId: any; MemofileName: any; Memofilesize: any; etagId: string; Message: string; filename: string;
  visible: boolean = false;
  a: any;
  downloadCard: boolean = true;
  unverifiedMemo: any = []; verifiedMemo: any = [];
  verificationInProgressStatus = [0, 1, 2, 5];
  ArchiveFileID: number = 0;
  module: string = "UploadMemo";
  archiveNumber: string;
  PPDUserName: string;
  NPPDUserName: string;
  toEDCDDate: string;
  EDCDDate: string;
  showUploadBtn:boolean = true;
  submit_form: FormGroup; submit_form1: FormGroup; submit_form2: FormGroup; submit_form3: FormGroup; submit_form4: FormGroup;
  submit_form5: FormGroup;
  users: Array<any> = [];
  selectedPPDUserDisplayName: string;
  selectedNPPDUserDisplayName: string;
  PPDUserAlias: string;
  NPPDUserAlias:string;
  selectedPPDUser: string;
  selectedNPPDUser: string;
  maxDate: Date;
  isEnableSubmit: boolean = false;
  ReadyToSubmit: boolean = false;
  ShowDatePicker: boolean = false;
  ShowDateField : boolean = false;
  ShowPeoplePicker: boolean = false;
  ShowDatePickerLabelMessage: boolean=false;
  isPPDUserSelected: boolean = false;
  isNPPDUserSelected: boolean = false;
  isFirstLevelEdited: boolean = false;
  canApprove: boolean = false;
  EstimatedDate: string;
  getcomments: any;
  sectionId: any;
  retentionExceptionStatus: string;
  selectDate: string;
  Displaydate: NgbDateStruct;
  estimatedate: any;
  ADExpandSection: boolean = true;
  ADCollapseSection: boolean;
  WPExpandSection: boolean = true;
  WPCollapseSection: boolean;
  DeliverablesExpandSection: boolean = true;
  DeliverablesCollapseSection: boolean;
  ERPExpandSection: boolean = true;
  ERPCollapseSection: boolean;
  showLinks: boolean = true;
  disableSubmitOnceSubmitted: boolean=false;
  // advanceFilter=true;
  labeltextfrom = "Change Estimated release date";
  archiveinfo: any;
  employeeUniqueIdentifier: string;
  userAlias = this.adalSvc.LoggedInUserEmail.substring(0, this.adalSvc.LoggedInUserEmail.lastIndexOf("@"));

  //userAlias='kallreddy';

  workingPaperStatus: any;
  displayworkingpaperbutton: boolean;
  deliverableStatus: any;
  displaydeliverablebutton: boolean;
  linkedArchiveStatus: any;
  displaylinkedArchivebutton: boolean;
  relatedArchiveStatus: any;
  binderStatus: any;
  isERPSectionVisitedinOpenBySubmitterVariable: any;
  initiateResubmissionParams: any;
  ppdnppdinfo: any;
  // VerificationInProgressStatusText: any = 'Verification in progress';
  isMemoverificationSuccess: boolean = true;

  //Declaring Individual Section Statuses//
  indArchiveDetailStatus: number = 9;
  indRetentionExpStatus: number = 9;
  indWorkingPapersStatus: number = 9;
  indDeliverableStatus: number = 9;
  indLinkedArchiveStatus: number = 9;
  indRelatedArchivesStatus: number = 9;
  indERPStatus: number = 9;
  indBinderStatus: number = 9;
  //End Individual Section Statuses//
  //Privacy Period//
  periodEnd: string = '';
  //End Privacy Period//

  dynamicTextForEditorApprove: string;
  archiveHomeLabel: string;

  archiveActionsForIndividualSections: any[];
  archiveActionsForIndividualSectionsForSubmitPopup: any[];
  apidata: any;
  ShowSubmitPopFlag: boolean;
  ShowResubmitButton: boolean = false;
  ShowSubmitButton: boolean = false;
  ShowApproveRejectButton: boolean = false;

  //Added for Resubmission Flow//
  Identifythesection: string;
  //Archive Details
  ArchiveDetailsEditedInResubmit: boolean = false;
  ADReasonsProvidedInResubmit: string;
  //End for Archive Details
  //ERP
  ERPMembersAddedInResubmit: boolean = false;
  ERPReasonsProvidedInResubmit: string = '';
  //End for ERP
  SubsorAdmn: boolean = false;
  substantive: boolean = false;
  administrative: boolean = false;
  wpAddedInResubmit: boolean = false;
  deliverablesAddedInResubmit: boolean = false;
  wpAddedInResubmitReason: string = '';
  deliverablesAddedInResubmitReason: string = '';
  linkedArchivesAddedInResubmit: boolean = false;
  linkedArchivesAddedInResubmitReason: string = '';
  ResubmissionReason: any = "";
  BodyCount: number = 250;
  TotalApprovalsRequired: number;
  TotalCompletedApprovals: number;
  //TotalApprovalsPending: number;
  PendingApprovalText: string = '';
  firstLvlApproverName: string;
  secondLvlApproverName: string;
  thirdLvlApproverName: string;
  resubmissionInProgess: number = 0;
  firstApprovalBar: number = 0;
  secondApprovalBar: number = 0;
  thirdApprovalBar: number = 0;
  resubmissionApproved: number = 0;
  //administrativeFirstLevelApprover:string='';
  PPDFirstName: string;
  PPDLastName: string;
  NPPDFirstName: string;
  ppdshow: boolean = false; nppdshow: boolean = false;
  NPPDLastName: string;
  ppdsaveresult: any;
  ResubmissionReasonsArrayforArchive: any;

  ResubmissionReasonTypes: any;
  ResubmissionReasonID: string;
  ResubmissionReasonValue: string;
  ResubmissionReasonProvided: string;
  ResubmissionReasonProvide: string;
  enabledResubmissionReasonTA: boolean = false;
  enableDefaultReasonSelection: boolean = true;
  ResubmissionReasonDescription: string;
  inputdataresubmissionreason: string;
  ShowRemove: boolean = true;

  //End of Added for Resubmission Flow//
  showROIUpdateAvailable: boolean = false;

  retentionexceptionedited: any;
  workingpapereditedby: any;
  deliverableeditedby: any;
  linkedArchiveeditedby: any;
  bindereditedby: any;
  archivelasteditedby: any;
  archiveFlowIndividualActions: any[];
  archivestatus: any;
  isArchiveDestroyed:number = 0;
  engagementrelatedcount: any;
  engagementrelatedmodifiedby: any;
  updateedcd: boolean;
  roleMapping = new UserActions();
  navigationSubscription;

  //New Varibles defined for centric
  privacyPeriodEndDate: Date;
  enableSubmit: boolean = false;
  archiveData: any;
  showonlyAdded: boolean = false;
  showBars: boolean = false;
  showPPDReasonMemo: boolean = false;
  showNPPD: boolean = false;
  approvalFlowObject: any;
  isPerecentageFilled: boolean = false;
  isApproveRejectLabel: boolean = false;
  showResubmissionApprovedBar: boolean = false;
  FlagFromSavePPDMethod:boolean=false;
  //firstLvlApproverText: string;
  submitterName: string;
  isQuestionMark: boolean = true;
  isPPDExists: boolean = false;
  isNPPDExists: boolean = false;
  isPPDPopulated: boolean = false;
  isNPPDpopulated: boolean = false;
  isResubmissionReasonPopulated: boolean = false;
  isMemoPopulated: boolean = false;  // It should be changed
  isCalledtwice: boolean = false;
  isFirstLevelPPD: boolean = false;
  isSecondLevelPPD: boolean = false;
  isThirdLevelPPD: boolean = false;
  isSecondLevelNPPD: boolean = false;
  isThirdLevelNPPD: boolean = false;
  levelCount: number = 0;
  isFromSavePPD: boolean = false;
  isFromSaveNPPD: boolean = false;
  AwaitingApprovalText: string;
  ArchiveRejectionComments: any = '';
  ArchiveRejectedBy: any = '';
  ArchiveRejectedDate: any;
  IsAwaitingOrPending: boolean = false;
  CanApproveatSecondorThrid: boolean = false;
  archiveHomeLabelHeader: string;
  visibleHeader: boolean = false;
  IsHideinfoIconstext: boolean = false;
  roleNameforinfo: string;
  IsUnauthorised: boolean = false;
  //Declaring Individual Section Awaiting Approval//
  ArchiveDetailawaitingApprval: number = 0;
  RetentionExpawaitingApprval: number = 0;
  WorkingPapersawaitingApprval: number = 0;
  DeliverableawaitingApprval: number = 0;
  RelatedArchivesawaitingApprval: number = 0;

  ERPawaitingApprval: number = 0;
  ispageloaded : boolean = false;
  //Declaring Individual Section Awaiting Approval//
  ppdCount;
  priorToCompletionCss: string;
  btnpriorToCompletion: any;
  rolecode: string;
  showMoreERPReason = false;
  showMoreADReason = false;
  showMoreWPReason = false;
  showMoreDelReason = false;
  showMoreLinkedReason = false;
  showOmniaTransferPending: boolean = false;
  omniaAssociatedData: any;
  firstLvlApproverRole: string;
  secondLvlApproverRole: string;
  thirdLvlApproverRole: string;
  isverificationsuccess: boolean = false;
  lastSearchKeyword: string = '';
  currentSearchKeyword: string = '';
  IsErrorReasonDescription:boolean = false;
  disableSubmitTooltip: string ='The Submit button will become enabled once each section below has been completed.';

  matRoiUpdates: number = 0;
  omniaTransferPending: boolean = false;
  linkedArchiveTileData:any;
  eRPTileData:any;
  testVariable:any;
  ArchiveButtontext : string = "Submit";

  private _subject: BehaviorSubject<string> = new BehaviorSubject<string>("");
  FileTransferIdOutVal: any;
  currentModule: any;
  memoFileVerificationStatusId: any;
  showverificationSuccessForMemoValidation: boolean = false;
  showverificationFailedForMemoValidation: boolean = false;
  showverificationInprogressForMemoValidation: boolean = false;
  memoFileVerificationStatusDesc: any;
  getUploadMemoData: any;
  fuparams: { ArchiveFileId: any; FileTransferId: any; FileUploadStatusCode: any; ETag: string; UploadId: any; FailedDescription: any; ArchiveNumber: string; };
  fileArrayObject: any;


  constructor(private archiveinfoSvc: archiveInfoService, private activatedRoute: ActivatedRoute, private router: Router, private pubsub: PubsubService,
    private modalService: ModalService, private peoplePickerService: PeoplePickerService, public fb: FormBuilder, private spinnerService: NgxSpinnerService, private archiveHomeService: ArchiveHomeService, private adalSvc: MsAdalAngular6Service, private notifier: NotifierService,
    private _fuEventService: FileUploadEventService, private _fuService: FielUploadService, private _wservice: WorkingPaperService, private deliverableservice: DeliverableService) {
      
      // activatedRoute.parent.params.subscribe(val => {
       //   //debugger;
      //   if(this.activatedRoute.snapshot.data.title == "Archive home"){}
     // });
  }


  ngOnInit() {
    //this.spinnerService.show();
    this.roleMapping = this.pubsub.getRoleMappingResult();
    this.archiveNumber = this.activatedRoute.snapshot.parent.paramMap.get('aN');
    this.employeeUniqueIdentifier = this.adalSvc.LoggedInUserEmail.split('@')[0];

    this.maxDate = new Date();
    let currentURL = this.router.url;
    let url = currentURL.split("/");
    this.archiveNumber = url[url.length - 2];
    this.submit_form = this.fb.group({
      'archivePPDUserName': [null, Validators.required],
      'EDCDDate': [null, Validators.required]
    });
    this.submit_form2 = this.fb.group({
      'archivePPDUserName': [null, Validators.required]
    });
    this.submit_form3 = this.fb.group({
      'archivePPDUserName': [null, Validators.required],
    });
    this.archiveHomeService.SyncForm3283SStatus(this.archiveNumber);
    /*commented as causing incorrect data on load */
/*
     this.archiveinfo = this.archiveinfoSvc.getArchiveInfo(this.archiveNumber, this.employeeUniqueIdentifier).subscribe(
      (info) => {
        localStorage.setItem('archiveInfoData', JSON.stringify(info));
        console.log('HomearchiveInfoData', info);
        localStorage['ApproverEdited'] = 0;
        this.archiveinfo = info
        this.archivestatus = info.archiveStatus;
      }
    );


    this.archiveinfo  = JSON.parse(localStorage.getItem('archiveInfoData'));
    console.log('infobarOninitarchiveInfoData',this.archiveinfo);
  if (this.archiveinfo) {
    console.log('HomearchiveInfoData', this.archiveinfo);
    localStorage['ApproverEdited'] = 0;
    // this.archiveinfo = this.archiveinfo
    this.archivestatus = this.archiveinfo.archiveStatus;

    }*/

    this.archiveinfo = this.archiveinfoSvc.getArchiveInfo(this.archiveNumber, this.employeeUniqueIdentifier).subscribe(
      (info) => {
        localStorage.setItem('archiveInfoData', JSON.stringify(info));
        console.log('HomearchiveInfoData', info);
        localStorage['ApproverEdited'] = 0;
        this.archiveinfo = info
        this.archivestatus = info.archiveStatus;
        this.isArchiveDestroyed = info.isDestroyed
        //debugger;
        
}
    );

   
   //New API 1 Sections individual actions
   this.archiveHomeService.GetArchiveActionsForIndividualSections(this.archiveNumber).subscribe(data => {
    if (data) {
       this.archiveFlowIndividualActions=data;     
    }
  });
   
   
    //New API 2 MAT ROI Updates API
    this.archiveHomeService.GetMatRoiUpdates(this.archiveNumber).subscribe(data => {
      if (data) {
        // this.matRoiUpdates=data.matRoiUpdates;          
         if (data.matRoiUpdates == 0) {
          this.showROIUpdateAvailable = false; // API 2
        }
        else {
          this.showROIUpdateAvailable = true; // API 2
        }
      }
    });

    
    //New API 3 Omnia updates
    this.archiveHomeService.GetOmniaUpdates(this.archiveNumber).subscribe(data => {
    if (data) {
       // this.omniaTransferPending=data.omniaTransferPending; 
        
        if (data.isAllowed == false) {
          this.showOmniaTransferPending = false; // API 3
        }
        else {
          this.showOmniaTransferPending = true;  // API 3
        }
    }
    });

     //New API 4 Linked Archive Tile Data
     this.archiveHomeService.GetLinkedArchivesTileData(this.archiveNumber).subscribe(data => {
      if (data) {
          this.linkedArchiveTileData=data;      
      }
      });


       //New API 5 ERP Tile Data
     this.archiveHomeService.GetERPTileData(this.archiveNumber).subscribe(data => {
      if (data) {
          this.eRPTileData=data;        
      }
      });

    this.archiveHomeService.GetArchiveStatus(this.archiveNumber, this.userAlias).subscribe(data => {

      if (data) {
        //debugger;
        this.ispageloaded = true;
        localStorage.setItem('archiveSubmissionStatusData', JSON.stringify(data));
        console.log('ArchiveHomeNgOnitarchiveSubmissionStatusData', data);
        //this.archiveActionsForIndividualSections = data.archiveAtcionsForIndividualSections; // Removed Completely
       // this.archiveFlowIndividualActions = data.archiveAtcionsForIndividualSections;  // API 1
        this.privacyPeriodEndDate = data.archiveInfo.privacyPeriodEndDate;  // Main API
        this.enableSubmit = data.readyToSubmit; // Main API


        console.log("Ready to submit value from DB 1", data.readyToSubmit);
        
        this.canApprove = data.canApprove;
        this.archivestatus = data.archiveInfo.archiveStatus;
        this.ShowPeoplePicker = data.showPeoplePicker;
        this.ShowDatePicker = data.showDatePicker;
        this.ShowDateField = data.showDatePicker;
        this.isverificationsuccess = data.isverificationsuccess
        this.archiveData = data;
        this.ReadyToSubmit = data.readyToSubmit;
        this.ShowSubmitButton = false;
        

     
      
      

        
        //Assigning Individual Section Statuses//
        this.HideorShowlogic();

        // if (!this.roleMapping.canSubmit) {
        //   console.log("Before Rolemapping", this.ReadyToSubmit);
        //   if (this.ReadyToSubmit) {
        //     this.ReadyToSubmit = false;
        //     console.log("After Rolemapping", this.ReadyToSubmit);

        //   }
        // }


       



        console.log('canapprove:' + data.canApprove);

        if (!(this.estimatedate == '' || this.estimatedate == undefined)) {
          this.Displaydate = {
            "year": parseInt(this.estimatedate.split("-")[0]),
            "month": parseInt(this.estimatedate.split("-")[1]),
            "day": parseInt(this.estimatedate.split("-")[2])
          }
        }
        this.omniaAssociatedData = data;

      }
     // this.spinnerService.hide(); // Required after load of ngonit
    });

 
     
    




    console.log("display date:" + this.Displaydate);
    console.log("Archive number:" + this.archiveNumber);

    //this.Displaydate="verify input"
    console.log("display date:" + this.Displaydate);
    console.log("Archive number:" + this.archiveNumber);

    //this.GetMemoByArchiveNumber(this.archiveNumber);

    //================================= Start: File Upload ===========================

    //FileUploadStep 12:
    //Update the uploaded status in DB and refresh the working papers list
    this.currentModule="UploadMemo";
    this._fuEventService.getfileUploadStatus.subscribe(fileArrayObject => {
      this.fileArrayObject = fileArrayObject;
      var self=this;
      if(fileArrayObject.module!=self.currentModule)
      return;
      if (fileArrayObject) {

        let etag = "";

        if (fileArrayObject.eTag) {
          etag = fileArrayObject.eTag.substr(1, fileArrayObject.eTag.length - 2);
        }


        let fuparams = {

          ArchiveFileId: fileArrayObject.metaData.ArchiveFileId,
          FileTransferId: fileArrayObject.metaData.FileTransferId,
          FileUploadStatusCode: fileArrayObject.uploadStatus,
          ETag: etag,
          UploadId: fileArrayObject.uploadId,
          FailedDescription: fileArrayObject.errorMessage,
          ArchiveNumber:this.archiveNumber
        };
        console.log("memo get" + this.ArchiveFileID);
        console.log("updating in DB");
        console.log(fuparams);
        this.fuparams = fuparams;
        this.createOrUpdateWorkingPaper(fuparams,fileArrayObject);
      }
    });
    // this.initialize();
    //this.spinnerService.hide();
  }
  createOrUpdateWorkingPaper(fuparams,fileArrayObject) {
    this._wservice.CreateOrUpdateWorkingPaper(fuparams).subscribe(response => {
      console.log("updated in DB");
      console.log(response);
    //  this.spinnerService.show();
      //Update the working papers upload files list on file upload success
      if (fileArrayObject.uploadStatus == "success") {
        debugger;
        this.archiveHomeService.GetUploadedMemo(this.archiveNumber).subscribe(data => {
          debugger;
          this.getUploadMemoData = data;
          if(data.length > 0) {
            this.getMemoFileStatus(data);
          } else {
            this.isMemoverificationSuccess = true;
          }
        if(this.memoFileVerificationStatusId == 6){
          this.notifier.notify('success', this.memoFileVerificationStatusDesc);
          this.GetUploadedMemo(this.archiveNumber);
         }
          if(this.memoFileVerificationStatusId !== 6 && this.memoFileVerificationStatusId !== 0  && this.memoFileVerificationStatusId !== 3) {
           this.notifier.notify('error', this.memoFileVerificationStatusDesc);
         }
          // this.filename = fileArrayObject.filename;
          if (this.verificationInProgressStatus.includes(data.fileVerificationStatusId)) {
            this.unverifiedMemo.unshift(data);
          }
          else {
            this.verifiedMemo.unshift(data);
          }
        },
          err => {
           // this.spinnerService.hide();
            console.log("failed to refresh Memo");
          }

        );
        this.router.navigate(['archive/myarchives/'+this.archiveNumber+'/archivehome']);
       // this.spinnerService.hide();
      }
     // this.spinnerService.show();
      if (this.Message !== undefined && this.Message !== "") {
        this.notifier.notify("success", this.Message);
        this.Message = "";
        this.GetUploadedMemo(this.archiveNumber);
      }
      //this.GetMemoByArchiveNumber(this.archiveNumber);
     // this.spinnerService.hide();
    },
      err => {
      //  this.spinnerService.hide();
        console.log("failed to update in Memo DB");
        console.log(err);
      });
  }
getMemoFileStatus(data) {
      this.memoFileVerificationStatusId = data[0].fileVerificationStatusID;
      this.memoFileVerificationStatusDesc = data[0].fileVerificationStatusDescription;
      this.filename = data[0].fileName;
      if(this.memoFileVerificationStatusId == 6){
        this.showverificationSuccessForMemoValidation = true;
        this.showverificationFailedForMemoValidation = false;
        this.showUploadBtn = false;
        this.isMemoverificationSuccess = true;
      } else if(this.memoFileVerificationStatusId == 3){
        this.isMemoverificationSuccess = false;
         this.showverificationInprogressForMemoValidation = true;
        this.showverificationSuccessForMemoValidation = false;
        this.showverificationFailedForMemoValidation = false;
        setTimeout(()=>{
          this.createOrUpdateWorkingPaper(this.fuparams,this.fileArrayObject);
        },20000);
        this.showUploadBtn = true;
      } else {
        this.isMemoverificationSuccess = false;
        this.showverificationFailedForMemoValidation = true;
        this.showverificationSuccessForMemoValidation = false;
        this.showUploadBtn = false;
      }
}
  ProvideReasonsButtonRefresh() {
    location.reload();
  }

  ShowSuccessToasterMessageforADPage() {
    setTimeout(() => this.notifier.notify('success', 'Archive Details Reasons saved succesfully'), 3000);
  }
  SavePPD() {
    this.PPDUserAlias=this.selectedPPDUser;
    
    if(this.archivestatus == "Resubmitted – Open")
    {
      this.FlagFromSavePPDMethod=true;
    }
    if(this.PPDUserAlias!='' && this.PPDUserAlias!=undefined && this.PPDUserAlias!=null)
    {
     if(this.PPDUserAlias == this.NPPDUserAlias )
      {
        this.notifier.notify("error", "Please enter different users for PPD and NPPD");
      }
       else
      {
        var PPDDetails = {
        "ArchiveNumber": this.archiveNumber,
        "CreatedBy": '',
        "PPDUserAlias": this.selectedPPDUser,
        "IsPPD": 1
      }
      var parameters = JSON.stringify(PPDDetails);
      //this.archiveHomeService.substantiveresubmissionEmployeeRolesCreate(this.archiveNumber,this.userAlias,this.selectedPPDUser,1).
      this.archiveHomeService.substantiveresubmissionEmployeeRolesCreate(parameters).
        subscribe(data => {
          if (data == "Success") {
            this.isFromSavePPD = true;
            this.isCalledtwice = true;
            this.GETPPDDEtails();
            setTimeout(() => this.notifier.notify('success', 'PPD Details saved successfully'), 3000);
          }
        },
          err => {
           // this.spinnerService.hide();
            this.notifier.notify("error", "Error occurred updating the PPD");
          });

        }
      }

  }

  SaveNPPD() {
  if(this.archivestatus == "Resubmitted – Open")
  {
      this.FlagFromSavePPDMethod=true;
  }
  this.NPPDUserAlias=this.selectedNPPDUser;
  
  if(this.PPDUserAlias== this.NPPDUserAlias)
  {
   this.notifier.notify("error", "Please enter different users for PPD and NPPD");
 }

else
{

    var PPDDetails = {
      "ArchiveNumber": this.archiveNumber,
      "CreatedBy": '',
      "PPDUserAlias": this.selectedNPPDUser,
      "IsPPD": 2
    }

    var parameters = JSON.stringify(PPDDetails);
    this.archiveHomeService.substantiveresubmissionEmployeeRolesCreate(parameters).
      subscribe(data => {
        if (data == "Success") {
          //this.ppdsaveresult=info[0];
          this.isFromSaveNPPD = true;
          this.isCalledtwice = true;
          this.GETPPDDEtails();
          setTimeout(() => this.notifier.notify('success', 'NPPD Details saved successfully'), 3000);
        }

      },
        err => {
         // this.spinnerService.hide();
          this.notifier.notify("error", "Error occurred updating the NPPD");
        });

      }

  }

  //Resubmission Reasons DropDown
  selectedResubmissionReason(event: any) {
    this.ResubmissionReasonID = event.target.value;
    this.ResubmissionReasonValue = event.target.options[event.target.selectedIndex].text;

    if (this.ResubmissionReasonValue == 'Other') {
      this.enabledResubmissionReasonTA = true;
      this.ResubmissionReasonDescription = "";
    }
    else {
      this.ResubmissionReasonDescription = undefined
      this.enabledResubmissionReasonTA = false;
    }
  }
  //End Resubmission Reasons DropDown
  //

  closeReasonsDialogandsave(Action) {

    if (this.ResubmissionReasonDescription != undefined) {
      if (this.ResubmissionReasonDescription.length != 0) {
        this.ResubmissionReasonValue = this.ResubmissionReasonDescription
      }
    }
    this.modalService.close(Action);
    this.SaveSubstantiation(this.ResubmissionReasonValue);
    this.enabledResubmissionReasonTA = false;
    this.ResubmissionReasonProvide = "change";
  }
  SaveSubstantiation(reason) {

    var parameter =
    {
      "ArchiveNumber": this.archiveNumber,
      "Comment": reason,
      "CreatedBy": '',
      "CommentCategoryId": 10,
    }
    var myobjstr = JSON.stringify(parameter);
    this.AddEditSubstantiation(reason, myobjstr)

  }

  AddEditSubstantiation(reason, myobjstr) {
    //this.spinnerService.show();
    this.deliverableservice.AddEditSubstantiation(myobjstr).subscribe(
      data => {
        if (data == true) {
          this.notifier.notify(
            "success",
            "Successfully added"
          );
          this.GetSubstantiation(this.archiveNumber, 10);
        }
        else {
          this.notifier.notify(
            "error",
            "Error occured"
          );
        }
       // this.spinnerService.hide();
      },
      err => {
        console.log("error is ", err);
      }
    );
  }

  //Submit2 Reasons
  GetSubstantiation(archiveNumber: string, commentCategoryId: number, showLoader?: boolean) {

    //this.spinnerService.show();
    if(showLoader == undefined){
      showLoader = true;
    }
    this.deliverableservice.GetSubstantiationByArchiveNumber(archiveNumber, commentCategoryId, showLoader).subscribe(
      data => {
        this.ResubmissionReasonProvided = data;
        if (this.ResubmissionReasonProvided != '' && this.ResubmissionReasonProvided != undefined) {
          this.enabledResubmissionReasonTA = false;
          this.enableDefaultReasonSelection = false;
          if (this.ResubmissionReasonProvided == "Addition of documentation – Omitted Procedures")
            this.inputdataresubmissionreason = "1"
          else if (this.ResubmissionReasonProvided == "Addition of documentation – Subsequently Discovered Facts")
            this.inputdataresubmissionreason = "2"
          else if (this.ResubmissionReasonProvided == "Addition of documentation – Inspection Memo")
            this.inputdataresubmissionreason = "3"
          else if (this.ResubmissionReasonProvided == "Addition of documentation – Restatement Memo")
            this.inputdataresubmissionreason = "4"
          else if (this.ResubmissionReasonProvided == "Addition of documentation - Omitted In Error From The Archive")
            this.inputdataresubmissionreason = "5"
          else {
            this.inputdataresubmissionreason = "6";
            this.enabledResubmissionReasonTA = true;
            this.ResubmissionReasonDescription = this.ResubmissionReasonProvided;
          }

          this.isResubmissionReasonPopulated = true;
          this.SubmitFinalView(2);

        }
        else {
          this.enableDefaultReasonSelection = true;
        }

       // this.spinnerService.hide();

      },
      err => {
        console.log("error is ", err);
      }
    );


  }


  //Need to update the archive status to Rejected in this call along with Rejected comments
  RejectArchive(reason, myobjstr) {
    this.deliverableservice.AddEditSubstantiation(myobjstr).subscribe(
      data => {
        if (data == true) {
          //this.onSubmitArchive();
          this.notifier.notify(
            "success",
            "Archive Rejected Successfully"
          );

          setTimeout(() => location.reload(), 3000);
        }
        else {
          this.notifier.notify(
            "error",
            "Error occured during rejection"
          );
          setTimeout(() => location.reload(), 3000);
        }
      },
      err => {
        console.log("error is ", err);
        setTimeout(() => location.reload(), 3000);
      }
    );
  }

  SaveArchiveRejectionReason(reason) {
    var parameter =
    {
      "ArchiveNumber": this.archiveNumber,
      "Comment": reason,
      "CreatedBy": '',
      "CommentCategoryId": 11,
    }
    var myobjstr = JSON.stringify(parameter);
    this.RejectArchive(reason, myobjstr)
    setTimeout(() => this.router.navigate(["/"]), 3000);
  }

  //
  //To load the bars, To show the Archive home  //123
  GetAdminstrativeSubstantiveViewWithBars() {

    //this.spinnerService.show();
    var inparameters = {
      "ArchiveNumber": this.archiveNumber,
      "UserAlias": ''
    }
    var parameters = JSON.stringify(inparameters);


    this.archiveHomeService.GetResubmissionApprovalFlowStatuses(parameters).subscribe(
      (obj) => {
        this.SubsorAdmn = true;
        this.approvalFlowObject = obj;
        this.showResubmissionApprovedBar = true;
        // It is for to show the number of Approvals dynamically in UI
        this.TotalApprovalsRequired = obj[0].totalLevelofApproval;
        // It is for handling bar percentage
        this.TotalCompletedApprovals = obj[0].completedApprovel;

        //Common
        if (obj[0].lstResubmissionApprover.length >= 1 && !this.IsHideinfoIconstext) {

          this.firstLvlApproverName = obj[0].lstResubmissionApprover[0].lastName + ", " + obj[0].lstResubmissionApprover[0].firstName;
          this.firstLvlApproverRole = this.GetRoleNameByID(obj[0].lstResubmissionApprover[0].roleID);
          if (this.firstLvlApproverName == ",") {
            this.firstLvlApproverName = "";
          }
          this.submitterName = obj[0].lstResubmissionApprover[obj[0].lstResubmissionApprover.length - 1].lastName + ", " + obj[0].lstResubmissionApprover[obj[0].lstResubmissionApprover.length - 1].firstName;
        }

        this.canApprove = obj[0].canApprove;

        //===========================Substantive=================================
        if (this.archiveinfo.resubmissionType == 'Substantive') {

          this.showPPDReasonMemo=true;
          //
          this.archiveHomeService.updateArchiveSubstantiation();


          // this.firstLvlApproverText = "1st lvl. approval in progress";



          // PPD and NPPD should be handled based on approvers
          if (obj[0].lstResubmissionApprover.length >= 3) // Need to remove submitter from the count
          {

            if (!this.IsHideinfoIconstext)  // It is not required for resubmit open case

            {
              this.secondLvlApproverName = obj[0].lstResubmissionApprover[1].lastName + ", " + obj[0].lstResubmissionApprover[1].firstName;
              this.secondLvlApproverRole = this.GetRoleNameByID(obj[0].lstResubmissionApprover[1].roleID);
              if (this.secondLvlApproverName.length <= 2) {
                this.secondLvlApproverName = "";
              }
            }


            obj[0].lstResubmissionApprover.forEach(element => {

              this.levelCount++;
              if (element.roleID == 11)  // PPD
              {
                this.showPPDReasonMemo = true;
                this.isPPDExists = true;
                if (this.levelCount == 1) {
                  this.isFirstLevelPPD = true;
                }
                else if (this.levelCount == 2) {
                  this.isSecondLevelPPD = true;
                }
                else if (this.levelCount == 3) {
                  this.isThirdLevelPPD = true;
                }
              }

              if (element.roleID == 12)  // NPPD
              {
                this.showNPPD = true
                this.isNPPDExists = true;

                if (this.levelCount == 2) {
                  this.isSecondLevelNPPD = true;
                }
                else if (this.levelCount == 3) {
                  this.isThirdLevelNPPD = true;
                }

              }



            });


          }
          if (obj[0].lstResubmissionApprover.length >= 4) {

            if (!this.IsHideinfoIconstext)  // It is not required for resubmit open case

            {

              this.thirdLvlApproverName = obj[0].lstResubmissionApprover[2].lastName + ", " + obj[0].lstResubmissionApprover[2].firstName;
              this.thirdLvlApproverRole = this.GetRoleNameByID(obj[0].lstResubmissionApprover[2].roleID);

              if (this.thirdLvlApproverName.length <= 2) {
                this.thirdLvlApproverName = "";
              }
            }

          }



          //Resubmit Open  or Resubmit Reject
          if (!this.isPerecentageFilled) {

            // Submit buttons handling
            this.ShowSubmitButton = true;
            this.ShowApproveRejectButton = false;
            this.ShowResubmitButton = false;
            console.log("Ready to Submit in RO and RR", this.ReadyToSubmit)
            this.ReadyToSubmit = true;

            //Loading Bars with percentage
            this.LoadBarsforResubmitOpenOrReject(0);
          }

          //Resubmit RFA
          else {

            //Substantive => 1st level Approval
            if (obj[0].completedApprovel == 0) {

              //Substantive => 1st level Approver view
              if (obj[0].canApprove == true) {

                //Substantive => 1st level Approver Edit view after clicking on link

                //Showing I agree only in 1st level for approver  Substantive
                  this.isAgreeChecked=false;
                  this.showAgreeBanner=true;
                
                this.ResubmitRFAFirstLevelApproverView(2);
                // }

              }  // Approver close

              //Substantive =>1st Level Reader Readonly View -- Submitter  (Substantive)
              else {
                this.ShowSubmitButton = false;
                this.PendingApprovalText = "";
                this.AwaitingApprovalText = "";
                this.showLinks = false;
                this.visible = true;
                this.archiveHomeLabel = "The archive has been submitted for approval. The Archive Partner will review the changes and the system will notify you as soon as it will be ready.";
                this.isQuestionMark = true;
                this.ShowRemove = false;
                this.IsUnauthorised = true;
              }

              this.LoadBarsforResubmitRFA(0);

            } //Substantive => 1st level Approval End


            //Substantive => 2nd level/3rd Level Approval -- Only for Substantive
            else if (obj[0].completedApprovel >= 1) {
              this.CanApproveatSecondorThrid = true;

              //Substantive =>2nd level/3rd Level Approver Edit View
              if (obj[0].canApprove == true) {
                this.ShowApproveRejectButton = true;
                this.ShowResubmitButton = false;
                this.ShowSubmitButton = false;
                this.showLinks = true; // Editable
                this.visible = true;
                this.archiveHomeLabel = "The Archive has been submitted for approval. Please review the changed section below and then select the “Approve” (or “Reject”)button to finish the review process."
                this.isQuestionMark = true;
              }



              // Substantive =>2nd level/3rd Level Readonly View
              else {
                this.ShowApproveRejectButton = false;
                this.ShowResubmitButton = false;
                this.ShowSubmitButton = false;
                this.showLinks = false; //
                this.visible = false;
                // this.nppdshow=false;
              }
              this.ShowRemove = false;
              this.LoadBarsforResubmitRFA(this.TotalCompletedApprovals);


            }  //Substantive => 2nd level/3rd Level End


            // It can be removed later by review
            else {
              this.ShowSubmitButton = false;
              this.showLinks = false;
            }



          }
          if(this.FlagFromSavePPDMethod==false){
          //To show the approvers PPD,NPPD,Reason Memo, and Upload Memo
          this.GETPPDDEtails();  // It Drives submit button , Just makes disable or enable
          debugger;
          this.GetUploadedMemo(this.archiveNumber);  // It drives submit button, Just makes disable
          this.ShowDownloadCard(this.downloadCard);
          this.GetResubmissionReason(); // It drives submit button
          }
          console.log('this.FlagFromSavePPDMethod before condition check',this.FlagFromSavePPDMethod);
          if(this.FlagFromSavePPDMethod==true)
          {
            console.log('this.FlagFromSavePPDMethod before condition',this.FlagFromSavePPDMethod);
            this.FlagFromSavePPDMethod=false;
            console.log('this.FlagFromSavePPDMethod before condition',this.FlagFromSavePPDMethod);
          }

          // Variables of above methods

          // filename  -- Memo
          // this.PPDFirstName = data[0].firstName;  -- PPD& NPPD Bar
          // this.PPDLastName = data[0].lastName; -- PPD& NPPD Bar
          // this.NPPDFirstName = data[1].firstName; -- PPD& NPPD Bar
          // this.NPPDLastName = data[1].lastName;  -- PPD& NPPD Bar
          //this.isPPDExists  -- From Approval flow
          // this.isNPPDExists  -- From Approval flow
          //this.ResubmissionReasonProvided  -- Resubmission reason for archive

        }   // Substantive closing

        //===========================Administrative=================================
        else {

          // this.firstLvlApproverText = "Approval in progress";
          this.showPPDReasonMemo = false;  // PPD, NPPD,Reason, Memo is false by always
          this.showNPPD = false; // PPD, NPPD,Reason, Memo is false by always

          //Administrative => Resubmit Open or Reject
          if (!this.isPerecentageFilled) {

            this.LoadBarsforResubmitOpenOrReject(0);
          }

          //Administrative => Resubmit RFA
          else {
            //Administrative => 1st level Approval
            if (obj[0].completedApprovel == 0) {

              //Administrative => 1st level Approval Approver view
              if (obj[0].canApprove == true) {

               
                //Showing I agree only in 1st level for approver  Administrative
                this.isAgreeChecked=false;
                this.showAgreeBanner=true;
                //Administrative => 1st level Approval Approver Edit view after clicking on link

                this.ResubmitRFAFirstLevelApproverView(1);;


              }

              //Administrative => 1st level Reader Readonly View
              else {
                this.ShowSubmitButton = false;
                this.PendingApprovalText = "";
                this.visible = true;
                this.archiveHomeLabel = "The archive has been submitted for approval. The Archive Partner will review the changes and the system will notify you as soon as it will be ready.";
                this.isQuestionMark = true;
                this.IsUnauthorised = true;
              }

              this.LoadBarsforResubmitRFA(0);

            }

          }
        }  // Admistrative end

               if(this.showResubmissionApprovedBar && this.TotalApprovalsRequired>=2){
                 this.disableSubmitTooltip ='The Submit button will become enabled once a PPD name has been provided, the substantive resubmission Reason has been selected, and the resubmission Memo has been uploaded.'
               }else{
                 this.disableSubmitTooltip = 'The Submit button will become enabled once each section below has been completed.'
               }
       // this.spinnerService.hide();
      });

   // this.spinnerService.hide();
  }


  //Submit1 PPD and NPPD details
  GETPPDDEtails() {
    this.archiveHomeService.Getsubstantiveresubmissionppdornppd(this.archiveNumber).subscribe(data => {
      
    //  this.spinnerService.show();
      this.ppdnppdinfo = data;

      if (data[0] != undefined && data[0] !== '' && data[0].roleID !== 0) {
        this.ppdshow = true
        this.PPDFirstName = data[0].firstName;
        this.PPDLastName = data[0].lastName;
        this.isPPDPopulated = true;

      }
      else {
        this.ppdshow = false;
        this.isPPDPopulated = false;
        // this.ReadyToSubmit=false;  // Makint submit button false as PPD is not given (Resubmit-Open, RFA 1st level)
      }
      if (data[1] != undefined && data[1] !== '' && data[1].roleID !== 0) {
        this.nppdshow = true;
        this.NPPDFirstName = data[1].firstName;
        this.NPPDLastName = data[1].lastName;
        this.isNPPDpopulated = true;

      }
      else {
        this.nppdshow = false;
        this.isNPPDpopulated = false;
      }
     // this.spinnerService.hide();
      //if(this.isCalledtwice)  // Shafi to remove this block after reviewing Save PPD API
      //{
      //this.GETPPDDEtails();
      //this.isCalledtwice=false;
      //}

      if (this.isFromSavePPD)
        this.PopulatePPDInfoIcon();

      if (this.isFromSaveNPPD)
        this.PopulateNPPDInfoIcon();
      // this.SubmitFinalView(2);
      this.SubmitFinalView(2);
      //setTimeout(() => this.SubmitFinalView(2), 3000);

    });

  }

  //Submit3
  GetUploadedMemo(archiveNumber: string) {
    debugger;
    this.archiveHomeService.GetUploadedMemo(this.archiveNumber).subscribe(data => {
      console.log("uploadmemo" + data);
      //this.spinnerService.show();
      if (data.length > 0) {
        this.getUploadMemoData = data;
        this.getMemoFileStatus(data);
        this.ArchiveFileID = data[0].archiveFileIdOut;
        this.MemofileName = data[0].s3FileNameOut;
        // this.filename = data[0].fileName;
        this.isMemoPopulated = true;

      }

      setTimeout(() => this.SubmitFinalView(2), 3000);

    },
      err => {
      //  this.spinnerService.hide();
        console.log("failed to get in Memo DB");
        console.log(err);
      });

    console.log("memo get" + this.ArchiveFileID);
   // this.spinnerService.hide();
  }

  formatDate(date) {
    var d = new Date(date),
      month = '' + (d.getMonth() + 1),
      day = '' + d.getDate(),
      year = d.getFullYear();

    if (month.length < 2)
      month = '0' + month;
    if (day.length < 2)
      day = '0' + day;

    return [year, month, day].join('-');
  }
  SaveDate(event) {
    this.selectDate = event["selectDate"];
    console.log("SelectedDate Archive Number: " + this.archiveNumber);
    console.log("SelectedDate:" + this.selectDate);
    this.archiveinfoSvc.updateEDCDDate(this.archiveNumber, this.selectDate).subscribe(
      (info) => {
        console.log("Success" + info);

      }
    );
    setTimeout(() => { this.updateedcd = true; this.sendArchiveDueDate(); }, 1000);
  }

  edceDetails: EdcdModel[] = [
    {
      days: 15,
      colorInner: "43B02A",  // case statement to Change color as per the number of days
      colorOuter: "43B02A",  // case statement to Change color as per the number of days
      date: "09/04/2020",
      time: "1:59",
      archiveDueDateCriteria: '',
      archiveDueDate: '',
      deliverableType: '',
      originalDate: ''
    }
  ];


  ngAfterViewInit() {

    /*  this.archiveHomeService.GetArchiveStatus(this.archiveNumber, this.userAlias).subscribe(data => {

        if (data) {
          localStorage.setItem('archiveSubmissionStatusData', JSON.stringify(data));
          console.log('ArchiveHomeAfterViewarchiveSubmissionStatusData',data);
          this.archiveActionsForIndividualSectionsForSubmitPopup = data.archiveAtcionsForIndividualSections;
          this.apidata = this.archiveActionsForIndividualSectionsForSubmitPopup.findIndex(x => x.archiveSectionId == 4)
          this.archiveActionsForIndividualSectionsForSubmitPopup.splice(this.apidata, 1);
          this.apidata = this.archiveActionsForIndividualSectionsForSubmitPopup.findIndex(x => x.archiveSectionId == 6)
          this.archiveActionsForIndividualSectionsForSubmitPopup.splice(this.apidata, 1);
          console.log('FilteredData', this.archiveActionsForIndividualSectionsForSubmitPopup);
          this.apidata = localStorage['IsSectionVisited'];
          if (this.archiveActionsForIndividualSectionsForSubmitPopup.find((x) => x.actionsTypeId == 0) == undefined && this.apidata == "1") {
            this.modalService.openWithCustomWidth('Archive-Submission-Modal', "500");
          }
          if (localStorage['IsSectionVisited'] == "1") {
            localStorage['IsSectionVisited'] = "0";
          }

        }
      });*/
    //This Method will be called to display the POP up on last section after all sections are approved/Rejected.
    //this.DataViewforSections();
  }



  OnClick(PageUrl) {
    if(PageUrl.type != 'click')
    this.router.navigate(["/" + PageUrl + ""]);
  }


  openReSubmitArchiveModal(modalType: string) {
    this.modalService.openWithCustomWidth(modalType, "600");
  }

  openSubmitArchiveModal(modalType: string) {
    this.isEnableSubmit = false;
    this.toEDCDDate = "";
    debugger;
    if (this.archivestatus == "Open" || this.archivestatus == "Rejected") {
      this.archiveHomeService.CheckInactiveAPSubmitter(this.archiveNumber, this.userAlias, 2).subscribe(data => {
        if (data) {
          this.ShowPeoplePicker = data.canApprove;
          console.log('AP is submitting the archive', data.canApprove);
          if(this.ShowPeoplePicker==true && this.ShowDatePicker==false)
          {
            this.ShowDatePickerLabelMessage=false;
            this.modalService.openWithCustomWidth(modalType, "600");
          }
          else if(this.ShowPeoplePicker==false && this.ShowDatePicker==true)
          {
            this.ShowDatePickerLabelMessage=true;
            this.modalService.openWithCustomWidth(modalType, "600");
          }
          else if(this.ShowPeoplePicker==true && this.ShowDatePicker==true){
            this.ShowDatePickerLabelMessage=true;
            this.modalService.openWithCustomWidth(modalType, "600");
          }
          else if(this.ShowPeoplePicker==false && this.ShowDatePicker==false)
          {
            this.ShowDatePickerLabelMessage=false;
            this.onSubmitArchive();
          }
        }
      });
    }
    else if(this.ShowDateField === true){
      this.closeModalDialog('Archive-Submission-Modal');
      this.modalService.openWithCustomWidth(modalType, "600");
    }
    else if (this.archivestatus == "Resubmitted – Open" || this.archivestatus == "Resubmitted - Rejected") {
     
      // Substantive always false
      if(this.archiveinfo.resubmissionType == 'Substantive')
      {
      this.ShowPeoplePicker=false;
      }
        
      
      if(this.ShowPeoplePicker==false && this.ShowDatePicker==false){
        this.onSubmitArchive();
      }
      else
      {
        this.modalService.openWithCustomWidth(modalType, "600");
      }
    }
    
    else {
      this.onSubmitArchive();
      //this.modalService.openWithCustomWidth("submit-confirmation-archive-modal", "600");
    }
    
  }
  closeModalDialog(Action) {
    if((Action=="Archive-Submission-Modal" && this.archivestatus=="Ready For Approval")||this.archivestatus == "Resubmitted - Ready for Approval" ){
      this.isAgreeChecked=false;
    }
    else{
      this.isAgreeChecked=true;
    }
    this.modalService.close(Action);
    this.cancelRetention();
  }



  ngDoCheck() {
    // this.roleMapping = JSON.parse(localStorage.getItem("roleMapping"));
    this.roleMapping = this.pubsub.getRoleMappingResult();
    this.validations();
  }

  validations() {
    let hasError = false;
    if (this.ShowDatePicker && this.ShowPeoplePicker)
      hasError = ((!this.toEDCDDate || this.toEDCDDate == "") || (!this.PPDUserName || this.PPDUserName == "" || !this.isPPDUserSelected));

    else if (this.ShowDatePicker)
      hasError = (!this.toEDCDDate || this.toEDCDDate == "");

    else if (this.ShowPeoplePicker)
      hasError = (!this.PPDUserName || this.PPDUserName == "" || !this.isPPDUserSelected);

    if (hasError) this.isEnableSubmit = false;
    else{
      this.isEnableSubmit = true;
    }
    // else {
    //   if (this.roleMapping) {
    //     if (this.roleMapping.canSubmit)
    //       this.isEnableSubmit = true;
    //     else
    //       this.isEnableSubmit = false;
    //   }
    // }
  }

  //For PeoplePicker
  onInputChanged(searchString: string, rolecode?: string) {
    this.users = [];
    this.isPPDUserSelected = false;
    this.rolecode = rolecode;
    this.currentSearchKeyword = searchString;
    this._subject.next(this.currentSearchKeyword ? this.currentSearchKeyword.trim() : "");

    if (searchString.length >= 3) {
      this._subject.pipe(
        distinctUntilChanged(),
        debounceTime(500),
      ).subscribe(value => this.getPeople(value))
    }
    else {
      this.users = [];
      this.lastSearchKeyword = '';
    }

  }
  getPeople(searchString: string) {
    if (searchString.length >= 3 && this.lastSearchKeyword != searchString) {
      this.lastSearchKeyword = searchString;
      this.peoplePickerService.GetPeople(searchString).subscribe(
        (value) => {
          this.users = [];
          value.forEach(element => {
            if (this.currentSearchKeyword.length >= 3) {
              // if (element.isPPD)
              this.users = value;
            } else {
              this.users = [];
              this.lastSearchKeyword = '';
            }
          });
        },
        (err) => {
          console.log("error is ", err)
        }
      );
      this.spinnerService.hide();
    }
  }

  selectedPPDUserName(partner, index, Identifytheuser:string) {
    debugger;
    if(Identifytheuser=='PPD')
    {
      this.selectedPPDUserDisplayName = partner.source.viewValue;
      this.selectedPPDUser = this.users[index].userAlias;
      this.isPPDUserSelected = true;
    }
    else if(Identifytheuser=='NPPD'){
      this.selectedNPPDUserDisplayName = partner.source.viewValue;
      this.selectedNPPDUser = this.users[index].userAlias;
      this.isNPPDUserSelected = true;
    }
  }



  onDateChange(val:any) {
    this.EDCDDate = val.year+'/'+val.month+'/'+val.day;
    this.toEDCDDate = val.year+'/'+val.month+'/'+val.day;
    console.log(this.EDCDDate);
  }
  cancelRetention() {
    this.submit_form.get('archivePPDUserName').reset();
    this.submit_form.get('EDCDDate').reset();
    this.isPPDUserSelected = false;
    //this.goToArchiveHomePage();
  }

  sendArchiveDueDate() {
    this.pubsub.sendduedate(this.updateedcd);
  }


  SaveEngagementCeasedDate() {
    var parameters = {
      "ArchiveNumber": this.archiveNumber,
      "EarlyTerminationDate": this.EDCDDate != undefined && this.EDCDDate != null ? new Date(this.EDCDDate).toLocaleDateString() : this.EDCDDate,
      "EarlyTerminated": false,
      "ModifiedBy": ''
    }
    if (this.EDCDDate != undefined && this.EDCDDate != null && this.EDCDDate != '') {
      this.deliverableservice.SaveEngagementCeasedDate(parameters).subscribe((result) => {
        if (result != null && result != undefined) {
          //this.updateedcd = true;
          //this.GetEnagementCeasedDate();
          //this.sendArchiveDueDate();
        }
      },
        (err) => {
          console.log("error", "Exception while saving Engagement Ceased Date", err)
        });
    }
   // this.spinnerService.hide();
  }
  onSubmitArchive() {

    var parameters = {
      "ArchiveNumber": this.archiveNumber,
      "PPDUserAlias": this.selectedPPDUser,
      "EstimatedDate": this.EDCDDate != '' && this.EDCDDate != undefined && this.EDCDDate != null ? new Date(this.EDCDDate).toLocaleDateString() : this.EDCDDate,
      "CreatedBy": '',
      "RoleID": this.roleMapping.roleId
    }
    var submitArchiveObj = JSON.stringify(parameters);
    //this.spinnerService.show();

    if (this.archivestatus == "Resubmitted – Open" || (this.substantive = true && this.archivestatus == "Resubmitted - Ready for Approval") || (this.archivestatus == "Resubmitted - Rejected")) {

      this.disableSubmitOnceSubmitted= true;

      var inparameters = {
        "ArchiveNumber": this.archiveNumber,
        "UserAlias": '',
        "RoleID": this.roleMapping.roleId
      }

      this.closeModalDialog('Archive-Submission-Modal');
      var submitParameters = JSON.stringify(inparameters);
      this.archiveHomeService.InsertResubmissionApproverFlow(submitParameters).subscribe(data => {
        if (data.archiveStatus == "Resubmitted - Ready for Approval" && data.message=="Success") {
          this.notifier.notify('success', 'Archive is successfully resubmitted and is ready for approval.');
          setTimeout(() => this.router.navigate(["/"]), 6000);
        }
        else if(data.archiveStatus == "Resubmitted – Approved" && data.message=="Success")
        {
          this.notifier.notify('success', 'Archive is successfully approved.');
          setTimeout(() => this.router.navigate(["/"]), 3000);
        }
        else if(data.archiveStatus == "Resubmitted - Rejected" && data.message=="Success")
        {
          this.notifier.notify('success', 'Archive is successfully Rejected.');
          setTimeout(() => this.router.navigate(["/"]), 3000);
        }
        else{
          setTimeout(() => this.router.navigate(["/"]), 3000);
        }

      });

      //  setTimeout(() => this.router.navigate(["/"]), 3000);

    }
    else {
      if (this.archivestatus == "Open" || this.archivestatus == "Rejected") {

        this.archiveHomeService.InsertUpdateArchiveSubmitter(this.archiveNumber, this.userAlias).subscribe(data => {
          if (data) {
            console.log('Success-Update the submitter with high role');
          }
        });
      }
      this.archiveHomeService.OnArchiveSubmit(submitArchiveObj).subscribe(data => {
        this.updateedcd = true;
        this.sendArchiveDueDate();
        this.archiveHomeService.updateArchiveStatus(data.archiveStatus);
       // this.spinnerService.hide();
        // Need to show the corresponding message as per the action


        if (data.archiveStatus == 'Approved') {
          this.notifier.notify('success', 'You successfully approved the archive.');

        }

        else if (data.archiveStatus == 'Rejected') {
          this.notifier.notify('success', 'You successfully rejected the archive.');
          setTimeout(() => this.router.navigate(["/"]), 3000);
        }

        else {
          this.notifier.notify('success', 'Your archive is successfully submitted and is ready for approval.');
        }

        if (data)
        //Removing the timeout as its causing PE issue.
        //  setTimeout(() => this.router.navigate(["/"]), 3000);
        this.router.navigate(["/"]);
      });

    }
  }

  goToArchiveHomePage() {
    this.router.navigate(["/archive/myarchives/" + this.archiveNumber + "/archivehome"]);
  }

  // temporaryArchiveStatus(){
  //   this.archivestatus = "Resumbitted Open";
  // }
  onResumbitArchive() {
    var parameters = {
      "ArchiveNumber": this.archiveNumber,
      "RoleID": this.roleMapping.roleId
    }
    var ResubmitArchiveObj = JSON.stringify(parameters);
   // this.spinnerService.show();
    this.archiveHomeService.ArchiveResubmitInitiate(ResubmitArchiveObj).subscribe(data => {
      if (data == "Success") {
        console.log("Successfully initiated Archive Resubmission" + data);
        this.archiveHomeService.updateArchiveStatus("Resubmitted – Open");
      //  this.spinnerService.hide();
        //setTimeout(() => { this.router.navigate(["archive/myarchives/" + this.archiveNumber + '/archivehome']) }, 1000);
        this.notifier.notify('success', 'Archive Resubmission Initiated');
        setTimeout(() => location.reload(), 3000);
      }
    },
      err => {
      //  this.spinnerService.hide();
        this.notifier.notify("error", "Error occurred while resubmitting the archive");
      }

    );

   // this.spinnerService.hide();
    this.ShowResubmitButton = false;
    this.ShowSubmitButton = true;
    //Commenting this 2 line codes as these are getting reloaded even though the status is not updated in DB
    //this.archiveHomeService.updateArchiveStatus("Resubmitted – Open");
    //setTimeout(() => location.reload(), 3000);

    //location.reload();
    //this.router.navigate(["/archive/myarchives/" + this.archiveNumber]);

  }
  //Reason for Resubmit Individual Sections

  SaveReasonsinArchiveHome() {
    //this.spinnerService.show();
    var reasonparameters =
    {
      "ArchiveNumber": this.archiveNumber,
      "Comment": this.ResubmissionReason,
      "CreatedBy": '',
      "CommentCategoryId": this.Identifythesection,
    }
    this.archiveHomeService.SavereasonsForArchiveDetails(reasonparameters).subscribe(data => {
      if (data == false) {
        this.notifier.notify("error", "Reasons are not saved successfully");
      }
      else {
        console.log("Engagement personnel Reasons are saved successfully");
      }
    })
   // this.spinnerService.hide();
  }
  //End Reason for Resubmit Individual Sections
  //Provide PPD name
  openPPDArchiveModal(modalType: string) {
    this.modalService.openWithCustomWidth(modalType, "600");
  }
  openNPPDArchiveModal(modalType: string) {
    this.modalService.openWithCustomWidth(modalType, "600");
  }

  //end Provide PPD Name
  //Upload Memo
  openMemoArchiveModal(modalType: string) {
    this.modalService.openWithCustomWidth(modalType, "1100");
  }
  //END Upload Memo
  //Reason
  openReasonArchiveModal(modalType: string) {
    this.modalService.openWithCustomWidth(modalType, "600");
    this.GetSubstantiation(this.archiveNumber, 10);
  }
  //End Reason
  //Upload Memo
  openRemoveMemo(modalType: string) {
    this.modalService.openWithCustomWidth(modalType, "480");
  }

  //End Upload Memo

  browseFileDialogClick(filetype: string) {
    var self = this;
   
        var fileElem = document.createElement('input');
        var fileIndex = self._fuEventService.fileIndex++;

        if (filetype === 'Memo') {
          self.MemofileId = 'fileId-' + fileIndex;
          fileElem.setAttribute("id", self.MemofileId);
        }

        fileElem.setAttribute("type", "file");
        //fileElem.setAttribute("accept", this.acceptedMIMETypes);
        document.getElementById("div_fileupload").appendChild(fileElem);

        fileElem.click();
        fileElem.onchange = function (e: any) {

          var file = e.target.files[0];
          if (file.name) {
            if (filetype === 'Memo') {
              self.MemofileName = file.name;
              self.Memofilesize = file.size;
            }
          }

          if(self.MemofileName!=undefined)
          { 
             setTimeout(() => { self.notifier.notify("success", "Memo upload initiated") }, 2000); 
             setTimeout(() => { self.UploadMemotoS3bucket()}, 5000);    
          }    
          else{
               setTimeout(() => { self.notifier.notify("error", "Error in Memo Upload") }, 2000); 
           }
        }
        this.etagId = this.MemofileId;      

  }

  UploadMemotoS3bucket() {
    this.isMemoverificationSuccess = false;
    //this.spinnerService.show();
      var inparameters = {
      "FileName": this.MemofileName
      , "FileSize": this.Memofilesize
      , "ArchiveNumber": this.archiveNumber
      , "CreatedBy": ''
      , "ETag": 0
      , "FileTypeID": 4

    }
    var parameters = JSON.stringify(inparameters);
    this.archiveHomeService.CreateOrUpdateMemo(parameters).subscribe((result) => {
      let c = result["archiveFileIdOut"];
      this.MemofileName = result["s3FileNameOut"];
      this.FileTransferIdOutVal = result["fileTransferIdOut"];
      this.ArchiveFileID = c;
     // this.spinnerService.hide();

      if (this.ArchiveFileID !== null && this.ArchiveFileID != undefined && this.ArchiveFileID !== 0) {
        if (this.ArchiveFileID === -2) {
          this.notifier.notify("error", "File Already Exists!!");
        }
        else if (this.ArchiveFileID === -1) {
          this.notifier.notify("error", "Error in Memo Upload -Please contact adminstrator !!");
        }
        else {
          setTimeout(() => { this.triggerFileUploadProcess(this.ArchiveFileID, this.MemofileId, this.MemofileName, this.Memofilesize, this.FileTransferIdOutVal) }, 0);
          this.isMemoPopulated = true;
          this.SubmitFinalView(2);
          this.Message="Memo was Uploaded Succesfully";
          this.notifier.notify("success", this.Message);
          this.Message="";
        }
      }
    }
      ,
      err => {
       // this.spinnerService.hide();
        this.notifier.notify("error", "failed to upload Memo");
      }
    );
  }

  triggerFileUploadProcess(archiveFileId: any, fileid: any, fileName: any, fileSize: any, fileTransferIdVal: any) {

    var self = this;
    self._fuEventService.fileArray.push({
      module: self.module,
      fileId: fileid,
      fileName: fileName,
      fileSize: fileSize,
      eTag: "",
      uploadId: "",
      uploadPercentage: "",
      uploadStatus: "add",
      uploadMessage: "",
      errorMessage: "",
      uploadRemaingTime: "",
      sunits: "",
      tunits: "",
      metaData: {}
    });

    var metaData = {
      ArchiveFileId: archiveFileId.toString(),
      FileTransferId: fileTransferIdVal.toString()
    }

    var s3FileName = fileName;

    var fileUploadProcessService = new FileUploadProcessService(
      self._fuService,
      self._fuEventService,
      self.spinnerService,
      fileid,
      s3FileName,
      metaData
    );
    var fileElement = document.getElementById(fileid);
    fileUploadProcessService.uploadFile(fileElement);
    this.filename = fileName;
  }

  downloadFile(ArchiveFileId, fileName: string) {
    if (!fileName && !ArchiveFileId) return false;
    var metaData = {};
    var fileUploadProcessService = new FileUploadProcessService(
      this._fuService,
      this._fuEventService,
      this.spinnerService,
      null,
      null,
      metaData
    );
    var s3fileName = fileName;
    fileUploadProcessService.downloadFile(s3fileName, this.filename);
  }

  ShowDownloadCard(value) {
    if (value == false)
      this.downloadCard = true;
    else
      this.downloadCard = false;
  }

  RemoveMemo(archiveFileId: string) {
    debugger;
    this.archiveHomeService.DeleteUploadedMemo(archiveFileId, this.userAlias, this.archiveNumber).subscribe(data => {
      var SucessInfo = data;
      if (SucessInfo = "Success") {
        this.notifier.notify("success", "Memo was Deleted Succesfully");       
      }
   });

  }

  Dismiss(action) {
    this.visible = action;
  }

  deleteFile() {
    var self = this;

    if (!this.filename) return false;

    //this.spinnerService.show();

    var s3FileName = this.filename;

    var deleteRequest = {
      "ArchiveNumber":this.archiveNumber,
      "FileName": s3FileName,
      "ArchiveFileId": this.ArchiveFileID,
      "ModifiedBy": ''
    }
        this.archiveHomeService.DeleteFile(deleteRequest).subscribe(
      res => {

        if (res == true) {
          self.verifiedMemo = self.verifiedMemo.filter(x => x.archiveFileId !== self.ArchiveFileID);
          self.notifier.notify(
            "success",
            self.filename + " successfully deleted"
          );
          this.ArchiveFileID = 0;
          this.isMemoPopulated = false;
          this.SubmitFinalView(2);
          
          // self.closeDeletePopUp();
          //self.goToArchiveHomePage();        
          this.downloadCard=false;
          this.showUploadBtn = true;
           this.GetUploadedMemo(this.archiveNumber);
        }
      //  self.spinnerService.hide();
      },
      err => {
       // self.spinnerService.hide();
        //self.closeDeletePopUp();
        self.notifier.notify(
          "error",
          self.filename + " deletion failed"
        );
      }
    );

  }


  ExpandCollapseSection(action, sectionuniqueid) {
    if (sectionuniqueid == 1) {
      if (action == 'less') {
        this.ADExpandSection = true;
        this.ADCollapseSection = false;
      }
      else if (action == 'more') {
        this.ADCollapseSection = true;
        this.ADExpandSection = false;
      }
    }
    else if (sectionuniqueid == 2) {
      if (action == 'less') {
        this.WPExpandSection = true;
        this.WPCollapseSection = false;
      }
      else if (action == 'more') {
        this.WPCollapseSection = true;
        this.WPExpandSection = false;
      }
    }
    else if (sectionuniqueid == 3) {
      if (action == 'less') {
        this.DeliverablesExpandSection = true;
        this.DeliverablesCollapseSection = false;
      }
      else if (action == 'more') {
        this.DeliverablesCollapseSection = true;
        this.DeliverablesExpandSection = false;
      }
    }
    else if (sectionuniqueid == 5) {
      if (action == 'less') {
        this.ERPExpandSection = true;
        this.ERPCollapseSection = false;
      }
      else if (action == 'more') {
        this.ERPCollapseSection = true;
        this.ERPExpandSection = false;
      }
    }

  }
  PendingapprovalClick() {
    var parameters = {
      "ArchiveNumber": this.archiveNumber,
      "UserAlias": this.userAlias
    }
    var pendingApprovalObj = JSON.stringify(parameters);
    this.archiveHomeService.PendingapprovalClick(pendingApprovalObj).subscribe(data => {
      console.log("Pending Approval Clicked");
      this.PendingApprovalText = "";
      // localStorage['isFirstLevelEdited']=1;

      if (this.archiveinfo.resubmissionType == 'Substantive') {

        this.ResubmitRFAFirstLevelApproverView(2);
      }

      else {
        this.ResubmitRFAFirstLevelApproverView(1);
      }
      // this.ShowSubmitButton = true;
    });

  }


  HideorShowlogic() {
debugger;
    //All will be false by default. Will show the right one after validation
    this.ShowSubmitButton = false;
    this.ShowApproveRejectButton = false;
    this.ShowResubmitButton = false;
    this.visible = false;  // Archive home label
   
    //this.spinnerService.show();this.ArchiveStatus
    var archiveStatusHome: string = this.archivestatus;
      this.ArchiveButtontext = "Submit";
if( (archiveStatusHome=== 'Ready For Approval') || (archiveStatusHome ==='Resubmitted - Ready for Approval' )){
  debugger;
  this.archiveFlowIndividualActions.forEach(element => {
       if (element.actionsTypeId===2){
        this.ArchiveButtontext = "Reject";
       }
       else if(this.ArchiveButtontext !== "Reject"){
        this.ArchiveButtontext = "Approve";
       }
  });
}
  // for(var i = 0; i > this.archiveFlowIndividualActions.length;i++){
  //       if(this.archiveFlowIndividualActions[i].actionsTypeId===2){
  //         this.ArchiveButtontext = "Reject";
  //       }
  //       else{
  //         this.ArchiveButtontext = "Approve";
  //       }
  //     }
  //   }
    switch (archiveStatusHome) {

      /* ====== Edit mode for Archive team All the times ======*/
      /* common for Open, Resubmitted – Open*/
      case 'Open': {  //@1
        
        this.OpenView();
        break;
      }
      case "Resubmitted – Open": { //@2
        this.ResubmitOpenView();

        //Archive home label
        this.visible = false;
        //this.archiveHomeLabel="As soon as the Archive team will complete each section, the archive should be submitted and it will be ready for approval process.";
        // this.isQuestionMark=true;
        break;

      }


      case "Rejected":
        {
          this.RejectedView();

          break;
        }

      case "Resubmitted - Rejected": {
        this.ResubmitRejectedView();
        break;
      }

      /*End common for Rejected, Resubmitted – Rejected*/

      /* ====== Edit mode for Archive team All the times ======*/

      case 'Ready For Approval': {
        debugger;
        this.archiveHomeService.GetArchiveApproverForArchiveSubmission(this.archiveNumber, this.roleMapping.roleId).subscribe(data => {
          if (data) {
            console.log('GetArchiveApproverForArchiveSubmission', data.canApprove);
            this.canApprove = data.canApprove;
          }
          if (this.canApprove) {
            this.RfaApproverView();
          }
          else {
            this.canChangePPDNPPDReasons=false;
            this.RfaReadonlyView();
          }
        },
          err => {
           // this.spinnerService.hide();
            console.log("GetArchiveApproverForArchiveSubmission-failed to get Approver");
            console.log(err);
          });
      //  this.spinnerService.hide();
        break;
      }
      case "Resubmitted - Ready for Approval": {

        this.ResubmitRfaView();   // Readonly and editable can't be decided here.


        break;
      }



      /*Common for Approved, Resubmitted – Approved */
      case "Approved": {
        this.ApprovedView();
        break;
      }
      case "Resubmitted – Approved": {
        this.ResubmitApprovedView();
        break;
      }

      /*End Common for Approved, Resubmitted – Approved and Resubmitted - Rejected */

    }

    if (this.matRoiUpdates > 0) {
      if (this.ReadyToSubmit) {
        console.log("Beore MAT", this.ReadyToSubmit);
        this.ReadyToSubmit = false;
        console.log("After MAT", this.ReadyToSubmit);
      }
    }
    //this.spinnerService.hide();

  }

  //Status Views.

  // Open
  OpenView() {

    this.isERPSectionVisitedinOpenBySubmitterVariable = localStorage['isERPSectionVisitedinOpenBySubmitter'];


    //To show approve/Reject/Awaiting approval labels
    this.isApproveRejectLabel = false;
    this.DataViewforSections();
    // Submit buttons handling. By default submit will be enabled till all the sections are vistited
    this.ShowSubmitButton = true;
    //this.ReadyToSubmit = this.enableSubmit; // Coming value from DB
    this.ShowApproveRejectButton = false;
    this.ShowResubmitButton = false;


    //this.ReadyToSubmit It will be true after covering all sections except ERP
    //this.isERPSectionVisitedinOpenBySubmitterVariable => It is for to know whether they visited ERP or not
    if (this.isERPSectionVisitedinOpenBySubmitterVariable == "1" && this.enableSubmit) {

      console.log("ERP Visited");
      this.ReadyToSubmit = true;
    }

    else {
      console.log("ERP Not Visited");
      this.ReadyToSubmit = false;
    }


    if (this.ReadyToSubmit == true) {
      this.archiveHomeService.CheckInactiveAPSubmitter(this.archiveNumber, this.userAlias, 1).subscribe(data => {
        if (data) {
          this.ReadyToSubmit = data.canApprove;
          console.log('Check if AP is InActive', this.ReadyToSubmit);
        }
      });
    }



    //Archive home label
    this.visible = true;
    this.archiveHomeLabel = "Complete each section below and then select the Submit button to submit the archive for approval.";
    this.isQuestionMark = false;
    // Enabling submit once after visiting all the actions

  }


  //Resubmitted-Open
  ResubmitOpenView() {

    this.GetStateReasonsAndPopulate();

    //To show approve/Reject/Awaiting approval labels
    this.isApproveRejectLabel = false;

    //To load Approval flow bars, PPDNPPD Bar
    this.isPerecentageFilled = false;
    this.IsHideinfoIconstext = false; // If we want to hide name of approver in the progress bar in resubmission open state make it as true
    this.GetAdminstrativeSubstantiveViewWithBars();

    // Submit buttons handling
    this.ShowSubmitButton = true;
    this.ShowApproveRejectButton = false;
    this.ShowResubmitButton = false;
    //this.ShowPeoplePicker = false;

    //Archive home label
    this.visible = false;
    this.archiveHomeLabel = "";

    if (this.archiveinfo.resubmissionType == 'Substantive') {
      this.SubmitFinalView(2);

    }

    else {
      this.SubmitFinalView(1);
    }


  }

  //Rejected
  RejectedView() {
    //To show approve/Reject/Awaiting approval labels
    this.isApproveRejectLabel = true;

    //To show approve/Reject/Awaiting approval labels
    this.isApproveRejectLabel = true;
    this.DataViewforSections();

    this.visible = true;
    this.visibleHeader = true;
    this.archiveHomeLabelHeader = "This archive has been rejected and sent back for edits";
    this.archiveHomeLabel = "Please review the rejection reasons on sections marked orange below, make the requested changes and then press the “Submit” button to finish.";
    this.isQuestionMark = true;

    // Submit buttons handling
    this.ShowSubmitButton = true;
    this.ReadyToSubmit = true;
    this.ShowApproveRejectButton = false;
    this.ShowResubmitButton = false;
    this.ShowPeoplePicker = false;

  }

  //Resubmit Rejected
  ResubmitRejectedView() {

    // To show the state reasons in section tiles
    this.GetStateReasonsAndPopulate();

    //To show approve/Reject/Awaiting approval labels
    this.isApproveRejectLabel = true;

    this.isPerecentageFilled = false;
    this.GetAdminstrativeSubstantiveViewWithBars();

    // Submit buttons handling
    if(this.roleMapping.roleId==11 || this.roleMapping.roleId==12)
    {
      this.ShowSubmitButton = false;
    }
    else
    {
      this.ShowSubmitButton = true;
    }
    this.ShowApproveRejectButton = false;
    this.ShowResubmitButton = false;
    this.ShowPeoplePicker = false;

    //Archive home label
    this.visible = true;
    this.visibleHeader = true;
    this.archiveHomeLabelHeader = "This archive has been rejected and sent back for edits";
    this.archiveHomeLabel = "Please review the rejection reasons on sections marked orange below, make the requested changes and then press the “Submit” button to finish.";
    this.isQuestionMark = true;

    // Rejected comments of Archive
    this.GetArchiveRejectioncomments();



  }

  //Ready for Approval approver view
  RfaApproverView() {
    //To show approve/Reject/Awaiting approval labels
    this.isApproveRejectLabel = true;

    this.RFASubmitpopupandToaster();
    this.DataViewforSections();
    // Submit buttons handling
    this.ShowSubmitButton = true;
    this.ReadyToSubmit = this.enableSubmit; // Coming from DB
    this.ShowApproveRejectButton = false;
    this.ShowResubmitButton = false;
    this.ShowPeoplePicker = false;
    this.ShowDatePicker = false;

    // Showing I agree to approver
    this.isAgreeChecked=false;
    this.showAgreeBanner=true;

    //Archive home labels
    this.visible = true;
    this.visibleHeader = true;
    this.PendingApprovalText = "";
    this.archiveHomeLabelHeader = "This archive has been submitted and is ready for approval.";
    this.archiveHomeLabel = "Please click on each section below to review and approve (or reject) and then select the “Submit” button to finish."
    this.isQuestionMark = true;
  }

  //Ready for Approval Readonly view
  RfaReadonlyView() {

    //To show approve/Reject/Awaiting approval labels
    this.isApproveRejectLabel = false;

    this.DataViewforSections();
    // Submit buttons handling
    this.ShowSubmitButton = true;
    this.ReadyToSubmit = false;
    this.ShowApproveRejectButton = false;
    this.ShowResubmitButton = false;

    //Archive home labels
    this.visible = true;
    this.archiveHomeLabel = "This archive has been submitted and is ready for approval.";

  }

  //Ready for Approval approver view
  ResubmitRfaView() {
    //To show the state reasons in section tiles
    this.GetStateReasonsAndPopulate();

    //To show approve/Reject/Awaiting approval labels
    this.isApproveRejectLabel = true;
    this.ShowPeoplePicker = false;
    this.ShowDatePicker = false;
    this.isPerecentageFilled = true;  //Remove. It looks like it is not required. Review and remove it
    this.GetAdminstrativeSubstantiveViewWithBars();


  }


  //Approved view
  ApprovedView() {
    //To show approve/Reject/Awaiting approval labels
    this.isApproveRejectLabel = false;

    this.DataViewforSections();
    // Submit buttons handling
    this.ShowSubmitButton = false;
    this.ReadyToSubmit = false;
    this.ShowApproveRejectButton = false;
    this.ShowResubmitButton = true;


    //These should false for not getting any popup while clicking on Resubmit button
    this.ShowDatePicker = false;
    this.ShowPeoplePicker = false;

    //Privacy Period
    let now = new Date();
    let nowdate = this.formatDate(now);
    let privacyPeriodEndDate = this.formatDate(this.privacyPeriodEndDate);
    debugger;
    if (privacyPeriodEndDate < nowdate && !(this.privacyPeriodEndDate.toString() == "0001-01-01T00:00:00")) {

      // this.visible = true;
      // this.archiveHomeLabel = "Privacy period started";
      // this.isQuestionMark = true;
      this.periodEnd = "Privacy period started";
    }


  }

  //Resubmit Approved View
  ResubmitApprovedView() {

    //To show approve/Reject/Awaiting approval labels
    this.isApproveRejectLabel = false;


    this.DataViewforSections();
    this.ShowSubmitButton = false;
    this.ReadyToSubmit = true;
    console.log("Resubmit approved", this.ReadyToSubmit);
    this.ShowApproveRejectButton = false;
    this.ShowResubmitButton = false;


    // Showing the normal Approval view by disabling the resubmission sections v
    this.ArchiveDetailsEditedInResubmit = false;
    this.wpAddedInResubmit = false;
    this.deliverablesAddedInResubmit = false;
    this.linkedArchivesAddedInResubmit = false;
    this.ERPMembersAddedInResubmit = false;
    this.ShowSubmitButton = false;
    this.ShowResubmitButton = true;


  }





  //Common view for sections data
  DataViewforSections() {
    this.showonlyAdded = true;
    this.workingPaperStatus = this.archiveData.workingPaperStatus.wkpdescription;
    this.workingpapereditedby = this.archiveData.workingPaperStatus.createdBy;
    this.deliverableStatus = this.archiveData.deliverableStatus.deliverabledescription;

    // Binding Linked Archives tile data
    if(this.linkedArchiveTileData != undefined)
    {
    this.linkedArchiveStatus = this.linkedArchiveTileData.ladescription; //New API 4
    this.linkedArchiveeditedby = this.linkedArchiveTileData.createdBy; //New API 4
    }
    else{
      this.archiveHomeService.GetLinkedArchivesTileData(this.archiveNumber).subscribe(data => {
        if (data) {
            this.linkedArchiveTileData=data;  
            this.linkedArchiveStatus = this.linkedArchiveTileData.ladescription; //New API 4
            this.linkedArchiveeditedby = this.linkedArchiveTileData.createdBy; //New API 4      
        }
        });
    }
    this.binderStatus = this.archiveData.binderStatus.bindescription;
    this.bindereditedby = this.archiveData.binderStatus.createdBy;
    if (this.deliverableStatus == "No deliverables-No Ceased Date") {
   //   this.ShowDatePicker = true;
      this.deliverableStatus = "No deliverables";
    }
    
    this.deliverableeditedby = this.archiveData.deliverableStatus.createdBy;

    //Binding ERP Tile data
    if(this.eRPTileData != undefined)
    {
    this.engagementrelatedcount = this.eRPTileData.erpCount;  //New API 5
    this.engagementrelatedmodifiedby = this.eRPTileData.createdBy; // New API 5
    }
    else{
      this.archiveHomeService.GetERPTileData(this.archiveNumber).subscribe(data => {
        if (data) {
            this.eRPTileData=data;   
            this.engagementrelatedcount = this.eRPTileData.erpCount;  //New API 5
            this.engagementrelatedmodifiedby = this.eRPTileData.createdBy; // New API 5      
        }
        });
    }
    //this.relatedArchiveStatus = this.archiveData.relatedArchiveStatus;
    this.archivelasteditedby = this.archiveData.archiveInfo.lastModifiedBy;
    this.estimatedate = this.archiveData.archiveInfo.estimatedReleaseDate.split("T")[0];

    if (this.isApproveRejectLabel) {

      if(this.archiveFlowIndividualActions!= undefined)
      {
        this.BindSectionsTileData();
     
      }


    else
    {
      this.archiveHomeService.GetArchiveActionsForIndividualSections(this.archiveNumber).subscribe(data => {
        if (data) {
           this.archiveFlowIndividualActions=data;
           this.BindSectionsTileData();     
        }
      });

    }


    }

    else {
      this.indArchiveDetailStatus = 9;
      this.indRetentionExpStatus = 9;
      this.indWorkingPapersStatus = 9;
      this.indDeliverableStatus = 9;
      this.indLinkedArchiveStatus = 9;
      this.indRelatedArchivesStatus = 9;
      this.indERPStatus = 9;
      this.indBinderStatus = 9;
    }


  }

  BindSectionsTileData()
  {
    this.archiveFlowIndividualActions.forEach(element => {

      // 1	Engagement Details
      // 2	Working Papers
      // 3	Deliverables
      // 4	Linked Archives
      // 5	Engagement Related Personnel
      // 6	Retention Exception
      // 7  Binders

      

  

      // Archive details
      if (element.archiveSectionId == 1) {
        localStorage['indArchiveDetailStatus']=element.actionsTypeId;
        this.indArchiveDetailStatus = element.actionsTypeId;
      }

      //Working papers
      else if (element.archiveSectionId == 2) {
        this.indWorkingPapersStatus = element.actionsTypeId;
      }
      //Deliverables
      else if (element.archiveSectionId == 3) {
        this.indDeliverableStatus = element.actionsTypeId;
      }
      //Linked Archives
      else if (element.archiveSectionId == 4) {
        this.indLinkedArchiveStatus = element.actionsTypeId;
      }
      //ERP details
      else if (element.archiveSectionId == 5) {
        this.indERPStatus = element.actionsTypeId;
      }
      //Binders
      else if (element.archiveSectionId == 7) {
        this.indBinderStatus = element.actionsTypeId;
      }


    });
  }


  // Edited reasons
  GetStateReasonsAndPopulate() {
    this.archiveHomeService.GetResubmissionReasonsforArchive(this.archiveNumber).subscribe(data => {

      if (data) {
        if (data.length > 0) {
          this.ResubmissionReasonsArrayforArchive = data;
          // 1	Engagement Details
          // 2	Working Papers
          // 3	Deliverables
          // 4	Linked Archives
          // 5	Engagement Related Personnel
          // 6	Retention Exception
          // 7  Binders

          data.forEach(element => {
            // Archive details
            if (element.archiveSectionId == 1) {
              this.ArchiveDetailsEditedInResubmit = element.actionTypeId == 3 ? true : false;
              this.ADReasonsProvidedInResubmit = element.comments != "" ? element.comments : "";
            }

            //Working papers
            else if (element.archiveSectionId == 2) {
              this.wpAddedInResubmit = element.actionTypeId == 3 ? true : false;
              this.wpAddedInResubmitReason = element.comments != "" ? element.comments : "";
            }
            //Deliverables
            else if (element.archiveSectionId == 3) {
              this.deliverablesAddedInResubmit = element.actionTypeId == 3 ? true : false;
              this.deliverablesAddedInResubmitReason = element.comments != "" ? element.comments : "";
            }
            //Linked Archives
            else if (element.archiveSectionId == 4) {
              this.linkedArchivesAddedInResubmit = element.actionTypeId == 3 ? true : false;
              this.linkedArchivesAddedInResubmitReason = element.comments != "" ? element.comments : "";
            }
            //ERP details
            else if (element.archiveSectionId == 5) {
              this.ERPMembersAddedInResubmit = element.actionTypeId == 3 ? true : false;
              this.ERPReasonsProvidedInResubmit = element.comments != "" ? element.comments : "";
            }
            //Binders
            else if (element.archiveSectionId == 7) {
              //this.indBinderStatus = element.actionsTypeId;
            }
          });
        }
        this.DataViewforSections();
      }
    });
  }




  // This is required only for
  // Resubmit-open, Resubmit-Rejected, Resubmit-RFA
  AdmSubView() {

    if (this.archiveinfo.resubmissionType == 'Substantive') {

      //To show the approvers PPD,NPPD,Reason Memo, and Upload Memo
      this.GETPPDDEtails();  // It Drives submit button , Just makes disable or enable
      debugger;
      this.GetUploadedMemo(this.archiveNumber);  // It drives submit button, Just makes disable
      this.ShowDownloadCard(this.downloadCard);
      this.GetResubmissionReason(); // It drives submit button
      // PPD and NPPD should be handled based on approvers
      this.showPPDReasonMemo = true;
      this.showNPPD = true;
    }
    else {
      //
      this.showPPDReasonMemo = false;
      this.showNPPD = false;
    }
  }

  //Resubmit Open View
  LoadBarsforResubmitOpenOrReject(status: number) {

    switch (status.toString()) {

      case '0': {
        this.resubmissionInProgess = 50
        break;
      }
      case '1': {

        this.resubmissionInProgess = 100;
        this.firstApprovalBar = 50;

        break;
      }

      case '2':
        {
          this.resubmissionInProgess = 100;
          this.firstApprovalBar = 100;
          this.secondApprovalBar = 50;

          break;
        }

      case '3': {
        this.resubmissionInProgess = 100;
        this.firstApprovalBar = 100;
        this.secondApprovalBar = 100;
        this.thirdApprovalBar = 50;
        break;
      }

      case '4': {
        this.resubmissionInProgess = 100;
        this.firstApprovalBar = 100;
        this.secondApprovalBar = 100;
        this.thirdApprovalBar = 100;
        this.resubmissionApproved = 100;
        break;
      }

    }

    this.SubsorAdmn = true;
    this.showBars = true;

  }


  // Resubmit ready for approval Bars
  LoadBarsforResubmitRFA(status: number) {

    switch (status.toString()) {


      case '0': {
        this.resubmissionInProgess = 100;
        this.firstApprovalBar = 50;
        break;
      }
      case '1': {

        this.resubmissionInProgess = 100;
        this.firstApprovalBar = 100;
        this.secondApprovalBar = 50;

        break;
      }

      case '2':
        {
          this.resubmissionInProgess = 100;
          this.firstApprovalBar = 100;
          this.secondApprovalBar = 100;
          this.thirdApprovalBar = 50;

          break;
        }

      case '3': {
        this.resubmissionInProgess = 100;
        this.firstApprovalBar = 100;
        this.secondApprovalBar = 100;
        this.thirdApprovalBar = 100;
        this.resubmissionApproved = 100;
        break;
      }

    }
    this.SubsorAdmn = true;
    this.showBars = true;

  }


  // It is to enable or disable submit button
  // Required in  RFA 1st Level, Resubmit-Open
  SubmitFinalView(ResubmissionType: number) {

    if (ResubmissionType == 2)   // Substantive

    {

      // If reader access the archive
      if (this.IsUnauthorised) {
        this.ShowSubmitButton = true;
        this.ReadyToSubmit = false;
      }

      else if (!this.isResubmissionReasonPopulated || (this.isPPDExists && !this.isPPDPopulated) ||
        (this.isNPPDExists && !this.isNPPDpopulated) || !this.isMemoPopulated) {
        console.log("Sub Before PPD Bar", this.ReadyToSubmit);
        this.ShowSubmitButton = true;
        this.ReadyToSubmit = false;
        console.log(" Sub After PPD Bar", this.ReadyToSubmit);

      }

      // Common check for reasons
      else if ((this.ArchiveDetailsEditedInResubmit == true && this.ADReasonsProvidedInResubmit == "") ||
        (this.wpAddedInResubmit == true && this.wpAddedInResubmitReason == "") ||
        (this.deliverablesAddedInResubmit == true && this.deliverablesAddedInResubmitReason == "") ||
        (this.ERPMembersAddedInResubmit == true && this.ERPReasonsProvidedInResubmit == "") ||
        (this.linkedArchivesAddedInResubmit == true && this.linkedArchivesAddedInResubmitReason == "")
      ) {
        console.log("Sub Before State Reasons ", this.ReadyToSubmit);
        //this.ShowSubmitButton=true;
        this.ShowSubmitButton = true;
        this.ReadyToSubmit = false;

        console.log("Sub After State Reasons ", this.ReadyToSubmit);

      }

      //
      // By default it is false. As long as link or awaiting approval are required submit button shoule be false
      else if (this.IsAwaitingOrPending) {
        this.ShowSubmitButton = true;
        this.ReadyToSubmit = false;

      }


      // Submit is not required
      else if (this.CanApproveatSecondorThrid) {
        this.ShowSubmitButton = false;

      }

      else {
        //this.ShowSubmitButton=true;
        console.log("Sub before Else case of State Reasons and PPd Bar ", this.ReadyToSubmit);
        this.ReadyToSubmit = this.enableSubmit;  // Showing it from DB
        console.log("Sub After Else case of State Reasons and PPd Bar ", this.ReadyToSubmit);

      }

     // this.ShowSubmitButton = true;
      // this.ReadyToSubmit = true;

    }


    else  // Administrative
    {

      // Common check for reasons
      if ((this.ArchiveDetailsEditedInResubmit == true && this.ADReasonsProvidedInResubmit == "") ||
        (this.wpAddedInResubmit == true && this.wpAddedInResubmitReason == "") ||
        (this.deliverablesAddedInResubmit == true && this.deliverablesAddedInResubmitReason == "") ||
        (this.linkedArchivesAddedInResubmit == true && this.linkedArchivesAddedInResubmitReason == "") ||
        (this.ERPMembersAddedInResubmit == true && this.ERPReasonsProvidedInResubmit == "")) {
        console.log("adm Before State Reasons ", this.ReadyToSubmit);
        //this.ShowSubmitButton=true;
        this.ShowSubmitButton = true;
        this.ReadyToSubmit = false;
        console.log("Adm After State Reasons ", this.ReadyToSubmit);
      }

      else {
        console.log("adm before Else case of State Reasons and PPd Bar ", this.ReadyToSubmit);
        this.ShowSubmitButton = true;
        this.ReadyToSubmit = true;
        console.log("adm before Else case of State Reasons and PPd Bar ", this.ReadyToSubmit);
      }
    }


  }



  GetResubmissionReason() {
    //Resubmission Reasons
    this.archiveHomeService.GetResubmissionReason().subscribe(
      (data) => {
        this.ResubmissionReasonTypes = data
        console.log(data);
        //GetSubstantiation
         let showLoader = false;
        this.GetSubstantiation(this.archiveNumber, 10, showLoader);

        setTimeout(() => {


          (this.ResubmissionReasonProvided != '' && this.ResubmissionReasonProvided != undefined) ? this.ResubmissionReasonProvide = "Change" : this.ResubmissionReasonProvide = "Select the reason";


          if (this.ResubmissionReasonProvided != '' && this.ResubmissionReasonProvided != undefined) {
            this.isResubmissionReasonPopulated = true;  // Disabling submit button for Resubmit open and 1st level
          }

          this.SubmitFinalView(2);
        }, 3000);

      },
      (err) => {
        console.log("error is ", err)
      }
    );

  }



  PopulatePPDInfoIcon() {

    // PPD Populate in info icon
    if (this.isFirstLevelPPD) {
      this.firstLvlApproverName = this.PPDLastName + "," + this.PPDFirstName;
      this.firstLvlApproverRole="PPD";
    }

    else if (this.isSecondLevelPPD) {
      this.secondLvlApproverName = this.PPDLastName + "," + this.PPDFirstName;
      this.secondLvlApproverRole="PPD";
    }

    else if (this.isThirdLevelPPD) {
      this.thirdLvlApproverName = this.PPDLastName + "," + this.PPDFirstName;
      this.thirdLvlApproverRole="PPD";

      if(this.FlagFromSavePPDMethod==true)
      {
        this.GetAdminstrativeSubstantiveViewWithBars();
      }
      
  }
    

  }


  // NPPD Populate in info icon
  PopulateNPPDInfoIcon() {

    if (this.isSecondLevelNPPD) {
      this.secondLvlApproverName = this.NPPDLastName + "," + this.NPPDFirstName;
      this.secondLvlApproverRole = "NPPD";
    }

    else if (this.isThirdLevelNPPD) {
      this.thirdLvlApproverName = this.NPPDLastName + "," + this.NPPDFirstName;
      this.thirdLvlApproverRole = "NPPD";
    }
  }


  ResubmitRFAFirstLevelApproverView(Resubmissiontype: number) {

    if(this.archiveFlowIndividualActions != undefined)
    {
      this.ResubmitRFAsubView(Resubmissiontype)

    }

    else
    {
      this.archiveHomeService.GetArchiveActionsForIndividualSections(this.archiveNumber).subscribe(data => {
        if (data) {
           this.archiveFlowIndividualActions=data; 
           this.ResubmitRFAsubView(Resubmissiontype);   
        }
      });
    }
    

  }

   ResubmitRFAsubView(Resubmissiontype: number)
   {
  

    var Approvedcount = 0;
    var awaitingapprovalcount = 0;
    for (let i = 0; i < this.archiveFlowIndividualActions.length; i++) {

      // Section edited when it is 1
      if (this.archiveFlowIndividualActions[i].isSectionEdited === 1) {
        // this.archiveHomeLabel = "Every edited section has been reviewd. Press the ''Submit'' button to finish."
        // this.isQuestionMark=true;
        awaitingapprovalcount++;
      }
      //Section  Approved when it is 1
      else if (this.archiveFlowIndividualActions[i].actionsTypeId === 1) {
        Approvedcount++;
      }
    }
    if (this.archiveFlowIndividualActions[0].isSectionEdited === 1) {
      this.ArchiveDetailawaitingApprval = 1;
    }
    if (this.archiveFlowIndividualActions[1].isSectionEdited === 1) {
      this.WorkingPapersawaitingApprval = 1;
    }
    if (this.archiveFlowIndividualActions[2].isSectionEdited === 1) {
      this.DeliverableawaitingApprval = 1;
    }
    if (this.archiveFlowIndividualActions[3].isSectionEdited === 1) {
      this.RelatedArchivesawaitingApprval = 1;
    }
    if (this.archiveFlowIndividualActions[4].isSectionEdited === 1) {
      this.ERPawaitingApprval = 1;
    }
    if (this.archiveFlowIndividualActions[5].isSectionEdited === 1) {
      this.RetentionExpawaitingApprval = 1;
    }
    if (Approvedcount === this.archiveFlowIndividualActions.length) {
      this.archiveHomeLabel = "Every edited section has been reviewd. Press the ''Submit'' button to finish."
    }
    // else
    // {
    // this.archiveHomeLabel ="The archive has been submitted for approval. The Archive Manager/Partner will review the changes and system will notify you as soon as it will be ready."
    // }

    // Few section are awaiting approval
    if (awaitingapprovalcount > 0) {

      if (awaitingapprovalcount == 1)
        this.AwaitingApprovalText = awaitingapprovalcount + " section awaiting approval.";
      else
        this.AwaitingApprovalText = awaitingapprovalcount + " sections awaiting approval.";


      this.PendingApprovalText = "";
      this.ShowSubmitButton = true;
      console.log("Before awaiting approval ", this.ReadyToSubmit);
      this.ReadyToSubmit = false;
      console.log("After awaiting approval ", this.ReadyToSubmit);
      this.visible = true;
      this.archiveHomeLabel = "The archive has been submitted for approval. Please click on each edited section below to review and approve (or reject) and then select the “Submit” button to finish."
      this.IsAwaitingOrPending = true;
    }
    // No further approvals

    else if (awaitingapprovalcount === 0 &&  localStorage['IsSectionVisited'] == "1") {
      this.PendingApprovalText = "";
      this.AwaitingApprovalText = "";
      this.IsAwaitingOrPending = false;
      this.SubmitFinalView(Resubmissiontype);
      localStorage['IsSectionVisited'] = "0";
      // this.ShowSubmitButton = true;
      // this.ReadyToSubmit=true;
      this.visible = true;
      this.archiveHomeLabel = "Every edited section has been reviewd. Press the ''Submit'' button to finish.";
      if (!this.showROIUpdateAvailable)   this.notifier.notify("success", "Review of all sections is completed");
      if (!this.showROIUpdateAvailable) this.modalService.openWithCustomWidth('Archive-Submission-Modal', "500");
    }

    else if (awaitingapprovalcount === 0 &&  localStorage['IsSectionVisited'] == "0") {
      this.PendingApprovalText = "";
      this.AwaitingApprovalText = "";
      this.IsAwaitingOrPending = false;
      this.SubmitFinalView(Resubmissiontype);
      localStorage['IsSectionVisited'] = "0";
      // this.ShowSubmitButton = true;
      // this.ReadyToSubmit=true;
      this.visible = true;
      this.archiveHomeLabel = "Every edited section has been reviewd. Press the ''Submit'' button to finish.";
     // if (!this.showROIUpdateAvailable)   this.notifier.notify("success", "Review of all sections is completed");
     //if (!this.showROIUpdateAvailable) this.modalService.openWithCustomWidth('Archive-Submission-Modal', "500");
    }

    //this.ShowSubmitButton = true;

    if (Resubmissiontype == 2) // Substantive
    {
      this.showLinks = true;
    }

    else {
      this.showLinks = false;
    }


    //Archive home label
    this.isQuestionMark = true;
    this.ShowRemove = true;

   }


  







  GetArchiveRejectioncomments() {
    this.ArchiveRejectionComments = '';
    this.archiveHomeService.Getsectioncomments(this.archiveNumber, 0, 0)
      .subscribe(
        data => {
          this.ArchiveRejectionComments = data.comments;
          this.ArchiveRejectedDate = data.rejectedDate;
          this.ArchiveRejectedBy = data.rejectedBy;
        }
      );
  }


  //Resubmit Open View
  GetRoleNameByID(status: string) {

    switch (status.toString()) {

      case '5': {
        this.roleNameforinfo = "Archive Partner";
        break;
      }
      case '6': {

        this.roleNameforinfo = "Archive Manager";

        break;
      }
      case '7': {

        this.roleNameforinfo = "Archive Field Senior";

        break;
      }

      case '11':
        {
          this.roleNameforinfo = "PPD"; //"Professional Practice Director";

          break;
        }

      case '12': {

        this.roleNameforinfo = "NPPD"; //"National Professional Practice Director";
        break;
      }


    }

    return this.roleNameforinfo;

  }

  RFASubmitpopupandToaster()
   {

    if(this.archiveFlowIndividualActions != undefined)
    {
      this.RFASubmitpopupandToasterSub()

    }

    else
    {
      this.archiveHomeService.GetArchiveActionsForIndividualSections(this.archiveNumber).subscribe(data => {
        if (data) {
       
           this.RFASubmitpopupandToasterSub();   
        }
      });
    }
   

  }





  RFASubmitpopupandToasterSub() {
    var Approvedcount = 0;
    var awaitingapprovalcount = 0;
    for (let i = 0; i < this.archiveFlowIndividualActions.length; i++) {

      // Section edited when it is 1. Excluding retention exception
      if (this.archiveFlowIndividualActions[i].actionsTypeId === 0 && this.archiveFlowIndividualActions[i].archiveSectionId !=6) {
        // this.archiveHomeLabel = "Every edited section has been reviewd. Press the ''Submit'' button to finish."
        // this.isQuestionMark=true;

        awaitingapprovalcount++;
      }
      //Section  Approved when it is 1
      else if (this.archiveFlowIndividualActions[i].actionsTypeId === 1) {
        Approvedcount++;
      }

      else if (this.archiveFlowIndividualActions[i].actionsTypeId === 2) {
        Approvedcount++;
      }

    }
    
    // if (Approvedcount === this.archiveFlowIndividualActions.length) {
    //   this.archiveHomeLabel = "Every edited section has been reviewd. Press the ''Submit'' button to finish."
    // }
    // else
    // {
    // this.archiveHomeLabel ="The archive has been submitted for approval. The Archive Manager/Partner will review the changes and system will notify you as soon as it will be ready."
    // }
    //awaitingapprovalcount=0;

    // Few section are awaiting approval
    if (awaitingapprovalcount > 0) {

      // if (awaitingapprovalcount == 1)
      //   this.AwaitingApprovalText = awaitingapprovalcount + " section awaiting approval.";
      // else
      //   this.AwaitingApprovalText = awaitingapprovalcount + " sections awaiting approval.";


      // this.PendingApprovalText = "";
      // this.ShowSubmitButton = true;
      // console.log("Before awaiting approval ", this.ReadyToSubmit);
      // this.ReadyToSubmit = false;
      // console.log("After awaiting approval ", this.ReadyToSubmit);
      // this.visible = true;
      // this.archiveHomeLabel = "The archive has been submitted for approval. Please click on each edited section below to review and approve (or reject) and then select the “Submit” button to finish."
      // this.IsAwaitingOrPending = true;
    }
    // No further approvals


    else if (awaitingapprovalcount === 0) {
      // this.PendingApprovalText = "";
      // this.AwaitingApprovalText = "";
      // this.IsAwaitingOrPending = false;
      // // this.ShowSubmitButton = true;
      // // this.ReadyToSubmit=true;
      // this.visible = true;
      // this.archiveHomeLabel = "Every edited section has been reviewd. Press the ''Submit'' button to finish.";
      if (!this.showROIUpdateAvailable && localStorage['IsSectionVisited'] == "1")
      {

        localStorage['IsSectionVisited'] ="0";
        this.notifier.notify("success", "Review of all sections is completed");
        this.modalService.openWithCustomWidth('Archive-Submission-Modal', "500");
        localStorage['IsSectionVisited'] =0;
     }
    }


  }

  onChangeEventFunc(isChecked: boolean) {
    if (isChecked == true) {
      this.isAgreeChecked = true;
    }
    else{
      this.isAgreeChecked=false;
    }
  }

  ResetForm() { }

  //All parts in Archive home page

  // Part 1 => Bars View  (Administrative/ Substantive )
  // Flags :  showBars
  //Logic :Step1:  GetAdminstrativeSubstantiveViewWithBars use this object to get the bars info
  //  Step 2: Call the corresponding switch logic method to load the percentage and info with the approvla flow object


  // Part 2 => Submit/Resubmit/Approve/Reject buttons View
  // Approve, Reject in 2nd and 3rd level
  //Resubmit in approved, Resubmit approved statuses
  // Submit in remaining scenarios by default


  // Part 3 => Showing approved/Rejected/Awaiting approval View
  // It comes only in Rejected, Resubmit-Rejected, Resubmit-RFA


  //Part 4 => Common sections data View

  //Part 5 => Getting state reasons

  //Part 6 : Getting Approvers (PPD,NPPD), Reason, Upload Memo

  //Flags : showPPDReasonMemo, showNPPD

  // Part 7 : Archive home labels
  //Flags : archiveHomeLabel

  // Part 8 : Submit labels
  // Flags

  resubmissionDescription(){
    this.ResubmissionReasonDescription.length < 5 ? this.IsErrorReasonDescription = true :  this.IsErrorReasonDescription = false;

  }

}
