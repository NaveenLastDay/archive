﻿using Amazon.Lambda.Core;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace Deloitte.AIFA.Lambda.Logging
{
    public class CustomLoggerProvider : ILoggerProvider
    {
        public IConfiguration Configuration { get; set; }
        IHttpContextAccessor _accessor;
        public CustomLoggerProvider(IConfiguration configuration, IHttpContextAccessor accessor)
        {
            Configuration = configuration;
            _accessor = accessor;
            if (accessor != null)
            {
                LambdaLogger.Log("Central logging1 :: accessor");
            }
        }
        public ILogger CreateLogger(string categoryName)
        {
            return new CustomCoreLogger(Configuration, _accessor);
        }

        public void Dispose()
        {

        }
    }
}
