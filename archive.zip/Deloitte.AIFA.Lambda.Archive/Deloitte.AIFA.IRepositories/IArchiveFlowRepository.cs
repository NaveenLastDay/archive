﻿using System;
using System.Collections.Generic;
using System.Text;
using Deloitte.AIFA.DomainEntities;

namespace Deloitte.AIFA.IRepositories
{
    public interface IArchiveFlowRepository
    {
        ArchiveFlowDetails GetArchiveSectionComments(string ArchiveNumber, int sectionId, int ActionTypeId);
        string CreateOrUpdateArchiveActions(ArchiveFlowDetails aFlowdetails);
        List<ArchiveFlowDetails> GetResubmissionReasonsforArchive(string ArchiveNumber);
    }
}
