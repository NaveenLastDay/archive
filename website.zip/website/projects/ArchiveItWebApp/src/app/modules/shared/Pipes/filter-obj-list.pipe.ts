import { Pipe, PipeTransform } from '@angular/core';
@Pipe({
  name: 'filterObj'
})
export class filterObjListPipe implements PipeTransform {
  transform(items: any[], searchText: string, searchField: any): any {
      debugger;
    if(!searchText)
     return items;
    return items.filter(
      item => item[searchField].toLowerCase().indexOf(searchText.toLowerCase()) > -1
   );
  }
}