﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.Serialization;
using System.Text;

namespace Deloitte.AIFA.Lambda.AutoArchiveCreation
{
           public enum LogCategory
        {

            [EnumMember]
            [Description("Error Log")]
            Error = 0,

            [EnumMember]
            [Description("Warning Log")]
            Warning = 1,

            [EnumMember]
            [Description("Information Log")]
            Information = 2,

            [EnumMember]
            [Description("Debug Log")]
            Debug = 12
        }
    
}
