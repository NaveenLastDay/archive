import { Component, OnInit, ViewChild} from '@angular/core';
import { map } from 'rxjs/operators';
import { Router, NavigationEnd, ActivatedRoute } from '@angular/router';
import { MatAutocompleteTrigger } from '@angular/material/autocomplete';
import { Observable, of } from 'rxjs';
import { SearchWbsService } from '../../../services/searchwbs.service';
import { NotifierService } from 'angular-notifier';
import { AppConfig } from '../../../services/appconfig.service';
import { MatAutocompleteSelectedEvent } from '@angular/material';
import { FormControl, FormBuilder, FormGroup, Validators,FormArray } from '@angular/forms';
//import { FileUploadRecordService } from '../../../services/fileupload.record.service';
import { HoldsService } from '../../../services/holds-admin.service';
import { FileUploadEventService } from '../../record/file-upload/fileupload.event.service';
import { FielUploadService } from '../../../services/fileupload.service';
import { WorkingPaperService } from '../../../services/working-paper.service';
import { FileUploadProcessService } from '../../record/file-upload/fileupload.process.service';
import { NgxSpinnerService } from "ngx-spinner";
import { DatePipe } from '@angular/common';
import { DateTime } from 'aws-sdk/clients/devicefarm';
import { stringToKeyValue } from '@angular/flex-layout/extended/typings/style/style-transforms';
import { dateType } from 'aws-sdk/clients/sts';




export class NoticeFileNames
{
  fileId:string
  fileName: string
  fileSize: number
  fileTypeId:number
}

export interface WBSData {
  clientNumber: string        ,
  clientID: string,
  clientName: string,
  archiveNumber: string,
  archiveName: string,
  archiveCategory: string,
  wbsClientName: string,
  wbsLevelOneNumber: string,
  wbsLevelOneDescription:string                                                                                                                                                                              ,
  wbsLevelOneDateCreated: Date
}

interface NoticeArray {
  NoticeNameArray: string;
  NoticeSizeArray: number;
  NoticeFileIDArray: string;
}

interface AttachmentArray {
  AttachmentNameArray: string;
  AttachmentSizeArray: number;
  AttachmentFileIDArray: string;
}


@Component({
  selector: 'app-creation-edit-hold-info',
  templateUrl: './creation-edit-hold-info.component.html',
  styleUrls: ['./creation-edit-hold-info.component.css'],
  providers: [DatePipe]  
})

export class CreateEditHoldInfoComponent implements OnInit {
  
  value : any;
  buisnessTypes: any;
  buisnessTypesForExceptAudit: any;
  enableDateforMatterEnergreen:boolean=false;
  ShowCancellationTextBox:boolean=false;
  selectedvalue :string="";
  SelectedValueForClientId:string="";
  selectedBuisnessvalue :string="";
  rowcount:number=0;
  module: string = "Holds";
  HoldNumber :string="";
  placeholderHoldNumberText:string=""
  HoldNumberEnable :boolean =false;
  ModeOfOperation: string
  login_form: FormGroup;
  currentUrl: string;
  NoAttachmentFileFlag:boolean=false;
  maxDate: Date;
  minDate: Date;

  $NoticeFileData: NoticeFileNames[];

  
    
  //Variable Decleration
  customRules: string[] = [];
  customRulesForClientID: string[] = [];
  customRulesBuisness: string[] = [];
  crossicon:boolean = false;
  autoTrigger: MatAutocompleteTrigger;
  $wbsClientData: Observable<any[]>;
  ClientData:any[];
  $searchWBSData: WBSData[];
  clients: Array<any> = [];
  $filteredwbsClientData: Observable<any[]>;
  wbsCount: any;
  AttachmentfileId: string = "";
  $NoticeArray: NoticeArray[]=[];
  $AttachmentArray: AttachmentArray[]=[]


  //Form Variables

  MatterID:string;
  radioGroup:number;
  rbMattergreen:number;

  matstartdate:DateTime;
  objMatstartdate:any;
  matenddate:DateTime;
  objMatenddate:any;

  effstartdate:DateTime;
  objEffstartdate:any;
  effenddate:DateTime;
  objEffenddate:any;
  
  effmatteregCD:DateTime;
  effmatterCD:DateTime;
  GeneralComments:string="";


 HoldId_out :number =0;
 NoticeHoldID: number=0
 NoticefileId :string="";
 NoticeName: string = '';
 NoticeSize: number = 0;

 AttchementHoldID: number=0
 AttchementFileId :string="";
 AttachmentName: string = '';
 AttachmentSize: number = 0;
 s3NoticeFileName: string = "";
 s3AttachmentFileName: string = "";

 NoticeHoldfileId: number = 0;
 NoticefileTransferId: number = 0;

 AttchmentHoldfileId: number = 0;
 AttchmentTransferId: number = 0;

 ClientNameString:string="";
 BuisnessNameString:string="";
 DisableMatSelection:boolean;

 verificationInProgressStatus = [0, 1, 2, 5];
 verifiedNotice: any = [];
 unverifiedNotice: any = [];
 verifiedAttachments: any = [];
 unverifiedAttachments: any = [];
 datePipeString : string;
 Buisness: any[];
 TitleCount: number = 0;

 GetHoldNumberFromSearchScreen:string='';
 ShowCreateHoldBanner:boolean;
 HoldCreatedDate:DateTime;
 MatterEvrgrnNoChecked:boolean;
 MatterEvrgrnYesChecked:boolean;
 CommentsErrorModel:string='';
 MatterIdError:string='';
 EnableCreateHoldButtonForClient:boolean=false;
 EnableCreateHoldButtonForBusiness:boolean=false;
 EnableCreateHoldButtonForPreservation:boolean;
 ErrorMsgFlagForEmptyBusiness:boolean=false;
 HoldId:number;
 

 today: number = 0;
 i: number = 0;
 Message: string;
 currentModule: any;
 @ViewChild('autoCompleteInputClient', { read: MatAutocompleteTrigger, static: false }) autoCompleteAP: MatAutocompleteTrigger;

  constructor(private router: Router,private searchwbs: SearchWbsService,private notifier: NotifierService,private fb: FormBuilder,
  private _fuService: FielUploadService,private SpinnerService: NgxSpinnerService,
  private _fuEventService: FileUploadEventService, 
  private _uploadEventService: FileUploadEventService, private _HoldsService: HoldsService,
  private datePipe: DatePipe){
  router.events.subscribe((_: NavigationEnd) => this.currentUrl = this.router.url);
  this.today = Date.now();
  this.rowcount=10;
  
  this.login_form = fb.group({
//    "MatterID": ['', [Validators.pattern("/^[0-9]*$/"),Validators.required, Validators.minLength(4),]], 
    "MatterID": ['', [Validators.required, Validators.minLength(4),]], 
    'HoldNumber': [null, Validators.required],
    'buisnessCheckbox': [null, Validators.required],
    'MatterStartDate': [null, Validators.required],
    'EffectiveStartDate': [null, Validators.required],
    'MatterEndDate': [null, Validators.required],
    'EffectiveEndDate': [null, Validators.required],
    'MatteregCD': [null, Validators.required],
    'matterCD': [null, Validators.required],
    'description':[null, ''],
    'clientName' : [null, Validators.required],
    'rbMattergreen': [0, ''],
    'radioGroup': [1, Validators.required],
    
  });
  this.placeholderHoldNumberText="<i>Enter matter ID first</i>";

}
  

  ngOnInit() {
    
    this.placeholderHoldNumberText="<i>Enter matter ID first</i>";
    this.login_form.get('HoldNumber').disable();
    this.TitleCount = 3000;
    this.GetHoldNumberFromSearchScreen=localStorage.getItem('HoldNumber');
    console.log('holdnumber',this.GetHoldNumberFromSearchScreen);
    localStorage.setItem('HoldNumber','');
    if(this.GetHoldNumberFromSearchScreen!='' && this.GetHoldNumberFromSearchScreen!=null)
    {
      this._HoldsService.GetHoldsInformationForHold(this.GetHoldNumberFromSearchScreen).subscribe(data => {
        if(data)
        {
  
          console.log(data);
          this.ShowCreateHoldBanner=false;
          this.HoldId=data.holdId;
          this.HoldCreatedDate=data.createdDate;
          this.MatterID=data.matterId;
          this.placeholderHoldNumberText=data.holdNumber;
          this.ClientData=data.getClientData;
          this.ClientNameString=data.getClientData[0].clientId;///This is to maintain client Info for enabling & disabling save button
          this.buisnessTypes=data.getBusinessData;
          this.BuisnessNameString=data.getBusinessData[0].businessID;//This is to maintain Business Info for enabling & disabling save button
          this.buisnessTypes.forEach(function(e){e.CheckedState=true});      
          this.matstartdate=data.matterStartDate;
          this.objMatstartdate = this.convertstringTodateObj(data.matterStartDate.split("T")[0]);
          this.matenddate=data.matterEndDate;
          this.objMatenddate = this.convertstringTodateObj(data.matterEndDate.split("T")[0]);
          this.effenddate=data.effectiveEndDate;
          this.objEffenddate = this.convertstringTodateObj(data.effectiveEndDate.split("T")[0]);
          this.effstartdate=data.effectiveStartDate;
          this.objEffstartdate = this.convertstringTodateObj(data.effectiveStartDate.split("T")[0]);
          if(data.matterEverGreen==1)
          {
            this.MatterEvrgrnYesChecked=true;
            this.MatterEvrgrnNoChecked=false;
            this.enableDateforMatterEnergreen=true;
            if(data.matterEvergreenCancellationDate.split("T")[0]=== "0001-01-01")
            {
              this.effmatteregCD = null;
            }
            else{
            this.effmatteregCD=data.matterEvergreenCancellationDate;
            }
            this.effmatterCD=data.matterCancellationDate;
          }
          else{
            this.MatterEvrgrnYesChecked=false;
            this.MatterEvrgrnNoChecked=true;
            this.enableDateforMatterEnergreen=false;
          }
          var ClientDatawithClientName=this.ClientData.map(function(Clients)
          {
            return Clients['clientName'];
          });

          if(data.getFilesUploadedData.length>0){
            data.getFilesUploadedData.filter(f=>f.fileTypeId===14).forEach(element => {
              let noticeArray: NoticeArray = {
                NoticeNameArray: element.fileName,
                NoticeSizeArray: 0,
                NoticeFileIDArray: ""   
              }
              this.$NoticeArray.push(noticeArray);
              //console.log("get",this.$NoticeArray);

            });

            data.getFilesUploadedData.filter(f=>f.fileTypeId===15).forEach(element => {
               let attachmentArray: AttachmentArray = {
                AttachmentNameArray: element.fileName,
                AttachmentSizeArray: 0,
                AttachmentFileIDArray: ""   
               }
               this.$AttachmentArray.push(attachmentArray);
               //console.log("get",this.$AttachmentArray);
 
             });

            
            
          }

          // if(data.getFilesUploadedData.length==2)
          // {
          //   this.NoticeName=data.getFilesUploadedData[0].fileName;
          //   this.AttachmentName=data.getFilesUploadedData[1].fileName;
          // }
          // else if(data.getFilesUploadedData.length==1)
          // {
          //   this.NoticeName=data.getFilesUploadedData[0].fileName;
          // }
          var ClientDatawithClientID=this.ClientData.map(function(Clients)
          {
            return Clients['clientId'];
          });;
          this.customRules=ClientDatawithClientName;
          this.customRulesForClientID=ClientDatawithClientID;
          this.GeneralComments=data.comments;
          console.log('Get the data for Hold from DB - GetHoldsInformationForHold');
        }
      });
    }
    else
    {
      this.ShowCreateHoldBanner=true;
      this.MatterEvrgrnNoChecked=true;
      this.MatterEvrgrnYesChecked=false;
    }

     this._uploadEventService.currentModule="Holds";
     this.currentModule="Holds";
    //================================= Start: File Upload ===========================

    //FileUploadStep 12:
    //Update the uploaded status in DB and refresh the working papers list
    this._fuEventService.getfileUploadStatus.subscribe(fileArrayObject => {
      var self=this;
      if(fileArrayObject.module!=self.currentModule)
      return;
      // debugger;
      if (fileArrayObject) {

        let etag = "";

        if (fileArrayObject.eTag) {
          etag = fileArrayObject.eTag.substr(1, fileArrayObject.eTag.length - 2);
        }
        
        let fuparams = {
          HoldFileId: fileArrayObject.metaData.ArchiveFileId,
          HoldFileTransferId: fileArrayObject.metaData.FileTransferId,
          FileUploadStatusCode: fileArrayObject.uploadStatus,
          ETag: etag,
          UploadId: fileArrayObject.uploadId,
          FailedDescription: fileArrayObject.errorMessage
        };


        console.log("updating in DB");
        console.log(fuparams);

        this._HoldsService.CreateOrUpdateholdTranfer(fuparams).subscribe(response => {
          console.log("updated in DB");
          console.log(response);

         // this.SpinnerService.hide();
          //Update the working papers upload files list on file upload success
          if (fileArrayObject.uploadStatus == "success") {
            this._HoldsService.GetHoldsByArchiveFileId(response.holdFileId).subscribe(data => {
              if (this.verificationInProgressStatus.includes(data.fileVerificationStatusId)) {
                this.unverifiedNotice.unshift(data);
              }
              else {
                this.unverifiedNotice.unshift(data);
              }
              this.NavigatetoSearchholds();
            },
              err => {
               // this.SpinnerService.hide();
                console.log("failed to refresh hold files");
              }

            );
          }

         // this.SpinnerService.show();
          if (this.Message !== undefined && this.Message !== "") {
            this.NavigatetoSearchholds();
           // setTimeout(() => { this.notifier.notify("success", this.Message);}, 5000);
            this.Message = "";
          }
         
         // this.SpinnerService.hide();
        },
          err => {
           // this.SpinnerService.hide();
            console.log("failed to update in Holds DB");
            console.log(err);
          });
      }
    });
    this.getBusiness();
    
  }

  get result() {
    return this.Buisness.filter(item => item.checked);
  }

  Cleardata(){
    this.selectedvalue = '';
    this.$searchWBSData = [];
    this.clients = [];

    this.NoticeName=undefined;
    this.AttachmentName=undefined;
    this.ClientNameString  =undefined;
    this.BuisnessNameString  =undefined;
    this.placeholderHoldNumberText="<i>Enter matter ID first</i>";
    this.login_form.get('MatterID').reset();
    this.login_form.get('clientName').reset();
    this.login_form.get('buisnessCheckbox').reset();
    this.login_form.get('MatterStartDate').reset();
    this.login_form.get('MatterEndDate').reset();
    this.login_form.get('EffectiveStartDate').reset();
    this.login_form.get('EffectiveEndDate').reset();
    this.login_form.get('MatteregCD').reset();
    this.login_form.get('matterCD').reset();
    this.login_form.get('description').reset();
    this.router.navigate(['/admin/adminsidenavbar/holds']);
  }
  //Filter the data for Search WBS
  private filterwbsClient(value: string) {
    let filterValue = '';
    if (value) {
      filterValue = value.toLowerCase();
      return this.$wbsClientData.pipe(
        map(data => data.filter(data => data.name.toLowerCase().indexOf(filterValue) === 0))
      );
    } else {
      return this.$wbsClientData;
    }
  }

  getBusiness(){
    this._HoldsService.GetBuisness().subscribe(
      data => {
        this.buisnessTypes = data;
        this.buisnessTypesForExceptAudit = this.buisnessTypes.filter(item => item.businessName !== "Audit");
        this.buisnessTypes=this.buisnessTypes.filter(item => item.businessName == "Audit");
        }
    );
 
  }

  SearchWBSOne(event: any) {
      if(this.customRules.length < 1){
      this.clients = [];
      if(event.target.value.length >= 3)
      {
      this._HoldsService.GetClientDatabasedonSearch(event.target.value).subscribe(result => {
      
        if(result.length>0){
          //this.$searchWBSData = result;
          this.clients = result;
        }
        else
        {
          //this.$searchWBSData = null;
          this.clients = null;
          this.notifier.notify("error","No results found for client");
        }
          
        });
      }
      }
      this.SpinnerService.hide();
      //  if (this.$searchWBSData != undefined)
      //   this.wbsCount = this.$searchWBSData.length;
  }
  onInputChanged(event: any){
    
    /*this.wbslength = event.length;
    
    if(this.wbslength < this.textlength) {
      this.buttonDisabled = true;
    }
    else{
      this.buttonDisabled = false;
    }*/
  }
  optionClientSelected(event: MatAutocompleteSelectedEvent) {
   
    if(this.customRules.length < 1){
    this.selectedvalue=event.option.value.clientName;
    this.SelectedValueForClientId=event.option.value.clientId;
    this.customRules.push(this.selectedvalue); 
    this.customRulesForClientID.push(this.SelectedValueForClientId);
    this.ClientNameString="";
    //To disable auto populate after selecting single client
    this.DisableMatSelection=true;
    for (var index in this.customRulesForClientID) {
      if(this.ClientNameString!="")
      {
        this.ClientNameString= this.ClientNameString +","+this.customRulesForClientID[index];
      }
      else{
        this.ClientNameString= this.customRulesForClientID[index];
      }
      
    }
    this.EnableCreateHoldButtonForClient=true;
  }
  //else{
  //  this.notifier.notify("error","Only one Client is allowed");
  //}

  }

  RemoveCustomRules(option:string){
    let index = this.customRules.indexOf(option);
    this.customRules.splice(index, 1);
    this.customRulesForClientID.splice(index, 1);
    this.ClientNameString="";
    this.DisableMatSelection=false;
    for (var indexr in this.customRulesForClientID) {
      if(this.ClientNameString!="")
      {
        this.ClientNameString= this.ClientNameString +","+this.customRulesForClientID[indexr];
      }
      else{
        this.ClientNameString= this.customRulesForClientID[indexr];
      }
      
    }
    if(this.ClientNameString!="")
    {
      this.EnableCreateHoldButtonForClient=true;
    }
    else
    {
      this.EnableCreateHoldButtonForClient=false;
    }
  }

  
  browseFileDialogClick(filetype: string) {
    var self = this;
    var fileElem = document.createElement('input');
    var fileIndex = self._fuEventService.fileIndex++;
    if (filetype === 'PreservationNotice') {
      self.NoticefileId = 'fileId-' + fileIndex;
      fileElem.setAttribute("id", self.NoticefileId);
      this.EnableCreateHoldButtonForPreservation=true;
    }
    else if (filetype === 'HoldAttachment') {
      self.AttachmentfileId = 'fileId-' + fileIndex;
      fileElem.setAttribute("id", self.AttachmentfileId);
    }

    fileElem.setAttribute("type", "file");
    //fileElem.setAttribute("accept", this.acceptedMIMETypes);
    document.getElementById("div_fileupload").appendChild(fileElem);

    fileElem.click();
    fileElem.onchange = function (e: any) {

      var file = e.target.files[0];

      if (file.name) {
        if (filetype === 'PreservationNotice') {

          let FileExist:boolean=false
          self.$NoticeArray.forEach(function(element){
            if(element.NoticeNameArray===file.name)
            {
              FileExist=true;
            }
          });
          
          if(!FileExist){
          let noticeArray: NoticeArray = {
            NoticeNameArray: file.name,
            NoticeSizeArray: file.size,
            NoticeFileIDArray: self.NoticefileId     
          }
          
          //  let noticeArrayobje: NoticeArray[] = [];
          // noticeArrayobje.push(noticeArray);
          
          self.$NoticeArray.push(noticeArray);
          console.log("Array",self.$NoticeArray);

          self.NoticeName = file.name;
          self.NoticeSize = file.size;       
        }
        else{
          self.notifier.notify("error","File with same name already exists"); 
        }
          /*let customObj = new NoticeFileNames();

          
          customObj.fileId= self.NoticefileId;
          customObj.fileName=self.NoticeName;
          customObj.fileSize=self.NoticeSize;
          customObj.fileTypeId=11;
          self.$NoticeFileData.push(customObj);*/
          
        }
        else if (filetype === 'HoldAttachment') {
          let FileExist:boolean=false;
          self.$AttachmentArray.forEach(function(element){
            
            if(element.AttachmentNameArray===file.name)
            {
              FileExist=true;
            }
          });
          if(!FileExist){
          let attachmentArray: AttachmentArray = {
            AttachmentNameArray: file.name,
            AttachmentSizeArray: file.size,
            AttachmentFileIDArray: self.AttachmentfileId   
           }
          
          // let noticeArray: NoticeArray = {
          //   NoticeNameArray: file.name,
          //   NoticeSizeArray: file.size,
          //   NoticeFileIDArray: self.NoticefileId     
          // }
          
          //  let noticeArrayobje: NoticeArray[] = [];
          // noticeArrayobje.push(noticeArray);
          
          self.$AttachmentArray.push(attachmentArray);
          //console.log("Array",self.$AttachmentArray);

          self.AttachmentName = file.name;
          self.AttachmentSize = file.size;
        }
        else{
          self.notifier.notify("error","File with same name already exists"); 
        }

         /* let customObj = new NoticeFileNames();
          customObj.fileId= self.AttachmentfileId;
          customObj.fileName=self.AttachmentName;
          customObj.fileSize=self.AttachmentSize;
          customObj.fileTypeId=12;
          self.$NoticeFileData.push(customObj);
          console.log(self.$NoticeFileData);*/
        }
      }
    }
  }

  
  cancelSelectedFile(filetype: string) {
    let div_fileupload = document.getElementById("div_fileupload")
    if (filetype === 'PreservationNotice') {
      var fileElement = document.getElementById(this.NoticefileId);
      if (div_fileupload && fileElement) div_fileupload.removeChild(fileElement);

      this.NoticefileId = "";
      this.NoticeName = "";
      this.NoticeSize = undefined;
      this.EnableCreateHoldButtonForPreservation=false;
    }
    else if (filetype === 'HoldAttachment') {
      var fileElement = document.getElementById(this.AttachmentfileId);
      if (div_fileupload && fileElement) div_fileupload.removeChild(fileElement);

      this.AttachmentfileId = "";
      this.AttachmentName = "";
      this.AttachmentSize = 0;
      this.NoAttachmentFileFlag=true;
    }
  }
  cancelSelectedFilewithIndex(filetype: string, index: number) {
    debugger;
    let div_fileupload = document.getElementById("div_fileupload")
    if (filetype === 'PreservationNotice') {
      //var fileElement = document.getElementById(this.NoticefileId);
      //if (div_fileupload && fileElement) div_fileupload.removeChild(fileElement);

      this.$NoticeArray;
      // this.NoticefileId = "";
      // this.NoticeName = "";
      // this.NoticeSize = undefined;
      if(this.HoldId!=undefined){
        var parameters3 = {
          "HoldFileId":0
        , "HoldFileTransferId":0
        , "HoldFileName": this.$NoticeArray[index]["NoticeNameArray"].toString()
        , "HoldSize":123
        , "HoldId": this.HoldId 
        , "FileTypeId":16
        }
        this._HoldsService.CreateOrUpdateholdTranfer(parameters3).subscribe(
          (data) => {
            debugger;

          });

      }
      

      this.$NoticeArray.splice(index,1);
      this.EnableCreateHoldButtonForPreservation=false;
    }
    else if (filetype === 'HoldAttachment') {
     // var fileElement = document.getElementById(this.AttachmentfileId);
      //if (div_fileupload && fileElement) div_fileupload.removeChild(fileElement);

      if(this.HoldId!=undefined){
        var parameters2 = {
          "HoldFileId":0
        , "HoldFileTransferId":0
        , "HoldFileName": this.$AttachmentArray[index]["AttachmentNameArray"].toString()
        , "HoldSize":123
        , "HoldId": this.HoldId 
        , "FileTypeId":17
        }
        this._HoldsService.CreateOrUpdateholdTranfer(parameters2).subscribe(
          (data) => {

          });
        
        
      }

      this.$AttachmentArray.splice(index,1);
      if(this.$AttachmentArray.length===0)
        this.NoAttachmentFileFlag=true;
    }
  }

  addcolour()
  {
    
    document.getElementById('colordiv').classList.add('bordercolorchange');
    this.crossicon = true;
  }
  
  removecolour(event:any)
  {
    document.getElementById('colordiv').classList.remove('bordercolorchange');
    if(event.target.value === ''){
      this.crossicon = false;
    }
  }

  
  onKeyUp(event,ActionType: number) {
   
    if(ActionType==1)
    {
      //var CheckMatterId=this.MatterID;
      //var reg=new RegExp('^[0-9]+$');
      //console.log('test if matter Id has alpha and special chars',reg.test(CheckMatterId));
      //if(reg.test(CheckMatterId)==true)
     // {
        if( this.login_form.get('MatterID').value.length>=4 )
        {
          this.MatterIdError='';
          this.login_form.get('HoldNumber').disable();
          this.placeholderHoldNumberText="T01200"+this.login_form.get('MatterID').value;
        }
        else{
          this.placeholderHoldNumberText="<i>Enter matter ID first</i>";
        }
      //}
      //else{
      //    this.MatterIdError="Only Numeric values are Allowed";
      //    this.placeholderHoldNumberText="Enter Matter ID First";
      //}
    }
    else if(ActionType==0)
    {
      this.TitleCount = 3000 - event.target.value.length;
      var Commentslength=this.GeneralComments.length;
      if((Commentslength>=5 && Commentslength<=3000) || (Commentslength==0) || (Commentslength==undefined))
      {
        this.CommentsErrorModel="";
      }
      else
      {
        this.CommentsErrorModel="Comments should be between 5 to 3000 characters";
      }
    }
  }
 
 GetHoldByHoldNumber(holdnumber: string) {
  //this.SpinnerService.show();
  this._HoldsService.GetHoldByHoldNumber(holdnumber).subscribe(
    (data) => {
       if (data!=undefined) {
        
      }
    });
}


markFormTouched(group: FormGroup | FormArray) {
  Object.keys(group.controls).forEach((key: string) => {
    const control = group.controls[key];
    if (control instanceof FormGroup || control instanceof FormArray) { control.markAsTouched(); this.markFormTouched(control); }
    else { control.markAsTouched(); };
  });
};

keyupDateChange(event:any, val:any){
  var pattern =new RegExp("[0-9]{2}/[0-9]{2}/[0-9]{4}");
   (pattern.test(event)) ? this.assignValue(val, event) : this.assignValue(val, null);
}
assignValue(ele:string, val:any ){
  switch(ele){
    case 'matstartdate': this.matstartdate = val;
    break;
    case 'effstartdate': this.effstartdate = val;
    break;
    case 'effenddate': this.effenddate = val;
    break;
    case 'matenddate': this.matenddate = val;
    break;    
  }
}

onDateChange(event:any, val:any){  
  if(event != null){
    var dateEvent = new Date(event.year,  event.month - 1 , event.day);
    switch(val){
      case 'matstartdate': { this.matstartdate = dateEvent;  this.objMatstartdate = event; }
      break;
      case 'effstartdate': { this.effstartdate = dateEvent; this.objEffstartdate =event;  }
      break;
      case 'effenddate': { this.effenddate = dateEvent; this.objEffenddate = event;  }
      break;
      case 'matenddate': { this.matenddate = dateEvent; this.objMatenddate = event; }
      break;    
    }
   
  }
}

  CreateorUpdateHold(InputoperationType:number) {
    var CommentsLength=this.GeneralComments.length;

    this.radioGroup=this.login_form.controls["radioGroup"].value;
    this.rbMattergreen= this.MatterEvrgrnYesChecked = true ? 1 : this.login_form.controls["rbMattergreen"].value;
   
    if(InputoperationType==1)
    {
      this.markFormTouched(this.login_form);
    }

    if((this.ClientNameString== "" || this.ClientNameString==undefined || this.ClientNameString==null)){
      this.notifier.notify("error","Please select atleast one client");           
    }
    else if(InputoperationType==0 && this.radioGroup==0 && (this.effmatterCD == undefined || this.effmatterCD == null)){
      this.notifier.notify("error","Please select cancellation date");  
    }
    else if(InputoperationType==0 && this.radioGroup==0 && (this.AttachmentName==null || this.AttachmentName==""))
    {
      this.notifier.notify("error","Please upload Attachment");  
    }
    else if(this.$NoticeArray.length===0)
    {
      this.notifier.notify("error","Please upload preservation notice file");  
    }
    else if(this.NoticeName!="" && this.AttachmentName!="" && (this.NoticeName===this.AttachmentName))
    {      
     this.notifier.notify("error","File name cannot be same");         
    }
    else if((this.BuisnessNameString=="" || this.BuisnessNameString==undefined || this.BuisnessNameString==null))
    {
      this.notifier.notify("error","Please select atleast one business");         
    }
    else if((this.effstartdate == undefined && this.effstartdate == null)||(this.effenddate == undefined && this.effenddate == null)||
            (this.matenddate == undefined && this.matenddate == null) || (this.matstartdate == undefined && this.matstartdate == null))
    {
      this.notifier.notify("error","Please enter mantadatory fields");  
    }
    else if (CommentsLength>0 && (CommentsLength<5 || CommentsLength>3000) && InputoperationType==0)
    {
        this.notifier.notify("error","Please enter comments between 5 to 3000 characters");  
    }
   else{
   // this.SpinnerService.show();
      var parameters = {
          "HoldNumber": this.placeholderHoldNumberText
        , "MatterID": this.MatterID
        , "MatterStartDate": this.matstartdate != undefined && this.matstartdate != null? new Date(this.matstartdate).toLocaleDateString():this.matstartdate
        , "MatterEndDate": this.matenddate != undefined && this.matenddate != null? new Date(this.matenddate).toLocaleDateString():this.matenddate
        , "EffectiveStartDate": this.effstartdate != undefined && this.effstartdate != null? new Date(this.effstartdate).toLocaleDateString():this.effstartdate
        , "EffectiveEndDate": this.effenddate != undefined && this.effenddate != null? new Date(this.effenddate).toLocaleDateString():this.effenddate
        , "MatterEverGreen": this.rbMattergreen
        , "MatterEvergreenCancellationDate":this.effmatteregCD != undefined && this.effmatteregCD != null? new Date(this.effmatteregCD).toLocaleDateString():this.effmatteregCD     
        , "MatterCancellationDate":this.effmatterCD!= undefined && this.effmatterCD != null? new Date(this.effmatterCD).toLocaleDateString():this.effmatterCD
        , "CreatedBy":""
        , "HoldStatus": this.radioGroup
        , "Comments": this.GeneralComments ? this.GeneralComments :''
        , "SelectedClients": this.ClientNameString
        , "SelectedBusiness": this.BuisnessNameString
        , "operationType"  :InputoperationType
      }
    
      if(this.MatterID!=null && this.MatterID!='' && this.MatterID!=undefined)
      {
        this._HoldsService.CreateOrUpdatehold(parameters).subscribe((data) => {
         // this.SpinnerService.show();
             console.log('Status of Holds data saving:',data);
                if(data.outputMessage=="Success - Insertion"){
                   this.Message ="Hold "+this.placeholderHoldNumberText+" has been created";                
                   setTimeout(() => { this.notifier.notify("success", this.Message);}, 300);
                   this.HoldId_out=data.holdId;
                   this.fileUploadForRecords(this.HoldId_out);  
                   setTimeout(() => {this.router.navigate(['/admin/adminsidenavbar/holds/holdsearch']);}, 12000);  
                }
                else if(data.outputMessage=="There is already a hold with this number")
                {
                 this.notifier.notify("error", data.outputMessage);
                // this.SpinnerService.hide(); 
                 return;
                }
                else if(data.outputMessage=="Succesfull Updation")
                {
                this.fileUploadForRecords(this.HoldId);
                setTimeout(() => {this.notifier.notify("success","Hold updated successfully");}, 2000);
                // this.SpinnerService.hide(); 
                
                 if(this.radioGroup === 0){
                  this._HoldsService.RemoveArchivesFromHold(this.HoldId,'-1').subscribe(
                    res => {
                 console.log(res);
                    },
                  );
                 }
                 setTimeout(() => {this.router.navigate(['/admin/adminsidenavbar/holds/holdsearch']);}, 3000);
                }
                else{
                 this.notifier.notify("error", data.outputMessage);
                // this.SpinnerService.hide(); 
                 return;
                }          
           },
           err => {
            // this.SpinnerService.hide();
           });
          // this.SpinnerService.hide();   
         }
      else{
       // this.SpinnerService.hide();
        this.notifier.notify("error", 'Please enter Matter Id');
      }
    }
  }

  //get Hold File Details
  fileUploadForRecords(HoldId_out) {
    // this.SpinnerService.show();
    var self=this;
    this.$NoticeArray.filter(f=>f.NoticeFileIDArray!="0").forEach(function(value){

      var parameters3 = {
        "HoldFileId":0
      , "HoldFileTransferId":0
      , "HoldFileName": value.NoticeNameArray
      , "HoldSize":value.NoticeSizeArray
      , "HoldId": HoldId_out  
      , "FileTypeId":14
            }
      self._HoldsService.CreateOrUpdateholdTranfer(parameters3).subscribe(
        (data) => {
        
        if (data.responseMessage == '') {
          self.NoticeHoldfileId=data.holdFileId;
          self.NoticefileTransferId=data.holdFileTransferId;
          self.s3NoticeFileName=data.s3FileName;
        // this.SpinnerService.hide();
        }
        if(self.NoticeHoldfileId==-1)
        {
          self.notifier.notify("error","Preservation notice - Upload failed to S3");
        }
        else{            
         self.triggerHoldsFileUploadProcess(self.NoticeHoldfileId, self.NoticefileTransferId, value.NoticeFileIDArray , value.NoticeNameArray, value.NoticeSizeArray, self.s3NoticeFileName);
        }
        },
        err => {
        // this.SpinnerService.hide();
        });

    })
    
    //Attachmet file Upload
    
    this.$AttachmentArray.filter(f=>f.AttachmentFileIDArray!="0").forEach(function(value){
        var parameters2 = {
          "HoldFileId":0
        , "HoldFileTransferId":0
        , "HoldFileName": value.AttachmentNameArray
        , "HoldSize":value.AttachmentSizeArray
        , "HoldId": HoldId_out   
        , "FileTypeId":15}
      
      self.NoAttachmentFileFlag=false;

      setTimeout(() => {  
      self._HoldsService.CreateOrUpdateholdTranfer(parameters2).subscribe
          (
            (data) => 
            {
              if (data.responseMessage == '') 
              {
                  self.AttchmentHoldfileId=data.holdFileId;
                  self.AttchmentTransferId=data.holdFileTransferId;
                  self.s3AttachmentFileName=data.s3FileName;
               // this.SpinnerService.hide();
              }          
              if(self.AttchmentHoldfileId==-1)
              {
                self.notifier.notify("error","Attachment File Upload failed to S3");
              }
              else
              {            
                self.triggerHoldsFileUploadProcess(self.AttchmentHoldfileId, self.AttchmentTransferId, value.AttachmentFileIDArray , value.AttachmentNameArray, value.AttachmentSizeArray, self.s3AttachmentFileName);
              }
            },
          
            err => {
             // this.SpinnerService.hide();
            }
          );
          },3000)
        });

    }
  NavigatetoSearchholds(){
    this.Cleardata();
      this.router.navigate(['/admin/adminsidenavbar/holds/holdsearch']);
  }

  MatterEverGreenRadio(value:boolean)
  {    
    if(value==true){
    this.enableDateforMatterEnergreen=true;}
    else{
      this.enableDateforMatterEnergreen=false;
    }
  }

  ShowCancellationTextbox(value:boolean)
  {   
    if(value==true){
    var currentDate = new Date();
    this.effmatterCD = currentDate;
    this.minDate = currentDate;
    this.maxDate = new Date(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate() + 29);
    this.ShowCancellationTextBox=true;}
    else{
      this.effmatterCD=null;
      this.ShowCancellationTextBox=false;
    }
  }

  
  onChangeEventFunc(buisnessName, isChecked: boolean) {
    this.selectedBuisnessvalue=buisnessName;
    if(isChecked==true){
    this.customRulesBuisness.push(this.selectedBuisnessvalue);  
    this.ErrorMsgFlagForEmptyBusiness=false; 
    }
    else{
      this.customRulesBuisness.pop(); 
      this.ErrorMsgFlagForEmptyBusiness=true;  
    }
    this.BuisnessNameString="";
    for (var index in this.customRulesBuisness) {
      if(this.BuisnessNameString!="")
      {
        this.BuisnessNameString= this.BuisnessNameString +","+this.customRulesBuisness[index];
      }
      else{
        this.BuisnessNameString= this.customRulesBuisness[index];
      }
      
    }
    if(this.BuisnessNameString!="")
    {
      this.EnableCreateHoldButtonForBusiness=true;
    }
    else{
      this.EnableCreateHoldButtonForBusiness=false;
    }

  }


  
  //FileUploadStep 9:
  //Pass meta data fielId, archiveFileId and fileTransferId to upload process
  //Triggers file upload process using FileUploadProcessService service
  //For each upload new instance of FileUploadProcessService is created
  triggerHoldsFileUploadProcess(HoldfileId: any, fileTransferId: any, fileId: any, Name: any, Size: any, s3FileName: any) {
    var self = this;

    self._fuEventService.fileArray.push({
      module: self.module,
      fileId: fileId,
      fileName:Name,
      s3NoticeFileName: s3FileName,
      fileSize: Size,
      eTag: "",
      uploadId: "",
      uploadPercentage: "",
      uploadStatus: "add",
      uploadMessage: "",
      errorMessage: "",
      uploadRemaingTime: "",
      sunits: "",
      tunits: "",
      metaData: {}
    });

    var metaData = {
      ArchiveFileId: HoldfileId.toString(),
      FileTransferId: fileTransferId.toString()      
    }

    var fileUploadProcessService = new FileUploadProcessService(
      self._fuService,
      self._fuEventService,
      self.SpinnerService,
      fileId,
      s3FileName,
      metaData
    );
      let fileElement = document.getElementById(fileId);
      fileUploadProcessService.uploadFile(fileElement);

    }

    convertstringTodateObj(val:any){
      let dateObj:any;
      dateObj = {
        "year": parseInt(val.split("-")[0]),
        "month": parseInt(val.split("-")[1]),
        "day": parseInt(val.split("-")[2])
      }

      return dateObj
    }
}
  

