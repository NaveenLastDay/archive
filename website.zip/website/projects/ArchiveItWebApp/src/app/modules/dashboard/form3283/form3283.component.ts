import { Component, OnInit } from '@angular/core';
import { ArchiveService } from '../../../services/archive.service';
// import { NgxSpinnerService } from 'ngx-spinner';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { Router } from '@angular/router';
import { SharedService } from '../../../services/shared.service';

@Component({
  selector: 'app-form3283',
  templateUrl: './form3283.component.html',
  styleUrls: ['./form3283.component.css']
})
export class Form3283Component implements OnInit {
  employeeUniqueIdentifier: string;
  appendArchiveToGrid: boolean = false;
  archives: any[];
  totalArchives: number = 0;
  currentPageNumber: number = 1;
  archiveNumber: string;
  pageSize: number = 10;
  archiveIDForChild: any;
  pageCount: number = 10;
  redColor: any;
  orangeColor: any;
  yellowColor: any;
  form3283Data: any;
  
  constructor(private archiveService: ArchiveService,private sharedService: SharedService, private router: Router, private adalSvc: MsAdalAngular6Service) { 
    // this.SpinnerService.show();
  }

  ngOnInit() {
    this.employeeUniqueIdentifier = this.adalSvc.LoggedInUserEmail.split('@')[0];
    this.getForm3283Data();
  }
  getForm3283Data() {
    this.archiveService.GetForm3283S(this.currentPageNumber, this.pageSize).subscribe((data) => {
      this.form3283Data = data;
      // this.redColor = data.filter((ele) => ele.due == 'Red');
      // this.orangeColor = data.filter((ele) => ele.due == 'Orange');
      // this.yellowColor = data.filter((ele) => ele.due == 'Yellow');
      if(this.form3283Data.length > 0) {
      this.redColor = data[0].countRed;
        this.orangeColor = data[0].countOrange;
        this.yellowColor = data[0].countYellow;
      }
        if (this.appendArchiveToGrid && data) {
          this.archives = this.archives.concat(data);
        }
        else {
          this.archives = data ? data : [];
        }
        if(this.form3283Data.length > 0) {
        this.totalArchives = this.archives[0]["count"];
        }
        // console.log('array length', this.totalArchives);
        // this.SpinnerService.hide();
      });
  }
  disableBack() {
    window.history.forward();
  }
  archiveID(event) {
    this.archiveIDForChild = event;
    // console.log('from child', event);
  }
  updateGridData(event) {
    this.appendArchiveToGrid = event.isLoadMoreClicked;
    this.currentPageNumber = event.pageNumber;
    this.getForm3283Data();
  }
  showArchiveDetails(archiveNumber, index) {
    if (this.archiveNumber == archiveNumber) {
      this.archiveNumber = '';
    }
    else {
      this.archiveNumber = archiveNumber;
    }
  }
  accessArchive(archiveNumber: string) {
    // this.SpinnerService.show();
    this.router.navigate(['/archive/myarchives', archiveNumber]);
  }
  exportToExcel() {
    // this.SpinnerService.show();
            let columns = [
          'Archive #',
          'Client',
          'Archive Name',
          'Period End',
          'WBS #',
          'EDCD',
          'Proposed ADCED',
          'Engagement Type',
          'RDCD',
          'Is Resubmission in Progress ?',
          'Archive Description',
          'Entity associated with archive',
          'Professional Standards Applied',
          'Reporting Entity',
          'Archive Partner',
          'Archive Manager',
          'Archive Field Senior',
          'Additional Archive Field Senior',
      ];
    this.archiveService.form3283ExportToExcel(0, this.totalArchives).subscribe((data) => {
          data.forEach(elm=> {
        delete elm.count;
        delete elm.rowNumber;
        delete elm.due;
        delete elm.archiveStatus;
        delete elm.countOrange;
        delete elm.countRed;
        delete elm.countYellow;
      });
      // this.SpinnerService.hide();
      var result = data.map(o => Object.keys(o).map(k => o[k]));
      if (data && data.length) {
        this.sharedService.generateExcel("Forms 3283S", "Forms 3283S", columns,result );
      }
     },
     error => {
       console.log('Exception occured ' + JSON.stringify(error));
      //  this.SpinnerService.hide();
     });
   
  } 
  openForm3283(archiveNumber) {
    this.router.navigate(['/archive/myarchives/'+archiveNumber+'/form3283S']);
  }
}
