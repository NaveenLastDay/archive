import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';

@Component({
  selector: 'app-admintiles',
  templateUrl: './admintiles.component.html',
  styleUrls: ['./admintiles.component.css']
})
export class AdmintilesComponent implements OnInit {

  currentUrl: string;


  constructor(private router: Router) {
      router.events.subscribe((_: NavigationEnd) => this.currentUrl = this.router.url);
    }

    OnAdminTileClick(menuItem:any)
    {
      this.router.navigate(["/" + menuItem]);
    }

    ngOnInit() {

    }

}
