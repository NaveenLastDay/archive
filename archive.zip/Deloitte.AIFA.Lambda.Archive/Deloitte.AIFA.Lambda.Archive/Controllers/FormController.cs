﻿using Deloitte.AIFA.DomainServices.Contracts;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Deloitte.AIFA.DomainEntities;
using System;
using Microsoft.AspNetCore.Http;
using Amazon.Lambda.Core;
using System.Linq;
using Deloitte.AIFA.DataModels;
using System.Collections.Generic;
using Deloitte.AIFA.ICloudServices;
using Newtonsoft.Json;

namespace Deloitte.AIFA.Lambda.Archive.Controllers
{
    [Route("api/form")]
    [ApiController]
    public class FormController : ControllerBase
    {
        IFormService _formService;
        ILogger _logger { get; set; }
        private readonly IHttpContextAccessor _contextAccessor;
        private string userAlias;
        private List<RoleFunction> roleFunctions;
        private readonly IUtilityService _utilityServie;

        public FormController(IHttpContextAccessor contextAccessor, IFormService formService, ILogger<FormController> logger, ICloudCacheService cloudCacheService, IUtilityService utilityServie)
        {
            _logger = logger;
            _formService = formService;
            this._contextAccessor = contextAccessor;
            this._utilityServie = utilityServie;

            _logger.LogInformation("Form Detail Controller Initiated");
            try
            {
                LambdaLogger.Log("Inside Form Controller");
                var _context = this._contextAccessor.HttpContext;
                try
                {
                    if (_context?.User?.Claims.Any() == true)
                    {
                        LambdaLogger.Log("Has claims in Form Controller");
                        foreach (var claim in _context?.User?.Claims)
                        {
                            //LambdaLogger.Log(claim.Type);
                            if (claim.Type == "UserAlias")
                            {
                                userAlias = claim.Value.Split('@')[0].ToString();
                            }
                            LambdaLogger.Log("User Alias from Form Controller," + userAlias);
                        }
                    }
                    else
                    {
                        LambdaLogger.Log("Has No claims");
                    }
                }
                catch (Exception ex)
                {
                    LambdaLogger.Log("Error with Http context in Form controller: " + ex.Message);
                }
            }
            catch (Exception e)
            {
                LambdaLogger.Log("Error in Form controller: " + e.Message);
            }
            try
            {
                CacheRequestModel cacheRequestModel = new CacheRequestModel();

                cacheRequestModel.Key = "RoleFunctions";
                _logger.LogInformation("RoleFunctions Cache RequestModelKey from Form Controller : " + System.Web.HttpUtility.HtmlEncode(cacheRequestModel.Key));
                var data = cloudCacheService.GetValue(cacheRequestModel);

                if (data == null)
                {
                    roleFunctions = utilityServie.GetRoleFunctions();
                    cacheRequestModel.Value = JsonConvert.SerializeObject(roleFunctions);
                    _logger.LogInformation("RoleFunctions Cache Model Value from Form Controller : " + System.Web.HttpUtility.HtmlEncode(JsonConvert.SerializeObject(cacheRequestModel.Value)));
                    var val = cloudCacheService.SetValue(cacheRequestModel);
                    _logger.LogInformation("RoleFunctions Cache Service Response from Form Controller : " + System.Web.HttpUtility.HtmlEncode(val.ToString()));
                }
                else
                {
                    roleFunctions = JsonConvert.DeserializeObject<List<RoleFunction>>(data);
                    _logger.LogInformation("RoleFunctions Cache Value from Form Controller : " + System.Web.HttpUtility.HtmlEncode(JsonConvert.SerializeObject(roleFunctions)));
                }

            }
            catch (Exception e)
            {
                _logger.LogError("Exception in Archive controller:" + e.Message);
            }
        }

        [HttpGet]
        [Route("getprepopulateddata")]
        public IActionResult GetPrepopulatedData(string archiveNumber)
        {
            var isValid = _utilityServie.IsUserAuthorizedtoPerformAction(archiveNumber, 0, userAlias, "GetFormDetail");
            if (isValid)
            {
                _logger.LogInformation("GetFormDetails - start");
                var result = _formService.GetFormsPrepopulatedData(archiveNumber, userAlias);
                _logger.LogInformation("GetFormDetails - end");
                return Ok(result);
            }
            else
            {
                _logger.LogInformation("Unauthorized Request Details: Action: Get Existing Archives Details, Object " + System.Web.HttpUtility.HtmlEncode(userAlias));
                return Forbid();
            }
        }

        [HttpPost]
        [Route("submit")]
        public IActionResult CreateOrUpdateForm([FromBody] FormSubmitInfo form)
        {
            form.CreatedBy = userAlias;
            var id = GetFuntionID("Request Form 3283S");
            var isValid = false;
            form = (FormSubmitInfo)_utilityServie.IsUserAuthorizedAndInputIsValid(form.ArchiveNumber, id, userAlias, form, out isValid);
            if (isValid)
            {
                var resultForm = _formService.CreateOrUpdateForm(form);
                _logger.LogInformation("CreateOrUpdateForm");

                _logger.LogInformation("Before calling UpsertEventSource method from CreateArchive action.");
                UpsertEventSource(form.ArchiveNumber, userAlias, 2);

                return Ok(resultForm);
            }
            else
                return Forbid();
        }

        [HttpPost]
        [Route("approve")]
        public IActionResult Approve(ApproveOrRejectFormRequest request)
        {
            request.ApprovedBy = userAlias;
            var id = GetFuntionID("Approve Form 3283S");
            var isValid = false;
            request = (ApproveOrRejectFormRequest)_utilityServie.IsUserAuthorizedAndInputIsValid(request.ArchiveNumber, id, userAlias, request, out isValid);
            if (isValid)
            {
                var result = _formService.ApproveForm(request);
                _logger.LogInformation("Approve Form3283");

                _logger.LogInformation("Before calling UpsertEventSource method from CreateArchive action.");
                UpsertEventSource(request.ArchiveNumber, userAlias, 2);

                return Ok(result);
            }
            else
                return Forbid();
        }

        [HttpPost]
        [Route("reject")]
        public IActionResult Reject(ApproveOrRejectFormRequest request)
        {
            request.RejectedBy = userAlias;
            var id = GetFuntionID("Approve Form 3283S");
            var isValid = false;
            request = (ApproveOrRejectFormRequest)_utilityServie.IsUserAuthorizedAndInputIsValid(request.ArchiveNumber, id, userAlias, request, out isValid);
            if (isValid)
            {
                var result = _formService.RejectForm(request);
                _logger.LogInformation("Reject Form3283");


                _logger.LogInformation("Before calling UpsertEventSource method from CreateArchive action.");
                UpsertEventSource(request.ArchiveNumber, userAlias, 2);

                return Ok(result);
            }
            else
                return Forbid();
        }

        [HttpPost]
        [Route("changeapprover")]
        public IActionResult ChangeApprover(ChangeApproverRequest request)
        {
            request.ChangedBy = userAlias;
            var id = GetFuntionID("Request Form 3283S");
            var isValid = false;
            request = (ChangeApproverRequest)_utilityServie.IsUserAuthorizedAndInputIsValid(request.ArchiveNumber, id, userAlias, request, out isValid);
            if (isValid)
            {
                var result = _formService.ChangeApprover(request);
                _logger.LogInformation("Change Approver for Form3283");

                _logger.LogInformation("Before calling UpsertEventSource method from CreateArchive action.");
                UpsertEventSource(request.ArchiveNumber, userAlias, 2);

                return Ok(result);
            }
            else
                return Forbid();
        }

        #region UpsertEventSource        
        [NonAction]
        private void UpsertEventSource(string metadata, string empAlias, int eventTypeID)
        {
            EventSource eventSource = null, eventSourceOut = null;
            try
            {
                eventSource = new EventSource() { Metadata = metadata, CreatedBy = empAlias, CreatedDate = DateTime.Now, IsProcessed = false, EventTypeID = eventTypeID };
                eventSourceOut = _utilityServie.UpsertEventSource(eventSource);
            }
            catch (Exception ex)
            {
                _logger.LogError(string.Format("Exception occured in UpsertEventSource method ArchiveController. ExceptionMessage: {0}, StackTrace: {1}", ex.Message, ex.StackTrace));
            }
        }
        #endregion UpsertEventSource

        private int GetFuntionID(string functionName)
        {
            var Id = roleFunctions.Where(e => e.FunctionName == functionName).Select(x => x.Id).FirstOrDefault();
            _logger.LogInformation("functionId: " + System.Web.HttpUtility.HtmlEncode(Id.ToString()));
            return Id;
        }
    }
}
