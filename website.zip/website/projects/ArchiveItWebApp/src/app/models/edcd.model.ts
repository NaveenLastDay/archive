export class EdcdModel {
    days: number;
    colorInner: string;
    colorOuter: string;
    date: string;
    time: string;
    archiveDueDateCriteria: string;
    adceddate?: Date;
    archiveDueDate: string;
    deliverableType: string;
    originalDate: string;
    daysOverdue?:boolean;
    formStatus?:string;
    isArchiveApprove?:boolean;
    isArchiveResubmitted?:boolean;
    archiveApprovedDate?:string;
}
