﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
    public class LinkTypes
    {
        public int LinkTypeId { get; set; }
        public string Description { get; set; }
    }
}
