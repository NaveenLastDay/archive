﻿using Deloitte.AIFA.DBHelper;
using Deloitte.AIFA.Models;
using Deloitte.AIFA.Repositories.UtilityHelper;
using System;
using System.Collections.Generic;
using System.Data;

namespace Deloitte.AIFA.Repositories.Transformers
{
    public enum ArchiveFolderField
    {
        ArchiveFolderId,
        ArchiveId,
        ArchiveFolderName
    }

    public enum ArchiveFolderFieldParameter
    {
        [CreateField(Name = "ArchiveId", Direction = ParameterDirection.Input, Type = DbType.Int32)]
        ArchiveId,

        [CreateField(Name = "ArchiveFolderId", Direction = ParameterDirection.Input, Type = DbType.Int32)]
        ArchiveFolderId
    }

    public class ArchiveFolderTransformer : BaseTransformer<ArchiveFolderModel>
    {
        //protected internal static Func<IDataReader, ArchiveFolderEntity, ArchiveFolderEntity> bindExtraFields
        //{
        //    get
        //    {
        //        return (dr, archiveFolder) =>
        //        {
        //            archiveFolder.ArchiveFolderId = Convert.ToInt32(dr[ArchiveFolderField.ArchiveFolderId.ToString()]);
        //            archiveFolder.ArchiveId = Convert.ToInt32(dr[ArchiveFolderField.ArchiveId.ToString()]);
        //            archiveFolder.ArchiveFolderName = dr[ArchiveFolderField.ArchiveFolderName.ToString()].ToString();

        //            return archiveFolder;
        //        };
        //    }
        //}

        internal override ArchiveFolderModel TransformElement(IDataReader dr, Func<IDataReader, ArchiveFolderModel, ArchiveFolderModel> bindExtraFields = null)
        {
            return new ArchiveFolderModel
            {
                ArchiveFolderId = Convert.ToInt32(dr[ArchiveFolderField.ArchiveFolderId.ToString()]),
                ArchiveId = Convert.ToInt32(dr[ArchiveFolderField.ArchiveId.ToString()]),
                ArchiveFolderName = dr[ArchiveFolderField.ArchiveFolderName.ToString()].ToString()
            };
        }
    }
}
