import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'formatFileSize'
})
export class FormatFileSizePipe implements PipeTransform {

  transform(sizeInBytes: number, longForm: boolean = false): string {
    let value = "";
    let type = "";

    if (sizeInBytes >= 1 * 1024 * 1024 * 1024) {
      value = (sizeInBytes / (1024 * 1024 * 1024)).toFixed(2);
      type = "GB";
    }
    else if (sizeInBytes >= 1 * 1024 * 1024) {
      value = (sizeInBytes / (1024 * 1024)).toFixed(2);
      type = "MB";
    }

    else if (sizeInBytes >= 1 * 1024) {
      value = (sizeInBytes / 1024).toFixed(2);
      type = "KB";
    }
    else {
      value = (sizeInBytes).toFixed(2);
      type = "bytes";
    }
    return `${value} ${type}`;
  }
}