import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PartialoutageComponent } from './partialoutage.component';

describe('PartialoutageComponent', () => {
  let component: PartialoutageComponent;
  let fixture: ComponentFixture<PartialoutageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PartialoutageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PartialoutageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
