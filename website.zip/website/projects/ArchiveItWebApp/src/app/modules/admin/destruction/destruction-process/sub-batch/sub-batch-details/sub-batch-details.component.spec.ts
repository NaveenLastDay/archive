import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SubBatchDetailsComponent } from './sub-batch-details.component';

describe('SubBatchDetailsComponent', () => {
  let component: SubBatchDetailsComponent;
  let fixture: ComponentFixture<SubBatchDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SubBatchDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SubBatchDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
