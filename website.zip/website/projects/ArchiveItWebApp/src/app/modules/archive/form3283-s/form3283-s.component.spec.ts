import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Form3283SComponent } from './form3283-s.component';

describe('Form3283SComponent', () => {
  let component: Form3283SComponent;
  let fixture: ComponentFixture<Form3283SComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Form3283SComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Form3283SComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
