﻿using Deloitte.AIFA.DataModels;
using Deloitte.AIFA.DomainEntities;
using System.Collections.Generic;

namespace Deloitte.AIFA.IRepositories
{
    public interface IUtilityRepository
    {
        List<Utility> GetUtilityDetail(string useralias,int rowCount,int filterId,int officeId, string role_code);
        EventSource UpsertEventSource(EventSource eventSource);
        List<RoleFunction> GetRoleFunctions();
        bool IsUserAuthorizedtoPerformAction(string archiveNumber, int functionId, string userAlias, string Keyword = null);
    }
}
