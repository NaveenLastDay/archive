import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ArchivesAwaitingApprovalListComponent } from './archives-awaiting-approval-list.component';

describe('ArchivesAwaitingApprovalListComponent', () => {
  let component: ArchivesAwaitingApprovalListComponent;
  let fixture: ComponentFixture<ArchivesAwaitingApprovalListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ArchivesAwaitingApprovalListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ArchivesAwaitingApprovalListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
