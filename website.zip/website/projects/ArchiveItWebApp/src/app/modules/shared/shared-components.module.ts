import { CustomDatePickerComponent } from './custom-date-picker/custom-date-picker.component';
import { CustomDateRangePickerComponent } from './custom-date-range-picker/custom-date-range-picker.component';
import { ResubmissionReasonsPopupComponent } from './Resubmission-Reasons/ResubmissionReasonspopup';
import { NgModule } from '@angular/core';
import { ListFilterPipe } from './../shared/Pipes/filter-list.pipe';
import { CommonModule } from '@angular/common';
import { NgbModule } from "@ng-bootstrap/ng-bootstrap";
import { FormBuilder, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MyArchviesListItemComponent } from '../archive/my-archvies-list-item/my-archvies-list-item.component';
import { PipeModule } from './Pipes/pipe.module';
import { PaginationComponent } from './pagination/pagination.component';
import { NotifierModule, NotifierOptions } from 'angular-notifier';
import { ExportToExcelComponent } from './export-to-excel/export-to-excel.component';
import { NgxSpinnerModule } from "ngx-spinner";
import { CustomModalModule } from '../shared/modal';
import { WorkingPaperComponent } from '../record/working-paper/working-paper.component'
import { RouterModule } from '@angular/router';
import { FormatFileSizePipe } from "./../shared/Pipes/format-file-size.pipe";
import { ArchiveInfobarComponent } from './archive-infobar/archive-infobar.component';
import { EDCDWidgetComponent } from '../shared/EDCD/edcdwidget.component';
import { NgCircleProgressModule } from 'ng-circle-progress';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';

import {
  MatMenuModule,
  MatButtonModule,
  MatButtonToggleModule,
  MatCheckboxModule,  
  MatFormFieldModule, 
  MatOptionModule, 
  MatInputModule, 
  MatTableModule, 
  MatDatepickerModule, 
  MatDividerModule, 
  MatExpansionModule
} from "@angular/material";
import { AngularEditorModule } from '@kolkov/angular-editor';
import { FileuploadProgressComponent } from "../record/fileUpload-progress/fileupload-progress.component";
import { FileUploadWpModalComponent } from '../record/working-paper/fileupload.wp.modal.component';
import { SubstantiationPopupComponent } from '../record/substantiation-popup/substantiation-popup.component';
import { ResizableModule } from "angular-resizable-element";
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { FormatTimePipe } from './../shared/Pipes/format-time.pipe';
import { PeoplePickerComponent } from './people-picker/people-picker.component';
import { TreeComponent } from './tree/tree.component';
import { PartialoutageComponent } from './partialoutage/partialoutage.component';

const customNotifierOptions: NotifierOptions = {
    position: {
      horizontal: {
        position: "right",
        distance: 12
      },
      vertical: {
        position: "top",
        distance: 12,
        gap: 10
      }
    },
    theme: "material",
    behaviour: {
      autoHide: 500,
      onClick: "hide",
      onMouseover: "pauseAutoHide",
      showDismissButton: true,
      stacking: 1
    },
    animations: {
      enabled: true,
      show: {
        preset: "slide",
        speed: 200,
        easing: "ease"
      },
      hide: {
        preset: "fade",
        speed: 3000,
        easing: "ease-in",
        offset: 50
      },
      shift: {
        speed: 300,
        easing: "ease"
      },
      overlap: 150
    }
  };
  
@NgModule({
    imports: [
      CommonModule,
      BsDatepickerModule.forRoot(),
      NgbModule, 
      CustomModalModule, 
      FormsModule,  
      ReactiveFormsModule, 
      PipeModule,
      NotifierModule.withConfig(customNotifierOptions), 
      NgxSpinnerModule,
      RouterModule,
      MatButtonModule,
      MatButtonToggleModule,
      MatMenuModule,
      AngularEditorModule,
      ResizableModule,
      MatAutocompleteModule,
      MatCheckboxModule,  
      MatFormFieldModule, 
      MatOptionModule, 
      MatInputModule, 
      MatTableModule, 
      MatDatepickerModule, 
      MatDividerModule, 
      MatExpansionModule,
      NgCircleProgressModule.forRoot({

        radius: 100,
        outerStrokeWidth: 16,
        innerStrokeWidth: 8,
        animationDuration: 300,
        "title": [
            "working",
            "in",
            "progress"

        ],
        maxPercent: 100,
        showSubtitle: false,
        showUnits: false
    })
    ],
    declarations: [
      CustomDatePickerComponent,
      ResubmissionReasonsPopupComponent,
      CustomDateRangePickerComponent,
      MyArchviesListItemComponent,
      PaginationComponent,
      ExportToExcelComponent,
      WorkingPaperComponent,
      FormatFileSizePipe,
      ListFilterPipe,
      FileuploadProgressComponent,
      FileUploadWpModalComponent,
      SubstantiationPopupComponent,
      FormatTimePipe,
      ArchiveInfobarComponent,
      EDCDWidgetComponent,
      PeoplePickerComponent,
      TreeComponent,
      PartialoutageComponent 
    ],
    exports: [
      CustomDatePickerComponent,
      ResubmissionReasonsPopupComponent,
      CustomDateRangePickerComponent,
      MyArchviesListItemComponent,
      PaginationComponent,
      ExportToExcelComponent,
      WorkingPaperComponent,
      FormatFileSizePipe,
      FileuploadProgressComponent,
      FileUploadWpModalComponent,
      SubstantiationPopupComponent,
      FormatTimePipe,
      ArchiveInfobarComponent, 
      EDCDWidgetComponent,
      PeoplePickerComponent,
      NgbModule,
      ListFilterPipe
    ]
})
export class SharedComponentsModule { }