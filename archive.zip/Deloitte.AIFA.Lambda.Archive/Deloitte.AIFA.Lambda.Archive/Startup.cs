using Amazon.XRay.Recorder.Handlers.AwsSdk;
using Deloitte.AIFA.Lambda.Logging;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace Deloitte.AIFA.Lambda.Archive
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
            AWSSDKHandler.RegisterXRayForAllServices();
        }

        public static IConfiguration Configuration { get; private set; }

        // This method gets called by the runtime. Use this method to add services to the container
        public void ConfigureServices(IServiceCollection services)
        {
            //services.AddLogging(logging =>
            //{
            //    logging.AddAWSProvider();
            //    logging.SetMinimumLevel(LogLevel.Information);
            //});
           // services.AddAutoMapper(typeof(Startup));

            services.AddCors(options =>
            {
                options.AddPolicy("AllowAnyOriginMethodHeader",
                builder => builder.AllowAnyOrigin()
                                   .AllowAnyMethod()
                                   .AllowAnyHeader());
            });

            //Register Authentication service
            AuthenticationService.Register(services);

            //Register business services
            RegisterServices.Register(services, Configuration);

            services.AddMemoryCache();
            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_1);
            services.AddHttpContextAccessor();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline
        public void Configure(IApplicationBuilder app, IHostingEnvironment env, ILoggerFactory loggerFactory)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseHsts();
            }

            //string basePath = Environment.CurrentDirectory;
            //loggerFactory.AddProvider(new CoreLoggerProvider(basePath));

            app.UseCors("AllowAnyOriginMethodHeader");
            app.UseHttpsRedirection();
            app.UseExceptionHandler("/error/log");
            app.ConfigureCustomException();
            app.UseXRay("ArchiveLambdaXRayTracing");
            app.UseMvc();
        }
    }
}
