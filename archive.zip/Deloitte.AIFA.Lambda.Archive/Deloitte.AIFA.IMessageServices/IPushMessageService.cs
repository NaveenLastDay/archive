﻿using System;

namespace Deloitte.AIFA.IMessageServices
{
    public interface IPushMessageService
    {
        bool PushMesageToQueue(string message);
    }
}
