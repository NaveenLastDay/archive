﻿using Deloitte.AIFA.DomainEntities;
using Deloitte.AIFA.DomainEntities.Report;
using Deloitte.AIFA.Models;
using System;
using System.Collections.Generic;

namespace Deloitte.AIFA.IRepositories
{
    public interface IRateThisAppRepository
    {
        int GetRatingByUserAlias(string userAlias, int applicationId);
        string SubmitRating(RatingSubmissionInfo ratingInfo);
    }
}
