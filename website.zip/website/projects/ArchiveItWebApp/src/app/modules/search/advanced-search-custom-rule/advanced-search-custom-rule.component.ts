import { Component, OnInit, ViewChild, ViewContainerRef } from '@angular/core';
import { Router } from '@angular/router';
import { PeoplePickerService } from '../../../services/MDREmployeeeDetails.service';
import { NgbDateStruct } from "@ng-bootstrap/ng-bootstrap";
import { FormGroup, Validators, FormBuilder, FormArray } from '@angular/forms';
import { ArchiveSearchService } from '../../../services/archive-search.service';
import { SearchEventService } from '../search.event.service';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-advanced-search-custom-rule',
  templateUrl: './advanced-search-custom-rule.component.html',
  styleUrls: ['./advanced-search-custom-rule.component.css']
})
export class AdvancedSearchCustomRuleComponent implements OnInit {

  fromDate: NgbDateStruct;
  toDate: NgbDateStruct;
  estimatedate: any;
  containers = [];
  labeltextfrom: string = 'From';
  labeltextto: string = 'To';
  advancefilter: boolean = true;
  defaultmanager: any;
  archivemanager: string;
  users: Array<any> = [];
  login_form: FormGroup;
  searchResult: Array<any> = [];
  customRules: Array<any> = [];
  selectedManagerViewName: string = "";
  selectedManager: string;
  customRulesFormGroup: FormGroup;
  customRuleFormGroup: FormGroup;
  fieldtype: number;
  index: number = 0;
  constructor(private router: Router, private peoplePickerService: PeoplePickerService, private searchEventService: SearchEventService,
    private fb: FormBuilder, private search: ArchiveSearchService, private SpinnerService: NgxSpinnerService) {
    this.login_form = fb.group({
      'archivemanager': [null, Validators.required],
    });
  }

  ngOnInit() {
    //this.getSearchResults();
    this.searchEventService.deleteClickEvent.subscribe(index => {
      this.customRules = this.customRules.filter(i => i._index != index)
    })
  }

  //For PeoplePicker

  onInputChanged(searchString: string) {
    this.users = [];

    if (searchString.length >= 3) {
      this.users = [];
      this.peoplePickerService.GetPeople(searchString).subscribe(
        (value) => {
          this.users = value;
        },
        (err) => {
          console.log("error is ", err)
        }
      );
    }
    else if (searchString.length == 0) {
      this.users = [];
    }
    else {
      this.users = [];
    }    
    this.SpinnerService.hide();  
  }

  selectedManagerName(partner, index) {
    this.selectedManagerViewName = partner.source.viewValue;
    this.selectedManager = this.users[index].userAlias;
    //change to useralias once lambda is changed.
    this.users = [];
  }

  add() {
    this.containers.push(this.containers.length);
  }


  ///////


  getSearchResults() {
    // debugger;
    this.search.getArchiveSearchResults("Women", "Client").subscribe(result => {
      if (result.length > 0) {
        this.searchResult = result;

      }
      else {
        this.searchResult = null;

      }

    });
  }
  addCustomRule() {
    this.customRules.push({ _index: this.index++ });
  }
  removeCustomRule() {
    this.customRules=[];
  }
  SaveDate(event){}
}
