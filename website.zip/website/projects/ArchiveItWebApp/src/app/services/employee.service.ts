import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { delay, map } from 'rxjs/operators';
import { HttpClient,HttpHeaders } from '@angular/common/http';

export interface Person {
    id: string;
    isActive: boolean;
    age: number;
    name: string;
    gender: string;
    company: string;
    email: string;
    phone: string;
    disabled?: boolean;
}

@Injectable({
    providedIn: 'root'
})
export class EmployeeService {

  apiData: any;
  
    constructor(private _http: HttpClient) {       
    }

    httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
  
      }),
    }



  public getPersonel(personel: string): Observable<any> {
    this.apiData = this._http.get<any>("erp/geterpsearchresults?searchquery=" + personel, this.httpOptions);
    return this.apiData;
  }

  public addPersonel(parameters: any): Observable<any> {
    this.apiData = this._http.post<any>("erp/addengagementpersonnels" , parameters, this.httpOptions);
    return this.apiData;
  }



}


