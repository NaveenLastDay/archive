﻿using Microsoft.AspNetCore.Builder;

namespace Deloitte.AIFA.Lambda.Logging
{
    public static class ExceptionExtension
    {
        public static void ConfigureCustomException(this IApplicationBuilder app)
        {
            app.UseMiddleware<ExceptionMiddleware>();
        }
    }
}
