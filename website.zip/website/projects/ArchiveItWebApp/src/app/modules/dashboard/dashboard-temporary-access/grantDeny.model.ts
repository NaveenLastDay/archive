export class GrantDenyTemporaryArchiveAccess {
    ArchiveAccessRequestId: string;
    GrantDenyReason: string;
    GrantOrDeny: string;
}