﻿using Deloitte.AIFA.DomainEntities;
using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DataModels
{
    public class ArchiveRetentionReasonModel
    {
        public ArchiveRetention ArchiveID { get; set; }
        public RetentionReason  RetentionReasonID { get; set; }
        public ArchiveRetention ExtendRetention { get; set; }
        public ArchiveRetention RetentionExtentionReason { get; set; }
        public ArchiveRetention RetentionTime { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CaretedDate { get; set; }
    }
}
