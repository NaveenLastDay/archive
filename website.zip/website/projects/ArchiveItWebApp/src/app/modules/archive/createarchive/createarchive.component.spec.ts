import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreatearchiveComponent } from './createarchive.component';

describe('CreatearchiveComponent', () => {
  let component: CreatearchiveComponent;
  let fixture: ComponentFixture<CreatearchiveComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreatearchiveComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreatearchiveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
