import { SharedComponentsModule } from './../shared/shared-components.module';
import { HighlightTextPipe } from './../shared/Pipes/highlight-text.pipe';
import { HighlightcolorTextPipe } from './../shared/Pipes/highlight-colortext.pipe';
// import { MyArchviesListItemComponent } from './my-archvies-list-item/my-archvies-list-item.component';
import { MyArchivesComponent } from './my-archives/my-archives.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CreateComponent } from './create/create.component';
import { RouterModule } from '@angular/router';
import { MatCheckboxModule, MatButtonToggleModule,MatFormFieldModule, MatOptionModule, MatInputModule, MatTableModule, MatDatepickerModule, MatDividerModule, MatExpansionModule,MatListModule,MatSidenavModule,MatLineModule,MatSlideToggleModule } from '@angular/material';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { FormBuilder, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NotifierModule, NotifierOptions } from "angular-notifier";
import { CustomModalModule } from '../shared/modal';
import { PeoplePickerFilter } from './create/peoplepickerfilter.pipe';
import { MatButtonModule } from '@angular/material/button';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatTooltipModule } from '@angular/material/tooltip';
import { ArchiveLeftPaneComponent } from './archive-left-pane/archive-left-pane.component';
import { MatIconModule, MatMenuModule } from '@angular/material';
import { AuthenticationGuard } from 'microsoft-adal-angular6';
import { SearchWbsComponent } from './search-wbs/search-wbs.component';
import { ExistingArchivesComponent } from './existing-archives/existing-archives.component';
import { ExistingWbsComponent } from './existing-wbs/existing-wbs.component';
import { CreatearchiveComponent } from './createarchive/createarchive.component';
//import { AddDeliverablesComponent } from './add-deliverables/add-deliverables.component';
import { EngagementDetailsComponent } from './wbs-details/wbs-details.component';
import { EngagementInfoComponent } from './engagement-info/engagement-info.component';
import { WorkingPaperComponent } from '../record/working-paper/working-paper.component'
// import { FormatFileSizePipe } from './../shared/Pipes/format-file-size.pipe';
// import { FormatTimePipe } from './../shared/Pipes/format-time.pipe';
// import { FileuploadProgressComponent } from "../record/fileUpload-progress/fileupload-progress.component";
// import { FileUploadWpModalComponent } from '../record/working-paper/fileupload.wp.modal.component';
import { ArchiveHomeComponent } from './archive-home/archive-home.component';
import { AddDeliverablesComponent } from '../record/deliverables/add-deliverables.component';
import { ArchiveSectionDetailsComponent } from './archive-section-details/archive-section-details.component';
import { RetentionExceptionComponent } from './retention-exception/retention-exception.component';
import { LegalHoldComponent } from './legal-hold/legal-hold.component';
import { ResizableModule } from "angular-resizable-element";
import { ManagearchiveteamComponent } from './managearchiveteam/managearchiveteam.component';
import { MyArchviesFilterPaneComponent } from './my-archvies-filter-pane/my-archvies-filter-pane.component';
import { MatSelectModule } from '@angular/material/select';
import { CKEditorModule } from 'ng2-ckeditor';
import { AngularEditorModule } from '@kolkov/angular-editor';
// import { NgCircleProgressModule } from 'ng-circle-progress';
//import { SubstantiationPopupComponent } from '../record/substantiation-popup/substantiation-popup.component';
import { NgbModule } from "@ng-bootstrap/ng-bootstrap";
// import { EDCDWidgetComponent } from '../shared/EDCD/edcdwidget.component';
// import {CustomDatePickerComponent} from '../shared/custom-date-picker/custom-date-picker.component';
import { NgxSpinnerModule } from "ngx-spinner";
import { GuardModalComponent } from '../record/guard-modal/guard-modal.component';
import { FileuploadProgressGuard } from '../../guards/fileupload-progress-guard.service';
import { LinkedDashboardValidationGuard } from '../../guards/linked-dashboard-validation-guard.service';

import { PipeModule } from '../shared/Pipes/pipe.module';
import { Form3283SComponent } from './form3283-s/form3283-s.component';
import { EngagementPersonnelComponent } from './engagement-personnel/engagement-personnel.component';
//import { TrimSummaryLengthPipe } from '../shared/Pipes/trim-summary-length.pipe';
import { RequestTemporaryAccessComponent } from './request-temporary-access/request-temporary-access.component';
import { ArchiveHistoryComponent } from './archive-history/archive-history.component';
import { ArchivehomeSidenavbarComponent } from './archivehome-sidenavbar/archivehome-sidenavbar.component';
import { LinkedArchivesComponent } from './linked-archives/linked-archives.component';
import { AddLinkedArchivesComponent } from './add-linked-archives/add-linked-archives.component';
import { DeleteArchiveComponent } from './delete-archive/delete-archive.component';
import { BindersComponent } from './binders/binders.component';
import { CanDeActivateGuard } from '../shared/guard/candeactivateguard.guard';


const customNotifierOptions: NotifierOptions = {
    position: {
        horizontal: {
            position: 'right',
            distance: 12
        },
        vertical: {
            position: 'top',
            distance: 12,
            gap: 10
        }
    },
    theme: 'material',
    behaviour: {
        autoHide: 500,
        onClick: 'hide',
        onMouseover: 'pauseAutoHide',
        showDismissButton: true,
        stacking: 1
    },
    animations: {
        enabled: true,
        show: {
            preset: 'slide',
            speed: 200,
            easing: 'ease'
        },
        hide: {
            preset: 'fade',
            speed: 3000,
            easing: 'ease-in',
            offset: 50
        },
        shift: {
            speed: 300,
            easing: 'ease'
        },
        overlap: 150
    }
};
@NgModule({
    declarations: [
        CreateComponent,
        PeoplePickerFilter,
        MyArchivesComponent,
        // MyArchviesListItemComponent,
        HighlightTextPipe,
        HighlightcolorTextPipe,
        SearchWbsComponent,
        ExistingWbsComponent,
        ExistingArchivesComponent,
        CreatearchiveComponent,
        ArchiveLeftPaneComponent,
        AddDeliverablesComponent,
        EngagementDetailsComponent,
        EngagementInfoComponent,
        EngagementPersonnelComponent,
        BindersComponent,
        ArchiveHomeComponent,
        ArchiveSectionDetailsComponent,
        // WorkingPaperComponent,
        // FormatFileSizePipe,
        // FormatTimePipe,
        // FileuploadProgressComponent,
        // FileUploadWpModalComponent,
        RetentionExceptionComponent,
        LegalHoldComponent,
        ManagearchiveteamComponent,
        MyArchviesFilterPaneComponent,
        //SubstantiationPopupComponent,
        // EDCDWidgetComponent,
        Form3283SComponent,
        // CustomDatePickerComponent,
        GuardModalComponent,
        RequestTemporaryAccessComponent,
        ArchiveHistoryComponent,
        ArchivehomeSidenavbarComponent,
        LinkedArchivesComponent,
        AddLinkedArchivesComponent,
        DeleteArchiveComponent
    ],
    imports: [
        CommonModule,
        PipeModule,
        MatCheckboxModule,
        MatButtonToggleModule,
        MatAutocompleteModule,
        MatFormFieldModule,
        MatOptionModule,
        MatInputModule,
        MatTableModule,
        FormsModule,
        ReactiveFormsModule,
        ResizableModule,
        NgxSpinnerModule,
        MatDatepickerModule,
        MatExpansionModule,
        MatListModule,
        MatSidenavModule,
        MatLineModule,
        MatSlideToggleModule,
        NgbModule,
        SharedComponentsModule,
        MatDividerModule, MatTooltipModule, MatToolbarModule, AngularEditorModule,
        CustomModalModule, MatButtonModule, MatMenuModule, MatSelectModule,
        NotifierModule.withConfig(customNotifierOptions), MatIconModule, CKEditorModule,

        // NgCircleProgressModule.forRoot({

        //     radius: 100,
        //     outerStrokeWidth: 16,
        //     innerStrokeWidth: 8,
        //     animationDuration: 300,
        //     "title": [
        //         "working",
        //         "in",
        //         "progress"

        //     ],
        //     maxPercent: 100,
        //     showSubtitle: false,
        //     showUnits: false
        // }),
        RouterModule.forChild(
            [
                { path: "requestAccess/:aN", component: RequestTemporaryAccessComponent, data: { title: 'Request Access', showbreadcrumb: 'true' }, canActivate: [AuthenticationGuard] },
                { path: "create", component: CreateComponent, data: { title: 'Create Archive', showbreadcrumb: 'true' } },
                { path: "myarchives", component: MyArchivesComponent, data: { title: 'My Archives', showbreadcrumb: 'true' }, canActivate: [AuthenticationGuard] },
                { path: "SearchWbs", component: SearchWbsComponent, data: { title: 'Create archive', showbreadcrumb: 'true' }, canActivate: [AuthenticationGuard] },
                { path: "existingWbs/:optionSelectedvalue", component: ExistingWbsComponent, data: { title: 'Existing wbs', showbreadcrumb: 'true' }, canActivate: [AuthenticationGuard] },
                { path: "existingArchives/:optionSelectedvalue", component: ExistingArchivesComponent, data: { title: 'Existing Archives', showbreadcrumb: 'true' }, canActivate: [AuthenticationGuard] },
                { path: "createarchive/:optionWBSNumber", component: CreatearchiveComponent, data: { title: 'Create archive', showbreadcrumb: 'true' }, canActivate: [AuthenticationGuard] },

                //{path:"archive-left-pane", component:ArchiveLeftPaneComponent,data:{title:'Archive Left Pane'}},
                // {path:"adddeliverables", component:AddDeliverablesComponent,data:{title:'Add Deliverables'}},
                {
                    path: "myarchives/:aN", component: ArchiveLeftPaneComponent, canDeactivate: [FileuploadProgressGuard], data: { title: 'Archive Left Pane', showbreadcrumb: 'false' },
                    children: [
                        { path: "", redirectTo: "archivehome", pathMatch: "full" },
                        { path: "engagementDetails/:optionWBSNumber", component: EngagementDetailsComponent, data: { title: 'SWIFT Engagement Details', showbreadcrumb: 'true' } },
                        { path: "engagementinfo", component: EngagementInfoComponent, data: { title: 'Engagement Info', showbreadcrumb: 'true' } },
                        { path: "engagementpersonnel", component: EngagementPersonnelComponent, data: { title: 'Engagement related personnel', showbreadcrumb: 'true' } },
                        { path: "binders", component: BindersComponent, data: { title: 'Binders', showbreadcrumb: 'true' } },
                        { path: "managearchiveteam", component: ManagearchiveteamComponent, canDeactivate:[CanDeActivateGuard], data: { title: 'archive team', showbreadcrumb: 'true' } },
                        { path: "sections", component: ArchiveSectionDetailsComponent, data: { title: 'Archive Sections', showbreadcrumb: 'true' } },
                        { path: "deliverables", component: AddDeliverablesComponent, data: { title: 'Add Deliverables', showbreadcrumb: 'true' } },
                        { path: "linkedarchives", component: LinkedArchivesComponent,canDeactivate: [LinkedDashboardValidationGuard], data: { title: 'Linked archives', showbreadcrumb: 'true' } },
                        { path: "addlinkedarchives", component: AddLinkedArchivesComponent, data: { title: 'Add Linked Archives', showbreadcrumb: 'true' } },
                        { path: "retentionexception", component: RetentionExceptionComponent },
                        { path: "legalhold", component: LegalHoldComponent },
                        { path: "workingpapers/:aN", component: WorkingPaperComponent, data: { title: 'Working papers', showbreadcrumb: 'true' } },
                        { path: "archivehome", component: ArchiveHomeComponent, data: { title: 'Archive home', showbreadcrumb: 'true' } },
                        { path: "form3283S", component: Form3283SComponent, data: { title: 'Form3283S', showbreadcrumb: 'true' } },
                        { path: "archiveHistory", component: ArchiveHistoryComponent },
                        { path: "createarchive/:optionWBSNumber", component: CreatearchiveComponent, data: { title: 'Auto archive', showbreadcrumb: 'true' } },
                        { path: "deletionarchive", component: DeleteArchiveComponent, data: { title: 'Auto archive', showbreadcrumb: 'true' } },
                    ]
                },

            ]
        )
    ],
    providers: [FormBuilder]
})
export class ArchiveModule { }
