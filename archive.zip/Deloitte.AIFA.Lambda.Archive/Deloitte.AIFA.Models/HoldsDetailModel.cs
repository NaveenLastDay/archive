﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.Models
{
    public class HoldsDetailModel
    {
        public string ClientName { get; set; }
        public string ArchiveName { get; set; }
        public string ArchiveNumber { get; set; }
        public string BusinessName { get; set; }
        public DateTime? PeriodEndDate { get; set; }
    }
}
