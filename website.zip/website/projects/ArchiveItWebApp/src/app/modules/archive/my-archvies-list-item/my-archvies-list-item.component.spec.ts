import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MyArchviesListItemComponent } from './my-archvies-list-item.component';

describe('MyArchviesListItemComponent', () => {
  let component: MyArchviesListItemComponent;
  let fixture: ComponentFixture<MyArchviesListItemComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MyArchviesListItemComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyArchviesListItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
