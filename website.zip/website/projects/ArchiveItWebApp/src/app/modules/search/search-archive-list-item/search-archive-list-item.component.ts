import { Component, OnInit, Input } from '@angular/core';
import { ArchiveService } from '../../../services/archive.service';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-search-archive-list-item',
  templateUrl: './search-archive-list-item.component.html',
  styleUrls: ['./search-archive-list-item.component.css']
})
export class SearchArchiveListItemComponent implements OnInit {

  //archiveDetails:any;
  //@Input('archiveNumber') archiveNumber : string;
  @Input('archiveDetails') archiveDetails : any;
  //@Input('entityTypeDescription') entityTypeDescription : string;
  //@Input('professionalStandardDescription') professionalStandardDescription : string;

  constructor(private archiveService : ArchiveService, private SpinnerService: NgxSpinnerService) { }

  ngOnInit() {
    //this.SpinnerService.show();
    // this.archiveService.GetMyArchiveDetails(this.archiveNumber).subscribe(
    //   data => {
    //     this.archiveDetails = data;
    //     this.SpinnerService.hide();
    //   });
  }

}
