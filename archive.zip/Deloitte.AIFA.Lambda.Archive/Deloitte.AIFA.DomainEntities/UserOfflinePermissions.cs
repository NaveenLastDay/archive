﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
    public class UserOfflinePermissions
    {
        public string userAlias { get; set; }
        public string IsEnabled { get; set; }

        public bool IsPartialOutage { get; set; }

        public string OfflinePage { get; set; }
    }
}
