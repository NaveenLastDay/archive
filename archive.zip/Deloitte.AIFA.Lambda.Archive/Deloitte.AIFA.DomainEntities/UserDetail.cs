﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
    public class UserDetail
    {
        public string userAlias { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }
     
        public int employeeRoleId { get; set; }

        public int isManager { get; set; }
        public int isPPD { get; set; }
        public string title { get; set; }

        public string preferredFirstName { get; set; }

    }
}
