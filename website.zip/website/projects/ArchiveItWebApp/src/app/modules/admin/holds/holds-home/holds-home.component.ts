import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-holds-home',
  templateUrl: './holds-home.component.html',
  styleUrls: ['./holds-home.component.css']
})
export class HoldsHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
