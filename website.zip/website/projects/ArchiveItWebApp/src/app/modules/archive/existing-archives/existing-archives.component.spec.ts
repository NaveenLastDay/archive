import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExistingArchivesComponent } from './existing-archives.component';

describe('ExistingArchivesComponent', () => {
  let component: ExistingArchivesComponent;
  let fixture: ComponentFixture<ExistingArchivesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExistingArchivesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExistingArchivesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
