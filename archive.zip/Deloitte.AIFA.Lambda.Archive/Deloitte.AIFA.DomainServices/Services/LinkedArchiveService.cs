﻿using Deloitte.AIFA.DomainEntities;
using Deloitte.AIFA.DomainServices.Contracts;
using Deloitte.AIFA.ICloudServices;
using Deloitte.AIFA.IRepositories;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainServices.Services
{
    public class LinkedArchiveService : BaseService, ILinkedArchiveService
    {
        ILinkedArchiveRepository _linkedArchiveRepository;
        ILogger _logger;
        IMemoryCache _cache;
        public LinkedArchiveService(IMemoryCache cache, IConfigManager configManager,
                              ILinkedArchiveRepository linkedArchiveRepository,
                                ILogger<LinkedArchiveService> logger) : base(cache, configManager)
        {
            _cache = cache;
            _logger = logger;
            _linkedArchiveRepository = linkedArchiveRepository;
        }

        public List<LinkTypes> GetLinkingTypes()
        {
            return _linkedArchiveRepository.GetLinkingTypes();
        }

        public List<LinkedArchives> GetListofLinkedArchiveDetails(string userAlias, string archiveNumber, int pageNumber, int pageSize, int sortBy)
        {
            return _linkedArchiveRepository.GetListofLinkedArchiveDetails(userAlias,archiveNumber, pageNumber, pageSize, sortBy);
        }

        public string InsertLinkedArchiveDetails(string archiveNumber, string linkedArchiveNumber, string createdBy)
        {
            return _linkedArchiveRepository.InsertLinkedArchiveDetails(archiveNumber, linkedArchiveNumber, createdBy);
        }

        public bool UpdateLinkedArchiveDetails(string archiveNumber, string linkedArchiveNumber, int? linkTypeId, string opertaionType, string createdBy)
        {
            return _linkedArchiveRepository.UpdateLinkedArchiveDetails(archiveNumber, linkedArchiveNumber, linkTypeId, opertaionType, createdBy);
        }
    }
}
