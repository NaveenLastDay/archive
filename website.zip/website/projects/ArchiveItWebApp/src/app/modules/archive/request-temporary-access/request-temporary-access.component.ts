import { Component, OnInit, OnDestroy, DoCheck, OnChanges } from '@angular/core';
import { EdcdModel } from '../../../models/edcd.model';
import { archiveInfoService } from '../../../services/archiveinfo.service';
import { ActivatedRoute, Router } from '@angular/router';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { PeoplePickerService } from '../../../services/MDREmployeeeDetails.service';
import { HomePageService } from '../../../services/homepage.service';
// import { NgxSpinnerService } from 'ngx-spinner';
import { bool } from 'aws-sdk/clients/signer';
import { RequestTemporaryArchiveAccess } from './requestAccess.model';
import { NotifierService } from 'angular-notifier';
import { BehaviorSubject } from 'rxjs';
import { distinctUntilChanged, debounceTime } from 'rxjs/operators';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-request-temporary-access',
  templateUrl: './request-temporary-access.component.html',
  styleUrls: ['./request-temporary-access.component.css']
})
export class RequestTemporaryAccessComponent implements OnInit, OnChanges, OnDestroy, DoCheck {
  archiveNumber: any;
  routes: Array<Object> = [];
  employeeUniqueIdentifier: string;
  wbsNumber: string;
  engDescToolTip: string;
  searchArray: any = [];
  requestTemporaryForm: FormGroup;
  count: any = 0;
  addIndex: number;
  isSigningUserDuplicate: boolean[] = [];
  users: Array<any> = [];
  PPMDUsers: Array<any> = [];
  selectedRequestAccessName: any;
  roleData: any = [];
  editMode = true;
  showSelect = new Array<boolean>(this.roleData.length);
  valueCount: number = 0;
  roleName: any = '';
  dataIndex: any;
  showAllExpired: boolean = true;
  showAllActive: boolean = false;
  requestTemporaryArchiveAccess = new RequestTemporaryArchiveAccess();
  sendRequestAccessData: any;
  selectedValFromCoreTeam: any;
  selectedRequestAccessAlias: any;
  isActive: boolean = false;
  isInactive: boolean = false;
  rolecode: string;

  lastSearchKeyword: string = '';
  currentSearchKeyword: string = '';

  private _subject: BehaviorSubject<string> = new BehaviorSubject<string>("");

  constructor(private router: Router, private notifier: NotifierService,private SpinnerService: NgxSpinnerService, private peoplePickerService: PeoplePickerService, private adalSvc: MsAdalAngular6Service, private archiveinfoSvc: archiveInfoService, private activatedRoute: ActivatedRoute, private formBuilder: FormBuilder, private homePageService: HomePageService, route: ActivatedRoute) {
    // this.router.onSameUrlNavigation = 'reload';
    route.params.subscribe(val => {
      if (this.requestTemporaryForm) {
        this.showSelect[this.dataIndex] = false;
        this.requestTemporaryForm.reset();
      }
      this.archiveNumber = this.activatedRoute.snapshot.params.aN;
      this.employeeUniqueIdentifier = this.adalSvc.LoggedInUserEmail.split('@')[0];
      // this.SpinnerService.show();
      this.homePageService.getActiveRolesForRequestAccess(this.archiveNumber).subscribe((data) => {
        console.log('active roles data', data);
        // this.showSelect[this.dataIndex] = false;
        this.roleData = data.map(x => ({ ...x, roleName: '' }));
        this.roleData = this.roleData.filter((ele) => (ele.roleId == 5) || (ele.roleId == 6) || (ele.roleId == 7) || (ele.roleId == 0))
        this.roleData.forEach(element => {
          if (element.roleId == UserRoles.Partner) {
            element.roleName = 'Archive Partner';
          }
          if (element.roleId == UserRoles.Manager) {
            element.roleName = 'Archive Manager';
          }
          if (element.roleId == UserRoles.FieldSenior && element.displayOrder == UserRoles.FieldSeniorOrder) {
            element.roleName = 'Archive Field Senior';
          }
          if (element.roleId == UserRoles.AdditionalFieldSenior && element.displayOrder == UserRoles.AdditionalFieldSeniorOrder) {
            element.roleName = 'Additional Field Senior';
          }
          if (element.roleId == UserRoles.TempPartner) {
            element.roleName = 'TempPartner';
          }
          if (element.roleId == UserRoles.TempManager) {
            element.roleName = 'TempManager';
          }
          if (element.roleId == UserRoles.TempFieldSenior) {
            element.roleName = 'TempFieldSenior';
          }
          if (element.roleId == UserRoles.SigningPartner) {
            element.roleName = 'SigningPartner';
          }
        });
        this.roleData.forEach(ele => {
          if (ele.accessStatus == 0) {
            this.isActive = true;
          }
          if (ele.accessStatus == 1) {
            this.isInactive = true;
          }

        });
        if (!this.isActive && this.isInactive) {
          this.showAllExpired = true;
          this.showAllActive = false;
        } else {
          this.showAllExpired = false;
          this.showAllActive = true;
        }
        // this.SpinnerService.hide();
      });
    });
  }
  ngOnChanges() {
    // console.log('ngonchanes');
  }
  ngOnInit() {
    let element = document.getElementById("customBreadcrumb");
    element.classList.add("custom-breadcrumb");
    let element1 = document.getElementById("spnBreadcrumbTxt");
    element1.classList.add("spn-breadcrumb-text");
    let element2 = document.getElementById("spnLiBreadcrumb");
    element2.classList.add("spn-li-breadcrumb");
    this.requestTemporaryForm = this.formBuilder.group({
      clientname: [''],
      businessPurpose: ['', Validators.required],
      requestAccessUserName: ['', Validators.required]
    });

  }
  ngDoCheck() {
    // this.SpinnerService.hide();
  }
  onInputChanged(searchString: string, rolecode?: string, indexValue?: number) {
    this.showSelect[this.dataIndex] = false;
    this.addIndex = indexValue;
    this.rolecode = rolecode;
    switch (rolecode) {
      case "requestAccessUserName":
        this.rolecode = "RAU";
        break;
    }
    this.currentSearchKeyword = searchString;
    this._subject.next(this.currentSearchKeyword ? this.currentSearchKeyword.trim() : "");

    if (!searchString)
      this.isSigningUserDuplicate[this.addIndex] = false;
    this.users = [];
    if (searchString.length >= 3) {
      this._subject.pipe(
        distinctUntilChanged(),
        debounceTime(500),
      ).subscribe(value => this.getPeople(value))
    }
    else if (searchString.length == 0) {
      this.users = [];
      this.lastSearchKeyword = '';
    }
    else {
      this.users = [];
      this.lastSearchKeyword = '';
    }

    // this.SpinnerService.hide();
  }

  getPeople(searchString: string) {
    if (searchString.length >= 3 && this.lastSearchKeyword != searchString) {
      this.lastSearchKeyword = searchString;
      this.peoplePickerService.GetPeople(searchString).subscribe(
        (value) => {
          this.users = [];
            if (this.currentSearchKeyword.length >= 3) {
              this.users = value.filter(element => {
                if ((element.isPPD == true) || (element.isRco == 1)) {
                  // this.PPMDUsers = value;
                  return value;
                }
              });

            } else {
              this.users = [];
            }
        },
        (err) => {
          console.log("error is ", err)
        }
      );
      this.SpinnerService.hide();
    }
  }
  selectedRequestAccess(alias, partner, index, data) {
    this.selectedRequestAccessName = partner.source.viewValue;
    this.selectedRequestAccessAlias = alias;
    // this.selectedPartner = this.users[index].userAlias;//change to useralias once lambda is changed.
  }
  selectField(event, i) {
    this.users = [];
    this.requestTemporaryForm.patchValue({ "requestAccessUserName": event });
    if(event !== '') {
    this.peoplePickerService.GetPeople(event).subscribe(
      (value) => {
        value.forEach(element => {
          this.selectedRequestAccessAlias = element.userAlias;
        });
      },
      (err) => {
        console.log("error is ", err)
      }
    );
    this.SpinnerService.hide();
  }
    console.log('name field', event);
    this.editMode = true;
    this.showSelect.fill(false);
    this.showSelect[i] = true;
    this.dataIndex = i;
  }
  onKeyUp(event) {
    this.valueCount = event.target.value.length;
  }
  goToHome() {
    this.router.navigate(['/home']);
  }
  ngOnDestroy() {
    this.requestTemporaryForm.reset();
    this.requestTemporaryForm.patchValue({ "requestAccessUserName": '' });
    this.requestTemporaryForm.patchValue({ "businessPurpose": '' });
    let element = document.getElementById("customBreadcrumb");
    element.classList.remove("custom-breadcrumb");
    let element1 = document.getElementById("spnBreadcrumbTxt");
    element1.classList.remove("spn-breadcrumb-text");
    let element2 = document.getElementById("spnLiBreadcrumb");
    element2.classList.remove("spn-li-breadcrumb");
  }
  sendRequestAccess() {
    // this.SpinnerService.show();
    this.requestTemporaryArchiveAccess.ArchiveNumber = this.archiveNumber;
    this.requestTemporaryArchiveAccess.Description = this.requestTemporaryForm.value.businessPurpose;
    this.requestTemporaryArchiveAccess.DispositionTypeId = 0;
    this.requestTemporaryArchiveAccess.RequestedBy = '';
    this.requestTemporaryArchiveAccess.RequestedOf = this.selectedRequestAccessAlias;
    this.homePageService.CreateTempArchiveAccessRequest(this.requestTemporaryArchiveAccess).subscribe((data) => {
      this.sendRequestAccessData = data;
      if (this.sendRequestAccessData.message == "You already sent request to this user.") {
        this.notifier.notify("error", "You already sent request to this user.");
      } else {
        this.notifier.notify("success", "Access request has been raised successfully.");
        setTimeout(() => {
          this.router.navigate(['/home']);
        }, 4000)
      }
      // this.SpinnerService.hide();
    });
  }
  // checkSize() {
  //       let element = document.getElementById("applicationFooter_ID");
  //       element.classList.add("mt-25");
  // }
}
enum UserRoles {
  FieldSeniorOrder = 0,
  AdditionalFieldSeniorOrder = 1,
  TempPartner = 3,
  TempManager = 4,
  TempFieldSenior = 2,
  Partner = 5,
  Manager = 6,
  FieldSenior = 7,
  AdditionalFieldSenior = 7,
  SigningPartner = 27
}