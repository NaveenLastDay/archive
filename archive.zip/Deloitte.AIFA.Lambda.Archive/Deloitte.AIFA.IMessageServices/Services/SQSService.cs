﻿using Amazon;
using Amazon.SQS;
using Amazon.SQS.Model;
using Deloitte.AIFA.DataModels;
using Deloitte.AIFA.IMessageServices.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Deloitte.AIFA.IMessageServices.Services
{
	public class SQSService: ISQSService
	{
		private readonly AmazonSQSClient _sqsClient;
		private readonly string _sqsURL;

		/// <summary>
		/// constructor for SQSService
		/// </summary>
		public SQSService(string Region, string SQSURL)
		{
			AmazonSQSConfig config = new AmazonSQSConfig()
			{
				RegionEndpoint = (!String.IsNullOrWhiteSpace(Region)) ? RegionEndpoint.GetBySystemName(Region) : throw new ArgumentNullException("Region cannot be null."),
				SignatureVersion = "V4"
			};
			_sqsClient = new AmazonSQSClient(config);
			_sqsURL = SQSURL;
		}

		/// <summary>
		/// DeleteMessageBatchAsync
		/// </summary>
		/// <param name="entries"></param>
		/// <returns></returns>
		public Task<DeleteMessageBatchResponse> DeleteMessageBatchAsync(IList<DeleteMessageBatchRequestModel> entries)
		{
			if (entries.Count > 10) throw new ArgumentException("Entries cannot be more than 10.");

			var request = new DeleteMessageBatchRequest()
			{
				QueueUrl = _sqsURL,
				Entries = entries.Select(m => new DeleteMessageBatchRequestEntry()
				{
					Id = m.Id,
					ReceiptHandle = m.ReceiptHandle
				}).ToList()
			};

			return _sqsClient.DeleteMessageBatchAsync(request);
		}

		/// <summary>
		/// ReceiveMessageAsync
		/// </summary>
		/// <returns></returns>
		public Task<ReceiveMessageResponse> ReceiveMessageAsync()
		{
			var request = new ReceiveMessageRequest()
			{
				MaxNumberOfMessages = 10,
				QueueUrl = _sqsURL,
				WaitTimeSeconds = 20,
				VisibilityTimeout = 30
			};

			return _sqsClient.ReceiveMessageAsync(request);
		}

		/// <summary>
		/// SendMessageAsync
		/// </summary>
		/// <param name="model"></param>
		/// <returns></returns>
		public Task<SendMessageResponse> SendMessageAsync(SendMessageRequestModel model)
		{
			if (model == null) throw new ArgumentNullException("send request model cannot be null.");

			var request = new SendMessageRequest()
			{
				MessageBody = model.MessageBody,
				QueueUrl = _sqsURL
			};
			return _sqsClient.SendMessageAsync(request);
		}

		/// <summary>
		/// SendMessageBatchAsync
		/// </summary>
		/// <param name="entries"></param>
		/// <returns></returns>
		public Task<SendMessageBatchResponse> SendMessageBatchAsync(IList<SendMessageRequestModel> entries)
		{
			var request = new SendMessageBatchRequest()
			{
				QueueUrl = _sqsURL,
				Entries = entries.Select(e => new SendMessageBatchRequestEntry()
				{
					MessageBody = e.MessageBody
				}).ToList()
			};
			return _sqsClient.SendMessageBatchAsync(request);
		}
	}
}
