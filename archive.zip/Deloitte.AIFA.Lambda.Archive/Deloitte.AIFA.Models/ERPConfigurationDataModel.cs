﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DataModels
{
    public class ERPConfigurationDataModel
    {
       public string ERPDataKey {get;set;}
         public string ERPDataValue { get; set; }

    }
}
