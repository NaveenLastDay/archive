import { Injectable } from '@angular/core';
import { async } from '@angular/core/testing';
import { AppConfig } from '../services/appconfig.service';

@Injectable({
  providedIn: 'root'
})
export class AnalyticsService {
  private title: string;
  private userName: string;
  constructor() { }

  private getDTMScript() {
    const DTMScriptInfo: HTMLScriptElement = document.createElement('script'),
      previousEl: HTMLElement = document.getElementById('DTMInfo');
    DTMScriptInfo.type = 'text/javascript';
    DTMScriptInfo.setAttribute('id', 'DTMInfo');
    if (previousEl) {
      document.getElementsByTagName('body')[0].removeChild(previousEl);
    }
    return DTMScriptInfo;
  }
  // this function need to call each time after navigate to another page
  public updateDTMPageInfo(title?: string, userName?: string): void {
     console.log("Flow Track => Before forming anlaytics object");
    const DTMScriptInfo: HTMLScriptElement = this.getDTMScript();
    if (title || userName) {
      this.title = title;
      this.userName = userName;
    }
    DTMScriptInfo.text = `var analyticsDataLayer = {
				'pageInfo': {
					'pageName': '${this.title || 'home'}',
                    'userID': '${this.userName}',
                    'applicationName': "Archive It Audit" 
				}
			};
      `;
    this.updateScriptInfo(DTMScriptInfo);
    

  }

//   public triggerDTMAction(action) {
//     const DTMScriptInfo: HTMLScriptElement = this.getDTMScript();
//     DTMScriptInfo.text = `var analyticsDataLayer = {
// 				'pageInfo': {
// 					'pageName': '${this.title || 'home'}',
// 					'userID': '${this.userName}',
//           'customAction': '${action}'
// 				}
// 			};
//       `;
//     this.updateScriptInfo(DTMScriptInfo);
//     (<any> window)._satellite.track('customActions');
//   }
//   public triggerEngDTMAction(action, nameid) {
//     const DTMScriptInfo: HTMLScriptElement = this.getDTMScript();
//     DTMScriptInfo.text = `var analyticsDataLayer = {
// 				'pageInfo': {
// 					'pageName': '${this.title || 'home'}',
// 					'userID': '${this.userName}',
// 					'engagementAction': '${action}',
//           'engNameid' : '${nameid}',
// 				}
// 			};
//       `;
//     this.updateScriptInfo(DTMScriptInfo);
//     (<any> window)._satellite.track('engagementActions');
//   }
//   public triggerPresDTMAction(action, nameid) {
//     const DTMScriptInfo: HTMLScriptElement = this.getDTMScript();
//     DTMScriptInfo.text = `var analyticsDataLayer = {
// 				'pageInfo': {
// 					'pageName': '${this.title || 'home'}',
// 					'userID': '${this.userName}',
// 					'presentationAction': '${action}',
//           'presNameid' : '${nameid}',
// 				}
// 			};
//       `;
//     this.updateScriptInfo(DTMScriptInfo);
//     (<any> window)._satellite.track('presentationActions');
//   }
//   public triggerSessionDTMAction(engnameid, sessaction, sessnameid) {
//     const DTMScriptInfo: HTMLScriptElement = this.getDTMScript();
//     DTMScriptInfo.text = `var analyticsDataLayer = {
// 				'pageInfo': {
// 					'pageName': '${this.title || 'home'}',
//           'userID': '${this.userName}',
//           'engNameid' : '${engnameid}',
// 					'sessionAction': '${sessaction}',
//           'sessionNameid' : '${sessnameid}'
// 				}
// 			};
//       `;
//     this.updateScriptInfo(DTMScriptInfo);
//     (<any> window)._satellite.track('sessionActions');
//   }
  
//   public triggerScenarioDTMAction(engamentnameid, sessionnameid, sceaction, scenameid) {
//     const DTMScriptInfo: HTMLScriptElement = this.getDTMScript();
    
//     DTMScriptInfo.text = `var analyticsDataLayer = {
// 				'pageInfo': {
// 					'pageName': '${this.title || 'home'}',
//           'userID': '${this.userName}',          
//           'engNameid' : '${engamentnameid}',					
//           'sessionNameid' : '${sessionnameid}',
// 					'scenarioAction': '${sceaction}',
//           'scenarioNameid' : '${scenameid}'
// 				}
// 			};
//       `;
//     this.updateScriptInfo(DTMScriptInfo);
//     (<any> window)._satellite.track('scenarioActions');
//   }

  private updateScriptInfo(DTMScriptInfo) {
    if (!!document.getElementById('DTMBody')) {
      document.getElementsByTagName('body')[0].insertBefore(DTMScriptInfo, document.getElementById('DTMBody'));
    } else {
      document.getElementsByTagName('body')[0].appendChild(DTMScriptInfo);
    }

    this.adobeSatelliteTrack();

    // if(typeof (<any> window)._satellite ==="undefined")
    // {
    //     this.adobeSatelliteTrack();


    //     console.log("I am from Satellite track");
    //     (<any> window)._satellite.track('pageview');
  
    // }

    // else

    // {
    //     console.log("I am from Timeout satellite");
       
    // }
     
    
  }


//   adobeSatelliteTrack()
//   {
//     setTimeout(() => {
//         (<any> window)._satellite.track('pageview');
//       }, 3000)
//   }

  adobeSatelliteTrack()
  {
    
        setTimeout(() => {
            if(!(typeof (<any> window)._satellite ==="undefined")) // Object exist
            {
            (<any> window)._satellite.track('pageview');
            }
            else
            {
                this.adobeSatelliteTrack();
            }
          }, 3000)
  
  }


 
}
