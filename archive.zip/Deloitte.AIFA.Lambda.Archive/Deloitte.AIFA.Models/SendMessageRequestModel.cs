﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DataModels
{
	public class SendMessageRequestModel
	{
		private string _messageBody;
		public string MessageBody
		{
			get => _messageBody;
			set => _messageBody = String.IsNullOrWhiteSpace(value) ? null : value.Trim();
		}
	}
}
