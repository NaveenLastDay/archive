﻿using System.Collections.Generic;

namespace Deloitte.AIFA.DomainEntities
{
    public class ArchiveSubmissionStatus
    {
        public bool ReadyToSubmit { get; set; }
        public bool ShowPeoplePicker { get; set; }
        public bool ShowDatePicker { get; set; }
        public bool Isverificationsuccess { get; set; }
        public bool CanApprove { get; set; }
        // ArchieveSectionStatus
        public string EngagementDetailsStatus { get; set; }
        public WorkingPapersStatus WorkingPaperStatus { get; set; }
        public DeliverablesStatus DeliverableStatus { get; set; }
        public LinkedArchivesStatus LinkedArchiveStatus { get; set; }
        public BindersStatus BinderStatus { get; set; }
        public string RelatedArchiveStatus { get; set; }
        public string EngagementrelatedpersonnelStatus { get; set; }
        public RetentionExceptionStatus RetentionExceptionStatus { get; set; }
        public ArchiveDetails ArchiveInfo { get; set; }
        public int MatRoiUpdates { get; set; }
        public EngagementRelatedPersonalStatus EngagementRelatedPersonalStatus { get; set; }
        public List<ArchiveAtcionsForIndividualSections> ArchiveAtcionsForIndividualSections { get; set; }

        public bool OmniaTransferPending { get; set; }

    }

    public class EngagementRelatedPersonalStatus
    {
        public string ERPCount { get; set; }
        public string createdBy { get; set; }
    }
}
