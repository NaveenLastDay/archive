﻿using System;

namespace Deloitte.AIFA.Models
{
    public class ArchiveFolderModel
    {
        public int ArchiveFolderId { get; set; }
        public int ArchiveId { get; set; }
        public int ParentFolderId { get; set; }
        public string ArchiveFolderName { get; set; }
    }
}
