﻿using Deloitte.AIFA.DataModels;
using Deloitte.AIFA.DomainEntities;
using Deloitte.AIFA.IRepositories;
using Deloitte.AIFA.Models;
using Deloitte.AIFA.Repositories.Transformers;
using Microsoft.Extensions.Caching.Memory;
using MySqlConnector;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Deloitte.AIFA.Repositories
{
    public class UtilityRepository : BaseRepository<UtilityField>, IUtilityRepository
    {
        IMemoryCache _cache;
        public UtilityRepository(IMemoryCache cache) : base(cache)
        {
            _cache = cache;
        }

        public List<Utility> GetUtilityDetail(string Term,int RowCount,int filterid,int OfficeId, string rolecode)
        {

            Exception e = new Exception();
            try
            {
                var parameters = Builder.Bind(UtilityFieldParameter.Term).On(Term)
                    .Bind(UtilityFieldParameter.RowCount).On(RowCount)
                    .Bind(UtilityFieldParameter.FilterId).On(filterid)
                    .Bind(UtilityFieldParameter.OfficeId).On(OfficeId)
                    .Bind(UtilityFieldParameter.RoleCode).On(rolecode)
                                 .Build();
                var result = DbHelper.ExecuteReader(
                    "pub_GetEmployeesBySearchTerm", // change  sp based on our condition
                    parameters,
                     dr => new UtilityTransformer().Transform(dr).ToList());


                return _mapper.Map<List<UtilityModel>, List<Utility>>(result);


            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        #region UpsertEventSource
        public EventSource UpsertEventSource(EventSource eventSource)
		{
			var parameters = Builder.Bind(EventSourceFieldParameter.EventSourceID).On(eventSource.EventSourceID)
									.Bind(EventSourceFieldParameter.EventTypeID).On(eventSource.EventTypeID) 
									.Bind(EventSourceFieldParameter.Metadata).On(eventSource.Metadata)
									.Bind(EventSourceFieldParameter.IsProcessed).On(eventSource.IsProcessed)
									.Bind(EventSourceFieldParameter.Date).On(eventSource.CreatedDate)
									.Bind(EventSourceFieldParameter.UserAlias).On(eventSource.CreatedBy)								
									.Build();
			return DbHelper.ExecuteReader(
                "pub_AIFA_UpsertEventSource",
				parameters,
					dr =>
					{
						var eventSourceEntity = new EventSourceTransformer().Transform(dr).FirstOrDefault();

						var eventSrc = _mapper.Map<EventSourceModel, EventSource>(eventSourceEntity);

						return eventSrc;
					});			
		}
        #endregion UpsertEventSource


        public List<RoleFunction> GetRoleFunctions()
        {
            try
            {
                var result = DbReaderHelper.ExecuteReader(
                    "pub_AIFA_RoleFunctions",
                    null,
                        dr => new RoleFunctionTransformer().Transform(dr).ToList());

                return _mapper.Map<List<RoleFunctionModel>, List<RoleFunction>>(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool IsUserAuthorizedtoPerformAction(string archiveNumber, int functionId, string userAlias, string Keyword = null)
        {
            try
            {
                var parameters = new MySqlParameter[]
                {
                    new MySqlParameter("p_ArchiveNumber", MySqlDbType.VarChar) {Value = archiveNumber},
                    new MySqlParameter("p_FunctionID", MySqlDbType.Int32) {Value = functionId},
                    new MySqlParameter("p_UserAlias", MySqlDbType.VarChar) {Value = userAlias},
                    new MySqlParameter("p_Keyword", MySqlDbType.VarChar) {Value = Keyword},
                };
                bool response = false;
                var result = DbHelper.ExecuteReader(
                    "pub_AIFA_IsUserAuthorizedtoPerformAction",
                    parameters,
                    dr =>
                    {
                        while (dr.Read())
                        {
                            response = dr["isAuthorized"] is DBNull ? false : Convert.ToBoolean(dr["isAuthorized"].ToString());
                        }
                        return response;
                    });

                return response;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


    }
}
