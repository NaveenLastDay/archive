import { Component, OnInit } from '@angular/core';
import { UserConfigSettingService } from '../../../guards/user-role-guard.service';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';

@Component({
  selector: 'app-admin-sidenavbar',
  templateUrl: './admin-sidenavbar.component.html',
  styleUrls: ['./admin-sidenavbar.component.css']
})
export class AdminSidenavbarComponent implements OnInit {

  userConfig: any;
  userEmail = this.adalSvc.LoggedInUserEmail;
  userAlias = this.userEmail.substring(0, this.userEmail.lastIndexOf("@"));

  constructor(private _userConfig:UserConfigSettingService, private adalSvc: MsAdalAngular6Service) { 

  }

  ngOnInit() {
    this.userConfig = this._userConfig.FetchLoggedInUser(this.userAlias);
  }

}
