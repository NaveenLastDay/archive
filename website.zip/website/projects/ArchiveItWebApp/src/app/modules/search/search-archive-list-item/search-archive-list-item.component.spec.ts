import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchArchiveListItemComponent } from './search-archive-list-item.component';

describe('SearchArchiveListItemComponent', () => {
  let component: SearchArchiveListItemComponent;
  let fixture: ComponentFixture<SearchArchiveListItemComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchArchiveListItemComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchArchiveListItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
