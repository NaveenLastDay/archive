﻿using Deloitte.AIFA.DomainServices.Contracts;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Deloitte.AIFA.DomainEntities;
using Deloitte.AIFA.PushMessageSNSHelper;
using System;
using Deloitte.AIFA.DomainEntities.Report;
using Deloitte.AIFA.Helpers.ExcelGenerator;
using Microsoft.AspNetCore.Http;
using Deloitte.AIFA.DataModels;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json.Linq;
using Deloitte.AIFA.ICloudServices;
using Newtonsoft.Json;
using Amazon.Lambda.Core;

namespace Deloitte.AIFA.Lambda.Archive
{
    [Route("api/archive")]
    [ApiController]
    public class ArchiveController : ControllerBase
    {
        IArchiveService _archiveService;
        private readonly IS3BucketService _s3BucketService;
        private readonly string _bucketName;
        ILogger _logger { get; set; }
        private readonly IHttpContextAccessor _contextAccessor;
        private readonly string userAlias;
        private readonly IUtilityService _utilityServie;
        //private dynamic context;
        private List<RoleFunction> roleFunctions;

        public ArchiveController(IHttpContextAccessor contextAccessor, IArchiveService archiveServie, ICloudCacheService cloudCacheService,
            ILogger<ArchiveController> logger, IS3BucketService s3BucketService, IUtilityService utilityServie)
        {
            _logger = logger;
            _archiveService = archiveServie;
            _logger.LogInformation("Archive Details Controller Initiated");
            this._contextAccessor = contextAccessor;
            _bucketName = "daifarecordvalstagestor";
            //Environment.GetEnvironmentVariable("stagingbucketname");
            _s3BucketService = s3BucketService;
            this._utilityServie = utilityServie;
            try
            {
                _logger.LogInformation("Inside Archive Controller");
                var _context = this._contextAccessor.HttpContext;
                try
                {
                    if (_context?.User?.Claims.Any() == true)
                    {
                        _logger.LogInformation("Has claims in Archive Controller");
                        foreach (var claim in _context?.User?.Claims)
                        {
                            //_logger.LogInformation(claim.Type);
                            if (claim.Type == "UserAlias")
                            {
                                userAlias = claim.Value.Split('@')[0].ToString();
                            }
                            _logger.LogInformation("User Alias from ArchiveController," + userAlias);
                        }
                    }
                    else
                    {
                        _logger.LogInformation("Has No claims");
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogInformation("Error with Http context in Archive controller: " + ex.Message);
                }
            }
            catch (Exception e)
            {
                _logger.LogInformation("Error in Archive controller: " + e.Message);
            }

            try
            {
                CacheRequestModel cacheRequestModel = new CacheRequestModel();

                cacheRequestModel.Key = "RoleFunctions";
                _logger.LogInformation("RoleFunctions Cache RequestModelKey from Archive Controller : " + System.Web.HttpUtility.HtmlEncode(cacheRequestModel.Key));
                var data = cloudCacheService.GetValue(cacheRequestModel);
                LambdaLogger.Log("cacheLog454345:" + System.Web.HttpUtility.HtmlEncode(data));
                _logger.LogInformation("cacheLog12345678:" + System.Web.HttpUtility.HtmlEncode(data));
                if (data == null)
                {
                    LambdaLogger.Log("cacheLogInside987978:");
                    roleFunctions = utilityServie.GetRoleFunctions();
                    cacheRequestModel.Value = JsonConvert.SerializeObject(roleFunctions);
                    _logger.LogInformation("RoleFunctions Cache Model Value from Archive Controller : " + System.Web.HttpUtility.HtmlEncode(JsonConvert.SerializeObject(cacheRequestModel.Value)));
                    var val = cloudCacheService.SetValue(cacheRequestModel);
                    _logger.LogInformation("RoleFunctions Cache Service Response from Archive Controller : " + System.Web.HttpUtility.HtmlEncode(val.ToString()));
                }
                else
                {
                    LambdaLogger.Log("cacheLogElse65978:");
                    roleFunctions = JsonConvert.DeserializeObject<List<RoleFunction>>(data);
                    LambdaLogger.Log("cacheLog764987: " + JsonConvert.SerializeObject(roleFunctions));
                    _logger.LogInformation("RoleFunctions Cache Value from Archive Controller : " + System.Web.HttpUtility.HtmlEncode(JsonConvert.SerializeObject(roleFunctions)));
                }

            }
            catch (Exception e)
            {
                _logger.LogError("Exception in Cloud Cache Archive Controller:" + e.Message);
            }

        }

        [HttpGet]
        [Route("GetArchiveDetail")]
        public IActionResult GetArchiveDetail(int archiveId)
        {
            //Archive details
            var archiveDetail = _archiveService.GetArchiveDetail(archiveId);
            _logger.LogInformation("GetArchiveDetail: " + System.Web.HttpUtility.HtmlEncode(archiveId));
            return Ok(archiveDetail);
        }

        [HttpGet]
        [Route("GetWBSSerchResults")]
        public IActionResult GetWBSSerchResults(string term, int rowcount)
        {
            var wbsSearchResults = _archiveService.GetWBSSerchResults(term, rowcount);
            _logger.LogInformation("GetArchiveDetail: " + System.Web.HttpUtility.HtmlEncode(term));
            return Ok(wbsSearchResults);
        }
        [HttpGet]
        [Route("GetWBSDetails")]
        public IActionResult GetWBSDetails(string wbsLevelOne)
        {
            var wbsResults = _archiveService.GetWBSDetails(wbsLevelOne);
            _logger.LogInformation("GetWBSDetails: " + System.Web.HttpUtility.HtmlEncode(wbsLevelOne));
            return Ok(wbsResults);
        }
        [HttpPost]
        [Route("{selectedWBS}")]
        public IActionResult Gets(string selectedWBS)
        {
            _logger.LogInformation("GetArchiveDetail: " + System.Web.HttpUtility.HtmlEncode(selectedWBS));
            return RedirectToAction("", "", selectedWBS);
        }

        [HttpPost("createlegalhold")]
        public IActionResult CreateLegalHold(ArchiveLegalHold archiveLegalHold)
        {
            archiveLegalHold.CreatedBy = userAlias;
            var id = GetFuntionID("Request Legal Hold");
            var isValid = false;
            archiveLegalHold = (ArchiveLegalHold)_utilityServie.IsUserAuthorizedAndInputIsValid(archiveLegalHold.ArchiveNumber, id, userAlias, archiveLegalHold, out isValid);
            if (isValid)
            {
                var result = _archiveService.CreateArchiveLegalHold(archiveLegalHold);

                _logger.LogInformation("Archive legal hold : ArchiveNumber: " + System.Web.HttpUtility.HtmlEncode(archiveLegalHold.ArchiveNumber));
                _logger.LogInformation("Before calling UpsertEventSource method from CreateLegalHold action.");
                UpsertEventSource(archiveLegalHold.ArchiveNumber, userAlias, 2);

                return Ok(result);
            }
            else
            {
                _logger.LogInformation("Unauthorized Request Details: Action: createlegalhold, Object " + System.Web.HttpUtility.HtmlEncode(userAlias));
                return Forbid();
            }
        }

        #region Archive Retention
        [HttpPost("createretention")]
        public IActionResult CreateArchiveRetention(ArchiveRetention archiveRetention)
        {
            archiveRetention.CreatedBy = userAlias;
            var isValid = false;
            archiveRetention = (ArchiveRetention)_utilityServie.IsInputIsSanitized(archiveRetention, out isValid);
            if (isValid)
            {
                var result = _archiveService.CreateArchiveRetention(archiveRetention);

                _logger.LogInformation("Archive retention extended : ArchiveNumber: " + System.Web.HttpUtility.HtmlEncode(archiveRetention.ArchiveNumber));
                _logger.LogInformation("Before calling UpsertEventSource method from CreateArchiveRetention action.");
                UpsertEventSource(archiveRetention.ArchiveNumber, userAlias, 2);
                return Ok(result);
            }
            else
            {
                _logger.LogInformation("Unauthorized Request Details: Action: createretention, Object " + System.Web.HttpUtility.HtmlEncode(userAlias));
                return Forbid();
            }
        }

        [HttpGet]
        [Route("getarchiveretentiondetails")]

        public IActionResult GetArchiveRetentionDetails(string ArchiveNumber)
        {
            _logger.LogInformation("Processing Getretentiondetails method.");
            var id = GetFuntionID("Access Archive");
            var isValid = _utilityServie.IsUserAuthorizedtoPerformAction(ArchiveNumber, id, userAlias);
            if (isValid)
            {
                var archiveRetention = _archiveService.GetArchiveRetentionDetails(ArchiveNumber);
                _logger.LogInformation("Completed processing GetRetentionDetails action method.");
                return Ok(archiveRetention);
            }
            else
            {
                _logger.LogInformation("Unauthorized Request Details: Action: getarchiveretentiondetails, Object " + System.Web.HttpUtility.HtmlEncode(userAlias));
                return Forbid();
            }
        }

        #endregion


        #region Create Archive
        [HttpPost("create")]
        public IActionResult CreateArchive(Deloitte.AIFA.DomainEntities.Archive argArchive)
        {
            Deloitte.AIFA.DomainEntities.Archive archive = null;

            try
            {
                argArchive.ArchiveInfo.Createdby = userAlias;
                _logger.LogInformation("Inside CreateArchive Method");
                var isValid = false;
                argArchive = (Deloitte.AIFA.DomainEntities.Archive)_utilityServie.IsUserAuthorizedAndInputIsValid("", 0, userAlias, argArchive, out isValid, "Create");
                if (isValid)
                {

                    archive = _archiveService.CreateArchive(argArchive);
                    _logger.LogInformation("Archive Created: ArchiveNumber: " + System.Web.HttpUtility.HtmlEncode(archive.ArchiveNumber));
                    _logger.LogInformation("Push Message To SNS");
                    string archiveNumber = archive.ArchiveNumber;

                    _logger.LogInformation("Archive created with " + System.Web.HttpUtility.HtmlEncode(archiveNumber));

                    var result = ProcessMessageOnStatusChange(archiveNumber);
                    if (!result.Item1) throw new Exception(result.Item2);

                    _logger.LogInformation("Before calling UpsertEventSource method from CreateArchive action.");
                    UpsertEventSource(archiveNumber, userAlias, 1);

                }
                else
                {
                    _logger.LogInformation("Unauthorized Request Details: Action: Get Existing Archives Details, Object " + System.Web.HttpUtility.HtmlEncode(userAlias));
                    return Forbid();
                }

            }
            catch (Exception ex)
            {
                _logger.LogInformation(ex.Message);
                Console.WriteLine(ex.Message);
            }
            return Ok(archive);
        }
        #endregion

        #region GetMyArchives        
        [HttpGet]
        [Route("GetMyArchives")]
        //public IActionResult GetMyArchives(int PersonnelNumber, int PageNumber, int PageSize, string SortDirection, string OrderBy, string Search)
        public IActionResult GetMyArchives(int PageNumber = 0, int PageSize = 0, int SortBy = 1, int FilterBy = 0, string FilterText = "")
        {
            _logger.LogInformation("Processing GetMyArchives action method.");
            //var archives = _archiveService.GetMyArchives(PersonnelNumber, PageNumber, PageSize, SortDirection, OrderBy, Search);
            var archives = _archiveService.GetMyArchives(userAlias, PageNumber, PageSize, SortBy, FilterBy, FilterText);
            _logger.LogInformation("Completed processing GetMyArchives action method.");
            return Ok(archives);
        }
        #endregion GetMyArchives

        #region GetMyArchiveDetails        
        [HttpGet]
        [Route("GetMyArchiveDetails")]
        public IActionResult GetMyArchiveDetails(string ArchiveNumber)
        {

            _logger.LogInformation("Processing GetMyArchiveDetails action method.");
            var archiveDetails = _archiveService.GetMyArchiveDetails(ArchiveNumber);
            _logger.LogInformation("Completed processing GetMyArchiveDetails action method.");
            return Ok(archiveDetails);

        }
        #endregion GetMyArchiveDetails

        #region Get Existing Archives Details  
        [HttpGet]
        [Route("GetExistingArchivesDetails")]
        public IActionResult GetExistingArchivesDetails(string wbsLevelOne, int PageNumber, int PageSize)
        {
            //Testing

            var isValid = _utilityServie.IsUserAuthorizedtoPerformAction("", 0, userAlias, "Create");
            if (isValid)
            {
                _logger.LogInformation("Processing GetExistingArchivesDetails action method.");
                var getExistingArchivesDetailsDetails = _archiveService.GetExistingArchivesDetails(wbsLevelOne, userAlias, PageNumber, PageSize);
                _logger.LogInformation("Completed processing GetExistingArchivesDetails action method.");
                return Ok(getExistingArchivesDetailsDetails);
            }
            else
            {
                _logger.LogInformation("Unauthorized Request Details: Action: Get Existing Archives Details, Object " + userAlias);
                return Forbid();
            }
        }
        #endregion GetExistingArchivesDetails

        #region GetArchiveDetailsInfo

        [HttpGet]
        [Route("GetArchiveDetailsInfo")]
        public IActionResult GetArchiveDetailsInfo(string archiveNumber)
        {
            var archiveDetailsInfo = _archiveService.GetArchiveDetailsInfo(archiveNumber, userAlias);
            _logger.LogInformation("GetArchiveDetailsInfo: " + System.Web.HttpUtility.HtmlEncode(archiveNumber));
            return Ok(archiveDetailsInfo);
        }

        [HttpGet]
        [Route("GetEditArchiveDetails")]
        public IActionResult GetEditArchiveDetails(string archiveNumber)
        {
            var id = GetFuntionID("Access Archive");
            var isValid = _utilityServie.IsUserAuthorizedtoPerformAction(archiveNumber, id, userAlias);
            if (isValid)
            {
                var EditArchiveDetails = _archiveService.GetEditArchiveDetails(archiveNumber);
                _logger.LogInformation("GetEngagementDetails: " + System.Web.HttpUtility.HtmlEncode(archiveNumber));
                return Ok(EditArchiveDetails);
            }
            else
            {
                _logger.LogInformation("Unauthorized Request Details: Action: GetEditArchiveDetails, Object " + System.Web.HttpUtility.HtmlEncode(userAlias));
                return Forbid();
            }
        }

        [HttpGet]
        [Route("GetAutoCreateArchiveDetails")]
        public IActionResult GetAutoCreateArchiveDetails(string archiveNumber)
        {
            var id = GetFuntionID("Access Archive");
            var isValid = _utilityServie.IsUserAuthorizedtoPerformAction(archiveNumber, id, userAlias);
            if (isValid)
            {
                var AutoCreateArchiveDetails = _archiveService.GetAutoCreateArchiveDetails(archiveNumber);
                _logger.LogInformation("GetAutoCreateArchiveDetails: " + System.Web.HttpUtility.HtmlEncode(archiveNumber));
                return Ok(AutoCreateArchiveDetails);
            }
            else
            {
                _logger.LogInformation("Unauthorized Request Details: Action: GetAutoCreateArchiveDetails, Object " + System.Web.HttpUtility.HtmlEncode(userAlias));
                return Forbid();
            }
        }

        [HttpPost]
        [Route("UpdateArchiveDetails")]
        public IActionResult UpdateArchiveDetails(UpdateArchive updateArchive)
        {
            var id = GetFuntionID("Manage Archive Info");
            var isValid = false;
            updateArchive = (UpdateArchive)_utilityServie.IsUserAuthorizedAndInputIsValid(updateArchive.ArchiveNumber, id, userAlias, updateArchive, out isValid);
            if (isValid)
            {
                var result = _archiveService.UpdateArchiveDetails(updateArchive);
                try
                {
                    _logger.LogInformation("Manage edit Archive for: ", System.Web.HttpUtility.HtmlEncode(updateArchive.ArchiveNumber));
                    _logger.LogInformation("Push Message To SNS");
                    string input = updateArchive.ArchiveNumber;

                    var resultSNS = ProcessMessageOnStatusChange(updateArchive.ArchiveNumber);
                    if (!resultSNS.Item1) throw new Exception(resultSNS.Item2);

                    _logger.LogInformation("Before calling UpsertEventSource method from CreateArchive action.");
                    UpsertEventSource(updateArchive.ArchiveNumber, userAlias, 2);
                }
                catch (Exception ex)
                {
                    _logger.LogInformation(ex.Message);
                    Console.WriteLine(ex.Message);
                }
                return Ok(result);

            }
            else
            {
                _logger.LogInformation("Unauthorized Request Details: Action: UpdateArchiveDetails, Object " + System.Web.HttpUtility.HtmlEncode(userAlias));
                return Forbid();
            }

        }
        #endregion

        [HttpPost]
        [Route("UpdateArchiveTeam")]
        public IActionResult UpdateArchiveTeam(ArchiveTeam archiveTeam)
        {
            archiveTeam.CreatedBy = userAlias;
            var id = GetFuntionID("Manage Access");
            var isValid = false;
            archiveTeam = (ArchiveTeam)_utilityServie.IsUserAuthorizedAndInputIsValid(archiveTeam.ArchiveNumber, id, userAlias, archiveTeam, out isValid);
            if (isValid)
            {
                var result = _archiveService.UpdateArchiveTeam(archiveTeam, userAlias);
                _logger.LogInformation("Manage Archive Team for: ", System.Web.HttpUtility.HtmlEncode(archiveTeam.ArchiveNumber));


                _logger.LogInformation("Push Message To SNS");
                string archiveNumber = archiveTeam.ArchiveNumber;

                _logger.LogInformation("Archive created with " + System.Web.HttpUtility.HtmlEncode(archiveNumber));

                var output = ProcessMessageOnStatusChange(archiveNumber);
                if (!output.Item1) throw new Exception(output.Item2);

                _logger.LogInformation("Before calling UpsertEventSource method from CreateArchive action.");
                UpsertEventSource(archiveTeam.ArchiveNumber, userAlias, 2);

                return Ok(result);
            }
            else
                return Forbid();
        }

        #region GetMyArchivesFilterDataByType
        [HttpGet]
        [Route("GetMyArchivesFilterDataByFilterType")]
        public IActionResult GetMyArchivesFilterDataByType(int FilterBy)
        {
            _logger.LogInformation("Started processing GetMyArchivesFilterDataByType action method.");
            var archives = _archiveService.GetMyArchivesFilterDataByType(userAlias, FilterBy);
            _logger.LogInformation("Completed processing GetMyArchivesFilterDataByType action method.");
            return Ok(archives);
        }
        #endregion GetMyArchivesFilterDataByType

        #region ArchiveSubmissionStatusDetails
        [HttpGet]
        [Route("GetArchiveSubmissionStatus")]
        public IActionResult GetArchiveSubmissionDetails(string archiveNumber)
        {

            var id = GetFuntionID("Access Archive");
            var isValid = _utilityServie.IsUserAuthorizedtoPerformAction(archiveNumber, id, userAlias);
            if (isValid)
            {
                _logger.LogInformation("Started processing GetArchiveSubmissionDetails action method.");

                if (!string.IsNullOrWhiteSpace(archiveNumber) && !string.IsNullOrWhiteSpace(userAlias))
                {
                    try
                    {
                        var submissioncheck = _archiveService.GetArchiveSubmissionStatus(archiveNumber, userAlias);
                        _logger.LogInformation("Completed processing GetArchiveSubmissionDetails action method.");
                        return Ok(submissioncheck);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex.Message);
                        return BadRequest(ex.Message);
                    }


                }
                else
                {
                    var errorMessage = "Failed to get Archive status. Invalida input parameters";

                    _logger.LogInformation(errorMessage);

                    return BadRequest(errorMessage);
                }
            }
            else
            {
                _logger.LogInformation("Unauthorized Request Details: Action: GetMyArchiveDetails, Object " + userAlias);
                return Forbid();
            }

        }
        #endregion ArchiveSubmissionStatusDetails

        #region ArchiveSubmission

        [HttpPost("createarchivesubmission")]
        public IActionResult CreateArchiveSubmission(ArchiveSubmission archiveSubmission)
        {
            try
            {
                archiveSubmission.CreatedBy = userAlias;
                var id = GetFuntionID("Access Archive");
                var isValid = false;
                archiveSubmission = (ArchiveSubmission)_utilityServie.IsUserAuthorizedAndInputIsValid(archiveSubmission.ArchiveNumber, id, userAlias, archiveSubmission, out isValid);
                if (isValid)
                {
                    var result = _archiveService.CreateArchiveSubmission(archiveSubmission, userAlias);
                    if (result != null)
                    {
                        result.CreatedBy = archiveSubmission.CreatedBy;
                        ProcessMessages(result.ArchiveNumber, archiveSubmission.CreatedBy, result.ArchiveStatus);
                    }
                    _logger.LogInformation("Archive submission for : ArchiveNumber: " + System.Web.HttpUtility.HtmlEncode(archiveSubmission.ArchiveNumber));

                    _logger.LogInformation("Before calling UpsertEventSource method from CreateArchive action.");
                    UpsertEventSource(archiveSubmission.ArchiveNumber, userAlias, 2);

                    return Ok(result);
                }
                else
                {
                    _logger.LogInformation("Unauthorized Request Details: Action: createarchivesubmission, Object " + System.Web.HttpUtility.HtmlEncode(userAlias));
                    return Forbid();
                }
            }
            catch (Exception ex)
            {
                _logger.LogInformation("Archive submission for : ArchiveNumber: " + System.Web.HttpUtility.HtmlEncode(archiveSubmission.ArchiveNumber));
                throw ex;
            }
        }

        private void ProcessMessages(string archiveNumber, string alias, string archiveStatus)
        {
            var result = ProcessMessageOnStatusChange(archiveNumber);
            if (!result.Item1) throw new Exception(result.Item2);

            IList<string> roiNumbers = _archiveService.GetROINumbers(archiveNumber);

            if (archiveStatus == "Approved" || archiveStatus == "Resubmitted – Approved")
            {
                Tuple<bool, string> fileMoveemntNotificationResponse = PushMessageforFileMovement(archiveNumber, alias, archiveStatus, string.Join(",", roiNumbers));
                if (!fileMoveemntNotificationResponse.Item1) throw new Exception(fileMoveemntNotificationResponse.Item2);
            }

            // MAT
            foreach (var number in roiNumbers)
            {
                Tuple<bool, string> reverseFeedNotificationResponse = PushMessageforReverseFeed(number);
                if (!reverseFeedNotificationResponse.Item1) throw new Exception(reverseFeedNotificationResponse.Item2);
            }
        }
        #endregion

        [HttpPost("substantiveresubmissionupdateppdornppd")]
        //public IActionResult SubstantiveResubmissionUpdatePPDorNPPD(string ArchiveNumber, string CreatedBy, string PPDUserAlias, int IsPPD)
        public IActionResult SubstantiveResubmissionUpdatePPDorNPPD(UpdatePPDNPPDDetails PPDNPPDDetails)
        {
            var id = GetFuntionID("Access Archive");
            var isValid = false;
            PPDNPPDDetails = (UpdatePPDNPPDDetails)_utilityServie.IsUserAuthorizedAndInputIsValid(PPDNPPDDetails.ArchiveNumber, id, userAlias, PPDNPPDDetails, out isValid);
            if (isValid)
            {
                var result = _archiveService.SubtantiveResubmissionUpdatePPDorNPPD(PPDNPPDDetails.ArchiveNumber, userAlias, PPDNPPDDetails.PPDUserAlias, PPDNPPDDetails.IsPPD);
                _logger.LogInformation("SubstantiveResubmissionUpdatePPDorNPPD : ", System.Web.HttpUtility.HtmlEncode(PPDNPPDDetails.ArchiveNumber));

                _logger.LogInformation("Before calling UpsertEventSource method from CreateArchive action.");
                UpsertEventSource(PPDNPPDDetails.ArchiveNumber, userAlias, 2);

                return Ok(result);
            }
            else
            {
                _logger.LogInformation("Unauthorized Request Details: Action: createarchivesubmission, Object " + System.Web.HttpUtility.HtmlEncode(userAlias));
                return Forbid();
            }
        }
        [HttpGet("Getsubstantiveresubmissionppdornppd")]
        public IActionResult Getsubstantiveresubmissionppdornppd(string ArchiveNumber)
        {
            var id = GetFuntionID("Access Archive");
            var isValid = _utilityServie.IsUserAuthorizedtoPerformAction(ArchiveNumber, id, userAlias);
            if (isValid)
            {
                var result = _archiveService.SubtantiveResubmissionGetPPDorNPPD(ArchiveNumber);
                _logger.LogInformation("SubstantiveResubmissionGetPPDorNPPD : ", System.Web.HttpUtility.HtmlEncode(ArchiveNumber));
                return Ok(result);
            }
            else
            {
                _logger.LogInformation("Unauthorized Request Details: Action: GetSubstantiveResubmissionPPDorNPPD, Object " + System.Web.HttpUtility.HtmlEncode(userAlias));
                return Forbid();
            }
        }

        #region UpdateEstimatedReleaseDate

        [HttpPost]
        [Route("UpdateEstimatedReleaseDate")]
        public IActionResult UpdateEstimatedReleaseDate(string ArchiveNumber, DateTime EstimatedReleaseDate)
        {
            var id = GetFuntionID("Change Estimated Release Date");
            var isValid = _utilityServie.IsUserAuthorizedtoPerformAction(ArchiveNumber, id, userAlias);
            if (isValid)
            {
                var result = _archiveService.UpdateEstimatedReleaseDate(ArchiveNumber, EstimatedReleaseDate);
                _logger.LogInformation("UpdateEstimatedReleaseDate : ", System.Web.HttpUtility.HtmlEncode(ArchiveNumber));

                _logger.LogInformation("Before calling UpsertEventSource method from CreateArchive action.");
                UpsertEventSource(ArchiveNumber, userAlias, 2);

                return Ok(result);
            }
            else
            {
                _logger.LogInformation("Unauthorized Request Details: Action: UpdateEstimatedReleaseDate, Object " + userAlias);
                return Forbid();
            }
        }

        #endregion

        #region UpdateEarlyTerminationDate

        [HttpPost]
        [Route("UpdateEarlyTerminationDate")]
        public IActionResult UpdateEarlyTerminationDate(EarlyTerminationCeasedDate earlyTerminationDate)
        {

            earlyTerminationDate.ModifiedBy = userAlias;

            var id = GetFuntionID("Upload Record");
            var isValid = false;
            earlyTerminationDate = (EarlyTerminationCeasedDate)_utilityServie.IsUserAuthorizedAndInputIsValid(earlyTerminationDate.ArchiveNumber, id, userAlias, earlyTerminationDate, out isValid);
            if (isValid)
            {
                var result = _archiveService.UpdateEarlyTerminationDate(earlyTerminationDate);
                _logger.LogInformation("UpdateEarlyTerminationDate : ", System.Web.HttpUtility.HtmlEncode(earlyTerminationDate.ArchiveNumber));

                _logger.LogInformation("Before calling UpsertEventSource method from CreateArchive action.");
                UpsertEventSource(earlyTerminationDate.ArchiveNumber, userAlias, 2);

                return Ok(result);
            }
            else
            {
                _logger.LogInformation("Unauthorized Request Details: Action: UpdateEarlyTerminationDate, Object " + System.Web.HttpUtility.HtmlEncode(userAlias));
                return Forbid();
            }
        }

        #endregion

        #region FetchEarlyTerminationDate

        [HttpPost]
        [Route("FetchEarlyTerminationDate")]
        public IActionResult FetchEarlyTerminationDate(EarlyTerminationCeasedDate GetEarlyTerminationDate)
        {
            GetEarlyTerminationDate.ModifiedBy = userAlias;

            var id = GetFuntionID("Access Archive");
            var isValid = false;
            GetEarlyTerminationDate = (EarlyTerminationCeasedDate)_utilityServie.IsUserAuthorizedAndInputIsValid(GetEarlyTerminationDate.ArchiveNumber, id, userAlias, GetEarlyTerminationDate, out isValid);
            if (isValid)
            {
                var result = _archiveService.FetchEarlyTerminationDate(GetEarlyTerminationDate);
                _logger.LogInformation("UpdateEarlyTerminationDate : ", System.Web.HttpUtility.HtmlEncode(GetEarlyTerminationDate.ArchiveNumber));
                return Ok(result);
            }
            else
            {
                _logger.LogInformation("Unauthorized Request Details: Action: FetchEarlyTerminationDate, Object " + System.Web.HttpUtility.HtmlEncode(userAlias));
                return Forbid();
            }
        }
        #endregion


        [HttpPost]
        [Route("InsertTempArciveTeam")]
        public IActionResult InsertTempArciveTeam(TemporaryArchiveTeam archiveTeam)
        {
            var isValid = _utilityServie.IsUserAuthorizedtoPerformAction("", 0, userAlias, "Admin");
            if (isValid)
            {
                archiveTeam.CreatedBy = userAlias;
                var result = _archiveService.InsertTempArciveTeam(archiveTeam);
                _logger.LogInformation("Manage Temporary Archive Team for: ", System.Web.HttpUtility.HtmlEncode(archiveTeam.ArchiveNumber));

                _logger.LogInformation("Before calling UpsertEventSource method from CreateArchive action.");
                UpsertEventSource(archiveTeam.ArchiveNumber, userAlias, 2);

                return Ok(result);
            }
            else
            {
                _logger.LogInformation("Unauthorized Request Details: Action: Manage Temporary Archive Team, Object " + System.Web.HttpUtility.HtmlEncode(userAlias));
                return Forbid();
            }
        }
        [HttpPost]
        [Route("CreateTempArchiveAccessRequest")]
        public IActionResult CreateTempArchiveAccessRequest(RequestTemporaryArchiveAccess requestAccess)
        {
            requestAccess.RequestedBy = userAlias;
            var result = _archiveService.CreateTempArchiveAccessRequest(requestAccess);
            _logger.LogInformation("Create Temporary Archive Access for Archive ID : " + System.Web.HttpUtility.HtmlEncode(requestAccess.ArchiveNumber) + " for " + System.Web.HttpUtility.HtmlEncode(requestAccess.RequestedBy));

            _logger.LogInformation("Before calling UpsertEventSource method from CreateArchive action.");
            UpsertEventSource(requestAccess.ArchiveNumber, userAlias, 2);

            return Ok(result);
        }

        /// <summary>
        /// Grant Deny Temporary Archive Access Request
        /// </summary>
        /// <param name="argGrantDenyAccess"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("GrantDenyTempArchiveAccessRequest")]
        public IActionResult GrantDenyTempArchiveAccessRequest(GrantDenyTemporaryArchiveAccess argGrantDenyAccess)
        {
            var isValid = false;
            argGrantDenyAccess = (GrantDenyTemporaryArchiveAccess)_utilityServie.IsUserAuthorizedAndInputIsValid("", argGrantDenyAccess.ArchiveAccessRequestId, userAlias, argGrantDenyAccess, out isValid, "GrantDenyTempArchiveAccessRequest");
            if (isValid)
            {
                Console.WriteLine("Grant/Deny action is being performed for ArchiveAccessRequestID:" + argGrantDenyAccess.ArchiveAccessRequestId);
                var result = _archiveService.GrantDenyTempArchiveAccessRequest(argGrantDenyAccess, userAlias);
                Console.WriteLine("Grant/Deny action taken successfully for ArchiveAccessRequestID:" + argGrantDenyAccess.ArchiveAccessRequestId);

                //_logger.LogInformation("Create Temporary Archive Access for Archive ID : " + requestAccess.ArchiveNumber + " for " + requestAccess.RequestedBy);
                return Ok(result);
            }
            else
            {
                _logger.LogInformation("Unauthorized Request Details: Action: GrantDenyTempArchiveAccessRequest, Object " + System.Web.HttpUtility.HtmlEncode(userAlias));
                return Forbid();
            }
        }

        [HttpPost]
        [Route("GetTemporaryArchiveAccessRequest")]
        public IActionResult GetTemporaryArchiveAccessRequest(GrantDenyTemporaryArchiveAccess argGrantDenyAccess)
        {
            Console.WriteLine("getting details for ArchiveAccessRequestID:" + argGrantDenyAccess.ArchiveAccessRequestId);
            var result = _archiveService.GetTemporaryArchiveAccessRequest(argGrantDenyAccess);
            Console.WriteLine("Got details successfully for ArchiveAccessRequestID:" + argGrantDenyAccess.ArchiveAccessRequestId);

            //_logger.LogInformation("Create Temporary Archive Access for Archive ID : " + requestAccess.ArchiveNumber + " for " + requestAccess.RequestedBy);
            return Ok(result);
        }

        #region GetMyArchiveAccessRequests        
        [HttpGet]
        [Route("GetArchiveAccessRequestsForApproval")]
        public IActionResult GetArchiveAccessRequestsForApproval(int PageNumber = 0, int PageSize = 0)
        {
            _logger.LogInformation("Processing GetArchiveAccessRequestsForApproval action method.");
            var result = _archiveService.GetArchiveAccessRequestsForApproval(userAlias, PageNumber, PageSize);
            _logger.LogInformation("Completed processing GetArchiveAccessRequestsForApproval action method.");
            return Ok(result);
        }

        [HttpGet]
        [Route("ArchiveAccessRequestDetailsReport")]
        public IActionResult GetArchiveAccessRequestDetailsReport(int PageNumber = 0, int PageSize = 0)
        {
            _logger.LogInformation("Processing GetArchiveAccessRequestsForApproval action method.");
            var result = _archiveService.GetArchiveAccessRequestDetailsReport(userAlias, PageNumber, PageSize);
            var abc = GenerateExcelFile(result, "ArchiveAccessDetails.xlsx");

            IActionResult response;
            //HttpResponseMessage responseMsg = new HttpResponseMessage(HttpStatusCode.OK);
            //responseMsg.Content = new ByteArrayContent(abc);
            //responseMsg.Content.Headers.ContentDisposition = new System.Net.Http.Headers.ContentDispositionHeaderValue("attachment");
            //responseMsg.Content.Headers.ContentDisposition.FileName = "ArchiveAccessDetails.xlsx";
            //responseMsg.Content.Headers.ContentType = new MediaTypeHeaderValue("application/octet-stream");
            //return new FileContentResult(abc, "application/octet-stream");
            return File(abc, "application/vnd.ms-excel", "ArchiveAccessDetails.xlsx");
            //return responseMsg;
            _logger.LogInformation("Completed processing GetArchiveAccessRequestsForApproval action method.");
            long size = 0;

            //var dirInfo = new DirectoryInfo("tmp");

            //foreach (FileInfo fi in dirInfo.GetFiles("*", SearchOption.AllDirectories))
            //{
            //    size += fi.Length;
            //}
            //return Ok(abc);

        }

        [HttpGet]
        [Route("ArchiveAccessRequestsDetails")]
        public IActionResult GetArchiveAccessRequestsDetails(int PageNumber = 0, int PageSize = 0)
        {
            _logger.LogInformation("Processing GetArchiveAccessRequestsForApproval action method.");
            var result = _archiveService.GetArchiveAccessRequestsDetailsReport(userAlias, PageNumber, PageSize);
            //var abc = GenerateExcelFile(result, "ArchiveAccessDetails.xlsx");

            return Ok(result);

        }
        [HttpGet]
        [Route("Form3283ExportToExcel")]
        public IActionResult GetForm3283RequestDetailsToExportToExcel(int PageNumber = 0, int PageSize = 0)
        {
            _logger.LogInformation("Processing GetArchiveAccessRequestsForApproval action method.");
            //_logger.LogInformation("User alias in form 3283 export to excel is " + userAlias +" Page Number "+PageNumber +" Page Size  "+PageSize);
            Console.WriteLine("User alias in form 3283 export to excel is " + userAlias + " Page Number " + PageNumber + " Page Size  " + PageSize);

            var result = _archiveService.GetForm3283RequestDetailsToExportToExcel(userAlias, PageNumber, PageSize);
            //var abc = GenerateExcelFile(result, "ArchiveAccessDetails.xlsx");

            return Ok(result);

        }

        [HttpGet]
        [Route("pendingsubmissionexporttoexcel")]
        public IActionResult GetMyPendingSubmissionDashBoardDataToExcel(int PageNumber = 0, int PageSize = 0)
        {
            _logger.LogInformation("Processing PendingSubmissionExportToExcel action method.");
            //_logger.LogInformation("User alias in form 3283 export to excel is " + userAlias +" Page Number "+PageNumber +" Page Size  "+PageSize);
            Console.WriteLine("User alias in PendingSubmissionExport to excel is " + userAlias + " Page Number " + PageNumber + " Page Size  " + PageSize);

            var result = _archiveService.GetMyPendingSubmissionDashBoardDataToExcel(userAlias, PageNumber, PageSize);
            //var abc = GenerateExcelFile(result, "ArchiveAccessDetails.xlsx");

            return Ok(result);

        }

        [HttpGet]
        [Route("requiringapprovalexporttoexcel")]
        public IActionResult GetMyRequiringApprovalDashBoardDataToExcel(int PageNumber = 0, int PageSize = 0)
        {
            _logger.LogInformation("Processing GetMyRequiringApprovalDashBoardDataToExcel action method.");
            //_logger.LogInformation("User alias in form 3283 export to excel is " + userAlias +" Page Number "+PageNumber +" Page Size  "+PageSize);
            Console.WriteLine("User alias in GetMyRequiringApprovalDashBoardData to excel is " + userAlias + " Page Number " + PageNumber + " Page Size  " + PageSize);

            var result = _archiveService.GetMyRequiringApprovalDashBoardDataToExcel(userAlias, PageNumber, PageSize);
            //var abc = GenerateExcelFile(result, "ArchiveAccessDetails.xlsx");

            return Ok(result);

        }

        [HttpGet]
        [Route("awaitingapprovalexporttoexcel")]
        public IActionResult GetMyAwaitingApprovalDashBoardDataToExcel(int PageNumber = 0, int PageSize = 0)
        {
            _logger.LogInformation("Processing GetMyRequiringApprovalDashBoardDataToExcel action method.");
            //_logger.LogInformation("User alias in form 3283 export to excel is " + userAlias +" Page Number "+PageNumber +" Page Size  "+PageSize);
            Console.WriteLine("User alias in GetMyRequiringApprovalDashBoardData to excel is " + userAlias + " Page Number " + PageNumber + " Page Size  " + PageSize);

            var result = _archiveService.GetMyAwaitingApprovalDashBoardDataToExcel(userAlias, PageNumber, PageSize);
            //var abc = GenerateExcelFile(result, "ArchiveAccessDetails.xlsx");

            return Ok(result);

        }

        [HttpGet]
        [Route("archivedeletionrequestsexporttoexcel")]
        public IActionResult GetDeletionRequestsDashBoardDataToExcel(int PageNumber = 0, int PageSize = 0)
        {
            _logger.LogInformation("Processing GetDeletionRequestsDashBoardDataToExcel action method.");
            Console.WriteLine("User alias in GetDeletionRequestsDashBoardDataToExcel to excel is " + userAlias + " Page Number " + PageNumber + " Page Size  " + PageSize);

            var result = _archiveService.GetDeletionRequestsDashBoardDataToExcel(userAlias, PageNumber, PageSize);

            return Ok(result);

        }


        private byte[] GenerateExcelFile(ArchiveAccessRequestDetailsReport storageReport, string excelFileName)
        {
            XlsxGenerator _xlsxGenerator = new XlsxGenerator();
            var sheets = _archiveService.GetBoxListingReportSheets(storageReport);
            return _xlsxGenerator.GenerateExcelFile(excelFileName, sheets, "//tmp");


        }


        #endregion GetMyArchiveAccessRequests

        [HttpGet]
        [Route("GetArchiveAccessRequestCountForApproval")]
        public IActionResult GetArchiveAccessRequestCountForApproval()
        {
            _logger.LogInformation("Processing GetArchiveAccessRequestsForApproval action method.");
            var result = _archiveService.GetArchiveAccessRequestCountForApproval(userAlias);
            _logger.LogInformation("Completed processing GetArchiveAccessRequestsForApproval action method.");
            return Ok(result);
        }

        [HttpGet]
        [Route("GetForm3283sCountForApproval")]
        public IActionResult GetForm3283sCountForApproval()
        {
            _logger.LogInformation("Processing GetForm3283sCountForApproval action method.");
            var result = _archiveService.GetForm3283sCountForApproval(userAlias);
            _logger.LogInformation("Completed processing GetForm3283sCountForApproval action method.");
            return Ok(result);
        }

        [HttpGet]
        [Route("getformstatus")]
        public IActionResult GetFormStatus(string archiveNumber, int timeOffset = 0)
        {
            var formStatus = _archiveService.GetFormStatus(archiveNumber, timeOffset);
            _logger.LogInformation("get Form3283 status");
            return Ok(formStatus);
        }

        #region ArchiveResubmissionOpen

        [HttpPost]
        [Route("ArchiveResubmissionOpen")]
        public IActionResult ArchiveResubmissionOpen(ArchiveSubmission archiveSubmission)
        {
            var id = GetFuntionID("Access Archive");
            var isValid = false;
            archiveSubmission = (ArchiveSubmission)_utilityServie.IsUserAuthorizedAndInputIsValid(archiveSubmission.ArchiveNumber, id, userAlias, archiveSubmission, out isValid);
            if (isValid)
            {
                if (archiveSubmission == null) return BadRequest("resubmissionParameters is null");
                archiveSubmission.CreatedBy = userAlias;
                var result = _archiveService.ArchiveResubmissionOpen(archiveSubmission);
                _logger.LogInformation("ArchiveResubmissionOpen : ", System.Web.HttpUtility.HtmlEncode(archiveSubmission.ArchiveNumber));

                // process message on status change
                var messageResult = ProcessMessageOnStatusChange(archiveSubmission.ArchiveNumber);
                if (!messageResult.Item1) throw new Exception(messageResult.Item2);

                // process message for reverse feed for resubmission
                IList<string> roiNumbers = _archiveService.GetROINumbers(archiveSubmission.ArchiveNumber);

                _logger.LogInformation("Processing a message for the resubmission.");

                // MAT
                foreach (var number in roiNumbers)
                {
                    Tuple<bool, string> reverseFeedNotificationResponse = PushMessageforReverseFeed(number);
                    if (!reverseFeedNotificationResponse.Item1) throw new Exception(reverseFeedNotificationResponse.Item2);
                    _logger.LogInformation("Message has been processed");
                }

                _logger.LogInformation("Before calling UpsertEventSource method from CreateArchive action.");
                UpsertEventSource(archiveSubmission.ArchiveNumber, userAlias, 2);

                return Ok(result);
            }
            else
            {
                _logger.LogInformation("Unauthorized Request Details: Action: ArchiveResubmissionOpen, Object " + System.Web.HttpUtility.HtmlEncode(userAlias));
                return Forbid();
            }
        }

        #endregion

        #region Get Resubmission Approvers
        [HttpPost]
        [Route("GetResubmissionApproverDetails")]
        public IActionResult GetResubmissionApproverDetails(ResubmissionParameters resubmissionParameters)
        {
            //Testing
            var id = GetFuntionID("Access Archive");
            var isValid = false;
            resubmissionParameters = (ResubmissionParameters)_utilityServie.IsUserAuthorizedAndInputIsValid(resubmissionParameters.ArchiveNumber, id, userAlias, resubmissionParameters, out isValid);
            if (isValid)
            {
                _logger.LogInformation("Processing GetResubmissionApproverDetails action method.");
                var GetResubmissionApproverDetails = _archiveService.GetResubmissionApproverDetails(resubmissionParameters.ArchiveNumber, userAlias);
                _logger.LogInformation("Completed processing GetResubmissionApproverDetails action method.");
                return Ok(GetResubmissionApproverDetails);
            }
            else
            {
                _logger.LogInformation("Unauthorized Request Details: Action: Get Resubmission Approvers, Object " + System.Web.HttpUtility.HtmlEncode(userAlias));
                return Forbid();
            }
        }
        #endregion Get Resubmission Approvers



        [HttpPost]
        [Route("InsertResubmissionApprover")]
        public IActionResult InsertResubmissionApprover(ResubmissionParameters resubmissionParameters)
        {
            ResubmissionStatusInfo InfoData = new ResubmissionStatusInfo();
            InfoData.Message = null;
            InfoData.ArchiveStatus = null;
            InfoData.OfficeCode = null;

            var id = GetFuntionID("Access Archive");
            var isValid = false;
            resubmissionParameters = (ResubmissionParameters)_utilityServie.IsUserAuthorizedAndInputIsValid(resubmissionParameters.ArchiveNumber, id, userAlias, resubmissionParameters, out isValid);
            if (isValid)
            {
                _logger.LogInformation("Processing InsertResubmissionApprover action method.");
                var (successMessage, archiveStatus,zoneName) = _archiveService.InsertResubmissionApprover(userAlias, resubmissionParameters.ArchiveNumber, resubmissionParameters.RoleID);

                if (successMessage == "Success")
                {
                    ProcessMessages(resubmissionParameters.ArchiveNumber, userAlias, archiveStatus);
                }

                _logger.LogInformation("Completed processing InsertResubmissionApprover action method.");

                _logger.LogInformation("Before calling UpsertEventSource method from CreateArchive action.");
                UpsertEventSource(resubmissionParameters.ArchiveNumber, userAlias, 2);

                InfoData.Message = successMessage;
                InfoData.ArchiveStatus = archiveStatus;
                InfoData.OfficeCode = zoneName;
                return Ok(InfoData);

               // return Ok(successMessage);
            }
            else
            {
                _logger.LogInformation("Unauthorized Request Details: Action: InsertResubmissionApprover, Object " + System.Web.HttpUtility.HtmlEncode(userAlias));
                return Forbid();
            }
        }

        private Tuple<bool, string> PushMessageforReverseFeed(string message, string identifier = "MAT")
        {
            try
            {
                PushMessageSNS sns = new PushMessageSNS("archievenotifarn");
                _logger.LogInformation("Pushing message to SNS from Archive lembda.", System.Web.HttpUtility.HtmlEncode(message));
                var messageId = sns.PushMsgtoSNS(identifier + "," + message).Result;
                _archiveService.LogMessageId(message + " : " + messageId);
                return Tuple.Create(true, "");
            }
            catch (Exception ex)
            {
                _logger.LogInformation("Failed to push message to SNS from Archive lembda");
                return Tuple.Create(false, ex.Message);
            }
        }


        [HttpPost]
        [Route("CreateOrUpdateMemo")]
        public IActionResult CreateOrUpdateMemo(Memo memo)
        {
            var id = GetFuntionID("Access Archive");
            var isValid = false;
            memo = (Memo)_utilityServie.IsUserAuthorizedAndInputIsValid(memo.ArchiveNumber, id, userAlias, memo, out isValid);
            if (isValid)
            {
                memo.CreatedBy = userAlias;
                _logger.LogInformation("CreateOrUpdateDeliverable: started");
                var memoinfo = _archiveService.CreateOrUpdateMemo(memo);
                _logger.LogInformation("CreateOrUpdateDeliverable: ended");
                return Ok(memoinfo);
            }
            else
            {
                _logger.LogInformation("Unauthorized Request Details: Action: CreateOrUpdateMemo, Object " + System.Web.HttpUtility.HtmlEncode(userAlias));
                return Forbid();
            }
        }

        [HttpGet]
        [Route("GetResubmissionReason")]
        public IActionResult GetResubmissionReasons()
        {
            _logger.LogInformation("GetResubmissionReasons: started");
            var resubmissionReason = _archiveService.GetResubmissionReasons();
            _logger.LogInformation("GetResubmissionReasons: ended");
            return Ok(resubmissionReason);

        }
        [HttpGet]
        [Route("GetUploadedMemo")]
        public IActionResult GetUploadedMemo(string ArchiveNumber)
        {
            var id = GetFuntionID("Access Archive");
            var isValid = _utilityServie.IsUserAuthorizedtoPerformAction(ArchiveNumber, id, userAlias);
            if (isValid)
            {
                _logger.LogInformation("GetUploadedMemo: started");
                var memoinfo = _archiveService.GetUploadedMemo(ArchiveNumber);
                _logger.LogInformation("GetUploadedMemo: ended");
                return Ok(memoinfo);
            }
            else
            {
                _logger.LogInformation("Unauthorized Request Details: Action: GetUploadedMemo, Object " + System.Web.HttpUtility.HtmlEncode(userAlias));
                return Forbid();
            }
        }

        [HttpPost]
        [Route("DeleteUploadedMemo")]
        public IActionResult DeleteUploadedMemo(string ArchiveFileID, string ArchiveNumber)
        {
            var id = GetFuntionID("Access Archive");
            var isValid = _utilityServie.IsUserAuthorizedtoPerformAction(ArchiveNumber, id, userAlias);
            if (isValid)
            {
                _logger.LogInformation("Processing DeleteUploadedMemo action method.");
                var result = _archiveService.DeleteUploadedMemo(ArchiveFileID, userAlias);
                _logger.LogInformation("Completed processing DeleteUploadedMemo action method.");
                return Ok(result);
            }
            else
            {
                _logger.LogInformation("Unauthorized Request Details: Action: DeleteUploadedMemo, Object " + System.Web.HttpUtility.HtmlEncode(userAlias));
                return Forbid();
            }
        }

        [HttpPost]
        [Route("InsertUpdateArchiveSubmissionFlow")]
        public IActionResult InsertUpdateArchiveSubmissionFlow(string ArchiveNumber)
        {
            var id = GetFuntionID("Access Archive");
            var isValid = _utilityServie.IsUserAuthorizedtoPerformAction(ArchiveNumber, id, userAlias);
            if (isValid)
            {
                _logger.LogInformation("InsertUpdateArchiveSubmissionFlow - Method for logging the Archive submitter in Open case.");
                var result = _archiveService.InsertUpdateArchiveSubmissionFlow(ArchiveNumber, userAlias);
                result = "{'output':'" + result + "'}";
                _logger.LogInformation("Before calling UpsertEventSource method from CreateArchive action.");
                UpsertEventSource(ArchiveNumber, userAlias, 2);

                return Ok(JObject.Parse(result));
            }
            else
            {
                _logger.LogInformation("Unauthorized Request Details: Action: InsertUpdateArchiveSubmissionFlow, Object " + System.Web.HttpUtility.HtmlEncode(userAlias));
                return Forbid();
            }
        }

        [HttpGet]
        [Route("GetArchiveApproverforArchiveSubmission")]
        public IActionResult GetArchiveApproverforArchiveSubmission(string ArchiveNumber, int RoleID)
        {
            var id = GetFuntionID("Access Archive");
            var isValid = _utilityServie.IsUserAuthorizedtoPerformAction(ArchiveNumber, id, userAlias);
            if (isValid)
            {
                _logger.LogInformation("GetArchiveApproverforArchiveSubmission - Method for fetching the Archive approver based on Submitter.");
                var result = _archiveService.GetArchiveApproverforArchiveSubmission(ArchiveNumber, userAlias, RoleID);
                return Ok(result);
            }
            else
            {
                _logger.LogInformation("Unauthorized Request Details: Action: GetArchiveApproverforArchiveSubmission, Object " + System.Web.HttpUtility.HtmlEncode(userAlias));
                return Forbid();
            }
        }

        [HttpGet]
        [Route("CheckAPSubmitterInactive")]
        public IActionResult CheckAPSubmitterInactive(string ArchiveNumber, int CheckType)
        {
            var id = GetFuntionID("Access Archive");
            var isValid = _utilityServie.IsUserAuthorizedtoPerformAction(ArchiveNumber, id, userAlias);
            if (isValid)
            {
                _logger.LogInformation("CheckAPSubmitterInactive - Method to check if the AP is submitter or Inactive.");
                var result = _archiveService.CheckAPSubmitterInactive(ArchiveNumber, userAlias, CheckType);
                return Ok(result);
            }
            else
            {
                _logger.LogInformation("Unauthorized Request Details: Action: CheckAPSubmitterInactive, Object " + System.Web.HttpUtility.HtmlEncode(userAlias));
                return Forbid();
            }
        }
        [HttpGet]
        [Route("checkomniasubmissionallowed")]
        public IActionResult CheckOmniaSubmissionAllowed(string ArchiveNumber)
        {
            _logger.LogInformation("CheckOmniaSubmissionAllowed - Method to check if the Archive has files for all engagements.");
            var result = _archiveService.CheckOmniaSubmissionAllowed(ArchiveNumber);
            return Ok(result);
        }


        [HttpGet]
        [Route("GetArchiveHistory")]
        public IActionResult GetArchiveHistory(string ArchiveNumber, int PageNumber = 0, int PageSize = 0, int SortBy = 1)
        {
            var id = GetFuntionID("View Archive History");
            var isValid = _utilityServie.IsUserAuthorizedtoPerformAction(ArchiveNumber, id, userAlias);
            if (isValid)
            {
                var archivehistory = _archiveService.GetArchiveHistory(ArchiveNumber, PageNumber, PageSize, SortBy);
                _logger.LogInformation("Archivehistory: ");
                return Ok(archivehistory);
            }
            else
            {
                _logger.LogInformation("Unauthorized Request Details: Action: GetArchiveHistory, Object " + System.Web.HttpUtility.HtmlEncode(userAlias));
                return Forbid();
            }
        }

        #region UpdateFirstLevelResubmissionApprovalFlagSet
        [HttpPost]
        [Route("UpdateFirstLevelResubmissionApprovalFlag")]
        public IActionResult UpdateFirstLevelResubmissionApprovalFlag(ResubmissionParameters resubmissionParameters)
        {
            //Testing
            _logger.LogInformation("Processing UpdateFirstLevelResubmissionApprovalFlag action method.");
            var UpdateFirstLevelResubmissionApprovalFlagDetails = _archiveService.UpdateFirstLevelResubmissionApprovalFlag(resubmissionParameters.ArchiveNumber, userAlias);
            _logger.LogInformation("Completed processing UpdateFirstLevelResubmissionApprovalFlag action method.");

            _logger.LogInformation("Before calling UpsertEventSource method from CreateArchive action.");
            UpsertEventSource(resubmissionParameters.ArchiveNumber, userAlias, 2);

            return Ok(UpdateFirstLevelResubmissionApprovalFlagDetails);
        }
        #endregion UpdateFirstLevelResubmissionApprovalFlagSet

        private Tuple<bool, string> PushMessageforFileMovement(string archiveNumber, string alias, string archiveStatus, string roiNumbers)
        {
            try
            {
                PushMessageSNS sns = new PushMessageSNS("archiveProcessorNotifyArn");
                HttpContext context = _contextAccessor.HttpContext;
                string accessToken = null;
                if (context.Request.Headers.ContainsKey("Authorization") && context.Request.Headers["Authorization"][0].StartsWith("Bearer "))
                {
                    accessToken = context.Request.Headers["Authorization"][0].Substring("Bearer ".Length);
                }
                else throw new ArgumentNullException("accessToken is null.");
                string eventToBeNotified = "ROI.UpdateArchiveNumbers";
                var message = $"{{\"ArchiveNumber\":\"{archiveNumber}\",\"CreatedBy\":\"{alias}\",\"AccessToken\":\"{accessToken}\",\"ROINumbers\":\"{roiNumbers}\",\"EventToBeNotified\":\"{eventToBeNotified}\"}}";
                _logger.LogInformation("Pushing message to SNS from Archive lembda for file movement.", System.Web.HttpUtility.HtmlEncode(message));
                var messageId = sns.PushMsgtoSNS(message).Result;
                _archiveService.LogMessageId(message + " : " + messageId);
                return Tuple.Create(true, "");
            }
            catch (Exception ex)
            {
                _logger.LogInformation("Failed to push message to SNS from Archive lembda for file movement");
                return Tuple.Create(false, ex.Message);
            }
        }
        #region DeleteArchive
        [HttpPost("DeleteArchiveRequest")]
        public IActionResult DeleteArchiveRequest(ArchiveDeletionAction deletionrequest)
        {
            deletionrequest.CreatedBy = userAlias;
            var id = GetFuntionID("Request Archive Deletion");
            var isValid = false;
            deletionrequest = (ArchiveDeletionAction)_utilityServie.IsUserAuthorizedAndInputIsValid(deletionrequest.ArchiveNumber, id, userAlias, deletionrequest, out isValid);
            if (isValid)
            {
                var result = _archiveService.DeleteArchive(deletionrequest);
                _logger.LogInformation("Delete archive request for : ", System.Web.HttpUtility.HtmlEncode(deletionrequest.ArchiveNumber));

                _logger.LogInformation("Before calling UpsertEventSource method from CreateArchive action.");
                UpsertEventSource(deletionrequest.ArchiveNumber, userAlias, 6);
                return Ok(result);
            }
            else
            {
                _logger.LogInformation("Unauthorized Request Details: Action: DeleteArchive, Object " + System.Web.HttpUtility.HtmlEncode(userAlias));
                return Forbid();
            }
        }
        #endregion DeleteArchive

        [HttpGet]
        [Route("GetBinderDetails")]
        public IActionResult GetBinderDetails(string archiveNumber, int pageNumber, int pageSize, int sortBy)
        {
            var id = GetFuntionID("Access Archive");
            var isValid = _utilityServie.IsUserAuthorizedtoPerformAction(archiveNumber, id, userAlias);
            if (isValid)
            {
                _logger.LogInformation("GetBinderDetails: " + System.Web.HttpUtility.HtmlEncode(archiveNumber));
                var binderResults = _archiveService.GetBinderDetails(archiveNumber, pageNumber, pageSize, sortBy);
                return Ok(binderResults);
            }
            else
            {
                _logger.LogInformation("Unauthorized Request Details: Action: GetBinderDetails, Object " + System.Web.HttpUtility.HtmlEncode(userAlias));
                return Forbid();
            }
        }
        [HttpPost]
        [Route("ApplyArchiveHolds")]
        public IActionResult ApplyArchiveHolds(ApplyArchiveHolds applyArchiveHolds)
        {
            var isValid = _utilityServie.IsUserAuthorizedtoPerformAction("", 0, userAlias, "Holds");
            if (isValid)
            {
                _logger.LogInformation("Apply Holds Screen- Archive Controller");

                _logger.LogInformation("Before calling UpsertEventSource method from CreateArchive action.");
                UpsertEventSource(applyArchiveHolds.ArchiveNumber, userAlias, 2);

                return Ok(_archiveService.ApplyArchiveHolds(applyArchiveHolds));
            }
            else
            {
                _logger.LogInformation("Unauthorized Request Details: Action: Apply Holds Screen, Object " + System.Web.HttpUtility.HtmlEncode(userAlias));
                return Forbid();
            }
        }

        [HttpGet]
        [Route("GetHoldHistoryDetails")]
        public IActionResult GetHoldHistoryDetails(int HoldId, string HoldNumber, int ArchiveHoldHistoryId, string ArchiveNumber)
        {
            var isValid = _utilityServie.IsUserAuthorizedtoPerformAction("", 0, userAlias, "Holds");
            if (isValid)
            {
                _logger.LogInformation("Get Holds History details - ArchiveController");
                var result = _archiveService.GetHoldHistoryDetails(HoldId, HoldNumber, ArchiveHoldHistoryId);
                return Ok(new { result });
            }
            else
            {
                _logger.LogInformation("Unauthorized Request Details: Action: GetHoldHistoryDetails, Object " + System.Web.HttpUtility.HtmlEncode(userAlias));
                return Forbid();
            }
        }
        [HttpPost]
        [Route("RemoveArchiveFromHold")]
        public IActionResult RemoveArchivesFromHold(int HoldId, string ArchiveNumber)
        {
            var isValid = _utilityServie.IsUserAuthorizedtoPerformAction("", 0, userAlias, "Holds");
            if (isValid)
            {
                _logger.LogInformation("Remove an archive from Hold - ArchiveController");
                var result = _archiveService.RemoveArchiveFromHold(HoldId, ArchiveNumber, userAlias);
                return Ok(new { result });
            }
            else
            {
                _logger.LogInformation("Unauthorized Request Details: Action: RemoveArchiveFromHold, Object " + System.Web.HttpUtility.HtmlEncode(userAlias));
                return Forbid();
            }
        }
        [HttpPost]
        [Route("RemoveHoldFromArchive")]
        public IActionResult RemoveHoldFromArchive(string ArchiveNumber, string HoldNumber)
        {
            var isValid = _utilityServie.IsUserAuthorizedtoPerformAction("", 0, userAlias, "Holds");
            if (isValid)
            {
                _logger.LogInformation("Remove Hold fro_httpClientm an archive - ArchiveController");
                var result = _archiveService.RemoveHoldFromArchive(ArchiveNumber, HoldNumber, userAlias);
                return Ok(new { result });
            }
            else
            {
                _logger.LogInformation("Unauthorized Request Details: Action: RemoveHoldFromArchive, Object " + System.Web.HttpUtility.HtmlEncode(userAlias));
                return Forbid();
            }
        }
        [HttpGet]
        [Route("GetArchivesAssociatedtoHolds")]
        public IActionResult GetArchivesAssociatedtoHolds(string HoldNumber, int BusinessId, string ClientId, string FilterText, int SortBy, string ArchiveNumber)
        {
            var isValid = _utilityServie.IsUserAuthorizedtoPerformAction("", 0, userAlias, "Holds");
            if (isValid)
            {
                _logger.LogInformation("Get archives associsted to Hold- ArchiveController");
                return Ok(_archiveService.GetArchivesAssociatedtoHolds(HoldNumber, BusinessId, ClientId, FilterText, SortBy));
            }
            else
            {
                _logger.LogInformation("Unauthorized Request Details: Action: GetArchivesAssociatedtoHolds, Object " + System.Web.HttpUtility.HtmlEncode(userAlias));
                return Forbid();
            }
        }

        [HttpPost]
        [Route("GetArchivesForApplyingHold")]
        public IActionResult GetArchivesForApplyingHold(GetDataForExportToExcelParameters ParameterData)
        {
            var isValid = _utilityServie.IsUserAuthorizedtoPerformAction("", 0, userAlias, "Holds");
            if (isValid)
            {
                _logger.LogInformation("Get archives for Applying Hold- ArchiveController");
                return Ok(_archiveService.GetArchivesForApplyingHold(ParameterData.SearchBy, ParameterData.SearchByValue, ParameterData.IncludeOrExclude, ParameterData.HoldName, ParameterData.Business, ParameterData.PeriodStart, ParameterData.PeriodEnd, ParameterData.SortBy, ParameterData.SortOrder, ParameterData.PageNumber, ParameterData.PageSize));
            }
            else
            {
                _logger.LogInformation("Unauthorized Request Details: Action: Get archives for Applying Hold, Object " + System.Web.HttpUtility.HtmlEncode(userAlias));
                return Forbid();
            }
        }

        [HttpGet]
        [Route("GetMatRoiUpdates")]
        public IActionResult GetMatRoiUpdates(string archiveNumber)
        {
            var id = GetFuntionID("Access Archive");
            var isValid = _utilityServie.IsUserAuthorizedtoPerformAction(archiveNumber, id, userAlias);
            if (isValid)
            {
                _logger.LogInformation("GetMatRoiUpdates");
                var data = new { matRoiUpdates = _archiveService.GetMatRoiUpdates(archiveNumber) };
                return Ok(data);
            }
            else
            {
                _logger.LogInformation("Unauthorized Request Details: Action: GetMyArchiveDetails, Object " + System.Web.HttpUtility.HtmlEncode(userAlias));
                return Forbid();
            }
        }




        [HttpGet]
        [Route("GetLinkedArchiveStatus")]
        public IActionResult GetLinkedArchiveStatus(string archiveNumber)
        {
            var id = GetFuntionID("Access Archive");
            var isValid = _utilityServie.IsUserAuthorizedtoPerformAction(archiveNumber, id, userAlias);
            if (isValid)
            {
                _logger.LogInformation("GetLinkedArchiveStatus: " + System.Web.HttpUtility.HtmlEncode(archiveNumber + userAlias));
                var linkedArchivesStatus = _archiveService.GetLinkedArchiveStatus(archiveNumber, userAlias);
                return Ok(linkedArchivesStatus);
            }
            else
            {
                _logger.LogInformation("Unauthorized Request Details: Action: GetLinkedArchiveStatus, Object " + System.Web.HttpUtility.HtmlEncode(userAlias));
                return Forbid();
            }
        }

        [HttpGet]
        [Route("GetERPStatus")]
        public IActionResult GetERPStatus(string archiveNumber)
        {
            var id = GetFuntionID("Access Archive");
            var isValid = _utilityServie.IsUserAuthorizedtoPerformAction(archiveNumber, id, userAlias);
            if (isValid)
            {
                _logger.LogInformation("GetERPStatus: " + System.Web.HttpUtility.HtmlEncode(archiveNumber));
                var ERPS = _archiveService.GetEngagementRelatedPersonalStatus(archiveNumber);
                return Ok(ERPS);
            }
            else
            {
                _logger.LogInformation("Unauthorized Request Details: Action: GetERPStatus, Object " + userAlias);
                return Forbid();
            }

        }


        [HttpGet]
        [Route("GetArchiveAtcionsForIndividualSections")]
        public IActionResult GetArchiveAtcionsForIndividualSections(string archiveNumber)
        {
            var id = GetFuntionID("Access Archive");
            var isValid = _utilityServie.IsUserAuthorizedtoPerformAction(archiveNumber, id, userAlias);
            if (isValid)
            {
                _logger.LogInformation("GetArchiveAtcionsForIndividualSections: " + System.Web.HttpUtility.HtmlEncode(archiveNumber));
                var archiveAtcionsForIndividualSections = _archiveService.GetArchiveAtcionsForIndividualSections(archiveNumber).ToList();
                return Ok(archiveAtcionsForIndividualSections);
            }
            else
            {
                _logger.LogInformation("Unauthorized Request Details: Action: GetArchiveActionsForIndividualSections, Object " + System.Web.HttpUtility.HtmlEncode(userAlias));
                return Forbid();
            }

        }


        private Tuple<bool, string> ProcessMessageOnStatusChange(string archiveNumber)
        {
            try
            {
                string jsonData = @"{""requestParameters"":{""OperationType"":""Insert"",""ArchiveNumber"":""" + archiveNumber + @"""}}";
                _logger.LogInformation("Json Data : " + System.Web.HttpUtility.HtmlEncode(jsonData));
                //PushMessageSNS obj = new PushMessageSNS("esindexingNotifyArn");
                PushMessageSNS obj = new PushMessageSNS("esindexingNotifyArn");
                var messageId = obj.PushMsgtoSNS(jsonData).Result;

                if (messageId != null || messageId != string.Empty || messageId != "")
                {
                    _archiveService.LogMessageId(archiveNumber + " : " + messageId);
                    _logger.LogInformation("SNS MessageId: " + System.Web.HttpUtility.HtmlEncode(messageId) + " for Archive: " + System.Web.HttpUtility.HtmlEncode(archiveNumber));
                    return Tuple.Create(true, "");
                }
                else
                {
                    _archiveService.LogMessageId(archiveNumber + " : " + "MessageId is null");
                    _logger.LogInformation("SNS MessageId: " + System.Web.HttpUtility.HtmlEncode(messageId) + " for Archive: " + System.Web.HttpUtility.HtmlEncode(archiveNumber));
                    throw new Exception("Message Id is null");
                }
            }
            catch (Exception ex)
            {
                return Tuple.Create(false, ex.Message);
            }
        }

        #region UpsertEventSource        
        [NonAction]
        private void UpsertEventSource(string metadata, string empAlias, int eventTypeID)
        {
            EventSource eventSource = null, eventSourceOut = null;
            try
            {
                eventSource = new EventSource() { Metadata = metadata, CreatedBy = empAlias, CreatedDate = DateTime.Now, IsProcessed = false, EventTypeID = eventTypeID };
                eventSourceOut = _utilityServie.UpsertEventSource(eventSource);
            }
            catch (Exception ex)
            {
                _logger.LogError(string.Format("Exception occured in UpsertEventSource method ArchiveController. ExceptionMessage: {0}, StackTrace: {1}", ex.Message, ex.StackTrace));
            }
        }
        #endregion UpsertEventSource

        #region RequestImageAction
        [HttpPost("CreateRequestImageAction")]
        public IActionResult CreateRequestImageAction(RMIntegrationActions requestImage)
        {
            try
            {
                var id = GetFuntionID("Request Image");
                var isValid = false;
                requestImage = (RMIntegrationActions)_utilityServie.IsUserAuthorizedAndInputIsValid(requestImage.ArchiveNumber, id, userAlias, requestImage, out isValid);
                if (isValid)
                {
                    //requestImage.RequestedBy = userAlias;
                    var result = _archiveService.CreateRequestImageAction(requestImage);
                    string actionMessageID = string.Empty;

                    //string jsonData = @"{""requestParameters"":{""OperationType"":""Insert"",""BinderID"":""" + requestImage.BinderID + @""",""Destination"":""RM"",""ArchiveNumber"":""" + requestImage.ArchiveNumber + @"""}}";
                    _logger.LogInformation("Processing a message for the RequestImage to RM.");
                    if (requestImage.IsBinderOrDeliverable == true)
                    {
                        actionMessageID = String.Concat(requestImage.BinderID.ToString(), " | ", "Binder");
                    }
                    else if (requestImage.IsBinderOrDeliverable == false)
                    {
                        actionMessageID = String.Concat(requestImage.BinderID.ToString(), " | ", "Deliverable");
                    }
                    Tuple<bool, string> reverseFeedNotificationResponse = PushMessageforReverseFeed(actionMessageID, "RM");
                    if (!reverseFeedNotificationResponse.Item1) throw new Exception(reverseFeedNotificationResponse.Item2);
                    _logger.LogInformation("Message to RM has been processed");
                    return Ok(result);
                }
                else
                {
                    _logger.LogInformation("Unauthorized Request Details: Action: CreateRequestImageAction, Object " + System.Web.HttpUtility.HtmlEncode(userAlias));
                    return Forbid();
                }
            }
            catch (Exception ex)
            {
                _logger.LogInformation("CreateRequestImageAction Failed Binder: " + System.Web.HttpUtility.HtmlEncode(requestImage.BinderID) + " For ArchiveNumber: " + System.Web.HttpUtility.HtmlEncode(requestImage.ArchiveNumber));
                throw ex;
            }


        }
        #endregion RequestImageAction

        private int GetFuntionID(string functionName)
        {
            LambdaLogger.Log("cacheLog43234432:" + functionName);
            _logger.LogInformation("cacheLog12798778:" + System.Web.HttpUtility.HtmlEncode(functionName));
            var Id = roleFunctions.Where(e => e.FunctionName == functionName).Select(x => x.Id).FirstOrDefault();
            _logger.LogInformation("functionId: " + System.Web.HttpUtility.HtmlEncode(Id.ToString()));
            return Id;
        }

    }
}
