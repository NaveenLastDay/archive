import { SharedComponentsModule } from './modules/shared/shared-components.module';
import { TrimSummaryLengthPipe } from './modules/shared/Pipes/trim-summary-length.pipe';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule, APP_INITIALIZER, Pipe, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { AppComponent } from './app.component';
import { HeaderComponent } from './home/header/header.component';
import { Routes, RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HomeComponent } from './home/body/home.component'; import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { MsAdalAngular6Module, MsAdalAngular6Service, AuthenticationGuard } from 'microsoft-adal-angular6';
import { AppConfig } from './services/appconfig.service';
import { InsertAuthTokenInterceptor } from './services/helpers/insert-auth-token-interceptor';
import { HttpErrorInterceptor } from './services/helpers/http-error-interceptor';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatNativeDateModule, MatDividerModule, MatFormFieldModule, MatTableModule, MatToolbarModule, MatTooltipModule, MatAutocompleteModule, MatInputModule, MatListModule,MatIconModule } from '@angular/material';
import { NotifierModule, NotifierOptions } from "angular-notifier";
import { MatDatepickerModule } from '@angular/material';
import { BreadcrumbModule } from './breadcrumb/breadcrumb.module';
import { NgxPaginationModule } from 'ngx-pagination';
import { NgxSpinnerModule } from "ngx-spinner";
import { DragDropModule } from '@angular/cdk/drag-drop';
import { CustomModalModule } from './modules/shared/modal';
import { SpinnerInterceptor } from './modules/shared/spinnerinterceptor';
import {MatExpansionModule} from '@angular/material/expansion';
import { FileUploadEventService } from './modules/record/file-upload/fileupload.event.service';
import { ArchiveSearchComponent } from './home/archive-search/archive-search.component';
import { FielUploadService } from './services/fileupload.service';
import { FileUploadRecordService } from './services/fileupload.record.service';
import { PipeModule } from './modules/shared/Pipes/pipe.module';
import {DatePipe} from '@angular/common';
import { FileuploadProgressGuard } from './guards/fileupload-progress-guard.service';
import { LinkedDashboardValidationGuard } from './guards/linked-dashboard-validation-guard.service';
import { As2FilepickerComponent } from './modules/record/working-paper/as2.filepicker.component';
import { NgbModule } from "@ng-bootstrap/ng-bootstrap";

import { NgIdleKeepaliveModule } from '@ng-idle/keepalive'; // this includes the core NgIdleModule but includes keepalive providers for easy wireup
import { MomentModule } from 'angular2-moment';
import { HighlightTextPipe } from './modules/shared/Pipes/highlight-text.pipe';
import { FaceSetSearchService } from './services/facesetSearch.service';
import { RateMyAppDirective } from '../app/directive/ratemyappdirective';
import { ApplicationFooterComponent } from './application-footer/application-footer.component';
import { BulkdownloadEventService } from './modules/record/bulk-download/bulkdownload.event.service';
import { ClickOutsideDirective } from './directive/click-outside.directive';
import { PartialoutageComponent } from './modules/shared/partialoutage/partialoutage.component';
// import { AdvanceSearchComponent } from  './modules/advance-search/advance-search.component';


let appRoutes: Routes = [   {path:"home", component:HomeComponent, canActivate : [AuthenticationGuard], data:{title:'Home'}},

// {path:"advance", component:AdvanceSearchComponent, data:{title:'Advance Search'}},


{
  path: "as2",
  component: As2FilepickerComponent,
  data: { title: "As2 Filepicker", showbreadcrumb: "false" }
},
                            {path:"", redirectTo:"home", pathMatch:"full",data:{title:'Home'}},
                            {path:"admin", loadChildren: () => import("./modules/admin/admin.module").then(m=> m.AdminModule),data:{title:'Admin',showbreadcrumb:'false'}},//lazy loading the module in angular 8
                            {path:"archive", loadChildren: () => import("./modules/archive/archive.module").then(m=> m.ArchiveModule),data:{title:'Archive',showbreadcrumb:'false'}},
                            { path: "record", loadChildren: () => import("./modules/record/record.module").then(m => m.RecordModule), data:{title:'Record',showbreadcrumb:'false'}},
                            { path:'search', loadChildren:() => import("./modules/search/search.module").then(m => m.SearchModule), data:{title:'Search', showbreadcrumb:'false'}},
                            { path:'dashboard', loadChildren:() => import("./modules/dashboard/dashboard.module").then(m => m.DashboardModule), data:{title:'Search', showbreadcrumb:'false'}},
                            {path:"partialoutage", component:PartialoutageComponent, canActivate : [AuthenticationGuard], data:{title:'Partial Outage', showbreadcrumb:'false'}}
                            // {path:"**", redirectTo:"home"}

                        ]

//ADAL authentication
let adalConfig: any; // will be initialized by APP_INITIALIZER
export function msAdalAngular6ConfigFactory() {
  return adalConfig; // will be invoked later when creating MsAdalAngular6Service
}

// Loading config values into adal config
export function initializeApp(appConfig: AppConfig) {
  const promise = appConfig.load().then(() => {
    adalConfig = {
      tenant: AppConfig.settings.adalConfig.tenant,
      clientId: AppConfig.settings.adalConfig.clientId,
      redirectUri: window.location.origin,
      endpoints: AppConfig.settings.adalConfig.endpoints,
      navigateToLoginRequestUrl: true,
      cacheLocation: AppConfig.settings.adalConfig.cacheLocation
    };
  });
  return () => promise;
}

/**
 * Custom angular notifier options
 */
const customNotifierOptions: NotifierOptions = {
  position: {
    horizontal: {
      position: 'right',
      distance: 12
    },
    vertical: {
      position: 'top',
      distance: 62,
      gap: 10
    }
  },
  theme: 'material',
  behaviour: {
    autoHide: 500,
    onClick: 'hide',
    onMouseover: 'pauseAutoHide',
    showDismissButton: true,
    stacking: 1
  },
  animations: {
    enabled: true,
    show: {
      preset: 'slide',
      speed: 200,
      easing: 'ease'
    },
    hide: {
      preset: 'fade',
      speed: 3000,
      easing: 'ease-in',
      offset: 50
    },
    shift: {
      speed: 300,
      easing: 'ease'
    },
    overlap: 150
  }
};



@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    HomeComponent,
    ClickOutsideDirective,
    ArchiveSearchComponent,
     As2FilepickerComponent,
        RateMyAppDirective,
        ApplicationFooterComponent
    ],
  imports:
  [
    BrowserModule,
    // FlexLayoutModule,
    MatExpansionModule,
    BrowserAnimationsModule,
    RouterModule.forRoot(appRoutes,{useHash : false}),
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    MsAdalAngular6Module ,
    MatNativeDateModule ,
    MatListModule,
    MatDatepickerModule,
    MatDividerModule,
    CustomModalModule,
    BreadcrumbModule,
    //NgxSpinnerModule,
    DragDropModule,
    PipeModule,
    NgbModule,
    NgxPaginationModule,
    NotifierModule.withConfig(customNotifierOptions),
    MatToolbarModule,MatTooltipModule,MatAutocompleteModule,
    NgxSpinnerModule,MatFormFieldModule,MatTableModule,MatInputModule,MatExpansionModule,MatIconModule,
    NgIdleKeepaliveModule.forRoot(),
    MomentModule,
   SharedComponentsModule
   ],


  providers: [
    AppConfig,
    {
      provide: APP_INITIALIZER,
      useFactory: initializeApp,
      deps: [AppConfig], multi: true
    },
    MsAdalAngular6Service,
    {
      provide: 'adalConfig',
      useFactory: msAdalAngular6ConfigFactory,
      deps: []
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: InsertAuthTokenInterceptor,
      multi: true
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: HttpErrorInterceptor,
      multi: true
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: SpinnerInterceptor,
      multi: true,
  },
    AuthenticationGuard,
    FileUploadEventService,
    BulkdownloadEventService,
    FielUploadService,
    FileUploadRecordService,
    DatePipe,
    FileuploadProgressGuard,
    LinkedDashboardValidationGuard,
    FaceSetSearchService

  ],
  bootstrap: [AppComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class AppModule { }
