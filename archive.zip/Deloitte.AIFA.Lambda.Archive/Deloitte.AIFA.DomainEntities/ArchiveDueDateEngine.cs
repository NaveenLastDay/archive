﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
   public class ArchiveDueDateEngine
    {
        public string ArchiveDueDateCriteria { get; set; }
        public DateTime OriginalDate { get; set; }
        public DateTime ArchiveDueDate { get; set; }
        public DateTime ExpectedDocumentationCompletionDate { get; set; }
        public string DeliverableType { get; set; }
        public DateTime ArchiveApprovedDate { get; set; }
        public string OfficeZone { get; set; }
    }
}
