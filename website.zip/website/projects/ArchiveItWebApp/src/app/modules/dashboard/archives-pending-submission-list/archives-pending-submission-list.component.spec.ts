import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ArchivesPendingSubmissionListComponent } from './archives-pending-submission-list.component';

describe('ArchivesPendingSubmissionListComponent', () => {
  let component: ArchivesPendingSubmissionListComponent;
  let fixture: ComponentFixture<ArchivesPendingSubmissionListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ArchivesPendingSubmissionListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ArchivesPendingSubmissionListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
