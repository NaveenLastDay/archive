import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateormanageBatchComponent } from './createormanage-batch.component';

describe('CreateormanageBatchComponent', () => {
  let component: CreateormanageBatchComponent;
  let fixture: ComponentFixture<CreateormanageBatchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateormanageBatchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateormanageBatchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
