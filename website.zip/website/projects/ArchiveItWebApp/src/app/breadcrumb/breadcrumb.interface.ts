/**
 * Created by complunm on 9/8/2016.
 */
export interface IBreadcrumb{
  url:string;
  label:string;
}
