﻿using System;

namespace Deloitte.AIFA.Models
{
    public class ProjectMetaDataModel
    {
        public string WBSNumber { get; set; }
        public string WBSName { get; set; }
        public string WBSStatus { get; set; }
        public string WBSProjectType { get; set; }
        public string WBSEngagementPPMD { get; set; }
        public string EngagementManager { get; set; }
        public string WBSClientNumber { get; set; }
        public string WBSClientName { get; set; }
        public string EngagementController { get; set; }
        public string WBSLBP { get; set; }
        public string WBSLCP { get; set; }
        public DateTime WBSClosedDate { get; set; }
        public string ProjectMarketOfferingCode { get; set; }
        public string ProjectMarketOfferingDescription { get; set; }
        public string ProjectPartnerDisplayName { get; set; }
        public string ProjectManagerDisplayName { get; set; }
        public string ProjectPartnerOfficeName { get; set; }
        public string ProjectPartnerFSSName { get; set; }
        public string ProjectPartnerServiceAreaName { get; set; }
        public string ProjectPartnerServiceLineName { get; set; }
        public string ProjectPartnerCostCenterCode { get; set; }
        public string ProjectPartnerCostCenterDescription { get; set; }
        public DateTime ProjectStartDate { get; set; }
        public DateTime ProjectEndDate { get; set; }

    }
}
