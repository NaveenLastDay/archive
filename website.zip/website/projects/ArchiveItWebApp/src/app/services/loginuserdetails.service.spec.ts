import { TestBed } from '@angular/core/testing';

import { LoginuserdetailsService } from './loginuserdetails.service';

describe('LoginuserdetailsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: LoginuserdetailsService = TestBed.get(LoginuserdetailsService);
    expect(service).toBeTruthy();
  });
});
