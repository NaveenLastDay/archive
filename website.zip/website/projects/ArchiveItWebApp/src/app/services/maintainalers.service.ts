import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable } from 'rxjs';
import { PubsubService } from './pubsub.service';
import { LoginuserdetailsService } from './loginuserdetails.service';

@Injectable({
  providedIn: 'root'
})
export class MaintainalersService {

  apiData: any;
  APIData : any;
  count: any;
  normalalertcount: any;
  highalertcount: any;
  constructor(private _http: HttpClient,private pubsub:PubsubService,private loginuserdetailsservice:LoginuserdetailsService ) { }

  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  }


  public GetSystemAlerts():Observable<any>
  {
    this.apiData = this._http.get<any[]>("alert/get");
    return this.apiData;
  }

  public GetUserAlerts(UserAlias:string):Observable<any>
  {
    this.apiData = this._http.get<any[]>("alert/getuseralerts/");
    return this.apiData;
  }

  public CreateSystemAlert(parameters:any):Observable<any>
  {
    this.apiData = this._http.post<any[]>("alert/create", parameters,this.httpOptions);
    return this.apiData;
  }

  public UpdateSystemAlert(parameters:any):Observable<any>
  {
    this.apiData = this._http.post<any[]>("alert/update", parameters,this.httpOptions);
    return this.apiData;
  }

  public DeleteSystemAlert(parameters:any):Observable<any>
  {
    this.apiData = this._http.post<any[]>("alert/delete", parameters,this.httpOptions);
    return this.apiData;
  }
  public SortSystemAlert(parameters:any):Observable<any>
  {
    this.apiData = this._http.post<any[]>("alert/sort", parameters,this.httpOptions);
    return this.apiData;
  }

  public ReadReceipents(parameters:any):Observable<any>
  {
    this.apiData = this._http.post<any[]>("alert/createread", parameters,this.httpOptions);
    return this.apiData;
  }

  public UserAlertsCount(UserAlias:string, showLoader?: boolean):Observable<any>
  {
    (showLoader == undefined)? showLoader = true : null;
    this.apiData = this._http.get<any[]>('alert/count/?showLoader='+showLoader);
    return this.apiData;
  }

  public SyncAlerts(showLoader ?:boolean) {
   (showLoader == undefined) ?  showLoader = true: null; 
    var UserAlias =this.loginuserdetailsservice.GetUserAlias();
    this.UserAlertsCount(UserAlias, showLoader).subscribe(
      data => {
        var normalalertcount = data.normalAlertCount;
        var highalertcount = data.highAlertCount;
        this.normalalertcount = normalalertcount;
        this.highalertcount = highalertcount;

        var UserAlertsCount = data.highAlertCount + data.normalAlertCount;
          this.count = UserAlertsCount ;
          this.sendNormalAlertsCount();
          this.sendHighAlertsCount();
      }
      
    );

  }

  sendNormalAlertsCount(){
    this.pubsub.sendNormalAlertsCount(this.normalalertcount);
  }

  sendHighAlertsCount(){
    this.pubsub.sendHighAlertsCount(this.highalertcount);
  }


}
