import { ArchiveService } from './../../../services/archive.service';
import { HoldsService } from '../../../services/holds-admin.service';
import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { JsonPipe } from '@angular/common';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { NgxSpinnerService } from 'ngx-spinner';
import { NotifierService, NotifierModule, NotifierOptions } from "angular-notifier";
import { FormControl, FormGroup, FormBuilder, Validators, FormArray,NgForm } from '@angular/forms';
import { ModalService } from "../../shared/modal";
import { UserConfigSettingService } from '../../../guards/user-role-guard.service';
import { SharedService } from '../../../services/shared.service';
import { debug } from 'console';



@Component({
  selector: 'app-holds',
  templateUrl: './holds.component.html',
  styleUrls: ['./holds.component.css']
})

export class HoldsComponent implements OnInit {

  currentUrl: string;

  employeeUniqueIdentifier: string;
  archiveNumber: string = '';
  eventType: string = '';
  Holds: any[];
  HoldsFilterData: any[];
  hoverIndex: number = -1;
  periodEndToolTip: string = "";
  sortByEnum: any = HoldsSortBy;
  filterByEnum: any = HoldsFilterBy;
  currentPageNumber: number = 1;
  totalHolds: number = 0;
  readonly pageSize: number = 10;
  pageCount: number = 1;
  pageArray = Array();
  sortBy: number = 0;
  filterBy: number = this.filterByEnum.FilterBy_ArchiveType;
  filterText: string = "";
  displayingRecordsFrom: number = 0;
  displayingRecordsTo: number = 0;
  popUpHeaderText: string;
  showPopUp: number = 0;
  holdsTextNumber:string;
  holdsSimpleTextNumber:string;
  createHoldDate: Date ;

  createSuspensionDate: Date = undefined;
  Status:string;
  btnHoldsSave:boolean=true;
  HoldId:number=0;
  popUpHeaderTextforEdit: string;
  successorerrormessage : string="";
  HoldsData : any[];
  HoldsNameToFetchAllHolds : string="";
  HoldName : string;
  displyaDeliverables : boolean = true;
  UserName =this.adalSvc.LoggedInUserName;
  userEmail = this.adalSvc.LoggedInUserEmail;
  HoldCreationDate : string;
  userConfig: any;
  filterarray : any[] = [];
  show : boolean = false;
  display : string = '';
  Name : string = '';
  Date : string;
  euserAlias =this.userEmail.replace("@deloitte.com", "");
  dataSource:any;
  /*Holds Search Param's*/
   effectstart:string='';
    effectend:string='';
    SearchHoldName:string='';
    SearchHoldClient:string='';
    SearchHoldBusiness:string=''
    SearchHoldStatus:number=2;
  /*end of Holds Search Param's*/

  /*Pagination Param's*/
  appendWPtoGrid: boolean = false;
  /* */
  /*Export to Excel */
  /*sorting */
  columnByEnum: any = HoldsColumnBy;
  sortColumnDialog: number = -1;
  sortColumn : string ='';
  sortascdesc: number;
  /*sorting*/
  holdsResultGridColumns: any =HoldsResultGridColumns;
  readonly emptyStringInReport : string = " ";
  showSearchContent:boolean=false;
  searchFilterParams:any;
  columnFilters: any[] =
  [
    {
      "displayName": "HoldName#",
      "value": this.holdsResultGridColumns.HoldName,
      "checked": true
    },
    {
      "displayName": "Business#",
      "value": this.holdsResultGridColumns.Business,
      "checked": true
    },
    {
      "displayName": "ClientName#",
      "value": this.holdsResultGridColumns.ClientName,
      "checked": true
    },
    {
      "displayName": "Status#",
      "value": this.holdsResultGridColumns.Status,
      "checked": true
    },

    {
      "displayName": "EffectiveStartDate#",
      "value": this.holdsResultGridColumns.EffectiveStartDate,
      "checked": true
    },
    {
      "displayName": "EffectiveEndDate#",
      "value": this.holdsResultGridColumns.EffectiveEndDate,
      "checked": true
    },

    {
      "displayName": "ArchivesCount#",
      "value": this.holdsResultGridColumns.ArchivesCount,
      "checked": true
    },

  ]
  /* end of Export to Excel */

  constructor(private router: Router,private _userConfig:UserConfigSettingService, private holdsService: HoldsService, private adalSvc: MsAdalAngular6Service,
    private SpinnerService: NgxSpinnerService, private notifier: NotifierService,private modalService: ModalService,private sharedService: SharedService,) {
    router.events.subscribe((_: NavigationEnd) => this.currentUrl = this.router.url);
    HoldsForm: FormGroup;
  }

  ngOnInit() {
    console.log(this.pageArray);
    this.employeeUniqueIdentifier = this.adalSvc.LoggedInUserEmail.split('@')[0];
    this.userConfig = this._userConfig.FetchLoggedInUser(this.employeeUniqueIdentifier);
    this.initialize();
  }

  initialize()
  {
    // debugger;
    this.GetHoldsDataforAdmin();
     //this.getHolds();
   //this.displyaDeliverables = true;

  }

  generateReportClicked(data1){
    debugger;
    //this.SpinnerService.show();
    let archiveForReport: any[] = [];
    let filterdColumns = (data1.filter(x => x.checked));
    this.holdsService.GetHoldsDataforAdmin(0, 0, this.sortascdesc, this.filterBy, this.sortColumn,this.SearchHoldName,this.SearchHoldClient ,this.SearchHoldBusiness ,this.SearchHoldStatus,this.effectstart,this.effectend).subscribe(
      data => {
        if (data.length > 0) {
          debugger;
          data.forEach(element => {
            let archive = {};
            filterdColumns.forEach(column => {

              if (column["value"] == this.holdsResultGridColumns.HoldName) { //Archive#
                archive[this.holdsResultGridColumns[this.holdsResultGridColumns.HoldName]] = element.holdName || this.emptyStringInReport;
              }
              if (column["value"] == this.holdsResultGridColumns.Business) { //Archive#
                archive[this.holdsResultGridColumns[this.holdsResultGridColumns.Business]] = element.business || this.emptyStringInReport;
              }
              if (column["value"] == this.holdsResultGridColumns.ClientName) { //Archive#
                archive[this.holdsResultGridColumns[this.holdsResultGridColumns.ClientName]] = element.clientName || this.emptyStringInReport;
              }
              if (column["value"] == this.holdsResultGridColumns.Status) { //Archive#
                archive[this.holdsResultGridColumns[this.holdsResultGridColumns.Status]] = element.status || this.emptyStringInReport;
              }
              if (column["value"] == this.holdsResultGridColumns.EffectiveStartDate) { //Archive#
                archive[this.holdsResultGridColumns[this.holdsResultGridColumns.EffectiveStartDate]] = element.effectiveStartDate || this.emptyStringInReport;
              }
              if (column["value"] == this.holdsResultGridColumns.EffectiveEndDate) { //Archive#
                archive[this.holdsResultGridColumns[this.holdsResultGridColumns.EffectiveEndDate]] = element.effectiveEndDate || this.emptyStringInReport;
              }
              if (column["value"] == this.holdsResultGridColumns.ArchivesCount) { //Archive#
                archive[this.holdsResultGridColumns[this.holdsResultGridColumns.ArchivesCount]] = element.archivesCount || this.emptyStringInReport;
              }



            });
            archiveForReport.push(archive);
          });
          if (archiveForReport && archiveForReport.length) {
            this.sharedService.generateExcel("Holdsfor"+this.archiveNumber, "Holds", filterdColumns.map(x => x.displayName), archiveForReport);
          }
        }
      });

  }

  updateGridData(event) {
    //this.SpinnerService.show();
    this.appendWPtoGrid = event.isLoadMoreClicked;
    this.currentPageNumber = event.pageNumber;
    this.holdsService.GetHoldsDataforAdmin(this.currentPageNumber, this.pageSize, this.sortascdesc, this.filterBy, this.sortColumn,this.SearchHoldName,this.SearchHoldClient,this.SearchHoldBusiness,this.SearchHoldStatus,this.effectstart,this.effectend).subscribe(
      data => {
        if (this.appendWPtoGrid && data) {
            for(var i =0;i<data.length;i++){
              this.Holds.push(data[i]);
            }
          }
          else{
            // this.totalHolds = data[0]["count"];
            this.Holds = data ? data : [];
          }

         // this.SpinnerService.hide();
        // this.getHoldsCount();

      }
    );
  }



  redirectToWorkingPapers(archiveNumber: string) {
    this.router.navigate(["/record/workingpapers/" + archiveNumber]);
  }

  redirectToCreatArchive(PageUrl: string) {
    this.router.navigate(["/" + PageUrl + ""]);
  }

  showHoldDetails(archiveNumber, index) {
    if (this.archiveNumber == archiveNumber) {
      this.archiveNumber = '';
      this.eventType = ''

    }
    else {
      this.archiveNumber = archiveNumber;
      this.eventType = 'select';

    }
  }

  mouseOver(event: any, index: number) {
    this.hoverIndex = index;
    //event.stopPropagation();
  }

  mouseOut(event: any) {
    let name: string = '';
    let present: number = -1;

    name = event.toElement ? event.toElement.getAttribute('name') : '';
    present = name ? name.search("AccessArchiveTop") : -1;

    if (event.toElement && present == -1 && (event.toElement["tagName"] != 'td' || event.toElement.className == 'trHoldsGridHeadFont')) {
      this.hoverIndex = -1;
    }
  }


  onFilterChangeEvent(event) {
    //// debugger;
    this.currentPageNumber = 1;

    if (event["filterText"] == "0") {
      this.filterBy = 0;
      this.filterText = "";
    }
    else {
      this.filterBy = event["filterBy"];
      this.filterText = event["filterText"];
    }
    this.GetHoldsDataforAdmin();
  }

  toggleAdvancedSearch(){
    this.showSearchContent = !this.showSearchContent;
  }
  hideSearchContent(event){
    this.showSearchContent=event;
  }
  searchHoldsByFilter(event){
    this.filterBy=0;
    this.searchFilterParams=event;
    console.log(this.searchFilterParams)
    
    
    if(this.searchFilterParams.EffectiveStartDate===undefined || this.searchFilterParams.EffectiveStartDate===null){
      this.effectstart='';
    }
    else
    {
      this.effectstart=this.searchFilterParams.EffectiveStartDate
    }

    if(this.searchFilterParams.EffectiveEndDate===undefined || this.searchFilterParams.EffectiveEndDate===null){
      this.effectend='';
    }
    else
    {
      this.effectend=this.searchFilterParams.EffectiveEndDate
    }
    this.SearchHoldName=this.searchFilterParams.HoldNames;
    this.SearchHoldClient=this.searchFilterParams.ClientNames;
    this.SearchHoldBusiness=this.searchFilterParams.Business;
    this.SearchHoldStatus=this.searchFilterParams.Status;
    
   // this.SpinnerService.show();
    this.currentPageNumber=1;
    this.holdsService.GetHoldsDataforAdmin(this.currentPageNumber, this.pageSize, this.sortBy, this.filterBy, this.filterText,this.SearchHoldName,this.SearchHoldClient,this.SearchHoldBusiness,this.SearchHoldStatus,this.effectstart,this.effectend).subscribe(
      data => {
       
        //this.SpinnerService.hide();
        this.Holds = data ? data : [];
        this.totalHolds = data[0]['recordsCount'];

      }
    );
    // this.holdsService.GetHoldsDataforAdmin(0, 0, this.sortBy, this.filterBy, this.filterText,this.SearchHoldName,this.SearchHoldClient,this.SearchHoldBusiness,this.SearchHoldStatus,this.effectstart,this.effectend).subscribe(
    //   data => {
    //     this.SpinnerService.hide();
    //     this.totalHolds = data.length;
    //   });

  }
  GetHoldsDataforAdmin() {
    //this.SpinnerService.show();

    this.holdsService.GetHoldsDataforAdmin(this.currentPageNumber, this.pageSize, this.sortascdesc, this.filterBy, this.sortColumn,this.SearchHoldName,this.SearchHoldClient,this.SearchHoldBusiness,this.SearchHoldStatus,this.effectstart,this.effectend).subscribe(
      data => {
        debugger;
        this.Holds = data ? data : [];
        this.totalHolds = data[0]['recordsCount'];
       // this.SpinnerService.hide();
      }
    );
    
    
  }

  showModelDialog(Action) {
    // debugger;
    if (Action === 'CreateHolds')
    {
      this.popUpHeaderText = "Create Hold";
      this.showPopUp =1;

      this.modalService.openWithCustomWidth("CreateHoldsData", "480");

    }
  //  else if (Action === 'Edit')
  //   {
  //       // debugger;
  //       this.popUpHeaderTextforEdit = "Edit Holds";

  //     }

    }


  closeModalDialog(Action) {

    if(Action=='CreateHoldsData')
    {
      // debugger;

      this.modalService.close(Action);
      this.holdsTextNumber = "";
      this.createHoldDate = undefined;
      this.createSuspensionDate=undefined;
    }

   else if(Action=='EditHoldsData'){
    // debugger;
    this.modalService.close(Action);
   }

  }
  omit_special_char(event)
{
   var k;
   k = event.charCode;
   return((k > 64 && k < 91) || (k > 96 && k < 123) || k == 8 || k == 32 || (k >= 48 && k <= 57));
}

//Create HOLD Data Methods

    CreateNewHolds(){

    // debugger;
    //this.SpinnerService.show();
    var parameters = {
      "HoldName":this.holdsTextNumber,
      "HoldCreationDate":this.createHoldDate,
      "SuspensionDate":this.createSuspensionDate,
      "HoldStatus":1,
      "UserAlias":''
    }
    this.holdsService.CreateNewHolds(parameters).subscribe((result) => {

      // debugger;
      if(result == "Success")
          {

            this.notifier.notify("success", "Added successfully");
            this.successorerrormessage = result.message;
            this.closeModalDialog('CreateHoldsData');
            this.GetHoldsDataforAdmin();

          }
          else{
            this.notifier.notify("error", result);

          }
    },
    (err) => {

      console.log("error","Exception while saving Holds Data", err.error)

    });
    //this.SpinnerService.hide();
  }



  /////////////////////////////////////////////////////////////////

  //EDIT Holds Data----------

  EditHoldsPopUp(HoldName,HoldsCreationDate,SuspensionDate) {
    // debugger;
    this.popUpHeaderTextforEdit = "Edit Hold";
    this.holdsTextNumber=HoldName;
    this.createHoldDate = new Date(HoldsCreationDate);

    if (SuspensionDate != null && SuspensionDate != 'undefined' )
    this.createSuspensionDate = new Date(SuspensionDate)
    //this.createHoldDate = HoldCreationDate;
    //this.holdsTextNumber = this.HoldsData.HoldName;
    //this.createHoldDate = this.HoldsData.CreationDate;
    this.showPopUp =1;
    this.modalService.openWithCustomWidth("EditHoldsData", "480");

  }
  NaavigateToApplyHold(holdName:string,clientName:string,business:string,effectiveStartDate:Date,effectiveEndDate:Date,status:string,archivesCount:number,clientID:string,businessID:string ){

    var holdObject ={holdName:holdName, clientName:clientName,business:business,effectiveStartDate:effectiveStartDate,effectiveEndDate:effectiveEndDate,status:status,archivesCount:archivesCount,clientID:clientID,businessID:businessID};
    localStorage.setItem('holdObject', JSON.stringify(holdObject));

    this.router.navigate(["/admin/adminsidenavbar/holds/holdsearch/applyHold"]);
  }

  NavigateToHoldDetails(HoldId:number,holdName:string,clientName:string,business:string,effectiveStartDate:Date,effectiveEndDate:Date,status:string,archivesCount:number,clientID:string,businessID:string,createdBy:string,createdDate:Date)
  {
    var holddetailsObject ={holdId:HoldId,holdName:holdName, clientName:clientName,business:business,effectiveStartDate:effectiveStartDate,effectiveEndDate:effectiveEndDate,status:status,archivesCount:archivesCount,clientID:clientID,businessID:businessID,createdBy:createdBy,createdDate:createdDate};
    localStorage.setItem('holddetailsObject', JSON.stringify(holddetailsObject));
    localStorage.setItem('HoldNumberForHistory',holdName);
    this.router.navigate(["/admin/adminsidenavbar/holds/holdsearch/" + holdName]);
  }
  NavigateToCreateHoldPage(holdName:string)
  {
    console.log('Navigating to Create Hold page');
    localStorage.setItem('HoldNumber',holdName);
    this.router.navigate(["/admin/adminsidenavbar/holds/holdsearch/"+holdName +"/EditHold"]);
  }

   UpdateHoldDetailsByID()
    {
     // debugger;
     var parameters = {
      "HoldName":this.holdsTextNumber,
      "HoldCreationDate":this.createHoldDate,
      "SuspensionDate":this.createSuspensionDate,
      "HoldStatus":1,
      "UserAlias":''
    }
    this.holdsService.UpdateHoldsData(parameters).subscribe((result) => {
      // this.HoldsData = result;
      // debugger;
      if(result!=null && result!=undefined)
          {
            if(result=="Success")
            {
              this.notifier.notify("success", "Updated successfully");
              console.log("success","Hold updated successfully");
              this.closeModalDialog('EditHoldsData');
              this.GetHoldsDataforAdmin();
            }

           else{
            this.notifier.notify("error", result);

          }

        }


      },
      (err) => {

        console.log("error","Exception while saving Holds Data", err.error)

      });
    }
    
    toggle(){}
    GetExcelforHolds(){}
    convertext(){
      debugger;

    }
    TextSearch(){
      this.filterBy=1;
      console.log("Logging",this.holdsSimpleTextNumber)
      this.SearchHoldName=this.holdsSimpleTextNumber;
      debugger;
      this.getHoldsDataforSort();
      

    }
    sortOrderChanged(event) {
      debugger;
      this.sortBy = event;

      console.log("sortOrderChanged ",this.sortColumnDialog +"Before"+this.sortBy)
      if(this.sortBy==1 || this.sortBy==3 || this.sortBy==5)
      {
        this.sortascdesc=1;
      }
      else if(this.sortBy==2 || this.sortBy==4 || this.sortBy==6)
      {
        this.sortascdesc=0;
      }
      if(this.sortColumnDialog==1)
      {
        this.sortColumn='HoldNumber';
      }
      else if(this.sortColumnDialog==2){
        this.sortColumn='ClientName';
      }
      else if(this.sortColumnDialog==3)
      {
        this.sortColumn='Business';
      }
      else if(this.sortColumnDialog==4){
        this.sortColumn='EffectiveStartDate';
      }
      else if(this.sortColumnDialog==5)
      {
        this.sortColumn='EffectiveEndDate';
      }
      else if(this.sortColumnDialog==6){
        this.sortColumn='HoldStatus';
      }
      else if(this.sortColumnDialog==7){
        this.sortColumn='ArchiveCount';
      }
      else{
        this.sortColumn='';
      }
      console.log("sortColumn",this.sortColumn);
      console.log("sortascdesc",this.sortascdesc);
      this.currentPageNumber=1;
      this.getHoldsDataforSort();
      console.log("sortOrderChanged ",this.sortColumnDialog +"After"+this.sortBy)
    }
    
    memberSortDialog(event) {
      debugger;
      if (this.sortColumnDialog == event) this.sortColumnDialog = -1;
      else
      this.sortColumnDialog = event;
      console.log("memberSortDialog",this.sortColumnDialog);
    }
    memberSortDialogASCDESC(event){
      debugger;
     var clickedColumn:number=event;
      /*For HoldName*/
      if(clickedColumn==1 && this.sortBy!=7){
      this.sortBy=7;
       this.sortColumn="HoldNumber";
       this.sortascdesc=1;
     }
     else if(clickedColumn==1 && this.sortBy==7){
      this.sortBy=0;
      this.sortColumn="HoldNumber";
      this.sortascdesc=0;
     }
     /*For HoldName*/
     /*for EffectiveStartDate */
     else if(clickedColumn==4 && this.sortBy!=8){
      this.sortBy=8;
       this.sortColumn="EffectiveStartDate";
       this.sortascdesc=1;
     }
     else if(clickedColumn==4 && this.sortBy==8){
      this.sortBy=0;
      this.sortColumn="EffectiveStartDate";
      this.sortascdesc=0;
     }
     /*FoR Effective Start Date */
     /*for EffectiveStartDate */
     else if(clickedColumn==5 && this.sortBy!=9){
      this.sortBy=9;
       this.sortColumn="EffectiveEndDate";
       this.sortascdesc=1;
     }
     else if(clickedColumn==5 && this.sortBy==9){
      this.sortBy=0;
      this.sortColumn="EffectiveEndDate";
      this.sortascdesc=0;
     }
     /*FoR Effective Start Date */



     this.currentPageNumber=1;
     this.getHoldsDataforSort();
     

    }

  getHoldsDataforSort()
  {
   // this.SpinnerService.show();
    this.holdsService.GetHoldsDataforAdmin(this.currentPageNumber, this.pageSize, this.sortascdesc, this.filterBy, this.sortColumn,this.SearchHoldName,this.SearchHoldClient,this.SearchHoldBusiness,this.SearchHoldStatus,this.effectstart,this.effectend).subscribe(
      data => {
        this.Holds = data ? data : [];
        this.totalHolds = data[0]['recordsCount'];
        //this.SpinnerService.hide();
      }
    );
    
  
  }

   

}

export enum HoldsSortBy {
  SortBy_EmployeeLastArchive = 1,
  SortBy_ArchiveName_Asc = 2,
  SortBy_ArchiveName_Desc = 3,
  SortBy_ClientName_Asc = 4,
  SortBy_ClientName_Desc = 5,
  SortBy_PeriodEnd_Asc = 6,
  SortBy_PeriodEnd_Desc = 7,
  SortBy_ArchiveStatus_Asc = 8,
  SortBy_ArchiveStatus_Desc = 9,
  SortBy_WBSNumber_Asc = 10,
  SortBy_WBSNumber_Desc = 11,
  SortBy_ArchiveNumber_Asc = 12,
  SortBy_ArchiveNumber_Desc = 13,
}

export enum HoldsFilterBy {
  FilterBy_Business = 1,
  FilterBy_ClientName = 2,
  FilterBy_WBS = 3,
  FilterBy_Status = 4,
  FilterBy_ArchiveType = 5,
}

export enum HoldsResultGridColumns
{
HoldName = 1,
Business = 2,
ClientName = 3,
Status = 4,
EffectiveStartDate= 5,
EffectiveEndDate = 6,
ArchivesCount = 7,
}


export enum HoldsColumnBy {
  ColumnBy_Default = -1,
  ColumnBy_HoldName = 1,
  ColumnBy_ClientName = 2,
  ColumnBy_Business = 3,
  ColumnBy_EffectiveStartDate = 4,
  ColumnBy_EffectiveEndDate = 5,
  ColumnBy_Status = 6,
  ColumnBy_ArchiveCount = 7,
}