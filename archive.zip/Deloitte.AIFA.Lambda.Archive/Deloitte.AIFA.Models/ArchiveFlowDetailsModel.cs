﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DataModels
{
    public class ArchiveFlowDetailsModel
    {
        public string ArchiveNumber { get; set; }
        public int ArchiveSectionId { get; set; }
        public int ActionTypeId { get; set; }
        public string Comments { get; set; }
        public string CreatedBy { get; set; }
        public string RejectedBy { get; set; }
        public int IsSectionApproved { get; set; }
        public DateTime RejectedDate { get; set; }
    }
}
