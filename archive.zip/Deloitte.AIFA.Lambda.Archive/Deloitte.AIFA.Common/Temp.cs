﻿namespace Deloitte.AIFA.DomainServices.Common
{
    public static class Temp
    {
        public static bool IsMigrationTest;
    }
}
