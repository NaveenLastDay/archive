import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd, ActivatedRoute, ParamMap } from '@angular/router';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
import { SearchWbsService } from '../../../services/searchwbs.service';
import { NgxSpinnerService } from "ngx-spinner";

@Component({
  selector: 'app-existing-wbs',
  templateUrl: './existing-wbs.component.html',
  styleUrls: ['./existing-wbs.component.css']
})
export class ExistingWbsComponent implements OnInit {
  currentUrl: string;
  selectedItem: any;
  rowcountparam: any;
  rowcount: any;
  apidata: any[];
  pageUrl: String;
  displayedColumns: string[] = ['WbsLevel1Number', 'WbsLevel1Name', 'ClientName', 'ClientNumber', 'Created', 'Action'];
  
  constructor(private router: Router, private SearchWbsService: SearchWbsService, private activatedRoute: ActivatedRoute,private SpinnerService: NgxSpinnerService ) {
    router.events.subscribe((_: NavigationEnd) => this.currentUrl = this.router.url);
  }
  ngOnInit() {

      this.selectedItem = this.activatedRoute.snapshot.params.optionSelectedvalue;
      this.rowcountparam=999999999;
      

      //Get the List of existing WBS from service
      //this.SpinnerService.show();
      this.SearchWbsService.GetWBSWildCardSearch(this.selectedItem, this.rowcountparam).subscribe((data) => {
        this.apidata = data;
        this.rowcount = this.apidata.length;
        // this.SpinnerService.hide();
      },
        error => console.log('error in listing wbs elemenst')
      );
  }
  OnClick(PageUrl) {
    this.router.navigate(["/" + PageUrl + ""]);
  }

  ShowExistingArchivesForWBS (row:any){
      this.router.navigate(["/" + "archive/existingArchives" + "/"+  row.wbsLevelOneNumber]);
  }

}
