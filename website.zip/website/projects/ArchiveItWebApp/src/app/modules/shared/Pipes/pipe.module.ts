import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';


import { SafeHtmlPipe } from './safehtml.pipe';
import { TrimSummaryLengthPipe } from './trim-summary-length.pipe';
import { SearchHighilghtPipe } from './search-highilght.pipe';
import { ListChildFilterPipe } from './filter-child-list.pipe';
import { filterObjListPipe } from './filter-obj-list.pipe';
import { TextHighlightboldPipe } from './text-hightlight-bold';

@NgModule({
    imports: [CommonModule],
    // declarations: [SafeHtmlPipe],
    declarations: [SafeHtmlPipe,ListChildFilterPipe, TrimSummaryLengthPipe, SearchHighilghtPipe, filterObjListPipe, TextHighlightboldPipe],
    exports: [SafeHtmlPipe,ListChildFilterPipe, TrimSummaryLengthPipe,SearchHighilghtPipe, filterObjListPipe, TextHighlightboldPipe]
})
export class PipeModule { }