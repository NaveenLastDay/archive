﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Text;
using Moq;
using Deloitte.AIFA.DomainServices.Contracts;
using Deloitte.AIFA.IRepositories;
using Deloitte.AIFA.DomainEntities;
using Deloitte.AIFA.DomainServices.Services;
using Microsoft.Extensions.Logging;
using Deloitte.AIFA.DataModels;

namespace Deloitte.AIFA.DomainServices.Tests
{
	[TestClass]
	public class UserServiceTestCases
	{
		private Mock<IUserRepository> _moqUserReposetory;
		private Mock<ILogger<UserService>> _mockLogger;
		private IUserService _userService;

		[TestInitialize]
		public void TestInitialize()
		{
			_moqUserReposetory = new Mock<IUserRepository>();
			_mockLogger = new Mock<ILogger<UserService>>();
			_userService = new UserService(null, null, _moqUserReposetory.Object, _mockLogger.Object);
		}

		[TestMethod]
		public void FetchLoggedInUserTest()
		{
			var userAlias = "test";
			_moqUserReposetory.Setup(del => del.FetchLoggedInUser(userAlias)).Returns(_userDetails);
			var result = _userService.FetchLoggedInUser(userAlias);
			Assert.AreEqual(result.Count, 1);
		}

		[TestMethod]
		public void GetRoleMappingsForUserTest()
		{
			string userAlias = "test";
			string archiveNumber = "testArchive";
			_moqUserReposetory.Setup(del => del.GetRoleMappingsForUser(userAlias, archiveNumber)).Returns(new RoleMapping() { RoleId = 1 });
			var result = _userService.GetRoleMappingsForUser(userAlias, archiveNumber);
			Assert.AreEqual(result.RoleId, 1);
		}

		[TestMethod]
		public void GetFooterConfigurationData()
		{
			_moqUserReposetory.Setup(del => del.GetFooterConfigurationData()).Returns(_footerConfigurationData);
			var result = _userService.GetFooterConfigurationData();
			Assert.AreEqual(result.Count >= 1, true);
		}

		private List<UserDetail> _userDetails = new List<UserDetail>()
		{
			new UserDetail(){ userAlias="test"}
		};

		private new List<FooterConfigurationDataModel> _footerConfigurationData => new List<FooterConfigurationDataModel>()
		{
			new FooterConfigurationDataModel()
			{
				Id = 1
			}
		};
	}
}
