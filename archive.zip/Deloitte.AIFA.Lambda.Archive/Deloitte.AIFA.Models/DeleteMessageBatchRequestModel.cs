﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DataModels
{
	public class DeleteMessageBatchRequestModel
	{
		public string Id { get; set; }
		public string ReceiptHandle { get; set; }
	}
}
