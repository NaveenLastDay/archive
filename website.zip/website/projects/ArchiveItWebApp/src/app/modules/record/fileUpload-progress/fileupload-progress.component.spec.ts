import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FileuploadProgressComponent } from './fileupload-progress.component';

describe('FileuploadProgressComponent', () => {
  let component: FileuploadProgressComponent;
  let fixture: ComponentFixture<FileuploadProgressComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FileuploadProgressComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FileuploadProgressComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
