﻿using AutoMapper;
using Deloitte.AIFA.DataModels;
using Deloitte.AIFA.DomainEntities;
using Deloitte.AIFA.Models;
using System.Collections.Generic;

namespace Deloitte.AIFA.Repositories.Automapper
{
    public static class ConfigureMapping 
    {
        public static IMapper InitializeMapping()
        {
            var config = new MapperConfiguration(cfg => {
                cfg.CreateMap<ArchiveModel, Archive>();
                cfg.CreateMap<ArchiveFolderModel, ArchiveFolder>();
                cfg.CreateMap<ProjectMetaDataModel, ProjectMetaData>();
                cfg.CreateMap<ArchiveMetaDataModel, ArchiveMetaData>();
                cfg.CreateMap<EngagementTypeModel, EngagementType>();
                cfg.CreateMap<LinkTypeModel, LinkTypes>();
                cfg.CreateMap<LinkedArchivesModel, LinkedArchives>();
                cfg.CreateMap<ArchiveTypeModel, ArchiveType>();
                cfg.CreateMap<EntityTypeModel, EntityType>();
                cfg.CreateMap<ProfessionalStandardsModel, ProfessionalStandards>();
                cfg.CreateMap<UtilityModel, Utility>();
                cfg.CreateMap<ArchiveSearchBaseModel, ArchiveSearchBase>();
                cfg.CreateMap<MyArchiveModel, MyArchive>();
                cfg.CreateMap<MyArchiveDetailsModel, MyArchiveDetails>();
                cfg.CreateMap<UserModel, User>();
                cfg.CreateMap<UserDetailsModel, UserDetail>();
                cfg.CreateMap<ExistingArchivesInfoModel, ExistingArchivesInfo>();
                cfg.CreateMap<ExistingArchivesModel, ExistingArchives>();
                cfg.CreateMap<ArchiveSearchBaseModel, ArchiveSearchBase>();
                cfg.CreateMap<EditArchiveDetailsModel, EditArchiveDetails>();
                cfg.CreateMap<ArchiveDetailsModel, ArchiveDetails>();
                cfg.CreateMap<ActiveRolesModel, ActiveRoles>();
                cfg.CreateMap<MyArchivesFilterDataModel, MyArchivesFilterData>();
                cfg.CreateMap<RetentionReasonModel, RetentionReason>();
                cfg.CreateMap<ArchiveFlowDetailsModel, ArchiveFlowDetails>();
                cfg.CreateMap<ArchiveRetentionDetailsModel, ArchiveRetentionDetails>();
                cfg.CreateMap<ArchiveSubmissionCheckModel, ArchiveSubmissionStatus>();
                cfg.CreateMap<ArchiveSubmissionModel, ArchiveSubmission>();
				cfg.CreateMap<EarlyTerminationDataModel, EarlyTerminationCeasedDate>();
                cfg.CreateMap<ERPConfigurationDataModel, ERPConfigurationData>();
                cfg.CreateMap<EngagementPersonnelInfoModel, EngagementPersonnelInfo>();
                cfg.CreateMap<SearchOptionsModel, SearchOptions>();
                cfg.CreateMap<GetApproverFromSubmitterModel, GetArchiveApproverFromSubmitter>();

                cfg.CreateMap<FormModel, Form>();
                cfg.CreateMap<FormArchiveInfoModel, FormArchiveInfo>();
                cfg.CreateMap<FormSubmitInfoModel, FormSubmitInfo>();
                cfg.CreateMap<Form3283PrepopulatedDataModel, Form3283PrepopulatedData>();
                cfg.CreateMap<Form3283ReasonTypeModel, Form3283ReasonType>();
                cfg.CreateMap<WorkingPaperSectionStatusCheckModel, WorkingPapersStatus>();
                cfg.CreateMap<DeliverablesStatusCheckModel, DeliverablesStatus>();
                cfg.CreateMap<LinkedArchivesSectionStatusCheckModel, LinkedArchivesStatus>();
                cfg.CreateMap<BindersSectionStatusCheckModel, BindersStatus>();
                cfg.CreateMap<RetentionExceptionStatusCheckModel, RetentionExceptionStatus>();
                cfg.CreateMap<EngagementRelatedPersonalStatusCheckModel, EngagementRelatedPersonalStatus>();
                cfg.CreateMap<DistributionListModel, DistributionList>();
                cfg.CreateMap<ERPmodel, ERPDetails>();
                cfg.CreateMap<FormActionModel, FormAction>();
                cfg.CreateMap<ArchiveTeamHistoryModel, ArchiveTeamHistory>();
                cfg.CreateMap<FormActionResponseModel, FormActionResponse>();
                cfg.CreateMap<FormStatusModel, FormStatus>();
                cfg.CreateMap<RoleMappingModel, RoleMapping>();
                cfg.CreateMap<UserActionsModel, UserActions>();
                cfg.CreateMap<ArchiveAccessRequestsForApprovalModel, ArchiveAccessRequestForApproval>();
                cfg.CreateMap<ArchiveAccessRequestCountForApprovalModel, RequestCountForApproval>();
                cfg.CreateMap<ArchiveDueDateEngineModel, ArchiveDueDateEngine>();
                cfg.CreateMap<InsertArchiveAccessRequestModel, InsertArchiveAccessRequest>();
                cfg.CreateMap<TemporaryArchiveAccessRequestModel, TempArchiveAccessRequest>();
                cfg.CreateMap<ResubmissionApproverModel, ResubmissionApprover>();
                cfg.CreateMap<ResubmissionApproverListModel, ResubmissionApproverList>();
                cfg.CreateMap<ArchiveAccessRequestDetailsModel, ArchiveAccessRequestDetails>();
                cfg.CreateMap<ResubmissionReasonModel, ResubmissionReason>();
                cfg.CreateMap<MemoModel, Memo>();
                cfg.CreateMap<ArchiveHistoryModel, ArchiveHistory>();
                cfg.CreateMap<MyForm3283DataModel, MyForm3283Data>();
                cfg.CreateMap<MyPendingSubmissionDataModel, MyPendingSubmissionData>();
                cfg.CreateMap<AutoCreateArchiveDetailsModel, AutoCreateArchiveDetails>();
                cfg.CreateMap<MyComplianceDataModel, MyComplianceData>();
                cfg.CreateMap <OmniaArchiveSubmissionStatusModel, OmniaArchiveSubmissionStatus >();
                cfg.CreateMap<BindersModel, Binders>();
                cfg.CreateMap<ArchiveDeletionStatusModel, ArchiveDeletionStatus>();
                cfg.CreateMap<ComplianceMetricsModel, ComplianceMetricsDetails>();
                
                cfg.CreateMap<HoldHistoryDetailsModel, HoldHistoryDetails>();
                cfg.CreateMap<HoldDetailsMetadataModel, HoldDetailsMetadata>();
                cfg.CreateMap<HoldsDetailModel, HoldsDetail>();
               
                cfg.CreateMap<ComplianceScoreForDashboardModel, ComplianceScoreForDashboard>();
                cfg.CreateMap<WBSDetailsModel, WBSDetails>();                
                cfg.CreateMap<EventSourceModel, EventSource>();
                cfg.CreateMap<RoleFunctionModel, RoleFunction>();
                cfg.CreateMap<AppliedArchiveHoldsInformationModel, AppliedArchiveHoldsInformation>();
                cfg.CreateMap<ArchiveTeamChangeDetailsModel, ArchiveTeamChangeDetailsData>();
                cfg.CreateMap<UserOfflinePermissionsModel, UserOfflinePermissions>();

            });
            return config.CreateMapper();
        }
    }
}

    