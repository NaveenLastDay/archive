﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace Deloitte.AIFA.DomainEntities.Enums
{
    public enum ArchiveStatus
    {
        [Description("Open")]
        Open,
        [Description("Ready For Approval")]
        ReadyForApproval,
        [Description("Approved")]
        Approved,
        [Description("Resubmitted – Open")]
        ResubmittedOpen,
        [Description("Resubmitted – Approved")]
        ResubmittedApproved,
		[Description("Resubmitted - Ready for Approval")]
		ResubmittedReadyForApproval
	}
}
