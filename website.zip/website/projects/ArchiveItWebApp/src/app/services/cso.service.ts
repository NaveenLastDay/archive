import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable, BehaviorSubject, of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CsoService {
  apiData: any;
  constructor(private _http: HttpClient) { }
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'

    }),

  }
  // /api/archive/getArchiveCSODetails 
  public getArchiveCSODetails(ArchiveNumber: string, PageNumber: number, PageSize: number,SortBy: string,SortOrder: string,FilterBy: number,FilterText: string): Observable<any> {
    this.apiData = this._http.get<any>('archive/getArchiveCSODetails?ArchiveNumber=' + ArchiveNumber + '&PageNumber=' + PageNumber+ '&PageSize=' + PageSize+ '&SortBy=' + SortBy+ '&SortOrder=' + SortOrder
    + '&FilterBy=' + FilterBy+ '&FilterText=' + FilterText, this.httpOptions);
    return this.apiData;
  }

  // /api/archive/getComplianceStatusOverride 
  public GetComplianceStatusTypes(): Observable<any> {
    return this._http.get<any[]>("archive/getComplianceStatusOverride ", this.httpOptions);
  }

  // /api/archive/AddEditCSO 
  public AddEditCSO(parameters: any): Observable<any> {
    this.apiData = this._http.post<any>("archive/createorUpdateComplianceStatus", parameters, this.httpOptions);
    return this.apiData;
  }

  // /api/archive/GetArchivesforCSO 
  public GetArchivesforCSO(searchTerm: string, rowCount : any): Observable<any> {
    this.apiData = this._http.get<any>('archive/GetArchivesforCSO?searchTerm='+searchTerm +'&rowCount='+rowCount);
    return this.apiData;
  }

}
