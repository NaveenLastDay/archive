﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
   public class ArchiveTeam
    {
        public string ArchiveNumber { get; set; }

        public string CreatedBy { get; set; }

        public string ArchivePartner { get; set; }

        public string ArchiveManager { get; set; }

        public string ArchiveFieldSenior { get; set; }

        public string AdditionalArchiveFieldSenior { get; set; }

		public string SigningPartners { get; set; }
	}

    public class TemporaryArchiveTeam
    {
        public string ArchiveNumber { get; set; }

        public string CreatedBy { get; set; }

        public string TempArchivePartner { get; set; }

        public DateTime? TempArchivePartnerExpDate { get; set; }

        public string TempArchiveManager { get; set; }

        public DateTime? TempArchiveManagerExpDate { get; set; }

        public string TempArchiveFieldSenior { get; set; }

        public DateTime? TempArchiveFieldSeniorExpDate { get; set; }
    }
}
