import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ArchivesPendingSubmissionComponent } from './archives-pending-submission.component';

describe('ArchivesPendingSubmissionComponent', () => {
  let component: ArchivesPendingSubmissionComponent;
  let fixture: ComponentFixture<ArchivesPendingSubmissionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ArchivesPendingSubmissionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ArchivesPendingSubmissionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
