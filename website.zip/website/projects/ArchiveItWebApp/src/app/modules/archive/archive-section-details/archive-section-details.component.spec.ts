import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ArchiveSectionDetailsComponent } from './archive-section-details.component';

describe('ArchiveSectionDetailsComponent', () => {
  let component: ArchiveSectionDetailsComponent;
  let fixture: ComponentFixture<ArchiveSectionDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ArchiveSectionDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ArchiveSectionDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
