﻿using Deloitte.AIFA.DataModels;
using Deloitte.AIFA.DBHelper;
using Deloitte.AIFA.Models;
using Deloitte.AIFA.Repositories.UtilityHelper;
using System;
using System.Collections.Generic;
using System.Data;

namespace Deloitte.AIFA.Repositories.Transformers
{
    public enum UtilityField
    {
        UserAlias,
        DisplayName,
        LastName,
        EmailAddress,
        Function,
        ArchiveAccessRoleID,
        ArchiveAccessRole,
        ArchiveEmployeeArchiveAccessId,
        FirstName,
        IsPPD,
        IsManager,
        PersonnelNumber,
        IsRco,
        Office,
        LegalEntity,
        Title,
        OfficeLocation

    }

    public enum UtilityFieldParameter
    {
        [CreateField(Name = "p_Term", Direction = ParameterDirection.Input, Type = DbType.String)]
        Term,
        [CreateField(Name = "p_rolecode", Direction = ParameterDirection.Input, Type = DbType.String)]
        RoleCode,
        [CreateField(Name = "p_RowCount", Direction = ParameterDirection.Input, Type = DbType.Int32)]
        RowCount,
        [CreateField(Name = "p_FilterId", Direction = ParameterDirection.Input, Type = DbType.Int32)]
        FilterId,
        [CreateField(Name = "p_OfficeId", Direction = ParameterDirection.Input, Type = DbType.Int32)]
        OfficeId
    }

    public class UtilityTransformer : BaseTransformer<UtilityModel>
    {
        internal override UtilityModel TransformElement(IDataReader dr, Func<IDataReader, UtilityModel,UtilityModel> bindExtraFields = null)
        {

            return new  UtilityModel
            {
                UserAlias = dr[UtilityField.UserAlias.ToString()].ToString(),
                DisplayName = dr[UtilityField.DisplayName.ToString()].ToString(),
                LastName = dr[UtilityField.LastName.ToString()].ToString(),
                EmailAddress = dr[UtilityField.EmailAddress.ToString()].ToString(),
                Function = dr[UtilityField.Function.ToString()].ToString(),
                ArchiveAccessRoleID = (dr[UtilityField.ArchiveAccessRoleID.ToString()] is DBNull) ? 0 : int.Parse(dr[UtilityField.ArchiveAccessRoleID.ToString()].ToString()), 
                ArchiveAccessRole = dr[UtilityField.ArchiveAccessRole.ToString()].ToString(),
                ArchiveEmployeeArchiveAccessId = (dr[UtilityField.ArchiveEmployeeArchiveAccessId.ToString()] is DBNull) ? 0 : int.Parse(dr[UtilityField.ArchiveEmployeeArchiveAccessId.ToString()].ToString()),
                FirstName = dr[UtilityField.FirstName.ToString()].ToString(),
                IsPPD = (dr[UtilityField.IsPPD.ToString()] is DBNull) ? false : Convert.ToBoolean(dr[UtilityField.IsPPD.ToString()]),
                IsManager  = (dr[UtilityField.IsManager.ToString()] is DBNull) ? false : Convert.ToBoolean(dr[UtilityField.IsManager.ToString()]),
                PersonnelNumber = (dr[UtilityField.PersonnelNumber.ToString()] is DBNull) ? 0 : int.Parse(dr[UtilityField.PersonnelNumber.ToString()].ToString()),
                IsRco = (dr[UtilityField.IsRco.ToString()] is DBNull) ? 0 : int.Parse(dr[UtilityField.IsRco.ToString()].ToString()),
                Office = (dr[UtilityField.Office.ToString()] is DBNull) ? string.Empty : dr[UtilityField.Office.ToString()].ToString(),
                LegalEntity = (dr[UtilityField.LegalEntity.ToString()] is DBNull) ? string.Empty : dr[UtilityField.LegalEntity.ToString()].ToString(),
                Title = (dr[UtilityField.Title.ToString()] is DBNull) ? string.Empty : dr[UtilityField.Title.ToString()].ToString(),
                OfficeLocation = (dr[UtilityField.OfficeLocation.ToString()] is DBNull) ? string.Empty : dr[UtilityField.OfficeLocation.ToString()].ToString(),
            };

        }

        //protected internal static Func<IDataReader, UtilityModel, UtilityModel> BindForGetUtilityByUserAlias
        //{
        //    get
        //    {
        //        return (dr, utility) =>
        //        {
        //            utility.DisplayName = dr[UtilityField.DisplayName.ToString()].ToString();
        //            utility.LastName = dr[UtilityField.LastName.ToString()].ToString();
        //            utility.EmailAddress = dr[UtilityField.EmailAddress.ToString()].ToString();
        //            utility.Function = dr[UtilityField.Function.ToString()].ToString();
        //            utility.ArchiveAccessRoleID = (dr[UtilityField.ArchiveAccessRoleID.ToString()] is DBNull) ? 0 : int.Parse(dr[UtilityField.ArchiveAccessRoleID.ToString()].ToString());
        //            utility.ArchiveAccessRole = dr[UtilityField.ArchiveAccessRole.ToString()].ToString();
        //            utility.ArchiveEmployeeArchiveAccessId = (dr[UtilityField.ArchiveEmployeeArchiveAccessId.ToString()] is DBNull) ? 0 : int.Parse(dr[UtilityField.ArchiveEmployeeArchiveAccessId.ToString()].ToString());
        //            utility.FirstName = dr[UtilityField.FirstName.ToString()].ToString();
        //            utility.IsPPD = (dr[UtilityField.IsPPD.ToString()] is DBNull) ? false : Convert.ToBoolean(dr[UtilityField.IsPPD.ToString()].ToString());
        //            utility.IsManager = (dr[UtilityField.IsManager.ToString()] is DBNull) ? false : Convert.ToBoolean(dr[UtilityField.IsManager.ToString()].ToString());
        //            utility.PersonnelNumber = (dr[UtilityField.PersonnelNumber.ToString()] is DBNull) ? 0 : int.Parse(dr[UtilityField.PersonnelNumber.ToString()].ToString());



        //            return utility;
        //        };
        //    }
        //}

     
    }


    #region UpsertEventSource
    public enum EventSourceOutputFields
    {
        EventSourceID,
        EventTypeID,
        Metadata,
        IsProcessed
    }

    public enum EventSourceFieldParameter
    {
        [CreateField(Name = "EventSourceID_IN", Direction = ParameterDirection.Input, Type = DbType.Int64)]
        EventSourceID,
        [CreateField(Name = "EventTypeID_IN", Direction = ParameterDirection.Input, Type = DbType.Int32)]
        EventTypeID,
        [CreateField(Name = "Metadata_IN", Direction = ParameterDirection.Input, Type = DbType.String)]
        Metadata,
        [CreateField(Name = "IsProcessed_IN", Direction = ParameterDirection.Input, Type = DbType.Boolean)]
        IsProcessed,
        [CreateField(Name = "Date_IN", Direction = ParameterDirection.Input, Type = DbType.DateTime)]
        Date,
        [CreateField(Name = "UserAlias_IN", Direction = ParameterDirection.Input, Type = DbType.String)]
        UserAlias
    }
    public class EventSourceTransformer : BaseTransformer<EventSourceModel>
    {
        internal override EventSourceModel TransformElement(IDataReader dr, Func<IDataReader, EventSourceModel, EventSourceModel> bindExtraFields = null)
        {
            return new EventSourceModel
            {
                EventSourceID = (dr[EventSourceOutputFields.EventSourceID.ToString()] is DBNull) ? 0 : int.Parse(dr[EventSourceOutputFields.EventSourceID.ToString()].ToString()),
                EventTypeID = (dr[EventSourceOutputFields.EventTypeID.ToString()] is DBNull) ? 0 : int.Parse(dr[EventSourceOutputFields.EventTypeID.ToString()].ToString()),
                Metadata = (dr[EventSourceOutputFields.Metadata.ToString()] is DBNull) ? string.Empty : dr[EventSourceOutputFields.Metadata.ToString()].ToString(),
                IsProcessed = (dr[EventSourceOutputFields.IsProcessed.ToString()] is DBNull) ? false : Convert.ToBoolean(dr[EventSourceOutputFields.IsProcessed.ToString()]),
            };
        }
    }
    #endregion UpsertEventSource


    public class RoleFunctionTransformer : BaseTransformer<RoleFunctionModel>
    {
        internal override RoleFunctionModel TransformElement(IDataReader dr, Func<IDataReader, RoleFunctionModel, RoleFunctionModel> bindExtraFields = null)
        {
            return new RoleFunctionModel
            {
                Id = Convert.ToInt32((dr[RoleFunctionOutputFields.Id.ToString()])),
                FunctionName = (dr[RoleFunctionOutputFields.FunctionName.ToString()] is DBNull ? string.Empty : dr[RoleFunctionOutputFields.FunctionName.ToString()].ToString())

            };
        }

    }

    public enum RoleFunctionOutputFields
    {
        Id,
        FunctionName


    }

}
