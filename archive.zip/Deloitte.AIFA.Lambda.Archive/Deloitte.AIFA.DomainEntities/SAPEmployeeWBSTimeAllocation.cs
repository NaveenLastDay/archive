﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
    public class SAPEmployeeWBSTimeAllocation
    {
        public string EmployeeFullName { get; set; }
        public string EmployeeEmailAddress { get; set; }
        public string CsHours { get; set; }
    }
}
