﻿using System;

namespace Deloitte.AIFA.Models
{
    public class ArchiveMetaDataModel
    {
        public bool IsAuditEngagement { get; set; }
        public bool IsArchiveNeeded { get; set; }
        public string EngagementDesc { get; set; }
        public DateTime PeriodEnd { get; set; }
        public string EngagementType { get; set; }
        public bool IsDeliverable { get; set; }
        public DateTime EstimatedDate { get; set; }
        public DateTime CompletionDate { get; set; }
        public string Office { get; set; }
        public string EntityType { get; set; }
        public string ProfessionalStandards { get; set; }
        public string WBSLevel1Archive { get; set; }
        public string ArchiveNum { get; set; }
        public string AdditionalDescriptor { get; set; }
    }
}
