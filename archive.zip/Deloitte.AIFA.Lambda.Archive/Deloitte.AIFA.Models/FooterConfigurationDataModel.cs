﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DataModels
{
	public class FooterConfigurationDataModel
	{
		public int Id { get; set; }
		public string TSPropertyName { get; set; }
		public string Link { get; set; }
		public string DisplayName { get; set; }
		public int SortOrder { get; set; }
		public double WidthInPercentage { get; set; }
	}
}
