﻿using Deloitte.AIFA.DataModels;
using Deloitte.AIFA.DomainEntities;
using System;
using System.Collections.Generic;

namespace Deloitte.AIFA.DomainServices.Contracts
{
    public interface IUtilityService
    {
        List<Utility> GetUtilityDetail(string useralias,string rolecode);
        EventSource UpsertEventSource(EventSource eventSource);
        List<RoleFunction> GetRoleFunctions();

        object IsUserAuthorizedAndInputIsValid(string archiveNumber, int functionId, string userAlias, object value, out bool isValid, string Keyword = null);

        object IsInputIsSanitized(object value,out bool isValid);
        bool IsUserAuthorizedtoPerformAction(string archiveNumber, int functionId, string userAlias, string Keyword = null);
    }
}
