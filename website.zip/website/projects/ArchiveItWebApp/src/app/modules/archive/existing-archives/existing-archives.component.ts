import { Component, OnInit } from '@angular/core';
import { DataSource } from '@angular/cdk/collections';
import { Observable, of } from 'rxjs';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { Router, NavigationEnd, ActivatedRoute, ParamMap } from '@angular/router';
import { MatPaginator, MatTableDataSource, PageEvent } from '@angular/material';
import { ExistingArchivesService } from '../../../services/existing-archives.service';
import { NgxSpinnerService } from "ngx-spinner";
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import {HomePageService} from '../../../services/homepage.service'
import {ResizeEvent} from 'angular-resizable-element';
import { UserConfigSettingService } from '../../../guards/user-role-guard.service';
import { ArchiveService } from '../../../services/archive.service';
@Component({
  selector: 'app-existing-archives',
  templateUrl: './existing-archives.component.html',
  styleUrls: ['./existing-archives.component.css'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0', display: 'none' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class ExistingArchivesComponent implements OnInit {
  currentUrl: string;
  selectedItem: any;
  rowcountparam: any;
  rowcount: any;
  apidata: any[];
  apidata2: any[];
  pageUrl: String;
  lstExistingArchives:any[];
  archiveSearchBase:any[];
  datasource:any;
  showTable:boolean;
  pageCount: number = 10;
  hoverIndex : number=-1;  
  employeeRoleId:number = 15;
  pageSize: number = 10;
  appendArchiveToGrid: boolean = false;
  userAlias = this.adalSvc.LoggedInUserEmail.substring(0, this.adalSvc.LoggedInUserEmail.lastIndexOf("@"));
  columnsToDisplay = ['action', 'archiveNumber', 'periodEndDate', 'archiveName', 'edcd','status', 'description',"SelectArchive"];
  userConfig: any;
  expandedElement : any;
  currentPageNumber: number = 1;
  myArchives: any;
  totalArchives: number = 0;
  lstExistingArchives1: any;
  archiveDetails: any;
  constructor(private router: Router,private _userConfig:UserConfigSettingService,private archiveService: ArchiveService,private adalSvc: MsAdalAngular6Service,private homepageSvc: HomePageService, private exisingArchiveService: ExistingArchivesService, private activatedRoute: ActivatedRoute,private SpinnerService: NgxSpinnerService) { }

  ngOnInit() {
    this.userConfig = this._userConfig.FetchLoggedInUser(this.userAlias);
    if(this.userConfig.value.IsManager||this.userConfig.value.IsPPD||this.userConfig.value.isAdmin){ 
    this.selectedItem = this.activatedRoute.snapshot.params.optionSelectedvalue;
    this.rowcountparam = 99;
    this.getAllArchives(this.selectedItem,this.userAlias,this.currentPageNumber, this.pageSize);
    }
    else{
      this.router.navigate(["/"]);
    }
  }

  showdetails(element){
    console.log(element);
    //this.SpinnerService.show();
    this.archiveService.GetMyArchiveDetails(element).subscribe(
      data => {        
        this.archiveDetails = data;
        console.log(this.archiveDetails);
       // this.SpinnerService.hide();
      });  
  }

 

  OnClick(PageUrl) {
     this.router.navigate(["/" + PageUrl + ""]);
  }

  OnClickCreate(PageUrl){
    this.router.navigate(["/" + PageUrl + "/"+this.selectedItem]);
  }
  

  getAllArchives(x: string, userAlias:string, pagenumber: number, pageSize:number) {
   // this.SpinnerService.show();
    this.exisingArchiveService.getExistingArchives(x,userAlias,pagenumber,pageSize).subscribe(data => {
      if (this.appendArchiveToGrid && data) {
        this.apidata = data;
        this.lstExistingArchives1=this.apidata[0].lstExistingArchives;
        this.lstExistingArchives = this.lstExistingArchives.concat(this.lstExistingArchives1);
        }
        else {
          this.apidata = data;
          this.lstExistingArchives=this.apidata[0].lstExistingArchives;
        }
      this.archiveSearchBase=this.apidata[0].archiveSearchBase;
      if (data[0].lstExistingArchives.length!="0"){
      this.totalArchives = this.apidata[0].archiveSearchBase.count;
      this.showTable=true;
      }
       else{
          this.showTable=false;
          this.totalArchives=0;
          this.router.navigate(["/" + "archive/createarchive" + "/"+ x]);
      }
      

      //this.SpinnerService.hide();      
    }); 

  }

  updateGridData(event) {
    this.appendArchiveToGrid = event.isLoadMoreClicked;
    this.currentPageNumber = event.pageNumber;
    this.getAllArchives(this.selectedItem,this.userAlias,this.currentPageNumber, this.pageSize);
  }

  handleMouseOver(index) {
    this.hoverIndex = index;
  }

  handleMouseLeave(index) {
    this.hoverIndex = index;
  }
  onResizeColumnEnd(event: ResizeEvent, columnName): void {
		if (event.edges.right) {
			const cssValue = event.rectangle.width + 'px';
			const columnElts = document.getElementsByClassName('mat-column-' + columnName);
			for (let i = 0; i < columnElts.length; i++) {
				const currentEl = columnElts[i] as HTMLDivElement;
				currentEl.style.width = cssValue;
			}
		}
	}
}


export interface Element {
  ArchiveNumber: string;
  PeriodEnd: string;
  EngagementDescription: number;
  EDCD: string;
  Status: string;
  ArchiveDescription: string;
}



