import { TestBed } from '@angular/core/testing';

import { StsserviceService } from './stsservice.service';

describe('StsserviceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: StsserviceService = TestBed.get(StsserviceService);
    expect(service).toBeTruthy();
  });
});
