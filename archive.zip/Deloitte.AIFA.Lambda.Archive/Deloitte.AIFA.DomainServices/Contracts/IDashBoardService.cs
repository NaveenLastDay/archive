﻿
using Deloitte.AIFA.DomainEntities;
using System.Collections.Generic;

namespace Deloitte.AIFA.DomainServices.Contracts
{
    public interface IDashBoardService
    {
        UserDashboardResponse GetUserDashboardData(string userAlias);
        List<MyForm3283Data> GetForm3283DashBoardData(string EmployeeUniqueIdentifier, int pageNumber, int pageSize);
        List<MyComplianceData> GetMyAwaitingApprovalDashBoardData(string userAlias, int pageNumber, int pagesize);
        List<MyComplianceData> GetArchiveDeletionsDashBoardData(string userAlias, int pageNumber, int pagesize);
        List<MyPendingSubmissionData> GetMyAwaitingSubmissionDashBoardData(string userAlias, int pageNumber, int pagesize);
        List<MyComplianceData> GetMyRequiringApprovalDashBoardData(string userAlias, int pageNumber, int pagesize);
        List<ComplianceMetricsDetails> GetComplianceMetrics(string EmployeeUniqueIdentifier, int pageNumber, int pageSize, int sortBy, string filterText);
    }

}
