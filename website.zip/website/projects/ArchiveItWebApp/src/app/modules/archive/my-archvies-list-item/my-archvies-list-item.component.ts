import { Component, OnInit, Input } from '@angular/core';
import { ArchiveService } from '../../../services/archive.service';
import { NgxSpinnerService } from 'ngx-spinner'; 

@Component({
  selector: 'app-my-archvies-list-item',
  templateUrl: './my-archvies-list-item.component.html',
  styleUrls: ['./my-archvies-list-item.component.css']
})
export class MyArchviesListItemComponent implements OnInit {

  archiveDetails:any;
  @Input('ArchiveNumber') archiveNumber : string;
  
  constructor(private archiveService : ArchiveService, private SpinnerService: NgxSpinnerService) { 

  }

  ngOnInit() {
    this.archiveService.GetMyArchiveDetails(this.archiveNumber).subscribe(
      data => {        
        this.archiveDetails = data;
      });    
  }
  
}
