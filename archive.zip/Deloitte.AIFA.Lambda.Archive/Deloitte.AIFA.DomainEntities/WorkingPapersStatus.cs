﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
    public class WorkingPapersStatus
    {
        public string wkpdescription { get; set; }
        public string createdBy { get; set; }
    }
}
