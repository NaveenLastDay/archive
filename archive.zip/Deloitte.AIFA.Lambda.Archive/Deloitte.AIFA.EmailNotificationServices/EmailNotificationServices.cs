﻿using Deloitte.AIFA.DomainEntities.EmailEntities;
using Deloitte.AIFA.PushMessageSNSHelper;
using Newtonsoft.Json;
using System;

namespace Deloitte.AIFA.EmailNotificationServices
{
    public class EmailNotificationService: IEmailNotificationService
    {
        public bool PublishEmailNotification(BaseEmailEntity argBE)
        {
            bool retval=false;
            try
            {
                PushMessageSNS objEmail = new PushMessageSNS("emailembeddednotifyarn");
                string JSONData = JsonConvert.SerializeObject(argBE);
                // _logger.LogInformation("Json Data : " + JSONData);
                var messageIdEmail = objEmail.PushMsgtoSNS(JSONData).Result;
                Console.WriteLine("Message Pushed with Id" + messageIdEmail);
                retval = messageIdEmail == null ? false : true;
                //_logger.LogInformation("SNS MessageId: " + messageIdEmail + " for Email Archive Temp Access: " + requestAccess.ArchiveNumber);
            }
            catch {

            }
            return retval;
        }
    }
}
