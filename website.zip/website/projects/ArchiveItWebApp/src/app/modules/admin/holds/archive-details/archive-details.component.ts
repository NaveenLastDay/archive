import { Component, OnInit } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { FormBuilder, Validators } from '@angular/forms';
import { HoldsService } from '../../../../services/holds-admin.service';
import { NotifierService} from "angular-notifier";
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { ModalService } from '../../../shared/modal';
import { SharedService } from '../../../../services/shared.service';
import { formatDate } from '@angular/common';



@Component({
  selector: 'app-archive-details',
  templateUrl: './archive-details.component.html',
  styleUrls: ['./archive-details.component.css']
})

export class ArchiveDetailsComponent implements OnInit{
ClientName:string;
ArchiveName:string;
ArchiveNumber:string;
hoverIndex: number = -1;
Business:string;
PeriodEnd:Date;
archiveHoldDetailsList:any[];
ArchiveHistoryDetails:any[];
 /*sorting */
 columnByEnum: any = HoldsColumnBy;
 sortColumnDialog: number = -1;
 sortColumn : string ='';
 HoldNumbertobedeleted:string;
 sortascdesc: number=0;
 sortBy: number = 0;
 GetHoldNumberFromSearchScreen:string;
 /*sorting*/

 /*Export to Excel */
 holdsResultGridColumns: any =HoldsResultGridColumns;
 holdsHistoryGridColumns: any =HoldsHistoryGridColumns; 
 readonly emptyStringInReport : string = " ";
 columnFilters: any[] =
 [
   {
     "displayName": "HoldName",
     "value": this.holdsResultGridColumns.HoldName,
     "checked": true
   },
   {
     "displayName": "ClientName",
     "value": this.holdsResultGridColumns.ClientName,
     "checked": true
   },
   {
     "displayName": "Business",
     "value": this.holdsResultGridColumns.Business,
     "checked": true
   },
   {
     "displayName": "EffectiveStartDate",
     "value": this.holdsResultGridColumns.EffectiveStartDate,
     "checked": true
   },

   {
     "displayName": "EffectiveEndDate",
     "value": this.holdsResultGridColumns.EffectiveEndDate,
     "checked": true
   },
   {
    "displayName": "Status",
    "value": this.holdsResultGridColumns.Status,
    "checked": true
  },
  {
    "displayName": "ArchiveCount",
    "value": this.holdsResultGridColumns.ArchiveCount,
    "checked": true
  }
 ]
 /*Export to Excel */
 columnHistoryFilters: any[] =
  [
    {
      "displayName": "Archive#",
      "value": this.holdsHistoryGridColumns.HoldNumber,
      "checked": true
    },
    {
      "displayName": "Status",
      "value": this.holdsHistoryGridColumns.Status,
      "checked": true
    },

    {
      "displayName": "CreatedBy",
      "value": this.holdsHistoryGridColumns.CreatedBy,
      "checked": true
    },
    {
      "displayName": "CreatedDate",
      "value": this.holdsHistoryGridColumns.CreatedDate,
      "checked": true
    }
  ]

constructor(
  private _HoldService:HoldsService,
  private _Router:Router,
  private _modalService:ModalService,
  private _notifierService:NotifierService
  ,private sharedService: SharedService
  

){}

ngOnInit()
{
    this.GetHoldNumberFromSearchScreen=localStorage.getItem('HoldNumberForHistory');
    var ArchiveDetailsFromHoldDetailspage=localStorage.getItem('ArchiveDetailsInfo');
    console.log('Message from Archive Details Component',JSON.parse(ArchiveDetailsFromHoldDetailspage));
    var ArchiveDetailsObj=JSON.parse(ArchiveDetailsFromHoldDetailspage);
    this.ClientName=ArchiveDetailsObj.clientName;
    this.ArchiveName=ArchiveDetailsObj.archiveName;
    this.ArchiveNumber=ArchiveDetailsObj.archiveNumber;
    this.Business=ArchiveDetailsObj.businessName;
    this.PeriodEnd=ArchiveDetailsObj.periodEnd;
    this._HoldService.GetHoldsRelatedToArchive(this.ArchiveNumber,'',0).subscribe(data=>
    {
      if(data)
      {
        this.archiveHoldDetailsList=data;
        console.log(this.archiveHoldDetailsList);
      }
    });

}
closeModalDialog(Action) {
  this._modalService.close(Action);
}
openPopupForRemoveHold(modalType: string,HoldNumber:string) {
  this.HoldNumbertobedeleted=HoldNumber;
  this._modalService.openWithCustomWidth(modalType, "480");
}

RemoveHoldFromArchive(holdNumber:string)
{
  //this.SpinnerService.show();
    this._HoldService.RemoveHoldFromArchive(holdNumber,this.ArchiveNumber).subscribe(
      data=>{
        if(data.result=="1")
        {
          console.log('Successfully removed Hold from Archive',data);
          this._modalService.close('remove-hold');
          this.archiveHoldDetailsList = this.archiveHoldDetailsList.filter(item => item.holdNumber !== holdNumber);
         // this.SpinnerService.hide();
          this._notifierService.notify(
            "success",
            holdNumber+ " removed successfully"
          );
        }
        else{
          this._modalService.close('remove-hold');
          this._notifierService.notify(
            "error",
            holdNumber+ " failed to remove"
          );
          //this.SpinnerService.hide();

        }
      },
        err => {
          
          this._modalService.close('remove-hold');
          this._notifierService.notify(
            "error",
            holdNumber+ " failed to remove"
          );
          //this.SpinnerService.hide();
        }
      
    );
}
OpenArchiveHistorydetails()
{
  //Get the Holds details associated with Archive
  this._HoldService.GetHoldDetailsHistoryForHold(0,this.ArchiveNumber,1).subscribe(
    data => {
      if(data)
      {
        this.ArchiveHistoryDetails = data.result;
        console.log(data.result);
      }
    });
  
  this._modalService.openWithCustomWidth("Holds_History_Modal", "600");
}
mouseOver(event: any, index: number) {
  this.hoverIndex = index;
}

mouseOut(event: any) {
  let name: string = '';
  let present: number = -1;

  name = event.toElement ? event.toElement.getAttribute('name') : '';
  present = name ? name.search("AccessArchiveTop") : -1;

  if (event.toElement && present == -1 && (event.toElement["tagName"] != 'td' || event.toElement.className == 'trArchiveHoldsGridHeadFont')) {
    this.hoverIndex = -1;
  }
}
GetHoldNumberForHoldDetails(holdNumbers:string)
{
  var objects=this.archiveHoldDetailsList.filter(({ holdNumber }) => holdNumber == holdNumbers); 
  localStorage.setItem('HoldFromArchiveDetails',JSON.stringify(objects));
  console.log('Hello message',localStorage.getItem('HoldFromArchiveDetails'));
  this._Router.navigate(["admin/adminsidenavbar/holds/holdsearch/" + holdNumbers]);
}
Returntoholds(){
      this._Router.navigate(["admin/adminsidenavbar/holds/holdsearch/"+this.GetHoldNumberFromSearchScreen]);
}
// Returntoholds(){
//     this._Router.navigate(["admin/adminsidenavbar/holds/holddetails"]);
// }

generateReportClicked(data1){
  //this.SpinnerService.show();
  let archiveForReport: any[] = [];
  let filterdColumns = (data1.filter(x => x.checked));
    this._HoldService.GetHoldsRelatedToArchive(this.ArchiveNumber,this.sortColumn,this.sortascdesc).subscribe(
      data => {
        if (data.length > 0) {
          data.forEach(element => {
            let archive = {};
            filterdColumns.forEach(column => {

              if (column["value"] == this.holdsResultGridColumns.HoldName) { //Archive#
                archive[this.holdsResultGridColumns[this.holdsResultGridColumns.HoldName]] = element.holdNumber || this.emptyStringInReport;
              }
              if (column["value"] == this.holdsResultGridColumns.ClientName) { //Archive#
                archive[this.holdsResultGridColumns[this.holdsResultGridColumns.ClientName]] = element.clientName || this.emptyStringInReport;
              }
              if (column["value"] == this.holdsResultGridColumns.Business) { //Archive#
                archive[this.holdsResultGridColumns[this.holdsResultGridColumns.Business]] = element.business || this.emptyStringInReport;
              }
              if (column["value"] == this.holdsResultGridColumns.EffectiveStartDate) { //Archive#
                archive[this.holdsResultGridColumns[this.holdsResultGridColumns.EffectiveStartDate]] = element.effectiveStartDate || this.emptyStringInReport;
              }
              if (column["value"] == this.holdsResultGridColumns.EffectiveEndDate) { //Archive#
                archive[this.holdsResultGridColumns[this.holdsResultGridColumns.EffectiveEndDate]] = element.effectiveEndDate || this.emptyStringInReport;
              }
              if (column["value"] == this.holdsResultGridColumns.Status) { //Archive#
                archive[this.holdsResultGridColumns[this.holdsResultGridColumns.Status]] = element.holdStatus || this.emptyStringInReport;
              }
              if (column["value"] == this.holdsResultGridColumns.ArchiveCount) { //Archive#
                archive[this.holdsResultGridColumns[this.holdsResultGridColumns.ArchiveCount]] = element.count || this.emptyStringInReport;
              }
              
            });
            archiveForReport.push(archive);
          });
          if (archiveForReport && archiveForReport.length) {
            this.sharedService.generateExcel("Holdsfor", "Holds", filterdColumns.map(x => x.displayName), archiveForReport);
          }
        }
      });
    }

    generateHistoryReportClicked(data1){
      //this.SpinnerService.show();
      let archiveForReport: any[] = [];
      let filterdColumns = (data1.filter(x => x.checked));
      this._HoldService.GetHoldDetailsHistoryForHold(0,this.ArchiveNumber,1).subscribe(
       
        data => {
          if (data.result.length > 0) {
            data.result.forEach(element => {
              let archive = {};
              filterdColumns.forEach(column => {
                if (column["value"] == this.holdsHistoryGridColumns.HoldNumber) { //Archive#
                  archive[this.holdsHistoryGridColumns[this.holdsHistoryGridColumns.HoldNumber]] = element.holdNumber || this.emptyStringInReport;
                }
                if (column["value"] == this.holdsHistoryGridColumns.Status) { //Archive#
                  archive[this.holdsHistoryGridColumns[this.holdsHistoryGridColumns.Status]] = element.status || this.emptyStringInReport;
                }
                if (column["value"] == this.holdsHistoryGridColumns.CreatedBy) { //Archive#
                  archive[this.holdsHistoryGridColumns[this.holdsHistoryGridColumns.CreatedBy]] = element.createdBy || this.emptyStringInReport;
                }
                if (column["value"] == this.holdsHistoryGridColumns.CreatedDate) { //Archive#
                  archive[this.holdsHistoryGridColumns[this.holdsHistoryGridColumns.CreatedDate]] = formatDate(element.createdDate,'short','en-US','UTC -6') || this.emptyStringInReport;
                }

                
              });
              archiveForReport.push(archive);
            });
            if (archiveForReport && archiveForReport.length) {
              this.sharedService.generateExcel("Holdsfor"+this.ArchiveNumber, "Holds", filterdColumns.map(x => x.displayName), archiveForReport);
            }
          }
        });
      }
      



sortOrderChanged(event) {
  this.sortBy = event;

  console.log("sortOrderChanged ",this.sortColumnDialog +"Before"+this.sortBy)
  if(this.sortBy==1 || this.sortBy==3 || this.sortBy==5)
  {
    this.sortascdesc=1;
  }
  else if(this.sortBy==2 || this.sortBy==4 || this.sortBy==6)
  {
    this.sortascdesc=0;
  }
  if(this.sortColumnDialog==1)
  {
    this.sortColumn='HoldNumber';
  }
  else if(this.sortColumnDialog==2){
    this.sortColumn='ClientName';
  }
  else if(this.sortColumnDialog==3)
  {
    this.sortColumn='Business';
  }
  else if(this.sortColumnDialog==4){
    this.sortColumn='EffectiveStartDate';
  }
  else if(this.sortColumnDialog==5)
  {
    this.sortColumn='EffectiveEndDate';
  }
  else if(this.sortColumnDialog==6){
    this.sortColumn='HoldStatus';
  }
  else if(this.sortColumnDialog==7){
    this.sortColumn='ArchiveCount';
  }
  else{
    this.sortColumn='';
  }
  console.log("sortColumn",this.sortColumn);
  console.log("sortascdesc",this.sortascdesc);
 /* this.currentPageNumber=1;*/
  this.getHoldsDataforSort();
  console.log("sortOrderChanged ",this.sortColumnDialog +"After"+this.sortBy)
}
getHoldsDataforSort(){
  this._HoldService.GetHoldsRelatedToArchive(this.ArchiveNumber,this.sortColumn,this.sortascdesc).subscribe(data=>
    {
      if(data)
      {
        this.archiveHoldDetailsList=data;
        console.log(this.archiveHoldDetailsList);
      }
    });

}

memberSortDialog(event) {
  if (this.sortColumnDialog == event) this.sortColumnDialog = -1;
  else
  this.sortColumnDialog = event;
  console.log("memberSortDialog",this.sortColumnDialog);
}
memberSortDialogASCDESC(event){
 var clickedColumn:number=event;
  /*For HoldName*/
  if(clickedColumn==1 && this.sortBy!=7){
  this.sortBy=7;
   this.sortColumn="HoldNumber";
   this.sortascdesc=1;
 }
 else if(clickedColumn==1 && this.sortBy==7){
  this.sortBy=0;
  this.sortColumn="HoldNumber";
  this.sortascdesc=0;
 }
 /*For HoldName*/
 /*for EffectiveStartDate */
 else if(clickedColumn==4 && this.sortBy!=8){
  this.sortBy=8;
   this.sortColumn="EffectiveStartDate";
   this.sortascdesc=1;
 }
 else if(clickedColumn==4 && this.sortBy==8){
  this.sortBy=0;
  this.sortColumn="EffectiveStartDate";
  this.sortascdesc=0;
 }
 /*FoR Effective Start Date */
 /*for EffectiveStartDate */
 else if(clickedColumn==5 && this.sortBy!=9){
  this.sortBy=9;
   this.sortColumn="EffectiveEndDate";
   this.sortascdesc=1;
 }
 else if(clickedColumn==5 && this.sortBy==9){
  this.sortBy=0;
  this.sortColumn="EffectiveEndDate";
  this.sortascdesc=0;
 }
 /*FoR Effective Start Date */



 /*this.currentPageNumber=1;*/
 this.getHoldsDataforSort();
 

}

}
export enum HoldsColumnBy {
  ColumnBy_Default = -1,
  ColumnBy_HoldName = 1,
  ColumnBy_ClientName = 2,
  ColumnBy_Business = 3,
  ColumnBy_EffectiveStartDate = 4,
  ColumnBy_EffectiveEndDate = 5,
  ColumnBy_Status = 6,
  ColumnBy_ArchiveCount = 7,
}
export enum HoldsResultGridColumns
{
HoldName = 1,
ClientName = 2,
Business = 3,
EffectiveStartDate = 4,
EffectiveEndDate= 5,
Status = 6,
ArchiveCount = 7
}
export enum HoldsHistoryGridColumns
{
  HoldNumber=1,
  Status=2,
  CreatedBy=3,
  CreatedDate=4
}