import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdvancedSearchLandingPageComponent } from './advanced-search-landing-page.component';

describe('AdvancedSearchLandingPageComponent', () => {
  let component: AdvancedSearchLandingPageComponent;
  let fixture: ComponentFixture<AdvancedSearchLandingPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdvancedSearchLandingPageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdvancedSearchLandingPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
