import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { String } from 'aws-sdk/clients/cloudtrail';


@Injectable({
  providedIn: 'root'
})

export class HoldsService {
 

  data: any;
  apiData: any;
  create: any;
  useralias: string;
  result: string;
  wbsinfo: any;
  roles: any;
  success: Observable<any>;
  UpdateArchive: any;
  

  constructor(private _http: HttpClient) { }
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
      
    }),
  }
   
  

  public GetEngagementType(): Observable<any> {
    
    //return this._http.get<any>(this.restURL,this.httpOptions);
    this.apiData = this._http.get<any>("ArchiveMetaData/EngagementType", this.httpOptions);

    return this.apiData;
  }
  public GetEntity(): Observable<any> {
    
    this.apiData = this._http.get<any[]>("ArchiveMetaData/ProfessionalStandard", this.httpOptions);

    return this.apiData;
  }


  public GetEntityType(): Observable<any> {
    
    this.apiData = this._http.get<any[]>("ArchiveMetaData/EntityTypes", this.httpOptions);
    return this.apiData;
  }


  public GetHolds(HoldName : string, pageNumber : number = 0, pageSize : number = 0, sortBy : number = 1, filterBy : number = 0, filterText : string = ""): Observable<any> {
   // debugger;
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    this.apiData = this._http.get<any[]>('hold/getHoldsforAdminScreen?holdName=' + HoldName, httpOptions);
    
    console.log('API Data' + this.apiData);
    return this.apiData;


      }

  public GetMyArchivesFilterData(employeeUniqueIdentifier : string,filterBy : number = 0): Observable<any> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    this.apiData = this._http.get<any[]>('archive/getmyarchivesfilterdatabyfiltertype?FilterBy='+filterBy
    , httpOptions);
    return this.apiData;
  }

  public GetMyArchiveDetails(archiveNumber: string): Observable<any> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    this.apiData = this._http.get<any[]>('archive/getmyarchivedetails?ArchiveNumber=' + archiveNumber, httpOptions);
    return this.apiData;
  }
  public GetHoldsInformationForHold(HoldNumber:string):Observable<any>{
     return this._http.get<any>("hold/GetHoldsInformationForHold?HoldNumber="+HoldNumber);
  }
  public GetEditArchiveDetails(archiveNumber: string): Observable<any> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    this.apiData = this._http.get<any[]>('archive/GetEditArchiveDetails?archiveNumber=' + archiveNumber, httpOptions);
    return this.apiData;
  }
  public GetClientDatabasedonSearch(SearchTerm:string):Observable<any>{
    this.apiData=this._http.get<any[]>('hold/GetClientData?SearchClientTerm='+SearchTerm,this.httpOptions);
    return this.apiData;
  }

  public UpdateArchiveDetails(parameters: any): Observable<any> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    this.UpdateArchive = this._http.post<any>("archive/UpdateArchiveDetails", parameters, this.httpOptions);
    console.log("Updated archive is", this.UpdateArchive);
    return this.UpdateArchive;
  }

  public GetArchiveHoldDetails(holdName: string): Observable<any> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    this.apiData = this._http.get<any[]>('hold/GetArchiveHoldDetails?HoldName=' + holdName, httpOptions);
    return this.apiData;
  }

  public CreateNewHolds(parameters:any): Observable<any>{
    // debugger;
    //const headers = new HttpHeaders().set('Content-Type', 'application/json; charset=utf-8');
  //this.success = this._http.post("Archive/UpdateArchiveTeam",parameters, { headers, responseType: 'text'});
  // return this.success;
    const headers = new HttpHeaders().set('Content-Type', 'application/json; charset=utf-8');
    this.success = this._http.post("hold/SaveHoldsInformation",parameters , { headers, responseType: 'text'});
    console.log("Create holds information", this.success);
    return this.success;
  }
  
   public UpdateHoldsData(parameters:any): Observable<any>{
     // debugger;
    //  this.apiData = this._http.post<any>("hold/UpdateHoldsInfo",parameters , this.httpOptions);
    //  console.log("Update holds information", this.apiData);
    // return this.apiData;
    const headers = new HttpHeaders().set('Content-Type', 'application/json; charset=utf-8');
    this.success = this._http.post("hold/UpdateHoldsInformation",parameters , { headers, responseType: 'text'});
    console.log("UpdateHoldsInfo holds information", this.success);
    return this.success;
  }

  public GetHoldsDataforAdminOld(holdsName:string): Observable<any>{
    // debugger;
    this.apiData = this._http.get<any>("hold/getHoldsforAdminScreen?holdName="+holdsName, this.httpOptions);
    console.log("Get holds information", this.apiData);
   return this.apiData;
  // const headers = new HttpHeaders().set('Content-Type', 'application/json; charset=utf-8');
  //   this.success = this._http.post("hold/GetArchiveHoldDetails",parameters , { headers, responseType: 'text'});
  //   console.log("Create holds information", this.success);
  //   return this.success;
 }

 public GetHoldsDataforAdmin(pageNumber : number = 0, pageSize : number = 0, sortBy : number = 1, filterBy : number = 0, filterText : string = ""
 ,holdNumber : string ='',clientName: string='',business:string='',
 holdStatus: number =1, effectiveStartDate:string,
 effectiveEndDate:string
 ): Observable<any> {
  const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
  this.apiData = this._http.get<any>("hold/getHoldsforAdminScreenWithPagination?PageNumber="+pageNumber
  +'&Pagesize='+ pageSize
  +'&SortBy='+ sortBy
  +'&FilterBy='+filterBy
  +'&FilterText='+filterText
  +'&HoldNumber='+holdNumber
  +'&ClientName='+clientName
  +'&Business='+business
  +'&HoldStatus='+holdStatus
  +'&EffectiveStartDate='+effectiveStartDate
  +'&EffectiveEndDate='+effectiveEndDate+''
  , httpOptions);
  console.log("Get holds information", this.apiData);
  return this.apiData;

}



// http://localhost:60140/api/hold/getHoldsforAdminScreenWithPagination?PageNumber=4&Pagesize=10&SortBy=0&FilterBy=0&FilterText





 public GetHoldsdetails(parameters:any): Observable<any>{
//   this.apiData = this._http.post<any>("hold/getHoldsforAdminScreen",parameters , this.httpOptions);
//   console.log("Get holds information", this.apiData);
//  return this.apiData;
const headers = new HttpHeaders().set('Content-Type', 'application/json; charset=utf-8');
    this.success = this._http.post("hold/getHoldsforAdminScreen",parameters , { headers});
    console.log("Create holds information", this.success);
    return this.success;
}

public GetArchiveHoldDetailss(holdName : string, pageNumber : number , pageSize : number ): Observable<any> {
  const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
  this.apiData = this._http.post<any[]>('hold/GetArchiveHoldDetailsWithPagination?holdName=' + holdName 
  +'&pageNumber='+pageNumber
  +'&pageSize='+ pageSize
  , httpOptions);
  console.log("apidata",this.apiData);
  return this.apiData;
}

public CreateOrUpdateholdTranfer(parameters: any): Observable<any> {
  this.apiData = this._http.post<any>("hold/CreateOrUpdateholdTranfer", parameters, this.httpOptions);
  return this.apiData;
}

public ApplyArchiveHolds(parameters: any): Observable<any> {
  debugger;
  this.apiData = this._http.post<any>("archive/ApplyArchiveHolds", parameters, this.httpOptions);
  return this.apiData;
}
public CreateOrUpdatehold (parameters: any): Observable<any> {
  this.apiData = this._http.post<any>("hold/CreateUpdateHoldsInformation", parameters, this.httpOptions);
  return this.apiData;
}

public GetHoldsByArchiveFileId(holdFileId: string): Observable<any> {
  this.apiData = this._http.post<any>("hold/GetHoldsByFileId?HoldFileId=" + holdFileId, this.httpOptions);
  return this.apiData;
}


public GetHoldByHoldNumber (parameters: string): Observable<any> {
  this.apiData = this._http.post<any[]>("hold/getHoldDetailByHoldNumber?HoldNumber=" + parameters, this.httpOptions);
  return this.apiData;
}

public GetBuisness(): Observable<any> {

  this.apiData = this._http.get<any[]>("hold/GetBusinessData", this.httpOptions);
  return this.apiData;
}

public GetHoldsAssociatedtoArchives (parameters: string): Observable<any> {
this.apiData = this._http.get<any[]>("hold/GetHoldsAssociatedtoArchives?ArchiveNumber=" + parameters, this.httpOptions);
return this.apiData;
}

public GetArchivesAssociatedtoHolds (holdNumber:string,businessId:number,clientid:string,FilterText:string,SortBy:number): Observable<any[]> {
  this.apiData = this._http.get<any[]>("archive/GetArchivesAssociatedtoHolds?HoldNumber=" + holdNumber +"&BusinessId="+businessId
  +"&ClientId="+clientid+"&FilterText="+FilterText+"&SortBy="+SortBy);
  return this.apiData;
  }

  public GetHoldsRelatedToArchive(archiveNumber:string,FilterText:string,SortBy:number):Observable<any[]>
  {
    this.apiData=this._http.get<any[]>("hold/GetHoldsAssociatedtoArchives?ArchiveNumber="+archiveNumber+"&FilterText="+FilterText+"&SortBy="+SortBy);
    return this.apiData;
  }
  public RemoveArchivesFromHold (holdId:number,archiveNumber:string): Observable<any> {
    this.apiData = this._http.post<any[]>("archive/RemoveArchiveFromHold?HoldId=" + holdId +"&ArchiveNumber="+archiveNumber,this.httpOptions);
    return this.apiData;
  }
  public RemoveHoldFromArchive(holdNumber:string,ArchiveNumber:string):Observable<any>{
    this.apiData = this._http.post<any[]>("archive/RemoveHoldFromArchive?ArchiveNumber=" + ArchiveNumber +"&HoldNumber="+holdNumber,this.httpOptions);
    return this.apiData;
  }
 
  public GetHoldDetailsHistoryForHold(HoldId:number,HoldorArchiveNumber:string,operationId:number):Observable<any>{
      this.apiData = this._http.get<any>("archive/GetHoldHistoryDetails?HoldId="+HoldId+"&HoldNumber="+HoldorArchiveNumber+"&ArchiveHoldHistoryId="+operationId, this.httpOptions);
      return this.apiData;
  }
  //public  GetArchivesForApplyingHold(SearchBy: string, SearchByValueCollection: any, IncludeOrExclude: string, holdName: string, business: string, PeriodStart: string, PeriodEnd: string, SortBy: string, SortOrder: string, PageNumber: number, pageSize: any) {
  /* this.apiData = this._http.get<any>("archive/GetArchivesForApplyingHold?SearchBy="+SearchBy+"&SearchByValue="+SearchByValueCollection+"&IncludeOrExclude="+IncludeOrExclude+"&HoldName="+holdName+"&Business="+business+"&PeriodStart="+PeriodStart
    +"&PeriodEnd="+PeriodEnd+"&SortBy="+SortBy+"&SortOrder="+SortOrder+"&PageNumber="+PageNumber
    +"&PageSize="+pageSize, this.httpOptions);
      return this.apiData;
  }*/
   public  GetArchivesForApplyingHold(parameters: any) {  
   this.apiData = this._http.post<any>("archive/GetArchivesForApplyingHold", parameters, this.httpOptions);
   return this.apiData;
   }
}




