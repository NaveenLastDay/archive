﻿using Deloitte.AIFA.DataModels;
using Deloitte.AIFA.DBHelper;
using Deloitte.AIFA.DomainEntities;
using Deloitte.AIFA.Models;
using Deloitte.AIFA.Repositories.UtilityHelper;
using System;
using System.Collections.Generic;
using System.Data;



namespace Deloitte.AIFA.Repositories.Transformers
{
    public enum ArchiveField
    {
        ArchiveNumber,
        ArchiveName,
        ArchiveStatus,
        ClientName,
        PeriodEndDate,
        WBSClosedDate,
        WBSNumber,
        WBSName,
        WBSStatus,
        WBSProjectType,
        WBSEngagementPPMD,
        EngagementManager,
        WBSClientNumber,
        WBSClientName,
        EngagementController,
        WBSLBP,
        WBSLCP
    }

    public enum ArchiveFieldParameter
    {
        [CreateField(Name = "ArchiveId", Direction = ParameterDirection.Input, Type = DbType.Int32)]
        ArchiveId,
        [CreateField(Name = "ArchiveNumber", Direction = ParameterDirection.Input, Type = DbType.String)]
        ArchiveNumber_In
    }
    public enum ArchiveMemoFieldParameter
    {
        [CreateField(Name = "ArchiveNumber", Direction = ParameterDirection.Input, Type = DbType.String)]
        ArchiveNumber,
        [CreateField(Name = "FileName", Direction = ParameterDirection.Input, Type = DbType.String)]
        FileName,
        [CreateField(Name = "FileSize", Direction = ParameterDirection.Input, Type = DbType.Int32)]
        FileSize,
        [CreateField(Name = "FileTypeID", Direction = ParameterDirection.Input, Type = DbType.Int32)]
        FileTypeID,
        [CreateField(Name = "CreatedBy", Direction = ParameterDirection.Input, Type = DbType.String)]
        CreatedBy,
        [CreateField(Name = "ETag", Direction = ParameterDirection.Input, Type = DbType.String)]
        ETag,
        [CreateField(Name = "ArchiveFileIdOut", Direction = ParameterDirection.Output, Type = DbType.Int32)]
        ArchiveFileIdOut,
        [CreateField(Name = "FileTransferIdOut", Direction = ParameterDirection.Output, Type = DbType.Int32)]
        FileTransferIdOut,
        [CreateField(Name = "ResponseMessageOut", Direction = ParameterDirection.Output, Type = DbType.String)]
        ResponseMessageOut,
        [CreateField(Name = "ArchiveFileID", Direction = ParameterDirection.Input, Type = DbType.String)]
        ArchiveFileID,
        [CreateField(Name = "FileTransferId", Direction = ParameterDirection.Input, Type = DbType.String)]
        FileTransferId,
        [CreateField(Name = "UserAlias", Direction = ParameterDirection.Input, Type = DbType.String)]
        UserAlias,
    }


    public enum ArchiveEstimatedReleaseDateFieldParameter
    {
        [CreateField(Name = "p_ArchiveNumber", Direction = ParameterDirection.Input, Type = DbType.String)]
        ArchiveNumber,
        [CreateField(Name = "p_EstimatedReleaseDate", Direction = ParameterDirection.Input, Type = DbType.DateTime)]
        EstimatedReleaseDate
    }

    public enum ArchiveResubmitOpenFieldParameter
    {
        [CreateField(Name = "p_ArchiveNumber", Direction = ParameterDirection.Input, Type = DbType.String)]
        ArchiveNumber
    }

    public enum ResubmissionOpenFieldParameter
    {
        [CreateField(Name = "TotalApprover", Direction = ParameterDirection.Input, Type = DbType.Int32)]
        TotalApprover,
        [CreateField(Name = "FirstName", Direction = ParameterDirection.Input, Type = DbType.String)]
        FirstName,
        [CreateField(Name = "LastName", Direction = ParameterDirection.Input, Type = DbType.String)]
        LastName,
        [CreateField(Name = "RoleID", Direction = ParameterDirection.Input, Type = DbType.String)]
        RoleID,
        [CreateField(Name = "CompletedApproval", Direction = ParameterDirection.Input, Type = DbType.String)]
        CompletedApproval,
        [CreateField(Name = "CanAccess", Direction = ParameterDirection.Input, Type = DbType.Boolean)]
        CanAccess,
        [CreateField(Name = "Type", Direction = ParameterDirection.Input, Type = DbType.String)]
        Type
    }

    public enum ArchiveEarlyTerminationDateOutputFields
    {
        ArchiveNumber,
        MetadataValue,
        EarlyTerminated,
        ModifiedBy,
        MetadataID
    }

    public enum ArchiveEarlyTerminationDateFieldParameter
    {
        [CreateField(Name = "p_ArchiveNumber", Direction = ParameterDirection.Input, Type = DbType.String)]
        ArchiveNumber,
        [CreateField(Name = "p_EarlyTerminationDate", Direction = ParameterDirection.Input, Type = DbType.DateTime)]
        EarlyTerminationDate,
        [CreateField(Name = "p_EarlyTerminated", Direction = ParameterDirection.Input, Type = DbType.Boolean)]
        EarlyTerminated,
        [CreateField(Name = "p_ModifiedBy", Direction = ParameterDirection.Input, Type = DbType.String)]
        ModifiedBy
    }

    public class ArchiveEarlyTerminationDateTransformer : BaseTransformer<EarlyTerminationDataModel>
    {
        internal override EarlyTerminationDataModel TransformElement(IDataReader dr, Func<IDataReader, EarlyTerminationDataModel, EarlyTerminationDataModel> bindExtraFields = null)
        {
            return new EarlyTerminationDataModel
            {
                ArchiveNumber = (dr[ArchiveEarlyTerminationDateOutputFields.ArchiveNumber.ToString()].ToString()),
                EarlyTerminationDate = (dr[ArchiveEarlyTerminationDateOutputFields.MetadataValue.ToString()] is DBNull) ? DateTime.MinValue : Convert.ToDateTime(dr[ArchiveEarlyTerminationDateOutputFields.MetadataValue.ToString()]),
                MetadataID = (dr[ArchiveEarlyTerminationDateOutputFields.MetadataID.ToString()] is DBNull) ? 0 : Convert.ToInt32(dr[ArchiveEarlyTerminationDateOutputFields.MetadataID.ToString()]),
                //EarlyTerminated = (dr[ArchiveEarlyTerminationDateOutputFields.EarlyTerminated.ToString()] is DBNull) ?  false : Convert.ToBoolean(dr[ArchiveEarlyTerminationDateOutputFields.EarlyTerminated.ToString()])

            };
        }
    }

    public enum ArchiveTeamFieldParameter
    {
        [CreateField(Name = "p_ArchiveNumber", Direction = ParameterDirection.Input, Type = DbType.String)]
        ArchiveNumber,
        [CreateField(Name = "p_Createdby", Direction = ParameterDirection.Input, Type = DbType.String)]
        Createdby,
        [CreateField(Name = "p_ArchivePartner", Direction = ParameterDirection.Input, Type = DbType.String)]
        ArchivePartner,
        [CreateField(Name = "p_ArchiveManager", Direction = ParameterDirection.Input, Type = DbType.String)]
        ArchiveManager,
        [CreateField(Name = "p_ArhiveFieldSenior", Direction = ParameterDirection.Input, Type = DbType.String)]
        ArchiveFieldSenior,
        [CreateField(Name = "p_AddArchiveFieldSenior", Direction = ParameterDirection.Input, Type = DbType.String)]
        AddArchiveFieldSenior,
        [CreateField(Name = "p_SigningPartners", Direction = ParameterDirection.Input, Type = DbType.String)]
        SigningPartners,
        [CreateField(Name = "p_TeamChangedBy", Direction = ParameterDirection.Input, Type = DbType.String)]
        TeamChangedBy

    }

    public enum TempArchiveTeamFieldParameter
    {
        [CreateField(Name = "p_ArchiveNumber", Direction = ParameterDirection.Input, Type = DbType.String)]
        ArchiveNumber,
        [CreateField(Name = "p_Createdby", Direction = ParameterDirection.Input, Type = DbType.String)]
        Createdby,
        [CreateField(Name = "p_TempArchivePartner", Direction = ParameterDirection.Input, Type = DbType.String)]
        TempArchivePartner,
        [CreateField(Name = "p_TempArchivePartnerExpDate", Direction = ParameterDirection.Input, Type = DbType.DateTime)]
        TempArchivePartnerExpDate,
        [CreateField(Name = "p_TempArchiveFieldSenior", Direction = ParameterDirection.Input, Type = DbType.String)]
        TempArchiveFieldSenior,
        [CreateField(Name = "p_TempArchiveFieldSeniorExpDate", Direction = ParameterDirection.Input, Type = DbType.DateTime)]
        TempArchiveFieldSeniorExpDate,
        [CreateField(Name = "p_TempArchiveManager", Direction = ParameterDirection.Input, Type = DbType.String)]
        TempArchiveManager,
        [CreateField(Name = "p_TempArchiveManagerExpDate", Direction = ParameterDirection.Input, Type = DbType.DateTime)]
        TempArchiveManagerExpDate
    }

    public enum TempRequestArchiveAccessFieldParameter
    {
        [CreateField(Name = "p_RequestedBy", Direction = ParameterDirection.Input, Type = DbType.String)]
        RequestedBy,
        [CreateField(Name = "p_RequestedOf", Direction = ParameterDirection.Input, Type = DbType.String)]
        RequestedOf,
        [CreateField(Name = "p_DispositiontypeId", Direction = ParameterDirection.Input, Type = DbType.Int32)]
        DispositionTypeId,
        [CreateField(Name = "p_RequestedArchiveNumber", Direction = ParameterDirection.Input, Type = DbType.String)]
        ArchiveNumber,
        [CreateField(Name = "p_RequestDescription", Direction = ParameterDirection.Input, Type = DbType.String)]
        Description

    }

    public enum GrantDenyTempArchiveAccessFieldParameter
    {
        [CreateField(Name = "p_ArchiveAccessRequestId", Direction = ParameterDirection.Input, Type = DbType.String)]
        ArchiveAccessRequestId,
        [CreateField(Name = "GrantDenyReason", Direction = ParameterDirection.Input, Type = DbType.String)]
        GrantDenyReason,
        [CreateField(Name = "GrantOrDeny", Direction = ParameterDirection.Input, Type = DbType.String)]
        GrantOrDeny,

    }

    public class ArchiveTransformer : BaseTransformer<ArchiveModel>
    {
        internal override ArchiveModel TransformElement(IDataReader dr, Func<IDataReader, ArchiveModel, ArchiveModel> bindExtraFields = null)
        {

            var archiveEntity = new ArchiveModel
            {
                ArchiveNumber = dr[ArchiveField.ArchiveNumber.ToString()].ToString(),
                ArchiveName = dr[ArchiveField.ArchiveName.ToString()].ToString(),
                ArchiveStatus = dr[ArchiveField.ArchiveStatus.ToString()].ToString(),
                ClientName = dr[ArchiveField.ClientName.ToString()].ToString(),
                PeriodEndDate = dr[ArchiveField.PeriodEndDate.ToString()] is DBNull
                                             ? DateTime.MinValue
                                             : TimeZoneHelper.ConvertCentralTimeToUtc(DateTime.Parse(dr[ArchiveField.PeriodEndDate.ToString()].ToString())),
                WBSClosedDate = dr[ArchiveField.WBSClosedDate.ToString()] is DBNull
                                             ? DateTime.MinValue
                                             : TimeZoneHelper.ConvertCentralTimeToUtc(DateTime.Parse(dr[ArchiveField.WBSClosedDate.ToString()].ToString())),
                WBSNumber = dr[ArchiveField.WBSNumber.ToString()].ToString(),
                WBSInfo = BindWBSInformationForArchive(dr)
            };
            archiveEntity.ArchiveInfo = BindArchiveInformationForArchive(archiveEntity, dr);

            return archiveEntity;
        }

        protected internal static Func<IDataReader, ArchiveModel, ArchiveModel> BindForGetArchiveByArchiveId
        {
            get
            {
                return (dr, archive) =>
                {
                    archive.ArchiveNumber = dr[ArchiveField.ArchiveNumber.ToString()].ToString();
                    archive.ArchiveName = dr[ArchiveField.ArchiveName.ToString()].ToString();
                    archive.ArchiveStatus = dr[ArchiveField.ArchiveStatus.ToString()].ToString();
                    archive.ClientName = dr[ArchiveField.ClientName.ToString()].ToString();
                    archive.PeriodEndDate = dr[ArchiveField.PeriodEndDate.ToString()] is DBNull
                                                     ? DateTime.MinValue
                                                     : TimeZoneHelper.ConvertCentralTimeToUtc(DateTime.Parse(dr[ArchiveField.PeriodEndDate.ToString()].ToString()));
                    archive.WBSClosedDate = dr[ArchiveField.WBSClosedDate.ToString()] is DBNull
                                                     ? DateTime.MinValue
                                                     : TimeZoneHelper.ConvertCentralTimeToUtc(DateTime.Parse(dr[ArchiveField.WBSClosedDate.ToString()].ToString()));
                    archive.WBSNumber = dr[ArchiveField.WBSNumber.ToString()].ToString();
                    archive.WBSInfo = BindWBSInformationForArchive(dr);
                    archive.ArchiveInfo = BindArchiveInformationForArchive(archive, dr);
                    return archive;
                };
            }
        }

        private static ProjectMetaDataModel BindWBSInformationForArchive(IDataReader dr)
        {
            //WBSInformation 
            //archive.WBSInfo.WBSNumber = dr[ArchiveField.WBSNumber.ToString()].ToString();
            //archive.WBSInfo.WBSName = dr[ArchiveField.WBSName.ToString()].ToString();
            //archive.WBSInfo.WBSStatus = dr[ArchiveField.WBSStatus.ToString()].ToString();
            //archive.WBSInfo.WBSProjectType = dr[ArchiveField.WBSProjectType.ToString()].ToString();
            //archive.WBSInfo.WBSEngagementPPMD = dr[ArchiveField.WBSEngagementPPMD.ToString()].ToString();
            //archive.WBSInfo.EngagementManager = dr[ArchiveField.EngagementManager.ToString()].ToString();
            //archive.WBSInfo.WBSClientNumber = dr[ArchiveField.WBSClientNumber.ToString()].ToString();
            //archive.WBSInfo.WBSClientName = dr[ArchiveField.WBSClientName.ToString()].ToString();
            //archive.WBSInfo.EngagementController = dr[ArchiveField.EngagementController.ToString()].ToString();
            //archive.WBSInfo.WBSLBP = dr[ArchiveField.WBSLBP.ToString()].ToString();
            //archive.WBSInfo.WBSLCP = dr[ArchiveField.WBSLCP.ToString()].ToString();
            return new ProjectMetaDataModel
            {
                WBSNumber = dr[ArchiveField.WBSNumber.ToString()].ToString(),
                WBSName = dr[ArchiveField.WBSName.ToString()].ToString(),
                WBSStatus = dr[ArchiveField.WBSStatus.ToString()].ToString(),
                WBSProjectType = dr[ArchiveField.WBSProjectType.ToString()].ToString(),
                WBSEngagementPPMD = dr[ArchiveField.WBSEngagementPPMD.ToString()].ToString(),
                EngagementManager = dr[ArchiveField.EngagementManager.ToString()].ToString(),
                WBSClientNumber = dr[ArchiveField.WBSClientNumber.ToString()].ToString(),
                WBSClientName = dr[ArchiveField.WBSClientName.ToString()].ToString(),
                EngagementController = dr[ArchiveField.EngagementController.ToString()].ToString(),
                WBSLBP = dr[ArchiveField.WBSLBP.ToString()].ToString(),
                WBSLCP = dr[ArchiveField.WBSLCP.ToString()].ToString()
            };
        }

        private static ArchiveMetaDataModel BindArchiveInformationForArchive(ArchiveModel archive, IDataReader dr)
        {
            //archive.WBSInfo.WBSNumber = dr[ArchiveField.WBSNumber.ToString()].ToString();
            //archive.WBSInfo.WBSName = dr[ArchiveField.WBSName.ToString()].ToString();
            //archive.WBSInfo.WBSStatus = dr[ArchiveField.WBSStatus.ToString()].ToString();
            //archive.WBSInfo.WBSProjectType = dr[ArchiveField.WBSProjectType.ToString()].ToString();
            //archive.WBSInfo.WBSEngagementPPMD = dr[ArchiveField.WBSEngagementPPMD.ToString()].ToString();
            //archive.WBSInfo.EngagementManager = dr[ArchiveField.EngagementManager.ToString()].ToString();
            //archive.WBSInfo.WBSClientNumber = dr[ArchiveField.WBSClientNumber.ToString()].ToString();
            //archive.WBSInfo.WBSClientName = dr[ArchiveField.WBSClientName.ToString()].ToString();
            //archive.WBSInfo.EngagementController = dr[ArchiveField.EngagementController.ToString()].ToString();
            //archive.WBSInfo.WBSLBP = dr[ArchiveField.WBSLBP.ToString()].ToString();
            //archive.WBSInfo.WBSLCP = dr[ArchiveField.WBSLCP.ToString()].ToString();
            return archive.ArchiveInfo;
        }
    }

    #region Archiveteamhistory
    public enum ArchiveTeamHistoryOutputFields
    {
        Role,
        CreatedDate,
        CreatedBy,
        ChangedFrom,
        ChangedTo,
        RowNumber,
        Count,
    }

    public enum ArchiveTeamHistoryFieldParameter
    {
        [CreateField(Name = "In_ArchiveNumber", Direction = ParameterDirection.Input, Type = DbType.String)]
        ArchiveNumber,
        [CreateField(Name = "In_PageNumber", Direction = ParameterDirection.Input, Type = DbType.Int32)]
        PageNumber,
        [CreateField(Name = "In_PageSize", Direction = ParameterDirection.Input, Type = DbType.Int32)]
        PageSize,
        [CreateField(Name = "In_SortBy", Direction = ParameterDirection.Input, Type = DbType.Int32)]
        SortBy
    }
    public class ArchiveTeamHistoryTransformer : BaseTransformer<ArchiveTeamHistoryModel>
    {
        internal override ArchiveTeamHistoryModel TransformElement(IDataReader dr, Func<IDataReader, ArchiveTeamHistoryModel, ArchiveTeamHistoryModel> bindExtraFields = null)
        {
            return new ArchiveTeamHistoryModel
            {
                Role = (dr[ArchiveTeamHistoryOutputFields.Role.ToString()] is DBNull) ? string.Empty : dr[ArchiveTeamHistoryOutputFields.Role.ToString()].ToString(),
                CreatedDate = (dr[ArchiveTeamHistoryOutputFields.CreatedDate.ToString()] is DBNull) ? string.Empty : dr[ArchiveTeamHistoryOutputFields.CreatedDate.ToString()].ToString(),
                CreatedBy = (dr[ArchiveTeamHistoryOutputFields.CreatedBy.ToString()] is DBNull) ? string.Empty : dr[ArchiveTeamHistoryOutputFields.CreatedBy.ToString()].ToString(),
                ChangedFrom = (dr[ArchiveTeamHistoryOutputFields.ChangedFrom.ToString()] is DBNull) ? string.Empty : dr[ArchiveTeamHistoryOutputFields.ChangedFrom.ToString()].ToString(),
                ChangedTo = (dr[ArchiveTeamHistoryOutputFields.ChangedTo.ToString()] is DBNull) ? string.Empty : dr[ArchiveTeamHistoryOutputFields.ChangedTo.ToString()].ToString(),
                RowNumber = (dr[ArchiveTeamHistoryOutputFields.RowNumber.ToString()] is DBNull) ? 0 : int.Parse(dr[ArchiveTeamHistoryOutputFields.RowNumber.ToString()].ToString()),
                Count = (dr[ArchiveTeamHistoryOutputFields.Count.ToString()] is DBNull) ? 0 : int.Parse(dr[ArchiveTeamHistoryOutputFields.Count.ToString()].ToString()),
            };
        }
    }
    #endregion Archiveteamhistory

    #region MyArchives
    public enum MyArchivesOutputFields
    {
        ArchiveID,
        ArchiveNumber,
        Description,
        PeriodEndDate,
        EngagementDescription,
        ClientName,
        WBSLevelOneName,
        EstimatedIssuanceReportDate,
        WBSLevelOne,
        Business,
        ArchiveType,
        SubmissionStatus,
        RowNumber,
        Count,
        IsPrivacyPeriodExp,
        IsTemporary,
        EntityTypeDescription,
        ProfessionalStandardDescription,
        IsArchiveCompleted
    }

    public enum MyArchiveFieldParameter
    {
        [CreateField(Name = "In_EmployeeUniqueIdentifier", Direction = ParameterDirection.Input, Type = DbType.String)]
        EmployeeUniqueIdentifier,
        [CreateField(Name = "In_PageNumber", Direction = ParameterDirection.Input, Type = DbType.Int32)]
        PageNumber,
        [CreateField(Name = "In_PageSize", Direction = ParameterDirection.Input, Type = DbType.Int32)]
        PageSize,
        [CreateField(Name = "In_SortBy", Direction = ParameterDirection.Input, Type = DbType.Int32)]
        SortBy,
        [CreateField(Name = "In_FilterBy", Direction = ParameterDirection.Input, Type = DbType.Int32)]
        FilterBy,
        [CreateField(Name = "In_FilterText", Direction = ParameterDirection.Input, Type = DbType.String)]
        FilterText
    }
    public class MyArchiveTransformer : BaseTransformer<MyArchiveModel>
    {
        internal override MyArchiveModel TransformElement(IDataReader dr, Func<IDataReader, MyArchiveModel, MyArchiveModel> bindExtraFields = null)
        {
            return new MyArchiveModel
            {
                ArchiveID = (dr[MyArchivesOutputFields.ArchiveID.ToString()] is DBNull) ? 0 : int.Parse(dr[MyArchivesOutputFields.ArchiveID.ToString()].ToString()),
                ArchiveNumber = (dr[MyArchivesOutputFields.ArchiveNumber.ToString()] is DBNull) ? string.Empty : dr[MyArchivesOutputFields.ArchiveNumber.ToString()].ToString(),
                Description = (dr[MyArchivesOutputFields.Description.ToString()] is DBNull) ? string.Empty : dr[MyArchivesOutputFields.Description.ToString()].ToString(),
                PeriodEndDate = (dr[MyArchivesOutputFields.PeriodEndDate.ToString()] is DBNull) ? DateTime.MinValue : Convert.ToDateTime(dr[MyArchivesOutputFields.PeriodEndDate.ToString()].ToString()),
                EngagementDescription = (dr[MyArchivesOutputFields.EngagementDescription.ToString()] is DBNull) ? string.Empty : dr[MyArchivesOutputFields.EngagementDescription.ToString()].ToString(),
                ClientName = (dr[MyArchivesOutputFields.ClientName.ToString()] is DBNull) ? string.Empty : dr[MyArchivesOutputFields.ClientName.ToString()].ToString(),
                WBSLevelOneName = (dr[MyArchivesOutputFields.WBSLevelOneName.ToString()] is DBNull) ? string.Empty : dr[MyArchivesOutputFields.WBSLevelOneName.ToString()].ToString(),
                EstimatedIssuanceReportDate = (dr[MyArchivesOutputFields.EstimatedIssuanceReportDate.ToString()] is DBNull) ? DateTime.MinValue : Convert.ToDateTime(dr[MyArchivesOutputFields.EstimatedIssuanceReportDate.ToString()].ToString()),
                WBSLevelOne = (dr[MyArchivesOutputFields.WBSLevelOne.ToString()] is DBNull) ? string.Empty : dr[MyArchivesOutputFields.WBSLevelOne.ToString()].ToString(),
                Business = (dr[MyArchivesOutputFields.Business.ToString()] is DBNull) ? string.Empty : dr[MyArchivesOutputFields.Business.ToString()].ToString(),
                ArchiveType = (dr[MyArchivesOutputFields.ArchiveType.ToString()] is DBNull) ? string.Empty : dr[MyArchivesOutputFields.ArchiveType.ToString()].ToString(),
                SubmissionStatus = (dr[MyArchivesOutputFields.SubmissionStatus.ToString()] is DBNull) ? string.Empty : dr[MyArchivesOutputFields.SubmissionStatus.ToString()].ToString(),
                RowNumber = (dr[MyArchivesOutputFields.RowNumber.ToString()] is DBNull) ? 0 : int.Parse(dr[MyArchivesOutputFields.RowNumber.ToString()].ToString()),
                Count = (dr[MyArchivesOutputFields.Count.ToString()] is DBNull) ? 0 : int.Parse(dr[MyArchivesOutputFields.Count.ToString()].ToString()),
                IsPrivacyPeriodExp = (dr[MyArchivesOutputFields.IsPrivacyPeriodExp.ToString()] is DBNull) ? false : Convert.ToBoolean(dr[MyArchivesOutputFields.IsPrivacyPeriodExp.ToString()]),
                IsTemporary = (dr[MyArchivesOutputFields.IsTemporary.ToString()] is DBNull) ? false : Convert.ToBoolean(dr[MyArchivesOutputFields.IsTemporary.ToString()]),
                EntityTypeDescription = (dr[MyArchivesOutputFields.EntityTypeDescription.ToString()] is DBNull) ? string.Empty : dr[MyArchivesOutputFields.EntityTypeDescription.ToString()].ToString(),
                ProfessionalStandardDescription = (dr[MyArchivesOutputFields.ProfessionalStandardDescription.ToString()] is DBNull) ? string.Empty : dr[MyArchivesOutputFields.ProfessionalStandardDescription.ToString()].ToString(),
                IsArchiveCompleted = (dr[MyArchivesOutputFields.IsArchiveCompleted.ToString()] is DBNull) ? false : Convert.ToBoolean(dr[MyArchivesOutputFields.IsArchiveCompleted.ToString()]),
            };
        }


    }
    #endregion MyArchives

    #region ArchiveAccessRequestDetails
    public enum ArchiveAccessRequestForApprovalParameter
    {
        [CreateField(Name = "p_loginas", Direction = ParameterDirection.Input, Type = DbType.String)]
        EmployeeUniqueIdentifier,
        [CreateField(Name = "In_PageNumber", Direction = ParameterDirection.Input, Type = DbType.Int32)]
        PageNumber,
        [CreateField(Name = "In_PageSize", Direction = ParameterDirection.Input, Type = DbType.Int32)]
        PageSize
    }

    public enum ArchiveAccessRequestCountForApprovalParameter
    {
        [CreateField(Name = "p_loginas", Direction = ParameterDirection.Input, Type = DbType.String)]
        EmployeeUniqueIdentifier
    }

    public enum Form3283sCountForApprovalParameter
    {
        [CreateField(Name = "p_loginas", Direction = ParameterDirection.Input, Type = DbType.String)]
        EmployeeUniqueIdentifier
    }
    public enum ComplianceScoreForDashboardParameter
    {
        [CreateField(Name = "In_EmployeeUniqueIdentifier", Direction = ParameterDirection.Input, Type = DbType.String)]
        EmployeeUniqueIdentifier
    }

    public class ArchiveAccessRequestForApprovalTransformer : BaseTransformer<ArchiveAccessRequestsForApprovalModel>
    {
        internal override ArchiveAccessRequestsForApprovalModel TransformElement(IDataReader dr, Func<IDataReader, ArchiveAccessRequestsForApprovalModel, ArchiveAccessRequestsForApprovalModel> bindExtraFields = null)
        {
            return new ArchiveAccessRequestsForApprovalModel
            {
                ArchiveNumber = (dr[ArchiveAccessRequestForApprovalOutputFields.ArchiveNumber.ToString()] is DBNull) ? string.Empty : dr[ArchiveAccessRequestForApprovalOutputFields.ArchiveNumber.ToString()].ToString(),
                EngagementDescription = (dr[ArchiveAccessRequestForApprovalOutputFields.EngagementDescription.ToString()] is DBNull) ? string.Empty : dr[ArchiveAccessRequestForApprovalOutputFields.EngagementDescription.ToString()].ToString(),
                PeriodEndDate = (dr[ArchiveAccessRequestForApprovalOutputFields.PeriodEndDate.ToString()] is DBNull) ? DateTime.MinValue : Convert.ToDateTime(dr[ArchiveAccessRequestForApprovalOutputFields.PeriodEndDate.ToString()].ToString()),
                ClientName = (dr[ArchiveAccessRequestForApprovalOutputFields.ClientName.ToString()] is DBNull) ? string.Empty : dr[ArchiveAccessRequestForApprovalOutputFields.ClientName.ToString()].ToString(),
                LastName = (dr[ArchiveAccessRequestForApprovalOutputFields.LastName.ToString()] is DBNull) ? string.Empty : dr[ArchiveAccessRequestForApprovalOutputFields.LastName.ToString()].ToString(),
                EstimatedIssuanceReportDate = (dr[ArchiveAccessRequestForApprovalOutputFields.EstimatedIssuanceReportDate.ToString()] is DBNull) ? DateTime.MinValue : Convert.ToDateTime(dr[ArchiveAccessRequestForApprovalOutputFields.EstimatedIssuanceReportDate.ToString()].ToString()),
                WBSLevelOneNumber = (dr[ArchiveAccessRequestForApprovalOutputFields.WBSLevelOneNumber.ToString()] is DBNull) ? string.Empty : dr[ArchiveAccessRequestForApprovalOutputFields.WBSLevelOneNumber.ToString()].ToString(),
                FirstName = (dr[ArchiveAccessRequestForApprovalOutputFields.FirstName.ToString()] is DBNull) ? string.Empty : dr[ArchiveAccessRequestForApprovalOutputFields.FirstName.ToString()].ToString(),
                RowNumber = (dr[ArchiveAccessRequestForApprovalOutputFields.RowNumber.ToString()] is DBNull) ? 0 : int.Parse(dr[ArchiveAccessRequestForApprovalOutputFields.RowNumber.ToString()].ToString()),
                Count = (dr[ArchiveAccessRequestForApprovalOutputFields.Count.ToString()] is DBNull) ? 0 : int.Parse(dr[ArchiveAccessRequestForApprovalOutputFields.Count.ToString()].ToString()),
                CountRed = (dr[ArchiveAccessRequestForApprovalOutputFields.CountRed.ToString()] is DBNull) ? 0 : int.Parse(dr[ArchiveAccessRequestForApprovalOutputFields.CountRed.ToString()].ToString()),
                CountYellow = (dr[ArchiveAccessRequestForApprovalOutputFields.CountYellow.ToString()] is DBNull) ? 0 : int.Parse(dr[ArchiveAccessRequestForApprovalOutputFields.CountYellow.ToString()].ToString()),
                CountOrange = (dr[ArchiveAccessRequestForApprovalOutputFields.CountOrange.ToString()] is DBNull) ? 0 : int.Parse(dr[ArchiveAccessRequestForApprovalOutputFields.CountOrange.ToString()].ToString()),
                EntityTypeDescription = (dr[ArchiveAccessRequestForApprovalOutputFields.EntityTypeDescription.ToString()] is DBNull) ? string.Empty : dr[ArchiveAccessRequestForApprovalOutputFields.EntityTypeDescription.ToString()].ToString(),
                ProfessionalStandardDescription = (dr[ArchiveAccessRequestForApprovalOutputFields.ProfessionalStandardDescription.ToString()] is DBNull) ? string.Empty : dr[ArchiveAccessRequestForApprovalOutputFields.ProfessionalStandardDescription.ToString()].ToString(),
                ArchiveAccessRequestID = (dr[ArchiveAccessRequestForApprovalOutputFields.ArchiveAccessRequestID.ToString()] is DBNull) ? string.Empty : dr[ArchiveAccessRequestForApprovalOutputFields.ArchiveAccessRequestID.ToString()].ToString(),
                Due = (dr[ArchiveAccessRequestForApprovalOutputFields.Due.ToString()] is DBNull) ? string.Empty : dr[ArchiveAccessRequestForApprovalOutputFields.Due.ToString()].ToString(),
                ArchiveStatus = (dr[ArchiveAccessRequestForApprovalOutputFields.ArchiveStatus.ToString()] is DBNull) ? string.Empty : dr[ArchiveAccessRequestForApprovalOutputFields.ArchiveStatus.ToString()].ToString()

            };
        }

    }

    public enum ArchiveAccessRequestForApprovalOutputFields
    {
        ArchiveNumber,
        ClientName,
        EngagementDescription,
        PeriodEndDate,
        WBSLevelOneNumber,
        EstimatedIssuanceReportDate,
        LastName,
        FirstName,
        RowNumber,
        Count,
        EntityTypeDescription,
        ProfessionalStandardDescription,
        ArchiveAccessRequestID,
        Due,
        ArchiveStatus,
        CountRed,
        CountYellow,
        CountOrange
    }

    public class ArchiveAccessRequestDetailsTransformer : BaseTransformer<ArchiveAccessRequestDetailsModel>
    {
        internal override ArchiveAccessRequestDetailsModel TransformElement(IDataReader dr, Func<IDataReader, ArchiveAccessRequestDetailsModel, ArchiveAccessRequestDetailsModel> bindExtraFields = null)
        {
            return new ArchiveAccessRequestDetailsModel
            {
                Description = (dr[ArchiveAccessRequestDetailsModelOutputFields.Description.ToString()] is DBNull) ? string.Empty : dr[ArchiveAccessRequestDetailsModelOutputFields.Description.ToString()].ToString(),
                EngagementDescription = (dr[ArchiveAccessRequestDetailsModelOutputFields.EngagementDescription.ToString()] is DBNull) ? string.Empty : dr[ArchiveAccessRequestDetailsModelOutputFields.EngagementDescription.ToString()].ToString(),
                EngagementTypeDescription = (dr[ArchiveAccessRequestDetailsModelOutputFields.EngagementTypeDescription.ToString()] is DBNull) ? string.Empty : dr[ArchiveAccessRequestDetailsModelOutputFields.EngagementTypeDescription.ToString()].ToString(),
                ReportingEntity = (dr[ArchiveAccessRequestDetailsModelOutputFields.ReportingEntity.ToString()] is DBNull) ? string.Empty : dr[ArchiveAccessRequestDetailsModelOutputFields.ReportingEntity.ToString()].ToString(),
                RequestorName = (dr[ArchiveAccessRequestDetailsModelOutputFields.RequestorName.ToString()] is DBNull) ? string.Empty : dr[ArchiveAccessRequestDetailsModelOutputFields.RequestorName.ToString()].ToString(),
                IsResubmissionInProgress = (dr[ArchiveAccessRequestDetailsModelOutputFields.IsResubmissionInProgress.ToString()] is DBNull) ? "No" : (Convert.ToBoolean(dr[ArchiveAccessRequestDetailsModelOutputFields.IsResubmissionInProgress.ToString()]) ? "Yes" : "No"),
                PeriodEndDate = (dr[ArchiveAccessRequestForApprovalOutputFields.PeriodEndDate.ToString()] is DBNull) ? string.Empty : String.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(dr[ArchiveAccessRequestForApprovalOutputFields.PeriodEndDate.ToString()].ToString())),
                ArchiveNumber = (dr[ArchiveAccessRequestDetailsModelOutputFields.ArchiveNumber.ToString()] is DBNull) ? string.Empty : dr[ArchiveAccessRequestDetailsModelOutputFields.ArchiveNumber.ToString()].ToString(),
                ArchivePartner = (dr[ArchiveAccessRequestDetailsModelOutputFields.ArchivePartner.ToString()] is DBNull) ? string.Empty : dr[ArchiveAccessRequestDetailsModelOutputFields.ArchivePartner.ToString()].ToString(),
                AddArchiveFieldSenior = (dr[ArchiveAccessRequestDetailsModelOutputFields.AddArchiveFieldSenior.ToString()] is DBNull) ? string.Empty : dr[ArchiveAccessRequestDetailsModelOutputFields.AddArchiveFieldSenior.ToString()].ToString(),
                ArchiveDueDate = (dr[ArchiveAccessRequestDetailsModelOutputFields.ArchiveDueDate.ToString()] is DBNull) ? string.Empty : String.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(dr[ArchiveAccessRequestDetailsModelOutputFields.ArchiveDueDate.ToString()].ToString())),
                ClientName = (dr[ArchiveAccessRequestDetailsModelOutputFields.ClientName.ToString()] is DBNull) ? string.Empty : dr[ArchiveAccessRequestDetailsModelOutputFields.ClientName.ToString()].ToString(),
                ArchiveFieldSenior = (dr[ArchiveAccessRequestDetailsModelOutputFields.ArchiveFieldSenior.ToString()] is DBNull) ? string.Empty : dr[ArchiveAccessRequestDetailsModelOutputFields.ArchiveFieldSenior.ToString()].ToString(),
                EstimatedIssuanceReportDate = (dr[ArchiveAccessRequestForApprovalOutputFields.EstimatedIssuanceReportDate.ToString()] is DBNull) ? string.Empty : String.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(dr[ArchiveAccessRequestForApprovalOutputFields.EstimatedIssuanceReportDate.ToString()].ToString())),
                WBSLevelOneNumber = (dr[ArchiveAccessRequestDetailsModelOutputFields.WBSLevelOneNumber.ToString()] is DBNull) ? string.Empty : dr[ArchiveAccessRequestDetailsModelOutputFields.WBSLevelOneNumber.ToString()].ToString(),
                ArchiveManager = (dr[ArchiveAccessRequestDetailsModelOutputFields.ArchiveManager.ToString()] is DBNull) ? string.Empty : dr[ArchiveAccessRequestDetailsModelOutputFields.ArchiveManager.ToString()].ToString(),
                RowNumber = (dr[ArchiveAccessRequestDetailsModelOutputFields.RowNumber.ToString()] is DBNull) ? 0 : int.Parse(dr[ArchiveAccessRequestDetailsModelOutputFields.RowNumber.ToString()].ToString()),
                Count = (dr[ArchiveAccessRequestDetailsModelOutputFields.Count.ToString()] is DBNull) ? 0 : int.Parse(dr[ArchiveAccessRequestDetailsModelOutputFields.Count.ToString()].ToString()),
                EntityTypeDescription = (dr[ArchiveAccessRequestForApprovalOutputFields.EntityTypeDescription.ToString()] is DBNull) ? string.Empty : dr[ArchiveAccessRequestForApprovalOutputFields.EntityTypeDescription.ToString()].ToString(),
                ProfessionalStandardDescription = (dr[ArchiveAccessRequestForApprovalOutputFields.ProfessionalStandardDescription.ToString()] is DBNull) ? string.Empty : dr[ArchiveAccessRequestForApprovalOutputFields.ProfessionalStandardDescription.ToString()].ToString(),
                Due = (dr[ArchiveAccessRequestForApprovalOutputFields.Due.ToString()] is DBNull) ? string.Empty : dr[ArchiveAccessRequestForApprovalOutputFields.Due.ToString()].ToString(),
                ArchiveStatus = (dr[ArchiveAccessRequestForApprovalOutputFields.ArchiveStatus.ToString()] is DBNull) ? string.Empty : dr[ArchiveAccessRequestForApprovalOutputFields.ArchiveStatus.ToString()].ToString()

            };
        }


    }

    public enum ArchiveAccessRequestDetailsModelOutputFields
    {
        ArchiveNumber,
        ClientName,
        EngagementDescription,
        PeriodEndDate,
        WBSLevelOneNumber,
        EstimatedIssuanceReportDate,
        RequestorName,
        EngagementTypeDescription,
        ArchiveDueDate,
        IsResubmissionInProgress,
        Description,
        ProfessionalStandardDescription,
        ReportingEntity,
        ArchivePartner,
        ArchiveManager,
        ArchiveFieldSenior,
        AddArchiveFieldSenior,
        RowNumber,
        Count
    }

    public class ArchiveAccessRequestCountForApprovalTransformer : BaseTransformer<ArchiveAccessRequestCountForApprovalModel>
    {
        internal override ArchiveAccessRequestCountForApprovalModel TransformElement(IDataReader dr, Func<IDataReader, ArchiveAccessRequestCountForApprovalModel, ArchiveAccessRequestCountForApprovalModel> bindExtraFields = null)
        {
            return new ArchiveAccessRequestCountForApprovalModel
            {
                ActionItemCount = (dr[ArchiveAccessRequestCountForApprovalOutputFields.ActionItemCount.ToString()] is DBNull) ? 0 : int.Parse(dr[ArchiveAccessRequestCountForApprovalOutputFields.ActionItemCount.ToString()].ToString()),
                Due = (dr[ArchiveAccessRequestCountForApprovalOutputFields.Due.ToString()] is DBNull) ? string.Empty : dr[ArchiveAccessRequestCountForApprovalOutputFields.Due.ToString()].ToString()

            };
        }


    }
    public class ComplianceScoreTransformer : BaseTransformer<ComplianceScoreForDashboardModel>
    {
        internal override ComplianceScoreForDashboardModel TransformElement(IDataReader dr, Func<IDataReader, ComplianceScoreForDashboardModel, ComplianceScoreForDashboardModel> bindExtraFields = null)
        {
            return new ComplianceScoreForDashboardModel
            {
                ComplianceMetricsScore = (dr[ComplianceScoreOutputFields.ComplianceMetricsScore.ToString()] is DBNull) ? 0 : Int32.Parse(dr[ComplianceScoreOutputFields.ComplianceMetricsScore.ToString()].ToString()),

            };
        }


    }
    

    public enum ArchiveAccessRequestCountForApprovalOutputFields
    {
        ActionItemCount,
        Due
    }
    public enum ComplianceScoreOutputFields
    {
        ComplianceMetricsScore
    }


    public class MyForm3283DetailsTransformer : BaseTransformer<MyForm3283DataModel>
    {
        internal override MyForm3283DataModel TransformElement(IDataReader dr, Func<IDataReader, MyForm3283DataModel, MyForm3283DataModel> bindExtraFields = null)
        {
            return new MyForm3283DataModel
            {
                ArchiveNumber = (dr[MyForm3283DataModelOutputFields.ArchiveNumber.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.ArchiveNumber.ToString()].ToString(),
                EngagementDescription = (dr[MyForm3283DataModelOutputFields.EngagementDescription.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.EngagementDescription.ToString()].ToString(),
                PeriodEndDate = (dr[MyForm3283DataModelOutputFields.PeriodEndDate.ToString()] is DBNull) ? string.Empty : String.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(dr[MyForm3283DataModelOutputFields.PeriodEndDate.ToString()].ToString())),
                ClientName = (dr[MyForm3283DataModelOutputFields.ClientName.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.ClientName.ToString()].ToString(),
                ProposedADCED = (dr[MyForm3283DataModelOutputFields.ProposedADCED.ToString()] is DBNull) ? string.Empty : String.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(dr[MyForm3283DataModelOutputFields.PeriodEndDate.ToString()].ToString())),
                EstimatedIssuanceReportDate = (dr[MyForm3283DataModelOutputFields.EstimatedIssuanceReportDate.ToString()] is DBNull) ? string.Empty : String.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(dr[MyForm3283DataModelOutputFields.EstimatedIssuanceReportDate.ToString()].ToString())),
                WBSLevelOneNumber = (dr[MyForm3283DataModelOutputFields.WBSLevelOneNumber.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.WBSLevelOneNumber.ToString()].ToString(),
                RowNumber = (dr[MyForm3283DataModelOutputFields.RowNumber.ToString()] is DBNull) ? 0 : int.Parse(dr[MyForm3283DataModelOutputFields.RowNumber.ToString()].ToString()),
                Count = (dr[MyForm3283DataModelOutputFields.Count.ToString()] is DBNull) ? 0 : int.Parse(dr[MyForm3283DataModelOutputFields.Count.ToString()].ToString()),
                CountOrange = (dr[MyForm3283DataModelOutputFields.CountOrange.ToString()] is DBNull) ? 0 : int.Parse(dr[MyForm3283DataModelOutputFields.CountOrange.ToString()].ToString()),
                CountRed = (dr[MyForm3283DataModelOutputFields.CountRed.ToString()] is DBNull) ? 0 : int.Parse(dr[MyForm3283DataModelOutputFields.CountRed.ToString()].ToString()),
                CountYellow = (dr[MyForm3283DataModelOutputFields.CountYellow.ToString()] is DBNull) ? 0 : int.Parse(dr[MyForm3283DataModelOutputFields.CountYellow.ToString()].ToString()),
                EntityTypeDescription = (dr[MyForm3283DataModelOutputFields.EntityTypeDescription.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.EntityTypeDescription.ToString()].ToString(),
                ProfessionalStandardDescription = (dr[MyForm3283DataModelOutputFields.ProfessionalStandardDescription.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.ProfessionalStandardDescription.ToString()].ToString(),
                EngagementTypeDescription = (dr[MyForm3283DataModelOutputFields.EngagementTypeDescription.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.EngagementTypeDescription.ToString()].ToString(),
                Due = (dr[MyForm3283DataModelOutputFields.Due.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.Due.ToString()].ToString(),
                ReportingEntity = (dr[MyForm3283DataModelOutputFields.ReportingEntity.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.ReportingEntity.ToString()].ToString(),
                ArchiveDueDate = (dr[MyForm3283DataModelOutputFields.ArchiveDueDate.ToString()] is DBNull) ? string.Empty : String.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(dr[MyForm3283DataModelOutputFields.ArchiveDueDate.ToString()].ToString())),
                ArchiveStatus= (dr[MyForm3283DataModelOutputFields.ArchiveStatus.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.ArchiveStatus.ToString()].ToString(),
                //IsResubmissionInProgress = (dr[MyForm3283DataModelOutputFields.IsResubmissionInProgress.ToString()] is DBNull) ? "No" : (Convert.ToBoolean(dr[MyForm3283DataModelOutputFields.IsResubmissionInProgress.ToString()]) ? "Yes" : "No"),
                //Description = (dr[MyForm3283DataModelOutputFields.Description.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.Description.ToString()].ToString(),
                //ArchivePartner = (dr[MyForm3283DataModelOutputFields.ArchivePartner.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.ArchivePartner.ToString()].ToString(),
                //ArchiveManager = (dr[MyForm3283DataModelOutputFields.ArchiveManager.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.ArchiveManager.ToString()].ToString(),
                //ArchiveFieldSenior = (dr[MyForm3283DataModelOutputFields.ArchiveFieldSenior.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.ArchiveFieldSenior.ToString()].ToString(),
                //AddArchiveFieldSenior = (dr[MyForm3283DataModelOutputFields.AddArchiveFieldSenior.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.AddArchiveFieldSenior.ToString()].ToString(),


            };
        }


    }

    public class ComplianceMetricsTransformer : BaseTransformer<ComplianceMetricsModel>
    {
        internal override ComplianceMetricsModel TransformElement(IDataReader dr, Func<IDataReader, ComplianceMetricsModel, ComplianceMetricsModel> bindExtraFields = null)
        {
            return new ComplianceMetricsModel
            {
                ArchiveNumber = (dr[ComplianceMetricsOutputFields.ArchiveNumber.ToString()] is DBNull) ? string.Empty : dr[ComplianceMetricsOutputFields.ArchiveNumber.ToString()].ToString(),
                ClientName = (dr[ComplianceMetricsOutputFields.ClientName.ToString()] is DBNull) ? string.Empty : dr[ComplianceMetricsOutputFields.ClientName.ToString()].ToString(),
                EngagementDescription = (dr[ComplianceMetricsOutputFields.EngagementDescription.ToString()] is DBNull) ? string.Empty : dr[ComplianceMetricsOutputFields.EngagementDescription.ToString()].ToString(),
                PeriodEndDate = (dr[ComplianceMetricsOutputFields.PeriodEndDate.ToString()] is DBNull) ? string.Empty : String.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(dr[ComplianceMetricsOutputFields.PeriodEndDate.ToString()].ToString())),
                DueDate = (dr[ComplianceMetricsOutputFields.DueDate.ToString()] is DBNull) ? string.Empty : String.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(dr[ComplianceMetricsOutputFields.DueDate.ToString()].ToString())),
                InitialApproval = (dr[ComplianceMetricsOutputFields.InitialApproval.ToString()] is DBNull) ? string.Empty : String.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(dr[ComplianceMetricsOutputFields.InitialApproval.ToString()].ToString())),
                WBSLevelOneNumber = (dr[ComplianceMetricsOutputFields.WBSLevelOne.ToString()] is DBNull) ? string.Empty : dr[ComplianceMetricsOutputFields.WBSLevelOne.ToString()].ToString(),
                ComplianceStatus= (dr[ComplianceMetricsOutputFields.ComplianceStatus.ToString()] is DBNull) ? string.Empty : dr[ComplianceMetricsOutputFields.ComplianceStatus.ToString()].ToString(),
                EngagementTypeDescription = (dr[ComplianceMetricsOutputFields.EngagementTypeDescription.ToString()] is DBNull) ? string.Empty : dr[ComplianceMetricsOutputFields.EngagementTypeDescription.ToString()].ToString(),
                EstimatedIssuanceReportDate = (dr[ComplianceMetricsOutputFields.EstimatedIssuanceReportDate.ToString()] is DBNull) ? string.Empty : String.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(dr[ComplianceMetricsOutputFields.EstimatedIssuanceReportDate.ToString()].ToString())),
                ArchiveDueDate = (dr[ComplianceMetricsOutputFields.ArchiveDueDate.ToString()] is DBNull) ? string.Empty : String.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(dr[ComplianceMetricsOutputFields.ArchiveDueDate.ToString()].ToString())),
                ADCED = (dr[ComplianceMetricsOutputFields.ADCED.ToString()] is DBNull) ? string.Empty : String.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(dr[ComplianceMetricsOutputFields.ADCED.ToString()].ToString())),
                IsResubmissionInProgress = (dr[ComplianceMetricsOutputFields.IsResubmissionInProgress.ToString()] is DBNull) ? "No" : (Convert.ToBoolean(dr[ComplianceMetricsOutputFields.IsResubmissionInProgress.ToString()]) ? "Yes" : "No"),
                Description = (dr[ComplianceMetricsOutputFields.Description.ToString()] is DBNull) ? string.Empty : dr[ComplianceMetricsOutputFields.Description.ToString()].ToString(),
                EntityTypeDescription = (dr[ComplianceMetricsOutputFields.EntityTypeDescription.ToString()] is DBNull) ? string.Empty : dr[ComplianceMetricsOutputFields.EntityTypeDescription.ToString()].ToString(),
                ProfessionalStandardDescription = (dr[ComplianceMetricsOutputFields.ProfessionalStandardDescription.ToString()] is DBNull) ? string.Empty : dr[ComplianceMetricsOutputFields.ProfessionalStandardDescription.ToString()].ToString(),
                ReportingEntity = (dr[ComplianceMetricsOutputFields.ReportingEntity.ToString()] is DBNull) ? string.Empty : dr[ComplianceMetricsOutputFields.ReportingEntity.ToString()].ToString(),
                ArchivePartner = (dr[ComplianceMetricsOutputFields.ArchivePartner.ToString()] is DBNull) ? string.Empty : dr[ComplianceMetricsOutputFields.ArchivePartner.ToString()].ToString(),
                ArchiveManager = (dr[ComplianceMetricsOutputFields.ArchiveManager.ToString()] is DBNull) ? string.Empty : dr[ComplianceMetricsOutputFields.ArchiveManager.ToString()].ToString(),
                ArchiveFieldSenior = (dr[ComplianceMetricsOutputFields.ArchiveFieldSenior.ToString()] is DBNull) ? string.Empty : dr[ComplianceMetricsOutputFields.ArchiveFieldSenior.ToString()].ToString(),
                AddArchiveFieldSenior = (dr[ComplianceMetricsOutputFields.AddArchiveFieldSenior.ToString()] is DBNull) ? string.Empty : dr[ComplianceMetricsOutputFields.AddArchiveFieldSenior.ToString()].ToString(),
                RowNumber = (dr[ComplianceMetricsOutputFields.RowNumber.ToString()] is DBNull) ? 0 : int.Parse(dr[ComplianceMetricsOutputFields.RowNumber.ToString()].ToString()),
                Count = (dr[ComplianceMetricsOutputFields.Count.ToString()] is DBNull) ? 0 : int.Parse(dr[ComplianceMetricsOutputFields.Count.ToString()].ToString()),
                OnTimeCount = (dr[ComplianceMetricsOutputFields.OnTimeCount.ToString()] is DBNull) ? 0 : int.Parse(dr[ComplianceMetricsOutputFields.OnTimeCount.ToString()].ToString()),
                LateWithApprovalCount= (dr[ComplianceMetricsOutputFields.LateWithApprovalCount.ToString()] is DBNull) ? 0 : int.Parse(dr[ComplianceMetricsOutputFields.LateWithApprovalCount.ToString()].ToString()),
                LateCount= (dr[ComplianceMetricsOutputFields.LateCount.ToString()] is DBNull) ? 0 : int.Parse(dr[ComplianceMetricsOutputFields.LateCount.ToString()].ToString()),
                LatePast45DaysCount= (dr[ComplianceMetricsOutputFields.LatePast45DaysCount.ToString()] is DBNull) ? 0 : int.Parse(dr[ComplianceMetricsOutputFields.LatePast45DaysCount.ToString()].ToString()),
                CountBeforeFiltering= (dr[ComplianceMetricsOutputFields.CountBeforeFiltering.ToString()] is DBNull) ? 0 : int.Parse(dr[ComplianceMetricsOutputFields.CountBeforeFiltering.ToString()].ToString()),
            };
        }
    }
    public class MyPendingSubmissionDetailsTransformer : BaseTransformer<MyPendingSubmissionDataModel>
    {
        internal override MyPendingSubmissionDataModel TransformElement(IDataReader dr, Func<IDataReader, MyPendingSubmissionDataModel, MyPendingSubmissionDataModel> bindExtraFields = null)
        {
            return new MyPendingSubmissionDataModel
            {
                ArchiveNumber = (dr[MyForm3283DataModelOutputFields.ArchiveNumber.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.ArchiveNumber.ToString()].ToString(),
                EngagementDescription = (dr[MyForm3283DataModelOutputFields.EngagementDescription.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.EngagementDescription.ToString()].ToString(),
                PeriodEndDate = (dr[MyForm3283DataModelOutputFields.PeriodEndDate.ToString()] is DBNull) ? string.Empty : String.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(dr[MyForm3283DataModelOutputFields.PeriodEndDate.ToString()].ToString())),
                ClientName = (dr[MyForm3283DataModelOutputFields.ClientName.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.ClientName.ToString()].ToString(),
                //ProposedADCED = (dr[MyForm3283DataModelOutputFields.ProposedADCED.ToString()] is DBNull) ? string.Empty : String.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(dr[MyForm3283DataModelOutputFields.PeriodEndDate.ToString()].ToString())),
                EstimatedIssuanceReportDate = (dr[MyForm3283DataModelOutputFields.EstimatedIssuanceReportDate.ToString()] is DBNull) ? string.Empty : String.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(dr[MyForm3283DataModelOutputFields.EstimatedIssuanceReportDate.ToString()].ToString())),
                WBSLevelOneNumber = (dr[MyForm3283DataModelOutputFields.WBSLevelOneNumber.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.WBSLevelOneNumber.ToString()].ToString(),
                RowNumber = (dr[MyForm3283DataModelOutputFields.RowNumber.ToString()] is DBNull) ? 0 : int.Parse(dr[MyForm3283DataModelOutputFields.RowNumber.ToString()].ToString()),
                Count = (dr[MyForm3283DataModelOutputFields.Count.ToString()] is DBNull) ? 0 : int.Parse(dr[MyForm3283DataModelOutputFields.Count.ToString()].ToString()),
                CountOrange = (dr[MyForm3283DataModelOutputFields.CountOrange.ToString()] is DBNull) ? 0 : int.Parse(dr[MyForm3283DataModelOutputFields.CountOrange.ToString()].ToString()),
                CountRed = (dr[MyForm3283DataModelOutputFields.CountRed.ToString()] is DBNull) ? 0 : int.Parse(dr[MyForm3283DataModelOutputFields.CountRed.ToString()].ToString()),
                CountYellow = (dr[MyForm3283DataModelOutputFields.CountYellow.ToString()] is DBNull) ? 0 : int.Parse(dr[MyForm3283DataModelOutputFields.CountYellow.ToString()].ToString()),

                EntityTypeDescription = (dr[MyForm3283DataModelOutputFields.EntityTypeDescription.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.EntityTypeDescription.ToString()].ToString(),
                ProfessionalStandardDescription = (dr[MyForm3283DataModelOutputFields.ProfessionalStandardDescription.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.ProfessionalStandardDescription.ToString()].ToString(),
                EngagementTypeDescription = (dr[MyForm3283DataModelOutputFields.EngagementTypeDescription.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.EngagementTypeDescription.ToString()].ToString(),
                Due = (dr[MyForm3283DataModelOutputFields.Due.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.Due.ToString()].ToString(),
                ReportingEntity = (dr[MyForm3283DataModelOutputFields.ReportingEntity.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.ReportingEntity.ToString()].ToString(),
                ArchiveDueDate = (dr[MyForm3283DataModelOutputFields.ArchiveDueDate.ToString()] is DBNull) ? string.Empty : String.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(dr[MyForm3283DataModelOutputFields.ArchiveDueDate.ToString()].ToString())),
                ArchiveStatus = (dr[MyForm3283DataModelOutputFields.ArchiveStatus.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.ArchiveStatus.ToString()].ToString(),
                IsArchiveCompleted = (dr[MyForm3283DataModelOutputFields.IsArchiveCompleted.ToString()] is DBNull) ? 0 : int.Parse(dr[MyForm3283DataModelOutputFields.IsArchiveCompleted.ToString()].ToString())
                //IsResubmissionInProgress = (dr[MyForm3283DataModelOutputFields.IsResubmissionInProgress.ToString()] is DBNull) ? "No" : (Convert.ToBoolean(dr[MyForm3283DataModelOutputFields.IsResubmissionInProgress.ToString()]) ? "Yes" : "No"),
                //Description = (dr[MyForm3283DataModelOutputFields.Description.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.Description.ToString()].ToString(),
                //ArchivePartner = (dr[MyForm3283DataModelOutputFields.ArchivePartner.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.ArchivePartner.ToString()].ToString(),
                //ArchiveManager = (dr[MyForm3283DataModelOutputFields.ArchiveManager.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.ArchiveManager.ToString()].ToString(),
                //ArchiveFieldSenior = (dr[MyForm3283DataModelOutputFields.ArchiveFieldSenior.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.ArchiveFieldSenior.ToString()].ToString(),
                //AddArchiveFieldSenior = (dr[MyForm3283DataModelOutputFields.AddArchiveFieldSenior.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.AddArchiveFieldSenior.ToString()].ToString(),


            };
        }


    }

    public class MyComplianceDetailsTransformer : BaseTransformer<MyComplianceDataModel>
    {
        internal override MyComplianceDataModel TransformElement(IDataReader dr, Func<IDataReader, MyComplianceDataModel, MyComplianceDataModel> bindExtraFields = null)
        {
            return new MyComplianceDataModel
            {
                ArchiveNumber = (dr[MyForm3283DataModelOutputFields.ArchiveNumber.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.ArchiveNumber.ToString()].ToString(),
                EngagementDescription = (dr[MyForm3283DataModelOutputFields.EngagementDescription.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.EngagementDescription.ToString()].ToString(),
                PeriodEndDate = (dr[MyForm3283DataModelOutputFields.PeriodEndDate.ToString()] is DBNull) ? string.Empty : String.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(dr[MyForm3283DataModelOutputFields.PeriodEndDate.ToString()].ToString())),
                ClientName = (dr[MyForm3283DataModelOutputFields.ClientName.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.ClientName.ToString()].ToString(),
                //ProposedADCED = (dr[MyForm3283DataModelOutputFields.ProposedADCED.ToString()] is DBNull) ? string.Empty : String.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(dr[MyForm3283DataModelOutputFields.PeriodEndDate.ToString()].ToString())),
                EstimatedIssuanceReportDate = (dr[MyForm3283DataModelOutputFields.EstimatedIssuanceReportDate.ToString()] is DBNull) ? string.Empty : String.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(dr[MyForm3283DataModelOutputFields.EstimatedIssuanceReportDate.ToString()].ToString())),
                WBSLevelOneNumber = (dr[MyForm3283DataModelOutputFields.WBSLevelOneNumber.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.WBSLevelOneNumber.ToString()].ToString(),
                RowNumber = (dr[MyForm3283DataModelOutputFields.RowNumber.ToString()] is DBNull) ? 0 : int.Parse(dr[MyForm3283DataModelOutputFields.RowNumber.ToString()].ToString()),
                Count = (dr[MyForm3283DataModelOutputFields.Count.ToString()] is DBNull) ? 0 : int.Parse(dr[MyForm3283DataModelOutputFields.Count.ToString()].ToString()),
                CountOrange = (dr[MyForm3283DataModelOutputFields.CountOrange.ToString()] is DBNull) ? 0 : int.Parse(dr[MyForm3283DataModelOutputFields.CountOrange.ToString()].ToString()),
                CountRed = (dr[MyForm3283DataModelOutputFields.CountRed.ToString()] is DBNull) ? 0 : int.Parse(dr[MyForm3283DataModelOutputFields.CountRed.ToString()].ToString()),
                CountYellow = (dr[MyForm3283DataModelOutputFields.CountYellow.ToString()] is DBNull) ? 0 : int.Parse(dr[MyForm3283DataModelOutputFields.CountYellow.ToString()].ToString()),
                EntityTypeDescription = (dr[MyForm3283DataModelOutputFields.EntityTypeDescription.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.EntityTypeDescription.ToString()].ToString(),
                ProfessionalStandardDescription = (dr[MyForm3283DataModelOutputFields.ProfessionalStandardDescription.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.ProfessionalStandardDescription.ToString()].ToString(),
                EngagementTypeDescription = (dr[MyForm3283DataModelOutputFields.EngagementTypeDescription.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.EngagementTypeDescription.ToString()].ToString(),
                Due = (dr[MyForm3283DataModelOutputFields.Due.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.Due.ToString()].ToString(),
                ReportingEntity = (dr[MyForm3283DataModelOutputFields.ReportingEntity.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.ReportingEntity.ToString()].ToString(),
                ArchiveDueDate = (dr[MyForm3283DataModelOutputFields.ArchiveDueDate.ToString()] is DBNull) ? string.Empty : String.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(dr[MyForm3283DataModelOutputFields.ArchiveDueDate.ToString()].ToString())),
                ArchiveStatus = (dr[MyForm3283DataModelOutputFields.ArchiveStatus.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.ArchiveStatus.ToString()].ToString(),
                //IsResubmissionInProgress = (dr[MyForm3283DataModelOutputFields.IsResubmissionInProgress.ToString()] is DBNull) ? "No" : (Convert.ToBoolean(dr[MyForm3283DataModelOutputFields.IsResubmissionInProgress.ToString()]) ? "Yes" : "No"),
                //Description = (dr[MyForm3283DataModelOutputFields.Description.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.Description.ToString()].ToString(),
                //ArchivePartner = (dr[MyForm3283DataModelOutputFields.ArchivePartner.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.ArchivePartner.ToString()].ToString(),
                //ArchiveManager = (dr[MyForm3283DataModelOutputFields.ArchiveManager.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.ArchiveManager.ToString()].ToString(),
                //ArchiveFieldSenior = (dr[MyForm3283DataModelOutputFields.ArchiveFieldSenior.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.ArchiveFieldSenior.ToString()].ToString(),
                //AddArchiveFieldSenior = (dr[MyForm3283DataModelOutputFields.AddArchiveFieldSenior.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.AddArchiveFieldSenior.ToString()].ToString(),


            };
        }


    }

    public class MyPendingSubmissionExportToExcelTransformer : BaseTransformer<MyPendingSubmissionDataModel>
    {
        internal override MyPendingSubmissionDataModel TransformElement(IDataReader dr, Func<IDataReader, MyPendingSubmissionDataModel, MyPendingSubmissionDataModel> bindExtraFields = null)
        {
            return new MyPendingSubmissionDataModel
            {
                ArchiveNumber = (dr[MyForm3283DataModelOutputFields.ArchiveNumber.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.ArchiveNumber.ToString()].ToString(),
                EngagementDescription = (dr[MyForm3283DataModelOutputFields.EngagementDescription.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.EngagementDescription.ToString()].ToString(),
                PeriodEndDate = (dr[MyForm3283DataModelOutputFields.PeriodEndDate.ToString()] is DBNull) ? string.Empty : String.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(dr[MyForm3283DataModelOutputFields.PeriodEndDate.ToString()].ToString())),
                ClientName = (dr[MyForm3283DataModelOutputFields.ClientName.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.ClientName.ToString()].ToString(),
                //ProposedADCED = (dr[MyForm3283DataModelOutputFields.ProposedADCED.ToString()] is DBNull) ? string.Empty : String.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(dr[MyForm3283DataModelOutputFields.PeriodEndDate.ToString()].ToString())),
                EstimatedIssuanceReportDate = (dr[MyForm3283DataModelOutputFields.EstimatedIssuanceReportDate.ToString()] is DBNull) ? string.Empty : String.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(dr[MyForm3283DataModelOutputFields.EstimatedIssuanceReportDate.ToString()].ToString())),
                WBSLevelOneNumber = (dr[MyForm3283DataModelOutputFields.WBSLevelOneNumber.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.WBSLevelOneNumber.ToString()].ToString(),
                RowNumber = (dr[MyForm3283DataModelOutputFields.RowNumber.ToString()] is DBNull) ? 0 : int.Parse(dr[MyForm3283DataModelOutputFields.RowNumber.ToString()].ToString()),
                Count = (dr[MyForm3283DataModelOutputFields.Count.ToString()] is DBNull) ? 0 : int.Parse(dr[MyForm3283DataModelOutputFields.Count.ToString()].ToString()),
                EntityTypeDescription = (dr[MyForm3283DataModelOutputFields.EntityTypeDescription.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.EntityTypeDescription.ToString()].ToString(),
                ProfessionalStandardDescription = (dr[MyForm3283DataModelOutputFields.ProfessionalStandardDescription.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.ProfessionalStandardDescription.ToString()].ToString(),
                EngagementTypeDescription = (dr[MyForm3283DataModelOutputFields.EngagementTypeDescription.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.EngagementTypeDescription.ToString()].ToString(),
                Due = (dr[MyForm3283DataModelOutputFields.Due.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.Due.ToString()].ToString(),
                ReportingEntity = (dr[MyForm3283DataModelOutputFields.ReportingEntity.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.ReportingEntity.ToString()].ToString(),
                ArchiveDueDate = (dr[MyForm3283DataModelOutputFields.ArchiveDueDate.ToString()] is DBNull) ? string.Empty : String.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(dr[MyForm3283DataModelOutputFields.ArchiveDueDate.ToString()].ToString())),
                IsResubmissionInProgress = (dr[MyForm3283DataModelOutputFields.IsResubmissionInProgress.ToString()] is DBNull) ? "No" : (Convert.ToBoolean(dr[MyForm3283DataModelOutputFields.IsResubmissionInProgress.ToString()]) ? "Yes" : "No"),
                Description = (dr[MyForm3283DataModelOutputFields.Description.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.Description.ToString()].ToString(),
                ArchivePartner = (dr[MyForm3283DataModelOutputFields.ArchivePartner.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.ArchivePartner.ToString()].ToString(),
                ArchiveManager = (dr[MyForm3283DataModelOutputFields.ArchiveManager.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.ArchiveManager.ToString()].ToString(),
                ArchiveFieldSenior = (dr[MyForm3283DataModelOutputFields.ArchiveFieldSenior.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.ArchiveFieldSenior.ToString()].ToString(),
                AddArchiveFieldSenior = (dr[MyForm3283DataModelOutputFields.AddArchiveFieldSenior.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.AddArchiveFieldSenior.ToString()].ToString(),
                ArchiveStatus = (dr[MyForm3283DataModelOutputFields.ArchiveStatus.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.ArchiveStatus.ToString()].ToString()


            };
        }


    }

    public class MyForm3283DetailsExportToExcelTransformer : BaseTransformer<MyForm3283DataModel>
    {
        internal override MyForm3283DataModel TransformElement(IDataReader dr, Func<IDataReader, MyForm3283DataModel, MyForm3283DataModel> bindExtraFields = null)
        {
            return new MyForm3283DataModel
            {
                ArchiveNumber = (dr[MyForm3283DataModelOutputFields.ArchiveNumber.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.ArchiveNumber.ToString()].ToString(),
                EngagementDescription = (dr[MyForm3283DataModelOutputFields.EngagementDescription.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.EngagementDescription.ToString()].ToString(),
                PeriodEndDate = (dr[MyForm3283DataModelOutputFields.PeriodEndDate.ToString()] is DBNull) ? string.Empty : String.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(dr[MyForm3283DataModelOutputFields.PeriodEndDate.ToString()].ToString())),
                ClientName = (dr[MyForm3283DataModelOutputFields.ClientName.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.ClientName.ToString()].ToString(),
                ProposedADCED = (dr[MyForm3283DataModelOutputFields.ProposedADCED.ToString()] is DBNull) ? string.Empty : String.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(dr[MyForm3283DataModelOutputFields.PeriodEndDate.ToString()].ToString())),
                EstimatedIssuanceReportDate = (dr[MyForm3283DataModelOutputFields.EstimatedIssuanceReportDate.ToString()] is DBNull) ? string.Empty : String.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(dr[MyForm3283DataModelOutputFields.EstimatedIssuanceReportDate.ToString()].ToString())),
                WBSLevelOneNumber = (dr[MyForm3283DataModelOutputFields.WBSLevelOneNumber.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.WBSLevelOneNumber.ToString()].ToString(),
                RowNumber = (dr[MyForm3283DataModelOutputFields.RowNumber.ToString()] is DBNull) ? 0 : int.Parse(dr[MyForm3283DataModelOutputFields.RowNumber.ToString()].ToString()),
                Count = (dr[MyForm3283DataModelOutputFields.Count.ToString()] is DBNull) ? 0 : int.Parse(dr[MyForm3283DataModelOutputFields.Count.ToString()].ToString()),
                EntityTypeDescription = (dr[MyForm3283DataModelOutputFields.EntityTypeDescription.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.EntityTypeDescription.ToString()].ToString(),
                ProfessionalStandardDescription = (dr[MyForm3283DataModelOutputFields.ProfessionalStandardDescription.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.ProfessionalStandardDescription.ToString()].ToString(),
                EngagementTypeDescription = (dr[MyForm3283DataModelOutputFields.EngagementTypeDescription.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.EngagementTypeDescription.ToString()].ToString(),
                Due = (dr[MyForm3283DataModelOutputFields.Due.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.Due.ToString()].ToString(),
                ReportingEntity = (dr[MyForm3283DataModelOutputFields.ReportingEntity.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.ReportingEntity.ToString()].ToString(),
                ArchiveDueDate = (dr[MyForm3283DataModelOutputFields.ArchiveDueDate.ToString()] is DBNull) ? string.Empty : String.Format("{0:MM/dd/yyyy}", Convert.ToDateTime(dr[MyForm3283DataModelOutputFields.ArchiveDueDate.ToString()].ToString())),
                IsResubmissionInProgress = (dr[MyForm3283DataModelOutputFields.IsResubmissionInProgress.ToString()] is DBNull) ? "No" : (Convert.ToBoolean(dr[MyForm3283DataModelOutputFields.IsResubmissionInProgress.ToString()]) ? "Yes" : "No"),
                Description = (dr[MyForm3283DataModelOutputFields.Description.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.Description.ToString()].ToString(),
                ArchivePartner = (dr[MyForm3283DataModelOutputFields.ArchivePartner.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.ArchivePartner.ToString()].ToString(),
                ArchiveManager = (dr[MyForm3283DataModelOutputFields.ArchiveManager.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.ArchiveManager.ToString()].ToString(),
                ArchiveFieldSenior = (dr[MyForm3283DataModelOutputFields.ArchiveFieldSenior.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.ArchiveFieldSenior.ToString()].ToString(),
                AddArchiveFieldSenior = (dr[MyForm3283DataModelOutputFields.AddArchiveFieldSenior.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.AddArchiveFieldSenior.ToString()].ToString(),
                ArchiveStatus = (dr[MyForm3283DataModelOutputFields.ArchiveStatus.ToString()] is DBNull) ? string.Empty : dr[MyForm3283DataModelOutputFields.ArchiveStatus.ToString()].ToString()


            };
        }


    }


    public enum MyForm3283DataModelOutputFields
    {
        ArchiveNumber,
        ClientName,
        EngagementDescription,
        PeriodEndDate,
        WBSLevelOneNumber,
        EstimatedIssuanceReportDate,
        ProposedADCED,
        LastName,
        FirstName,
        RowNumber,
        Count,
        EntityTypeDescription,
        ProfessionalStandardDescription,
        Due,
        ArchiveStatus,
        IsArchiveCompleted,
        EngagementTypeDescription,
        ReportingEntity,
        ArchiveDueDate,
        IsResubmissionInProgress,
        Description,
        ArchivePartner,
        ArchiveManager,
        ArchiveFieldSenior,
        AddArchiveFieldSenior,
        CountOrange,
        CountRed,
        CountYellow
    }

    public enum ComplianceMetricsOutputFields
    {
        ArchiveNumber,
        ClientName,
        EngagementDescription,
        PeriodEndDate,
        DueDate,
        InitialApproval,
        WBSLevelOne,
        ComplianceStatus,
        EngagementTypeDescription,
        EstimatedIssuanceReportDate,
        ArchiveDueDate,
        ADCED,
        IsResubmissionInProgress,
        Description,
        EntityTypeDescription,
        ProfessionalStandardDescription,
        ReportingEntity,
        ArchivePartner,
        ArchiveManager,
        ArchiveFieldSenior,
        AddArchiveFieldSenior,
        RowNumber,
        Count,
        OnTimeCount,
        LateWithApprovalCount,
        LateCount,
        LatePast45DaysCount,
        CountBeforeFiltering
    }


    public class InsertArchiveAccessRequestTransformer : BaseTransformer<InsertArchiveAccessRequestModel>
    {
        internal override InsertArchiveAccessRequestModel TransformElement(IDataReader dr, Func<IDataReader, InsertArchiveAccessRequestModel, InsertArchiveAccessRequestModel> bindExtraFields = null)
        {
            return new InsertArchiveAccessRequestModel
            {
                Message = (dr[InsertArchiveAccessRequestOutputFields.Message.ToString()] is DBNull) ? string.Empty : dr[InsertArchiveAccessRequestOutputFields.Message.ToString()].ToString(),
                RequestedByName = (dr[InsertArchiveAccessRequestOutputFields.RequestedByName.ToString()] is DBNull) ? string.Empty : dr[InsertArchiveAccessRequestOutputFields.RequestedByName.ToString()].ToString(),
                RequestedOfName = (dr[InsertArchiveAccessRequestOutputFields.RequestedOfName.ToString()] is DBNull) ? string.Empty : dr[InsertArchiveAccessRequestOutputFields.RequestedOfName.ToString()].ToString()


            };
        }


    }

    public class TemporaryArchiveAccessRequestTransformer : BaseTransformer<TemporaryArchiveAccessRequestModel>
    {
        internal override TemporaryArchiveAccessRequestModel TransformElement(IDataReader dr, Func<IDataReader, TemporaryArchiveAccessRequestModel, TemporaryArchiveAccessRequestModel> bindExtraFields = null)
        {
            return new TemporaryArchiveAccessRequestModel
            {
                RequestedBy = (dr["RequestedByPersonnelName"] is DBNull) ? string.Empty : dr["RequestedByPersonnelName"].ToString(),
                RequestDesc = (dr["ReqDesc"] is DBNull) ? string.Empty : dr["ReqDesc"].ToString(),
                ArchiveAccessRequestID = (dr["argreqid"] is DBNull) ? string.Empty : dr["argreqid"].ToString()
            };
        }


    }

    public enum InsertArchiveAccessRequestOutputFields
    {
        Message,
        RequestedByName,
        RequestedOfName
    }

    #endregion

    #region ComplianceMetrics
    public enum ComplianceMetricsParameter
    {
        [CreateField(Name = "In_EmployeeUniqueIdentifier", Direction = ParameterDirection.Input, Type = DbType.String)]
        EmployeeUniqueIdentifier,
        [CreateField(Name = "In_PageNumber", Direction = ParameterDirection.Input, Type = DbType.Int32)]
        PageNumber,
        [CreateField(Name = "In_PageSize", Direction = ParameterDirection.Input, Type = DbType.Int32)]
        PageSize,
        [CreateField(Name = "In_SortBy", Direction = ParameterDirection.Input, Type = DbType.Int32)]
        SortBy,
        [CreateField(Name = "In_FilterText", Direction = ParameterDirection.Input, Type = DbType.String)]
        FilterText
    }
    #endregion

    #region MyArchiveDetails
    public enum MyArchiveDetailsOutputFields
    {
        ArchiveID,
        WBSLevelOneNumber,
        EngagementTypeDescription,
        ArchiveDueDate,
        EstimatedIssuanceReportDate,
        IsResubmissionInProgress,
        ReportingEntity,
        ArchivePartner,
        ArchvieManger,
        ArchvieFieldSenior,
        AddArchvieFieldSenior,
        Description,
        FormID
    }

    public enum MyArchiveDetailsFieldParameter
    {
        [CreateField(Name = "ArchiveNumber_In", Direction = ParameterDirection.Input, Type = DbType.String)]
        ArchiveNumber
    }
    public class MyArchiveDetailsTransformer : BaseTransformer<MyArchiveDetailsModel>
    {
        internal override MyArchiveDetailsModel TransformElement(IDataReader dr, Func<IDataReader, MyArchiveDetailsModel, MyArchiveDetailsModel> bindExtraFields = null)
        {
            return new MyArchiveDetailsModel
            {
                ArchiveID = (dr[MyArchiveDetailsOutputFields.ArchiveID.ToString()] is DBNull) ? 0 : int.Parse(dr[MyArchiveDetailsOutputFields.ArchiveID.ToString()].ToString()),
                WBSLevelOneNumber = (dr[MyArchiveDetailsOutputFields.WBSLevelOneNumber.ToString()] is DBNull) ? string.Empty : dr[MyArchiveDetailsOutputFields.WBSLevelOneNumber.ToString()].ToString(),
                EngagementTypeDescription = (dr[MyArchiveDetailsOutputFields.EngagementTypeDescription.ToString()] is DBNull) ? string.Empty : dr[MyArchiveDetailsOutputFields.EngagementTypeDescription.ToString()].ToString(),
                ArchiveDueDate = (dr[MyArchiveDetailsOutputFields.ArchiveDueDate.ToString()] is DBNull) ? DateTime.MinValue : Convert.ToDateTime(dr[MyArchiveDetailsOutputFields.ArchiveDueDate.ToString()].ToString()),
                EstimatedIssuanceReportDate = (dr[MyArchiveDetailsOutputFields.EstimatedIssuanceReportDate.ToString()] is DBNull) ? DateTime.MinValue : Convert.ToDateTime(dr[MyArchiveDetailsOutputFields.EstimatedIssuanceReportDate.ToString()].ToString()),
                IsResubmissionInProgress = (dr[MyArchiveDetailsOutputFields.IsResubmissionInProgress.ToString()] is DBNull) ? false : Convert.ToBoolean(dr[MyArchiveDetailsOutputFields.IsResubmissionInProgress.ToString()]),
                ReportingEntity = (dr[MyArchiveDetailsOutputFields.ReportingEntity.ToString()] is DBNull) ? string.Empty : dr[MyArchiveDetailsOutputFields.ReportingEntity.ToString()].ToString(),
                ArchivePartner = (dr[MyArchiveDetailsOutputFields.ArchivePartner.ToString()] is DBNull) ? string.Empty : dr[MyArchiveDetailsOutputFields.ArchivePartner.ToString()].ToString(),
                ArchvieManger = (dr[MyArchiveDetailsOutputFields.ArchvieManger.ToString()] is DBNull) ? string.Empty : dr[MyArchiveDetailsOutputFields.ArchvieManger.ToString()].ToString(),
                ArchvieFieldSenior = (dr[MyArchiveDetailsOutputFields.ArchvieFieldSenior.ToString()] is DBNull) ? string.Empty : dr[MyArchiveDetailsOutputFields.ArchvieFieldSenior.ToString()].ToString(),
                AddArchvieFieldSenior = (dr[MyArchiveDetailsOutputFields.AddArchvieFieldSenior.ToString()] is DBNull) ? string.Empty : dr[MyArchiveDetailsOutputFields.AddArchvieFieldSenior.ToString()].ToString(),
                Description = (dr[MyArchiveDetailsOutputFields.Description.ToString()] is DBNull) ? string.Empty : dr[MyArchiveDetailsOutputFields.Description.ToString()].ToString(),
            };
        }
    }
    #endregion MyArchiveDetails

    #region ActiveRoleDetais
    public enum ActiveRoleOutputFields
    {
        RoleId,
        EmployeeAlias,
        EmployeeName,
        DisplayOrder,
        ExpirationDate,
        AccessStatus

    }

    public enum ActiveRoleFieldParameter
    {
        [CreateField(Name = "p_ArchiveNumber", Direction = ParameterDirection.Input, Type = DbType.String)]
        ArchiveNumber
    }
    public class ArchiveActiveRoleTransformer : BaseTransformer<ActiveRolesModel>
    {
        internal override ActiveRolesModel TransformElement(IDataReader dr, Func<IDataReader, ActiveRolesModel, ActiveRolesModel> bindExtraFields = null)
        {
            return new ActiveRolesModel
            {
                RoleId = (dr[ActiveRoleOutputFields.RoleId.ToString()] is DBNull) ? 0 : int.Parse(dr[ActiveRoleOutputFields.RoleId.ToString()].ToString()),
                EmployeeAlias = (dr[ActiveRoleOutputFields.EmployeeAlias.ToString()] is DBNull) ? string.Empty : dr[ActiveRoleOutputFields.EmployeeAlias.ToString()].ToString(),
                EmployeeName = (dr[ActiveRoleOutputFields.EmployeeName.ToString()] is DBNull) ? string.Empty : dr[ActiveRoleOutputFields.EmployeeName.ToString()].ToString(),
                DisplayOrder = (dr[ActiveRoleOutputFields.DisplayOrder.ToString()] is DBNull) ? 0 : int.Parse(dr[ActiveRoleOutputFields.DisplayOrder.ToString()].ToString()),
                ExpirationDate = (dr[ActiveRoleOutputFields.ExpirationDate.ToString()] is DBNull) ? DateTime.MinValue : Convert.ToDateTime(dr[ActiveRoleOutputFields.ExpirationDate.ToString()].ToString()),
                AccessStatus = (dr[ActiveRoleOutputFields.AccessStatus.ToString()] is DBNull) ? 0 : int.Parse(dr[ActiveRoleOutputFields.AccessStatus.ToString()].ToString())
            };
        }
    }
    #endregion ActiveRoleDetais

    #region CreateArchive
    public enum CreateArchiveFieldParameter
    {
        [CreateField(Name = "p_WBSLevelOneNumber", Direction = ParameterDirection.Input, Type = DbType.String)]
        WBSLevelOneNumber,
        [CreateField(Name = "p_Description", Direction = ParameterDirection.Input, Type = DbType.String)]
        Description,
        [CreateField(Name = "p_AdditionalDescription", Direction = ParameterDirection.Input, Type = DbType.String)]
        AdditionalDescription,
        [CreateField(Name = "p_EngagementDescription", Direction = ParameterDirection.Input, Type = DbType.String)]
        EngagementDescription,
        [CreateField(Name = "p_PeriodEndDate", Direction = ParameterDirection.Input, Type = DbType.DateTime)]
        PeriodEndDate,
        [CreateField(Name = "p_EngagementType", Direction = ParameterDirection.Input, Type = DbType.String)]
        EngagementType,
        [CreateField(Name = "p_Estimatedissuancedate", Direction = ParameterDirection.Input, Type = DbType.DateTime)]
        Estimatedissuancedate,
        [CreateField(Name = "p_ArchiveType", Direction = ParameterDirection.Input, Type = DbType.String)]
        ArchiveType,
        [CreateField(Name = "p_EntityType", Direction = ParameterDirection.Input, Type = DbType.String)]
        EntityType,
        [CreateField(Name = "p_ArchivePartner", Direction = ParameterDirection.Input, Type = DbType.String)]
        ArchivePartner,
        [CreateField(Name = "p_ArchiveManager", Direction = ParameterDirection.Input, Type = DbType.String)]
        ArchiveManager,
        [CreateField(Name = "p_ArchiveFieldSenior", Direction = ParameterDirection.Input, Type = DbType.String)]
        ArchiveFieldSenior,
        [CreateField(Name = "p_AdditionalArchiveFieldSenior", Direction = ParameterDirection.Input, Type = DbType.String)]
        AdditionalArchiveFieldSenior,
        [CreateField(Name = "p_createdby", Direction = ParameterDirection.Input, Type = DbType.String)]
        createdby,
        [CreateField(Name = "p_roleId", Direction = ParameterDirection.Input, Type = DbType.Int32)]
        RoleId,
        [CreateField(Name = "p_ProfessionalStandard", Direction = ParameterDirection.Input, Type = DbType.String)]
        ProfessionalStandard,
        [CreateField(Name = "p_archivenum", Direction = ParameterDirection.Input, Type = DbType.String)]
        ArchiveNum,
        [CreateField(Name = "p_MessageId", Direction = ParameterDirection.Input, Type = DbType.String)]
        MessageId,
        [CreateField(Name = "p_SigningPartners", Direction = ParameterDirection.Input, Type = DbType.String)]
        SigningPartners
    }

    public enum CreateArchiveOutputFields
    {
        ArchiveNumber,
        IsAccessAllowed
    }


    public class CreateArchiveTransformer : BaseTransformer<ArchiveModel>
    {
        internal override ArchiveModel TransformElement(IDataReader dr, Func<IDataReader, ArchiveModel, ArchiveModel> bindExtraFields = null)
        {
            return new ArchiveModel
            {
                ArchiveNumber = dr[CreateArchiveOutputFields.ArchiveNumber.ToString()].ToString(),
                IsAccessAllowed = int.Parse(dr[CreateArchiveOutputFields.IsAccessAllowed.ToString()].ToString())
            };
        }
    }


    #endregion Create Archive

    #region ArchiveDetailsinfo


    public enum ArchiveDetailsInfoParameter
    {
        [CreateField(Name = "p_ArchiveNumber", Direction = ParameterDirection.Input, Type = DbType.String)]
        ArchiveNumber,
        [CreateField(Name = "UpdateROIResult_Out", Direction = ParameterDirection.Output, Type = DbType.Int32)]
        UpdateROIResult_Out,
        [CreateField(Name = "p_EmployeeUniqueIdentifier", Direction = ParameterDirection.Input, Type = DbType.String)]
        EmployeeUniqueIdentifier
    }

    public enum ArchiveDetailsInfoOutputFields
    {
        EngagementDescription,
        ArchiveDescription,
        WBSNumber,
        ArchiveNumber,
        ClientName,
        PeriodEnd,
        LegalHoldStatus,
        ArchiveStatus,
        CreatedBy,
        LastSubmittedBy,
        EstimatedReleaseDate,
        PrivacyPeriodEndDate,
        LastModifiedBy,
        Resubmissiontype,
        IsApprovalEdited

    }

    public class ArchiveDetailsInfoTransformer : BaseTransformer<ArchiveDetailsModel>
    {
        internal override ArchiveDetailsModel TransformElement(IDataReader dr, Func<IDataReader, ArchiveDetailsModel, ArchiveDetailsModel> bindExtraFields = null)
        {
            return new ArchiveDetailsModel
            {
                EngagementDescription = (dr[ArchiveDetailsInfoOutputFields.EngagementDescription.ToString()] is DBNull) ? string.Empty : dr[ArchiveDetailsInfoOutputFields.EngagementDescription.ToString()].ToString(),
                ArchiveDescription = (dr[ArchiveDetailsInfoOutputFields.ArchiveDescription.ToString()] is DBNull) ? string.Empty : dr[ArchiveDetailsInfoOutputFields.ArchiveDescription.ToString()].ToString(),
                WBSNumber = (dr[ArchiveDetailsInfoOutputFields.WBSNumber.ToString()] is DBNull) ? string.Empty : dr[ArchiveDetailsInfoOutputFields.WBSNumber.ToString()].ToString(),
                ArchiveNumber = (dr[ArchiveDetailsInfoOutputFields.ArchiveNumber.ToString()] is DBNull) ? string.Empty : dr[ArchiveDetailsInfoOutputFields.ArchiveNumber.ToString()].ToString(),
                ClientName = (dr[ArchiveDetailsInfoOutputFields.ClientName.ToString()] is DBNull) ? string.Empty : dr[ArchiveDetailsInfoOutputFields.ClientName.ToString()].ToString(),
                PeriodEnd = (dr[ArchiveDetailsInfoOutputFields.PeriodEnd.ToString()] is DBNull
                                             ? DateTime.MinValue
                                             : Convert.ToDateTime(dr[ArchiveDetailsInfoOutputFields.PeriodEnd.ToString()].ToString())),
                LegalHoldStatus = (dr[ArchiveDetailsInfoOutputFields.LegalHoldStatus.ToString()] is DBNull) ? string.Empty : dr[ArchiveDetailsInfoOutputFields.LegalHoldStatus.ToString()].ToString(),
                ArchiveStatus = (dr[ArchiveDetailsInfoOutputFields.ArchiveStatus.ToString()] is DBNull) ? string.Empty : dr[ArchiveDetailsInfoOutputFields.ArchiveStatus.ToString()].ToString(),
                CreatedBy = (dr[ArchiveDetailsInfoOutputFields.CreatedBy.ToString()] is DBNull) ? string.Empty : dr[ArchiveDetailsInfoOutputFields.CreatedBy.ToString()].ToString(),
                LastSubmittedBy = (dr[ArchiveDetailsInfoOutputFields.LastSubmittedBy.ToString()] is DBNull) ? string.Empty : dr[ArchiveDetailsInfoOutputFields.LastSubmittedBy.ToString()].ToString(),
                EstimatedReleaseDate = (dr[ArchiveDetailsInfoOutputFields.EstimatedReleaseDate.ToString()] is DBNull
                                             ? DateTime.MinValue
                                             : Convert.ToDateTime(dr[ArchiveDetailsInfoOutputFields.EstimatedReleaseDate.ToString()].ToString())),
                PrivacyPeriodEndDate = (dr[ArchiveDetailsInfoOutputFields.PrivacyPeriodEndDate.ToString()] is DBNull
                                             ? DateTime.MinValue
                                             : Convert.ToDateTime(dr[ArchiveDetailsInfoOutputFields.PrivacyPeriodEndDate.ToString()].ToString())),
                LastModifiedBy = (dr[ArchiveDetailsInfoOutputFields.LastModifiedBy.ToString()] is DBNull) ? string.Empty : dr[ArchiveDetailsInfoOutputFields.LastModifiedBy.ToString()].ToString(),
                ResubmissionType = (dr[ArchiveDetailsInfoOutputFields.Resubmissiontype.ToString()] is DBNull) ? null : dr[ArchiveDetailsInfoOutputFields.Resubmissiontype.ToString()].ToString(),
                IsApprovalEdited = (dr[ArchiveDetailsInfoOutputFields.IsApprovalEdited.ToString()] is DBNull) ? null : dr[ArchiveDetailsInfoOutputFields.IsApprovalEdited.ToString()].ToString()
            };
        }
    }

    #endregion ArchiveDetailsinfo

    #region MyArchivesFilterDataTransformer

    public enum MyArchivesFilterDataOutputFields
    {
        RowNumber,
        FilterData
    }
    public enum MyArchivesFilterDataParameter
    {
        [CreateField(Name = "In_EmployeeUniqueIdentifier", Direction = ParameterDirection.Input, Type = DbType.String)]
        EmployeeUniqueIdentifier,
        [CreateField(Name = "In_FilterBy", Direction = ParameterDirection.Input, Type = DbType.Int32)]
        FilterBy
    }
    public class MyArchivesFilterDataTransformer : BaseTransformer<MyArchivesFilterDataModel>
    {
        internal override MyArchivesFilterDataModel TransformElement(IDataReader dr, Func<IDataReader, MyArchivesFilterDataModel, MyArchivesFilterDataModel> bindExtraFields = null)
        {
            return new MyArchivesFilterDataModel
            {
                RowNumber = (dr[MyArchivesFilterDataOutputFields.RowNumber.ToString()] is DBNull) ? 0 : int.Parse(dr[MyArchivesFilterDataOutputFields.RowNumber.ToString()].ToString()),
                FilterData = (dr[MyArchivesFilterDataOutputFields.FilterData.ToString()] is DBNull) ? string.Empty : dr[MyArchivesFilterDataOutputFields.FilterData.ToString()].ToString(),
            };
        }
    }
    #endregion MyArchivesFilterDataTransformer

    #region EditArchiveDetails

    public enum EditArchiveDetailsFieldParameter
    {
        [CreateField(Name = "ArchiveNumber_IN", Direction = ParameterDirection.Input, Type = DbType.String)]
        ArchiveNumber,
        [CreateField(Name = "EngagementDescription_IN", Direction = ParameterDirection.Input, Type = DbType.String)]
        EngagementDescription,
        [CreateField(Name = "PeriodEndDate_IN", Direction = ParameterDirection.Input, Type = DbType.DateTime)]
        PeriodEndDate,
        [CreateField(Name = "EngagementTypeDescription_IN", Direction = ParameterDirection.Input, Type = DbType.String)]
        EngagementTypeDescription,
        [CreateField(Name = "EntityTypeDescription_IN", Direction = ParameterDirection.Input, Type = DbType.String)]
        EntityTypeDescription,
        [CreateField(Name = "StandardsApplied_IN", Direction = ParameterDirection.Input, Type = DbType.String)]
        StandardsApplied,
        [CreateField(Name = "ArchiveNameForWBSLevel1Number_IN", Direction = ParameterDirection.Input, Type = DbType.String)]
        ArchiveNameForWBSLevel1Number,
        [CreateField(Name = "AdditionalDescription_IN", Direction = ParameterDirection.Input, Type = DbType.String)]
        AdditionalDescription,
        [CreateField(Name = "ModifiedBy_IN", Direction = ParameterDirection.Input, Type = DbType.String)]
        ModifiedBy

    }

    #endregion EditArchiveDetails

    #region ArchiveSubmissionTransformer

    public enum ArchiveSubmissionOutputFields
    {
        ArchiveNumber,
        ArchiveStatus,
        OfficeTimeZone,
        ArchiveApprovedDate
    }
    public enum ArchiveSubmissionParameter
    {
        [CreateField(Name = "p_ArchiveNumber", Direction = ParameterDirection.Input, Type = DbType.String)]
        ArchiveNumber,
        [CreateField(Name = "p_CreatedBy", Direction = ParameterDirection.Input, Type = DbType.String)]
        CreatedBy,
        [CreateField(Name = "p_PPDUserAlias", Direction = ParameterDirection.Input, Type = DbType.String)]
        PPDUserAlias,
        [CreateField(Name = "EDCDDate", Direction = ParameterDirection.Input, Type = DbType.DateTime)]
        EstimatedDate,
        [CreateField(Name = "p_roleId", Direction = ParameterDirection.Input, Type = DbType.Int32)]
        RoleId,

    }
    public class ArchiveSubmissionTransformer : BaseTransformer<ArchiveSubmissionModel>
    {
        internal override ArchiveSubmissionModel TransformElement(IDataReader dr, Func<IDataReader, ArchiveSubmissionModel, ArchiveSubmissionModel> bindExtraFields = null)
        {
            return new ArchiveSubmissionModel
            {
                ArchiveNumber = (dr[ArchiveSubmissionOutputFields.ArchiveNumber.ToString()] is DBNull) ? string.Empty : (dr[ArchiveSubmissionOutputFields.ArchiveNumber.ToString()].ToString()),
                ArchiveStatus = (dr[ArchiveSubmissionOutputFields.ArchiveStatus.ToString()] is DBNull) ? string.Empty : dr[ArchiveSubmissionOutputFields.ArchiveStatus.ToString()].ToString(),
                OfficeTimeZone = (dr[ArchiveSubmissionOutputFields.OfficeTimeZone.ToString()] is DBNull) ? string.Empty : dr[ArchiveSubmissionOutputFields.OfficeTimeZone.ToString()].ToString(),
                ArchiveApprovedDate = (dr[ArchiveSubmissionOutputFields.ArchiveApprovedDate.ToString()] is DBNull) ? string.Empty : dr[ArchiveSubmissionOutputFields.ArchiveApprovedDate.ToString()].ToString(),
            };
        }
    }



    #endregion ArchiveSubmissionTransformer

    public enum ResubmissionUpdatePPDORNPPDParameter
    {
        [CreateField(Name = "p_ArchiveNumber", Direction = ParameterDirection.Input, Type = DbType.String)]
        ArchiveNumber,
        [CreateField(Name = "p_CreatedBy", Direction = ParameterDirection.Input, Type = DbType.String)]
        CreatedBy,
        [CreateField(Name = "p_PPDUserAlias", Direction = ParameterDirection.Input, Type = DbType.String)]
        PPDUserAlias,
        [CreateField(Name = "p_isPPD", Direction = ParameterDirection.Input, Type = DbType.Int16)]
        IsPPD
    }


    public enum ArchiveLegalHoldFieldParameter
    {
        [CreateField(Name = "p_ArchiveNumber", Direction = ParameterDirection.Input, Type = DbType.String)]
        ArchiveNumber,
        
        [CreateField(Name = "p_OGCHoldNumber", Direction = ParameterDirection.Input, Type = DbType.String)]
        OGCHoldNumber,
        
        [CreateField(Name = "p_OGCPreservationNoticeDate", Direction = ParameterDirection.Input, Type = DbType.DateTime)]
        OGCPreservationNoticeDate,
        
        [CreateField(Name = "p_OGCAttorneyName", Direction = ParameterDirection.Input, Type = DbType.String)]
        OGCAttorneyName,
        
        [CreateField(Name = "p_Description", Direction = ParameterDirection.Input, Type = DbType.String)]
        Description,

        [CreateField(Name = "p_CreatedBy", Direction = ParameterDirection.Input, Type = DbType.String)]
        CreatedBy

    }

    #region RetentionTransformer

    public enum ArchiveRetentionFieldParameter
    {
        [CreateField(Name = "p_ArchiveNumber", Direction = ParameterDirection.Input, Type = DbType.String)]
        ArchiveNumber,
        [CreateField(Name = "p_Createdby", Direction = ParameterDirection.Input, Type = DbType.String)]
        Createdby,
        [CreateField(Name = "p_Comment", Direction = ParameterDirection.Input, Type = DbType.String)]
        Comment,
        [CreateField(Name = "p_RetentionExtentionReasonId", Direction = ParameterDirection.Input, Type = DbType.String)]
        RetentionReasonId,
        [CreateField(Name = "p_RetentionTime", Direction = ParameterDirection.Input, Type = DbType.Int32)]
        RetentionTime


    }

    public enum RetentionFields
    {
        ArchiveId,
        ArchiveNumber,
        RetentionReasons,
        RetentionTime,
        Comment
    }

    public class ArchiveRetentionTransformer : BaseTransformer<ArchiveRetentionDetailsModel>
    {
        internal override ArchiveRetentionDetailsModel TransformElement(IDataReader dr, Func<IDataReader, ArchiveRetentionDetailsModel, ArchiveRetentionDetailsModel> bindExtraFields = null)
        {

            var retentionEntity = new ArchiveRetentionDetailsModel
            {
                ArchiveId = (dr[RetentionFields.ArchiveId.ToString()] is DBNull) ? 0 : int.Parse(dr[RetentionFields.ArchiveId.ToString()].ToString()),
                ArchiveNumber = (dr[RetentionFields.ArchiveNumber.ToString()] is DBNull) ? String.Empty : dr[RetentionFields.ArchiveNumber.ToString()].ToString(),
                RetentionReasons = (dr[RetentionFields.RetentionReasons.ToString()] is DBNull) ? String.Empty : dr[RetentionFields.RetentionReasons.ToString()].ToString(),
                RetentionTime = (dr[RetentionFields.RetentionTime.ToString()] is DBNull) ? 0 : int.Parse(dr[RetentionFields.RetentionTime.ToString()].ToString()),
                Comments = (dr[RetentionFields.Comment.ToString()] is DBNull) ? String.Empty : dr[RetentionFields.Comment.ToString()].ToString()

            };


            return retentionEntity;
        }



    }


    #endregion RetentionTransformer

    #region ArchiveSubmissionCheckDetails


    public enum ArchiveSubmissionCheckInputParameter
    {
        [CreateField(Name = "archiveNum", Direction = ParameterDirection.Input, Type = DbType.String)]
        ArchiveNumber,
        [CreateField(Name = "UserAlias", Direction = ParameterDirection.Input, Type = DbType.String)]
        UserAlias
        //    ,
        //[CreateField(Name = "wkpdescription", Direction = ParameterDirection.Output, Type = DbType.String)]
        //Workpaperdesc,
        //[CreateField(Name = "deliverabledescription", Direction = ParameterDirection.Output, Type = DbType.String)]
        //deliverabledesc,
        //[CreateField(Name = "retentiondescription", Direction = ParameterDirection.Output, Type = DbType.String)]
        //RetentionDesc,
        //[CreateField(Name = "createdBy", Direction = ParameterDirection.Output, Type = DbType.String)]
        //createdBy

    }

    public enum ArchiveSubmissionCheckOutputFields
    {
        EnableSubmitButton,
        EnableDatePicker,
        EnablePeoplePicker,
        Isverificationsuccess,
        EngagementDetailsStatus,
        wkpdescription,
        deliverabledescription,
        RelatedArchiveStatus,
        EngagementrelatedpersonnelStatus,
        RetentionExceptionStatus

    }

    public class ArchiveDateAndPeoplePickerDetailsTransformer : BaseTransformer<ArchiveSubmissionCheckModel>
    {
        internal override ArchiveSubmissionCheckModel TransformElement(IDataReader dr, Func<IDataReader, ArchiveSubmissionCheckModel, ArchiveSubmissionCheckModel> bindExtraFields = null)
        {
            return new ArchiveSubmissionCheckModel
            {
                ReadyToSubmit = (dr[ArchiveSubmissionCheckOutputFields.EnableSubmitButton.ToString()] is DBNull) ? false : Convert.ToBoolean(dr[ArchiveSubmissionCheckOutputFields.EnableSubmitButton.ToString()]),
                ShowPeoplePicker = (dr[ArchiveSubmissionCheckOutputFields.EnablePeoplePicker.ToString()] is DBNull) ? false : Convert.ToBoolean(dr[ArchiveSubmissionCheckOutputFields.EnablePeoplePicker.ToString()]),
                ShowDatePicker = (dr[ArchiveSubmissionCheckOutputFields.EnableDatePicker.ToString()] is DBNull) ? false : Convert.ToBoolean(dr[ArchiveSubmissionCheckOutputFields.EnableDatePicker.ToString()]),
                Isverificationsuccess = (dr[ArchiveSubmissionCheckOutputFields.Isverificationsuccess.ToString()] is DBNull) ? false : Convert.ToBoolean(dr[ArchiveSubmissionCheckOutputFields.Isverificationsuccess.ToString()]),

            };
        }
    }

    #endregion ArchiveSubmissionCheckDetails

    #region ArchiveActions


    public enum ArchiveActionsInputParameter
    {
        [CreateField(Name = "archiveNum", Direction = ParameterDirection.Input, Type = DbType.String)]
        ArchiveNumber
    }

    public enum ArchiveActionsOutputFields
    {
        Submissionpackageid,
        ActionTypeId,
        ArchiveSectionId,
        ActionBy,
        isSectionEdited
    }

    public class ArchiveActionsTransformer : BaseTransformer<ArchiveAction>
    {
        internal override ArchiveAction TransformElement(IDataReader dr, Func<IDataReader, ArchiveAction, ArchiveAction> bindExtraFields = null)
        {
            return new ArchiveAction
            {
                ArchiveId = (dr[ArchiveActionsOutputFields.Submissionpackageid.ToString()] is DBNull) ? 0 : Convert.ToInt32(dr[ArchiveActionsOutputFields.Submissionpackageid.ToString()]),
                ActionsTypeId = (dr[ArchiveActionsOutputFields.ActionTypeId.ToString()] is DBNull) ? 0 : Convert.ToInt32(dr[ArchiveActionsOutputFields.ActionTypeId.ToString()]),
                ArchiveSectionId = (dr[ArchiveActionsOutputFields.ArchiveSectionId.ToString()] is DBNull) ? 0 : Convert.ToInt32(dr[ArchiveActionsOutputFields.ArchiveSectionId.ToString()]),
                ActionBy = (dr[ArchiveActionsOutputFields.ActionBy.ToString()] is DBNull) ? null : dr[ArchiveActionsOutputFields.ActionBy.ToString()].ToString()
            };
        }
    }

    public class ArchiveActionsIndividualSectionTransformer : BaseTransformer<ArchiveAtcionsForIndividualSections>
    {
        internal override ArchiveAtcionsForIndividualSections TransformElement(IDataReader dr, Func<IDataReader, ArchiveAtcionsForIndividualSections, ArchiveAtcionsForIndividualSections> bindExtraFields = null)
        {
            return new ArchiveAtcionsForIndividualSections
            {
                ActionsTypeId = (dr[ArchiveActionsOutputFields.ActionTypeId.ToString()] is DBNull) ? 0 : Convert.ToInt32(dr[ArchiveActionsOutputFields.ActionTypeId.ToString()]),
                ArchiveSectionId = (dr[ArchiveActionsOutputFields.ArchiveSectionId.ToString()] is DBNull) ? 0 : Convert.ToInt32(dr[ArchiveActionsOutputFields.ArchiveSectionId.ToString()]),
                ActionBy = (dr[ArchiveActionsOutputFields.ActionBy.ToString()] is DBNull) ? null : dr[ArchiveActionsOutputFields.ActionBy.ToString()].ToString(),
                isSectionEdited = (dr[ArchiveActionsOutputFields.isSectionEdited.ToString()] is DBNull) ? 0 : Convert.ToInt32(dr[ArchiveActionsOutputFields.isSectionEdited.ToString()])
            };
        }
    }

    #endregion ArchiveSubmissionCheckDetails

    #region GetWorkingPapersStatus


    //public enum WorkingPapersStatusInputParameter
    //{
    //    [CreateField(Name = "archiveNum", Direction = ParameterDirection.Input, Type = DbType.String)]
    //    ArchiveNumber
    //}

    public enum WorkingPapersStatusOutputFields
    {
        wkpdescription,
        createdBy
    }

    public class WorkingPapersStatusTransformer : BaseTransformer<WorkingPaperSectionStatusCheckModel>
    {
        internal override WorkingPaperSectionStatusCheckModel TransformElement(IDataReader dr, Func<IDataReader, WorkingPaperSectionStatusCheckModel, WorkingPaperSectionStatusCheckModel> bindExtraFields = null)
        {
            return new WorkingPaperSectionStatusCheckModel
            {
                wkpdescription = (dr[WorkingPapersStatusOutputFields.wkpdescription.ToString()] is DBNull) ? null : dr[WorkingPapersStatusOutputFields.wkpdescription.ToString()].ToString(),
                createdBy = (dr[WorkingPapersStatusOutputFields.createdBy.ToString()] is DBNull) ? null : dr[WorkingPapersStatusOutputFields.createdBy.ToString()].ToString()
            };
        }
    }

    #endregion GetWorkingPapersStatus

    #region GetDeliverablesStatus


    //public enum WorkingPapersStatusInputParameter
    //{
    //    [CreateField(Name = "archiveNum", Direction = ParameterDirection.Input, Type = DbType.String)]
    //    ArchiveNumber
    //}

    public enum DeliverablesStatusOutputFields
    {
        deliverabledescription,
        createdBy
    }

    public class DeliverablesStatusTransformer : BaseTransformer<DeliverablesStatusCheckModel>
    {
        internal override DeliverablesStatusCheckModel TransformElement(IDataReader dr, Func<IDataReader, DeliverablesStatusCheckModel, DeliverablesStatusCheckModel> bindExtraFields = null)
        {
            return new DeliverablesStatusCheckModel
            {
                deliverabledescription = (dr[DeliverablesStatusOutputFields.deliverabledescription.ToString()] is DBNull) ? null : dr[DeliverablesStatusOutputFields.deliverabledescription.ToString()].ToString(),
                createdBy = (dr[DeliverablesStatusOutputFields.createdBy.ToString()] is DBNull) ? null : dr[DeliverablesStatusOutputFields.createdBy.ToString()].ToString()
            };
        }
    }

    #endregion GetDeliverablesStatus

    #region GetLinkedArchivesStatus

    public enum LinkedArchivesStatusOutputFields
    {
        ladescription,
        createdBy
    }

    public class LinkedArchivesStatusTransformer : BaseTransformer<LinkedArchivesSectionStatusCheckModel>
    {
        internal override LinkedArchivesSectionStatusCheckModel TransformElement(IDataReader dr, Func<IDataReader, LinkedArchivesSectionStatusCheckModel, LinkedArchivesSectionStatusCheckModel> bindExtraFields = null)
        {
            return new LinkedArchivesSectionStatusCheckModel
            {
                ladescription = (dr[LinkedArchivesStatusOutputFields.ladescription.ToString()] is DBNull) ? null : dr[LinkedArchivesStatusOutputFields.ladescription.ToString()].ToString(),
                createdBy = (dr[LinkedArchivesStatusOutputFields.createdBy.ToString()] is DBNull) ? null : dr[LinkedArchivesStatusOutputFields.createdBy.ToString()].ToString()
            };
        }
    }

    #endregion GetLinkedArchivesStatus

    #region GetBindersStatus

    public enum BindersStatusOutputFields
    {
        bindescription,
        createdBy
    }

    public class BindersStatusTransformer : BaseTransformer<BindersSectionStatusCheckModel>
    {
        internal override BindersSectionStatusCheckModel TransformElement(IDataReader dr, Func<IDataReader, BindersSectionStatusCheckModel, BindersSectionStatusCheckModel> bindExtraFields = null)
        {
            return new BindersSectionStatusCheckModel
            {
                bindescription = (dr[BindersStatusOutputFields.bindescription.ToString()] is DBNull) ? null : dr[BindersStatusOutputFields.bindescription.ToString()].ToString(),
                createdBy = (dr[BindersStatusOutputFields.createdBy.ToString()] is DBNull) ? null : dr[BindersStatusOutputFields.createdBy.ToString()].ToString()
            };
        }
    }

    #endregion GetBindersStatus

    public enum ArchiveSubmissionFlowSubmitter
    {
        [CreateField(Name = "p_ArchiveNumber", Direction = ParameterDirection.Input, Type = DbType.String)]
        ArchiveNumber,
        [CreateField(Name = "p_UserAlias", Direction = ParameterDirection.Input, Type = DbType.String)]
        UserAlias,
        [CreateField(Name = "p_roleId", Direction = ParameterDirection.Input, Type = DbType.Int32)]
        RoleId,
        [CreateField(Name = "OutputResult", Direction = ParameterDirection.Output, Type = DbType.String)]
        OutputResult
    }
    public enum CheckIfAPSubmitterInactive
    {
        [CreateField(Name = "p_ArchiveNumber", Direction = ParameterDirection.Input, Type = DbType.String)]
        ArchiveNumber,
        [CreateField(Name = "p_UserAlias", Direction = ParameterDirection.Input, Type = DbType.String)]
        UserAlias,
        [CreateField(Name = "P_CheckType", Direction = ParameterDirection.Input, Type = DbType.Int32)]
        CheckType
    }
    public enum HoldDetailMetadataOutputFields
    {
        HoldNumber,
        ClientName,
        BusinessName,
        EffectiveStartDate,
        EffectiveEndDate,
        HoldStatus,
        Count
    }
    public enum HoldDetailMetadataInputParameter
    {
        [CreateField(Name = "p_HoldNumber", Direction = ParameterDirection.Input, Type = DbType.String)]
        HoldNumber,
        [CreateField(Name = "p_BuisnessID", Direction = ParameterDirection.Input, Type = DbType.String)]
        BusinessId,
        [CreateField(Name = "p_Clientid", Direction = ParameterDirection.Input, Type = DbType.String)]
        ClientId,
        [CreateField(Name = "p_FilterText", Direction = ParameterDirection.Input, Type = DbType.String)]
        FilterText,
        [CreateField(Name = "p_SortBy", Direction = ParameterDirection.Input, Type = DbType.Int32)]
        SortBy
    }
    public enum HoldDetailOutputFields
    {
        ClientName,
        ArchiveName,
        ArchiveNumber,
        BusinessName,
        PeriodEndDate
    }
    public enum ApplyArchiveHoldsParams
    {
        [CreateField(Name = "p_HoldNumber", Direction = ParameterDirection.Input, Type = DbType.String)]
        HoldNumber,
        [CreateField(Name = "p_ArchiveNumber", Direction = ParameterDirection.Input, Type = DbType.String)]
        ArchiveNumber,
        [CreateField(Name = "p_CreatedBy", Direction = ParameterDirection.Input, Type = DbType.String)]
        CreatedBy,
        [CreateField(Name = "SearchBy_IN", Direction = ParameterDirection.Input, Type = DbType.String)]
        SearchBy,
        [CreateField(Name = "SearchBy_Value", Direction = ParameterDirection.Input, Type = DbType.String)]
        SearchByValue,
        [CreateField(Name = "IncludeOrExclude", Direction = ParameterDirection.Input, Type = DbType.String)]
        IncludeOrExclude,
        [CreateField(Name = "Business", Direction = ParameterDirection.Input, Type = DbType.String)]
        Business,
        [CreateField(Name = "PeriodStart", Direction = ParameterDirection.Input, Type = DbType.String)]
        PeriodStart,
        [CreateField(Name = "PeriodEnd", Direction = ParameterDirection.Input, Type = DbType.String)]
        PeriodEnd,
        [CreateField(Name = "SortBy", Direction = ParameterDirection.Input, Type = DbType.String)]
        SortBy,
        [CreateField(Name = "SortOrder", Direction = ParameterDirection.Input, Type = DbType.String)]
        SortOrder,
        [CreateField(Name = "In_PageNumber", Direction = ParameterDirection.Input, Type = DbType.Int32)]
        PageNumber,
        [CreateField(Name = "In_PageSize", Direction = ParameterDirection.Input, Type = DbType.Int32)]
        PageSize
    }

    public enum AppliedHoldsonArchives
    {
        ClientName,
        ArchiveNumber,
        Business,
        PeriodEndDate,
        EffectiveStartDate,
        EffectiveEndDate,
        Status,
        ArchiveName,
        RecordDescription,
        Count
    }

    
    public class ApplyArchiveHoldsTransformer : BaseTransformer<AppliedArchiveHoldsInformationModel>
    {
        internal override AppliedArchiveHoldsInformationModel TransformElement(IDataReader dr, Func<IDataReader, AppliedArchiveHoldsInformationModel, AppliedArchiveHoldsInformationModel> bindExtraFields = null)
        {

            var appliedArchiveHoldsDetails = new AppliedArchiveHoldsInformationModel
            {
                
                ClientName = (dr[AppliedHoldsonArchives.ClientName.ToString()] is DBNull) ? string.Empty : dr[AppliedHoldsonArchives.ClientName.ToString()].ToString(),
                ArchiveNumber = (dr[AppliedHoldsonArchives.ArchiveNumber.ToString()] is DBNull) ? string.Empty : dr[AppliedHoldsonArchives.ArchiveNumber.ToString()].ToString(),
                ArchiveName = (dr[AppliedHoldsonArchives.ArchiveName.ToString()] is DBNull) ? string.Empty : dr[AppliedHoldsonArchives.ArchiveName.ToString()].ToString(),
                RecordDescription = (dr[AppliedHoldsonArchives.RecordDescription.ToString()] is DBNull) ? string.Empty : dr[AppliedHoldsonArchives.RecordDescription.ToString()].ToString(),
                Business = (dr[AppliedHoldsonArchives.Business.ToString()] is DBNull) ? string.Empty : dr[AppliedHoldsonArchives.Business.ToString()].ToString(),
                PeriodEndDate = dr[AppliedHoldsonArchives.PeriodEndDate.ToString()] is DBNull ? (DateTime?)null : DateTime.Parse(dr[AppliedHoldsonArchives.PeriodEndDate.ToString()].ToString()),
                EffectiveStartDate = dr[AppliedHoldsonArchives.EffectiveStartDate.ToString()] is DBNull ? (DateTime?)null : DateTime.Parse(dr[AppliedHoldsonArchives.EffectiveStartDate.ToString()].ToString()),
                EffectiveEndDate = dr[AppliedHoldsonArchives.EffectiveEndDate.ToString()] is DBNull ? (DateTime?)null : DateTime.Parse(dr[AppliedHoldsonArchives.EffectiveEndDate.ToString()].ToString()),
                Status = (dr[AppliedHoldsonArchives.Status.ToString()] is DBNull) ? string.Empty : dr[AppliedHoldsonArchives.Status.ToString()].ToString(),
                Count  = Convert.ToInt32(dr[AppliedHoldsonArchives.Count.ToString()].ToString())

        };
            return appliedArchiveHoldsDetails;
        }

    }
    public class HoldsMeatadataDetailTransformer : BaseTransformer<HoldDetailsMetadataModel>
    {
        internal override HoldDetailsMetadataModel TransformElement(IDataReader dr, Func<IDataReader, HoldDetailsMetadataModel, HoldDetailsMetadataModel> bindExtraFields = null)
        {
            HoldDetailsMetadataModel lstDetails = new HoldDetailsMetadataModel();
            lstDetails.lstholdsDetails = new List<HoldsDetailModel>();

            lstDetails.HoldNumber = (dr[HoldDetailMetadataOutputFields.HoldNumber.ToString()] is DBNull) ? string.Empty : dr[HoldDetailMetadataOutputFields.HoldNumber.ToString()].ToString();
            lstDetails.ClientName = (dr[HoldDetailMetadataOutputFields.ClientName.ToString()] is DBNull) ? string.Empty : dr[HoldDetailMetadataOutputFields.ClientName.ToString()].ToString();
            lstDetails.BusinessName = (dr[HoldDetailMetadataOutputFields.BusinessName.ToString()] is DBNull) ? string.Empty : dr[HoldDetailMetadataOutputFields.BusinessName.ToString()].ToString();
            lstDetails.EffectiveStartDate = (dr[HoldDetailMetadataOutputFields.EffectiveStartDate.ToString()] is DBNull ? DateTime.MinValue : DateTime.Parse(dr[HoldDetailMetadataOutputFields.EffectiveStartDate.ToString()].ToString()));
            lstDetails.EffectiveEndDate = (dr[HoldDetailMetadataOutputFields.EffectiveEndDate.ToString()] is DBNull ? DateTime.MinValue : DateTime.Parse(dr[HoldDetailMetadataOutputFields.EffectiveEndDate.ToString()].ToString()));
            lstDetails.HoldStatus = Convert.ToInt32(dr[HoldDetailMetadataOutputFields.HoldStatus.ToString()].ToString());
            lstDetails.ArchivesCount = Convert.ToInt32(dr[HoldDetailMetadataOutputFields.Count.ToString()].ToString());

            if (dr.NextResult())
            {
                while (dr.Read())
                {
                    lstDetails.lstholdsDetails.Add(new HoldsDetailModel
                    {
                        ClientName = (dr[HoldDetailOutputFields.ClientName.ToString()] is DBNull) ? string.Empty : dr[HoldDetailOutputFields.ClientName.ToString()].ToString(),
                        ArchiveName = (dr[HoldDetailOutputFields.ArchiveName.ToString()] is DBNull) ? string.Empty : dr[HoldDetailOutputFields.ArchiveName.ToString()].ToString(),
                        ArchiveNumber = (dr[HoldDetailOutputFields.ArchiveNumber.ToString()] is DBNull) ? string.Empty : dr[HoldDetailOutputFields.ArchiveNumber.ToString()].ToString(),
                        BusinessName = (dr[HoldDetailOutputFields.BusinessName.ToString()] is DBNull) ? string.Empty : dr[HoldDetailOutputFields.BusinessName.ToString()].ToString(),
                        PeriodEndDate = (dr[HoldDetailOutputFields.PeriodEndDate.ToString()] is DBNull ? DateTime.MinValue : DateTime.Parse(dr[HoldDetailOutputFields.PeriodEndDate.ToString()].ToString()))
                    });
                }
            }
            return lstDetails;
        }
    }
    public enum HoldDetailsOutput
    {
        HoldId,
        HoldNumber,
        ArchiveID,
        ArchiveNumber,
        Login,
        CreatedDate,
        HoldDetailStatus,
    }
    public class GetHoldsDetailsHistoryTransformer : BaseTransformer<HoldHistoryDetailsModel>
    {
        internal override HoldHistoryDetailsModel TransformElement(IDataReader dr, Func<IDataReader, HoldHistoryDetailsModel, HoldHistoryDetailsModel> bindExtraFields = null)
        {

            var GetHoldsHistoryDetails = new HoldHistoryDetailsModel
            {

                HoldId = dr[HoldDetailsOutput.HoldId.ToString()] is DBNull ? 0 : int.Parse(dr[HoldDetailsOutput.HoldId.ToString()].ToString()),
                ArchiveId = dr[HoldDetailsOutput.ArchiveID.ToString()] is DBNull ? 0 : int.Parse(dr[HoldDetailsOutput.ArchiveID.ToString()].ToString()),
                HoldNumber = dr[HoldDetailsOutput.HoldNumber.ToString()] is DBNull ? string.Empty : dr[HoldDetailsOutput.HoldNumber.ToString()].ToString(),
                ArchiveNumber = dr[HoldDetailsOutput.ArchiveNumber.ToString()] is DBNull ? string.Empty : dr[HoldDetailsOutput.ArchiveNumber.ToString()].ToString(),
                CreatedBy = dr[HoldDetailsOutput.Login.ToString()] is DBNull ? string.Empty : dr[HoldDetailsOutput.Login.ToString()].ToString(),
                CreatedDate = dr[HoldDetailsOutput.CreatedDate.ToString()] is DBNull ? (DateTime?)null : DateTime.Parse(dr[HoldDetailsOutput.CreatedDate.ToString()].ToString()),
                Status = dr[HoldDetailsOutput.HoldDetailStatus.ToString()] is DBNull ? string.Empty : dr[HoldDetailsOutput.HoldDetailStatus.ToString()].ToString()

            };
            return GetHoldsHistoryDetails;
        }

    }

    public enum GetArchiveApprover
    {
        CanApprove,
        LoggedInUserAlias,
        ArchiveSubmitter
    }
    public enum OmniaArchiveSubmissionStatusField
    {
        IsAllowed
    }
   
    public enum GetHoldsInfoForPagination
    {
        [CreateField(Name = "S_PageNumber", Direction = ParameterDirection.Input, Type = DbType.Int32)]
        PageNumber,
        [CreateField(Name = "S_PageSize", Direction = ParameterDirection.Input, Type = DbType.Int32)]
        PageSize,
        [CreateField(Name = "S_SortBy", Direction = ParameterDirection.Input, Type = DbType.Int32)]
        SortBy,
        [CreateField(Name = "S_FilterBy", Direction = ParameterDirection.Input, Type = DbType.Int32)]
        FilterBy,
        [CreateField(Name = "S_FilterText", Direction = ParameterDirection.Input, Type = DbType.String)]
        FilterText
    }
   

    public class GetArchiveApproverTransformer : BaseTransformer<GetApproverFromSubmitterModel>
    {
        internal override GetApproverFromSubmitterModel TransformElement(IDataReader dr, Func<IDataReader, GetApproverFromSubmitterModel, GetApproverFromSubmitterModel> bindExtraFields = null)
        {
            return new GetApproverFromSubmitterModel
            {
                CanApprove = (dr[GetArchiveApprover.CanApprove.ToString()] is DBNull) ? false : Convert.ToBoolean(dr[GetArchiveApprover.CanApprove.ToString()].ToString()),
                LoggedInUserAlias = (dr[GetArchiveApprover.LoggedInUserAlias.ToString()] is DBNull) ? string.Empty : dr[GetArchiveApprover.LoggedInUserAlias.ToString()].ToString(),
                ArchiveSubmitter = (dr[GetArchiveApprover.ArchiveSubmitter.ToString()] is DBNull) ? string.Empty : dr[GetArchiveApprover.ArchiveSubmitter.ToString()].ToString()
            };
        }
    }

    public class OmniaArchiveSubmissionStatusTransformer : BaseTransformer<OmniaArchiveSubmissionStatusModel>
    {
        internal override OmniaArchiveSubmissionStatusModel TransformElement(IDataReader dr, Func<IDataReader, OmniaArchiveSubmissionStatusModel, OmniaArchiveSubmissionStatusModel> bindExtraFields = null)
        {
            return new OmniaArchiveSubmissionStatusModel
            {
                IsAllowed = (dr[OmniaArchiveSubmissionStatusField.IsAllowed.ToString()] is DBNull) ? false : Convert.ToBoolean(dr[OmniaArchiveSubmissionStatusField.IsAllowed.ToString()]),
            };
        }
    }


    #region GetRetentionExceptionStatus


    //public enum WorkingPapersStatusInputParameter
    //{
    //    [CreateField(Name = "archiveNum", Direction = ParameterDirection.Input, Type = DbType.String)]
    //    ArchiveNumber
    //}

    public enum RetentionExceptionStatusOutputFields
    {
        retentiondescription,
        createdBy
    }

    public class RetentionExceptionStatusTransformer : BaseTransformer<RetentionExceptionStatusCheckModel>
    {
        internal override RetentionExceptionStatusCheckModel TransformElement(IDataReader dr, Func<IDataReader, RetentionExceptionStatusCheckModel, RetentionExceptionStatusCheckModel> bindExtraFields = null)
        {
            return new RetentionExceptionStatusCheckModel
            {
                retentiondescription = (dr[RetentionExceptionStatusOutputFields.retentiondescription.ToString()] is DBNull) ? null : dr[RetentionExceptionStatusOutputFields.retentiondescription.ToString()].ToString(),
                createdBy = (dr[RetentionExceptionStatusOutputFields.createdBy.ToString()] is DBNull) ? null : dr[RetentionExceptionStatusOutputFields.createdBy.ToString()].ToString()
            };
        }
    }

    #endregion GeRetentionExceptionStatus

    #region GetEngagementRelatedPersonalStatus

    public enum EngagementRelatedPersonalStatusOutputFields
    {
        ERPCount,
        createdBy
    }

    public class EngagementRelatedPersonalStatusTransformer : BaseTransformer<EngagementRelatedPersonalStatusCheckModel>
    {
        internal override EngagementRelatedPersonalStatusCheckModel TransformElement(IDataReader dr, Func<IDataReader, EngagementRelatedPersonalStatusCheckModel, EngagementRelatedPersonalStatusCheckModel> bindExtraFields = null)
        {
            return new EngagementRelatedPersonalStatusCheckModel
            {
                ERPCount = (dr[EngagementRelatedPersonalStatusOutputFields.ERPCount.ToString()] is DBNull) ? null : dr[EngagementRelatedPersonalStatusOutputFields.ERPCount.ToString()].ToString(),
                createdBy = (dr[EngagementRelatedPersonalStatusOutputFields.createdBy.ToString()] is DBNull) ? null : dr[EngagementRelatedPersonalStatusOutputFields.createdBy.ToString()].ToString()
            };
        }
    }

    #endregion GetEngagementRelatedPersonalStatus

    #region GetPPDNPPDRegion

    public enum ResubmissionApproverListOutputFields
    {
        FirstName,
        LastName,
        RoleID
    }

    public class ResubmissionApproverListTransformer : BaseTransformer<ResubmissionApproverListModel>
    {
        internal override ResubmissionApproverListModel TransformElement(IDataReader dr, Func<IDataReader, ResubmissionApproverListModel, ResubmissionApproverListModel> bindExtraFields = null)
        {
            return new ResubmissionApproverListModel
            {
                FirstName = (dr[ResubmissionApproverListOutputFields.FirstName.ToString()] is DBNull) ? null : dr[ResubmissionApproverListOutputFields.FirstName.ToString()].ToString(),
                LastName = (dr[ResubmissionApproverListOutputFields.LastName.ToString()] is DBNull) ? null : dr[ResubmissionApproverListOutputFields.LastName.ToString()].ToString(),
                RoleID = Convert.ToInt32(dr[ResubmissionApproverListOutputFields.RoleID.ToString()])
            };
        }
    }
    #endregion



    #region Archivehistory
    public enum ArchiveHistoryOutputFields
    {
        Action,
        ArchiveID,
        ArchiveNumber,
        CreatedDate,
        CreatedZoneDate,
        ChangedFrom,
        ChangedTo,
        CreatedBy,
        RoleName,
        ZoneName,
        RowNumber,
        Count,
        ResubmissionReason
    }

    public enum ArchiveHistoryFieldParameter
    {
        [CreateField(Name = "p_ArchiveNumber", Direction = ParameterDirection.Input, Type = DbType.String)]
        ArchiveNumber,
        [CreateField(Name = "p_PageNumber", Direction = ParameterDirection.Input, Type = DbType.Int32)]
        PageNumber,
        [CreateField(Name = "p_PageSize", Direction = ParameterDirection.Input, Type = DbType.Int32)]
        PageSize,
        [CreateField(Name = "p_SortBy", Direction = ParameterDirection.Input, Type = DbType.Int32)]
        SortBy
    }
    public class ArchiveHistoryTransformer : BaseTransformer<ArchiveHistoryModel>
    {
        internal override ArchiveHistoryModel TransformElement(IDataReader dr, Func<IDataReader, ArchiveHistoryModel, ArchiveHistoryModel> bindExtraFields = null)
        {
            return new ArchiveHistoryModel
            {
                Action = (dr[ArchiveHistoryOutputFields.Action.ToString()] is DBNull) ? string.Empty : dr[ArchiveHistoryOutputFields.Action.ToString()].ToString(),
                ArchiveID = (dr[ArchiveHistoryOutputFields.ArchiveID.ToString()] is DBNull) ? 0 : int.Parse(dr[ArchiveHistoryOutputFields.ArchiveID.ToString()].ToString()),
                ArchiveNumber = (dr[ArchiveHistoryOutputFields.ArchiveNumber.ToString()] is DBNull) ? string.Empty : dr[ArchiveHistoryOutputFields.ArchiveNumber.ToString()].ToString(),
                RoleName = (dr[ArchiveHistoryOutputFields.RoleName.ToString()] is DBNull) ? string.Empty : dr[ArchiveHistoryOutputFields.RoleName.ToString()].ToString(),
                ZoneName = (dr[ArchiveHistoryOutputFields.ZoneName.ToString()] is DBNull) ? string.Empty : dr[ArchiveHistoryOutputFields.ZoneName.ToString()].ToString(),
                CreatedDate = (dr[ArchiveHistoryOutputFields.CreatedDate.ToString()] is DBNull) ? string.Empty : dr[ArchiveHistoryOutputFields.CreatedDate.ToString()].ToString(),
                CreatedZoneDate = (dr[ArchiveHistoryOutputFields.CreatedZoneDate.ToString()] is DBNull) ? string.Empty : dr[ArchiveHistoryOutputFields.CreatedZoneDate.ToString()].ToString(),
                CreatedBy = (dr[ArchiveHistoryOutputFields.CreatedBy.ToString()] is DBNull) ? string.Empty : dr[ArchiveHistoryOutputFields.CreatedBy.ToString()].ToString(),
                ChangedFrom = (dr[ArchiveHistoryOutputFields.ChangedFrom.ToString()] is DBNull) ? string.Empty : dr[ArchiveHistoryOutputFields.ChangedFrom.ToString()].ToString(),
                ChangedTo = (dr[ArchiveHistoryOutputFields.ChangedTo.ToString()] is DBNull) ? string.Empty : dr[ArchiveHistoryOutputFields.ChangedTo.ToString()].ToString(),
                RowNumber = (dr[ArchiveHistoryOutputFields.RowNumber.ToString()] is DBNull) ? 0 : int.Parse(dr[ArchiveHistoryOutputFields.RowNumber.ToString()].ToString()),
                Count = (dr[ArchiveHistoryOutputFields.Count.ToString()] is DBNull) ? 0 : int.Parse(dr[ArchiveHistoryOutputFields.Count.ToString()].ToString()),
                ResubmissionReason = (dr[ArchiveHistoryOutputFields.ResubmissionReason.ToString()] is DBNull) ? string.Empty : dr[ArchiveHistoryOutputFields.ResubmissionReason.ToString()].ToString(),
            };
        }
    }
    #endregion Archivehistory


    #region MyArchiveTeamChangeDetailsTransformer

    public enum MyArchiveTeamChangeDetailsOutputFields
    {
        ArchiveStatus,
        TeamChangedBy,
        RolePartner, NewPartnerAlias, NewPartnerName, OldPartnerAlias, OldPartnerName,FormID,
        RoleManager, NewManagerAlias, NewManagerName, OldManagerAlias, OldManagerName,
        RoleFieldSenior, NewFieldSeniorAlias, NewFieldSeniorName, OldFieldSeniorAlias, OldFieldSeniorName,
        RoleAddFieldSenior, NewAddFieldSeniorAlias, NewAddFieldSeniorName, OldAddFieldSeniorAlias, OldAddFieldSeniorName

    }
      public class ArchiveTeamChangeDetailsTransformer : BaseTransformer<ArchiveTeamChangeDetailsModel>
    {
        internal override ArchiveTeamChangeDetailsModel TransformElement(IDataReader dr, Func<IDataReader, ArchiveTeamChangeDetailsModel, ArchiveTeamChangeDetailsModel> bindExtraFields = null)
        {
           // var result = new ArchiveTeamChangeDetailsModel();
            int vArchiveStatus=0;
            string vTeamChangedBy="";
            string vRolePartner="", vNewPartnerAlias="", vNewPartnerName="", vOldPartnerAlias="", vOldPartnerName="";
            string vRoleManager="", vNewManagerAlias="", vNewManagerName="", vOldManagerAlias="", vOldManagerName="";
            string vRoleFieldSenior="", vNewFieldSeniorAlias="", vNewFieldSeniorName="", vOldFieldSeniorAlias="", vOldFieldSeniorName="";
            string vRoleAddFieldSenior = "", vNewAddFieldSeniorAlias = "", vNewAddFieldSeniorName = "", vOldAddFieldSeniorAlias = "", vOldAddFieldSeniorName = "";

            int? vFormID = null;
            while (dr.Read())
            {
                vArchiveStatus = (dr[MyArchiveTeamChangeDetailsOutputFields.ArchiveStatus.ToString()] is DBNull) ? 0 : int.Parse(dr[MyArchiveTeamChangeDetailsOutputFields.ArchiveStatus.ToString()].ToString());
                vTeamChangedBy = (dr[MyArchiveTeamChangeDetailsOutputFields.TeamChangedBy.ToString()] is DBNull) ? string.Empty : dr[MyArchiveTeamChangeDetailsOutputFields.TeamChangedBy.ToString()].ToString();

                if (dr.NextResult())
                {
                    while (dr.Read())
                    {
                        vRolePartner = (dr[MyArchiveTeamChangeDetailsOutputFields.RolePartner.ToString()] is DBNull) ? string.Empty : dr[MyArchiveTeamChangeDetailsOutputFields.RolePartner.ToString()].ToString();
                        vNewPartnerAlias = (dr[MyArchiveTeamChangeDetailsOutputFields.NewPartnerAlias.ToString()] is DBNull) ? string.Empty : dr[MyArchiveTeamChangeDetailsOutputFields.NewPartnerAlias.ToString()].ToString();
                        vNewPartnerName = (dr[MyArchiveTeamChangeDetailsOutputFields.NewPartnerName.ToString()] is DBNull) ? string.Empty : dr[MyArchiveTeamChangeDetailsOutputFields.NewPartnerName.ToString()].ToString();
                        vOldPartnerAlias = (dr[MyArchiveTeamChangeDetailsOutputFields.OldPartnerAlias.ToString()] is DBNull) ? string.Empty : dr[MyArchiveTeamChangeDetailsOutputFields.OldPartnerAlias.ToString()].ToString();
                        vOldPartnerName = (dr[MyArchiveTeamChangeDetailsOutputFields.OldPartnerName.ToString()] is DBNull) ? string.Empty : dr[MyArchiveTeamChangeDetailsOutputFields.OldPartnerName.ToString()].ToString();
                        vFormID = dr[MyArchiveTeamChangeDetailsOutputFields.FormID.ToString()] is DBNull ? 0 : int.Parse(dr[MyArchiveTeamChangeDetailsOutputFields.FormID.ToString()].ToString());
                    }
                }
                if (dr.NextResult())
                {
                    while (dr.Read())
                    {
                        vRoleManager = (dr[MyArchiveTeamChangeDetailsOutputFields.RoleManager.ToString()] is DBNull) ? string.Empty : dr[MyArchiveTeamChangeDetailsOutputFields.RoleManager.ToString()].ToString();
                        vNewManagerAlias = (dr[MyArchiveTeamChangeDetailsOutputFields.NewManagerAlias.ToString()] is DBNull) ? string.Empty : dr[MyArchiveTeamChangeDetailsOutputFields.NewManagerAlias.ToString()].ToString();
                        vNewManagerName = (dr[MyArchiveTeamChangeDetailsOutputFields.NewManagerName.ToString()] is DBNull) ? string.Empty : dr[MyArchiveTeamChangeDetailsOutputFields.NewManagerName.ToString()].ToString();
                        vOldManagerAlias = (dr[MyArchiveTeamChangeDetailsOutputFields.OldManagerAlias.ToString()] is DBNull) ? string.Empty : dr[MyArchiveTeamChangeDetailsOutputFields.OldManagerAlias.ToString()].ToString();
                        vOldManagerName = (dr[MyArchiveTeamChangeDetailsOutputFields.OldManagerName.ToString()] is DBNull) ? string.Empty : dr[MyArchiveTeamChangeDetailsOutputFields.OldManagerName.ToString()].ToString();
                    }
                }

                if (dr.NextResult())
                {
                    while (dr.Read())
                    {
                        vRoleFieldSenior = (dr[MyArchiveTeamChangeDetailsOutputFields.RoleFieldSenior.ToString()] is DBNull) ? string.Empty : dr[MyArchiveTeamChangeDetailsOutputFields.RoleFieldSenior.ToString()].ToString();
                        vNewFieldSeniorAlias = (dr[MyArchiveTeamChangeDetailsOutputFields.NewFieldSeniorAlias.ToString()] is DBNull) ? string.Empty : dr[MyArchiveTeamChangeDetailsOutputFields.NewFieldSeniorAlias.ToString()].ToString();
                        vNewFieldSeniorName = (dr[MyArchiveTeamChangeDetailsOutputFields.NewFieldSeniorName.ToString()] is DBNull) ? string.Empty : dr[MyArchiveTeamChangeDetailsOutputFields.NewFieldSeniorName.ToString()].ToString();
                        vOldFieldSeniorAlias = (dr[MyArchiveTeamChangeDetailsOutputFields.OldFieldSeniorAlias.ToString()] is DBNull) ? string.Empty : dr[MyArchiveTeamChangeDetailsOutputFields.OldFieldSeniorAlias.ToString()].ToString();
                        vOldFieldSeniorName = (dr[MyArchiveTeamChangeDetailsOutputFields.OldFieldSeniorName.ToString()] is DBNull) ? string.Empty : dr[MyArchiveTeamChangeDetailsOutputFields.OldFieldSeniorName.ToString()].ToString();
                    }
                }

                if (dr.NextResult())
                {
                    while (dr.Read())
                    {
                        vRoleAddFieldSenior = (dr[MyArchiveTeamChangeDetailsOutputFields.RoleAddFieldSenior.ToString()] is DBNull) ? string.Empty : dr[MyArchiveTeamChangeDetailsOutputFields.RoleAddFieldSenior.ToString()].ToString();
                        vNewAddFieldSeniorAlias = (dr[MyArchiveTeamChangeDetailsOutputFields.NewAddFieldSeniorAlias.ToString()] is DBNull) ? string.Empty : dr[MyArchiveTeamChangeDetailsOutputFields.NewAddFieldSeniorAlias.ToString()].ToString();
                        vNewAddFieldSeniorName = (dr[MyArchiveTeamChangeDetailsOutputFields.NewAddFieldSeniorName.ToString()] is DBNull) ? string.Empty : dr[MyArchiveTeamChangeDetailsOutputFields.NewAddFieldSeniorName.ToString()].ToString();
                        vOldAddFieldSeniorAlias = (dr[MyArchiveTeamChangeDetailsOutputFields.OldAddFieldSeniorAlias.ToString()] is DBNull) ? string.Empty : dr[MyArchiveTeamChangeDetailsOutputFields.OldAddFieldSeniorAlias.ToString()].ToString();
                        vOldAddFieldSeniorName = (dr[MyArchiveTeamChangeDetailsOutputFields.OldAddFieldSeniorName.ToString()] is DBNull) ? string.Empty : dr[MyArchiveTeamChangeDetailsOutputFields.OldAddFieldSeniorName.ToString()].ToString();
                    }
                }
            }

            if (!dr.IsClosed)
                dr.Close();


            return new ArchiveTeamChangeDetailsModel
            {
                ArchiveStatus = vArchiveStatus,
                RolePartner = vRolePartner,
                NewPartnerAlias = vNewPartnerAlias,
                NewPartnerName = vNewPartnerName,
                OldPartnerAlias = vOldPartnerAlias,
                OldPartnerName = vOldPartnerName,
                RoleManager = vRoleManager,
                NewManagerAlias = vNewManagerAlias,
                NewManagerName = vNewManagerName,
                OldManagerAlias = vOldManagerAlias,
                OldManagerName = vOldManagerName,
                RoleFieldSenior = vRoleFieldSenior,
                NewFieldSeniorAlias = vNewFieldSeniorAlias,
                NewFieldSeniorName = vNewFieldSeniorName,
                OldFieldSeniorAlias = vOldFieldSeniorAlias,
                OldFieldSeniorName = vOldFieldSeniorName,
                TeamChangedBy=vTeamChangedBy,
                FormId = vFormID,
                RoleAddFieldSenior = vRoleAddFieldSenior,
                NewAddFieldSeniorAlias = vNewAddFieldSeniorAlias,
                NewAddFieldSeniorName = vNewAddFieldSeniorName,
                OldAddFieldSeniorAlias = vOldAddFieldSeniorAlias,
                OldAddFieldSeniorName = vOldAddFieldSeniorName
              
            };
        }
    }
    #endregion MyArchiveTeamChangeDetailsTransformer


    public enum LinkedArchiveFieldParameters
    {
        [CreateField(Name = "p_ArchiveNumber", Direction = ParameterDirection.Input, Type = DbType.String)]
        ArchiveNumber,
        [CreateField(Name = "p_CreatedBy", Direction = ParameterDirection.Input, Type = DbType.String)]
        CreatedBy,
        [CreateField(Name = "p_LinkedArchiveNumber", Direction = ParameterDirection.Input, Type = DbType.String)]
        LinkedArchiveNumber,
        [CreateField(Name = "p_InsertOutput", Direction = ParameterDirection.Output, Type = DbType.String)]
        InsertOutput,
        [CreateField(Name = "p_LinkTypeId", Direction = ParameterDirection.Input, Type = DbType.Int32)]
        LinkTypeId,
        [CreateField(Name = "p_OpertaionType", Direction = ParameterDirection.Input, Type = DbType.String)]
        OpertaionType
    }
    public enum GetHoldInfoInputParameter
    {
        [CreateField(Name = "P_HoldId", Direction = ParameterDirection.Input, Type = DbType.Int32)]
        HoldId,
        [CreateField(Name = "P_HoldorArchiveNumber", Direction = ParameterDirection.Input, Type = DbType.String)]
        HoldNumber,
        [CreateField(Name = "ArchiveHoldHistoryId", Direction = ParameterDirection.Input, Type = DbType.String)]
        ArchiveHoldHistoryId
    }
    public enum CreateUpdateHoldInfoParameters
    {
        [CreateField(Name = "p_ArchiveNumber", Direction = ParameterDirection.Input, Type = DbType.String)]
        ArchiveNumber,
        [CreateField(Name = "p_HoldNumber", Direction = ParameterDirection.Input, Type = DbType.String)]
        HoldNumber,
        [CreateField(Name = "p_HoldId", Direction = ParameterDirection.Input, Type = DbType.Int32)]
        HoldId,
        [CreateField(Name = "p_CreatedBy", Direction = ParameterDirection.Input, Type = DbType.String)]
        CreatedBy,
        [CreateField(Name = "p_Result", Direction = ParameterDirection.Output, Type = DbType.Int32)]
        Result
    }
    public enum CreateOrUpdateHoldTransfer
    {
        [CreateField(Name = "p_HoldFileId", Direction = ParameterDirection.Input, Type = DbType.Int32)]
        HoldFileID,
        [CreateField(Name = "p_HoldFileTransferId", Direction = ParameterDirection.Input, Type = DbType.Int32)]
        HoldFileTransferID,
        [CreateField(Name = "p_HoldNumber", Direction = ParameterDirection.Input, Type = DbType.String)]
        HoldNumber,
        [CreateField(Name = "p_HoldFileName", Direction = ParameterDirection.Input, Type = DbType.String)]
        HoldFileName,
        [CreateField(Name = "p_HoldSize", Direction = ParameterDirection.Input, Type = DbType.Int32)]
        HoldFileSize,
        [CreateField(Name = "p_FileUploadStatusCode", Direction = ParameterDirection.Input, Type = DbType.String)]
        FileUploadStatusCode,
        [CreateField(Name = "p_Etag", Direction = ParameterDirection.Input, Type = DbType.String)]
        Etag,
        [CreateField(Name = "p_FailedDescription", Direction = ParameterDirection.Input, Type = DbType.String)]
        FailedDescription,
        [CreateField(Name = "p_UploadId", Direction = ParameterDirection.Input, Type = DbType.String)]
        UploadId,
        [CreateField(Name = "p_CreatedBy", Direction = ParameterDirection.Input, Type = DbType.String)]
        CreatedBy,
        [CreateField(Name = "p_FileTypeId", Direction = ParameterDirection.Input, Type = DbType.Int32)]
        FileTypeId,
        [CreateField(Name = "p_HoldId", Direction = ParameterDirection.Input, Type = DbType.Int32)]
        HoldId,
        [CreateField(Name = "p_HoldFileIdOut", Direction = ParameterDirection.Output, Type = DbType.Int32)]
        HoldFileIdOut,
        [CreateField(Name = "p_HoldFileTransferIdOut", Direction = ParameterDirection.Output, Type = DbType.Int32)]
        HoldFileTransferIdOut,
        [CreateField(Name = "p_ResponseMessageOut", Direction = ParameterDirection.Output, Type = DbType.String)]
        ResponseMessageOut,
        [CreateField(Name = "p_S3FileName", Direction = ParameterDirection.Output, Type = DbType.String)]
        s3FileName


    }
 
    

    public enum DeleteArchiveParameters
    {
        [CreateField(Name = "p_ArchiveNumber", Direction = ParameterDirection.Input, Type = DbType.String)]
        ArchiveNumber,
        [CreateField(Name = "p_CreatedBy", Direction = ParameterDirection.Input, Type = DbType.String)]
        CreatedBy,
        [CreateField(Name = "p_DeleteReason", Direction = ParameterDirection.Input, Type = DbType.String)]
        DeleteReason,
        [CreateField(Name = "p_ActionTypeId", Direction = ParameterDirection.Input, Type = DbType.Int32)]
        ActionTypeId,
        [CreateField(Name = "p_RejectionReason", Direction = ParameterDirection.Input, Type = DbType.String)]
        RejectionReason,
    }

    public enum RMIntegrationParameters
    {
        [CreateField(Name = "p_ArchiveNumber", Direction = ParameterDirection.Input, Type = DbType.String)]
        ArchiveNumber,
        [CreateField(Name = "p_BinderID", Direction = ParameterDirection.Input, Type = DbType.String)]
        BinderID,
        [CreateField(Name = "p_RequestedBy", Direction = ParameterDirection.Input, Type = DbType.String)]
        RequestedBy,
        [CreateField(Name = "p_RequestTypeID", Direction = ParameterDirection.Input, Type = DbType.Int32)]
        RequestTypeID,
        [CreateField(Name = "p_IsBinderOrDeliverable", Direction = ParameterDirection.Input, Type = DbType.Boolean)]
        IsBinderOrDeliverable,
    }
    public class BinderTransformer : BaseTransformer<BindersModel>
    {
        internal override BindersModel TransformElement(IDataReader dr, Func<IDataReader, BindersModel, BindersModel> bindExtraFields = null)
        {
            return new BindersModel
            {
                BinderID = (dr[BindersOutputFields.BinderID.ToString()] is DBNull) ? 0 : int.Parse(dr[BindersOutputFields.BinderID.ToString()].ToString()),
                Description = (dr[BindersOutputFields.Description.ToString()] is DBNull) ? string.Empty : dr[BindersOutputFields.Description.ToString()].ToString(),
                Barcode = (dr[BindersOutputFields.Barcode.ToString()] is DBNull) ? string.Empty : dr[BindersOutputFields.Barcode.ToString()].ToString(),
                PhysicalRecordStatusID = (dr[BindersOutputFields.PhysicalRecordStatusID.ToString()] is DBNull) ? 0 : int.Parse(dr[BindersOutputFields.PhysicalRecordStatusID.ToString()].ToString()),
                PhysicalRecordStatus = (dr[BindersOutputFields.PhysicalRecordStatus.ToString()] is DBNull) ? string.Empty : dr[BindersOutputFields.PhysicalRecordStatus.ToString()].ToString(),
                RowNumber = (dr[BindersOutputFields.RowNumber.ToString()] is DBNull) ? 0 : int.Parse(dr[BindersOutputFields.RowNumber.ToString()].ToString()),
                Count = (dr[BindersOutputFields.Count.ToString()] is DBNull) ? 0 : int.Parse(dr[BindersOutputFields.Count.ToString()].ToString()),
            };
        }

    }
    public enum BindersOutputFields
    {
    BinderID
    , Description
    , Barcode
    , PhysicalRecordStatusID
    , PhysicalRecordStatus
    , RowNumber
    , Count
    }

}


