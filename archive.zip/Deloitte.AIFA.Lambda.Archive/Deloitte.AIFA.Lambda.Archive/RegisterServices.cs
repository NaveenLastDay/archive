﻿using Deloitte.AIFA.CloudServices;
using Deloitte.AIFA.DomainServices;
using Deloitte.AIFA.DomainServices.Contracts;
using Deloitte.AIFA.DomainServices.Services;
using Deloitte.AIFA.EmailNotificationServices;
using Deloitte.AIFA.ICloudServices;
using Deloitte.AIFA.IMessageServices.Contracts;
using Deloitte.AIFA.IMessageServices.Services;
using Deloitte.AIFA.IRepositories;
using Deloitte.AIFA.Lambda.Logging;
using Deloitte.AIFA.Repositories;
using Deloitte.AIFA.Repositories.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace Deloitte.AIFA.Lambda.Archive
{
    public class RegisterServices
    {
        public static void Register(IServiceCollection services, IConfiguration configuration)
        {
            #region Common

            services.AddTransient<IConfigManager, SecretsManagerService>();
            services.AddTransient<ICloudCacheService, CloudCacheService>();
            services.AddSingleton<ILogger, CustomCoreLogger>();
            services.AddLogging(
                logging =>
                {
                    var httpContextAccessor = new HttpContextAccessor();
                    logging.AddConfiguration(configuration.GetSection("Logging"));
                    logging.AddProvider(new CustomLoggerProvider(configuration, httpContextAccessor));
                });

            #endregion Common

            #region Repository

            services.AddTransient<IArchiveRepository, ArchiveRepository>();
            services.AddTransient<IArchiveFolderRepository, ArchiveFolderRepository>();
            services.AddTransient<IUtilityRepository, UtilityRepository>();
            services.AddTransient<IUserRepository, UserRepository>();
            services.AddTransient<IArchiveFlowRepository, ArchiveFlowRepository>();
            services.AddTransient<IERPRepository,ERPRepository>();
            services.AddTransient<IFormRepository, FormRepository>();
            services.AddTransient<IArchiveSearchRepository, ArchiveSearchRepository>();
            services.AddTransient<IRateThisAppRepository, RateThisAppRepository>();
            services.AddTransient<ILinkedArchiveRepository, LinkedArchiveRepository>();
            services.AddTransient<IUserDashBoardRepository, UserDashBoardRepository>();
            #endregion Repository

            #region Service

            services.AddTransient<IArchiveService, ArchiveService>();
            services.AddTransient<IDashBoardService, DashBoardService>();
            services.AddTransient<IArchiveFolderService, ArchiveFolderService>();
            services.AddTransient<IUtilityService, UtilityService>();
            services.AddTransient<IUserService, UserService>();
            services.AddTransient<IArchiveFlowService, ArchiveFlowService>();
            services.AddTransient<IERPService,ERPService>();
            services.AddTransient<IFormService, FormService>();
            services.AddTransient<IArchiveSearchService, ArchiveSearchService>();
            services.AddTransient<IRateThisAppService, RateThisAppService>();
            services.AddTransient<ILinkedArchiveService, LinkedArchiveService>();
            services.AddSingleton<ISQSService>(new SQSService(configuration["Region"], configuration["archievequeueendpoint"]));
            services.AddSingleton<IS3BucketService>(new S3BucketService(configuration["Region"], configuration["storagekmskey"]));
            services.AddTransient<IEmailNotificationService, EmailNotificationService>();
            #endregion Service


        }
    }
}
