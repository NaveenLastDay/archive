import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-archivehome-sidenavbar',
  templateUrl: './archivehome-sidenavbar.component.html',
  styleUrls: ['./archivehome-sidenavbar.component.css']
})
export class ArchivehomeSidenavbarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
