﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
    public class EditArchiveDetails
    {
        public string EngagementDescription { get; set; }
        public DateTime PeriodEndDate { get; set; }
        public string EngagementTypeDescription { get; set; }
        public string EntityTypeDescription { get; set; }
        public string StandardsApplied { get; set; }
        public string ArchiveNameForWBSLevel1Number { get; set; }
        public string AdditionalDescription { get; set; }
        public string EngagementPartner { get; set; }
        public string BusinessName { get; set; }
        public string ServiceArea { get; set; }
    }
}
