﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
    public class ArchiveDeletionAction
    {
        public string ArchiveNumber { get; set; }
        public string DeleteReason  { get; set; }
        public string RejectionReason { get; set; }
        public int ActionTypeID { get; set; }
        public string CreatedBy { get; set; }
    }
}
