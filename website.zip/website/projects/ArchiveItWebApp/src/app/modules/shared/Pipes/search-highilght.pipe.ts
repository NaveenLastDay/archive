import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'searchHighilght'
})
export class SearchHighilghtPipe implements PipeTransform {

  transform(value: string, query: any[]) {
    debugger;
    for(let i=0;i<query.length;i++){
      if (value != undefined && value != "" && value != null && query[i] != undefined && query[i] != "" && query != null)
         return value.toLocaleLowerCase().replace(query[i].toLocaleLowerCase(), `<span class="searchcolor" style="background-color:yellow">${value.substr(value.toLocaleLowerCase().indexOf(query[i].toLocaleLowerCase()),query[i].length)}</span>`)
          //return value.replace(value.substr(value.toLocaleLowerCase().indexOf(query.toLocaleLowerCase()),query.length),`<span class="highlighedTxtColor" style="color:black;font-weight:700">${value.substr(value.toLocaleLowerCase().indexOf(query.toLocaleLowerCase()),query.length)}</span>`);
      else {
          return value;
      }
      debugger;
  }
}
}
