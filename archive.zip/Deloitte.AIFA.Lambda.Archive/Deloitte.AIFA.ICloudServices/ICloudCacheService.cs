﻿using Deloitte.AIFA.DomainEntities;
using System.Collections.Generic;

namespace Deloitte.AIFA.ICloudServices
{
    public interface ICloudCacheService
    {
        bool SetValue(CacheRequestModel request);
        string GetValue(CacheRequestModel request);
        bool RemoveValue(CacheRequestModel request);
        List<CacheRequestModel> GetAll();
    }
}
