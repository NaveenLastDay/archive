import { TestBed } from '@angular/core/testing';

import { Form3283SService } from './form3283-s.service';

describe('Form3283SService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: Form3283SService = TestBed.get(Form3283SService);
    expect(service).toBeTruthy();
  });
});
