﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DataModels
{
	public class DeleteMessagesModel
	{
		public DeleteMessagesModel()
		{
			Entries = new List<DeleteMessageBatchRequestModel>();
		}
		public IList<DeleteMessageBatchRequestModel> Entries { get; set; }
	}
}
