﻿using Amazon.Lambda.Core;
using Deloitte.AIFA.PushMessageSNSHelper;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Reflection;
using System.Security.Claims;

namespace Deloitte.AIFA.Lambda.Logging
{
    public class CustomCoreLogger : ILogger
    {
        public enum LogLevelEnum
        {
            Trace = 0,
            Debug = 1,
            Information = 2,
            Warning = 3,
            Error = 4,
            Critical = 5,
            None = 6
        }

        private static object _lock = new object();
        IHttpContextAccessor _accessor;
        public IConfiguration Configuration { get; set; }
        public CustomCoreLogger(IConfiguration configuration, IHttpContextAccessor accessor)
        {
            Configuration = configuration;
            _accessor = accessor;

        }
        public IDisposable BeginScope<TState>(TState state)
        {
            return new Disposable();
        }

        public bool IsEnabled(LogLevel logLevel)
        {
            var EnableLogging = Environment.GetEnvironmentVariable("EnableLogging");
            if (string.IsNullOrEmpty(EnableLogging))
            {
                EnableLogging = Configuration.GetValue<string>("EnableLogging");
            }
            if (!string.IsNullOrEmpty(EnableLogging) && bool.Parse(EnableLogging))
            {
                return true;
            }
            return false;
        }

        public void Log<TState>(LogLevel logLevel, EventId eventId, TState state, Exception exception, Func<TState, Exception, string> formatter)
        {
            try
            {
                RecordMsg(logLevel, eventId, state, exception, formatter);
            }
            catch (Exception ex)
            {
                RecordMsg(logLevel, eventId, state, exception, formatter);
            }
        }

        private void RecordMsg<TState>(LogLevel logLevel, EventId eventId, TState state, Exception exception, Func<TState, Exception, string> formatter)
        {
            if (!IsEnabled(logLevel))
            {
                return;
            }
            lock (_lock)
            {
                LoggerModel logModel = new LoggerModel();

                if (_accessor != null)
                {
                    if (_accessor.HttpContext != null)
                    {
                        if (_accessor.HttpContext.Request != null)
                        {
                            if (_accessor.HttpContext.Request.Headers != null)
                            {
                                var userIdentity = GetIdentityUser(_accessor.HttpContext.Request.Headers["Authorization"]);
                                if (!string.IsNullOrEmpty(userIdentity))
                                {
                                    logModel.Path = _accessor.HttpContext.Request.Path;
                                    logModel.CorrelationId = _accessor.HttpContext.Request.Headers["X-Amzn-Trace-Id"];
                                    logModel.User = GetIdentityUser(_accessor.HttpContext.Request.Headers["Authorization"]);
                                    logModel.LogLevel = ((LogLevelEnum)logLevel).ToString();
                                    logModel.LogDate = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                                    logModel.Source = Assembly.GetExecutingAssembly().ManifestModule.ToString().Replace(".dll", "");
                                    logModel.Message = $"{ state }";

                                    var jsonLog = JsonConvert.SerializeObject(logModel);

                                    LambdaLogger.Log(jsonLog);
                                    var messageId = PushLogMessageToSNS(jsonLog);
                                    LambdaLogger.Log("SNS Message Id" + messageId);
                                }
                            }
                        }
                    }
                }
            }
        }

        private string PushLogMessageToSNS(string jsonLog)
        {
            LambdaLogger.Log("ENV: errorlogNotifyArn : " + Environment.GetEnvironmentVariable("errorlogNotifyArn"));
            PushMessageSNS obj = new PushMessageSNS("errorlogNotifyArn");
            var messageId = obj.PushMsgtoSNS(jsonLog).Result;
            return messageId;
        }

        private string GetIdentityUser(string token)
        {
            string user = null;

            if (string.IsNullOrEmpty(token)) return null;

            token = token.Substring("bearer ".Length).Trim();
            var jwtHandler = new JwtSecurityTokenHandler();
            var readableToken = jwtHandler.CanReadToken(token);

            if (readableToken != true)
            {
                LambdaLogger.Log("Invalid Token ");
            }
            if (readableToken == true)
            {
                var token_read = jwtHandler.ReadJwtToken(token);

                var claims = token_read.Claims;

                foreach (Claim c in claims)
                {
                    if (c.Type == "upn")
                    {
                        user = c.Value.Split('@')[0].ToString();
                    }
                }
                LambdaLogger.Log("User name : " + user);
            }
            return user;

        }

    }
    class Disposable : IDisposable
    {
        public void Dispose()
        {
        }
    }

}
