﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DataModels
{
    public class ActionItemModel
    {
        public int EntityId { get; set; }
        public int ActionItemId { get; set; }
        public string ActionItemIdentifier { get; set; }
        public string ActionItemAssignedTo { get; set; }
        public string ActionItemAssignedToFullName { get; set; }
        public string ActionItemStatusDescription { get; set; }
        public DateTime? CompletedDate { get; set; }

    }

    public class ActionItemResponseModel
    {
        public bool IsSuccessful { get; set; }
        public DateTime? CompletedDate { get; set; }
        public string ActionItemStatusDescription { get; set; }
        public string ResponseMessage { get; set; }
    }
}
