﻿using Amazon.Lambda.Core;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace Deloitte.AIFA.CloudServices
{
    public class JWTService
    {
        dynamic authorizer;
        public string GetClaimFromJWT(string token)
        {
            string inputAlias = null;
            try
            {

                var jwtHandler = new JwtSecurityTokenHandler();
                var jwtInput = token;
                //string inputAlias = null;
                LambdaLogger.Log("Getting Claims from Token: " + token);

                //Check if readable token (string is in a JWT format)
                var readableToken = jwtHandler.CanReadToken(jwtInput);

                if (readableToken != true)
                {
                    // txtJwtOut.Text = "The token doesn't seem to be in a proper JWT format.";
                    Console.WriteLine("Invalid token");
                    LambdaLogger.Log("Invalid Token: token " + jwtInput);
                }
                if (readableToken == true)
                {
                    var token_read = jwtHandler.ReadJwtToken(jwtInput);

                    var claims = token_read.Claims;
                    //LambdaLogger.Log("Claims: " + ServiceStack.JSON.stringify(claims));

                    foreach (Claim c in claims)
                    {
                        if (c.Type == "upn")
                        {
                            inputAlias = c.Value.Split('@')[0].ToString();
                        }
                    }
                    LambdaLogger.Log("User Alias : " + inputAlias);

                }

            }
            catch (Exception e)
            {
                LambdaLogger.Log("Error iN JWT Service :" + e.Message);
            }
            return inputAlias;

        }

        public void SetAuthorizer(object authorizer)
        {
            this.authorizer = authorizer;
        }

        public object GetAuthorizer()
        {
            return this.authorizer;
        }
    }
}
