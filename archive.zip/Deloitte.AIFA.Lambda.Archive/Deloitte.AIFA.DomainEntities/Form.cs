﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
    public class Form
    {
        public int FormId { get; set; }
        public string ArchivePartner { get; set; }
        public string TypeOfEntity { get; set; }
        public DateTime EDCDDate { get; set; }
        public DateTime RDCDDate { get; set; }
        public DateTime? ProposedADCEDDate { get; set; }
        public string AdditionalDetails { get; set; }
        public string ActionsToBeTaken { get; set; }

        public string FormStatus { get; set; }
        public string RejectionReason { get; set; }
        public string RejectionReasonByFullName { get; set; }
        public DateTime? RejectionReasonDate { get; set; }
        public bool IsApprover { get; set; }
        public bool IsActive { get; set; }
        public bool IsNewFormData { get; set; }
        public string ArchiveDueDateCriteria { get; set;}
        public string DeliverableType {get; set;}
        public DateTime? DateThatDrivesEDCD { get; set; }
        public DateTime? SubmittedDate { get; set; }
        public List<Form3283ReasonType> ReasonTypes { get; set; }
        public List<FormAction> ActionItems { get; set; }

    }
}
