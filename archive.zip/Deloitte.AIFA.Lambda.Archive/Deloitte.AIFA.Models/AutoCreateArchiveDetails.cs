﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DataModels
{
    public class AutoCreateArchiveDetailsModel
    {
        public string ArchiveNumber { get; set; }
        public DateTime EstimatedIssuanceReportDate { get; set; }
        public bool IsArchiveCompleted { get; set; }
        public string Archivepartneralias { get; set; }
        public string ArchivepartnerName { get; set; }
        public string Archivemanageralias { get; set; }
        public string Archivemanagername { get; set; }
        public string WBSLevelOne { get; set; }
        public string WBSLevelOneName { get; set; }
        public string ClientName { get; set; }
    }

}
