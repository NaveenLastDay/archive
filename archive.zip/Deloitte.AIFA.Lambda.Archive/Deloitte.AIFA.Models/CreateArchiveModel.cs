﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DataModels
{
    public class CreateArchiveModel
    {
       
        public string ArchiveNumber { get; set; }
        public string ArchiveName { get; set; }
    }
}
