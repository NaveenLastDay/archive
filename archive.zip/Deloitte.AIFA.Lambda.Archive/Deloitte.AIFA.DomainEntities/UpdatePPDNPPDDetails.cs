﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
    public class UpdatePPDNPPDDetails
    {
        public string ArchiveNumber { get; set; }
        public string CreatedBy { get; set; }
        public string PPDUserAlias { get; set; }
        public int IsPPD { get; set; }
    }
}
