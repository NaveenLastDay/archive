﻿using Amazon.Lambda.Core;
using Deloitte.AIFA.DataModels;
using Deloitte.AIFA.DomainEntities;
using Deloitte.AIFA.DomainServices.Contracts;
using Deloitte.AIFA.ICloudServices;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Deloitte.AIFA.Lambda.Archive.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    
    public class ArchiveMetaDataController : ControllerBase
    {
        IArchiveService _archiveService;
        private readonly IHttpContextAccessor _contextAccessor;
        private string userAlias;
        private readonly IUtilityService _utilityServie;
        private List<RoleFunction> roleFunctions;

        ILogger _logger { get; set; }
        public ArchiveMetaDataController(IHttpContextAccessor contextAccessor, IArchiveService archiveServie, ILogger<ArchiveMetaDataController> logger, ICloudCacheService cloudCacheService, IUtilityService utilityServie)
        {
            _logger = logger;
            _archiveService = archiveServie;
            this._contextAccessor = contextAccessor;
            this._utilityServie = utilityServie;

            _logger.LogInformation("Archive Meta Data Controller Initiated");
            try
            {
                LambdaLogger.Log("Inside Archive Metadata Controller");
                var _context = this._contextAccessor.HttpContext;
                try
                {
                    if (_context?.User?.Claims.Any() == true)
                    {
                        LambdaLogger.Log("Has claims in Archive Metadata Controller");
                        foreach (var claim in _context?.User?.Claims)
                        {
                            //LambdaLogger.Log(claim.Type);
                            if (claim.Type == "UserAlias")
                            {
                                userAlias = claim.Value.Split('@')[0].ToString();
                            }
                            LambdaLogger.Log("User Alias from Archive Metadata Controller," + userAlias);
                        }
                    }
                    else
                    {
                        LambdaLogger.Log("Has No claims");
                    }
                }
                catch (Exception ex)
                {
                    LambdaLogger.Log("Error with Http context in Archive Metadata Controller: " + ex.Message);
                }
            }
            catch (Exception e)
            {
                LambdaLogger.Log("Error in Archive Metadata Controller: " + e.Message);
            }
            try
            {
                CacheRequestModel cacheRequestModel = new CacheRequestModel();

                cacheRequestModel.Key = "RoleFunctions";
                _logger.LogInformation("RoleFunctions Cache RequestModelKey from Archive Metadata Controller : " + System.Web.HttpUtility.HtmlEncode(cacheRequestModel.Key));
                var data = cloudCacheService.GetValue(cacheRequestModel);
                _logger.LogInformation("cacheLog from Archive Metadata Controller :" + System.Web.HttpUtility.HtmlEncode(data));
                if (data == null)
                {
                    roleFunctions = utilityServie.GetRoleFunctions();
                    cacheRequestModel.Value = JsonConvert.SerializeObject(roleFunctions);
                    _logger.LogInformation("RoleFunctions Cache Model Value from Archive Metadata Controller : " + System.Web.HttpUtility.HtmlEncode(JsonConvert.SerializeObject(cacheRequestModel.Value)));
                    var val = cloudCacheService.SetValue(cacheRequestModel);
                    _logger.LogInformation("RoleFunctions Cache Service Response from Archive Metadata Controller : " + System.Web.HttpUtility.HtmlEncode(val.ToString()));
                }
                else
                {
                    roleFunctions = JsonConvert.DeserializeObject<List<RoleFunction>>(data);
                    _logger.LogInformation("RoleFunctions Cache Value from Archive Metadata Controller : " + System.Web.HttpUtility.HtmlEncode(JsonConvert.SerializeObject(roleFunctions)));
                }

            }
            catch (Exception e)
            {
                _logger.LogError("Exception in Cloud Cache Archive Controller: " + e.Message);
            }
        }

        [HttpGet]
        [Route("EngagementType")]
        public IActionResult GetEngagementType()
        {
            var engagements = _archiveService.GetEngagementType();
            _logger.LogInformation("GetEngagementType: ");
            return Ok(engagements);
        }

        [HttpGet]
        [Route("ArchiveTypes")]
        public IActionResult GetArchiveTypes()
        {
            var archiveTypes = _archiveService.GetArchiveType();
            _logger.LogInformation("GetArchiveType: ");
            return Ok(archiveTypes);
        }

        [HttpGet]
        [Route("EntityTypes")]
        public IActionResult GetEntityTypes()
        {
            var entityTypes = _archiveService.GetEntityType();
            _logger.LogInformation("GetEntityType: ");
            return Ok(entityTypes);
        }


        [HttpGet]
        [Route("ProfessionalStandard")]
        public IActionResult GetProfessionalStandard()
        {
            var professionalStandards = _archiveService.GetProfessionalStandard();
            _logger.LogInformation("ProfessionalStandard: ");
            return Ok(professionalStandards);
        }

        [HttpGet]
        [Route("RetentionReasons")]
        public IActionResult GetRetentionReasons(string ArchiveNumber)
        {
            var id = GetFuntionID("Access Archive");
            var isValid = _utilityServie.IsUserAuthorizedtoPerformAction(ArchiveNumber, id, userAlias);
            if (isValid)
            {
             var RetentionReasons = _archiveService.GetRetentionReasons();
            _logger.LogInformation("RetentionReason: ");
            return Ok(RetentionReasons);
            }
            else
            {
                _logger.LogInformation("Unauthorized Request Details: Action: GetRetentionReasons, Object " + System.Web.HttpUtility.HtmlEncode(userAlias));
                return Forbid();
            }
        }

        [HttpGet]
        [Route("GetActiveRoles")]
        public IActionResult GetActiveRoles(string ArchiveNumber)
        {
            var id = GetFuntionID("Access Archive");
            var isValid = _utilityServie.IsUserAuthorizedtoPerformAction(ArchiveNumber, id, userAlias);
            if (isValid)
            {
            var ActiveRoles = _archiveService.GetActiveRoles(ArchiveNumber);
            _logger.LogInformation("ActiveRoles: ");
            return Ok(ActiveRoles);
            }
            else
            {
                _logger.LogInformation("Unauthorized Request Details: Action: GetActiveRoles, Object " + System.Web.HttpUtility.HtmlEncode(userAlias));
                return Forbid();
            }
        }
        [HttpGet]
        [Route("GetActiveRolesForRequestTemporaryAccess")]
        public IActionResult GetActiveRolesForRequestTemporaryAccess(string ArchiveNumber)
        {
            var ActiveRoles = _archiveService.GetActiveRolesForRequestTemporaryAccess(ArchiveNumber);
            _logger.LogInformation("ActiveRoles For Request Temporary Access: ");
            return Ok(ActiveRoles);
        }

        [HttpGet]
        [Route("GetArchiveTeamHistory")]
        public IActionResult GetArchiveTeamHistory(string ArchiveNumber, int PageNumber = 0, int PageSize = 0, int SortBy = 1)
        {
            var id = GetFuntionID("Access Archive");
            var isValid = _utilityServie.IsUserAuthorizedtoPerformAction(ArchiveNumber, id, userAlias);
            if (isValid)
            {
            var archiveteam = _archiveService.GetArchiveTeamHistory(ArchiveNumber, PageNumber, PageSize, SortBy);
            _logger.LogInformation("Archiveteamhistory: ");
            return Ok(archiveteam);
            }
            else
            {
                _logger.LogInformation("Unauthorized Request Details: Action: GetArchiveTeamHistory, Object " + userAlias);
                return Forbid();
            }
        }


        [HttpGet]
        [Route("getswiftengagementinfo")]
        public IActionResult GetSwiftEngagementInfo(string wbsLevelOne, string ArchiveNumber)
        {
            var id = GetFuntionID("Access Archive");
            var isValid = _utilityServie.IsUserAuthorizedtoPerformAction(ArchiveNumber, id, userAlias);
            if (isValid)
            {
                var engagementInfo = _archiveService.GetSwiftEngagementInfo(wbsLevelOne);
            _logger.LogInformation("Swift Engagement Info: ");
            return Ok(engagementInfo);
            }
            else
            {
                _logger.LogInformation("Unauthorized Request Details: Action: GetSwiftEngagementInfo, Object " + System.Web.HttpUtility.HtmlEncode(userAlias));
                return Forbid();
            }
        }


        [HttpGet]
        [Route("getarchiveduedatecriteria")]
        public IActionResult GetArchiveDueDateCriteria(string ArchiveNumber)
        {
            var archiveDueDateInfo = _archiveService.GetArchiveDueDateCriteria(ArchiveNumber, userAlias);
            _logger.LogInformation("Archive Due date : ");
            return Ok(archiveDueDateInfo);
        }

        [HttpGet]
        [Route("GetArchiveDeletionStatus")]
        public IActionResult GetArchiveDeletionStatus(string ArchiveNumber)
        {
            var id = GetFuntionID("Access Archive");
            var isValid = _utilityServie.IsUserAuthorizedtoPerformAction(ArchiveNumber, id, userAlias);
            if (isValid)
            {
                var deletionstatus = _archiveService.GetArchiveDeletionStatus(ArchiveNumber);
            _logger.LogInformation("Archive deletion status: ");
            return Ok(deletionstatus);
            }
            else
            {
                _logger.LogInformation("Unauthorized Request Details: Action: GetArchiveDeletionStatus, Object " + System.Web.HttpUtility.HtmlEncode(userAlias));
                return Forbid();
            }
        }
        private int GetFuntionID(string functionName)
        {
            LambdaLogger.Log("cacheLog43234432:" + functionName);
            _logger.LogInformation("cacheLog12798778:" + System.Web.HttpUtility.HtmlEncode(functionName));
            var Id = roleFunctions.Where(e => e.FunctionName == functionName).Select(x => x.Id).FirstOrDefault();
            _logger.LogInformation("functionId: " + System.Web.HttpUtility.HtmlEncode(Id.ToString()));
            return Id;
        }

    }
}