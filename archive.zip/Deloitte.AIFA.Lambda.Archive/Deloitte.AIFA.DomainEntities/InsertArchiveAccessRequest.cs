﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
    public class InsertArchiveAccessRequest
    {
        public string Message { get; set; }
        public string RequestedByName { get; set; }
        public string RequestedOfName { get; set; }
    }
}
