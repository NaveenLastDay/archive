import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { DestructionService } from '../../../../../services/destruction.service';
import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { NgxSpinnerService } from 'ngx-spinner';
import { NotifierService, NotifierModule, NotifierOptions } from "angular-notifier";
import { FormControl, FormGroup, FormBuilder, Validators, FormArray,NgForm, Form } from '@angular/forms';
import { ModalService } from "../../../../shared/modal";
import { UserConfigSettingService } from '../../../../../guards/user-role-guard.service';
import { SharedService } from '../../../../../services/shared.service';
import { NgbCalendar, NgbDate } from '@ng-bootstrap/ng-bootstrap';
import { DestructionProcessRouteComponent } from './destruction-process-route.component';

describe('DestructionProcessRouteComponent', () => {
  let component: DestructionProcessRouteComponent;
  let fixture: ComponentFixture<DestructionProcessRouteComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DestructionProcessRouteComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DestructionProcessRouteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
