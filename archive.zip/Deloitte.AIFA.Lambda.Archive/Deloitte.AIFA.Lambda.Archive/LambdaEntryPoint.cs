using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using System.IO;
using Microsoft.AspNetCore.Hosting.Internal;
using Amazon.Lambda.APIGatewayEvents;
using Amazon.Lambda.Core;
using System.Security.Claims;
using Deloitte.AIFA.CloudServices;
using Deloitte.AIFA.DomainServices.Common;

namespace Deloitte.AIFA.Lambda.Archive
{
    /// <summary>
    /// This class extends from APIGatewayProxyFunction which contains the method FunctionHandlerAsync which is the 
    /// actual Lambda function entry point. The Lambda handler field should be set to
    /// 
    /// Deloitte.AIFA.Lambda.Archive::Deloitte.AIFA.Lambda.Archive.LambdaEntryPoint::FunctionHandlerAsync
    /// </summary>
    public class LambdaEntryPoint :
        // When using an ELB's Application Load Balancer as the event source change 
        // the base class to Amazon.Lambda.AspNetCoreServer.ApplicationLoadBalancerFunction
        Amazon.Lambda.AspNetCoreServer.APIGatewayProxyFunction
    {
        /// <summary>
        /// The builder has configuration, logging and Amazon API Gateway already configured. The startup class
        /// needs to be configured in this method using the UseStartup<>() method.
        /// </summary>
        /// <param name="builder"></param>
        protected override void Init(IWebHostBuilder builder)
        {
            builder
                .UseStartup<Startup>();
        }

        protected override void PostCreateContext(
        HostingApplication.Context context,
        APIGatewayProxyRequest apiGatewayRequest, ILambdaContext lambdaContext)
        {
            // handling output from cognito user pool authorizer
            //if (apiGatewayRequest?.RequestContext?.Authorizer?.Claims != null)
            //{
            //    var identity = new ClaimsIdentity(apiGatewayRequest.RequestContext.Authorizer.Claims.Select(
            //        entry => new Claim(entry.Key, entry.Value.ToString())), "AuthorizerIdentity");

            //    context.HttpContext.User = new ClaimsPrincipal(identity);
            //    return;
            //}

            // handling output from lambda authorizer
            
            try
            {
                if (apiGatewayRequest?.RequestContext?.Authorizer != null)
                {
                    LambdaLogger.Log("Logging from PostCreateContext");
                    //foreach (var key in apiGatewayRequest.RequestContext.Authorizer)
                    //{
                    //    LambdaLogger.Log(key.Key);
                    //    LambdaLogger.Log(key.Value?.ToString());

                    //}
                    var identity = new ClaimsIdentity(apiGatewayRequest.RequestContext.Authorizer.Select(
                        entry => new Claim(entry.Key, entry.Value.ToString())), "AuthorizerIdentity");

                    context.HttpContext.User = new ClaimsPrincipal(identity);
                }

                Temp.IsMigrationTest = context.HttpContext.Request.Headers["env"] == "env2";

            }
            catch (Exception e)
            {
                LambdaLogger.Log("Logging from PostCreateContext error");
                LambdaLogger.Log(e.Message);
            }
            //LambdaLogger.Log("Log from Lambda Entry Point Authorizer" + ServiceStack.JSON.stringify(apiGatewayRequest.RequestContext.Authorizer));
        }

    }
}
