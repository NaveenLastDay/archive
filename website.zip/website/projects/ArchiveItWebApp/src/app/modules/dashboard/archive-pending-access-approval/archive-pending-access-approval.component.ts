import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { UserConfigSettingService } from '../../../guards/user-role-guard.service';
import { ArchiveService } from '../../../services/archive.service';
// import { NgxSpinnerService } from 'ngx-spinner';
import { NotifierService, NotifierModule, NotifierOptions } from "angular-notifier";
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { TrimSummaryLengthPipe } from '../../shared/Pipes/trim-summary-length.pipe';
import * as FileSaver from 'file-saver';
import * as Excel from "exceljs/dist/exceljs.min.js";
import * as ExcelProper from "exceljs";
import { Workbook } from 'exceljs';
import { HomePageService } from '../../../services/homepage.service';
import { SharedService } from '../../../services/shared.service';

@Component({
  selector: 'app-archive-pending-access-approval',
  templateUrl: './archive-pending-access-approval.component.html',
  styleUrls: ['./archive-pending-access-approval.component.css']
})
export class ArchivePendingAccessApprovalComponent implements OnInit {
  totalArchivesAssigned: number = 0;
  currentUrl: string;
  employeeUniqueIdentifier: string;
  sortByEnum: any = MyArchivesSortBy;
  filterByEnum: any = MyArchivesFilterBy;
  sortBy: number = this.sortByEnum.SortBy_ArchiveName_Asc;
  filterBy: number = this.filterByEnum.FilterBy_ArchiveType;
  filterText: string = "";
  displayingRecordsFrom: number = 0;
  displayingRecordsTo: number = 0;
  userConfig: any;
  myArchives: any[];
  currentPageNumber: number = 1;
  totalArchives: number = 0;
  pageSize: number = 10;
  archiveNumber: string = '';
  eventType: string = '';
  hoverIndex: number = -1;
  pageCount: number = 10;
  appendArchiveToGrid: boolean = false;
  archives: any[];
  pageArray = Array();
  archiveAccessRequestsForApprovalData: any;
  archiveIDForChild: any;
  exportExcelData: any;
  archiveAccessRequestID: string;
  countForAccessRequests: any;
  headerColumns: any = [];
  redColor: any;
  orangeColor: any;
  yellowColor: any;
  accessRequestData: any;


  constructor(private archiveService: ArchiveService,private homePageService: HomePageService, private adalSvc: MsAdalAngular6Service,
    private sharedService: SharedService, private notifier: NotifierService, private router: Router) {
      // this.SpinnerService.show();
  }

  ngOnInit() {
    this.employeeUniqueIdentifier = this.adalSvc.LoggedInUserEmail.split('@')[0];   
    this.getArchives();
    this.employeeUniqueIdentifier = this.adalSvc.LoggedInUserEmail.split('@')[0];
    // this.homePageService.GetArchiveAccessRequestCountForApproval(this.employeeUniqueIdentifier).subscribe((data) => {
    //   this.countForAccessRequests = data;
    //   if( this.countForAccessRequests.length == 0) {
    //     this.disableBack();
    //   }
    // });
    // this.homePageService.GetArchiveAccessRequestCountForDashboard().subscribe((data) => {
    //   data.complianceMetricsForUser.forEach((ele) => {
    //     if(ele.category == "AccessRequests") {
    //       if(ele.count == 0) {
    //         this.disableBack();
    //       }
    //     }
    //   })
    // });
  }

  showArchiveDetails(archiveAccessRequestID, index) {
    if (this.archiveAccessRequestID == archiveAccessRequestID) {
      this.archiveAccessRequestID = '';
    }
    else {
      this.archiveAccessRequestID = archiveAccessRequestID;
    }
  }
  getArchives() {
    this.archiveService.GetArchiveAccessRequestsForApproval(this.currentPageNumber, this.pageSize).subscribe(
      data => {
        this.accessRequestData = data;
        // this.redColor = data.filter((ele) => ele.due == 'Red');
        // this.orangeColor = data.filter((ele) => ele.due == 'Orange');
        // this.yellowColor = data.filter((ele) => ele.due == 'Yellow');
        if(this.accessRequestData.length > 0) {
        this.redColor = data[0].countRed;
        this.orangeColor = data[0].countOrange;
        this.yellowColor = data[0].countYellow;
        }
        if (this.appendArchiveToGrid && data) {
          this.archives = this.archives.concat(data);
        }
        else {
          this.archives = data ? data : [];
        }
        if(this.accessRequestData.length > 0) {
        this.totalArchives = this.archives[0]["count"];
      }
        console.log('array length', this.totalArchives);
        // this.SpinnerService.hide();
      }
    );
  }
    disableBack() {
    window.history.forward();
  }
  exportToExcel() {
    // this.SpinnerService.show();
            let columns = [
          'Archive #',
          'Client',
          'Archive Name',
          'Period End',
          'WBS #',
          'Archive Status',
          'Requestor Name',
          'Engagement Type',
          'EDCD',
          'RDCD',
          'Is Resubmission in Progress ?',
          'Archive Description',
          'Entity associated with archive',
          'Professional Standards Applied',
          'Reporting Entity',
          'Archive Partner',
          'Archive Manager',
          'Archive Field Senior',
          'Additional Archive Field Senior',
      ];
    this.archiveService.ExportToExcel(0, this.totalArchives).subscribe((data) => {
          data.forEach(elm=> {
        delete elm.count;
        delete elm.rowNumber;
        delete elm.due;
        delete elm.isArchiveCompleted;
      });
      // this.SpinnerService.hide();
      var result = data.map(o => Object.keys(o).map(k => o[k]));
      if (data && data.length) {
        this.sharedService.generateExcel("Access requests", "Access requests", columns,result);
      }
     },
     error => {
       console.log('Exception occured ' + JSON.stringify(error));
      //  this.SpinnerService.hide();
     });
   
  } 


  // exportToExcel() {   
  //   this.SpinnerService.show();
  //   this.archiveService.ExportToExcel(this.employeeUniqueIdentifier, this.currentPageNumber, this.totalArchives).subscribe((data) => {
  //     data.forEach(elm=> {
  //       delete elm.count;
  //       delete elm.rowNumber;
  //       delete elm.due;
  //     });
  //      var headerData = ['Archive #','Client','Archive Name','Period End','WBS #','Archive Status','Requestor Name','Engagement Type','EDCD','RDCD','Is Resubmission in Progress ?','Archive Description','Type Of Entity','Professional Standards Applied','Reporting Entity','Archive Partner','Archive Manager','Archive Field Senior','Additional Archive Field Senior']
  //       var result = data.map(o => Object.keys(o).map(k => o[k]));
  //       const title = 'ArchiveAccessDetails';
  //       let workbook = new Workbook();
  //       let worksheet = workbook.addWorksheet('ArchiveAccessDetails');
    
  //       let headerRow = worksheet.addRow(headerData);
  //       headerRow.eachCell((cell, number) => {
  //         cell.font = { bold: true },
  //           cell.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } }
  //       });
  //       data.forEach(d => {
  //         let row = worksheet.addRow(Object.values(d));
  //         row.alignment = { vertical: 'top', horizontal: 'left', wrapText: true };
  //         row.eachCell(
  //           cell => {
  //             cell.border = {
  //               top: { style: 'thin' },
  //               left: { style: 'thin' },
  //               bottom: { style: 'thin' },
  //               right: { style: 'thin' }
  //             };
  //             cell.alignment = {
  //               vertical: 'top',
  //               horizontal: 'left',
  //               wrapText: true
  //             }
  //           }
  //         )
  //       });
  //       worksheet.columns = [
  //         { header: headerData[0], key: 'Archive #', width: headerData[0].length+1 },
  //         { header: headerData[1], key: 'Client', width: headerData[1].length+15 },
  //         { header: headerData[2], key: 'Archive Name', width: headerData[2].length+5 },
  //         { header: headerData[3], key: 'Period End', width: headerData[3].length+3 },
  //         { header: headerData[4], key: 'WBS #', width: headerData[4].length+8 },
  //         { header: headerData[5], key: 'Archive Status', width: headerData[5].length+8 },
  //         { header: headerData[6], key: 'Requestor Name', width: headerData[6].length+5 },
  //         { header: headerData[7], key: 'Engagement Type', width: headerData[7].length+5 },
  //         { header: headerData[8], key: 'EDCD', width: headerData[8].length+8 },
  //         { header: headerData[8], key: 'RDCD', width: headerData[8].length+8 },
  //         { header: headerData[9], key: 'Is Resubmission in Progress ?', width: headerData[9].length+1 },
  //         { header: headerData[10], key: 'Archive Description', width: headerData[10].length+5 },
  //         { header: headerData[11], key: 'Type Of Entity', width: headerData[11].length+5 },
  //         { header: headerData[12], key: 'Professional Standards Applied', width: headerData[12].length+1 },
  //         { header: headerData[13], key: 'Reporting Entity', width: headerData[13].length+1 },
  //         { header: headerData[14], key: 'Archive Partner', width: headerData[14].length+5 },
  //         { header: headerData[15], key: 'Archive Manager', width: headerData[15].length+5 },
  //         { header: headerData[16], key: 'Archive Field Senior', width: headerData[16].length+5 },
  //         { header: headerData[17], key: 'Additional Archive Field Senior', width: headerData[17].length+3 },
  //     ];
  //       workbook.xlsx.writeBuffer().then((result) => {
  //         let blob = new Blob([result], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  //         FileSaver.saveAs(blob, 'ArchiveAccessDetails.xlsx');
  //       });
  //     this.SpinnerService.hide();
  //   });
  // }

  clearPageCount() {
    this.currentPageNumber = 1;
    this.pageCount = 1;
    this.pageArray = Array();
  }
// openPendingAccess(archiveNumber) {
//   this.router.navigate(['/dashboard/dashboardHome/temporaryAccess/'+archiveNumber]);
// }
openPendingAccessParent(archiveNumber,accessRequestid) {
  this.archiveService.SetArchiveIdChildVal(accessRequestid);
  setTimeout(() => {
    this.router.navigate(['/dashboard/dashboardHome/temporaryAccess/'+archiveNumber]);
  },50);
}
  // accessArchive(archiveNumber: string) {
  //   this.router.navigate(['/archive/myarchives', archiveNumber]);
  // }

  updateGridData(event) {
    this.appendArchiveToGrid = event.isLoadMoreClicked;
    this.currentPageNumber = event.pageNumber;
    this.getArchives();
  }
  archiveID(event) {
    this.archiveIDForChild = event;
    console.log('from child', event);
  }

}

export enum MyArchivesSortBy {
  SortBy_EmployeeLastArchive = 1,
  SortBy_ArchiveName_Asc = 2,
  SortBy_ArchiveName_Desc = 3,
  SortBy_ClientName_Asc = 4,
  SortBy_ClientName_Desc = 5,
  SortBy_PeriodEnd_Asc = 6,
  SortBy_PeriodEnd_Desc = 7,
  SortBy_ArchiveStatus_Asc = 8,
  SortBy_ArchiveStatus_Desc = 9,
  SortBy_WBSNumber_Asc = 10,
  SortBy_WBSNumber_Desc = 11,
  SortBy_ArchiveNumber_Asc = 12,
  SortBy_ArchiveNumber_Desc = 13,
}

export enum MyArchivesFilterBy {
  FilterBy_Business = 1,
  FilterBy_ClientName = 2,
  FilterBy_WBS = 3,
  FilterBy_Status = 4,
  FilterBy_ArchiveType = 5,
}
