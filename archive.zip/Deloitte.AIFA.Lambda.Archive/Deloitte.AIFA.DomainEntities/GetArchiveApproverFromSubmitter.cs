﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
    public class GetArchiveApproverFromSubmitter
    {
        public bool CanApprove { get; set; }
        public string LoggedInUserAlias { get; set; }
        public string ArchiveSubmitter { get; set; }
    }
}
