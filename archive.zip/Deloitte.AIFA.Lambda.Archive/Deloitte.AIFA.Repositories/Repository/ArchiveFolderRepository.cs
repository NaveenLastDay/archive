﻿using Deloitte.AIFA.DomainEntities;
using Deloitte.AIFA.IRepositories;
using Deloitte.AIFA.Models;
using Deloitte.AIFA.Repositories.Transformers;
using Microsoft.Extensions.Caching.Memory;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Deloitte.AIFA.Repositories
{
    public class ArchiveFolderRepository : BaseRepository<ArchiveField>, IArchiveFolderRepository
    {
        IMemoryCache _cache;
        public ArchiveFolderRepository(IMemoryCache cache) : base(cache)
        {
            _cache = cache;
        }

        public List<ArchiveFolder> GetArchiveFolders(ArchiveFolder archiveFolder)
        {
            try
            {
                var parameters = Builder.Bind(ArchiveFolderFieldParameter.ArchiveId).On(archiveFolder.ArchiveId)
                                        .Bind(ArchiveFolderFieldParameter.ArchiveFolderId).On(archiveFolder.ArchiveFolderId)
                                 .Build();
                var result =  DbHelper.ExecuteReader(
                    "pub_GetArchiveFolders",
                    parameters,
                        dr => new ArchiveFolderTransformer().Transform(dr).ToList());
               
                return _mapper.Map<List<ArchiveFolderModel>, List<ArchiveFolder>>(result); 
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
