﻿using Deloitte.AIFA.Helpers.ExcelGenerator;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace Deloitte.AIFA.DataModels
{
    public class ArchiveAccessRequestDetailsModel
    {
        [ReportColumn(20, typeof(string))]
        [DisplayName("Archive Number")]
        public string ArchiveNumber { get; set; }

        [ReportColumn(45, typeof(string))]
        [DisplayName("Client")]
        public string ClientName { get; set; }

        [ReportColumn(50, typeof(string))]
        [DisplayName("Archive Name")]
        public string EngagementDescription { get; set; }

        [ReportColumn(25, typeof(string))]
        [DisplayName("Period End")]
        public string PeriodEndDate { get; set; }

        [ReportColumn(25, typeof(string))]
        [DisplayName("WBS Number")]
        public string WBSLevelOneNumber { get; set; }

        public string ArchiveStatus { get; set; }


        [ReportColumn(40, typeof(string))]
        [DisplayName("Requestor Name")]
        public string RequestorName { get; set; }

        [ReportColumn(50, typeof(string))]
        [DisplayName("Engagement Type")]
        public string EngagementTypeDescription { get; set; }

        [ReportColumn(25, typeof(string))]
        [DisplayName("EDCD")]
        public string EstimatedIssuanceReportDate { get; set; }

        [ReportColumn(25, typeof(string))]
        [DisplayName("RDCD")]
        public string ArchiveDueDate { get; set; }

        [ReportColumn(15, typeof(string))]
        [DisplayName("Is Resubmission in Progress")]
        public string IsResubmissionInProgress { get; set; }

        [ReportColumn(25, typeof(string))]
        [DisplayName("Archive Description")]
        public string Description { get; set; }

        [ReportColumn(35, typeof(string))]
        [DisplayName("Type Of Entity")]
        public string EntityTypeDescription { get; set; }

        [ReportColumn(15, typeof(string))]
        [DisplayName("Professional Standards Applied")]
        public string ProfessionalStandardDescription { get; set; }

        [ReportColumn(15, typeof(string))]
        [DisplayName("Reporting Entity")]
        public string ReportingEntity { get; set; }

        [ReportColumn(15, typeof(string))]
        [DisplayName("Archive Partner")]
        public string ArchivePartner { get; set; }

        [ReportColumn(15, typeof(string))]
        [DisplayName("Archive Manager")]
        public string ArchiveManager { get; set; }

        [ReportColumn(15, typeof(string))]
        [DisplayName("Archive Field Senior")]
        public string ArchiveFieldSenior { get; set; }

        [ReportColumn(15, typeof(string))]
        [DisplayName("Additional Archive Field Senior")]
        public string AddArchiveFieldSenior { get; set; }
        public string Due { get; set; }
        public int RowNumber { get; set; }
        public int Count { get; set; }
    }
}
