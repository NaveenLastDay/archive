﻿using Deloitte.AIFA.DomainEntities;
using Deloitte.AIFA.DomainEntities.Report;
using Deloitte.AIFA.Models;
using System;
using System.Collections.Generic;


namespace Deloitte.AIFA.IRepositories
{
	public interface IArchiveRepository
	{
		Archive GetArchiveDetail(int ArchiveId);

		List<EngagementType> GetEngagementType();
		List<ActiveRoles> GetActiveRoles(string ArchiveNumber);
		List<ActiveRoles> GetActiveRolesForRequestTemporaryAccess(string ArchiveNumber);

		List<ArchiveTeamHistory> GetArchiveTeamHistory(string ArchiveNumber, int PageNumber, int PageSize, int SortBy);
		List<ArchiveType> GetArchiveType();

		List<EntityType> GetEntityType();

		List<ProfessionalStandards> GetProfessionalStandard();
		List<RetentionReason> GetRetentionReasons();

		string CreateArchiveRetention(ArchiveRetention archiveRetention);

		string CreateArchiveLegalHold(ArchiveLegalHold archiveLegalHold);

		List<ArchiveAccessRequestDetails> GetArchiveAccessRequestsDetailsReport(string employeeUniqueIdentifier, int pageNumber, int pageSize);

		List<MyForm3283Data> GetForm3283RequestDetailsToExportToExcel(string employeeUniqueIdentifier, int pageNumber, int pageSize);

		List<MyPendingSubmissionData> GetMyPendingSubmissionDashBoardDataToExcel(string employeeUniqueIdentifier, int pageNumber, int pageSize);

		List<ArchiveSearchBase> GetWBSSerchResults(string term, int rowcount);

		WBSDetails GetWBSDetails(string wbsLevelOne);

		Archive CreateArchive(Archive createArchiveRequest);
		//List<MyArchive> GetMyArchives(int PersonnelNumber, int PageNumber, int PageSize, string SortDirection, string OrderBy, string Search);
		List<MyArchive> GetMyArchives(string employeeUniqueIdentifier, int pageNumber, int pageSize, int sortBy, int filterBy, string filterText);

		List<ArchiveAccessRequestForApproval> GetArchiveAccessRequestsForApproval(string employeeUniqueIdentifier, int pageNumber, int pageSize);
		ArchiveAccessRequestDetailsReport GetArchiveAccessRequestDetailsReport(string employeeUniqueIdentifier, int pageNumber, int pageSize);

		MyArchiveDetails GetMyArchiveDetails(string archiveNumber);
		List<ExistingArchivesInfo> GetExistingArchivesDetails(string wbsLevelOne, string userAlias, int PageNumber, int PageSize);
		ProjectMetaData GetSwiftEngagementInfo(string wbsLevelOne);

		EditArchiveDetails GetEditArchiveDetails(string archiveNumber);
		AutoCreateArchiveDetails GetAutoCreateArchiveDetails(string archiveNumber);

		string UpdateArchiveDetails(UpdateArchive updateArchive);

		ArchiveDetails GetArchiveDetailsInfo(string archiveNumber, string employeeUniqueIdentifier);

		int GetMatRoiUpdates(string archiveNumber);

        ArchiveTeamChangeDetailsData UpdateArchiveTeam(ArchiveTeam archiveTeam, string argUserAlias);


        List<MyArchivesFilterData> GetMyArchivesFilterDataByType(string employeeUniqueIdentifier, int filterBy);

		void LogMessageId(string messageId);

		ArchiveSubmission CreateArchiveSubmission(ArchiveSubmission archiveSubmission);

		ArchiveRetentionDetails GetArchiveRetentionDetails(string archiveNumber);

		string UpdateEstimatedReleaseDate(string ArchiveNumber, DateTime EstimatedReleaseDate);

		string SubtantiveResubmissionUpdatePPDorNPPD(string ArchiveNumber, string CreatedBy, string PPDUserAlias, int IsPPD);


		ArchiveSubmissionStatus GetDateAndPeoplePickerStatus(string archiveNumber, string userAlias);

		LinkedArchivesStatus GetLinkedArchiveStatus(string archiveNumber, string userAlias);

		WorkingPapersStatus GetWorkingPapersStatus(string archiveNumber, string userAlias);
		DeliverablesStatus GetDeliverablesStatus(string archiveNumber, string userAlias);
		RetentionExceptionStatus GetRetentionExceptionStatus(string archiveNumber, string userAlias);

		IList<ArchiveAction> GetArchiveActions(string archiveNumber);

		EngagementRelatedPersonalStatus GetEngagementRelatedPersonalStatus(string archiveNumber);

		IList<ArchiveAtcionsForIndividualSections> GetArchiveAtcionsForIndividualSections(string archiveNumber);

		EarlyTerminationCeasedDate AddEarlyTerminationDate(EarlyTerminationCeasedDate earlyTerminationValues);
		EarlyTerminationCeasedDate getEarlyTerminationDate(EarlyTerminationCeasedDate fetchEarlyTerminationValues);


		RequestCountForApproval GetArchiveAccessRequestCountForApproval(string EmployeeUniqueIdentifier);
		RequestCountForApproval GetForm3283sCountForApproval(string EmployeeUniqueIdentifier);
		string InsertTempArciveTeam(TemporaryArchiveTeam archiveTeam);
		InsertArchiveAccessRequest CreateTempArchiveAccessRequest(RequestTemporaryArchiveAccess requestAccess);
		FormStatus GetFormStatus(string archiveNumber, int timeOffset = 0);
		string GrantDenyTempArchiveAccessRequest(GrantDenyTemporaryArchiveAccess argGrantDenyAccess);
		Object GetTemporaryArchiveAccessRequest(GrantDenyTemporaryArchiveAccess argGrantDenyAccess);
		ArchiveDueDateEngine GetArchiveDueDateCriteria(string ArchiveNumber, string UserAlias);
		List<ArchiveDeletionStatus> GetArchiveDeletionStatus(string ArchiveNumber);
		string ArchiveResubmissionOpen(ArchiveSubmission archiveSubmission);

		List<ResubmissionApprover> GetResubmissionApproverDetails(string ArchiveNumber, string UserAlias);
		(string successMessage, string archiveStatus, string officeZoneName) InsertResubmissionApprover(string UserAlias, string ArchiveNumber, int? RoleID);
		List<ResubmissionApproverList> SubtantiveResubmissionGetPPDorNPPD(string ArchiveNumber);
		string GetUserAlias(string employeeUniqueIdentifier);
		Memo CreateOrUpdateMemo(Memo memoModel);

		List<ResubmissionReason> GetResubmissionReasons();
		List<Memo> GetUploadedMemo(string ArchiveNumber);
		string DeleteUploadedMemo(string ArchiveFileID, string userAlias);
		string InsertUpdateArchiveSubmissionFlow(string ArchiveNumber, string UserAlias);
		GetArchiveApproverFromSubmitter GetArchiveApproverforArchiveSubmission(string ArchiveNumber, string UserAlias, int RoleID);
		GetArchiveApproverFromSubmitter CheckAPSubmitterInactive(string ArchiveNumber, string UserAlias, int CheckType);
		IList<string> GetROINumbers(string archiveNumber);
		bool UpdateRoiFilePath(string archiveNumber, string roiNumber, string eTag, long fileTransferId, string s3FilePath, string createdBy);
		string UpdateFirstLevelResubmissionApprovalFlagSet(string UserAlias, string ArchiveNumber);


		List<ArchiveHistory> GetArchiveHistory(string ArchiveNumber, int PageNumber, int PageSize, int SortBy);
        List<MyPendingSubmissionData> GetMyRequiringApprovalDashBoardDataToExcel(object employeeUniqueIdentifier, object pageNumber, object pageSize);
        List<MyPendingSubmissionData> GetMyAwaitingApprovalDashBoardDataToExcel(string userAlias, int pageNumber, int pageSize);
		List<MyPendingSubmissionData> GetDeletionRequestsDashBoardDataToExcel(string userAlias, int pageNumber, int pageSize);

		string DeleteArchive(ArchiveDeletionAction deletionrequest);
		List<AppliedArchiveHoldsInformation> ApplyArchiveHolds(ApplyArchiveHolds applyArchiveHolds);

		List<HoldHistoryDetails> GetHoldHistoryDetails(int HoldId,string HoldNumber, int ArchiveHoldHistoryId);

		List<HoldDetailsMetadata> GetArchivesAssociatedtoHolds(string HoldNumber, int BusinessId, string ClientId, string FilterText, int SortBy);
		OmniaArchiveSubmissionStatus CheckOmniaSubmissionAllowed(string archiveNumber);
        List<Binders> GetBinderDetails(string archiveNumber, int pageNumber, int pageSize, int sortBy);

		string CreateRequestImageAction(RMIntegrationActions requestImage);
		string RemoveArchiveFromHold(int HoldId, string ArchiveNumber, string userAlias);
		string RemoveHoldFromArchive(string ArchiveNumber,string HoldNumber, string userAlias);
		List<AppliedArchiveHoldsInformation> GetArchivesForApplyingHold(string searchBy, string searchByValue, string includeOrExclude, string holdName, string business, string periodStart, string periodEnd, string sortBy, string sortOrder, int pageNumber, int pageSize);
    }
  
}

