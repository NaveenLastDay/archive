import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ArchivesAwaitingApprovalComponent } from './archives-awaiting-approval.component';

describe('ArchivesAwaitingApprovalComponent', () => {
  let component: ArchivesAwaitingApprovalComponent;
  let fixture: ComponentFixture<ArchivesAwaitingApprovalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ArchivesAwaitingApprovalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ArchivesAwaitingApprovalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
