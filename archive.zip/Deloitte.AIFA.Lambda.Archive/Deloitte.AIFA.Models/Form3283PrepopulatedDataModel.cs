﻿using System;
using System.Collections.Generic;
using System.Text;


namespace Deloitte.AIFA.DataModels
{
    public class Form3283PrepopulatedDataModel
    {
        public List<FormModel> Forms { get; set; }
        public List<Form3283ReasonTypeModel> ReasonTypes { get; set; }
        public List<FormActionModel> FormActions { get; set; }
    }
}
