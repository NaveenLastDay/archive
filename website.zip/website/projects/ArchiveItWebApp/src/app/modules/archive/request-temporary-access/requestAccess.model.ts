export class RequestTemporaryArchiveAccess
    {
        RequestedBy: string ;
        RequestedOf: string;
        DispositionTypeId: number;
        ArchiveNumber: string;
        Description: string;
    }