import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DestructionProcessShowdetailsComponent } from './destruction-process-showdetails.component';

describe('DestructionProcessShowdetailsComponent', () => {
  let component: DestructionProcessShowdetailsComponent;
  let fixture: ComponentFixture<DestructionProcessShowdetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DestructionProcessShowdetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DestructionProcessShowdetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
