import { Component, OnInit, ElementRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { RetentionexceptionService } from '../../../services/retentionexception.service';
import { ModalService } from '../../shared/modal';
import { AngularEditorConfig } from '@kolkov/angular-editor';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { ArchiveHomeService } from '../../../services/archive-home.service';
import { NotifierService } from 'angular-notifier';
import { archiveInfoService } from '../../../services/archiveinfo.service'

@Component({
  selector: 'app-retention-exception',
  templateUrl: './retention-exception.component.html',
  styleUrls: ['./retention-exception.component.css']
})
export class RetentionExceptionComponent implements OnInit {
isRetentionSelect:boolean=false;
retentionForm: FormGroup;
circumstanceDiscription:string;
retentionData:any;
archiveNumber:string;
employeeUniqueIdentifier: string = "";
isArchiveDestroyed:number = 0;
retentionPeriod:string;
retentionReasonIDs: Array<string>=[];
isHavingRetentionException:boolean=false;
isCheckedItem:boolean=false;
BodyCount: number = 0;
Description: string = "";
isGovtAuditStndChecked: boolean = false;
isExtRetentionPeriod: boolean = false;
isOtherRegulatoryReq: boolean = false;
isPeriodConsiderations: boolean = false;
success: any;
ApproveDisabled : boolean = true;
showEdit : boolean = false;
disabledColor:any;
rejectedBy : any;
isSectionApproved : boolean = false;
isSectionRejected : boolean = false;
topCss : any;
sectionid: number = 6;
userAlias = this.adalSvc.LoggedInUserEmail.substring(0, this.adalSvc.LoggedInUserEmail.lastIndexOf("@"));
rejectionDiscrption: any;
rejectionDiscrptionDisplay: any;
isRejectDiscrptionMin:boolean=false;
isRejectDiscrptionMax:boolean=false;
getcomments: any;
comment: any;
rejectedb: any;
rejectedDate:any;
ShowContent: number = 0;
popUpHeaderText : string = "";
retentionInfo:any;
canApprove:boolean=false;
isEditMode:boolean=false;

IsSectionVisited:any;
roleMapping : any;
  constructor(private retentionExceptionService:RetentionexceptionService,private archiveInfoService: archiveInfoService, private archiveHomeService: ArchiveHomeService, private modalService: ModalService, public formBuilder: FormBuilder,
    private notifier: NotifierService,private activatedRoute: ActivatedRoute,private spinnerService: NgxSpinnerService,private router: Router,private adalSvc: MsAdalAngular6Service) {

    }

  ngOnInit() {
    this.archiveNumber = this.activatedRoute.snapshot.parent.paramMap.get('aN');
    this.archiveHomeService.SyncForm3283SStatus(this.archiveNumber);
    this.employeeUniqueIdentifier = this.adalSvc.LoggedInUserEmail.split('@')[0];
    this.retentionForm = this.formBuilder.group({
      'retentionPeriodControl': [null, [Validators.required, Validators.min(1), Validators.max(99)]],
      'retentionReasonDiscription': [null, [Validators.nullValidator]]
    });
    this.getAndCheckReasonOptionsIds();
    this.archiveInfoService.getArchiveInfo(this.archiveNumber, this.employeeUniqueIdentifier).subscribe(
      (info) => {
        this.isArchiveDestroyed = info.isDestroyed;
      }
    );
  }

  getAndCheckReasonOptionsIds(){
    this.retentionExceptionService.getRetentionExceptionReasons(this.archiveNumber).subscribe(data => {
      this.retentionData=data;
      this.retentionExceptionService.getRetentionExceptionDetails(this.archiveNumber).subscribe(dataResult=>{ this.retentionInfo=dataResult;
         if(this.retentionInfo.retentionReasons && +this.retentionInfo.retentionTime>0){
          this.isRetentionSelect=true;this.isHavingRetentionException=true;
          for(let i=0;i<this.retentionData.length;i++){
             for(let id of this.retentionReasonIDs){
             if(this.retentionData[i].retentionReasonID==id){
             this.retentionData[i]['selectedReasonId']=id;
            }
          }
        }
        console.log("retentionData:::::::::::");
        console.log(this.retentionData);
      }
    });
  });
  var data = JSON.parse(localStorage.getItem('archiveSubmissionStatusData'));
  console.log('retentionarchiveSubmissionStatusData',data);
    if(data){
      this.canApprove=data.canApprove;
    }
}

  saveRetention(){
    this.markFormAsTouched(this.retentionForm);
    if (this.retentionForm.valid) {
      var parameters =
        {
          "ArchiveNumber": this.archiveNumber,
          "RetentionExtentionReasonId": this.retentionReasonIDs,
          "Comments":this.circumstanceDiscription,
          "RetentionTime":this.retentionPeriod,
          "CreatedBy":this.userAlias
        }
      var myobjstr = JSON.stringify(parameters);
      console.log("SATEESH::::::::::::::");
      console.log(myobjstr);
      this.retentionExceptionService.SaveRetentionException(myobjstr).subscribe(data => {
         this.notifier.notify("success", "Success! Your retention exception proposal has been sent to Records Management Services.");
         if(data)
         {
          setTimeout(() => { this.goToArchiveHomePage(); }, 2500);
         }
        });
    }
  }
  cancelRetention(){
    this.retentionForm.get('retentionPeriodControl').reset();
    this.retentionForm.get('retentionReasonDiscription').reset();
    this.goToArchiveHomePage();
  }
  goToArchiveHomePage() {
    this.router.navigate(["/archive/myarchives/" + this.archiveNumber]);
  }
  onKeyUpBody(boxInput) {
    this.BodyCount = 250 - this.stripHtml(boxInput).length;
    this.rejectionDiscrption=boxInput;
    //this.rejectionDiscrptionDisplay=boxInput;
    // this.rejectionDiscrptionDisplay =this.rejectionDiscrptionDisplay.replace(/<[^>]*>/g, '');
    if(this.rejectionDiscrption!==undefined && this.stripHtml(boxInput).length<5){
      this.isRejectDiscrptionMin=true;
      this.isRejectDiscrptionMax=false;
    }
    else if(this.rejectionDiscrption!==undefined && this.stripHtml(boxInput).length>250){
      this.isRejectDiscrptionMax=true;
      this.isRejectDiscrptionMin=false;
    }
    else{
      this.isRejectDiscrptionMax=false;
      this.isRejectDiscrptionMin=false;
    }

  }
  selectedQuestion(selectedOption:any,isChecked:boolean){
    if(isChecked){
    this.retentionReasonIDs.push(selectedOption);
    }
    else{
      let index = this.retentionReasonIDs.indexOf(selectedOption);
      this.retentionReasonIDs.splice(index, 1);
    }
    this.retentionForm.get('retentionPeriodControl').reset();
    this.retentionForm.get('retentionReasonDiscription').reset();
    this.checkCheckBoxvalue(isChecked,selectedOption);
  }

  checkCheckBoxvalue(isChecked:boolean, type){

    if(type==1)
      this.isGovtAuditStndChecked = isChecked;
    else if(type==2)
      this.isExtRetentionPeriod = isChecked;
    else if(type==3)
      this.isOtherRegulatoryReq = isChecked;
    else if(type==5)
      this.isPeriodConsiderations = isChecked;
  }

  markFormAsTouched(group: FormGroup | FormArray) {
    Object.keys(group.controls).forEach((key: string) => {
      const control = group.controls[key];
      if (control instanceof FormGroup || control instanceof FormArray) { control.markAsTouched(); this.markFormAsTouched(control); }
      else { control.markAsTouched(); };
    });
  };
  stripHtml(html: string) {
    // Create a new div element
    var temporalDivElement = document.createElement("div");
    // Set the HTML content with the providen
    temporalDivElement.innerHTML = html;
    // Retrieve the text property of the element (cross-browser support)
    return temporalDivElement.textContent || temporalDivElement.innerText || "";
  }
}
