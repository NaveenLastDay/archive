﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DataModels
{
    public class UserOfflinePermissionsModel
    {
        public string userAlias { get; set; }
        public int IsEnabled { get; set; }

        public bool IsPartialOutage { get; set; }

        public string OfflinePage { get; set; }
    }
}
