﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DataModels
{
    public class EngagementPersonnelInfoModel
    {
        public string EmployeeName { get; set; }
        public string Office { get; set; }
        public string Business { get; set; }
        public string EmployeeAlias { get; set; }
        public int IsManualSubmission { get; set; }
		public DateTime CreatedDate { get; set; }

	}
}
