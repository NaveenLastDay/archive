import { Component, OnInit, Output } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router'
import { FormControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { debounceTime, distinctUntilChanged, map } from 'rxjs/operators';
import { SearchWbsService } from '../../../services/searchwbs.service';
import { MatAutocompleteSelectedEvent } from '@angular/material';
import { NotifierService } from 'angular-notifier';
import { MatAutocompleteTrigger } from '@angular/material';
import { AppConfig } from '../../../services/appconfig.service';
import { UserConfigSettingService } from '../../../guards/user-role-guard.service';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { NgxSpinnerService } from "ngx-spinner";

export interface WBSData {
  clientNumber: string,
  clientID: string,
  clientName: string,
  archiveNumber: string,
  archiveName: string,
  archiveCategory: string,
  wbsClientName: string,
  wbsLevelOneNumber: string,
  wbsLevelOneDescription: string,
  wbsLevelOneDateCreated: Date
}

@Component({
  selector: 'app-search-wbs',
  templateUrl: './search-wbs.component.html',
  styleUrls: ['./search-wbs.component.css']
})
export class SearchWbsComponent implements OnInit {


  //Variable Decleration

  autoTrigger: MatAutocompleteTrigger;
  $wbsClientData: Observable<any[]>;
  $searchWBSData: WBSData[];
  $filteredwbsClientData: Observable<any[]>;
  wbsCount: any;
  apiData2: any[];
  rowcount: any;
  searchedWBSResults: string;
  searchWBSData2: any[];
  wbslength: any;
  buttonDisabled: boolean;
  textlength: any;
  searchedtext: string = "";
  crossicon: boolean = false;

  value: any;
  userConfig: any;
  userEmail = this.adalSvc.LoggedInUserEmail;
  euserAlias = this.userEmail.replace("@deloitte.com", "");

  lastSearchKeyword: string = '';
  currentSearchKeyword: string = '';

  private _subject: BehaviorSubject<string> = new BehaviorSubject<string>("");

  constructor(private router: Router, private fb: FormBuilder,
    private searchwbs: SearchWbsService, private notifier: NotifierService, private _userConfig: UserConfigSettingService,
    private adalSvc: MsAdalAngular6Service, private SpinnerService: NgxSpinnerService) {
    this.rowcount = 10;
    this.searchedWBSResults = '';
  }
  ngOnInit() {
    this.userConfig = this._userConfig.FetchLoggedInUser(this.euserAlias);
    if (this.userConfig.value.IsManager || this.userConfig.value.IsPPD || this.userConfig.value.isAdmin) {
      this.buttonDisabled = true;
      let element3 = document.getElementById("applicationFooter_ID");
      element3.classList.add("application-footer-b-0");
    }
    else {
      this.router.navigate(["/"]);
    }
  }
  ngOnDestroy() {
    let element3 = document.getElementById("applicationFooter_ID");
    element3.classList.remove("application-footer-b-0");
  }
  onInputChanged(event: any) {
    this.wbslength = event.length;
    this.textlength = AppConfig.settings.searchwbs.textboxlength;
    this.currentSearchKeyword = event;
    this._subject.next(this.currentSearchKeyword ? this.currentSearchKeyword.trim() : "");

    if (event.length >= this.textlength) {
      this._subject.pipe(
        distinctUntilChanged(),
        debounceTime(500),
      ).subscribe(value => this.GetWBSSerchResults(value))
    }
    else {
      this.$searchWBSData = null;
    }
    if (this.$searchWBSData != undefined)
      this.wbsCount = this.$searchWBSData.length;
  }
  addcolour() {
    document.getElementById('colordiv').classList.add('bordercolorchange');
    this.crossicon = true;
  }

  removecolour(event: any) {
    document.getElementById('colordiv').classList.remove('bordercolorchange');
    if (event.target.value === '') {
      this.crossicon = false;
    }
  }

  OnReset() {
    this.searchedtext = '';
    this.$searchWBSData = [];
    this.buttonDisabled = true;
  }
  optionSelected(event: MatAutocompleteSelectedEvent) {
    console.log(event.option.value.wbsLevelOneNumber);
    this.router.navigate(["/" + "archive/existingArchives" + "/" + event.option.value.wbsLevelOneNumber]);
  }

  GetWBSSerchResults(searchString: string) {
    if (searchString.length >= this.textlength && this.lastSearchKeyword != searchString) {
      this.lastSearchKeyword = searchString;
      this.searchwbs.GetWBSSerchResults(searchString, this.rowcount).subscribe(result => {
        if (result.length > 0) {
          if (this.currentSearchKeyword.length >= this.textlength) {
            this.$searchWBSData = result;
          } else {
            this.$searchWBSData = null;
          }
          this.$searchWBSData = result;
        }
        else {
          this.$searchWBSData = null;
          this.notifier.notify("error", "No results found for Search WBS");
        }

      },
        (err) => {
          console.log("error is ", err)
        });

        this.SpinnerService.hide();
    }
  }

  //Filter the data for Search WBS
  private filterwbsClient(value: string) {
    let filterValue = '';
    if (value) {
      filterValue = value.toLowerCase();
      return this.$wbsClientData.pipe(
        map(data => data.filter(data => data.name.toLowerCase().indexOf(filterValue) === 0))
      );
    } else {
      return this.$wbsClientData;
    }
  }

  OnClick(PageUrl) {
    this.router.navigate(["/" + PageUrl + ""]);
  }

  //Navigate to Existing WBS List Screen
  reDirectToWbsList(path, optionSelectedvalue) {
    // debugger;
    if (this.$searchWBSData != null && this.$searchWBSData.length > 0) {
      this.router.navigate(["/" + path + "/", optionSelectedvalue]);
    }
    else
      this.notifier.notify("error", "No results found for Selected WBS");
  }

}

