import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-holds-search-home',
  templateUrl: './holds-search-home.component.html'
})

export class HoldsSearchHomeComponent implements OnInit {

  constructor() {
  }
  ngOnInit() {
  }
   

}
