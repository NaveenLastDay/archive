﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Web;

namespace Deloitte.AIFA.Helpers.ExcelGenerator
{
    public class FileHelper
    {
        //public FileStream GetFileContentStream(string filePath)
        //{
        //    var file = new FileInfo(filePath);
        //    return new FileStream(file.FullName, FileMode.Open, FileAccess.Read, FileShare.Read);
        //}

        public static string CanonicalCombine(string path, string basePath = null)
        {
            if (string.IsNullOrEmpty(path))
            {
                throw new ArgumentNullException();
            }

            if (string.IsNullOrWhiteSpace(basePath))
            {
                basePath = Path.GetDirectoryName(path);
            }

            basePath = HttpUtility.UrlDecode(basePath) ?? string.Empty;
            path = HttpUtility.UrlDecode(RemoveUnexpectedCarriageReturn(Path.GetFileName(path)));

            if (basePath.IndexOfAny(Path.GetInvalidPathChars()) > -1)
            {
                throw new DirectoryNotFoundException("FolderPath is not valid");
            }

            if (string.IsNullOrEmpty(path) || path.IndexOfAny(Path.GetInvalidFileNameChars()) > -1)
            {
                throw new FileNotFoundException("FileName is not valid");
            }

            var filePath = Path.Combine(basePath, path);

            if (!filePath.StartsWith(basePath))
            {
                throw new FileNotFoundException("Path is not valid");
            }

            return Path.GetFullPath(filePath);
        }

        public static FileStream FileOpen(string path, FileMode mode, FileAccess access, FileShare share)
        {
            return File.Exists(path)
                ? File.Open(HttpUtility.UrlDecode(HttpUtility.UrlEncode(path)) ?? string.Empty, mode, access, share)
                : null;
        }

        //public static void FileDelete(string path)
        //{
        //    path = CanonicalCombine(path);
        //    if (File.Exists(path))
        //        File.Delete(HttpUtility.UrlDecode(HttpUtility.UrlEncode(path)) ?? string.Empty);
        //}

        public static string RemoveUnexpectedCarriageReturn(string value)
        {
            return HttpUtility.UrlEncode(value.Replace("\r", string.Empty)
                        .Replace("%0d", string.Empty)
                        .Replace("%0D", string.Empty)
                        .Replace("\n", string.Empty)
                        .Replace("%0a", string.Empty)
                        .Replace("%0A", string.Empty));
        }
    }
}

