﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DataModels
{
    public class Form3283ReasonTypeModel
    {
        public int FormId { get; set; }
        public int ReasonTypeId { get; set; }
        public string ReasonTypeDescription { get; set; }
        public bool IsSelectedBefore { get; set; }
    }
}
