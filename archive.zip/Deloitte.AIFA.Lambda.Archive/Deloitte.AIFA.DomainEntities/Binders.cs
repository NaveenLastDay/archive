﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
    public class Binders
    {
        public int BinderID { get; set; }
        public string Description { get; set; }
        public string Barcode { get; set; }
        public int PhysicalRecordStatusID { get; set; }
        public string PhysicalRecordStatus { get; set; }
        public int RowNumber { get; set; }
        public int Count { get; set; }
    }
}
