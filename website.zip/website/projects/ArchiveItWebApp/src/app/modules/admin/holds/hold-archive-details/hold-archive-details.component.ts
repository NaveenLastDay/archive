import { Component, OnInit } from '@angular/core';
import { MatTable, MatSlideToggleChange } from '@angular/material';
import { HoldsService } from '../../../../services/holds-admin.service';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { Router, NavigationEnd, ActivatedRoute } from '@angular/router';
import { NotifierService, NotifierModule, NotifierOptions } from "angular-notifier";

@Component({
  selector: 'app-hold-archive-details',
  templateUrl: './hold-archive-details.component.html',
  styleUrls: ['./hold-archive-details.component.css']
})
export class HoldArchiveDetailsComponent implements OnInit {
  data: any;
  dataSource:any;
  archiveHoldDetails:any[];
  currentUrl: string;
  selectedItem: string;
  hoverIndex: number = -1;
  currentPageNumber: number = 1;
  readonly pageSize: number = 10;
  pageCount: number = 1;
  pageArray = Array();
  displayingRecordsFrom: number = 0;
  displayingRecordsTo: number = 0;
  totalHoldsAssigned: number = 0;
  holdCreationDate: any;
  suspensionDate:any;
  holdStatus:any;
  holdName: string;
  dataSourceHold: any[];
  
  constructor(private router: Router,private holdService: HoldsService, 
    private adalSvc: MsAdalAngular6Service,private notifier: NotifierService,
    private activatedRoute: ActivatedRoute
    ) { }

  ngOnInit() {
   this.selectedItem = this.activatedRoute.snapshot.params.HN;     
    this.GetHoldsAssociatedtoArchives('AEA502255');   
  }

 /* GetHoldDetailsData(x : string) {
    this.dataSource= [
        {clientName: '1', archiveName: 'AN-archiveName 1',archiveNumber:'archiveNum 1',business:'Tax',periodEnd:'10/10/1992'},
        {clientName: '2', archiveName: 'AN-archiveName 2',archiveNumber:'archiveNum 2',business:'Tax',periodEnd:'10/10/1992'},
        {clientName: '3', archiveName: 'AN-archiveName 3',archiveNumber:'archiveNum 3',business:'Tax',periodEnd:'10/10/1992'},
        {clientName: '4', archiveName: 'AN-archiveName 4',archiveNumber:'archiveNum 4',business:'Tax',periodEnd:'10/10/1992'},
    ];

  }
*/
GetHoldsAssociatedtoArchives(ArchiveNumber:string) {
    // debugger;
    //this.SpinnerService.show();
    this.holdService.GetHoldsAssociatedtoArchives(ArchiveNumber).subscribe(
      data => {
        this.archiveHoldDetails = data ;
        console.log('apiData',data);
/*
        if (this.archiveHoldDetails.length > 0) {
          this.calculatePageCount();
        }
        else {
          this.clearPageCount();
        }*/
       // this.SpinnerService.hide();
      }
      
    );
    
  }
/*
  calculatePageCount() {
    let possiblePages: number;

    if (this.archiveHoldDetails && this.archiveHoldDetails.length > 0) {
      let possiblePages = Math.ceil(parseInt(this.archiveHoldDetails[0]["count"]) / this.pageSize);
      this.pageCount = possiblePages;
      this.pageArray = Array(this.pageCount).fill(0).map((e, i) => i + 1);
      this.holdCreationDate =this.archiveHoldDetails[0]["holdCreationDate"];
      this.suspensionDate= this.archiveHoldDetails[0]["suspensionDate"];
      this.holdStatus =this.archiveHoldDetails[0]["holdStatus"]==1?'Active':'Suspended';
      // debugger;
      if(this.archiveHoldDetails[0]["archiveName"]==""){
        this.archiveHoldDetails=[];
        this.totalHoldsAssigned = 0
        this.displayingRecordsFrom = 0
        this.displayingRecordsTo = 0
        this.pageArray=[];
      }
      else{
      this.totalHoldsAssigned = this.archiveHoldDetails[0]["count"];
      this.displayingRecordsFrom = this.archiveHoldDetails[0]["rowNumber"];
      this.displayingRecordsTo = this.archiveHoldDetails[this.archiveHoldDetails.length - 1]["rowNumber"];
      this.pageArray = Array(this.pageCount).fill(0).map((e, i) => i + 1);
    }
    }
    else {
      this.clearPageCount();
    }
  }
  changePage(event, requestedPage: any) {


    if (isNaN(requestedPage) || requestedPage < 1 || requestedPage > this.pageCount) {
      this.notifier.notify("error", "Invalid page number.");
      return false;
    }
    this.currentPageNumber = parseInt(requestedPage);
    this.GetArchiveHoldDetails();

  }
  clearPageCount() {
    this.currentPageNumber = 1;
    this.pageCount = 1;
    this.pageArray = Array();
  }
  jumpToNextPage() {
    console.log('jumpToNextPage');

    if (this.currentPageNumber < this.pageArray.length) {
      this.currentPageNumber++;
      this.GetArchiveHoldDetails();
    }

  }

  jumpToPreviousPage() {
    console.log('jumpToPreviousPage');

    if (this.currentPageNumber > 1) {
      this.currentPageNumber--;
      this.GetArchiveHoldDetails();
    }
  }

  jumpToStartPage() {
    console.log('jumpToStartPage');
    // this.currentPageNumber = this.pageArray[0];
    this.currentPageNumber = 1;
    this.GetArchiveHoldDetails();
  }

  jumToEndPage() {
    console.log('jumToEndPage');
    //this.currentPageNumber = this.pageArray[this.pageArray.length-1];
    this.currentPageNumber = this.pageArray[this.pageArray.length - 1];
    this.GetArchiveHoldDetails();
  }

  /*
  generateReportClicked(data) {

    if (this.totalArchives > 1000000) {
      this.notifier.notify("error", "Record count more than 1000000.");
    }
    else {
      this.SpinnerService.show();
      let archiveForReport: any[] = [];
      let filterdColumns = (this.columnFilters.filter(x => x.checked));
      let selectedJson = Object.assign({}, this.searchEventService.finalSelectedJson);
      selectedJson["pageSize"] = 10000;//1048000//1,048,576
      this._search.getAdvancedSearchResults(selectedJson).subscribe(
        data => {
          if (data && data.hits && data.hits.total.value && data.hits.hits.length) {
            // console.log("data exists");
            data.hits.hits.forEach(element => {
              let archive = {};
              filterdColumns.forEach(column => {

                if (column["value"] == this.archiveResultGridColumns.ArchiveNumber) { //Archive#
                  archive[this.archiveResultGridColumns[this.archiveResultGridColumns.ArchiveNumber]] = element._source.ArchiveNumber || this.emptyStringInReport;
                }

                if (column["value"] == this.archiveResultGridColumns.Business) { //Business
                  archive[this.archiveResultGridColumns[this.archiveResultGridColumns.Business]] = element._source.Business.original || this.emptyStringInReport;
                }

                if (column["value"] == this.archiveResultGridColumns.Client) { //Client
                  archive[this.archiveResultGridColumns[this.archiveResultGridColumns.Client]] = element._source.ClientName.original || this.emptyStringInReport;
                }

                if (column["value"] == this.archiveResultGridColumns.ArchiveName) { //Archive Name
                  archive[this.archiveResultGridColumns[this.archiveResultGridColumns.ArchiveName]] = element._source.ArchiveName.original || this.emptyStringInReport;
                }

                if (column["value"] == this.archiveResultGridColumns.PeriodEnd) { //Period End
                  archive[this.archiveResultGridColumns[this.archiveResultGridColumns.PeriodEnd]] = element._source.RetentionPeriodEndDate ? this.datePipe.transform(element._source.RetentionPeriodEndDate, this.dateFormatInReport) : this.emptyStringInReport;
                }

                if (column["value"] == this.archiveResultGridColumns.WBSNumber) { //WBS#
                  archive[this.archiveResultGridColumns[this.archiveResultGridColumns.WBSNumber]] = element._source.WbsNumber.original || this.emptyStringInReport;
                }

                if (column["value"] == this.archiveResultGridColumns.Type) { //Type
                  archive[this.archiveResultGridColumns[this.archiveResultGridColumns.Type]] = element._source.ArchiveType.original || this.emptyStringInReport;
                }

                if (column["value"] == this.archiveResultGridColumns.Status) { //Status
                  archive[this.archiveResultGridColumns[this.archiveResultGridColumns.Status]] = element._source.ArchiveStatus.original || this.emptyStringInReport;
                }

                if (column["value"] == this.archiveResultGridColumns.Engagement) { //Engagement
                  archive[this.archiveResultGridColumns[this.archiveResultGridColumns.Engagement]] = element._source.EngagementType.original || this.emptyStringInReport;
                }

                if (column["value"] == this.archiveResultGridColumns.RDCD) { //RDCD
                  archive[this.archiveResultGridColumns[this.archiveResultGridColumns.RDCD]] =  element._source.ArchiveDueDate ? this.datePipe.transform(element._source.ArchiveDueDate, this.dateFormatInReport) : this.emptyStringInReport;
                  //archive[this.archiveResultGridColumns[this.archiveResultGridColumns.RDCD]] = "";
                }

                if (column["value"] == this.archiveResultGridColumns.EDCD) { //EDCD
                  archive[this.archiveResultGridColumns[this.archiveResultGridColumns.EDCD]] =  element._source.EstimatedIssuanceReportDate ? this.datePipe.transform(element._source.EstimatedIssuanceReportDate, this.dateFormatInReport) : this.emptyStringInReport;
                  //archive[this.archiveResultGridColumns[this.archiveResultGridColumns.EDCD]] = "";
                }

                if (column["value"] == this.archiveResultGridColumns.IsResubmissionInProgress) { //Is Resubmission In Progress
                  // console.log(element._source.IsResubmissionInProgress);
                  archive[this.archiveResultGridColumns[this.archiveResultGridColumns.IsResubmissionInProgress]] = element._source.IsResubmissionInProgress=="true" ? "Yes" : "No";
                  //archive[this.archiveResultGridColumns[this.archiveResultGridColumns.IsResubmissionInProgress]] = "No";
                }

                if (column["value"] == this.archiveResultGridColumns.ArchiveDescription) { //Archive Description
                  archive[this.archiveResultGridColumns[this.archiveResultGridColumns.ArchiveDescription]] = element._source.ArchiveDescription.original || this.emptyStringInReport;
                }

                if (column["value"] == this.archiveResultGridColumns.EntityAssociatedWithArchive) { //Entity Associated With Archive
                  archive[this.archiveResultGridColumns[this.archiveResultGridColumns.EntityAssociatedWithArchive]] = element._source.EntityType.original || this.emptyStringInReport;
                }

                if (column["value"] == this.archiveResultGridColumns.StandardsApplied) { //Standards Applied
                  archive[this.archiveResultGridColumns[this.archiveResultGridColumns.StandardsApplied]] = element._source.ProfessionalStandard.original || this.emptyStringInReport;
                }

                if (column["value"] == this.archiveResultGridColumns.ReportingEntity) { //Reporting Entity
                  //archive[this.archiveResultGridColumns[this.archiveResultGridColumns.ReportingEntity]] = element._source.ReportingEntity.original || "";
                  archive[this.archiveResultGridColumns[this.archiveResultGridColumns.ReportingEntity]] = "";
                }

                if (column["value"] == this.archiveResultGridColumns.ArchivePartner) { //Archive Partner
                  archive[this.archiveResultGridColumns[this.archiveResultGridColumns.ArchivePartner]] = element._source.ArchivePartner.original || this.emptyStringInReport;
                }

                if (column["value"] == this.archiveResultGridColumns.ArchiveManager) { //Archive Manager
                  archive[this.archiveResultGridColumns[this.archiveResultGridColumns.ArchiveManager]] = element._source.ArchiveManager.original || this.emptyStringInReport;
                }

                if (column["value"] == this.archiveResultGridColumns.ArchiveFieldSenior) { //Archive Field Senior
                  archive[this.archiveResultGridColumns[this.archiveResultGridColumns.ArchiveFieldSenior]] = element._source.ArchvieFieldSenior.original || this.emptyStringInReport;
                }

                if (column["value"] == this.archiveResultGridColumns.AdditionalArchiveFieldSenior) { //Additional Archive Field Senior
                  archive[this.archiveResultGridColumns[this.archiveResultGridColumns.AdditionalArchiveFieldSenior]] = element._source.AddArchvieFieldSenior.original || this.emptyStringInReport;
                }
              });
              archiveForReport.push(archive);
            });
          }
          if (archiveForReport && archiveForReport.length) {
            this.sharedService.generateExcel("search-result", "archives", filterdColumns.map(x => x.displayName), archiveForReport);
          }
        },
        error => {
          console.log('Exception occured ' + JSON.stringify(error));
          this.SpinnerService.hide();
        }
      );
    }
  }
  */



  mouseOver(event: any, index: number) {
    this.hoverIndex = index;
    //event.stopPropagation();
  }

  mouseOut(event: any) {
    let name: string = '';
    let present: number = -1;

    name = event.toElement ? event.toElement.getAttribute('name') : '';
    present = name ? name.search("AccessArchiveTop") : -1;

    if (event.toElement && present == -1 && (event.toElement["tagName"] != 'td' || event.toElement.className == 'trArchiveHoldsGridHeadFont')) {
      this.hoverIndex = -1;
    }
  }
  Returntoholds(){
    this.router.navigate(["admin/adminsidenavbar/holds"]);
  }
  showArchiveDetails(archiveNumber : string, i : number){}
}
