import { Component, OnInit, OnDestroy, HostListener } from '@angular/core';
import { MaintainalersService } from './services/maintainalers.service';
import { ModalService } from './modules/shared/modal';
import { Subscription } from 'rxjs';
import { PubsubService } from './services/pubsub.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { LoginuserdetailsService } from './services/loginuserdetails.service';
import { Idle, DEFAULT_INTERRUPTSOURCES } from '@ng-idle/core';
import { Keepalive } from '@ng-idle/keepalive';
import { Router, NavigationEnd } from '@angular/router';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { AppConfig } from './services/appconfig.service';
import { UtilityService } from './services/utility.service';
import { NotifierService } from 'angular-notifier';
import { environment } from '../environments/environment';
import { BulkdownloadEventService } from './modules/record/bulk-download/bulkdownload.event.service';
import { FileUploadEventService } from './modules/record/file-upload/fileupload.event.service';
import { HomePageService } from './services/homepage.service';




//import {loginUserWalkMe} from './assets/js/loadLoginUserForWalkme.js';
declare var setUserForWalkme: any;

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit, OnDestroy {
  title = 'ArchiveItWebApp';
  currentUrl: string;
  routes: Array<Object>;
  alerts: any[];
  enablepopup: boolean = false;
  highseveritypopuplistcount: number;
  highalertssubscription: Subscription;
  highAlertCount: any;

  //Session management
  idleState = 'Not started.';
  timedOut = false;
  lastPing?: Date = null;
  showSessionTimeoutPopup = false;
  formnotifier: any;
  submitText: any;
  approveText: any;
  rejectText: any;

  userOfflinePermissionDetails:any;
  isApplicationEnabled:any;
  isPartialOutageEnabled:boolean;
  offlinePageUrl:string;
  hideHeader = true;

  constructor(private maintainalerts: MaintainalersService, private modalService: ModalService,
    private pubsub: PubsubService, private notifier: NotifierService, private spinner: NgxSpinnerService, private userloginservice: LoginuserdetailsService, private idle: Idle, private keepalive: Keepalive,
    private router: Router, private adal: MsAdalAngular6Service, private utility: UtilityService,
    private _bdownloadEventService: BulkdownloadEventService, private homepageSvc: HomePageService,
    private _fuEventService: FileUploadEventService) {

    if (!this.adal.isAuthenticated) {
        this.adal.login();
    }

    this.FetchUserOfflinePermissions();
    this.getHighAlertsCount();
    console.log("Flow Track => app.component.ts is loaded")
    // this.getFormSubmitNotifierflag();
    console.log("app component contructor")
    //Session management
    // sets an idle timeout of 600 seconds (10 minutes).
    idle.setIdle(1200);
    // sets a timeout period of 5 seconds. after 0 seconds of inactivity, the user will be considered timed out.
    idle.setTimeout(5);
    // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
    idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);

    idle.onIdleEnd.subscribe(() => {
      this.idleState = 'No longer idle.'
      console.log(this.idleState);
      this.reset();
    });

    idle.onTimeout.subscribe(() => {
      this.idleState = `Your session expired!
      Clicking on \'Reload\' will redirect you to home page.`;
      this.timedOut = true;
      this.showSessionTimeoutPopup = true;
      console.log(this.idleState);
      //this.router.navigate(['/refresh']);
    });

    idle.onIdleStart.subscribe(() => {
      this.idleState = 'You\'ve gone idle!'
      console.log(this.idleState);
    });

    idle.onTimeoutWarning.subscribe((countdown) => {
      console.log(this.showSessionTimeoutPopup);
      //this.showSessionTimeoutPopup = true;
      this.idleState = 'You will time out in ' + countdown + ' seconds!'
      console.log(this.idleState);

    });

    this.pubsub.sessionExtentionNotification().subscribe(
      message => {
        //console.log("Session extended on request");
        this.reset();
      }
    );

    setInterval(() => {
      if (this.timedOut == false) {
        this.adal.RenewToken(AppConfig.settings.adalConfig.endpoints.api);
        console.log("AD token renewed!  " + Date().toString());
        this.utility.PingAdminService();
        //this.getHighSeverityAlerts();
        console.log("Pinged service " + Date().toString());
      }
    }
      , 3300 * 1000); // 55 minutes

    // sets the ping interval to 60 seconds
    keepalive.interval(60);

    keepalive.onPing.subscribe(() => { this.lastPing = new Date(); });

    this.reset();
    // if (!this.isPartialOutageEnabled && this.isApplicationEnabled!=0)
    this.walkmeSnippet();
    this.adobeAnalyticsSnippet();

     this.router.events.subscribe((ev) => {
      if (ev instanceof NavigationEnd) { 
        if (location.href.indexOf("/MIG")>0) {
          this.router.navigate(["/home"]);
        }
      }
    }); 

  }

  walkmeSnippet()
  {

  const walkme = document.createElement('script');
  walkme.type = 'text/javascript';
  walkme.async = true;
  walkme.src  =AppConfig.settings.walkMe.WalkMeSrc;
  var s = document.getElementsByTagName('script')[0];
  s.parentNode.insertBefore(walkme, s);
  document.head.appendChild(walkme);
  setUserForWalkme(this.userloginservice.GetUserAlias().toString());

  }


  adobeAnalyticsSnippet()
  {
    const adobeAnalytics = document.createElement('script');
    adobeAnalytics.type = 'text/javascript';
    adobeAnalytics.async = true;
    adobeAnalytics.src  =AppConfig.settings.adobeAnalytics.AdobeAnalyticsSrc;
    var s = document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(adobeAnalytics, s);
    document.head.appendChild(adobeAnalytics);
    //setUserForWalkme(this.userloginservice.GetUserAlias().toString());

  }


  reset() {
    this.idle.watch();
    this.idleState = 'Started.';
    this.timedOut = false;
  }

  stay(modelPopuId) {
    this.showSessionTimeoutPopup = false;
    this.reset();
  }

  reload(modelPopuId) {
    this.showSessionTimeoutPopup = false;
    //this.router.navigate(['/refresh']);
    window.location.href = window.location.origin;
  }

  ngOnInit() {
    console.log("FlowTrack => I am Onit from app.component.ts")
    //this.getHighSeverityAlerts(); commented this line to avoid duplicate calls to getAlerts during page load
    this.getFormSubmitNotifierflag();

    //initiate bulkdownload pooling
    this._bdownloadEventService.notifybulkdownload();

  }

  FetchUserOfflinePermissions(){
    this.homepageSvc.FetchUserOfflinePermissions().subscribe(
      (data: { isEnabled: any; isPartialOutage: boolean; offlinePage: string; })=>{

        this.isApplicationEnabled=data.isEnabled;
        this.isPartialOutageEnabled=data.isPartialOutage;
        this.offlinePageUrl=data.offlinePage;
        if (this.isPartialOutageEnabled && this.isApplicationEnabled==0){
          this.hideHeader= false;
          this.router.navigate(['/partialoutage']);
          // window.location.href=this.offlinePageUrl;
       }
      //  else
      //  this.router.navigate(['/']);
      });
  }

  getFormSubmitNotifierflag() {
    this.formnotifier = this.pubsub.getFormSubmitNotifier().subscribe(
      message => {
        this.submitText = message.text;
        if (this.submitText == "Submit") {
          this.notifier.notify("success", "Submitted successfully! You have successfully submitted Form 3283S for approval");
        }
        else if (this.submitText == "Approve") {
          this.notifier.notify("success", "Form3283S Approved successfully!");
        }
        else if (this.submitText == "Reject") {
          this.notifier.notify("success", "Form3283S Rejected successfully!");
        }
      }
    );
  }

  getHighAlertsCount() {
    this.highalertssubscription = this.pubsub.getHighAlertsCount().subscribe(
      message => {
        this.highAlertCount = message.text;
        if (this.highAlertCount == "0") {
          this.enablepopup = false;
        }
        else {
          this.getHighSeverityAlerts();
        }
      }
    );
  }

  sendHighAlertCount() {
    this.pubsub.sendHighAlertsCount(this.highAlertCount);
  }

  closeModalDialog(Action, obj) {
    var userAlias = this.userloginservice.GetUserAlias();
    this.sendHighAlertCount();
    var parameter = obj.map(x => x.id);
    var stringalertids = parameter.toString();
    var myobjstr = {
      "alertIds": stringalertids,
      "UserAlias": ''
    }
    this.maintainalerts.ReadReceipents(myobjstr).subscribe(
      data => {
        var readReceipents = data;
        this.maintainalerts.SyncAlerts();
      }
    );

    this.modalService.close(Action);
  }

  getHighSeverityAlerts() {
    var userAlias = this.userloginservice.GetUserAlias();
    this.maintainalerts.GetUserAlerts(userAlias).subscribe(
      data => {
        var myArray = data;
        this.alerts = myArray.filter((x) => { return x.isHighSeverity == true && x.isRead == false; });
        this.highseveritypopuplistcount = this.alerts.length;
        if (this.alerts.length == 0) {
          this.enablepopup = false;
        }
        else {
          this.enablepopup = true;
        }
      }

    );
  }
  @HostListener('window:beforeunload', ['$event'])
  beforeunloadHandler(event) {

    var filearray = this._fuEventService.fileArray.filter(x =>  x.fileName != "" && x.uploadStatus != "add" && x.uploadStatus == "started" );
    if (((filearray && filearray.length > 0) || this._bdownloadEventService.bulkDownloadsArray.length > 0) && this._fuEventService.guardflag==0) {
      this._fuEventService.guardflag=0;
      return false;
    }
    else
    {
      this._fuEventService.guardflag=0;
      return true;
    }
    //I have used return false but you can your other functions or any query or condition
  }
  ngOnDestroy() {
    this.highalertssubscription.unsubscribe();
    this.idle.onIdleEnd.unsubscribe();
    this.idle.onTimeout.unsubscribe();
    this.idle.onIdleStart.unsubscribe();
    this.idle.onTimeoutWarning.unsubscribe();
    console.log("app component destroy");
  }

}
