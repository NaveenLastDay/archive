﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
    public class ArchiveAction
    {
        public int ArchiveId { get; set; }
        public int ActionsTypeId { get; set; }
        public int ArchiveSectionId { get; set; }
        public string ActionBy { get; set; }
    }
    public class ArchiveAtcionsForIndividualSections
    {
        public int ArchiveSectionId { get; set; }
        public int? ActionsTypeId { get; set; }

        public string ActionBy { get; set; }
        public int isSectionEdited { get; set; }


    }

    public class ArchiveActionForSubstantiveResubmit
    {
        public Boolean ArchiveDetailsEdited { get; set; }
        public Boolean ERPEdited { get; set; }
        public Boolean WorkingPapersEdited { get; set; }
        public Boolean DeliverablesEdited { get; set; }
        public string ArchiveDetailsResubmitReason { get; set; }
        public string ERPResubmitReason { get; set; }
        public string WorkingPapersResubmitReason { get; set; }
        public string DeliverablesResubmitReason { get; set; }
    }
}
