﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Amazon.Lambda.Core;
using Deloitte.AIFA.DataModels;
using Deloitte.AIFA.DomainEntities;
using Deloitte.AIFA.DomainServices.Contracts;
using Deloitte.AIFA.ICloudServices;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace Deloitte.AIFA.Lambda.Archive.Controllers
{
    [Route("api/archiveflow")]
    [ApiController]
    public class ArchiveFlowController : ControllerBase
    {
        IArchiveFlowService _archiveflowService;
        ILogger _logger { get; set; }
        private readonly IHttpContextAccessor _contextAccessor;
        private string userAlias;

        private readonly IUtilityService _utilityServie;
        //private dynamic context;
        private List<RoleFunction> roleFunctions;

        public ArchiveFlowController(IHttpContextAccessor contextAccessor, IArchiveFlowService archiveflowService, ILogger<ArchiveFlowController> logger, ICloudCacheService cloudCacheService, IUtilityService utilityServie)
        {
            _logger = logger;
            _archiveflowService = archiveflowService;
            this._contextAccessor = contextAccessor;
            this._utilityServie = utilityServie;

            _logger.LogInformation("Archive Flow Controller Initiated");
            try
            {
                LambdaLogger.Log("Inside ArchiveFlow Controller");
                var _context = this._contextAccessor.HttpContext;
                try
                {
                    if (_context?.User?.Claims.Any() == true)
                    {
                        LambdaLogger.Log("Has claims in ArchiveFlow Controller");
                        foreach (var claim in _context?.User?.Claims)
                        {
                            //LambdaLogger.Log(claim.Type);
                            if (claim.Type == "UserAlias")
                            {
                                userAlias = claim.Value.Split('@')[0].ToString();
                            }
                            LambdaLogger.Log("User Alias from ArchiveFlow Controller," + userAlias);
                        }
                    }
                    else
                    {
                        LambdaLogger.Log("Has No claims");
                    }
                }
                catch (Exception ex)
                {
                    LambdaLogger.Log("Error with Http context in ArchiveFlow controller: " + ex.Message);
                }
            }
            catch (Exception e)
            {
                LambdaLogger.Log("Error in ArchiveFlow controller: " + e.Message);
            }
            try
            {
                CacheRequestModel cacheRequestModel = new CacheRequestModel();

                cacheRequestModel.Key = "RoleFunctions";
                _logger.LogInformation("RoleFunctions Cache RequestModelKey from Archive Controller : " + System.Web.HttpUtility.HtmlEncode(cacheRequestModel.Key));
                var data = cloudCacheService.GetValue(cacheRequestModel);
                LambdaLogger.Log("cacheLog454345:" + data);
                _logger.LogInformation("cacheLog12345678:" + data);
                if (data == null)
                {
                    LambdaLogger.Log("cacheLogInside987978:");
                    roleFunctions = utilityServie.GetRoleFunctions();
                    cacheRequestModel.Value = JsonConvert.SerializeObject(roleFunctions);
                    _logger.LogInformation("RoleFunctions Cache Model Value from Archive Controller : " + System.Web.HttpUtility.HtmlEncode(JsonConvert.SerializeObject(cacheRequestModel.Value)));
                    var val = cloudCacheService.SetValue(cacheRequestModel);
                    _logger.LogInformation("RoleFunctions Cache Service Response from Archive Controller : " + System.Web.HttpUtility.HtmlEncode(val.ToString()));
                }
                else
                {
                    LambdaLogger.Log("cacheLogElse65978:");
                    roleFunctions = JsonConvert.DeserializeObject<List<RoleFunction>>(data);
                    LambdaLogger.Log("cacheLog764987: " + JsonConvert.SerializeObject(roleFunctions));
                    _logger.LogInformation("RoleFunctions Cache Value from Archive Controller : " + System.Web.HttpUtility.HtmlEncode(JsonConvert.SerializeObject(roleFunctions)));
                }

            }
            catch (Exception e)
            {
                _logger.LogError("Exception in Cloud Cache Archive Controller:" + e.Message);
            }
        }

        [HttpGet]
        [Route("getarchivesectioncomments")]
        public IActionResult GetArchiveSectionComments(string ArchiveNumber, int sectionId, int ActionTypeId)
        {
            var id = GetFuntionID("Access Archive");
            var isValid = _utilityServie.IsUserAuthorizedtoPerformAction(ArchiveNumber, id, userAlias);
            if (isValid)
            {
                //Archive details
                var archiveDetail = _archiveflowService.GetArchiveSectionComments(ArchiveNumber, sectionId, ActionTypeId);
                _logger.LogInformation("GetArchiveSectionComments: " + System.Web.HttpUtility.HtmlEncode(ArchiveNumber + sectionId + ActionTypeId));
                return Ok(archiveDetail);
            }
            else
            {
                _logger.LogInformation("Unauthorized Request Details: Action: GetLinkedArchiveStatus, Object " + System.Web.HttpUtility.HtmlEncode(userAlias));
                return Forbid();
            }
        }

        [HttpPost]
        [Route("createOrUpdateArchiveActions")]
        public IActionResult CreateOrUpdateArchiveActions(ArchiveFlowDetails aFlowdetails)
        {
            var id = GetFuntionID("Access Archive");
            var isValid = false;
            aFlowdetails = (ArchiveFlowDetails)_utilityServie.IsUserAuthorizedAndInputIsValid(aFlowdetails.ArchiveNumber, id, userAlias, aFlowdetails, out isValid);
            if (isValid)
            {
                //Archive details
                aFlowdetails.CreatedBy = userAlias;
                var archiveDetail = _archiveflowService.CreateOrUpdateArchiveActions(aFlowdetails);
                _logger.LogInformation("CreateOrUpdateArchiveActions: " + System.Web.HttpUtility.HtmlEncode(aFlowdetails));
                return Ok(archiveDetail);
            }
            else
            {
                _logger.LogInformation("Unauthorized Request Details: Action: DeleteArchive, Object " + System.Web.HttpUtility.HtmlEncode(userAlias));
                return Forbid();
            }
        }
        [HttpGet]
        [Route("GetResubmissionReasonsforArchive")]
        public IActionResult GetResubmissionReasonsforArchive(string ArchiveNumber)
        {
            var id = GetFuntionID("Access Archive");
            var isValid = _utilityServie.IsUserAuthorizedtoPerformAction(ArchiveNumber, id, userAlias);
            if (isValid)
            {
                var archiveDetail = _archiveflowService.GetResubmissionReasonsforArchive(ArchiveNumber);
                _logger.LogInformation("GetResubmissionReasonsforArchive: " + System.Web.HttpUtility.HtmlEncode(ArchiveNumber));
                return Ok(archiveDetail);
            }
            else
            {
                _logger.LogInformation("Unauthorized Request Details: Action: GetLinkedArchiveStatus, Object " + System.Web.HttpUtility.HtmlEncode(userAlias));
                return Forbid();
            }
        }

        private int GetFuntionID(string functionName)
        {
            LambdaLogger.Log("cacheLog43234432:" + functionName);
            _logger.LogInformation("cacheLog12798778:" + System.Web.HttpUtility.HtmlEncode(functionName));
            var Id = roleFunctions.Where(e => e.FunctionName == functionName).Select(x => x.Id).FirstOrDefault();
            _logger.LogInformation("functionId: " + System.Web.HttpUtility.HtmlEncode(Id.ToString()));
            return Id;
        }
    }
}