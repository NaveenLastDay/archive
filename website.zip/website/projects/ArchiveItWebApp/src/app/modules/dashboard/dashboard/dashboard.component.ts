import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { HomePageService } from '../../../services/homepage.service';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
// import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit, OnDestroy {
  countForAccessRequests: any;
  employeeUniqueIdentifier: string;
  tooltipInfoRequiringApproval: string = 'Archives for you to approve/reject where you are the approver (Archive Manager, Archive Partner, PPD, or NPPD). Archives should be approved by the EDCD.';
  tooltipInfoPendingSubmission: string = 'Archives not yet submitted where you are a member of the Archive team. Archives should be submitted and approved by the EDCD.';
  tooltipInfoRequestAccess: string = 'Requests for you to approve/reject  temporary access to archives where you are a member of the Archive team. If these are not addressed within 2 days, the action item will be removed from pending requests.';
  tooltipInfoForm3283s: string = 'Requests for you to approve/reject an extension of the archive due date where you are the approver (Archive Partner, PIC, or PPD). These should be addressed as soon as possible.';
  tooltipInfoRetensionExceptions: string = 'Requests for you to approve/reject  exceptions to standard retention of the archive records. These should be addressed as soon as possible.';
  tooltipInfoArchiveDeletions: string = 'Requests for you to approve/reject the deletion of an archive where you are the Archive Partner. These should be addressed as soon as possible.';
  tooltipInfoComplianceMetrics: string = 'Your compliance metrics is the percentage of archives that were approved on time where you are a member of the Archive team.';
  tooltipInfoArchivesAwaitingApproval: string = 'Submitted or resubmitted archives ready for approval where you are a member of the Archive team.';
  tilesCount: any;
  archivesRequiringApproval: any;
  archivesAwaitingApprovals: any;
  complianceMetrics: any;
  form3283SApprovals: any;
  archivesRequiringApprovals: any;
  pendingSubmissions: any;
  retensionExceptions: any;
  archiveDeletions: any;
  toggleValueForSwitch: boolean = false;
  showZeroActions: boolean;
  tilesData: any;
  hideToggleSwitch: boolean = false;
  color: any;
  archiveDeletionscolor: any;
  archivesAwaitingApprovalscolor: any;
  complianceMetricscolor: any;
  pendingSubmissionscolor: any;
  retensionExceptionscolor: any;
  archivesRequiringApprovalscolor: any;
  form3283SApprovalscolor: any;
  accessRequests: any;
  accessRequestscolor: any;
  countForcards: any;

  constructor(private router: Router, private homePageService: HomePageService, private adalSvc: MsAdalAngular6Service) {
    // this.SpinnerService.show();
    this.employeeUniqueIdentifier = this.adalSvc.LoggedInUserEmail.split('@')[0];
    // this.homePageService.GetArchiveAccessRequestCountForApproval(this.employeeUniqueIdentifier).subscribe((data) => {
    //   this.countForAccessRequests = data;
    //   if(this.countForAccessRequests && this.countForAccessRequests.actionItemCount !== 0) {
    //     this.hideToggleSwitch = true;
    //   } else {
    //     this.hideToggleSwitch = false;
    //   }
    // });
    var data = JSON.parse(localStorage.getItem('dashboardCountData'));
      this.tilesData = data;
      // data.complianceMetricsForUser.forEach((ele)=> {
      //   if(ele.count !== 0) {
      //     this.hideToggleSwitch = true;
      //   } else {
      //     this.hideToggleSwitch = false;
      //   }
      // });
      this.countForcards = data.complianceMetricsForUser.filter((x) => x.count == 0);
      if (this.countForcards.length >= 2) {
        let element = document.getElementById("content");
        element.classList.add("custom-dashboard-appmainbody");
      } else {
        let element = document.getElementById("content");
        element.classList.remove("custom-dashboard-appmainbody");
      }
      if (this.countForcards.length > 0) {
        this.hideToggleSwitch = false;
      } else {
        this.hideToggleSwitch = true;
      }
      data.complianceMetricsForUser.forEach((ele) => {
        if (ele.category == "AccessRequests") {
          this.accessRequests = ele.count;
          this.accessRequestscolor = ele.color;
        }
        if (ele.category == "ArchiveDeletions") {
          this.archiveDeletions = ele.count;
          this.archiveDeletionscolor = ele.color;
        }
        if (ele.category == "ArchivesAwaitingApprovals") {
          this.archivesAwaitingApprovals = ele.count;
          this.archivesAwaitingApprovalscolor = ele.color;
        }
        if (ele.category == "ComplianceMetrics") {
          this.complianceMetrics = ele.count;
          this.complianceMetricscolor = ele.color;
        }
        if (ele.category == "Form3283SApprovals") {
          this.form3283SApprovals = ele.count;
          this.form3283SApprovalscolor = ele.color;
        }
        if (ele.category == "ArchivesRequiringApprovals") {
          this.archivesRequiringApprovals = ele.count;
          this.archivesRequiringApprovalscolor = ele.color;
        }
        if (ele.category == "PendingSubmissions") {
          this.pendingSubmissions = ele.count;
          this.pendingSubmissionscolor = ele.color;
        }
        if (ele.category == "RetensionExceptions") {
          this.retensionExceptions = ele.count;
          this.retensionExceptionscolor = ele.color;
        }
      });
      // this.SpinnerService.hide();
    
  }

  ngOnInit() {
    this.checkSize();
  }
  openForm3283(event) {
    // if (event !== 0) {
      this.router.navigate(['/dashboard/dashboardHome/form3283']);
    // } else {
    //   return false;
    // }
  }
  openAccessReq(event) {
    // if (event !== 0) {
      this.router.navigate(['/dashboard/dashboardHome/pendingAccess']);
    // } else {
    //   return false;
    // }
  }
  openAwaitingApproval(event) {
    // if (event !== 0) {
      this.router.navigate(['/dashboard/dashboardHome/awaitingapproval']);
    // } else {
    //   return false;
    // }
  }
  openRequiringApproval(event) {
    // if (event !== 0) {
      this.router.navigate(['/dashboard/dashboardHome/requiringapproval']);
    // } else {
    //   return false;
    // }
  }
  openPendingSubmission(event) {
    // if (event !== 0) {
      this.router.navigate(['/dashboard/dashboardHome/pendingsubmission']);
    // } else {
    //   return false;
    // }
  }
  svgOnClick() {
    console.log('svg click');
  }
  toggleSwitch(event) {
    console.log('toggle data', event);
    if (event == false) {
      this.showZeroActions = true;
      let element3 = document.getElementById("content");
      element3.classList.remove("custom-dashboard-appmainbody");
      // let element2 = document.getElementById("applicationFooter_ID");
      // element2.classList.remove("application-footer-b-0");
    } else {
      if (this.countForcards.length >= 2) {
        let element = document.getElementById("content");
        element.classList.add("custom-dashboard-appmainbody");
        // let element2 = document.getElementById("applicationFooter_ID");
        // element2.classList.add("application-footer-b-0");
      } else {
        let element = document.getElementById("content");
        element.classList.remove("custom-dashboard-appmainbody");
        // let element2 = document.getElementById("applicationFooter_ID");
        // element2.classList.remove("application-footer-b-0");
      }
      this.showZeroActions = false;
    }
  }
  checkSize() {
    console.log(window.devicePixelRatio);
    if ((window.devicePixelRatio > 1.34) && (window.devicePixelRatio < 1.5)) {
      let element = document.getElementById("applicationFooter_ID");
      element.classList.add("custom-app-footer");
      let element1 = document.getElementById("applicationFooter_ID");
      element1.classList.remove("custom-app-footertxt");
      let element2 = document.getElementById("applicationFooter_ID");
      element2.classList.remove("custom-app-footertxt1");
      let element3 = document.getElementById("applicationFooter_ID");
      element3.classList.remove("custom-app-footertxt2");
    } else if ((window.devicePixelRatio > 1.2) && (window.devicePixelRatio < 1.3)) {
      let element = document.getElementById("applicationFooter_ID");
      element.classList.add("custom-app-footertxt1");
      let element2 = document.getElementById("applicationFooter_ID");
      element2.classList.remove("custom-app-footer");
      let element1 = document.getElementById("applicationFooter_ID");
      element1.classList.remove("custom-app-footertxt");
      let element3 = document.getElementById("applicationFooter_ID");
      element3.classList.remove("custom-app-footertxt2");
    } else if((window.devicePixelRatio == 1.125) || (window.devicePixelRatio == 1)) {
      let element1 = document.getElementById("applicationFooter_ID");
      element1.classList.add("custom-app-footertxt2");
      let element = document.getElementById("applicationFooter_ID");
      element.classList.remove("custom-app-footer");
      let element4 = document.getElementById("applicationFooter_ID");
      element4.classList.add("custom-app-footertxt");
      let element2 = document.getElementById("applicationFooter_ID");
      element2.classList.remove("custom-app-footertxt1");
    }
    else {
      let element = document.getElementById("applicationFooter_ID");
      element.classList.remove("custom-app-footer");
      let element1 = document.getElementById("applicationFooter_ID");
      element1.classList.add("custom-app-footertxt");
      let element2 = document.getElementById("applicationFooter_ID");
      element2.classList.remove("custom-app-footertxt1");
      let element3 = document.getElementById("applicationFooter_ID");
      element3.classList.remove("custom-app-footertxt2");
    }
  }
  ngOnDestroy() {
    let element = document.getElementById("applicationFooter_ID");
    element.classList.remove("custom-app-footer");
    let element1 = document.getElementById("applicationFooter_ID");
    element1.classList.remove("custom-app-footertxt");
    let element2 = document.getElementById("applicationFooter_ID");
    element2.classList.remove("custom-app-footertxt1");
    let element3 = document.getElementById("content");
    element3.classList.remove("custom-dashboard-appmainbody");
    let element4 = document.getElementById("applicationFooter_ID");
    element4.classList.remove("application-footer-b-0");
    let element5 = document.getElementById("applicationFooter_ID");
    element5.classList.remove("custom-app-footertxt2");
  }
  // checkSize() {
  //   console.log('dashboard check size',window.devicePixelRatio);
  //   if(window.devicePixelRatio < 1.5) {
  //     let element = document.getElementById("dasboard_windowsize");
  //   element.classList.add("ml-18");
  //   } else {
  //     let element = document.getElementById("dasboard_windowsize");
  //     element.classList.remove("ml-18");
  //   }
  // }
  // goToAccessApproval() {
  //   this.router.navigate(['/archive/dashboard/pendingaccessapproval']);
  // }
}

