import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class ArchiveSearchService {

 
  constructor(private _http: HttpClient) { }
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'

    }),

   
  }
  public getArchiveSearchResults(seacrhTerm:string,category:any):Observable<any>{
    return this._http.get<any[]>("ArchiveSearch/GetSearchResults?search=" + seacrhTerm + "&category="+ category +"");
  }
}
