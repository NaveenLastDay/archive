﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Amazon.Lambda.Core;
using Deloitte.AIFA.CloudServices;
using Deloitte.AIFA.DomainServices.Contracts;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Deloitte.AIFA.Lambda.Archive.Controllers
{
    [Route("api/user")]
    [ApiController]
    public class UserController : ControllerBase
    {
        IUserService _userService;
        ILogger _logger { get; set; }
        private readonly IHttpContextAccessor _contextAccessor;
        private string userAlias;

        public UserController(IHttpContextAccessor contextAccessor, IUserService userService, ILogger<UserController> logger)
        {
            _logger = logger;
            _userService = userService;
            this._contextAccessor = contextAccessor;
            _logger.LogError("User Controller Initiated");

            try
            {
                LambdaLogger.Log("Inside User Controller");
                var _context = this._contextAccessor.HttpContext;
                //this.token = _context.Request.Headers["Authorization"];
                //LambdaLogger.Log("Requested token in User Controller: " + this.token);
                //this.token = this.token.Substring("bearer ".Length).Trim();
                //this.inputAlias = new JWTService().GetClaimFromJWT(token);
                //LambdaLogger.Log("UserAlias from User Controller: " + this.inputAlias);

                try
                {
                    LambdaLogger.Log("Error in controller - User");

                    if (_context?.User?.Claims.Any() == true)
                    {
                        LambdaLogger.Log("Has claims in User Controller");
                        foreach (var claim in _context?.User?.Claims)
                        {
                            //LambdaLogger.Log(claim.Type);
                            if (claim.Type == "UserAlias")
                            {
                                userAlias = claim.Value.Split('@')[0].ToString();
                            }
                            LambdaLogger.Log(userAlias);
                        }
                    }
                    else
                    {
                        LambdaLogger.Log("Has No claims");
                    }

                }
                catch (Exception ex)
                {
                    LambdaLogger.Log("Error in User Controller: " + ex.Message);
                }

            }
            catch (Exception e)
            {
                LambdaLogger.Log("Error in controller: " + e.Message);
            }

        }

        [HttpGet]
        [Route("FetchLoggedInUser")]
        public IActionResult FetchLoggedInUser()
        {
            // userDetails
            var userDetail = _userService.FetchLoggedInUser(userAlias);
            _logger.LogInformation("IsUserAdmin Method: UserAlias" + userAlias);
            return Ok(userDetail);
        }


        [HttpGet]
        [Route("GetRoleMappingsForUser")]
        public IActionResult GetRoleMappingsForUser(string ArchiveNumber)
        {
            // userDetails
            var roleMappingDetailForUser = _userService.GetRoleMappingsForUser(this.userAlias, ArchiveNumber);
            _logger.LogInformation("Get RoleMapping details for user" + roleMappingDetailForUser);
            return Ok(roleMappingDetailForUser);
        }

		[HttpGet]
		[Route("GetFooterConfigurationData")]
		public IActionResult GetFooterConfigurationData()
		{
			_logger.LogInformation("Getting hyperlinks.");
			var footerConfigurationData = _userService.GetFooterConfigurationData();
			_logger.LogInformation("Received hyperlinks.");
			return Ok(footerConfigurationData);
		}

        [HttpGet]
        [Route("FetchUserofflinePermissions")]
        public IActionResult FetchUserofflinePermissions()
        {
           
            var userDetail = _userService.FetchUserofflinePermissions(userAlias);
            _logger.LogInformation("FetchUserofflinePermissions Method: UserAlias" + userAlias);
            return Ok(userDetail);
        }
    }
}