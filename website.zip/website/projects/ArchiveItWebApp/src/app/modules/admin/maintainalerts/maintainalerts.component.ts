import { Component, OnInit, ViewChild,Renderer2,Inject } from '@angular/core';
import { Router } from '@angular/router';
import { MaintainalersService } from '../../../services/maintainalers.service';
import { ModalService } from '../../shared/modal';
import { NgxSpinnerService } from "ngx-spinner";
import { MatTable, MatSlideToggleChange } from '@angular/material';
import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
import { LoginuserdetailsService } from '../../../services/loginuserdetails.service';
import { CKEditorModule } from 'ng2-ckeditor';
import { NotifierService } from "angular-notifier";
import { DOCUMENT } from '@angular/common';

@Component({
  selector: 'app-maintainalerts',
  templateUrl: './maintainalerts.component.html',
  styleUrls: ['./maintainalerts.component.css']
})
export class MaintainalertsComponent implements OnInit {
  data: any;
  dataSource: any;
  AlertId: number;
  AlertTitle: string = '';
  Alert: string = '';
  IsHighSeverityAlert: boolean = false;
  IsEnable: boolean = true;
  display = 'none';
  popUpHeaderText: string;
  public selectedVal: string;
  public selectedValEnable: string;
  EditObj: any;
  checkedStatus: boolean = false;
  checkedSeverity: boolean = false;
  TitleCount: number = 0;
  BodyCount: number = 0;
  displayedColumns: string[] = ['Sort', 'Severity', 'Title','spacetitle', 'Body', 'spacebody','LastModified','StatusEdit', 'Edit', 'Delete'];
  ApplicationID: number;
  Order: number;
  PublishDate: Date;
  IsDisabled: boolean = true;
  checkedStatusEdit: boolean;
  DeleteObj: any;
  CreatedBy: number;
  AlertCount: number;
  userAlias: string='';

  @ViewChild(MatTable, { static: true }) table: MatTable<any>;
  myArray: any[];
  previousOrder: number;
  previousItem: any;
  NewSortOrder: number;
  userAlerts: any;
  

  constructor(private router: Router, private service: MaintainalersService,
    private loginuserservice: LoginuserdetailsService,
    private modalService: ModalService, private SpinnerService: NgxSpinnerService,private notifier: NotifierService,private _renderer2: Renderer2,@Inject(DOCUMENT) private _document: Document ) { 
      
    }

  /*text editor config*/

 

  ckeditorConfig:CKEditorModule={
          allowedContent: false,
          extraPlugins:'autolink',
          forcePasteAsPlainText: true,
          toolbar: 'Full',
          height:"100px",
          removeButtons: 'Source,Save,ImageButton,NewPage,Preview,Print,Templates,Cut,Copy,Paste,PasteText,PasteFromWord,Undo,Redo,Find,Replace,SelectAll,Scayt,Form,Checkbox,Radio,TextField,Textarea,Select,Button,HiddenField,Strike,Subscript,Superscript,CopyFormatting,RemoveFormat,Outdent,Indent,CreateDiv,Blockquote,BidiLtr,BidiRtl,Language,Unlink,Anchor,Flash,Table,HorizontalRule,Smiley,SpecialChar,PageBreak,Iframe,Maximize,ShowBlocks,About,ExportPdf',
          removePlugins : 'elementspath'
      };
    


  ngOnInit() {
    this.selectedVal = 'No';
    this.selectedValEnable = 'No';
    this.GetAlerts();
    this.getUserAlias();

    const s = this._renderer2.createElement('script');
    s.src = 'https://cdn.ckeditor.com/4.15.1/full-all/ckeditor.js';
    s.text = ``;
    this._renderer2.appendChild(this._document.body, s);
    }
  // Fetching Login User Alias

  getUserAlias() {
    this.userAlias = this.loginuserservice.GetUserAlias();
  }
   
 

  // Drag and Drop for sorting - start
  dropTable(event: CdkDragDrop<any[]>) {
    if (this.isInvalidDragEvent) {
      this.isInvalidDragEvent = false;
      return;
    }
    const prevIndexofCurrentItem = this.dataSource.findIndex((d) => d === event.item.data);
    var previousItemArray = this.dataSource[event.currentIndex]; // gets the previous item into which the item is dragged
    moveItemInArray(this.dataSource, prevIndexofCurrentItem, event.currentIndex);

    this.table.renderRows();

    this.AlertId = event.item.data.id;
    this.previousOrder = event.item.data.order; // will get previous Order
    this.NewSortOrder = previousItemArray.order; // will get current Order
    this.SortAlert();

  }

  isInvalidDragEvent: boolean = false;
  onInvalidDragEventMouseDown() {
    this.isInvalidDragEvent = true;
  }
  dragStarted(event) {
    if (this.isInvalidDragEvent) {
      document.dispatchEvent(new Event('mouseup'));
    }

  }

  SortAlert() {
    var parameter = {
      "Id": this.AlertId,
      "Order": this.NewSortOrder,
      "UserAlias": ''
    }
    var myobjstr = JSON.stringify(parameter);
    //this.SpinnerService.show();
    this.service.SortSystemAlert(myobjstr).subscribe(
      data => {
        var isSorted = data;
        if (isSorted == true) {
          this.GetAlerts();
         // this.SpinnerService.hide();
        }


      });

  }

  // Drag and Drop for sorting -end

  onKeyUp(event) {

    this.TitleCount = 80 - event.target.value.length;

  }


  onchangeBody(boxInput) {
    // debugger;
    var bodytext=boxInput.replace(/<\/?[^>]+(>|$)/g,"").trim('')
    this.BodyCount = 600 - bodytext.length;
  }

  GetAlerts() {
   // this.SpinnerService.show();
    this.service.GetSystemAlerts().subscribe
      (data => {
        this.dataSource = data;
        this.myArray = data;
        this.AlertCount = data.length;
      //  this.SpinnerService.hide();
      }

      );
  }
  onChangeStatusEdit(val, obj) {
    this.checkedStatusEdit = val.checked; 
    if (this.checkedStatusEdit == true) {
      this.IsDisabled = false;
    }
    else {
      this.IsDisabled = true;
    }

    var parameter = {
      "Id": obj.id,
      "ApplicationID": obj.applicationID,
      "Body": obj.body,
      "IsDisabled": this.IsDisabled,
      "IsHighSeverity": obj.isHighSeverity,
      "Order": obj.order,
      "PublishDate": obj.publishDate,
      "Title": obj.title,
      "CreatedBy": ''
    }

    var myobjstr = JSON.stringify(parameter);
    //this.SpinnerService.show();
    this.service.UpdateSystemAlert(myobjstr).subscribe(
      data => {
        var editData = data;
        this.GetAlerts();
        this.service.SyncAlerts();
        //this.SpinnerService.hide();
      });

  }


  onChangeStatus(obj) {
    this.checkedStatus = obj;

  }
  onChangeSeverity(obj) {
    this.IsHighSeverityAlert = obj;
    this.checkedSeverity = this.IsHighSeverityAlert;
  }


  openModalDialog(Action, obj) {
    if (Action == "Add" || Action == "Update") {
      if (Action == "Add") {

        this.popUpHeaderText = "Create alert";
        this.AlertId = 0;
        this.AlertTitle = "";
        this.Alert = "";
        this.TitleCount = 0;
        this.BodyCount = 0;
        this.checkedStatus = false;
        this.checkedSeverity = false;


      }
      else {
        // debugger;
        this.popUpHeaderText = "Edit Alert";
        this.AlertTitle = obj.title;
        this.Alert = obj.body;
        this.AlertId = obj.id;
        this.EditObj = obj;
        this.ApplicationID = obj.applicationID;
        this.PublishDate = obj.publishDate;
        this.Order = obj.order;
        this.CreatedBy = obj.createdBy;
        if (obj.isDisabled == true) {
          this.checkedStatus = false;
        }
        else {
          this.checkedStatus = true;
        }

        this.checkedSeverity = obj.isHighSeverity;
        this.TitleCount = 80 - obj.title.length;
        var bodytext=obj.body.replace(/<\/?[^>]+(>|$)/g,"").trim('');
        this.BodyCount = 600 - bodytext.length;
      }

      this.modalService.openWithCustomWidth('add-alert-modal', "595");
    }

    if (Action == "Delete") {
      this.modalService.openWithCustomWidth('delete-alert-modal', "500");

      this.AlertId = obj.id;
      this.CreatedBy = obj.createdBy;
      this.DeleteObj = obj;

    }
    this.notifier.hideAll();
  }

  closeModalDialog(Action) {
    this.modalService.close(Action);
  }

  ResetForm() {
    this.AlertId = 0;
    this.AlertTitle = "";
    this.Alert = "";
    this.TitleCount = 0;
    this.BodyCount = 0;
    this.checkedStatus = false;
    this.checkedSeverity = false;
  }



  SaveClick() {
    if(this.BodyCount>=0)
    {
    if (this.checkedStatus == true) {
      this.IsDisabled = false;
    }
    else {
      this.IsDisabled = true;
    }
    if (this.popUpHeaderText == "Create alert") {

      this.AddNewAlert();
    }

    else {
      this.EditAlert();
    }
  }
  else
  {
    this.modalService.openWithCustomWidth('add-alert-modal', "595");
    this.notifier.notify("error","Body text cannot be more than 600 characters");
    
  }
}

  AddNewAlert() {

    var parameter =
    {
      "Id": this.AlertId,
      "Title": this.AlertTitle,
      "Body": this.Alert,
      "PublishDate": new Date(),
      "ApplicationID": "1",
      "IsHighSeverity": this.checkedSeverity,
      "IsDisabled": this.IsDisabled,
      "UserAlias": ''

    }

    var myobjstr = JSON.stringify(parameter);
    //this.SpinnerService.show();
    this.service.CreateSystemAlert(myobjstr).subscribe(
      data => {
        if( data != undefined){
          this.dataSource.unshift(data);
          this.table.renderRows();
          this.service.SyncAlerts();
          this.GetAlerts();
        //  this.SpinnerService.hide();
        }
        else{
          this.notifier.notify("error","Error Occurred.Please contact administrator");
        }

      }
    );

  
  }

  EditAlert() {
    var parameter =
    {
      "Id": this.AlertId,
      "ApplicationID": "1",
      "Body": this.Alert,
      "IsDisabled": this.IsDisabled,
      "IsHighSeverity": this.checkedSeverity,
      "PublishDate": this.PublishDate,
      "Title": this.AlertTitle,
      "UserAlias": ''
    }
    var myobjstr = JSON.stringify(parameter);
   // this.SpinnerService.show();
    this.service.UpdateSystemAlert(myobjstr).subscribe(
      data => {
       var editData = data;
        this.service.SyncAlerts();
        this.GetAlerts();
       // this.SpinnerService.hide();
      });

  }

  delete() {
    var parameter = {

      "Id": this.AlertId,
      "UserAlias": ''
    }

    var myobjstr = JSON.stringify(parameter);
   // this.SpinnerService.show();
    this.service.DeleteSystemAlert(myobjstr).subscribe(
      data => {
        if (data == true) {
          this.dataSource = this.dataSource.filter(i => i !== this.DeleteObj)
          this.GetAlerts();
         // this.SpinnerService.hide();
        }

      }
    );

  }

  OnClick(PageUrl) {
    this.router.navigate(["/" + PageUrl + ""]);
  }

}