﻿
using Deloitte.AIFA.DomainEntities;
using Deloitte.AIFA.DomainEntities.Report;
using Deloitte.AIFA.Helpers.ExcelGenerator;
using System;
using System.Collections.Generic;

namespace Deloitte.AIFA.DomainServices.Contracts
{
    public interface IRateThisAppService
    {
        int GetRatingByUserAlias(string userAlias, int applicationId);
        string SubmitRating(RatingSubmissionInfo ratingInfo);
    }
}
