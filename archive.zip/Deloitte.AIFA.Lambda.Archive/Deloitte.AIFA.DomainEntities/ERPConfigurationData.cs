﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
    public class ERPConfigurationData
    {
        public string ERPDataKey { get; set; }
        public string ERPDataValue { get; set; }
    }
}
