﻿using Deloitte.AIFA.DataModels;
using Deloitte.AIFA.DBHelper;
using Deloitte.AIFA.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace Deloitte.AIFA.Repositories.Transformers
{
    public class ERPTransformer : BaseTransformer<ERPConfigurationDataModel>
    {
        public enum ERPConfigurationField
        {
            keys,
            ERPDataKey,
            ERPDataValue
        }
        public enum ERPConfigurationFieldParameters
        {
            [CreateField(Name = "p_Keys", Direction = ParameterDirection.Input, Type = DbType.String)]
            p_Keys
        }
        public enum ERPConfigurationDataOutputFields
        {
            ERPDataKey,
            ERPDataValue
        }
        internal override ERPConfigurationDataModel TransformElement(IDataReader dr, Func<IDataReader, ERPConfigurationDataModel, ERPConfigurationDataModel> bindExtraFields = null)
        {
            return new ERPConfigurationDataModel
            {
                ERPDataKey = (dr[ERPConfigurationDataOutputFields.ERPDataKey.ToString()] is DBNull) ? string.Empty : dr[ERPConfigurationDataOutputFields.ERPDataKey.ToString()].ToString(),
                ERPDataValue = (dr[ERPConfigurationDataOutputFields.ERPDataValue.ToString()] is DBNull) ? string.Empty : dr[ERPConfigurationDataOutputFields.ERPDataValue.ToString()].ToString()
            };
        }


        #region EngagementPersonnelInfo


        public enum EngagementPersonnelInfoParameter
        {
            [CreateField(Name = "p_ArchiveNumber", Direction = ParameterDirection.Input, Type = DbType.String)]
            ArchiveNumber,
            [CreateField(Name = "p_EmailAlias", Direction = ParameterDirection.Input, Type = DbType.String)]
            EmailAlias,
            [CreateField(Name = "PPDAlias", Direction = ParameterDirection.Output, Type = DbType.String)]
            PPDAlias
        }

        public enum EngagementPersonnelInfoOutputFields
        {
            EmployeeName,
            Office,
            Business,
            EmployeeAlias,
            IsManualSubmission,
			CreatedDate
		}

        public class EngagementPersonnelInfoTransformer : BaseTransformer<EngagementPersonnelInfoModel>
        {
            internal override EngagementPersonnelInfoModel TransformElement(IDataReader dr, Func<IDataReader, EngagementPersonnelInfoModel, EngagementPersonnelInfoModel> bindExtraFields = null)
            {
                return new EngagementPersonnelInfoModel
                {
                    EmployeeName = (dr[EngagementPersonnelInfoOutputFields.EmployeeName.ToString()] is DBNull) ? string.Empty : dr[EngagementPersonnelInfoOutputFields.EmployeeName.ToString()].ToString(),
                    Office = (dr[EngagementPersonnelInfoOutputFields.Office.ToString()] is DBNull) ? string.Empty : dr[EngagementPersonnelInfoOutputFields.Office.ToString()].ToString(),
                    Business = (dr[EngagementPersonnelInfoOutputFields.Business.ToString()] is DBNull) ? string.Empty : dr[EngagementPersonnelInfoOutputFields.Business.ToString()].ToString(),
                    EmployeeAlias = (dr[EngagementPersonnelInfoOutputFields.EmployeeAlias.ToString()] is DBNull) ? string.Empty : dr[EngagementPersonnelInfoOutputFields.EmployeeAlias.ToString()].ToString(),
                    IsManualSubmission = (dr[EngagementPersonnelInfoOutputFields.IsManualSubmission.ToString()] is DBNull) ? 0 : int.Parse(dr[EngagementPersonnelInfoOutputFields.IsManualSubmission.ToString()].ToString()),
					CreatedDate = (dr[EngagementPersonnelInfoOutputFields.CreatedDate.ToString()] is DBNull) ? DateTime.MinValue : Convert.ToDateTime(dr[EngagementPersonnelInfoOutputFields.CreatedDate.ToString()].ToString()),

				};
            }
        }

        #endregion EngagementPersonnelInfo

        #region ERPDetails
        public enum ERPDetailFieldParameter
        {
            [CreateField(Name = "In_searchquery", Direction = ParameterDirection.Input, Type = DbType.String)]
            searchquery,
        }

        public enum ERPDetailOutputParameters
        {
            Personnel,
            Fullname,
            Officelocation,
            Business,
            Designation

        }
        public class ERPdetailTransformer : BaseTransformer<ERPmodel>
        {
            internal override ERPmodel TransformElement(IDataReader dr, Func<IDataReader, ERPmodel, ERPmodel> bindExtraFields = null)
            {
                return new ERPmodel
                {
                    Personnel = (dr[ERPDetailOutputParameters.Personnel.ToString()] is DBNull) ? string.Empty : dr[ERPDetailOutputParameters.Personnel.ToString()].ToString(),
                    Fullname = (dr[ERPDetailOutputParameters.Fullname.ToString()] is DBNull) ? string.Empty : dr[ERPDetailOutputParameters.Fullname.ToString()].ToString(),
                    Officelocation = (dr[ERPDetailOutputParameters.Officelocation.ToString()] is DBNull) ? string.Empty : dr[ERPDetailOutputParameters.Officelocation.ToString()].ToString(),


                    Business = (dr[ERPDetailOutputParameters.Business.ToString()] is DBNull) ? string.Empty : dr[ERPDetailOutputParameters.Business.ToString()].ToString(),
                    Designation = (dr[ERPDetailOutputParameters.Designation.ToString()] is DBNull) ? string.Empty : dr[ERPDetailOutputParameters.Designation.ToString()].ToString(),


                };
            }


        }
        #endregion ERPdetails

        #region RemoveEngagementPersonnel
        public enum RemoveEngagementPersonnelOutputFields
        {
            SubmissionPackageID,
            EngagementPersonnel,
            DeletedBy,
            DeletedDate,
            TotalPersonnelsProcessed,
            ArchiveNumber
        }

        public enum RemoveEngagementPersonnelFieldParameter
        {
            [CreateField(Name = "In_ArchiveNumber", Direction = ParameterDirection.Input, Type = DbType.String)]
            ArchiveNumber,
            [CreateField(Name = "In_EngagementPersonnel", Direction = ParameterDirection.Input, Type = DbType.String)]
            EngagementPersonnel,
            [CreateField(Name = "In_DeletedBy", Direction = ParameterDirection.Input, Type = DbType.String)]
            DeletedBy,
            [CreateField(Name = "In_DeletedDate", Direction = ParameterDirection.Input, Type = DbType.DateTime)]
            DeletedDate,
        }
        public class RemoveEngagementPersonnelTransformer : BaseTransformer<DistributionListModel>
        {
            internal override DistributionListModel TransformElement(IDataReader dr, Func<IDataReader, DistributionListModel, DistributionListModel> bindExtraFields = null)
            {
                return new DistributionListModel
                {
                    TotalPersonnelsProcessed = (dr[RemoveEngagementPersonnelOutputFields.TotalPersonnelsProcessed.ToString()] is DBNull) ? 0 : int.Parse(dr[RemoveEngagementPersonnelOutputFields.TotalPersonnelsProcessed.ToString()].ToString()),
                    SubmissionPackageID = (dr[RemoveEngagementPersonnelOutputFields.SubmissionPackageID.ToString()] is DBNull) ? 0 : int.Parse(dr[RemoveEngagementPersonnelOutputFields.SubmissionPackageID.ToString()].ToString()),
                    EngagementPersonnel = (dr[RemoveEngagementPersonnelOutputFields.EngagementPersonnel.ToString()] is DBNull) ? string.Empty : dr[RemoveEngagementPersonnelOutputFields.EngagementPersonnel.ToString()].ToString(),
                    DeletedBy = (dr[RemoveEngagementPersonnelOutputFields.DeletedBy.ToString()] is DBNull) ? string.Empty : dr[RemoveEngagementPersonnelOutputFields.DeletedBy.ToString()].ToString(),
                    DeletedDate = (dr[RemoveEngagementPersonnelOutputFields.DeletedDate.ToString()] is DBNull) ? DateTime.MinValue : Convert.ToDateTime(dr[RemoveEngagementPersonnelOutputFields.DeletedDate.ToString()].ToString()),
                    ArchiveNumber = (dr[RemoveEngagementPersonnelOutputFields.ArchiveNumber.ToString()] is DBNull) ? string.Empty : dr[RemoveEngagementPersonnelOutputFields.ArchiveNumber.ToString()].ToString(),
                };
            }
        }
        #endregion RemoveEngagementPersonnel

        #region AddEngagementPersonnels
        public enum AddEngagementPersonnelsOutputFields
        {
            SubmissionPackageID,
            Personnels,
            IsManualSubmission,
            CreatedBy,
            CreatedDate,
            TotalPersonnelsProcessed,
            ArchiveNumber
        }

        public enum AddEngagementPersonnelsFieldParameter
        {
            [CreateField(Name = "In_ArchiveNumber", Direction = ParameterDirection.Input, Type = DbType.String)]
            ArchiveNumber,
            [CreateField(Name = "In_Personnels", Direction = ParameterDirection.Input, Type = DbType.String)]
            Personnels,
            [CreateField(Name = "In_IsManualSubmission", Direction = ParameterDirection.Input, Type = DbType.Boolean)]
            IsManualSubmission,
            [CreateField(Name = "In_CreatedBy", Direction = ParameterDirection.Input, Type = DbType.String)]
            CreatedBy,
            [CreateField(Name = "In_CreatedDate", Direction = ParameterDirection.Input, Type = DbType.DateTime)]
            CreatedDate,
        }
        public class AddEngagementPersonnelsTransformer : BaseTransformer<DistributionListModel>
        {
            internal override DistributionListModel TransformElement(IDataReader dr, Func<IDataReader, DistributionListModel, DistributionListModel> bindExtraFields = null)
            {
                return new DistributionListModel
                {
                    TotalPersonnelsProcessed = (dr[AddEngagementPersonnelsOutputFields.TotalPersonnelsProcessed.ToString()] is DBNull) ? 0 : int.Parse(dr[AddEngagementPersonnelsOutputFields.TotalPersonnelsProcessed.ToString()].ToString()),
                    SubmissionPackageID = (dr[AddEngagementPersonnelsOutputFields.SubmissionPackageID.ToString()] is DBNull) ? 0 : int.Parse(dr[AddEngagementPersonnelsOutputFields.SubmissionPackageID.ToString()].ToString()),
                    Personnels = (dr[AddEngagementPersonnelsOutputFields.Personnels.ToString()] is DBNull) ? string.Empty : dr[AddEngagementPersonnelsOutputFields.Personnels.ToString()].ToString(),
                    IsManualSubmission = (dr[AddEngagementPersonnelsOutputFields.IsManualSubmission.ToString()] is DBNull) ? false : Convert.ToBoolean(dr[AddEngagementPersonnelsOutputFields.IsManualSubmission.ToString()]),
                    CreatedBy = (dr[AddEngagementPersonnelsOutputFields.CreatedBy.ToString()] is DBNull) ? string.Empty : dr[AddEngagementPersonnelsOutputFields.CreatedBy.ToString()].ToString(),
                    CreatedDate = (dr[AddEngagementPersonnelsOutputFields.CreatedDate.ToString()] is DBNull) ? DateTime.MinValue : Convert.ToDateTime(dr[AddEngagementPersonnelsOutputFields.CreatedDate.ToString()].ToString()),
                    ArchiveNumber = (dr[AddEngagementPersonnelsOutputFields.ArchiveNumber.ToString()] is DBNull) ? string.Empty : dr[AddEngagementPersonnelsOutputFields.ArchiveNumber.ToString()].ToString(),
                };
            }
        }
        #endregion AddEngagementPersonnels
    }
}
