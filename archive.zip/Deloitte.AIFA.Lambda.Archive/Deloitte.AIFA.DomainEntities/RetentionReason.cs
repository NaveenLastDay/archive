﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
   public class RetentionReason
    {
        public int RetentionReasonID { get; set; }

        public string Description { get; set; }
    }
}
