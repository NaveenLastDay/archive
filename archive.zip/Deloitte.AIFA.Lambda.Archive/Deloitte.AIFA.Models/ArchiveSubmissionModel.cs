﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DataModels
{
    public class ArchiveSubmissionModel
    {
        public string ArchiveNumber { get; set; }

        public string ArchiveStatus { get; set; }

        public string ArchiveApprovedDate { get; set; }

        public string OfficeTimeZone { get; set; }
    }
}
