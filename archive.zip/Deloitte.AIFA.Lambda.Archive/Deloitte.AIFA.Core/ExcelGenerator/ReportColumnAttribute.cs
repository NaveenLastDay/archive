﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.Helpers.ExcelGenerator
{
    public class ReportColumnAttribute : Attribute
    {
        public ReportColumnAttribute(double width, Type dataType, CellColor headerBackgroundColor = CellColor.None, bool customFormated = true)
        {
            Width = width;
            DataType = dataType;
            HeaderBackgroundColor = headerBackgroundColor;
            CustomFormated = customFormated;
        }

        public double Width { get; set; }

        public Type DataType { get; set; }

        public CellColor HeaderBackgroundColor { get; set; }

        public bool CustomFormated { get; set; }
    }
}
