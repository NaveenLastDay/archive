﻿using Deloitte.AIFA.Common;
using Deloitte.AIFA.DomainEntities;
using Deloitte.AIFA.DomainEntities.Enums;
using Deloitte.AIFA.DomainEntities.Report;
using Deloitte.AIFA.DomainServices.Common;
using Deloitte.AIFA.DomainServices.Contracts;
using Deloitte.AIFA.Helpers.ExcelGenerator;
using Deloitte.AIFA.ICloudServices;
using Deloitte.AIFA.IRepositories;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Deloitte.AIFA.DomainServices.Services
{
    public class RateThisAppService : BaseService, IRateThisAppService
    {
        IRateThisAppRepository _rateThisAppRepository;
        ILogger _logger;
        IMemoryCache _cache;
        public RateThisAppService(IMemoryCache cache, IConfigManager configManager,
                              IRateThisAppRepository rateThisAppRepository,
                                ILogger<ArchiveService> logger) : base(cache, configManager)
        {
            _cache = cache;
            _logger = logger;
            _rateThisAppRepository = rateThisAppRepository;
        }

        public int GetRatingByUserAlias(string userAlias, int applicationId)
        {
            _logger.LogInformation("This is from RateThisAppService: GetRatingByUserAlias");
            int archives = _rateThisAppRepository.GetRatingByUserAlias(userAlias, applicationId);
            return archives;
        }
        public string SubmitRating(RatingSubmissionInfo ratingInfo)
        {
            _logger.LogInformation("This is from RateThisAppService: Submit Rating for" + System.Web.HttpUtility.HtmlEncode(ratingInfo.UserAlias));
            var result = _rateThisAppRepository.SubmitRating(ratingInfo);
            return result;
        }
    }
}
