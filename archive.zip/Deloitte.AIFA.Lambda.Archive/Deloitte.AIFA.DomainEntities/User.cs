﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
    public class User
    {
        public string userAlias { get; set; }
        public int employeeRoleId { get; set; }
    }
}
