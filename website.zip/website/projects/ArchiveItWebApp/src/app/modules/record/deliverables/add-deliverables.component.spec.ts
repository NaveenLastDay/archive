import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddDeliverablesComponent } from './add-deliverables.component';

describe('AddDeliverablesComponent', () => {
  let component: AddDeliverablesComponent;
  let fixture: ComponentFixture<AddDeliverablesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddDeliverablesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddDeliverablesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });
  

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
