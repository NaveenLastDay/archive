﻿
using Deloitte.AIFA.DomainEntities;
using Deloitte.AIFA.Repositories.UtilityHelper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;


namespace Deloitte.AIFA.Repositories.Transformers
{
    public class UserDashboardTransformer : BaseTransformer<ComplianceMetrics>
    {
       
        internal override ComplianceMetrics TransformElement(IDataReader dr, Func<IDataReader, ComplianceMetrics, ComplianceMetrics> bindExtraFields = null)
        {
          return new ComplianceMetrics
                {
                    ClientName= (dr[DashboardOutputFields.ClientName.ToString()] is DBNull ? string.Empty : dr[DashboardOutputFields.ClientName.ToString()].ToString()),
                    ArchiveName= (dr[DashboardOutputFields.Name.ToString()] is DBNull ? string.Empty : dr[DashboardOutputFields.Name.ToString()].ToString()),
                    ArchiveNumber= (dr[DashboardOutputFields.ArchiveNumber.ToString()] is DBNull ? string.Empty : dr[DashboardOutputFields.ArchiveNumber.ToString()].ToString()),
                    WBSNumber= (dr[DashboardOutputFields.WBSNumber.ToString()] is DBNull ? string.Empty : dr[DashboardOutputFields.WBSNumber.ToString()].ToString()),
                    Status= (dr[DashboardOutputFields.Status.ToString()] is DBNull ? string.Empty : dr[DashboardOutputFields.Status.ToString()].ToString()),
                    
            };
        }


        protected internal static Func<IDataReader, ComplianceMetrics, ComplianceMetrics> BindDashboardExtraFields
        {
            get
            {
                return (dr, myComplianceItem) =>
                {
                    myComplianceItem.DueDate = (dr[DashboardOutputFields.DueDate.ToString()] is DBNull ? DateTime.MinValue : TimeZoneHelper.ConvertCentralTimeToUtc(DateTime.Parse(dr[DashboardOutputFields.DueDate.ToString()].ToString())));
                    myComplianceItem.ArchiveClosed = (dr[DashboardOutputFields.ArchiveClosedDate.ToString()] is DBNull ? DateTime.MinValue : TimeZoneHelper.ConvertCentralTimeToUtc(DateTime.Parse(dr[DashboardOutputFields.ArchiveClosedDate.ToString()].ToString())));
                    myComplianceItem.Performance = (dr[DashboardOutputFields.Performance.ToString()] is DBNull ? string.Empty : dr[DashboardOutputFields.Performance.ToString()].ToString());
                    return myComplianceItem;
                };
            }
        }

    }

    public enum DashboardOutputFields
    {
        ClientName,
        Name,
        ArchiveNumber,
        WBSNumber,
        Status,
        DueDate,
        ArchiveClosedDate,
        Performance

    }
    public class UserDashboardComplianceMetricsTransformer : BaseTransformer<ComplianceMetrics>
    {
        internal override ComplianceMetrics TransformElement(IDataReader dr, Func<IDataReader, ComplianceMetrics, ComplianceMetrics> bindExtraFields = null)
        {
            return new ComplianceMetrics
            {
                ClientName = (dr[DashboardOutputFields.ClientName.ToString()] is DBNull ? string.Empty : dr[DashboardOutputFields.ClientName.ToString()].ToString()),
                ArchiveName = (dr[DashboardOutputFields.Name.ToString()] is DBNull ? string.Empty : dr[DashboardOutputFields.Name.ToString()].ToString()),
                ArchiveNumber = (dr[DashboardOutputFields.ArchiveNumber.ToString()] is DBNull ? string.Empty : dr[DashboardOutputFields.ArchiveNumber.ToString()].ToString()),
                WBSNumber = (dr[DashboardOutputFields.WBSNumber.ToString()] is DBNull ? string.Empty : dr[DashboardOutputFields.WBSNumber.ToString()].ToString()),
                Status = (dr[DashboardOutputFields.Status.ToString()] is DBNull ? string.Empty : dr[DashboardOutputFields.Status.ToString()].ToString()),
                DueDate = (dr[DashboardOutputFields.DueDate.ToString()] is DBNull ? DateTime.MinValue : TimeZoneHelper.ConvertCentralTimeToUtc(DateTime.Parse(dr[DashboardOutputFields.DueDate.ToString()].ToString()))),
                ArchiveClosed = (dr[DashboardOutputFields.ArchiveClosedDate.ToString()] is DBNull ? DateTime.MinValue : TimeZoneHelper.ConvertCentralTimeToUtc(DateTime.Parse(dr[DashboardOutputFields.ArchiveClosedDate.ToString()].ToString()))),
                Performance = (dr[DashboardOutputFields.Performance.ToString()] is DBNull ? string.Empty : dr[DashboardOutputFields.Performance.ToString()].ToString())
            };
    
        
        }
    }



}
