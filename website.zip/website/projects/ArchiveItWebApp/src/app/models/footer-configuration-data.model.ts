export class FooterConfigurationDataModel {
    id: number;
    tsPropertyName: string;
    link: string;
    displayName: string;
    sortOrder: number;
    widthInPercentage: number;
}