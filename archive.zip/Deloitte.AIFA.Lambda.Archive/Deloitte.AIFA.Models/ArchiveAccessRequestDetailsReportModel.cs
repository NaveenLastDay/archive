﻿using Deloitte.AIFA.DomainEntities;
using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DataModels
{
    public class ArchiveAccessRequestDetailsReportModel
    {
         public ArchiveAccessRequestDetailsReportModel()
            {
                List = new List<ArchiveAccessRequestDetails>();
            }

            public List<ArchiveAccessRequestDetails> List { get; set; }

            public bool IsDataTruncated { get; set; }



    }
}
