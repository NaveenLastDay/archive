﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DataModels
{
    public class ArchiveSubmissionCheckModel
    {
        public bool ReadyToSubmit { get; set; }
        public bool ShowPeoplePicker { get; set; }
        public bool ShowDatePicker { get; set; }
        public bool Isverificationsuccess { get; set; }
        // ArchieveSectionStatus
        public string EngagementDetailsStatus { get; set; }
        public string WorkingPaperStatus { get; set; }
        public string DeliverableStatus { get; set; }
        public string RelatedArchiveStatus { get; set; }
        public string EngagementrelatedpersonnelStatus { get; set; }
        public string RetentionExceptionStatus { get; set; }
    }
}
