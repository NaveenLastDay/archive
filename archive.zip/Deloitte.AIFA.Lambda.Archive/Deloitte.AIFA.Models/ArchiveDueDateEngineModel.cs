﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;

namespace Deloitte.AIFA.Models
{
   public class ArchiveDueDateEngineModel
    {
        public string ArchiveDueDateCriteria { get; set; }
        public DateTime OriginalDate { get; set; }
        public DateTime ArchiveDueDate { get; set; }
        public DateTime ExpectedDocumentationCompletionDate { get; set; }
        public string DeliverableType { get; set; }
        public DateTime ArchiveApprovedDate { get; set; }
        public string OfficeZone { get; set; }

    }
}
