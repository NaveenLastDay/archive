﻿using Deloitte.AIFA.DomainEntities;
using Deloitte.AIFA.DomainEntities.Report;
using Deloitte.AIFA.Models;
using System;
using System.Collections.Generic;


namespace Deloitte.AIFA.IRepositories
{
    public interface IUserDashBoardRepository
    {
        IDictionary<string, string> ValidateUserForDashboardDetails(string userAlias);
        UserDashboardResponse GetUserDashboardData(string userAlias, int requestId);
        List<MyForm3283Data> GetForm3283DashBoardData(string employeeUniqueIdentifier, int pageNumber,int pageSize);
        List<MyComplianceData> GetMyAwaitingApprovalDashBoardData(string employeeUniqueIdentifier, int pageNumber, object pageSize);
        List<MyComplianceData> GetArchiveDeletionsDashBoardData(string employeeUniqueIdentifier, int pageNumber, object pageSize);
        List<MyPendingSubmissionData> GetMyAwaitingSubmissionDashBoardData(string employeeUniqueIdentifier, int pageNumber, object pageSize);
        List<MyComplianceData> GetMyRequiringApprovalDashBoardData(string userAlias, int pageNumber, int pagesize);
        List<ComplianceMetricsDetails> GetComplianceMetricsData(string employeeUniqueIdentifier, int pageNumber, int pageSize, int sortBy, string filterText);
    }

}

