﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.Models
{
    public class ExistingArchivesInfoModel
    {
        public ArchiveSearchBaseModel archiveSearchBase { get; set; }
        public List<ExistingArchivesModel> lstExistingArchives { get; set; }
        
    }
}
