import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MaintainliststileComponent } from './maintain-lists-tile.component';

describe('MaintainliststileComponent', () => {
  let component: MaintainliststileComponent;
  let fixture: ComponentFixture<MaintainliststileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MaintainliststileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MaintainliststileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
