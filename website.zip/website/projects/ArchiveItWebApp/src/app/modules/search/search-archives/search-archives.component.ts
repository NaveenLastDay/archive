import { Subscription } from 'rxjs';
import { SearchService } from './../../../services/search.service';
import { Router, ActivatedRoute } from '@angular/router';
import { ArchiveService } from './../../../services/archive.service';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { NgxSpinnerService } from 'ngx-spinner';
import { NotifierService } from 'angular-notifier';
import { SearchEventService } from '../search.event.service';
import { FormBuilder, FormGroup } from '@angular/forms';
import { HomePageService } from '../../../services/homepage.service';
import { SharedService } from '../../../services/shared.service';
import { DatePipe } from '@angular/common';
import { Console } from 'console';
import { UserConfigSettingService } from '../../../guards/user-role-guard.service';


@Component({
  selector: 'app-search-archives',
  templateUrl: './search-archives.component.html',
  styleUrls: ['./search-archives.component.css']
})
export class SearchArchivesComponent implements OnInit, OnDestroy {

  employeeUniqueIdentifier: string = '';
  archives: any[] = [];
  archiveNumber: string = '';
  currentPageNumber: number = 1;
  totalArchives: number = 0;
  readonly pageSize: number = 10;
  displayingRecordsFrom: number = 0;
  displayingRecordsTo: number = 0;
  appendArchiveToGrid: boolean = false;
  searchTerm: string = '';
  fromRecord: number = 0;
  userSubscription: Subscription;
  hoverIndex: number = -1;
  readonly dateFormatInReport: string = "MM/dd/yyyy";
  readonly emptyStringInReport: string = " ";

  // Custom Rules

  login_form: FormGroup;
  customRules: Array<any> = [];
  index: number = 0;
  containers = [];
  searchText: string;
  jsonData = [];
  ArchiveNames = [];
  ArchiveNumbers = [];
  Statuses = [];
  Clients = [];
  WBSNumbers = [];
  PeriodEndDates = [];
  ArchiveMembers = [];
  userEmail: string;
  userAlias: string;
  clientData = [];
  customRuleJson = {};
  Index = [];
  enableRemoveCRule: boolean = false;
  disableSearchBtn: boolean = true;
  maxIndex: number;
  archiveResultGridColumns: any = ArchiveResultGridColumns;
  //searchEventService : SearchEventService;

  columnFilters: any[] = [
    {
      "displayName": "Archive#",
      "value": this.archiveResultGridColumns.ArchiveNumber,
      "checked": false
    },
    /*{
       "displayName": "Business",
       "value": this.archiveResultGridColumns.Business,
       "checked": false
     },*/
    {
      "displayName": "Client",
      "value": this.archiveResultGridColumns.Client,
      "checked": false
    },
    {
      "displayName": "Archive Name",
      "value": this.archiveResultGridColumns.ArchiveName,
      "checked": false
    },
    {
      "displayName": "Period End",
      "value": this.archiveResultGridColumns.PeriodEnd,
      "checked": false
    },
    {
      "displayName": "WBS#",
      "value": this.archiveResultGridColumns.WBSNumber,
      "checked": false
    },
    /*{
      "displayName": "Type",
      "value": this.archiveResultGridColumns.Type,
      "checked": false
    },*/
    {
      "displayName": "Status",
      "value": this.archiveResultGridColumns.Status,
      "checked": false
    },
    {
      "displayName": "Engagement Type",
      "value": this.archiveResultGridColumns.Engagement,
      "checked": false
    },
    {
      "displayName": "RDCD",
      "value": this.archiveResultGridColumns.RDCD,
      "checked": false
    },
    {
      "displayName": "EDCD",
      "value": this.archiveResultGridColumns.EDCD,
      "checked": false
    },
    {
      "displayName": "Is Resubmission In Progress",
      "value": this.archiveResultGridColumns.IsResubmissionInProgress,
      "checked": false
    },
    {
      "displayName": "Archive Description",
      "value": this.archiveResultGridColumns.ArchiveDescription,
      "checked": false
    },
    {
      "displayName": "Entity Associated With Archive",
      "value": this.archiveResultGridColumns.EntityAssociatedWithArchive,
      "checked": false
    },
    {
      "displayName": "Standards Applied",
      "value": this.archiveResultGridColumns.StandardsApplied,
      "checked": false
    },
    {
      "displayName": "Reporting Entity",
      "value": this.archiveResultGridColumns.ReportingEntity,
      "checked": false
    },
    {
      "displayName": "Archive Partner",
      "value": this.archiveResultGridColumns.ArchivePartner,
      "checked": false
    },
    {
      "displayName": "Archive Manager",
      "value": this.archiveResultGridColumns.ArchiveManager,
      "checked": false
    },
    {
      "displayName": "Archive Field Senior",
      "value": this.archiveResultGridColumns.ArchiveFieldSenior,
      "checked": false
    },
    {
      "displayName": "Additional Archive Field Senior",
      "value": this.archiveResultGridColumns.AdditionalArchiveFieldSenior,
      "checked": false
    }
  ];
  userConfig: any;
  notifierflag: number;

  constructor(private adalSvc: MsAdalAngular6Service, private fb: FormBuilder, private _userConfig: UserConfigSettingService,
    private SpinnerService: NgxSpinnerService, private notifier: NotifierService, private router: Router, private activatedRoute: ActivatedRoute, private _search: SearchService
    , private _searchEventService: SearchEventService, private homeService: HomePageService, private sharedService: SharedService, private datePipe: DatePipe, private homepageSvc: HomePageService) {

    this.userSubscription = this.activatedRoute.params.subscribe(
      data => {
        //alert('alert1');    
        this.resetValues();
        this.ngOnInit();
      }
    );
    this.userEmail = this.adalSvc.LoggedInUserEmail;
    this.userAlias = this.userEmail.substring(0, this.userEmail.lastIndexOf("@"));
    //this.searchEventService = searchEveService;
    this.userConfig = this._userConfig.FetchLoggedInUser(this.userAlias);
  }

  get searchEventService(): SearchEventService {
    return this._searchEventService;
  }

  ngOnInit() {
    this.searchTerm = this.activatedRoute.snapshot.paramMap.get("searchTerm") || '';
    if (this.searchTerm) {
      this.removeCustomRule();
      this.clearFinalRules();
      this.emptyFacets();
      this.searchEventService.finalSelectedJson.isKeywordbaseSearch = true;
      this.searchEventService.finalSelectedJson.searchKeyword = this.searchTerm;
      this.searchEventService.enableBindfacets = true;
      this.searchEventService.customRules = [];
    }
    else {
      this.searchTerm = this.searchEventService.finalSelectedJson.searchKeyword;
    }
    if (!this.validateCustomRules()) {
      return;
    }

    this.searchEventService.selectedFieldName = [];
    this.searchEventService.selectedFields = [];
    this.customRules = this.searchEventService.customRules;

    if (this.customRules.length > 0) {
      this.index = this.customRules.length;
      this.enableRemoveCRule = true;
    }
    this.searchEventService.deleteClickEvent.subscribe(index => {
      this.customRules = this.customRules.filter(i => i._index != index)
    });
    this.searchEventService.enableSearch = false;
    this.searchEventService.disableSearchBtn = true;
    // this.SpinnerService.show();
    this.employeeUniqueIdentifier = this.adalSvc.LoggedInUserEmail.split('@')[0];
    //this.employeeUniqueIdentifier = 'galahari'; //nabasha //goavinash //galahari//golyadav//
    // if(this.searchEventService.finalSelectedJson.searchKeyword!=""){
    this.searchTerm = this.searchEventService.finalSelectedJson.searchKeyword;
    // console.log(this.searchTerm);
    this.getSearchResults();
    this.searchEventService.triggerAdvanceSearch.subscribe(data => {
      this.resetValues();
      this.getSearchResults();
    });

    //alert('alert2');
    //this.childComponent.testMethod();
  }
  validateCustomRules() {
    if ((this.searchEventService.finalSelectedJson.isKeywordbaseSearch
      && this.searchEventService.finalSelectedJson.searchKeyword != "")
      || this.searchEventService.customRuleJson.length > 0) {
      return true;
    }
    else {
      this.router.navigate(["/search/advancedsearch"]);
      return false;

    }

  }
  onReset() {
    this.router.navigate(["/search/advancedsearch"]);
  }

  showArchiveDetails(archiveNumber, index) {
    if (this.archiveNumber == archiveNumber) {
      this.archiveNumber = '';
    }
    else {
      this.archiveNumber = archiveNumber;
    }
  }




  accessArchive(archiveNumber: string) {
    // this.SpinnerService.show();
    this.router.navigate(['/archive/myarchives', archiveNumber])
  }

  updateGridData(event) {
    // this.SpinnerService.show();
    this.appendArchiveToGrid = event.isLoadMoreClicked;
    this.currentPageNumber = event.pageNumber;
    this.getSearchResults();

  }

  getSearchResults() {
    //debugger;
    this.fromRecord = (this.pageSize * (this.currentPageNumber - 1));
    this.searchEventService.finalSelectedJson.employeeAlias = this.adalSvc.LoggedInUserEmail.split('@')[0];
    this.searchEventService.finalSelectedJson.pageSize = this.pageSize;
    this.searchEventService.finalSelectedJson.from = this.fromRecord;
    ///this.SpinnerService.show();
    this.notifierflag = 0;
    this._search.getAdvancedSearchResults(this.searchEventService.finalSelectedJson).subscribe(

      data => {
        //debugger;

        if (data && data.hits && data.hits.total.value && data.hits.hits.length) {
          // console.log("data exists");
          if (!this.appendArchiveToGrid) {
            this.archives = [];
          }

          data.hits.hits.forEach(element => {
            let archive = {};
            archive["archiveNumber"] = element._source.ArchiveNumber;
            archive["engagementDescription"] = element._source.ArchiveName.original;
            archive["periodEndDate"] = element._source.RetentionPeriodEndDate.split("T", 1);
            archive["business"] = element._source.Business.original;
            archive["clientName"] = element._source.ClientName.original;
            archive["wbsLevelOne"] = element._source.WbsNumber.original;
            archive["archiveType"] = element._source.ArchiveType.original;
            archive["submissionStatus"] = element._source.ArchiveStatus.original;
            archive["professionalStandardDescription"] = element._source.ProfessionalStandard.original;
            //archive["entityTypeDescription"] = element._source.EntityType.original;
            archive["IsAccessible"] = element._source.IsAccessible || 0;
            archive["engagementTypeDescription"] = element._source.EngagementType.original || this.emptyStringInReport;
            archive["archiveDueDate"] = element._source.ArchiveDueDate ? this.datePipe.transform(element._source.ArchiveDueDate, this.dateFormatInReport) : this.emptyStringInReport;
            archive["estimatedIssuanceReportDate"] = element._source.EstimatedIssuanceReportDate ? this.datePipe.transform(element._source.EstimatedIssuanceReportDate, this.dateFormatInReport) : this.emptyStringInReport;
            archive["isResubmissionInProgress"] = element._source.IsResubmissionInProgress == "true" ? "Yes" : "No";
            archive["description"] = element._source.ArchiveDescription.original || this.emptyStringInReport;
            archive["professionalStandardDescription"] = element._source.ProfessionalStandard.original || this.emptyStringInReport;
            archive["entityTypeDescription"] = element._source.EntityType.original || this.emptyStringInReport;
            archive["reportingEntity"] = "";
            archive["archivePartner"] = element._source.ArchivePartner.original || this.emptyStringInReport;
            archive["archvieManger"] = element._source.ArchiveManager.original || this.emptyStringInReport;
            archive["archvieFieldSenior"] = element._source.ArchvieFieldSenior.original || this.emptyStringInReport;
            archive["addArchvieFieldSenior"] = element._source.AddArchvieFieldSenior.original || this.emptyStringInReport;
            if (this.userConfig.value.isAdmin || this.userConfig.value.isGlobalReader || this.userConfig.value.isRCO) {
              archive["IsAccessible"] = 0;
            }
            this.archives.push(archive);
          });

          if (this.searchEventService.enableBindfacets) {
            this.emptyFacets();
            data.aggregations.agg_nested_ArchiveStatus.agg_ArchiveStatus.buckets
              .map(x => x.tophits.hits.hits).forEach(status => {
                this.searchEventService.ArchiveStatusDataArray
                  .push(status.map(x => x._source.original)[0])
              });

            data.aggregations.agg_nested_ClientName.agg_ClientName.buckets
              .map(x => x.tophits.hits.hits).forEach(status => {
                this.searchEventService.clientDataArray
                  .push(status.map(x => x._source.original)[0])
              });
            data.aggregations.agg_nested_ArchiveType.agg_ArchiveType.buckets
              .map(x => x.tophits.hits.hits).forEach(status => {
                this.searchEventService.TypeDataArray
                  .push(status.map(x => x._source.original)[0])
              });
            data.aggregations.agg_nested_WbsNumber.agg_WbsNumber.buckets
              .map(x => x.tophits.hits.hits).forEach(status => {
                this.searchEventService.WBSDataArray
                  .push(status.map(x => x._source.original)[0])
              });
            data.aggregations.agg_nested_Business.agg_Business.buckets
              .map(x => x.tophits.hits.hits).forEach(status => {
                this.searchEventService.BusinessDataArray
                  .push(status.map(x => x._source.original)[0])
              });

            data.aggregations.agg_nested_ArchiveDescription.agg_ArchiveDescription.buckets
              .map(x => x.tophits.hits.hits).forEach(status => {
                this.searchEventService.ArchivedescriptionDataArray
                  .push(status.map(x => x._source.original)[0])
              });
            data.aggregations.agg_nested_ProfessionalStandard.agg_ProfessionalStandard.buckets
              .map(x => x.tophits.hits.hits).forEach(status => {
                this.searchEventService.ProfessionalstandardsDataArray
                  .push(status.map(x => x._source.original)[0])
              });
            data.aggregations.agg_nested_EngagementType.agg_EngagementType.buckets
              .map(x => x.tophits.hits.hits).forEach(status => {
                this.searchEventService.EngagementtypeDataArray
                  .push(status.map(x => x._source.original)[0])
              });
            data.aggregations.agg_nested_EntityType.agg_EntityType.buckets
              .map(x => x.tophits.hits.hits).forEach(status => {
                this.searchEventService.TypeofentityDataArray
                  .push(status.map(x => x._source.original)[0])
              });
            try {
              data.aggregations.agg_nested_ArchiveManager.agg_ArchiveManager.buckets
                .map(x => x.tophits.hits.hits).forEach(status => {
                  this.searchEventService.ArchiveManagerDataArray
                    .push(status.map(x => x._source.original)[0])
                });
              data.aggregations.agg_nested_ArchvieFieldSenior.agg_ArchvieFieldSenior.buckets
                .map(x => x.tophits.hits.hits).forEach(status => {
                  this.searchEventService.ArchvieFieldSeniorDataArray
                    .push(status.map(x => x._source.original)[0])
                });
              data.aggregations.agg_nested_AddArchvieFieldSenior.agg_AddArchvieFieldSenior.buckets
                .map(x => x.tophits.hits.hits).forEach(status => {
                  this.searchEventService.AddArchvieFieldSeniorDataArray
                    .push(status.map(x => x._source.original)[0])
                });
              data.aggregations.agg_nested_ArchivePartner.agg_ArchivePartner.buckets
                .map(x => x.tophits.hits.hits).forEach(status => {
                  this.searchEventService.ArchivePartnerDataArray
                    .push(status.map(x => x._source.original)[0])
                });
            }
            catch (e) { console.log("null reference to aggregates of team member!") }
            if (this.searchEventService.finalSelectedJson.rules.archiveTeamMembers && this.searchEventService.finalSelectedJson.rules.archiveTeamMembers.length > 0) {
              this.searchEventService.ArchivePartnerDataArray = this.searchEventService.AddArchvieFieldSeniorDataArray = this.searchEventService.ArchvieFieldSeniorDataArray = this.searchEventService.ArchiveManagerDataArray = this.searchEventService.finalSelectedJson.rules.archiveTeamMembers;
            }
            this.searchEventService.onRebindFacetComponents();
            this.searchEventService.enableBindfacets = false;
          }
          //debugger;
          this.totalArchives = data.hits.total.value;
          //  this.SpinnerService.hide();
        }
        else {

          this.searchEventService.enableNotifier = true;
          this.archives = [];
          if (this.searchEventService.enableBindfacets) {
            this.clearFacets();
          }
          if (this.notifierflag == 0) {
            this.notifier.notify("error", "No results found");
            this.notifierflag = 1;
          }
          this.resetValues();
          console.log("no data");
          this.searchEventService.enableNotifier = false;
        }
        // this.SpinnerService.hide();
      },
      error => {
        this.searchEventService.enableNotifier = true;
        // this.SpinnerService.hide();
        this.notifier.notify("error", "Something went wrong, please try again");
        this.resetValues();
        this.searchTerm = "";
        this.searchEventService.enableNotifier = false;
      }

    );
  }

  ngOnDestroy() {
    //this.userSubscription.unsubscribe();
    this.homepageSvc.simpleSearchVisible = false;
    this.homeService.advanceSearchBtnDisable = false;
  }

  resetValues() {
    //this.employeeUniqueIdentifier = '';
    this.archives = [];
    this.archiveNumber = '';
    this.currentPageNumber = 1;
    this.totalArchives = 0;
    this.displayingRecordsFrom = 0;
    this.displayingRecordsTo = 0;
    this.appendArchiveToGrid = false;
    //this.searchTerm = '';
    this.fromRecord = 0;
  }


  //Custom Rule


  add() {
    this.containers.push(this.containers.length);
  }
  addCustomRule() {
    if (this.searchEventService.selectedFields.length < this.customRules.length) {
      this.notifier.notify("error", "Please provide value(s) for  search parameters");
      return;
    }
    else

      this.searchEventService.bindCustomRules = false;
    this.customRules.push({ _index: this.index++ });
    this.searchText = "";
    this.searchEventService.enableSearch = true;
    this.enableRemoveCRule = true;
    this.searchEventService.disableSearchBtn = false;
    if (this.customRules.length == 7) {
      this.searchEventService.enableCustomRuleBtn = false;
    }
    // this.searchEventService.showApplyAll=true;
  }
  deleteCustomRule(e) {
    if (this.customRules.length == 0) {
      this.searchEventService.enableSearch = false;
      this.enableRemoveCRule = false;
      this.searchEventService.disableSearchBtn = true;
      this.searchEventService.showApplied = false;
      this.searchEventService.showApplyAll = false;
    }
  }
  removeCustomRule() {
    this.searchEventService.bindCustomRules = false;
    this.searchEventService.finalSelectedJson.employeeAlias = this.userAlias;
    this.clearFinalRules();
    this.index = 0;
    this.searchEventService.enableCustomRuleBtn = true;
    this.searchEventService.disableSearchBtn = true;
    this.searchEventService.selectedFields = [];
    this.customRules = [];
    this.searchEventService.customRules = [];
    this.enableRemoveCRule = false;
    this.searchEventService.enableSearch = false;
    this.searchEventService.customRuleJson = [];
    this.customRuleJson = {};
    this.searchEventService.selectedManagerList = [];
    this.searchEventService.selectedClientsList = [];
    this.searchEventService.selectedStatusList = [];
    this.searchEventService.selectedWbsList = [];
    this.searchEventService.showApplied = false;
    this.searchEventService.showApplyAll = false;
    // console.log(this.searchEventService.finalSelectedJson.rules);
  }
  triggerAdvanceSearch() {
    this.searchEventService.enableBindfacets = true;
    this.searchEventService.enablePageCount = false;
    this.searchEventService.enableNotifier = true;
    this.customRuleJson = {};
    if (this.searchText) {
      this.searchEventService.searchText = this.searchText;
      // console.log(this.searchEventService.searchText);
      this.searchEventService.finalSelectedJson.employeeAlias = this.employeeUniqueIdentifier;
      this.searchEventService.finalSelectedJson.searchKeyword = this.searchText;
      this.searchEventService.finalSelectedJson.isKeywordbaseSearch = true;
      this.router.navigate(["/search/advancedsearch/archives/" + this.searchText]);
      this.homeService.advanceSearchBtnDisable = false;
      this.homeService.simpleSearchVisible = false;

    }
    else {
      var crJson = this.searchEventService.customRuleJson;
      this.Index = [];
      this.customRules.forEach(index => {
        var Indexvalue = crJson.findIndex(x => x.Index == index._index)
        this.Index.push(Indexvalue);
      });
      var notExists = this.Index.findIndex(x => x == -1);
      //To check from date and to date 
      var fromDateExists = "";
      var toDateExists = "";
      if (this.searchEventService.customRuleJson.filter(x => x.FromDate).length > 0) {
        fromDateExists = this.searchEventService.customRuleJson.filter(x => x.FromDate)[0].FromDate;
      }
      if (this.searchEventService.customRuleJson.filter(x => x.ToDate).length > 0) {
        toDateExists = this.searchEventService.customRuleJson.filter(x => x.ToDate)[0].ToDate;
      }

      if ((fromDateExists == "" && toDateExists) || (fromDateExists && toDateExists == "")) {
        this.notifier.notify("error", "Please enter the From date & To date");
        return;
      }
      //to check values are given or not 
      if (notExists != -1) {
        this.notifier.notify("error", "Please provide value(s) for  search parameters");
      }
      else {
        this.clearFinalRules();
        crJson.forEach(x => {
          if (x["ArchiveName"]) this.searchEventService.finalSelectedJson.rules.archiveName.push(x["ArchiveName"]);
          if (x["ArchiveNumber"]) this.searchEventService.finalSelectedJson.rules.archiveNumber.push(x["ArchiveNumber"])
          if (x["Status"]) this.searchEventService.finalSelectedJson.rules.archiveStatus.push(x["Status"])
          if (x["ClientName"]) this.searchEventService.finalSelectedJson.rules.clientName.push(x["ClientName"]);
          if (x["ManagerName"]) this.searchEventService.finalSelectedJson.rules.archiveTeamMembers.push(x["DisplayName"])
          if (x["WBS"]) this.searchEventService.finalSelectedJson.rules.WBSNumber.push(x["WBS"])
        });

        if (fromDateExists && toDateExists) {
          this.searchEventService.finalSelectedJson.rules.periodEndDate.push({
            StartDate: fromDateExists,
            EndDate: toDateExists
          });
        }

        this.searchEventService.finalSelectedJson.employeeAlias = this.employeeUniqueIdentifier;

        //this.searchEventService.customRuleJsondata=this.customRuleJson;
        // this.searchEventService.selectedFields = [];
        this.searchEventService.selectedManagerList = [];
        this.searchEventService.selectedClientsList = [];
        this.searchEventService.selectedStatusList = [];
        this.searchEventService.selectedWbsList = [];
        this.searchEventService.customRuleCount = 0;
        this.searchEventService.cloneFinalJson();
        // console.log(this.searchEventService.finalBackupJson);
        // console.log(this.searchEventService.finalSelectedJson);
        // this.searchEventService.customRuleJson=[];
        this.searchEventService.showApplied = true;
        this.searchEventService.showApplyAll = false;
        this.homeService.advanceSearchBtnDisable = false;
        this.homeService.simpleSearchVisible = false;
        this.searchTerm = "";
        this.searchEventService.finalSelectedJson.isKeywordbaseSearch = false;
        this.searchEventService.finalSelectedJson.searchKeyword = "";
        this.searchEventService.facesetJson = [];
        this.searchEventService.periodEndDate = "";
        this.searchEventService.periodStartDate = "";
        this.resetValues();
        this.getSearchResults();
      }
    }


  }
  clearSelectedFacets() {
    //debugger;
    this.searchEventService.onClearFacetsSelection();
    this.searchEventService.selectedFacetsCount = 0;

    // this.searchEventService.facesetJson = [];
    // this.searchEventService.periodEndDate = "";
    // this.searchEventService.periodStartDate = "";
    // this.searchEventService.finalSelectedJson.rules.archiveDescription = [];
    // this.searchEventService.finalSelectedJson.rules.archiveType = [];
    // this.searchEventService.finalSelectedJson.rules.entityAssociatedwithArchives = [];
    // this.searchEventService.finalSelectedJson.rules.standardsApplied = [];
    // this.searchEventService.finalSelectedJson.rules.engagementType = [];
    // this.searchEventService.finalSelectedJson.rules.business = [];
    // this.searchEventService.finalSelectedJson.rules.periodEndDate = [];
    // this.searchEventService.finalSelectedJson.rules.clientName = this.searchEventService.finalBackupJson.clientName;
    // this.searchEventService.finalSelectedJson.rules.WBSNumber = this.searchEventService.finalBackupJson.WBSNumber;
    // this.searchEventService.finalSelectedJson.rules.archiveStatus = this.searchEventService.finalBackupJson.archiveStatus;
    // this.searchEventService.finalSelectedJson.rules.archiveTeamMembers=this.searchEventService.finalBackupJson.archiveTeamMembers;
    // this.searchEventService.facetcounter=0;
    // this.searchEventService.errormessage=false;
    // this.searchEventService.errormessagerange=false;
    // this.searchEventService.startDate="";
    // this.searchEventService.toDate="";

    this.searchEventService.facesetJson.forEach(x => {
      this.searchEventService.finalSelectedJson.rules[x.field] = this.searchEventService.finalSelectedJson.rules[x.field].filter(y => y != x.value);

      if (x.field == 'periodEndDate') {
        this.searchEventService.finalSelectedJson.rules[x.field] = [];

        if (this.searchEventService.periodEndStartDateCustomRule && this.searchEventService.periodEndToDateCustomRule) {
          this.searchEventService.finalSelectedJson.rules[x.field].push({
            StartDate: this.datePipe.transform(this.searchEventService.periodEndStartDateCustomRule,'yyyy-MM-dd'),
            EndDate: this.datePipe.transform(this.searchEventService.periodEndToDateCustomRule,'yyyy-MM-dd')
          });
        }
      }
    });

    this.searchEventService.facesetJson = [];
    this.resetValues();
    this.getSearchResults();
  }
  clearFinalRules() {
    this.searchEventService.finalSelectedJson.rules.archiveName = [];
    this.searchEventService.finalSelectedJson.rules.archiveNumber = [];
    this.searchEventService.finalSelectedJson.rules.clientName = [];
    this.searchEventService.finalSelectedJson.rules.WBSNumber = [];
    this.searchEventService.finalSelectedJson.rules.archiveTeamMembers = [];
    this.searchEventService.finalSelectedJson.rules.archiveStatus = [];
    this.searchEventService.finalSelectedJson.rules.periodEndDate = [];
  }
  emptyFacets() {
    this.searchEventService.clientDataArray = [];
    this.searchEventService.WBSDataArray = [];
    this.searchEventService.BusinessDataArray = [];
    this.searchEventService.TypeDataArray = [];
    this.searchEventService.ArchivedescriptionDataArray = [];
    this.searchEventService.ProfessionalstandardsDataArray = [];
    this.searchEventService.EngagementtypeDataArray = [];
    this.searchEventService.TypeofentityDataArray = [];
    this.searchEventService.ArchiveStatusDataArray = [];
    this.searchEventService.ArchivePartnerDataArray = [];
    this.searchEventService.ArchvieFieldSeniorDataArray = [];
    this.searchEventService.AddArchvieFieldSeniorDataArray = [];
    this.searchEventService.ArchiveManagerDataArray = [];
    this.searchEventService.selectedFacetsCount = 0;
    this.searchEventService.periodStartDate = "";
    this.searchEventService.periodEndDate = "";
    this.searchEventService.facetcounter = 0;
    this.searchEventService.errormessage = false;
    this.searchEventService.errormessagerange = false;
    this.searchEventService.startDate = "";
    this.searchEventService.toDate = "";
  }
  clearFacets() {
    this.emptyFacets();
    this.searchEventService.onRebindFacetComponents();
  }

  generateReportClicked(data) {

    if (this.totalArchives > 1048000) {
      this.notifier.notify("error", "Record count more than 1000000.");
    }
    else {
      // this.SpinnerService.show();
      let archiveForReport: any[] = [];
      let filterdColumns = (this.columnFilters.filter(x => x.checked));
      let selectedJson = Object.assign({}, this.searchEventService.finalSelectedJson);
      selectedJson["from"] = 0;
      selectedJson["pageSize"] = this.totalArchives;//1048000//1,048,576
      this._search.getAdvancedSearchResults(selectedJson).subscribe(
        data => {
          if (data && data.hits && data.hits.total.value && data.hits.hits.length) {
            // console.log("data exists");
            data.hits.hits.forEach(element => {
              let archive = {};
              filterdColumns.forEach(column => {

                if (column["value"] == this.archiveResultGridColumns.ArchiveNumber) { //Archive#
                  archive[this.archiveResultGridColumns[this.archiveResultGridColumns.ArchiveNumber]] = element._source.ArchiveNumber || this.emptyStringInReport;
                }

                if (column["value"] == this.archiveResultGridColumns.Business) { //Business
                  archive[this.archiveResultGridColumns[this.archiveResultGridColumns.Business]] = element._source.Business.original || this.emptyStringInReport;
                }

                if (column["value"] == this.archiveResultGridColumns.Client) { //Client
                  archive[this.archiveResultGridColumns[this.archiveResultGridColumns.Client]] = element._source.ClientName.original || this.emptyStringInReport;
                }

                if (column["value"] == this.archiveResultGridColumns.ArchiveName) { //Archive Name
                  archive[this.archiveResultGridColumns[this.archiveResultGridColumns.ArchiveName]] = element._source.ArchiveName.original || this.emptyStringInReport;
                }

                if (column["value"] == this.archiveResultGridColumns.PeriodEnd) { //Period End
                  archive[this.archiveResultGridColumns[this.archiveResultGridColumns.PeriodEnd]] = element._source.RetentionPeriodEndDate ? this.datePipe.transform(element._source.RetentionPeriodEndDate, this.dateFormatInReport) : this.emptyStringInReport;
                }

                if (column["value"] == this.archiveResultGridColumns.WBSNumber) { //WBS#
                  archive[this.archiveResultGridColumns[this.archiveResultGridColumns.WBSNumber]] = element._source.WbsNumber.original || this.emptyStringInReport;
                }

                if (column["value"] == this.archiveResultGridColumns.Type) { //Type
                  archive[this.archiveResultGridColumns[this.archiveResultGridColumns.Type]] = element._source.ArchiveType.original || this.emptyStringInReport;
                }

                if (column["value"] == this.archiveResultGridColumns.Status) { //Status
                  archive[this.archiveResultGridColumns[this.archiveResultGridColumns.Status]] = element._source.ArchiveStatus.original || this.emptyStringInReport;
                }

                if (column["value"] == this.archiveResultGridColumns.Engagement) { //Engagement
                  archive[this.archiveResultGridColumns[this.archiveResultGridColumns.Engagement]] = element._source.EngagementType.original || this.emptyStringInReport;
                }

                if (column["value"] == this.archiveResultGridColumns.RDCD) { //RDCD
                  archive[this.archiveResultGridColumns[this.archiveResultGridColumns.RDCD]] = element._source.ArchiveDueDate ? this.datePipe.transform(element._source.ArchiveDueDate, this.dateFormatInReport) : this.emptyStringInReport;
                  //archive[this.archiveResultGridColumns[this.archiveResultGridColumns.RDCD]] = "";
                }

                if (column["value"] == this.archiveResultGridColumns.EDCD) { //EDCD
                  archive[this.archiveResultGridColumns[this.archiveResultGridColumns.EDCD]] = element._source.EstimatedIssuanceReportDate ? this.datePipe.transform(element._source.EstimatedIssuanceReportDate, this.dateFormatInReport) : this.emptyStringInReport;
                  //archive[this.archiveResultGridColumns[this.archiveResultGridColumns.EDCD]] = "";
                }

                if (column["value"] == this.archiveResultGridColumns.IsResubmissionInProgress) { //Is Resubmission In Progress
                  // console.log(element._source.IsResubmissionInProgress);
                  archive[this.archiveResultGridColumns[this.archiveResultGridColumns.IsResubmissionInProgress]] = element._source.IsResubmissionInProgress == "true" ? "Yes" : "No";
                  //archive[this.archiveResultGridColumns[this.archiveResultGridColumns.IsResubmissionInProgress]] = "No";
                }

                if (column["value"] == this.archiveResultGridColumns.ArchiveDescription) { //Archive Description
                  archive[this.archiveResultGridColumns[this.archiveResultGridColumns.ArchiveDescription]] = element._source.ArchiveType.original || this.emptyStringInReport;
                }

                if (column["value"] == this.archiveResultGridColumns.EntityAssociatedWithArchive) { //Entity Associated With Archive
                  archive[this.archiveResultGridColumns[this.archiveResultGridColumns.EntityAssociatedWithArchive]] = element._source.EntityType.original || this.emptyStringInReport;
                }

                if (column["value"] == this.archiveResultGridColumns.StandardsApplied) { //Standards Applied
                  archive[this.archiveResultGridColumns[this.archiveResultGridColumns.StandardsApplied]] = element._source.ProfessionalStandard.original || this.emptyStringInReport;
                }

                if (column["value"] == this.archiveResultGridColumns.ReportingEntity) { //Reporting Entity
                  //archive[this.archiveResultGridColumns[this.archiveResultGridColumns.ReportingEntity]] = element._source.ReportingEntity.original || "";
                  archive[this.archiveResultGridColumns[this.archiveResultGridColumns.ReportingEntity]] = "";
                }

                if (column["value"] == this.archiveResultGridColumns.ArchivePartner) { //Archive Partner
                  archive[this.archiveResultGridColumns[this.archiveResultGridColumns.ArchivePartner]] = element._source.ArchivePartner.original || this.emptyStringInReport;
                }

                if (column["value"] == this.archiveResultGridColumns.ArchiveManager) { //Archive Manager
                  archive[this.archiveResultGridColumns[this.archiveResultGridColumns.ArchiveManager]] = element._source.ArchiveManager.original || this.emptyStringInReport;
                }

                if (column["value"] == this.archiveResultGridColumns.ArchiveFieldSenior) { //Archive Field Senior
                  archive[this.archiveResultGridColumns[this.archiveResultGridColumns.ArchiveFieldSenior]] = element._source.ArchvieFieldSenior.original || this.emptyStringInReport;
                }

                if (column["value"] == this.archiveResultGridColumns.AdditionalArchiveFieldSenior) { //Additional Archive Field Senior
                  archive[this.archiveResultGridColumns[this.archiveResultGridColumns.AdditionalArchiveFieldSenior]] = element._source.AddArchvieFieldSenior.original || this.emptyStringInReport;
                }
              });
              archiveForReport.push(archive);
            });
          }
          if (archiveForReport && archiveForReport.length) {
            this.sharedService.generateExcel("search-result", "archives", filterdColumns.map(x => x.displayName), archiveForReport);
          }
        },
        error => {
          console.log('Exception occured ' + JSON.stringify(error));
          // this.SpinnerService.hide();
        }
      );
    }
  }

  requestTemporaryAccess(archiveNumber: string) {

    if (archiveNumber) {
      //this.SpinnerService.show();
      this.router.navigate(['archive/requestAccess/' + archiveNumber]);
    }
  }

  checkAccessibility(isAccessible: number) {
    if (isAccessible == 2) {
      return false;
    }
    else {
      return true;
    }
  }

  onRowMouseOver(event, index: number) {
    this.hoverIndex = index;
    event.stopPropagation();
  }

  onMouseLeave(event) {
    this.hoverIndex = -1;
    event.stopPropagation();
  }

  applyHighlightByColumn(colname?: string) {
    if (this.searchEventService.finalSelectedJson.searchKeyword) {
      return this.searchEventService.finalSelectedJson.searchKeyword
    }
    else {
      //  if(!this.searchEventService.enableBindfacets)
      //          return;
      if (colname == "ArchiveNumber" && this.isselectedcustomrules(2)) {
        return this.searchEventService.finalSelectedJson.rules.archiveNumber[0];
      }
      else if (colname == "ArchiveName" && this.isselectedcustomrules(1)) {
        return this.searchEventService.finalSelectedJson.rules.archiveName[0];
      }

      else if (colname == "Client" && this.isselectedcustomrules(3)) {
        return this.searchEventService.finalSelectedJson.rules.clientName;
      }
      else if (colname == "WBS" && this.isselectedcustomrules(6)) {
        return this.searchEventService.finalSelectedJson.rules.WBSNumber;
      }
      else if (colname == "Status" && this.isselectedcustomrules(5)) {
        return this.searchEventService.finalSelectedJson.rules.archiveStatus;
      }
      else if (colname == "PeriodEndDate" && this.isselectedcustomrules(7)) {
        return this.searchEventService.finalSelectedJson.rules.periodEndDate;
      }
    }
  }
  isselectedcustomrules(nameKey) {
    for (var i = 0; i < this.searchEventService.selectedFields.length; i++) {
      if (this.searchEventService.selectedFields[i].id == nameKey) {
        return true;
      }

    }
    return false;
  }
}

export enum ArchiveResultGridColumns {
  ArchiveNumber = 1,
  Business = 2,
  Client = 3,
  ArchiveName = 4,
  PeriodEnd = 5,
  WBSNumber = 6,
  Type = 7,
  Status = 8,
  Engagement = 9,
  RDCD = 10,
  EDCD = 11,
  IsResubmissionInProgress = 12,
  ArchiveDescription = 13,
  EntityAssociatedWithArchive = 14,
  StandardsApplied = 15,
  ReportingEntity = 16,
  ArchivePartner = 17,
  ArchiveManager = 18,
  ArchiveFieldSenior = 19,
  AdditionalArchiveFieldSenior = 20
}
