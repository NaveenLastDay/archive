
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormArray, Validators } from '@angular/forms';
import { NotifierService } from "angular-notifier";
import { UserConfigSettingService } from '../../../guards/user-role-guard.service';
import { ManageCacheService } from '../../../services/manage-cache.service';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { Router } from '@angular/router';

@Component({
    selector: "manage-cache",
    templateUrl: './manage-cache.component.html',
    styleUrls: ['./manage-cache.component.css']
})
export class ManageCacheComponent implements OnInit {

    title = 'Manage Cache Component';
    userConfig: any;

    cacheFormGroup: FormGroup;
    cacheFormArrayGroup: FormGroup;

    constructor(private fb: FormBuilder, private _manageCacheService: ManageCacheService,
        private _adalService: MsAdalAngular6Service,
        private _userConfig: UserConfigSettingService,
        private _router: Router,
        private notifier: NotifierService) {
    }

    ngOnInit() {

        let employeeUniqueIdentifier = this._adalService.LoggedInUserEmail.split('@')[0];
        this.userConfig = this._userConfig.FetchLoggedInUser(employeeUniqueIdentifier)
        
        if (!this.userConfig.value.isITS) {
            this._router.navigate(['/home']);
            return;
        }
        else {

            this.cacheFormGroup = this.fb.group({
                key: ['', Validators.required],
                value: ['', Validators.required]
            });
            this.cacheFormArrayGroup = this.fb.group({
                cacheItems: this.fb.array([])
            });
            this.showAll();
        }
    }

    get cacheItems() {
        return this.cacheFormArrayGroup.get('cacheItems') as FormArray;
    }

    showAll() {

        var request = {};

        this._manageCacheService.getAllItems(request).subscribe(
            data => {

                this.cacheItems.clear();
                data.forEach(item => {
                    this.cacheItems.push(this.fb.group({
                        key: [item.key, Validators.required],
                        value: [item.value, Validators.required]
                    }));
                });
            },
            err => {
                console.log(err);
            });
    }

    save() {
        // debugger;
        var key = this.cacheFormGroup.get('key').value;
        var value = this.cacheFormGroup.get('value').value;
        var self = this;

        var request = {
            "key": key,
            "value": value
        };

        this._manageCacheService.addItem(request).subscribe(
            data => {
                if (data) {
                    self.notifier.notify(
                        "success",
                        "Item added successfully"
                    );
                    this.showAll();
                }
            },
            err => {
                console.log(err);
            }
        );

        this.cacheFormGroup.reset();
    }

    remove(item) {

        var key = item.get('key').value;
        var self = this;

        var request = {
            "key": key
        };

        this._manageCacheService.removeItem(request).subscribe(
            data => {
                if (data) {
                    self.notifier.notify(
                        "success",
                        "Item removed successfully"
                    );
                    this.showAll();
                }
            },
            err => {
                console.log(err);
            }
        );;

    }

    removeAllItems() {

        var self = this;

        var request = {};

        this._manageCacheService.removeAllItems(request).subscribe(
            data => {
                if (data) {
                    self.notifier.notify(
                        "success",
                        "Item removed successfully"
                    );
                    this.showAll();
                }
            },
            err => {
                console.log(err);
            }
        );;

    }


}
