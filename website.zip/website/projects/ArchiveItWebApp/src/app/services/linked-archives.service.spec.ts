import { TestBed } from '@angular/core/testing';

import { LinkedArchivesService } from './linked-archives.service';

describe('LinkedArchivesService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: LinkedArchivesService = TestBed.get(LinkedArchivesService);
    expect(service).toBeTruthy();
  });
});
