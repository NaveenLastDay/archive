﻿using Deloitte.AIFA.DomainEntities;
using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.IRepositories
{
    public interface IERPRepository
    {
        List<ERPConfigurationData> GetERPCpnfigurationData(string keys);
        List<EngagementPersonnelInfo> GetEngagementPersonnelInfo(string ArchiveNumber);
        List<ERPDetails> GetERPDetails(string searchquery);
        string GetPartnerAlias(string archiveNumber);
        DistributionList RemoveEngagementPersonnel(DistributionList distributionList);
        DistributionList AddEngagementPersonnels(DistributionList distributionList);
    }
}
