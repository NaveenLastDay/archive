import { Component, OnInit, ViewChild } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { SgfoldersService } from '../../../services/sgfolders.service';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
//import { ModalService } from '../../shared/modal/modal.service';
import { NotifierService } from "angular-notifier";

@Component({
  selector: 'app-sgfolders',
  templateUrl: './sgfolders.component.html',
  styleUrls: ['./sgfolders.component.css']
})
export class SgfoldersComponent implements OnInit {

  currentUrl: string;
  selectedpolicy: string;
  data: any;
  display: string = 'none';
  displaytable: boolean = false;
  displaybusiness: boolean = false;
  displaygroup: boolean = false;
  displayRecord2: boolean = false;
  displaybusiness2: boolean = false;
  displayArchiveType2: boolean = false;
  IsEnable: boolean = true;
  policyid: string;
  logedInForm: FormGroup;
  dataSource: any;
  IsChecked: boolean;

  displayedColumns: string[] = ['Business/Groups', 'FolderName', 'RecordCategory', 'ArchiveType', 'Grouping', 'IsDisabled', 'Action'];
  placeholderGroupingsType: string = '';
  popUpHeaderText: string;
  placeholderName: string = '';
  placeholderRecordCategory: any;
  placeholderPolicyGuidanceText: string = '';
  placeholderArchiveType: string;
  formData: FormData;
  selectedRecordCategoryName: Number;
  RecordCategories: any;
  businessName: string = '';
  Business: any = [];
  groupName: string = '';
  Group: any = [];
  ArchiveTypeName: string = '';
  ArchiveType: any;
  Name: string;
  RecordCategory: string;
  PolicyGuidanceText: string;
  GroupingsType: string;
  Active: string;
  placeholderBusiness: any;
  PolicyText: any;
  GroupingType: string;
  policies: any;
  RecordCategoriesBusinessGroup: any = [];
  CategoryNumber: any;
  CategoryName: any;
  groupId: any;
  businessId: any;
  RecordCategoryFolderMappingId: Number;
  FolderMappingData: any;
  selectedValEnable: string;
  index: number = 0;
  IndexBusiness: number = 0;
  IndexGroup: number = 0;

  constructor(private router: Router, private sgservice: SgfoldersService,
    private formBuilder: FormBuilder, private notifier: NotifierService) {
    router.events.subscribe((_: NavigationEnd) => this.currentUrl = this.router.url);
  }


  ngOnInit() {
    this.logedInForm = this.formBuilder.group({
      fullName: ['', Validators.required]
      // RequiredField: new FormControl("Required",
      // Validators.compose([
      // Validators.required
      //]))
    });
    this.getpolicies();

    this.notifier.notify("success", "Application loaded successfully.");

  }

  public onValChangeEnable(val: string) {
    this.selectedValEnable = val;
    if (this.selectedValEnable == "No") {
      this.IsEnable = false;
    }
    else this.IsEnable = true;


  }

  selectedRecordCategory(args) {
    this.selectedRecordCategoryName = args.target.value;
    let RecordCategoryString = args.target.options[args.target.selectedIndex].text;

    var CategoryNumArray = RecordCategoryString.split(" - ");
    this.CategoryNumber = CategoryNumArray[0].toString();
    this.CategoryName = CategoryNumArray[1].toString();
    if (this.selectedRecordCategoryName != 0) {
      this.displaybusiness = true;

      this.getBusiness();
      //this.CategoryNumber = this.RecordCategories.Number;


    }
    else {
      this.displaybusiness = false;
    }


  }

  getRecordCategories() {

    var parameters = {
      "details": {
        "parameters": {
          "FunctionName": "GetAllRecordCategoriesByPolicyId",
          "FunctionInput": {
            "PolicyId": this.selectedpolicy
          }
        }
      }
    }

    var myobjstr = JSON.stringify(parameters);
    this.sgservice.GetSystemFolders(myobjstr).subscribe(
      data => {

        this.RecordCategories = data.RecordCategories;
        // this.Business = data.RecordRetentionPolicies;
        // this.Group = data.Groups;
        this.RecordCategoriesBusinessGroup = data.RecordCategoriesBusinessGroup;
        // this.folderMapping();
      }

    );



  }

  selectedBusiness(args) {

    this.businessId = args.target.value;
    this.businessName = args.target.options[args.target.selectedIndex].text;
    if ((this.businessId != "0") && (this.selectedpolicy == "13")) {
      this.displaygroup = true;

    }
    else {
      this.displaygroup = false;
    }
  }

  getBusiness() {


    var businessList = [];
    var groupList = [];
    for (var i = 0; i < this.RecordCategoriesBusinessGroup.length; i++) {

      if (this.selectedRecordCategoryName == this.RecordCategoriesBusinessGroup[i].RecordCategoryId) {
        var dups = false;
        for (var k = 0; k < businessList.length; k++) {
          if (businessList[k].RecordRetentionPolicyId == this.RecordCategoriesBusinessGroup[i].RecordRetentionPolicyId)
            dups = true;


        }

        if (!dups) {

          var b = {
            RecordRetentionPolicyId: this.RecordCategoriesBusinessGroup[i].RecordRetentionPolicyId,
            id: this.RecordCategoriesBusinessGroup[i].RecordRetentionPolicyId,
            Text: this.RecordCategoriesBusinessGroup[i].BusinessName,
            BusinessName: this.RecordCategoriesBusinessGroup[i].BusinessName,
            selectDescription: this.RecordCategoriesBusinessGroup[i].BusinessName

          }
          businessList.push(b);
          this.Business = businessList;

          //this.businessName = this.Business.BusinessName;         
        }
        dups = false;
        for (var k = 0; k < groupList.length; k++) {
          if (groupList[k].GroupId == this.RecordCategoriesBusinessGroup[i].GroupId)
            dups = true;
        }
        if (!dups && this.RecordCategoriesBusinessGroup[i].GroupId > 0) {
          var c = {
            GroupId: this.RecordCategoriesBusinessGroup[i].GroupId,
            id: this.RecordCategoriesBusinessGroup[i].GroupId,
            Text: this.RecordCategoriesBusinessGroup[i].GroupName,
            GroupName: this.RecordCategoriesBusinessGroup[i].GroupName,
            selectDescription: this.RecordCategoriesBusinessGroup[i].GroupName
          }
          groupList.push(c);
          this.Group = groupList;
        }


      }

    }
  }

  selectedGroup(args) {
    this.groupId = args.target.value;
    this.groupName = args.target.options[args.target.selectedIndex].text;
  }

  // getGroups() {

  //   var parameters = {
  //     "details": {
  //       "parameters": {
  //         "FunctionName": "GetAllRecordCategoriesByPolicyId",
  //         "FunctionInput": {
  //           "BusinessIds": this.businessName
  //         }
  //       }
  //     }

  //   }
  //   var myobjstr = JSON.stringify(parameters);
  //   this.sgservice.GetSystemFolders(myobjstr).subscribe(
  //     data => {

  //       this.Group = data;
  //     },

  //   );
  // }

  selectedArchiveType(ArchiveType: any) {
    this.ArchiveTypeName = ArchiveType;
  }

  // getArchiveTypes()
  // {
  //   this.ArchiveType = this.service.GetArchiveType(this.selectedRecordCategoryName).subscribe(
  //     (posRes) => {
  //       this.ArchiveType = posRes;
  //     },
  //   );
  // }

  getpolicies() {

    var parameter = {
      "details": {
        "parameters": {
          "FunctionName": "GetPolicies",
          "FunctionInput": {}
        }
      }
    }
    var myobjstr = JSON.stringify(parameter);
    this.sgservice.GetSystemFolders(myobjstr).subscribe(
      data => {

        this.policies = data;
      }
    );
  }


  // get fval() {
  // return this.logedInForm.controls;
  //  } 


  selectPolicy(policyname: any) {
    this.selectedpolicy = policyname;
    this.router.navigate(["admin/sgfolders"]);
    if (this.selectedpolicy != 'Please select a Policy') {
      this.displaytable = true;
      //var functionName = JSON.stringify("");
      //var functionInput = JSON.stringify("this.selectedpolicy");
      // var json = functionName.concat(functionInput);
      //var parameters = JSON.stringify(json);
      var parameter = {
        "details": {
          "parameters": {
            "FunctionName": "GetAllSystemFolderMappingByPolicyId",
            "FunctionInput": { "PolicyId": this.selectedpolicy }
          }
        }
      }
      var myobjstr = JSON.stringify(parameter);

      // var parameters = JSON.parse(myobjstr);




      this.sgservice.GetSystemFolders(myobjstr).subscribe(
        data => {
          this.dataSource = data;

        }
      );
    }

    else {
      this.displaytable = false;
    }

  }

  openModalDialog(Action, obj) {
    this.display = 'block';
    if (Action == "Add") {

      this.popUpHeaderText = "Add System Generated Folders";
      this.Name = "";
      this.PolicyGuidanceText = "";
      this.GroupingType = "";
      this.index = 0;
      this.IndexBusiness = 0;
      this.IndexGroup = 0;
      if (this.selectedpolicy = "13") {
        this.displaybusiness = false;
        this.displaygroup = false;
      }
      this.getRecordCategories();

    }//Set block css
    if (Action == "Update") {
      this.popUpHeaderText = "Edit System Generated Folders";
      if (this.selectedpolicy = "12") {
        this.displaybusiness = true;
      }
      if (this.selectedpolicy = "13") {
        this.displaybusiness = true;
        this.displaygroup = true;
      }

      this.RecordCategoryFolderMappingId = obj.ECMRecordCategoryFolderMappingId;
      this.Name = obj.FolderName;
      this.PolicyGuidanceText = obj.GuidanceText;
      this.GroupingType = obj.GroupingType;
      //this.CategoryName = obj.RecordCategoryId.selectedRecordCategoryName;
      // this.CategoryName = this.selectedRecordCategory(obj.RecordCategoryId);


      this.folderMapping();
      this.getBusinessAndGroupsForEdit();
      this.getRecordCategories();


    }

  }

  getBusinessAndGroupsForEdit() {


    var businessList = [];
    var groupList = [];
    for (var i = 0; i < this.RecordCategoriesBusinessGroup.length; i++) {

      if (this.index == this.RecordCategoriesBusinessGroup[i].RecordCategoryId) {
        var dups = false;
        for (var k = 0; k < businessList.length; k++) {
          if (businessList[k].RecordRetentionPolicyId == this.RecordCategoriesBusinessGroup[i].RecordRetentionPolicyId)
            dups = true;


        }

        if (!dups) {

          var b = {
            RecordRetentionPolicyId: this.RecordCategoriesBusinessGroup[i].RecordRetentionPolicyId,
            id: this.RecordCategoriesBusinessGroup[i].RecordRetentionPolicyId,
            Text: this.RecordCategoriesBusinessGroup[i].BusinessName,
            BusinessName: this.RecordCategoriesBusinessGroup[i].BusinessName,
            selectDescription: this.RecordCategoriesBusinessGroup[i].BusinessName

          }
          businessList.push(b);
          this.Business = businessList;

          //this.businessName = this.Business.BusinessName;         
        }
        dups = false;
        for (var k = 0; k < groupList.length; k++) {
          if (groupList[k].GroupId == this.RecordCategoriesBusinessGroup[i].GroupId)
            dups = true;
        }
        if (!dups && this.RecordCategoriesBusinessGroup[i].GroupId > 0) {
          var c = {
            GroupId: this.RecordCategoriesBusinessGroup[i].GroupId,
            id: this.RecordCategoriesBusinessGroup[i].GroupId,
            Text: this.RecordCategoriesBusinessGroup[i].GroupName,
            GroupName: this.RecordCategoriesBusinessGroup[i].GroupName,
            selectDescription: this.RecordCategoriesBusinessGroup[i].GroupName
          }
          groupList.push(c);
          this.Group = groupList;
        }


      }

    }
  }



  folderMapping() {

    var parameter =

    {
      "details": {
        "parameters": {
          "FunctionName": "GetSystemPolicyFolderById ",
          "FunctionInput": { "FolderId": this.RecordCategoryFolderMappingId }
        }
      }
    }

    this.sgservice.GetSystemFolders(parameter).subscribe(
      data => {

        this.FolderMappingData = data;
        this.index = this.FolderMappingData.RecordCategoryId;
        this.IndexBusiness = this.FolderMappingData.BusinessIds;
        this.IndexGroup = this.FolderMappingData.GroupIds;
      }
    );

  }


  closeModalDialog() {
    this.display = 'none'; //set none css after close dialog
  }

  SaveClick() {

    if (this.popUpHeaderText == "Add System Generated Folders") {

      this.AddNewPolicy();

    }

    if (this.popUpHeaderText == "Edit System Generated Folders") {
      this.EditPolicy();

    }
  }

  AddNewPolicy() {
    var parameters = {
      "details": {
        "parameters": {
          "FunctionName": "AddSGFFolders",
          "FunctionInput": {
            "ECMRecordCategoryFolderMappingId": this.RecordCategoryFolderMappingId,
            "RecordCategoryId": this.selectedRecordCategoryName,
            "PolicyId": this.selectedpolicy,
            "FolderName": this.Name,
            "CategoryNumber": this.CategoryNumber,
            "GuidanceText": this.PolicyGuidanceText,
            "CreatedBy": -1,
            "IsEnabled": this.IsEnable,
            "EffectiveStartDate": Date,
            "ArchiveTypeId": 1,
            "ArchiveType": this.ArchiveTypeName,
            "BusinessIds": this.businessId,
            "Business": this.businessName,
            "GroupIds": this.groupId,
            "Group": this.groupName,
            "GroupingType": this.GroupingType,
            "UserPersonelNumber": 0
          }
        }
      }
    }

    var myobjstr = JSON.stringify(parameters);

    this.sgservice.AddNewPolicy(myobjstr).subscribe(
      data => {
        this.dataSource = this.dataSource.concat(data);

      }
    );

  }

  EditPolicy() {
    var parameter = {
      "details": {
        "parameters": {
          "FunctionName": "AddSGFFolders",
          "FunctionInput": {
            "ECMRecordCategoryFolderMappingId": this.RecordCategoryFolderMappingId,
            "RecordCategoryId": this.selectedRecordCategoryName,
            "PolicyId": this.selectedpolicy,
            "FolderName": this.Name,
            "CategoryNumber": this.CategoryNumber,
            "GuidanceText": this.PolicyGuidanceText,
            "CreatedBy": -1,
            "IsEnabled": this.IsEnable,
            "EffectiveStartDate": Date,
            "ArchiveTypeId": 1,
            "ArchiveType": this.ArchiveTypeName,
            "BusinessIds": this.businessId,
            "Business": this.businessName,
            "GroupIds": this.groupId,
            "Group": this.groupName,
            "GroupingType": this.GroupingType,
            "UserPersonelNumber": 0
          }
        }
      }
    }


    this.sgservice.AddNewPolicy(parameter).subscribe(
      data => {

        // // debugger;
        this.dataSource = this.dataSource.concat(data);

      }
    );








  }

}
