﻿using System;
using System.Collections.Generic;
using System.Text;
using Deloitte.AIFA.IRepositories;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Microsoft.Extensions.Logging;
using Deloitte.AIFA.DomainServices.Services;
using Deloitte.AIFA.DomainEntities;
//using Microsoft.Extensions.Caching.Memory;


namespace Deloitte.AIFA.DomainServices.Tests
{
    [TestClass]
    public class Form3283SUnitTestCases
    {
        private static readonly Mock<IFormRepository> _formRepository = new Mock<IFormRepository>();
        //private static readonly Mock<IMemoryCache> _memoryCache = new Mock<IMemoryCache>();
        //private static readonly Mock<IConfigManager> _configManager = new Mock<IConfigManager>()
        private static readonly Mock<ILogger<FormService>> _logger = new Mock<ILogger<FormService>>();
        private static FormService _formService = new FormService(null, null, _formRepository.Object,null, _logger.Object);

        [TestMethod]
        public void CreateForm_Success_ValidInput()
        {
            FormActionResponse result = new FormActionResponse();
            //Form input = new Form() { FormId = 1 };
            var input = new FormSubmitInfo() { 
                ActionsToBeTaken  = "abcd",
                Id=0,
                ArchiveNumber= "AEA501857",
                ProposedADCEDDate = Convert.ToDateTime("2020 - 08 - 24 18:30:00.000"),
                ReasonTypeIDs ="1,2,3",
                ReasonDescription ="",
                AdditionalDetails="my sample text",
                AuditPICAlias="resunanda",
                AuditPPDAlias="nseerapu",
                CreatedBy="ysaiyasaswini",
        };         
            _formRepository.Setup(x => x.CreateOrUpdateForm(input)).Returns(result);
            var actual = _formService.CreateOrUpdateForm(input);

            Assert.IsNotNull(actual);
            Assert.AreEqual(actual.GetType(), typeof(FormActionResponse));
            // Assert.IsTrue(actual.Count > 0);
        }

        
        [TestMethod]
        public void UpdateForm_Success()
        {
            FormActionResponse result = new FormActionResponse();
            FormSubmitInfo input = new FormSubmitInfo()
            {
                Id = 263,
                ArchiveNumber = "AEA501857",
                ProposedADCEDDate = Convert.ToDateTime("2020 - 08 - 24 18:30:00.000"),
                ReasonTypeIDs = "1,2,3",
                ReasonDescription = "",
                AdditionalDetails = "my sample test",
                ActionsToBeTaken = "my sample test",
                AuditPICAlias = "resunanda",
                AuditPPDAlias = "nseerapu",
                CreatedBy = "ysaiyasaswini",
            };
            _formRepository.Setup(x => x.CreateOrUpdateForm(input)).Returns(result);
            var actual = _formService.CreateOrUpdateForm(input);
            Assert.IsNotNull(actual);
            //Assert.AreEqual(actual, true);
        }

        //public static void Get_UpdateForm_Found()
        //{
        //    Form3283PrepopulatedData result = new Form3283PrepopulatedData();
        //    result.
        //}

        //[TestMethod]
        //public void GetFormsPrepopulatedData()
        //{
        //    Form3283PrepopulatedData sampletest = new Form3283PrepopulatedData();
        //    List<Form> result = new List<Form>();
        //    result.Add(new Form() { FormId = 1 });
        //    string archiveNumber = "AEA501857";
        //    string loggedInUser = "xyz";

        //    _formRepository.Setup(x => x.GetForm3283PrepopulatedData(archiveNumber, loggedInUser)).Returns(sampletest);
        //    var actual = _formService.GetFormsPrepopulatedData(archiveNumber, loggedInUser);

        //    Assert.IsNotNull(actual);
        //    Assert.AreEqual(actual.GetType(), typeof(List<Form>));
        //}


        [TestMethod]
        public void ApprovedForm_ValidInput()
        {
            FormActionResponse result = new FormActionResponse();
            ApproveOrRejectFormRequest request = new ApproveOrRejectFormRequest()
            {
                ActionItemId = 1,
                ApprovedBy = "ysaiyasaswini",
                RejectedBy = "ysaiyasaswini",
                IsEditRequired = true,
                RejectionReason = "test reject data"

            };

            _formRepository.Setup(x => x.ApproveForm(request)).Returns(result);
            var actual = _formService.ApproveForm(request);

            Assert.IsNotNull(actual);
            //Assert.AreEqual(actual, true);
        }

        [TestMethod]
        public void ApprovedForm_InvalidInput()
        {
            FormActionResponse result = new FormActionResponse();
            ApproveOrRejectFormRequest request = new ApproveOrRejectFormRequest()
            {
                ActionItemId = 0,
                ApprovedBy = "abcd",
                RejectedBy = "efgh",
                IsEditRequired = false,
                RejectionReason = "test data"

            };

            _formRepository.Setup(x => x.ApproveForm(request)).Returns(result);
            var actual = _formService.ApproveForm(request);

            Assert.IsNotNull(actual);
            //Assert.AreEqual(actual, true);
        }
        [TestMethod]
        public void GetFormStatus_WithRejectReason()
        {
            FormActionResponse result = new FormActionResponse();
            ApproveOrRejectFormRequest request = new ApproveOrRejectFormRequest()
            {
                ActionItemId = 2,
                ApprovedBy = "resunanda",
                RejectedBy = "resunanda",
                IsEditRequired = true,
                RejectionReason = "test reject data"
            };

            _formRepository.Setup(x => x.RejectForm(request)).Returns(result);
            var actual = _formService.RejectForm(request);

            Assert.IsNotNull(actual);
            Assert.AreEqual(actual.GetType(), typeof(FormActionResponse));
        }

        [TestMethod]
        public void GetFormStatus_ConfirmReject()
        {
            FormActionResponse result = new FormActionResponse();
            ApproveOrRejectFormRequest request = new ApproveOrRejectFormRequest()
            {
                ActionItemId = 2,
                ApprovedBy = "nseerapu",
                RejectedBy = "nseerapu",
                IsEditRequired = false,
                RejectionReason = null
            };
            _formRepository.Setup(x => x.RejectForm(request)).Returns(result);
            var actual = _formService.RejectForm(request);

            Assert.IsNotNull(actual);
            Assert.AreEqual(actual.GetType(), typeof(FormActionResponse));
        }
    }
}

