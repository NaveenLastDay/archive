﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
   public class ActiveRoles
    {
        public int RoleId { get; set; }
        public string EmployeeAlias { get; set; }
        public string EmployeeName { get; set; }
        public int DisplayOrder { get; set; }
        public DateTime ExpirationDate { get; set; }
        public int AccessStatus { get; set; }
    }
}
