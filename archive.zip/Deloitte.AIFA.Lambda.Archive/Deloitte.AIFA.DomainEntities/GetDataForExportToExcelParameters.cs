﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
    public class GetDataForExportToExcelParameters
    {
        public string SearchBy { get; set; }
        public string SearchByValue { get; set; }
        public string IncludeOrExclude { get; set; }
        public string HoldName { get; set; }
        public string Business { get; set; }
        public string PeriodStart { get; set; }
        public string PeriodEnd { get; set; }
        public string SortBy { get; set; }
        public string SortOrder { get; set; }
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
        public string ArchiveNumber { get; set; }
    }
}
