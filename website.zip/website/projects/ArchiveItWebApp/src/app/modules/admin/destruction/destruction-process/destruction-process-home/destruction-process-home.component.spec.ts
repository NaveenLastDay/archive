import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DestructionProcessHomeComponent } from './destruction-process-home.component';

describe('DestructionProcessHomeComponent', () => {
  let component: DestructionProcessHomeComponent;
  let fixture: ComponentFixture<DestructionProcessHomeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DestructionProcessHomeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DestructionProcessHomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
