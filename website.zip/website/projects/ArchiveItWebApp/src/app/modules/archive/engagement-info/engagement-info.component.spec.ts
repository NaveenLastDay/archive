import { async, ComponentFixture, TestBed, inject  } from '@angular/core/testing';

import { EngagementInfoComponent } from './engagement-info.component';
import { ReactiveFormsModule } from '@angular/forms';
import { MatDatepickerModule, MatNativeDateModule } from '@angular/material';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { ArchiveService } from '../../../services/archive.service';
import { RouterTestingModule } from '@angular/router/testing';

describe('EngagementInfoComponent', () => {
  let component: EngagementInfoComponent;
  let fixture: ComponentFixture<EngagementInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EngagementInfoComponent ],
      imports: [
        ReactiveFormsModule, 
        MatDatepickerModule, 
        MatNativeDateModule,
        HttpClientTestingModule,
        RouterTestingModule.withRoutes([]),
      ],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EngagementInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should called getengagementtypes methods', () => {
    let Result = component.getengagementtypes();    
    expect(component).toBeTruthy();
  });

  // it('should get list of engagementtypes ', () => {
  //   expect(component.engagements).toBeTruthy();
  // });

  // it(`should create`, async(inject([HttpTestingController, ArchiveService],
  //   (httpClient: HttpTestingController, apiService: ArchiveService) => {
  //     // debugger;
  //     var Result = apiService.GetEngagementType()
  //     expect(Result).toBeTruthy();
  // })));
});
