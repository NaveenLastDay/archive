﻿using Deloitte.AIFA.DataModels;
using Deloitte.AIFA.DomainEntities;
using Deloitte.AIFA.IRepositories;
using Deloitte.AIFA.Repositories.Transformers;
using Microsoft.Extensions.Caching.Memory;
using MySqlConnector;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Deloitte.AIFA.Repositories.Repository
{
    public class LinkedArchiveRepository : BaseRepository<LinkedArchiveField>, ILinkedArchiveRepository
    {
        IMemoryCache _cache;
        public LinkedArchiveRepository(IMemoryCache cache) : base(cache)
        {
            _cache = cache;
        }

        public List<LinkedArchives> GetListofLinkedArchiveDetails(string userAlias, string archiveNumber, int pageNumber, int pageSize, int sortBy)
        {
            try
            {
                var parameters = new MySqlParameter[]
                {
                    new MySqlParameter("@p_UserAlias", MySqlDbType.VarChar) {Value = userAlias},
                    new MySqlParameter("@p_ArchiveNumber", MySqlDbType.VarChar) {Value = archiveNumber},
                    new MySqlParameter("@In_PageNumber", MySqlDbType.Int32) {Value = pageNumber},
                    new MySqlParameter("@In_PageSize", MySqlDbType.Int32) {Value = pageSize},
                    new MySqlParameter("@p_SortBy", MySqlDbType.Int32) {Value = sortBy},
                };
                var result = DbHelper.ExecuteReader(
                    "pub_AIFA_GetLinkedHeirArchives_Test_multiple",
                    parameters,
                        dr => new LinkedArchiveTransformer().Transform(dr).ToList());

                return _mapper.Map<List<LinkedArchivesModel>, List<LinkedArchives>>(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<LinkTypes> GetLinkingTypes()
        {
            try
            {
                var result = DbHelper.ExecuteReader(
                    "pub_AIFA_GetLinkedArchiveTypes",
                    null,
                        dr => new LinkedArchiveTypeTransformer().Transform(dr).ToList());

                return _mapper.Map<List<LinkTypeModel>, List<LinkTypes>>(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string InsertLinkedArchiveDetails(string archiveNumber, string linkedArchiveNumber, string createdBy)
        {
            try
            {
                var parameters = Builder.Bind(LinkedArchiveFieldParameters.ArchiveNumber).On(archiveNumber)
                                        .Bind(LinkedArchiveFieldParameters.CreatedBy).On(createdBy)
                                        .Bind(LinkedArchiveFieldParameters.LinkedArchiveNumber).On(linkedArchiveNumber)
                                        .Bind(LinkedArchiveFieldParameters.InsertOutput).On()
                                        .Build();

                return DbHelper.ExecuteNonQuery("pub_InsertLinkedArchives", parameters
                , cmd => cmd.Parameters["@p_InsertOutput"].Value.ToString());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool UpdateLinkedArchiveDetails(string archiveNumber, string linkedArchiveNumber, int? linkTypeId, string opertaionType, string createdBy)
        {
            try
            {
                var parameters = Builder.Bind(LinkedArchiveFieldParameters.ArchiveNumber).On(archiveNumber)
                                        .Bind(LinkedArchiveFieldParameters.CreatedBy).On(createdBy)
                                        .Bind(LinkedArchiveFieldParameters.LinkedArchiveNumber).On(linkedArchiveNumber)
                                        .Bind(LinkedArchiveFieldParameters.LinkTypeId).On(linkTypeId)
                                        .Bind(LinkedArchiveFieldParameters.OpertaionType).On(opertaionType)
                                        .Build();
                DbHelper.ExecuteNonQuery(
                    "pub_AIFA_UpdateLinkedArchiveDetails",
                    parameters);

                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
