﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
   public  class EntityType
    {
        public string EntityTypeDescription { get; set; }
        public int EntityTypeId { get; set; }
       
    }
}
