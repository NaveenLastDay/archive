﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
    public class UserActions
    {
        public bool canSearchArchives { get; set;}
        public bool canAccesArchives { get; set;}
        public bool CanCreateArchive { get; set;}
        public bool CanManageArchiveInfo { get; set;}
        public bool CanManageAccess { get; set;}
        public bool CanSubmit { get; set;}
        public bool CanDownload { get; set;}
        public bool CanDelete { get; set;}
        public bool CanMarkAsInactive { get; set;}
        public bool CanManageERP { get; set;}
        public bool CanRequestRetentionException { get; set;}
        public bool CanRequestAccess { get; set;}
        public bool CanApproveTemporaryAccess { get; set;}
        public bool CanViewArchiveHistory { get; set;}
        public bool CanPrintBinderReportCovers { get; set;}
        public bool CanRequestImage { get; set;}
        public bool CanLinkArchives { get; set;}
        public bool CanApprove { get; set;}
        public bool CanResubmitAdminApproval { get; set;}
        public bool CanRequestArchiveDeletion { get; set;}
        public bool CanRequestForm3283S { get; set;}
        public bool CanRequestLegalHold { get; set;}
        public bool CanTempArchiveAccess { get; set;}

    }
}
