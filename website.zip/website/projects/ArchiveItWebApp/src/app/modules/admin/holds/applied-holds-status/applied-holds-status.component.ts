import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { FormBuilder, Validators } from '@angular/forms';
import { HoldsService } from '../../../../services/holds-admin.service';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { NgbTooltip } from '@ng-bootstrap/ng-bootstrap';
import { ArchiveSearchService } from '../../../../services/archive-search.service';
import { SearchEventService } from '../../../search/search.event.service';
import { SharedService } from '../../../../services/shared.service';
import { NotifierService } from 'angular-notifier';
import { formatDate } from '@angular/common';
import { MatAutocompleteSelectedEvent } from '@angular/material';

import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-applied-holds-status',
  templateUrl: './applied-holds-status.component.html',
  styleUrls: ['./applied-holds-status.component.css']
})
export class AppliedHoldsStatusComponent implements OnInit {

  @ViewChild('selectAll', {static: false}) selectAllCheckbox: ElementRef;
  currentUrl: string;
  PeriodStartDate : string = '0';
  startDate:any;
  EndDate:any;
  PeriodEndDate : string = '0';
  placeholderText : string = "Search by client name";
  selectedlist :  Array<any> = [];
  selectedHoldsList: Array<any> = [];
  clientChecked : boolean = true;
  archiveNumberChecked : boolean = false;
  archiveNameChecked : boolean = false;
  recordDescChecked : boolean = false;
  isInSearchScreen : boolean = true;
  SelectedListOfClients:string;
  searchByText : string = '';
  AddHoldsText : string = '';
  hoverIndex: number = -1;
  dataSource : any;
  Archives : any[];
  allArchives : any = [];
  SearchClient:any[];
  holdName:string;clientName:string;business:string;
  effectiveStartDate:Date;effectiveEndDate:Date;
  status:string;archivesCount:number;
  employeeUniqueIdentifier: string = "";
  myForm;
  show : boolean = false;
  selectedArchives: any = [];
  SearchBy : string = 'Client';
  SearchByValue : string = '';
  IncludeOrExclude : string = '0';
   SortBy : string = '0';
  SortOrder : string = '0';
  PageNumber : number = 1;
  readonly PageSize : number = 1000;
  appendtoGrid : boolean = false;
  totalArchivesForApplyingHolds : number = 0;
  selectedClientViewName: string = "";
  selectedClient: string;
  selectedClients: Array<any> = [];
  clients: Array<any> = [];
  index: number = 0;
  selectedAppliedHold:string='Include';
  isClientFilter:boolean = false;
  clientFilterList:Array<any> =[];
  searchAlias:string='Client';
  SearchByValueCollectionforExport:string;
  CheckAuditCheckBoxforAutopopulate:boolean;
  masterSelected : boolean =  false;
  filterdColumnsChunks : any;
  
  /*sorting */
  columnByEnum: any = HoldsDetailsColumnBy;
  sortColumnDialog: number = -1;
  sortColumn : string ='0';
  sortascdesc: string='0';
  sortBy: number = 0;
  disableBtn:boolean=true;
  disableApplyBtn : boolean = true;
  

  childloader:boolean = true;
  /*sorting*/

  /*Export to Excel */
 holdsResultGridColumns: any =HoldsResultGridColumns;
 readonly emptyStringInReport : string = " ";
 IncludeExclude;
 columnFilters: any[] =
 [
   
   {
     "displayName": "ClientName",
     "value": this.holdsResultGridColumns.ClientName,
     "checked": true
   },
   {
    "displayName": "ArchiveName",
    "value": this.holdsResultGridColumns.ArchiveName,
    "checked": true
  },
   {
     "displayName": "RecordDescription",
     "value": this.holdsResultGridColumns.RecordDescription,
     "checked": true
   },
   {
     "displayName": "Archive#",
     "value": this.holdsResultGridColumns.ArchiveNumber,
     "checked": true
   }
 ]
  filteredArchives: any[];
 /*Export to Excel */

  constructor(private router: Router,fb: FormBuilder, private _HoldsService: HoldsService,private adalSvc: MsAdalAngular6Service, private search: ArchiveSearchService, private searchEventService: SearchEventService,private sharedService: SharedService,private notifier: NotifierService, private spinnerServices:NgxSpinnerService) {
    router.events.subscribe((_: NavigationEnd) => this.currentUrl = this.router.url);
    this.myForm = fb.group({
      'inputClientName': [null, Validators.required],
      'inputArchiveName': [null, Validators.required],
      'inputHoldsName': [null, Validators.required],
      'EffectiveStartDate': [null, Validators.required],
      'EffectiveEndDate': [null, Validators.required],
      'checkboxgroup' : [null, Validators.required],
      'radiogroup' : ['clientNameRadio', Validators.required]
    });
   }

  ngOnInit() {
   
    this.employeeUniqueIdentifier = this.adalSvc.LoggedInUserEmail.split('@')[0];
    var retriveHoldObject = localStorage.getItem('holdObject');
    console.log('',JSON.parse(retriveHoldObject))
    var parshedHoldObject =JSON.parse(retriveHoldObject)
    //console.log('',JSON.parse(parshedHoldObject))
    this.clientChecked = true;
    this.holdName=parshedHoldObject.holdName;
    this.clientName=parshedHoldObject.clientName;
    this.selectedClients.push(this.clientName);
    this.business=parshedHoldObject.business;
    this.IncludeExclude=[];
    let potentialProduct = [
      {
        key: 1, value: `Include`,
      },
      {
        key: 2, value: `Exclude`,
      }
    ]
 this.IncludeExclude = potentialProduct;
    if(this.business=='Audit')
    {
      this.CheckAuditCheckBoxforAutopopulate=true;
    }
    else{
      this.CheckAuditCheckBoxforAutopopulate=false;
    }
    this.effectiveStartDate=parshedHoldObject.effectiveStartDate;
    this.effectiveEndDate=parshedHoldObject.effectiveEndDate;
    this.PeriodStartDate=parshedHoldObject.effectiveStartDate;
    this.startDate = this.convertstringTodateObj(this.PeriodStartDate.split("T")[0]);   
    this.PeriodEndDate=parshedHoldObject.effectiveEndDate;
    this.EndDate = this.convertstringTodateObj(this.PeriodEndDate.split("T")[0]);  
    this.status=parshedHoldObject.status;
    this.archivesCount=parshedHoldObject.archivesCount;


    //this.GetHoldDetailsData('1')
  }
  getArchiveSelection(isSelected, archiveNum){
    debugger;
    if(isSelected){
      let obj=
      {
        archiveNumber : archiveNum
      }
      this.selectedArchives.push(obj)
      if(this.selectedArchives.length === (this.PageSize*this.PageNumber) || (this.selectedArchives.length === this.totalArchivesForApplyingHolds) )
      {
        this.masterSelected = true;
      }
    }
    else{
      this.masterSelected = false;
      this.selectedArchives = this.selectedArchives.filter(({ archiveNumber }) => archiveNumber !== archiveNum);

    }
    console.log(isSelected, archiveNum)
    console.log("Arraydata", this.selectedArchives)

  }
  navigateApplyHoldsConfirmation(){
   
    // let archiveCollection: string="";
    // this.selectedArchives.forEach(function (value) {
    //   if(archiveCollection!='')
    //   archiveCollection= archiveCollection.concat(","+value.archiveNumber.toString());
    //   else
    //   archiveCollection=value.archiveNumber
    // });

    let archiveHoldsInfo = {
      ArchiveNumber:this.selectedArchives
    };
    console.log("archiveHoldsInfo",archiveHoldsInfo)
    //this._HoldsService.ApplyArchiveHolds(archiveHoldsInfo).subscribe(response => {
     
      //var appliedHoldObject =response;
      localStorage.setItem('archiveHoldsInfo', JSON.stringify(archiveHoldsInfo));
      //console.log("response",response);
      this.router.navigate(["/admin/adminsidenavbar/holds/applyHoldconfirmation"]);
    //});

  //setTimeout(() => { this.router.navigate(["/admin/holds/applyHoldconfirmation"]) }, 5000);
  }

  SearchBySelectedRadio(e){   
    
     console.log(e.target.id);
     this.clients = [];
     this.selectedClientViewName="";
     if(this.archiveNumberChecked==true)
     {
        this.selectedClients = [];
        this.selectedlist=[];
     }
    
     if(e.target.id==="clientNameRadio"){
      this.placeholderText="Search by client name";
      this.SearchBy = 'Client';
      this.searchAlias = 'Client';
      this.clientChecked = true;
      this.archiveNameChecked = false;
      this.archiveNumberChecked=false;
      this.recordDescChecked = false;
     }
     else if(e.target.id==="archiveNameRadio"){
      this.placeholderText="Search by archive name";
      this.SearchBy = 'ArchiveName';
      this.searchAlias = 'Archive Name';
      this.clientChecked = false;
      this.archiveNameChecked = true;
      this.archiveNumberChecked=false;
      this.recordDescChecked = false;
     }
     else if(e.target.id==="rDescriptionRadio"){
      this.placeholderText="Search by record description";
      this.SearchBy = 'rDescriptionRadio';
      this.searchAlias = 'Record Description';
      this.clientChecked = false;
      this.archiveNameChecked = false;
      this.archiveNumberChecked=false;
      this.recordDescChecked = true;
     }
     else if(e.target.id==="archiveNumberRadio"){
      this.placeholderText="Search by archive number";
      this.SearchBy = 'ArchiveNumber';
      this.searchAlias = 'Archive Number';
      this.clientChecked = false;
      this.archiveNameChecked = false;
      this.archiveNumberChecked=true;
      this.recordDescChecked = false;
      this.selectedClients = []; // New implementation  - part of demo feedback story
      this.selectedlist=[]; // New implementation  - part of demo feedback story
     }
  }
  SearchBySelectedCheckBox(e){
 
  }
  onFieldSelect(e){
    this.IncludeExclude=[];
    let potentialProduct = [
      {
        key: 1, value: `Include`,
      },
      {
        key: 2, value: `Exclude`,
      }
    ]

    
     if(e.target.value == '1')
     {
      this.selectedAppliedHold = 'Include'; 
      potentialProduct = [
        {
          key: 1, value: `Include`,
        },
        {
          key: 2, value: `Exclude`,
        }
      ]
      }
      else{
        potentialProduct = [
          {
            key: 2, value: `Exclude`,
          },
          {
            key: 1, value: `Include`,
          }
        ]
      this.selectedAppliedHold = 'Exclude';
      }
      this.IncludeExclude = potentialProduct;
  }
  mouseOver(event: any, index: number) {
    this.hoverIndex = index;
    //event.stopPropagation();
  }

  mouseOut(event: any) {
    let name: string = '';
    let present: number = -1;

    name = event.toElement ? event.toElement.getAttribute('name') : '';
    present = name ? name.search("AccessArchiveTop") : -1;

    if (event.toElement && present == -1 && (event.toElement["tagName"] != 'td' || event.toElement.className == 'trHoldsGridHeadFont')) {
      this.hoverIndex = -1;
    }
  }
  onDateChange(event:any, val:string){
    if(event != null){
    if(val == 'periodStart'){
      this.startDate = event;
     this.PeriodStartDate = new Date(event.year, event.month - 1, event.day).toString();
    }else{
      this.EndDate = event;
      this.PeriodEndDate = new Date(event.year, event.month - 1, event.day).toString();
    }
  }
  }
  keyupDateChange(event:string, val:string){
    var pattern = new RegExp("[0-9]{2}/[0-9]{2}/[0-9]{4}");
      if(pattern.test(event)){
        (val == 'periodStart') ? this.PeriodStartDate = event : this.PeriodEndDate = event;
     
      }else{
        (val == 'periodStart') ? this.PeriodStartDate = null : this.PeriodEndDate = null;
  }
  }
  NavigateArchiveResults(){
    var SearchByValueCollection : string = "";
    SearchByValueCollection = this.selectedlist.join();
  
   
   if(this.SearchBy==='Client'){
        this.SearchClient=this.selectedClients;
        SearchByValueCollection = this.selectedClients.join(';');
   }
   else if(this.SearchBy==='ArchiveNumber' && this.selectedlist.length==1 && this.selectedlist[0].indexOf('|')!==-1 ){
    SearchByValueCollection=  this.selectedlist.join().split('|').join();
  }

   this.SearchByValueCollectionforExport=SearchByValueCollection;
   this.getArchivesResults(SearchByValueCollection);
  }

  getArchivesResults(SearchByValueCollection:string){
    var HoldCollection : string = "0";
    if(this.selectedHoldsList.length > 0){
    HoldCollection = this.selectedHoldsList.join();
    }   
    var periodStartDate = this.PeriodStartDate != "0" && this.PeriodStartDate != null? new Date(this.PeriodStartDate).toLocaleDateString():"0";
    var periodEndDate = this.PeriodEndDate != "0" && this.PeriodEndDate != null? new Date(this.PeriodEndDate).toLocaleDateString():"0";

if(periodStartDate !== "0" && periodEndDate ==="0" ){
  this.notifier.notify("error","Effective End Date is required");
  return;
}
else if(periodStartDate === "0" && periodEndDate !=="0" ){
  this.notifier.notify("error","Effective Start Date is required");
  return;
}
else if( formatDate(periodEndDate,'yyyy-MM-dd','en_US')  < formatDate(periodStartDate,'yyyy-MM-dd','en_US') ) {
  this.notifier.notify("error","Effective Start Date should be less than Effective End Date");
  return;
}
else
{
  this.show = false;
  //this.SpinnerService.show();
  this.isInSearchScreen=false;
  this.masterSelected = false;

  let ExportToExcelParams1={
    SearchBy:this.SearchBy,
    SearchByValue:SearchByValueCollection,
    IncludeOrExclude:this.selectedAppliedHold,
    HoldName:HoldCollection,
    Business:this.business,
    PeriodStart:periodStartDate,
    PeriodEnd:periodEndDate,
    SortBy:this.sortColumn,
    SortOrder:this.sortascdesc, 
    PageNumber:this.PageNumber,
    PageSize:this.PageSize
  };

   // this._HoldsService.GetArchivesForApplyingHold(this.SearchBy,SearchByValueCollection,this.selectedAppliedHold,HoldCollection,this.business,periodStartDate,periodEndDate,this.sortColumn,this.sortascdesc, this.PageNumber, this.PageSize).subscribe(response => {
    this._HoldsService.GetArchivesForApplyingHold(ExportToExcelParams1).subscribe(response => {
      if (this.appendtoGrid && response) {
        for(var i =0;i<response.length;i++){
          this.Archives.push(response[i]);
        }
      }
      else{
        // this.totalHolds = data[0]["count"];
        this.Archives = response ? response : [];
      }
      if(response.length>0){
        this.totalArchivesForApplyingHolds = response[0]["count"];
      }
      else{
        this.notifier.notify("error","No results found");
        this.totalArchivesForApplyingHolds = 0;
        this.isInSearchScreen=true;
      }
     // this.SpinnerService.hide();
    // this.getHoldsCount();
    });
  }
}
  ResetResults(){
    this.isInSearchScreen=true;
    this.ResetSearchParameters();
  }
  NavigateBack(){
    if(this.isInSearchScreen==false){
      this.isInSearchScreen=true;
    }
    else{
      this.router.navigate(["/admin/adminsidenavbar/holds/holdsearch"]);
    }
  }

  ResetSearchParameters(){
 
    this.myForm.reset();
    this.selectedHoldsList = [];
    this.selectedlist = [];
    this.selectedClients=[];
    this.searchByText='';
    this.AddHoldsText='';
    this.selectedClientViewName ='';
    this.selectedClients = [];
    this.clientFilterList = [];
    this.searchEventService.selectedClientsList=[];
    this.myForm.controls.radiogroup.patchValue('clientNameRadio');
    this.selectedAppliedHold = 'Include';
    this.masterSelected = true;
  this.selectedArchives = [];
  }
  deleteItem(deleteItem, event:Event){
    event.stopPropagation();
    this.selectedlist = this.selectedlist.filter(e => e !== deleteItem);
  }
  deleteHoldItem(deleteItem, event:Event){
    event.stopPropagation();
    this.selectedHoldsList = this.selectedHoldsList.filter(e => e !== deleteItem);
  }
  onSelectSearchBy(item) {
    if (item == "null") {

    }
    else {
      if (this.selectedlist.length > 0) {
        var statusExists = this.selectedlist.findIndex(x => x.Status == item)
        if (statusExists == -1) {
          this.selectedlist.push(item);
        }
      }
      else {
        this.selectedlist.push(item);
      }
    }
  }
  AddHoldsList(item) {
    if (item == "null") {

    }
    else {
      if (this.selectedHoldsList.length > 0) {
        var statusExists = this.selectedHoldsList.findIndex(x => x.Status == item)
        if (statusExists == -1) {
          this.selectedHoldsList.push(item);
        }
      }
      else {
        this.selectedHoldsList.push(item);
      }
    }
  }
  onSearchBy(searchByValue){
  this.searchByText = searchByValue;
  }
  OnHoldSearch(searchByValue)
  {
  this.AddHoldsText = searchByValue;
  }
  AddSearchBy(){
   
    if(this.searchByText !=''){
      this.onSelectSearchBy(this.searchByText);
  }
    this.searchByText='';
  }
  AddHolds(){
    
    if(this.AddHoldsText !=''){
      this.AddHoldsList(this.AddHoldsText);
    }
    this.AddHoldsText='';
    this.router.navigate(["/admin/adminsidenavbar/holds/holdsearch/applyHold"]);
  }
  closeContent(){
    this.show = false;
  }
  toggle(){
    this.show = true;
  }
  SearchToggle(){
    this.show = false;
  }
  updateGridData(event) {
    this.selectAllCheckbox.nativeElement.checked = false;
    //this.SpinnerService.show();
    this.appendtoGrid = event.isLoadMoreClicked;
    this.PageNumber = event.pageNumber;
    this.NavigateArchiveResults();
  }

  /*Search Archives Sample Data */
  // GetHoldDetailsData(x : string) {
  //   this.dataSource= [
  //     {clientName:"ABC Company",archiveName:"archiveNumber1",recordDescription:"Dev Data",archiveNumber:"AEA502324"},
  //     {clientName:"ABC Company",archiveName:"archiveNumber2",recordDescription:"Dev Data",archiveNumber:"AEA502323"},
  //     {clientName:"ABC Company",archiveName:"archiveNumber3",recordDescription:"Dev Data",archiveNumber:"AEA502322"},
  //     {clientName:"ABC Company",archiveName:"archiveNumber4",recordDescription:"Dev Data",archiveNumber:"AEA502321"},
  //     {clientName:"ABC Company",archiveName:"archiveNumber5",recordDescription:"QA Data",archiveNumber:"AEA502667"},
  //     {clientName:"Audit compa",archiveName:"archiveNumber6",recordDescription:"QA Data",archiveNumber:"AEA502666"},
  //     {clientName:"Audit compa",archiveName:"archiveNumber7",recordDescription:"QA Data",archiveNumber:"AEA502665"},
  //     {clientName:"Audit compa",archiveName:"archiveNumber8",recordDescription:"QA Data",archiveNumber:"AEA502664"},
  //     {clientName:"Audit compa",archiveName:"archiveNumber9",recordDescription:"STG Data",archiveNumber: "AEA595762"},
  //     {clientName:"Audit compa",archiveName:"archiveNumber10",recordDescription:"STG Data",archiveNumber:"AEA595761"},
  //     {clientName:"Audit compa",archiveName:"archiveNumber11",recordDescription:"STG Data",archiveNumber:"AEA595760"},
  //     {clientName:"Audit compa",archiveName:"archiveNumber12",recordDescription:"STG Data",archiveNumber:"AEA595759"}


  //   ];

  //    this.Archives=this.dataSource;
  //    this.SearchClient=
  //    [
  //      "ABC","Audit"
  //    ]
  // }
  /**/
  ApplyHoldsCheckboxSelectAll(e: any) {
debugger;
if(e.target.checked === true){
  this.masterSelected = true;
  this.selectedArchives = [];
}
else{
  this.masterSelected = false;
  this.selectedArchives = [];
}

     for(let i=0; i < this.Archives.length; i++){
       (e.target.checked) ? this.Archives[i].isSelected =true : this.Archives[i].isSelected = false;
       this.getArchiveSelection(this.Archives[i].isSelected, this.Archives[i].archiveNumber);
     }
  }
  //Client
  //To get client Details
  onClientInputChanged(searchString: string) {

    this.clients = [];
    if (searchString.length >= 3) {
      this.search.getArchiveSearchResults(searchString, "Client").subscribe(result => {
        if (result.length > 0) {
          this.clients = result;
          this.clients.forEach(function(e){e.CheckedState=false});
          if(this.selectedClients.length>0)
          {
            this.clients.forEach(MainDataSet=>{
              this.selectedClients.forEach
               (item=>{
                 if (item==MainDataSet["itemName"])
                  {
                    //console.log('this.MainDataSet - loop result',MainDataSet["itemName"]);
                    //console.log('this.selectedClients - loop result',item);
                    MainDataSet.CheckedState=true;
                }
               })
             });
          }
        }
        else {
          this.clients = null;

        }
      },
        (err) => {
          console.log("error is ", err)
        }
      );
    }
    else if (searchString.length == 0) {
      this.clients = [];
    }
    else {
      this.clients = [];
    }
    //this.spinnerServices.hide();
  }

  toggleSelection(user, index, isChecked: boolean) {
    if(isChecked==null)
    {
      this.selectedClient=user;
    }
    else if(isChecked==true)
    {
      this.selectedClient=user.itemName;
    }
    if(isChecked==true || (isChecked==null && this.selectedClient!="" && this.selectedClient!=undefined && this.selectedClient!="undefined" && this.selectedClient!=null))
    {
      //this.selectedClient=user.itemName;
       if (this.searchEventService.selectedClientsList.length > 0) {
         var clientExists = this.searchEventService.selectedClientsList.findIndex(x => x.ClientName == this.selectedClient)
         if (clientExists == -1) {
           this.searchEventService.selectedClientsList.push({ Index: this.index++, ClientName: this.selectedClient });
           this.selectedClients.push(this.selectedClient);
           this.searchEventService.customRuleJson.push({
             Index: this.index++,
             ClientName: this.selectedClient
           });
         this.searchEventService.showApplied = false;
         this.searchEventService.showApplyAll = true;
         }
       }
        else {
          this.selectedClients.push(this.selectedClient);
          this.searchEventService.selectedClientsList.push({ Index: this.index++, ClientName: this.selectedClient });
          this.searchEventService.customRuleJson.push({
            Index: this.index++,
            ClientName: this.selectedClient
          });
          this.searchEventService.showApplied = false;
          this.searchEventService.showApplyAll = true;
        }
  }
  else if(isChecked==false){
    this.selectedClients = this.selectedClients.filter(e => e !== user.itemName);
    this.searchEventService.customRuleJson = this.searchEventService.customRuleJson.filter(x => !(x.ClientName == user.itemName));
    this.searchEventService.selectedClientsList = this.searchEventService.selectedClientsList.filter(x => x.ClientName !== user.itemName);
    this.searchEventService.showApplied = false;
    this.searchEventService.showApplyAll = true;
  }
  }

  //To store the selected Client details
  selectedClientName(client, index) {
   
    this.selectedClientViewName = client.source.viewValue;
    this.selectedClient = this.clients[index].itemName;
    if (this.searchEventService.selectedClientsList.length > 0) {
      var clientExists = this.searchEventService.selectedClientsList.findIndex(x => x.ClientName == this.selectedClient)
      if (clientExists == -1) {
        this.searchEventService.selectedClientsList.push({ Index: this.index++, ClientName: this.selectedClient });
        this.selectedClients.push(this.selectedClient);
        this.searchEventService.customRuleJson.push({
          Index: this.index++,
          ClientName: this.selectedClient

        });
        this.searchEventService.showApplied = false;
        this.searchEventService.showApplyAll = true;
      }
    }
    else {
      this.selectedClients.push(this.selectedClient);
      this.searchEventService.selectedClientsList.push({ Index: this.index++, ClientName: this.selectedClient });
      this.searchEventService.customRuleJson.push({
        Index: this.index++,
        ClientName: this.selectedClient
      });
      this.searchEventService.showApplied = false;
      this.searchEventService.showApplyAll = true;
    }
    console.log(this.selectedClients);
    //change to useralias once lambda is changed.
    this.clients = [];
    this.selectedClientViewName="";
    this.myForm.get('inputClientName').reset();

  }
  //To delete the selected Client
  deleteClient(clientName, event:Event) {
    event.stopPropagation();
    this.selectedClients = this.selectedClients.filter(e => e !== clientName);
    this.searchEventService.customRuleJson = this.searchEventService.customRuleJson.filter(x => !(x.ClientName == clientName));
    this.searchEventService.selectedClientsList = this.searchEventService.selectedClientsList.filter(x => x.ClientName !== clientName);
    this.searchEventService.showApplied = false;
    this.searchEventService.showApplyAll = true;
  }

  checkObj(val:any){
    
    var d =  this.selectedArchives.find(x => x.archiveNumber == val.archiveNumber);
      if(d != undefined && d.archiveNumber.length > 0 ){
       val.isSelected = true;
      }else{
        val.isSelected = false;
      }

  }

  clientFilter(){
    this.toggleClientFilter();
    var SearchByValueCollection = this.selectedlist.join();
    if(this.searchAlias==='Client'){
      SearchByValueCollection = this.selectedClients.join();
   }
    this.getAllArchivesbyFilter(SearchByValueCollection);
    
  }

  toggleClientFilter(){
    this.isClientFilter = !this.isClientFilter;
  }

  appliedClientFilter(obj:any){
     
     let objList =[];
     let selectedSearch:string ='';
     switch(this.searchAlias){
       case 'Client' : selectedSearch = 'clientName';
       break;
       case 'Archive Name' : selectedSearch = 'archiveName';
       break;
       case 'Record Description' : selectedSearch = 'recordDescription';
       break;
       case 'Archive Number' : selectedSearch = 'archiveNumber';
       break;
     }
     for(let i=0; i < obj.length; i++){
        objList.push(obj[i][selectedSearch]);
     }
    var SearchByValueCollection = objList.join();    
     this.getArchivesResults(SearchByValueCollection);     
     this.isClientFilter = false;
  }

  getAllArchivesbyFilter(SearchByValueCollection:string){
    var HoldCollection : string = "0";
    HoldCollection = this.selectedHoldsList.join();
    var periodStartDate = this.PeriodStartDate != "0" && this.PeriodStartDate != null? new Date(this.PeriodStartDate).toLocaleDateString():"0";
    var periodEndDate = this.PeriodEndDate != "0" && this.PeriodEndDate != null? new Date(this.PeriodEndDate).toLocaleDateString():"0";
   
    let ExportToExcelParams2={
      SearchBy:this.SearchBy,
      SearchByValue:SearchByValueCollection,
      IncludeOrExclude:this.selectedAppliedHold,
      HoldName:HoldCollection,
      Business:this.business,
      PeriodStart:periodStartDate,
      PeriodEnd:periodEndDate,
      SortBy:this.sortColumn,
      SortOrder:this.sortascdesc, 
      PageNumber:0,
      PageSize:0
    };

    //this._HoldsService.GetArchivesForApplyingHold(this.SearchBy,SearchByValueCollection,this.selectedAppliedHold,HoldCollection,this.business,periodStartDate,periodEndDate,this.sortColumn,this.sortascdesc, 0, 0).subscribe(response => {
     this._HoldsService.GetArchivesForApplyingHold(ExportToExcelParams2).subscribe(response => {
      if(response.length > 0){
        this.masterSelected = false;
        if(this.clientFilterList.length == 0){
          this.clientFilterList = response.filter((thing, i, arr) => {
              return arr.indexOf(arr.find(t => t.clientName === thing.clientName)) === i;
            });
            this.clientFilterList.map(obj => obj.isSelected = true );

              this.childloader = false;
            
          }
      }
   
  });
  }

  memberSortDialog(event) {
  
    if (this.sortColumnDialog == event) this.sortColumnDialog = -1;
    else
    this.sortColumnDialog = event;
    console.log("memberSortDialog",this.sortColumnDialog);
  }
  sortOrderChanged(event) {
    
    console.log("sortOrderChanged"+true);
    this.sortBy = event;
    if(this.sortBy==1 || this.sortBy==3 || this.sortBy==5)
    {
      this.sortascdesc='ASC';
    }
    else if(this.sortBy==2 || this.sortBy==4 || this.sortBy==6)
    {
      this.sortascdesc='DESC';
    }
    if(this.sortColumnDialog==1)
    {
      this.sortColumn='ClientName';
    }
    else if(this.sortColumnDialog==2){
      this.sortColumn='ArchiveName';
    }
    else if(this.sortColumnDialog==3)
    {
      this.sortColumn='RecordDescription';
    }
    else if(this.sortColumnDialog==4){
      this.sortColumn='ArchiveNumber';
    }
 this.NavigateArchiveResults();
    
  }

  memberSortDialogASCDESC(event){

    var clickedColumn:number=event;
      /*For HoldName*/
      if(clickedColumn==4 && this.sortBy!=7){
      this.sortBy=7;
       this.sortColumn="ArchiveNumber";
       this.sortascdesc='ASC';
     }
     else if(clickedColumn==4 && this.sortBy==7){
      this.sortBy=0;
      this.sortColumn="ArchiveNumber";
      this.sortascdesc='DESC';
     }
     /*For HoldName*/

     this.NavigateArchiveResults();
  }

  generateReportClicked(data1){
    let archiveForReport: any[] = [];
    let filterdColumns = (data1.filter(x => x.checked));
    this.filterdColumnsChunks = filterdColumns;
    var SearchByValueCollection = this.selectedlist.join();
    var HoldCollection : string = "";
    HoldCollection = this.selectedHoldsList.join();
    if(this.SearchBy==='Client'){
         this.SearchClient=this.selectedClients;
         SearchByValueCollection = this.selectedClients.join();
    }

    var HoldCollection : string = "0";
    HoldCollection = this.selectedHoldsList.join();
   
    var periodStartDate = this.PeriodStartDate != "0" && this.PeriodStartDate != null? new Date(this.PeriodStartDate).toLocaleDateString():"0";
    var periodEndDate = this.PeriodEndDate != "0" && this.PeriodEndDate != null? new Date(this.PeriodEndDate).toLocaleDateString():"0";

    this.SearchByValueCollectionforExport=SearchByValueCollection;

    var selectedArchives = [] ;

    let archiveCollection: string="";
       this.selectedArchives.forEach(function (value) {
      if(archiveCollection!='')
      archiveCollection= archiveCollection.concat(","+value.archiveNumber.toString());
      else
      archiveCollection=value.archiveNumber
    });
    
    let ExportToExcelParams={
      SearchBy:(this.selectedArchives.length===0)?this.SearchBy:"ArchiveNumber",
      SearchByValue:(this.selectedArchives.length===0)?SearchByValueCollection:archiveCollection,
      IncludeOrExclude:this.selectedAppliedHold,
      HoldName:HoldCollection,
      Business:this.business,
      PeriodStart:periodStartDate,
      PeriodEnd:periodEndDate,
      SortBy:this.sortColumn,
      SortOrder:this.sortascdesc, 
      PageNumber:0,
      PageSize:0
    };

    if(this.selectedArchives!= '')
    {
      if (this.Archives.length > 0) {        
        this.filteredArchives = this.Archives.filter(arc => this.selectedArchives.some(selArc => arc.archiveNumber === selArc.archiveNumber));
       
        this.filteredArchives.forEach(element => {
          let archive = {};
          filterdColumns.forEach(column => {

            if (column["value"] == this.holdsResultGridColumns.ClientName) { //Archive#
              archive[this.holdsResultGridColumns[this.holdsResultGridColumns.ClientName]] = element.clientName || this.emptyStringInReport;
            }
            if (column["value"] == this.holdsResultGridColumns.ArchiveName) { //Archive#
              archive[this.holdsResultGridColumns[this.holdsResultGridColumns.ArchiveName]] = element.archiveName || this.emptyStringInReport;
            }
            if (column["value"] == this.holdsResultGridColumns.RecordDescription) { //Archive#
              archive[this.holdsResultGridColumns[this.holdsResultGridColumns.RecordDescription]] = element.recordDescription || this.emptyStringInReport;
            }
            if (column["value"] == this.holdsResultGridColumns.ArchiveNumber) { //Archive#
              archive[this.holdsResultGridColumns[this.holdsResultGridColumns.ArchiveNumber]] = element.archiveNumber || this.emptyStringInReport;
            }
          });
          archiveForReport.push(archive);
        });
        if (archiveForReport && archiveForReport.length) {
          this.sharedService.generateExcel("Holdsfor", "Holds", filterdColumns.map(x => x.displayName), archiveForReport);
        }
      }
    }
    else
    {
        ExportToExcelParams.PageNumber= 1;
        ExportToExcelParams.PageSize= 2500;
        this.getExportExcelInChunks(ExportToExcelParams);
      }
    }

    getExportExcelInChunks(ExportToExcelParams : any){
    this._HoldsService.GetArchivesForApplyingHold(ExportToExcelParams).subscribe(  
      data => {

        if (data.length > 0) {
            for(var i =0;i<data.length;i++){
              this.allArchives.push(data[i]);
            }
            if(this.allArchives.length < this.totalArchivesForApplyingHolds)
            {
              ExportToExcelParams.PageNumber++;
              this.getExportExcelInChunks(ExportToExcelParams);
            }
            else
            {
              if(this.allArchives.length == this.totalArchivesForApplyingHolds)
              {
                let archiveForReport: any[] = [];
                  this.allArchives.forEach(element => {
                    let archive = {};
                    this.filterdColumnsChunks.forEach(column => {


                      if (column["value"] == this.holdsResultGridColumns.ClientName) { //Archive#
                        archive[this.holdsResultGridColumns[this.holdsResultGridColumns.ClientName]] = element.clientName || this.emptyStringInReport;
                      }
                      if (column["value"] == this.holdsResultGridColumns.ArchiveName) { //Archive#
                        archive[this.holdsResultGridColumns[this.holdsResultGridColumns.ArchiveName]] = element.archiveName || this.emptyStringInReport;
                      }
                      if (column["value"] == this.holdsResultGridColumns.RecordDescription) { //Archive#
                        archive[this.holdsResultGridColumns[this.holdsResultGridColumns.RecordDescription]] = element.recordDescription || this.emptyStringInReport;
                      }
                      if (column["value"] == this.holdsResultGridColumns.ArchiveNumber) { //Archive#
                        archive[this.holdsResultGridColumns[this.holdsResultGridColumns.ArchiveNumber]] = element.archiveNumber || this.emptyStringInReport;
                      }
                    });
                    archiveForReport.push(archive);
                  });
                  if (archiveForReport && archiveForReport.length) {
                    this.sharedService.generateExcel("Holdsfor", "Holds", this.filterdColumnsChunks.map(x => x.displayName), archiveForReport);
                  }
                }
            }
          }
        });
      }             
    ngDoCheck() {
      this.validations();
    }
    validations(){
      let hasError: boolean = false;
      hasError = (this.selectedlist.length > 0 || this.selectedClients.length > 0)
      if(hasError)
      this.disableBtn=false;
      else
      this.disableBtn=true;

      if(this.selectedArchives.length > 0)
      this.disableApplyBtn = false;
      else
      this.disableApplyBtn= true;
    }

    convertstringTodateObj(val:any){
      let dateObj:any;
      dateObj = {
        "year": parseInt(val.split("-")[0]),
        "month": parseInt(val.split("-")[1]),
        "day": parseInt(val.split("-")[2])
      }

      return dateObj
    }
}

export enum HoldsResultGridColumns
{
ClientName = 1,
ArchiveName = 2,
RecordDescription=3,
ArchiveNumber = 4
}

export enum HoldsDetailsColumnBy {
  ColumnBy_Default = -1,
  ColumnBy_ClientName = 1,
  ColumnBy_ArchiveName = 2,
  ColumnBy_RecordDescription = 3,
  ColumnBy_ArchiveNumber = 4
}