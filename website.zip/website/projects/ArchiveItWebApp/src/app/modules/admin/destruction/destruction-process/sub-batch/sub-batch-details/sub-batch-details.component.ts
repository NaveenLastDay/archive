import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { NotifierService } from 'angular-notifier';
import { NgxSpinnerService } from 'ngx-spinner';
import { BatchDetailsInfo, DestructionSubBatch } from '../../../../../../models/batch-details.model';
import { SharedService } from '../../../../../../services/shared.service';
import { ModalService } from '../../../../../shared/modal';
import { DestructionService } from '../../../../../../services/destruction.service';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-sub-batch-details',
  templateUrl: './sub-batch-details.component.html',
  styleUrls: ['./sub-batch-details.component.css']
})
export class SubBatchDetailsComponent implements OnInit {
  mySubBatchSearchForm:FormGroup;
  subBatchID:string;
  /*sorting */
sortColumnDialog: number = -1;
sortColumn : string ='DestructionEligibleDate'
sortascdesc: number=0;
sortBy: number = 0;
currentPageNumber: number=1;
readonly pageSize: number = 100;
IsSimpleSearch:number = 0;

batchDetailInfoList = new BatchDetailsInfo();
subBatch = new DestructionSubBatch();
batchArchiveObjects:any[];
totalSubBatchsRecords:number = 0;
hoverIndex: number = -1;
archiveNumber:string;
limitObjNumber:number=5;
limitBatchObjNumber:number=10;
ascUniqueIdSort = true;
masterSelected : boolean =  false;
inEligibleArchives : any[];
batchSimpleText:string;
showSearchContent:boolean=false;
AddClientText : string = '';
searchDistEligibleDateShow:boolean=false;
DestrElgStartDate:string;
DestrElgEndDate:string;
DestructionEligibleFullDate:string;
disableBtn:boolean=false;
selectedRecordStatus: number[] = [1,2,3,5,6];
advSelectedHoldFlag:number=-1;
advSelectedLinkedArchive:number=-1;
advSelectedRetentionException:number=-1;
selectedClient: string='';
selectedHolds: Array<any> = [];
clients: Array<any> = [];
index: number = 0;
searchArchiveNumber:string='';
simpleSearch:string= '';
showElgibleArchives:number=0;
searchUniqueID:string='';
simpleSearchText:string= '';
showInElgibleArchives:number=0;
inEligibleArchivesCount:number = 0;
showBulkRemoval:boolean=false;
batchDetailsID:number;
isUpdateGridData:boolean;
removeArchive:string;
removeTextMessage:string;
archiveCheckAll:boolean=false;
subBatchDetailsGridColumns: any =SubBatchDetailsGridColumns;
destructionBatch:any;
batchNumber:string;
todaydate = new Date();
destructionEligibleFromToDate:string;
columnFilters:any[]=
[
  {
    "displayName": "Client",
    "value": this.subBatchDetailsGridColumns.Client,
    "checked": true
  },
  {
    "displayName": "Archive #",
    "value": this.subBatchDetailsGridColumns.ArchiveNumber,
    "checked": true
  },
  {
    "displayName": "Destruction eligible date",
    "value": this.subBatchDetailsGridColumns.DestructionEligibleDate,
    "checked": true
  },
  {
    "displayName": "Retention exception triggered date",
    "value": this.subBatchDetailsGridColumns.RetentionExceptionTriggerDate,
    "checked": true
  },

  {
    "displayName": "Hold flag",
    "value": this.subBatchDetailsGridColumns.HoldFlag,
    "checked": true
  },
  {
    "displayName": "Unique ID",
    "value": this.subBatchDetailsGridColumns.UniqueID,
    "checked": true
  },
  {
    "displayName": "Barcode",
    "value": this.subBatchDetailsGridColumns.Barcode,
    "checked": true
  },
  {
    "displayName": "Hard copy record status",
    "value": this.subBatchDetailsGridColumns.Hardcopyrecordstatus,
    "checked": true
  },
  {
    "displayName": "Electronic record status",
    "value": this.subBatchDetailsGridColumns.Electronicrecordstatus,
    "checked": true
  },

]
  /* end of Export to Excel */
  constructor(private fb:FormBuilder,private sharedService: SharedService,private _notifierService:NotifierService, private modalService: ModalService,private SpinnerService: NgxSpinnerService,private activatedRoute: ActivatedRoute,private _destService: DestructionService,private _datepipe:DatePipe) {
    this.mySubBatchSearchForm = fb.group({
      'inputClientName': [null, Validators.required],
      'inputArchiveName': [null, Validators.required],
      'DestEligibleDate': [null, Validators.required],
      'recordStatuscheckboxgroup' : [null, Validators.required],
      'retentionExceptionRadioGroup' : [-1, Validators.required],
      'holdRadioGroup' : [-1, Validators.required],
      'linkedArchiveRadioGroup' : [-1, Validators.required]
    });
   }

  ngOnInit() {
    this.subBatchID = this.activatedRoute.snapshot.paramMap.get('subBatchId');
    this.destructionBatch = JSON.parse(localStorage.getItem('batchInfoBarData'));
    this.batchNumber = this.destructionBatch.batchNumber;
    this.advSelectedLinkedArchive=-1;
    this.advSelectedRetentionException=-1;
    this.advSelectedHoldFlag=-1;
    this.selectedRecordStatus=[1,2,3,5,6];
    this.getSubBatchData();
  }
  getSubBatchData() {
      this._destService.GetSubBatchDetailInfo(this.subBatchID,this.currentPageNumber, this.pageSize, this.sortBy, this.sortColumn, this.IsSimpleSearch,this.simpleSearch,
      this.searchArchiveNumber, this.selectedClient, null,  "1/1/1111", this.selectedRecordStatus.toString(),
      this.advSelectedRetentionException, this.advSelectedHoldFlag, this.advSelectedLinkedArchive, this.showElgibleArchives).subscribe(data => {
        if (data){
          this.batchDetailInfoList =  data ? data : [];
          this.subBatch =  data["subBatch"];
          this.inEligibleArchivesCount = data["eligibleArchivesCount"];
          this.totalSubBatchsRecords =  data["totalRecords"];
          this.destructionEligibleFromToDate = this._datepipe.transform(this.subBatch.destructionEligibleFromDate,'MM/dd/yyyy')+" - "+this._datepipe.transform(this.subBatch.destructionEligibleToDate,'MM/dd/yyyy');
        }
        this.showSearchContent = false;
    this.SpinnerService.hide();
   });
  }
  toggleAdvancedSearch(){
    console.log("Advanced search popup show");
    this.showSearchContent = !this.showSearchContent;
  }
  UserSelectedRecordStatus(event)
  {
      if(event.target.checked==true){
        this.selectedRecordStatus.push(parseInt(event.target.value));
      }
      else{
        var index=this.selectedRecordStatus.indexOf(parseInt(event.target.value));
        this.selectedRecordStatus.splice(index,1);
      }
      console.log(this.selectedRecordStatus);
  }
  generateReportClicked(data1){
    console.log("Export to excel");
  }
  updateGridData(event) {
    //this.SpinnerService.show();
    this.currentPageNumber = event.pageNumber;
    this._destService.GetSubBatchDetailInfo(this.subBatchID,this.currentPageNumber, this.pageSize, this.sortBy, this.sortColumn, this.IsSimpleSearch,this.simpleSearch,
      this.searchArchiveNumber, this.selectedClient, null,  "1/1/1111", this.selectedRecordStatus.toString(),
      this.advSelectedRetentionException, this.advSelectedHoldFlag, this.advSelectedLinkedArchive, this.showElgibleArchives).subscribe(data => {
        if (data){
          this.batchDetailInfoList =  data ? data : [];
          this.subBatch = data["subBatch"];
          this.inEligibleArchivesCount = data["eligibleArchivesCount"];
          this.totalSubBatchsRecords =  data["totalRecords"];
        }
    this.SpinnerService.hide();
   });
  }
  beginDestructionProcess(){
    var parameters = {"subBatchID": this.subBatch.subBatchID };
      this._destService.beginDestructionProcess(parameters).subscribe(data => {
          if (data == "Destruction process started"){
            this.subBatch.status =  "InProgress";
            this._notifierService.notify(
              "success",
              "Destruction is in progress"
            );
          }
          else
          this.subBatch.status =  "New";
      this.SpinnerService.hide();
    });
  }
  openBeginDestructionProcess(modalType: string) {
    this.modalService.openWithCustomWidth(modalType, "485");
  }
  closeModalDialog(modalType:string) {
    this.modalService.close(modalType);
  }
  SelectedRetentionException(e){
    console.log(e.target.id);
    if(e.target.id=='showall')
    this.advSelectedRetentionException=BatchRetentionException.ShowAll;
    else if(e.target.id=='applied')
    this.advSelectedRetentionException=BatchRetentionException.Applied;
    else
    this.advSelectedRetentionException=BatchRetentionException.NotApplied;
    this.mySubBatchSearchForm.controls.retentionExceptionRadioGroup.patchValue(this.advSelectedRetentionException);
  }
  SelectedLinkedArchive(e){
    console.log(e.target.id);
    if(e.target.id=='showall')
    this.advSelectedLinkedArchive=BatchLinkedArchive.ShowAll;
    else if(e.target.id=='linked')
    this.advSelectedLinkedArchive=BatchLinkedArchive.Linked;
    else
    this.advSelectedLinkedArchive=BatchLinkedArchive.NotLinked;
    this.mySubBatchSearchForm.controls.linkedArchiveRadioGroup.patchValue(this.advSelectedLinkedArchive);
 }
  SelectedHoldFlag(e){
    console.log(e.target.id);
    if(e.target.id=='showall')
    this.advSelectedHoldFlag=BatchHoldFlag.ShowAll;
    else if(e.target.id=='applied')
    this.advSelectedHoldFlag=BatchHoldFlag.Applied;
    else
    this.advSelectedHoldFlag=BatchHoldFlag.NotApplied;
    this.mySubBatchSearchForm.controls.holdRadioGroup.patchValue(this.advSelectedHoldFlag);
  }
  onSimpleSearch(searchValue:string,){
    this.currentPageNumber=1;
    this.simpleSearch = searchValue;
    if(this.simpleSearch)
    this.IsSimpleSearch = 1;
    else
    this.IsSimpleSearch = 0;
    this.getSubBatchData();
  }
  ResetAdvFields()
  {
    this.mySubBatchSearchForm.controls.retentionExceptionRadioGroup.patchValue(-1);
    this.mySubBatchSearchForm.controls.holdRadioGroup.patchValue(-1);
    this.mySubBatchSearchForm.controls.linkedArchiveRadioGroup.patchValue(-1);
    this.mySubBatchSearchForm.controls.recordStatuscheckboxgroup.patchValue(true);
    this.searchArchiveNumber='';
    this.selectedClient='';
    this.IsSimpleSearch = 0;
    this.selectedRecordStatus=[1,2,3,5,6];
    this.advSelectedLinkedArchive=-1;
    this.advSelectedRetentionException=-1;
    this.advSelectedHoldFlag=-1;
    this.currentPageNumber =1;
    this.getSubBatchData();
  }
}
export enum SubBatchDetailsGridColumns
{
Client = 1,
ArchiveNumber = 2,
DestructionEligibleDate = 3,
RetentionExceptionTriggerDate = 4,
HoldFlag= 5,
UniqueID = 6,
Barcode = 7,
Hardcopyrecordstatus =8,
Electronicrecordstatus=9
}
export enum BatchLinkedArchive{
  ShowAll=-1,
  Linked=1,
  NotLinked=0
}
export enum BatchRetentionException{
  ShowAll=-1,
  Applied=1,
  NotApplied=0
}
export enum BatchHoldFlag{
  ShowAll=-1,
  Applied=1,
  NotApplied=0
}