﻿using System;
using System.IO;
using Microsoft.Extensions.Logging;

namespace Deloitte.AIFA.Common.Logging
{
    public class CoreFileLogger : ILogger
    {
        private readonly string _categoryName;
        private readonly string _path;

        public CoreFileLogger(string categoryName, string logFilePath)
        {
            _path = logFilePath;
            _categoryName = categoryName;
        }

        public IDisposable BeginScope<TState>(TState state)
        {
            return new NoopDisposable();
        }

        public bool IsEnabled(LogLevel logLevel)
        {
            return true;
        }

        public void Log<TState>(LogLevel logLevel, EventId eventId, TState state, Exception exception, Func<TState, Exception, string> formatter)
        {
            try
            {
                if (logLevel == LogLevel.Critical || logLevel == LogLevel.Error || logLevel == LogLevel.Warning)
                    RecordMsg(logLevel, eventId, state, exception, formatter);
            }
            catch (Exception ex)
            {
                RecordMsg(logLevel, eventId, state, exception, formatter);
            }
        }

        private void RecordMsg<TState>(LogLevel logLevel, EventId eventId, TState state, Exception exception, Func<TState, Exception, string> formatter)
        {
            string msg = $"{logLevel} :: {_categoryName} :: {formatter(state, exception)} :: username :: {DateTime.Now}";

            using (var writer = File.AppendText(_path))
            {
                writer.WriteLine(msg);
            }
        }
    }
    class NoopDisposable : IDisposable
    {
        public void Dispose()
        {
        }
    }
}