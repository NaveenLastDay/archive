﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;

namespace Deloitte.AIFA.DomainEntities
{
    public class ArchiveRetention
    {
        public string ArchiveNumber { get; set; }
        public List<int> RetentionExtentionReasonId { get; set; }
        public int RetentionTime { get; set; }
        public string Comments { get; set; }
        public string CreatedBy { get; set; }

        
    }
}
