﻿using System;

namespace Deloitte.AIFA.ICloudServices
{
    public interface IConfigManager
    {
        string GetConfigValueByKey(string key);
        string GetCacheSecretValueByKey(string secretName);
    }
}
