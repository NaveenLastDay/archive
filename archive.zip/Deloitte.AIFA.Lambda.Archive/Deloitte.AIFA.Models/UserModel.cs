﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DataModels
{
    public class UserModel
    {
        public string userAlias { get; set; }
        public int employeeRoleId { get; set; }
    }
}
