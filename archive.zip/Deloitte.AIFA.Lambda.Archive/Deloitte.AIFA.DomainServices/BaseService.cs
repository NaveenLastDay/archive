﻿using Deloitte.AIFA.ICloudServices;
using Microsoft.Extensions.Caching.Memory;

namespace Deloitte.AIFA.DomainServices
{
    public class BaseService
    {
        IMemoryCache _cache;
        IConfigManager _configManager;
        public BaseService(IMemoryCache cache, IConfigManager configManager)
        {
            _cache = cache;
            _configManager = configManager;
        }
    }
}
