﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Deloitte.AIFA.Models
{
    public class ArchiveInfoModel
    {
        public int ArchiveID { get; set; }
        public string WBSLevelOneNumber { get; set; }
        public string EngagementTypeDescription { get; set; }
        public DateTime ArchiveDueDate { get; set; }
         public DateTime EDCD { get; set; }
        public string IsResubmissionInProgress { get; set; }
        public string ReportingEntity { get; set; }
        public string ArchivePartner { get; set; }
        public string ArchvieManger { get; set; }
        public string ArchvieFieldSenior { get; set; }
        public string AddArchiveFieldSenior { get; set; }
        public string Status { get; set; }
    }
}
