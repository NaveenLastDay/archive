import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { bool } from 'aws-sdk/clients/signer';
import { ArchiveSearchService } from '../../../../services/archive-search.service';
import { SearchEventService } from '../../../search/search.event.service';
import { DateTime } from 'aws-sdk/clients/devicefarm';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-holds-search',
  templateUrl: './holds-search.component.html',
  styleUrls: ['./holds-search.component.css']
})
export class HoldsSearchComponent implements OnInit {
  @Input("showSearchContent") showContent: boolean;
  @Output("hideSearchContent") hideSearchContent = new EventEmitter<any>();
  @Output("searchContentParams") searchContentParams = new EventEmitter<any>();

  myForm:FormGroup;
  AddHoldsText : string = '';
  selectedHoldsList: Array<any> = [];
  selectedClientViewName: string = "";
  selectedClient: string;
  selectedClients: Array<any> = [];
  selectedClientsOnSeach: Array<any> = [];
  clients: Array<any> = [];
  index: number = 0;
  selectedStatus:any;
  selectedBuisness: string[] = [];
  effstartdate:DateTime;
  effenddate:DateTime;
  disableBtn:boolean=false;
  constructor(private fb: FormBuilder, private search: ArchiveSearchService, private searchEventService: SearchEventService, private SpinnerService:NgxSpinnerService) {
    this.myForm = fb.group({
      'inputClientName': [null, Validators.required],
      'inputHoldName': [null, Validators.required],
      'EffectiveStartDate': [null, Validators.required],
      'EffectiveEndDate': [null, Validators.required],
      'checkboxgroup' : [null, Validators.required],
      'radioGroup' : [2, Validators.required]
    });
  }
  ngOnInit() {
    this.selectedStatus="2";
    this.ResetSearchParameters();
  }
  ngDoCheck() {
    this.validations();
  }
    OnHoldSearch(searchByValue)
    {
    this.AddHoldsText = searchByValue;
    }
    AddHolds(){
      if(this.AddHoldsText !=''){
        if (this.selectedHoldsList.length > 0) {
          var statusExists = this.selectedHoldsList.findIndex(x => x.Status == this.AddHoldsText)
          if (statusExists == -1) {
            this.selectedHoldsList.push(this.AddHoldsText);
          }
        }
        else {
          this.selectedHoldsList.push(this.AddHoldsText);
        }
      }
      this.AddHoldsText='';
    }


    deleteHoldItem(deleteItem){
      this.selectedHoldsList = this.selectedHoldsList.filter(e => e !== deleteItem);
    }

  //Client
  //To get client Details
  onClientInputChanged(searchString: string) {
    this.clients = [];
    if (searchString.length >= 3) {
      this.search.getArchiveSearchResults(searchString, "Client").subscribe(result => {
        if (result.length > 0) {
          this.clients = result;
        }
        else {
          this.clients = null;

        }
      },
        (err) => {
          console.log("error is ", err)
        }
      );
    }
    else if (searchString.length == 0) {
      this.clients = [];
    }
    else {
      this.clients = [];
    }
    //this.SpinnerService.hide();
  }
  //To store the selected Client details
  selectedClientName(client, index) {
     if(index===-1){
      this.selectedClients.push(client);
      return;
    }
    this.selectedClientViewName = client.source.viewValue;
    this.selectedClient = this.clients[index].itemName;
    if (this.searchEventService.selectedClientsList.length > 0) {
      var clientExists = this.searchEventService.selectedClientsList.findIndex(x => x.ClientName == this.selectedClient)
      if (clientExists == -1) {
        this.searchEventService.selectedClientsList.push({ Index: this.index++, ClientName: this.selectedClient });
        this.selectedClients.push(this.selectedClient);
        this.searchEventService.customRuleJson.push({
          Index: this.index++,
          ClientName: this.selectedClient

        });
        this.searchEventService.showApplied = false;
        this.searchEventService.showApplyAll = true;
      }
    }
    else {
      this.selectedClients.push(this.selectedClient);
      this.searchEventService.selectedClientsList.push({ Index: this.index++, ClientName: this.selectedClient });
      this.searchEventService.customRuleJson.push({
        Index: this.index++,
        ClientName: this.selectedClient
      });
      this.searchEventService.showApplied = false;
      this.searchEventService.showApplyAll = true;
    }

    //change to useralias once lambda is changed.
    this.clients = [];
    this.myForm.get('inputClientName').reset();

  }
  //To delete the selected Client
  deleteClient(clientName) {
    this.selectedClients = this.selectedClients.filter(e => e !== clientName);
    this.searchEventService.customRuleJson = this.searchEventService.customRuleJson.filter(x => !(x.ClientName == clientName));
    this.searchEventService.selectedClientsList = this.searchEventService.selectedClientsList.filter(x => x.ClientName !== clientName);
    this.searchEventService.showApplied = false;
    this.searchEventService.showApplyAll = true;
  }
  SearchBySelectedRadio(e){
     console.log(e.target.id);
     if(e.target.id=='showall')
     this.selectedStatus='2'
     else if(e.target.id=='active')
     this.selectedStatus='1'
     else
     this.selectedStatus='0'
  }
  SearchBySelectedCheckBox(event) {
    if(event.target.checked==true){
    this.selectedBuisness.push(event.target.id);
    }
    else{
      let index = this.selectedBuisness.indexOf(event.target.id);
      this.selectedBuisness.splice(index, 1);
    }
  }
  searchHolds(){
    debugger;
    this.selectedClientsOnSeach=this.selectedClients;
    for (let i = 0; i < this.selectedClientsOnSeach.length; ++i) {
      this.selectedClientsOnSeach[i] = this.selectedClientsOnSeach[i].replaceAll(","," ")
    }
    var parameters = {
    "ClientNames":this.selectedClientsOnSeach.toString(),
    "HoldNames":this.selectedHoldsList.toString(),
    "Business":this.selectedBuisness.toString(),
    "Status":this.selectedStatus,
    "EffectiveStartDate": this.effstartdate != undefined && this.effstartdate != null? new Date(this.effstartdate).toLocaleDateString():this.effstartdate,
    "EffectiveEndDate": this.effenddate != undefined && this.effenddate != null? new Date(this.effenddate).toLocaleDateString():this.effenddate
    }
    this.searchContentParams.emit(parameters);
    this.closeContent();
  }
  closeContent(){
    this.showContent=false;
    this.hideSearchContent.emit(this.showContent);
    this.ResetSearchParameters();
  }
  ResetSearchParameters(){
    this.myForm.reset();
    this.selectedHoldsList = [];
    this.selectedClients = [];
    this.searchEventService.selectedClientsList=[];
    this.selectedBuisness = [];
    this.selectedStatus='2';
    this.myForm.controls.radioGroup.patchValue(2);
    this.effstartdate= null;
    this.effenddate= null;
  }
  validations() {
    let hasError: boolean = false;
    hasError = (this.selectedStatus!='2'|| this.effstartdate != undefined || this.effenddate != undefined || this.selectedClients.length>0 || this.selectedHoldsList .length > 0 || this.selectedBuisness .length > 0);
    if(hasError)
    this.disableBtn=false;
    else
    this.disableBtn=true;
  }
}
