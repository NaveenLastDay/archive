import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpBackend } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { map } from 'rxjs/operators';
import { PubsubService } from './pubsub.service';

@Injectable({
    providedIn: 'root'
})
export class FielUploadService {

    hasUploadDetails: boolean = false;
    fuConfig: any;

    constructor(private _http: HttpClient, private handler: HttpBackend, private pubsub: PubsubService) {

        this.fuConfig = {
            region: "",
            bucketName: "",
            apiVersion: "2006-03-01",
            signatureVersion: "v4",
            identityPoolId: "",
            kmsKey: "",
            serverSideEncryption: "aws:kms"
        };

    }

    getFileUploadConfig(): Observable<any> {

        if (!this.hasUploadDetails) {

            this.hasUploadDetails = true;
            var tcHttpOptions = {
                headers: new HttpHeaders({
                    'Content-Type': 'application/json'
                }),
            }
            return this._http.get<any>("sts/tc" + "/" + 900, tcHttpOptions)
                .pipe(
                    map(
                        data => {
                            this.fuConfig.bucketName = data.StagingBucketName;
                            this.fuConfig.kmsKey = data.KmsKey;
                            this.fuConfig.region = data.Region;
                            this.fuConfig.identityPoolId = data.IdentityPoolId;

                            return this.fuConfig;
                        }
                    )
                );
        } else {
            return of(this.fuConfig);
        }
    }

    uploadPartUsingSignedURL(url: string, partIndex: number, chunk: any, callback) {

        // Extend the session
        this.pubsub.SessionExtentionRequest();

        var xhr = new XMLHttpRequest();
        xhr.open("PUT", url, true);
        var error = "";

        xhr.onload = function () {

            if (xhr.readyState == 4 && xhr.status == 200) {
                var etag = xhr.getResponseHeader('etag');
                callback(null, partIndex, etag);
            } else {
                console.log("error: PUT -> onload for part: " + (partIndex + 1));
                error = xhr.responseText == "" ? "part failed to upload: " : xhr.responseText;
                callback(error, partIndex, null);
            }
        }
        xhr.onerror = function (e) {
            console.log("error: PUT -> onerror for part: " + (partIndex + 1));
            error = xhr.responseText == "" ? "part failed to upload: " : xhr.responseText;
            callback(error, partIndex, null);
        };
        xhr.send(chunk);
    }

}