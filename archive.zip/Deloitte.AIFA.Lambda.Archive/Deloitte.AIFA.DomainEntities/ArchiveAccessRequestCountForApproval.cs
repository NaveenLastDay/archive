﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
    public class RequestCountForApproval
    {
        public int ActionItemCount { get; set; }
        public string Due { get; set; }
    }
}
