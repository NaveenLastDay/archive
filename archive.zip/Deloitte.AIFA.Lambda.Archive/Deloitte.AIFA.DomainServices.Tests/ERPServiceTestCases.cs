﻿using Deloitte.AIFA.DomainEntities;
using Deloitte.AIFA.DomainServices.Contracts;
using Deloitte.AIFA.DomainServices.Services;
using Deloitte.AIFA.IRepositories;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Net;
using System.Text;

namespace Deloitte.AIFA.DomainServices.Tests
{
	[TestClass]
	public class ERPServiceTestCases
	{
		private Mock<IERPRepository> _moqERPReposetory;
		private Mock<ILogger<ERPService>> _mockLogger;
		private IERPService _erpService;

		[TestInitialize]
		public void TestInitialize()
		{
			_moqERPReposetory = new Mock<IERPRepository>();
			_mockLogger = new Mock<ILogger<ERPService>>();
			_erpService = new ERPService(null, null,null, _moqERPReposetory.Object, _mockLogger.Object);
		}

		[TestMethod]
		public void GetERPDetailsTest()
		{
			var searchquery = "testQuery";
			_moqERPReposetory.Setup(del => del.GetERPDetails(searchquery)).Returns(_mockERPDetails);
			var result = _erpService.GetERPDetails(searchquery);
			Assert.AreEqual(result.Count, 1);
		}

		[TestMethod]
		public void RemoveEngagementPersonnelTest()
		{
			DistributionList obj = new DistributionList()
			{
				ArchiveNumber = "testArchiveNumber"
			};

			_moqERPReposetory.Setup(del => del.RemoveEngagementPersonnel(obj)).Returns(obj);
			var result = _erpService.RemoveEngagementPersonnel(obj);
			Assert.AreEqual(result.ArchiveNumber, obj.ArchiveNumber);
		}

		[TestMethod]
		public void AddEngagementPersonnelsTest()
		{
			DistributionList obj = new DistributionList()
			{
				ArchiveNumber = "testArchiveNumber"
			};
			_moqERPReposetory.Setup(del => del.AddEngagementPersonnels(obj)).Returns(obj);
			var result = _erpService.AddEngagementPersonnels(obj);
			Assert.AreEqual(result.ArchiveNumber, obj.ArchiveNumber);
		}

		private readonly List<ERPDetails> _mockERPDetails = new List<ERPDetails>()
		{
			new ERPDetails()
			{
				Fullname = "Test FUll Name"
			}
		};

		private readonly List<ERPConfigurationData> _mockERPConfigurationData = new List<ERPConfigurationData>()
		{
			new ERPConfigurationData()
			{
				ERPDataKey = "sapTokenUrl",
				ERPDataValue = "sapTokenUrlValue"
			},
			new ERPConfigurationData()
			{
				ERPDataKey = "sapClientID",
				ERPDataValue = "sapClientIDValue"
			},
			new ERPConfigurationData()
			{
				ERPDataKey = "sapClientSecret",
				ERPDataValue = "sapClientSecretValue"
			},
			new ERPConfigurationData()
			{
				ERPDataKey = "sapGrantType",
				ERPDataValue = "sapGrantTypeValue"
			},
			new ERPConfigurationData()
			{
				ERPDataKey = "sapCache",
				ERPDataValue = "sapCacheValue"
			}
		};
	}
}
