﻿using Amazon.Runtime.Internal;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Xml;

namespace Deloitte.AIFA.Helpers.ExcelGenerator
{
    public class XlsxGenerator : IXlsxGenerator
    {
        private static readonly string DateTimeFormat =  "MM/dd/yyyy";
        private static readonly string ThousandsIntegerDelimiterFormat =  "#,##0";
        private static readonly string ThousandsDecimalDelimiterFormat =  "#,##0.00";

        public List<IDataForSheet> GetIDataSheetList<T>(IEnumerable<T> entityList)
        {
            return entityList.Cast<IDataForSheet>().ToList();
        }

        public byte[] GenerateExcelFile(string excelFileName, List<XlsxSheetToGenerate> sheets, string folderPath)
        {
            //return ExceptionHandler.Execute(
            //    LoggingBoundaries.UI,
            //    this,
            //    "GenerateExcelFile",
            //    () =>
            //    {
            Console.WriteLine("passing excel file path");

            var fullFileName = "/tmp/ArchiveAccessDetails.xlsx";
                    //var fullPath = HttpUtility.UrlEncode(Path.GetDirectoryName(fullFileName));
                    //Directory.CreateDirectory(HttpUtility.UrlDecode(fullPath) ?? string.Empty);
                    return Generate(sheets, fullFileName);
                    
               // });
        }

        private static string GetExcelCellDataTypeFormat(TypeCode typeCode)
        {
            switch (typeCode)
            {
                case TypeCode.Decimal:
                case TypeCode.Double:
                    return ThousandsDecimalDelimiterFormat;
                case TypeCode.Int16:
                case TypeCode.Int32:
                case TypeCode.Int64:
                    return ThousandsIntegerDelimiterFormat;
                case TypeCode.DateTime:
                    return DateTimeFormat;
                default:
                    return string.Empty;
            }
        }

        private static CellDataType GetExcelCellDataType(TypeCode typeCode)
        {
            switch (typeCode)
            {
                case TypeCode.Boolean:
                    return CellDataType.Boolean;
                case TypeCode.Int16:
                case TypeCode.Int32:
                case TypeCode.Int64:
                case TypeCode.Decimal:
                case TypeCode.Double:
                    return CellDataType.Number;
                case TypeCode.DateTime:
                    return CellDataType.DateTime;
                default:
                    return CellDataType.String;
            }
        }

        private static Cell GetExcelCell(IDataForSheet objectExample, string columnHeader)
        {
            var propertyInfo = objectExample.GetType().GetProperty(columnHeader);
            var columnAttribute = propertyInfo.GetCustomAttributes(typeof(ReportColumnAttribute), true).Any()
                                      ? (propertyInfo.GetCustomAttributes(typeof(ReportColumnAttribute), true)
                                                     .FirstOrDefault() as ReportColumnAttribute)
                                      : null;

            var propertyType = columnAttribute != null && columnAttribute.DataType != null ? columnAttribute.DataType : propertyInfo.PropertyType;

            var value = propertyInfo.GetValue(objectExample, null);
            var typeCode = Type.GetTypeCode(propertyType);

            if (value != null)
            {
                if (propertyInfo.PropertyType == typeof(string))
                    value = RemoveInvalidXmlChars((string)value);

                switch (typeCode)
                {
                    case TypeCode.Object:
                        typeCode = Type.GetTypeCode(value.GetType());
                        if (typeCode == TypeCode.DateTime)
                            value = Convert.ToDateTime(value).ToOADate();

                        break;
                    case TypeCode.DateTime:
                        value = Convert.ToDateTime(value.ToString()).ToOADate();
                        break;
                }
            }

            return new Cell
            {
                Value = value,
                CellDataType = GetExcelCellDataType(typeCode),
                Width = columnAttribute != null ? columnAttribute.Width : 20,
                FormatCode = (columnAttribute != null && columnAttribute.CustomFormated) ? GetExcelCellDataTypeFormat(typeCode) : string.Empty,
                Bold = false,
                Italic = false,
                BackgroungColor = CellColor.None
            };
        }

        private static byte[] Generate(IEnumerable<XlsxSheetToGenerate> sheetsToGenerateList, string fileName)
        {
            var worksheets = new List<Worksheet>();

            foreach (var sheetToGenerate in sheetsToGenerateList)
            {
                var props = sheetToGenerate.Properties;
                var objectsList = sheetToGenerate.DataSource;

                var anyTitles = (from prop in props
                                 let attrs = prop.GetCustomAttributes(typeof(SuperTitleColumnAttribute), true)
                                 where (attrs != null && attrs.Length > 0)
                                 let superTitleNameAttribute = attrs[0] as SuperTitleColumnAttribute
                                 select superTitleNameAttribute).Any();

                var columnTitles = new List<SuperTitleColumnAttribute>();

                if (anyTitles)
                {
                    columnTitles = (from prop in props
                                    let attrs = prop.GetCustomAttributes(typeof(SuperTitleColumnAttribute), true)
                                    let superTitleNameAttribute =
                                        attrs != null && attrs.Length > 0
                                            ? attrs[0] as SuperTitleColumnAttribute
                                            : new SuperTitleColumnAttribute(string.Empty, CellColor.None)
                                    select superTitleNameAttribute).ToList();
                }

                var columnHeaders = (from prop in props
                                     let attrs = prop.GetCustomAttributes(typeof(DisplayNameAttribute), true)
                                     where (attrs != null && attrs.Length > 0)
                                     let displayNameAttribute = attrs[0] as DisplayNameAttribute
                                     where (displayNameAttribute != null && !string.IsNullOrEmpty(displayNameAttribute.DisplayName))
                                     select attrs.Length > 0 ? displayNameAttribute.DisplayName : prop.Name).ToList();

                var columnColor = (from prop in props
                                   let attrs = prop.GetCustomAttributes(typeof(ReportColumnAttribute), true)
                                   where (attrs != null && attrs.Length > 0)
                                   let reportColumnAttribute =
                                       prop.GetCustomAttributes(typeof(ReportColumnAttribute), true)[0] as
                                       ReportColumnAttribute
                                   select
                                       reportColumnAttribute == null
                                           ? CellColor.None
                                           : reportColumnAttribute.HeaderBackgroundColor).ToList();

                var properties = (from prop in props
                                  let attrs = prop.GetCustomAttributes(typeof(DisplayNameAttribute), true)
                                  where (attrs != null && attrs.Length > 0)
                                  select prop.Name).ToList();

                var rows = objectsList.Select(
                    objectExample =>
                        properties.Select(columnHeader => GetExcelCell(objectExample, columnHeader)).ToList()).Select(cells => new Row { Cells = cells }).ToList();

                worksheets.Add(new Worksheet
                {
                    Name = sheetToGenerate.SheetName,
                    ColumnHeadings = Enumerable.Range(0, columnHeaders.Count)
                                               .Select(c => new Cell
                                               {
                                                   Value = columnHeaders[c],
                                                   Bold = true,
                                                   BackgroungColor = columnColor[c]
                                               }),
                    Titles = anyTitles
                                 ? Enumerable.Range(0, columnTitles.Count)
                                             .Select(c => new Cell
                                             {
                                                 Value = columnTitles[c].Title,
                                                 Bold = true,
                                                 BackgroungColor = columnTitles[c].Color
                                             })
                                 : null,
                    Rows = rows
                });
            }

            var workbook = new Workbook
            {
                Worksheets = worksheets
            };

            return XlsxWriter.Write(fileName, workbook);
        }

        private static string RemoveInvalidXmlChars(string text)
        {
            if (string.IsNullOrEmpty(text)) return string.Empty;

            // a bit complicated, but avoids memory usage if not necessary
            StringBuilder result = null;
            for (int i = 0; i < text.Length; i++)
            {
                var ch = text[i];
                if (XmlConvert.IsXmlChar(ch))
                {
                    if (result != null)
                    {
                        result.Append(ch);
                    }
                }
                else
                {
                    if (result == null)
                    {
                        result = new StringBuilder();
                        result.Append(text.Substring(0, i));
                    }
                }
            }

            if (result == null)
                return text; // no invalid xml chars detected - return original text

            return result.ToString();
        }
    }
}
