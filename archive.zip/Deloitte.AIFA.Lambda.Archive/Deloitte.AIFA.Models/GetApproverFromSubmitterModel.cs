﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DataModels
{
    public class GetApproverFromSubmitterModel
    { 
    public bool CanApprove { get; set; }
    public string LoggedInUserAlias { get; set; }
    public string ArchiveSubmitter { get; set; }
}
}
