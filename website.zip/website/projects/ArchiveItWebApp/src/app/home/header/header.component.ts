import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { MaintainalersService } from '../../services/maintainalers.service';
import {HomePageService} from '../../services/homepage.service'
import { PubsubService } from '../../services/pubsub.service';
import { Subscription } from 'rxjs';
import { isNumber } from 'util';
import { UserConfigSettingService } from '../../guards/user-role-guard.service';
import { SearchService } from '../../services/search.service';
import { ModalService } from '../../modules/shared/modal';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit,OnDestroy {

  currentUrl: string;
  UserName = this.adalSvc.LoggedInUserName;
  IsClicked: any;
  IsClickedArrow:boolean;
  IsClickedhelp:boolean;
  alerts: any;
  highSeverityalerts: any;
  readreceipents: any;
  count:number;
  IsDisable:boolean=false;
  userprofilepicurl : string;
  userEmail = this.adalSvc.LoggedInUserEmail;
  userAlias = this.userEmail.substring(0, this.userEmail.lastIndexOf("@"));
  imageText: boolean;
  // dataRefresher: NodeJS.Timer;
  dataRefresher:any;
  highseveritypopuplistcount: number;
  userConfig: any;

  number: any;
  subscription: Subscription;
  normalalertsubscription: Subscription;
  highalertssubscription : Subscription;
  normalAlertCount: number =0;
  highAlertCount: number =0;
  Alertscount: number = 0;
  homepageSvc : any;
  element: HTMLElement;

  constructor(private router: Router, private adalSvc: MsAdalAngular6Service,
    private maintainService: MaintainalersService, private modalService: ModalService,
    //private homepageSvc: HomePageService,
    private homepageService: HomePageService,
    private _userConfig:UserConfigSettingService,
    private pubsub:PubsubService,private searchService:SearchService) {
    router.events.subscribe((_: NavigationEnd) => this.currentUrl = this.router.url);
    this.userConfig = this._userConfig.FetchLoggedInUser(this.userAlias);
    this.homepageSvc =  homepageService;
  }
  clickOutside() {
    this.IsClickedArrow = !this.IsClickedArrow;
  }
  clickOutsideforDoc() {
    this.IsClickedhelp = !this.IsClickedhelp;
  }
  clickOutsideforAlerts(){
    this.IsClicked = !this.IsClicked;
  }
  alertscount(){
   this.normalalertsubscription =this.pubsub.getNormalAlertsCount().subscribe(
     message =>{
       if(!isNaN(message.text) && isNumber(message.text)){
        this.normalAlertCount =  message.text;
        this.Alertscount = this.normalAlertCount + this.highAlertCount ;
        if(this.Alertscount >0){
          this.IsDisable = true;
        }
        else{
          this.IsDisable = false;
        }
       }
       else{
         console.log(message.text);
       }
     }
   );

   this.highalertssubscription = this.pubsub.getHighAlertsCount().subscribe(
     message =>{
       if(!isNaN(message.text) && isNumber(message.text)){
        this.highAlertCount =  message.text;
        this.Alertscount = this.normalAlertCount + this.highAlertCount ;
        if(this.Alertscount >0){
          this.IsDisable = true;
        }
        else{
          this.IsDisable = false;
        }
       }
       else{
        console.log(message.text);
      }
     }
   );

  }


  ngOnInit() {

    this.imageText=false;
    this.userprofilepicurl = "https://people.m.us.deloitte.com/N/people/Photo/"+this.userAlias+"_MThumb_S";
    this.getAlerts();
    this.alertscount();
    this.maintainService.SyncAlerts();
    //this.refreshData(); //Commented by Mohan
    this.userConfig = this._userConfig.FetchLoggedInUser(this.userAlias);

  }

  OnClickAlerts() {
    this.IsClicked = true;
    this.IsClickedhelp=false;
    this.getAlerts();
  }
  OnClickRateThisApp(){
    this.element = document.getElementById('deloitteRateThisApp') as HTMLElement;
    this.element.setAttribute("style", "display:block;");;
  }
  OnClickArrow() {
    this.IsClickedArrow = true;
    this.IsClickedhelp=false;
  }
  OnClickHelp(){
    this.IsClickedhelp=true;
    this.IsClickedArrow = false;
  }
  OnClickAdmin(PageUrl) {
    this.homepageSvc.advanceSearchBtnDisable=false;
    this.homepageSvc.simpleSearchVisible=false;
    this.router.navigate(["/" + PageUrl + ""]);
    this.IsClickedArrow = false;
  }
  logout(){
    // this.modalService.openWithCustomWidth( 'ConfirmLogout', "450");
    this.adalSvc.logout();
   }
  //  closewindow(){
  //   window.history.forward();
  //   localStorage.clear();
  //   window.open('about:blank', '_self', '');
  //   window.close();
  //  }
  //  closepopup(){
  //   this.modalService.close('ConfirmLogout');
  //   this.IsClickedArrow = false;
  //  }
  closeModalDialog(pagename) {
if(pagename=='Alerts'){
    this.IsClicked = false;
    var parameter = this.readreceipents.map(x => x.id);
    var stringalertids = parameter.toString();
    //var alertIds = JSON.stringify(stringalertids);
    var myobjstr = {
      "alertIds": stringalertids,
      "UserAlias": ''
    }
    //add service code to send the read receipt.

    this.maintainService.ReadReceipents(myobjstr).subscribe(
      data=>{
        var readReceipents = data;
        this.Alertscount = 0 ;
        this.IsDisable = false;
      }
    );
  }
  else if (pagename=='Arrow'){
    this.IsClickedArrow=false;
  }
  else if (pagename=='help'){
    this.IsClickedhelp=false;
  }
  }

  getAlerts() {
    this.maintainService.GetUserAlerts(this.userAlias).subscribe(
      data => {
        var myArray = data;
        this.readreceipents = myArray.filter((x) => { return x.isRead == false })
        this.alerts = myArray.filter((x) => { return x.isHighSeverity == false })
        this.highSeverityalerts = myArray.filter((x) => { return x.isHighSeverity == true})
      });
  }
  // this.highseveritypopuplistcount =  this.maintainService.gethighseveritypopuplistcount();

  // UserAlertsCount() {
  //   var UserAlias = this.userAlias;
  //   this.maintainService.UserAlertsCount(UserAlias).subscribe(
  //     data => {
  //       var UserAlertsCount = data.highAlertCount + data.normalAlertCount;
  //       this.count = UserAlertsCount;
  //       if (this.count > 0) {
  //         this.IsDisable = true;
  //       }
  //       else {
  //         this.IsDisable = false;
  //       }
  //     }
  //   );

  // }

  refreshData(){
    this.dataRefresher =
      setInterval(() => {
        this.maintainService.SyncAlerts(false);
        //Passing the false flag would prevent page reset to 1 and hinder user interaction
      }, 60000);    //Refresh time is set to 10s
    }

    ngOnDestroy(){
      this.subscription.unsubscribe();
      this.highalertssubscription.unsubscribe();
      this.normalalertsubscription.unsubscribe();
    }

}
