﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
    public class FormSubmitInfo
    {
        public int Id { get; set; }
        public string ArchiveNumber { get; set; }
        public DateTime ProposedADCEDDate { get; set; }
        public string ReasonTypeIDs { get; set; }
        public string ReasonDescription{get; set; }
        public string AdditionalDetails { get; set; }
        public string ActionsToBeTaken { get; set; }
        public string AuditPICAlias{ get; set; }
        public string AuditPPDAlias { get; set; }
        public string CreatedBy { get; set; }
    }
}
