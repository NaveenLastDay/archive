import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpBackend } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { map } from 'rxjs/operators';
import { PubsubService } from './pubsub.service';

@Injectable({
    providedIn: 'root'
})
export class FaceSetSearchService {
    constructor(private _http: HttpClient) {
    }
    getAdvanceSearchArchiveDetails(searchQuery:string) {

        var tcHttpOptions = {
            headers: new HttpHeaders({
                'Content-Type': 'application/json'
            })
        }

        return this._http.get<any>("getadvancedsearcharchivedetails/"+searchQuery+"/saisgattu/0/0", tcHttpOptions)

    }
}