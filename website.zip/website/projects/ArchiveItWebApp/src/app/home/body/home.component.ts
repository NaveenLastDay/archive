import { Component, OnInit, Input, OnDestroy } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { AppConfig } from '../../services/appconfig.service';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { NotifierService } from "angular-notifier";
import { ModalService } from '../../modules/shared/modal';
import { MaintainalersService } from '../../services/maintainalers.service';
//import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { HomePageService } from '../../services/homepage.service'
import { Subscription } from 'rxjs';
import { PubsubService } from '../../services/pubsub.service';
import { NgxSpinnerService } from 'ngx-spinner'
import { UserConfigSettingService } from '../../guards/user-role-guard.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit, OnDestroy {
  currentUrl: string;
  HomeTiles: boolean = true;
  tileDashboard: boolean = true;
  tileLastArchive: boolean = true;
  tileMyArchives:boolean = true;
  tileAdminPanel:boolean = true;
  tileCreateArchive:boolean = true;
  tileReports:boolean=true;
  employeeRoleId:number = 15;
  UserName =this.adalSvc.LoggedInUserName;
  firstName=this.UserName.substring(0, this.UserName.lastIndexOf(","));
  lastName=this.UserName.substring(-1, this.UserName.lastIndexOf(","));
  userEmail = this.adalSvc.LoggedInUserEmail;
  userAlias = this.userEmail.substring(0, this.userEmail.lastIndexOf("@"));
  MouseHover: boolean = false;
  alerts: any[];
  enablepopup: boolean = false;
  highseveritypopuplistcount: number;
  IsClicked: any;
  readreceipents: any;
  userConfig: any;
  actionItemsCount: number;


  constructor(private router: Router, private adalSvc: MsAdalAngular6Service, private notifier: NotifierService
    , private modalService: ModalService, private maintainalerts: MaintainalersService,
      private SpinnerService: NgxSpinnerService, 
      private _userConfig:UserConfigSettingService,
     private homepageSvc: HomePageService, private pubsub: PubsubService ) {
    console.log(adalSvc.LoggedInUserEmail);
    console.log(adalSvc.LoggedInUserName);

  }

  public pubsubcount :number = 0;

  sendNumber(){
    this.pubsub.sendNumber(this.alerts.length);
  }

  ngOnInit() {
    this.actionItemsCount=0;
    let element = document.getElementById("customBreadcrumb");
    element.classList.add("home-breadcrumb");
    let element3 = document.getElementById("applicationFooter_ID");
    element3.classList.add("application-footer-b-0");
    this.userConfig = this._userConfig.FetchLoggedInUser(this.userAlias);
    this.HomeTiles = true;
    this.tileDashboard = true;
    this.tileLastArchive = true;
    this.tileMyArchives = true;
    this.tileAdminPanel = true;
    this.tileCreateArchive = true;
    this.tileReports = true;
    console.log(AppConfig.settings.env)
    console.log("MouseOver:" + this.MouseHover);
    this.homepageSvc.advanceSearchBtnDisable=false;
    this.homepageSvc.simpleSearchVisible=false;
    let element2 = document.getElementById("appRootScroll");
    element2.classList.remove("app-root-scroll");
    let element1 = document.getElementById("ulBreadcrumbDetails");
    element1.classList.add("custombreadcrumb-display");
    let element4 = document.getElementById("customBreadcrumb");
    element4.classList.remove("custom-breadcrumb");
    localStorage['IsSectionVisited']=0;
    localStorage['isERPSectionVisitedinOpenBySubmitter']=0;
    localStorage['archiveInfoData']='';
    localStorage['dashboardCountData']='';
    console.log("LocalStorage Reset to 0 in Main Home (85):",localStorage['IsSectionVisited']);
    //this.notifier.notify("success", "Application loaded successfully.");
    this.homepageSvc.GetArchiveAccessRequestCountForDashboard().subscribe((data) =>{
      localStorage.setItem('dashboardCountData', JSON.stringify(data));
      data.complianceMetricsForUser.forEach((ele) => {
        if (ele.category == 'AccessRequests' || ele.category == 'ArchiveDeletions' ||
        ele.category == 'Form3283SApprovals'||ele.category == 'ArchivesRequiringApprovals'||
        ele.category == 'PendingSubmissions'||ele.category == 'RetensionExceptions')
        {
          this.actionItemsCount=this.actionItemsCount+ele.count;
        }

      });
    });

  }
  ngOnDestroy() {
    let element3 = document.getElementById("applicationFooter_ID");
    element3.classList.remove("application-footer-b-0");
    let element = document.getElementById("customBreadcrumb");
    element.classList.remove("home-breadcrumb");
    let element2 = document.getElementById("appRootScroll");
    element2.classList.add("app-root-scroll");
    let element1 = document.getElementById("ulBreadcrumbDetails");
    element1.classList.remove("custombreadcrumb-display");
  }
  OnClick(PageUrl) {
    this.homepageSvc.advanceSearchBtnDisable=false;
    this.homepageSvc.simpleSearchVisible=false;
    this.router.navigate(["/" + PageUrl + ""]);
  }
  OnClickReports(){
    this.notifier.notify("error", "Coming Soon...");
  }
  OnClickCreateArchive(){
    if(this.userConfig.value.IsManager||this.userConfig.value.IsPPD||this.userConfig.value.isAdmin)
    {
      this.router.navigate(['/archive/SearchWbs']);
    }
    else{
      this.notifier.notify("error", "User is not eligible to create archive");
    }
  }
  openDashboard() {
    this.router.navigate(['/dashboard/dashboardHome']);
  }

}