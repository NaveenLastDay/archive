import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';


@Component({
  selector: 'app-maintainlists',
  templateUrl: './maintain-lists.component.html',
  styleUrls: ['./maintain-lists.component.css']
})
export class MaintainlistsComponent implements OnInit {
  currentUrl: string;
  data: any;
  display: string = 'none';
  dataSource: any;
  maintainList: any = [];

  constructor(private router: Router){ 
    router.events.subscribe((_: NavigationEnd) => this.currentUrl = this.router.url);
  //   this.maintainList=[    
  //     'Engagement Types',
  //     'Privacy Period'
  //   ]
  
}

  ngOnInit() {
  }

}
