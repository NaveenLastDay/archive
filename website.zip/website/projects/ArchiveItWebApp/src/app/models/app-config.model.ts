export interface IAppConfig {
        env: {
            name: string;
        };
        language:{
            name:string;
        }
        appInsights: {
            instrumentationKey: string;
        };
        logging: {
            console: boolean;
            appInsights: boolean;
        };
        adalConfig: {
            clientId: string,
            tenant: string,
            redirectUri: string,
            cacheLocation: string,
            endpoints: {api: string},
            // apiServer: {metadata:string ,rules:string }
        };
        endpoints: {
            apigatewayurl: string
        };
    
        searchwbs: {
            textboxlength: Int16Array
        };
        rateThisApp: {
            RateThisAppUri: string,
            UseRateThisAppService: string,
            ApplicationID: string
        };

       walkMe: {
        WalkMeSrc:  string;
        
       };
       

    adobeAnalytics: {
        AdobeAnalyticsSrc:string;  
      
    };

    } 