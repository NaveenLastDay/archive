﻿using System;
using System.Collections.Generic;
using System.Text;
using Deloitte.AIFA.Models;
using System.Data;


namespace Deloitte.AIFA.Repositories.Transformers
{
    public class ProjectDetailsTransformer : BaseTransformer<ProjectMetaDataModel>
    {
        public enum ProjectDataFields
        {
            WBSLevelOne,
            WBSLevelOneName,
            ProjectMarketOfferingCode,
            ProjectMarketOfferingDescription,
            ProjectPartnerDisplayName,
            ProjectManagerDisplayName,
            ProjectPartnerOfficeName,
            ProjectPartnerFSSName,
            ProjectPartnerServiceAreaName,
            ProjectPartnerServiceLineName,
            ProjectPartnerCostCenterCode,
            ProjectPartnerCostCenterDescription,
            ProjectStartDate,
            ProjectEndDate,
            ClientNumber,
            ClientName

        }

        internal override ProjectMetaDataModel TransformElement(IDataReader dr, Func<IDataReader, ProjectMetaDataModel, ProjectMetaDataModel> bindExtraFields = null)
        {

            var projectEntity = new ProjectMetaDataModel
            {
                WBSNumber = dr[ProjectDataFields.WBSLevelOne.ToString()].ToString(),
                WBSName = dr[ProjectDataFields.WBSLevelOneName.ToString()].ToString(),
                ProjectMarketOfferingCode = dr[ProjectDataFields.ProjectMarketOfferingCode.ToString()].ToString(),
                ProjectMarketOfferingDescription = dr[ProjectDataFields.ProjectMarketOfferingDescription.ToString()].ToString(),
                ProjectPartnerDisplayName = dr[ProjectDataFields.ProjectPartnerDisplayName.ToString()].ToString(),
                ProjectManagerDisplayName = dr[ProjectDataFields.ProjectManagerDisplayName.ToString()].ToString(),
                ProjectPartnerOfficeName = dr[ProjectDataFields.ProjectPartnerOfficeName.ToString()].ToString(),
                ProjectPartnerFSSName = dr[ProjectDataFields.ProjectPartnerFSSName.ToString()].ToString(),
                ProjectPartnerServiceAreaName = dr[ProjectDataFields.ProjectPartnerServiceAreaName.ToString()].ToString(),
                ProjectPartnerServiceLineName = dr[ProjectDataFields.ProjectPartnerServiceLineName.ToString()].ToString(),
                ProjectPartnerCostCenterCode = dr[ProjectDataFields.ProjectPartnerCostCenterCode.ToString()].ToString(),
                ProjectPartnerCostCenterDescription = dr[ProjectDataFields.ProjectPartnerCostCenterDescription.ToString()].ToString(),
                ProjectStartDate= (dr[ProjectDataFields.ProjectStartDate.ToString()] is DBNull) ? DateTime.MinValue : DateTime.Parse(dr[ProjectDataFields.ProjectStartDate.ToString()].ToString()),
                ProjectEndDate= (dr[ProjectDataFields.ProjectEndDate.ToString()] is DBNull) ? DateTime.MinValue : DateTime.Parse(dr[ProjectDataFields.ProjectEndDate.ToString()].ToString()),
                WBSClientName= dr[ProjectDataFields.ClientName.ToString()].ToString(),
                WBSClientNumber= dr[ProjectDataFields.ClientNumber.ToString()].ToString(),
            };

            return projectEntity;
        }

    }
}
