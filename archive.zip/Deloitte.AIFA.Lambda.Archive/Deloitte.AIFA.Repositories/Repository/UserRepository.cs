﻿using Deloitte.AIFA.DataModels;
using Deloitte.AIFA.DomainEntities;
using Deloitte.AIFA.IRepositories;
using Deloitte.AIFA.Repositories.Transformers;
using Microsoft.Extensions.Caching.Memory;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Deloitte.AIFA.Repositories.Repository
{
	public class UserRepository : BaseRepository<UserField>, IUserRepository
	{
		IMemoryCache _cache;
		public UserRepository(IMemoryCache cache) : base(cache)
		{
			_cache = cache;
		}

		public List<UserDetail> FetchLoggedInUser(string userName)
		{

			Exception e = new Exception();
			try
			{
				var parameters = Builder.Bind(UserParameter.userAlias).On(userName)
								.Build();
				var userEntity = DbHelper.ExecuteReader(
					"pub_AIFA_GetLoggedInUser_v1",
					parameters,
						dr => new UserDetailsTransformer().Transform(dr).ToList());
				// return null;
				return _mapper.Map<List<UserDetailsModel>, List<UserDetail>>(userEntity);

			}
			catch (Exception ex)
			{
				e = ex;
				return null;
			}
		}

		public RoleMapping GetRoleMappingsForUser(string UserAlias, string ArchiveNumber)
		{
			Exception e = new Exception();
			try
			{
				var parameters = Builder.Bind(UserRoleMappingParameter.userAlias).On(UserAlias)
										.Bind(UserRoleMappingParameter.archiveNumber).On(ArchiveNumber)
							   .Build();
				var roleMappingDetailsforUser = DbHelper.ExecuteReader(
					"pub_AIFA_GetUserRoleFunctionMapping",
					parameters,
						dr => new RoleMappingTransformer().Transform(dr).FirstOrDefault());

				return _mapper.Map<RoleMappingModel, RoleMapping>(roleMappingDetailsforUser);

			}
			catch (Exception ex)
			{
				e = ex;
				throw e;
			}
		}

		public List<FooterConfigurationDataModel> GetFooterConfigurationData()
		{

			var parameters = Builder.Build();
			List<FooterConfigurationDataModel> footerConfigurationData = new List<FooterConfigurationDataModel>();
			return DbHelper.ExecuteReader(
					"pub_AIFA_GetFooterConfigurationData",
					parameters,
					dr =>
					{
						while (dr.Read())
						{
							FooterConfigurationDataModel model = new FooterConfigurationDataModel()
							{
								DisplayName = dr["DisplayName"].ToString(),
								Link = dr["Link"].ToString(),
								TSPropertyName = dr["TSPropertyName"].ToString(),
								Id = Convert.ToInt32(dr["Id"]),
								SortOrder = Convert.ToInt32(dr["SortOrder"]),
								WidthInPercentage = Convert.ToDouble(dr["WidthInPercentage"])
							};
							footerConfigurationData.Add(model);
						};
						return footerConfigurationData;
					});
		}

		public UserOfflinePermissions FetchUserofflinePermissions(string UserAlias)
		{
			Exception e = new Exception();
			try
			{
				var parameters = Builder.Bind(UserOfflinePermissionsParameter.userAlias).On(UserAlias)
										
							   .Build();
				var userOfflinePermissionDetails = DbHelper.ExecuteReader(
					"pub_GetUserOfflinePermissions",
					parameters,
						dr => new UserOfflinePermissionDetailsTransformer().Transform(dr).FirstOrDefault());

				return _mapper.Map<UserOfflinePermissionsModel, UserOfflinePermissions>(userOfflinePermissionDetails);

			}
			catch (Exception ex)
			{
				e = ex;
				throw e;
			}
		}


	}
}
