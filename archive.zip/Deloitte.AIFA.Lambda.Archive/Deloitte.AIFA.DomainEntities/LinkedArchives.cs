﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
    public class LinkedArchives
    {
        public  int? UniqueID { get; set; }
        public  int ArchiveID { get; set; }
        public  string ArchiveNumber { get; set; }
        public  string ReportingEntity { get; set; }
        public  string ArchiveDescription { get; set; }
        public  DateTime? PeriodEndDate { get; set; }
        public  DateTime? DueDate { get; set; }
        public  int LinkTypeID { get; set; }
        public  int LinkedArchiveID { get; set; }
        public  string LinkedArchive { get; set; }
        public  DateTime? ExpectedDocumentationCompletionDate { get; set; }
        public  string SubmissionStatusID { get; set; }
        public  int? LinkedArchiveId { get; set; }
        public  string TemporaryId { get; set; }
        public  int CreatedBy { get; set; }
        public  DateTime CreatedDate { get; set; }
        public  int? ModifiedBy { get; set; }
        public  DateTime? ModifiedDate { get; set; }
        public  int? DeletedBy { get; set; }
        public  DateTime? DeletedDate { get; set; }
        public int IsDirectLink { get; set; }
        public int LinkLevel { get; set; }
        public int ParentHierarchy { get; set; }
        public int ChildCount { get; set; }
        public string LinkedArchiveName { get; set; }
        public string LinkTypeDescription { get; set; }
        public int RowNumber { get; set; }
        public int Count { get; set; }
        public int IsAcessible { get; set; }
    }
}
