﻿using System;
using System.Collections.Generic;
using System.Text;
using Deloitte.AIFA.DataModels;
using System.Collections.Generic;
using System.Data;

namespace Deloitte.AIFA.Repositories.Transformers
{
   

    public enum ResubmissionReasonField
    {
        ResubmissionReasonID,
        Description
    }

    public class ResubmissionReasonTransformer : BaseTransformer<ResubmissionReasonModel>
    {
        internal override ResubmissionReasonModel TransformElement(IDataReader dr, Func<IDataReader, ResubmissionReasonModel, ResubmissionReasonModel> bindExtraFields = null)
        {
            return new ResubmissionReasonModel
            {
                ResubmissionReasonID = Convert.ToInt32(dr[ResubmissionReasonField.ResubmissionReasonID.ToString()]),
                Description = dr[ResubmissionReasonField.Description.ToString()] is DBNull ? "" : dr[ResubmissionReasonField.Description.ToString()].ToString()
            };
        }
    }
}
