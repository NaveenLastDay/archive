﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
    public class GrantDenyTemporaryArchiveAccess
    {
        public int ArchiveAccessRequestId { get; set; }
        public string GrantDenyReason { get; set; }
        public string GrantOrDeny { get; set; }        
    }
}
