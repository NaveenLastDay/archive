import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExistingWbsComponent } from './existing-wbs.component';

describe('ExistingWbsComponent', () => {
  let component: ExistingWbsComponent;
  let fixture: ComponentFixture<ExistingWbsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExistingWbsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExistingWbsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
