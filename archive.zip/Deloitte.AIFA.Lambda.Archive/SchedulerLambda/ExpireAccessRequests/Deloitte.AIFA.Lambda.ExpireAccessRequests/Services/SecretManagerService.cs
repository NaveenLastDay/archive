﻿using Amazon;
using Amazon.Lambda.Core;
using Amazon.SecretsManager;
using Amazon.SecretsManager.Model;
using Deloitte.AIFA.Lambda.AutoExpireTemporaryAccessRequests.Entities;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.IO;

namespace Deloitte.AIFA.Lambda.AutoExpireTemporaryAccessRequests.Services
{
    public class SecretsManagerService
    {
        #region Properties
        IConfiguration _configManager;
        IMemoryCache _cache;
        string decodedBinarySecret = "";
        private readonly AmazonSecretsManagerClient managerClient;
        public const string DBConnectionstring = "DBConnectionString";

        #endregion Properties

        #region Constructor
        public SecretsManagerService(IConfiguration configuration, IMemoryCache cache)
        {
            _cache = cache;
            this._configManager = configuration;
            try
            {
                string regionkey = _configManager["region-key"];
                var secretsManagerConfig = new AmazonSecretsManagerConfig
                {

                    RegionEndpoint = RegionEndpoint.GetBySystemName(
                        Environment.GetEnvironmentVariable(regionkey))
                };
                managerClient = new AmazonSecretsManagerClient(secretsManagerConfig);

                _cache.Set(DBConnectionstring, GetDBConString());
                LambdaLogger.Log(String.Format("{0} :", LogCategory.Information.ToString()) + " :" + "connection string created");

            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception in Secretmanager ctor:" + ex.InnerException.ToString() + ex.Message + ex.StackTrace);
            }

        }

        #endregion

        /// <summary>
        /// Method to get DB connection string
        /// </summary>
        /// <returns></returns>
        public string GetDBConString()
        {
            return GetConfig(_configManager["secret-key"]);

        }

        /// <summary>
        /// Method to get Config
        /// </summary>
        /// <param name="secretName"></param>
        /// <returns></returns>
        public string GetConfig(string secretName)
        {
            string connString = string.Empty;
            string dbName = _configManager["database-name"];
            var request = new GetSecretValueRequest
            {
                SecretId = Environment.GetEnvironmentVariable(secretName)
            };

            GetSecretValueResponse response = null;

            try
            {
                response = managerClient.GetSecretValueAsync(request).GetAwaiter().GetResult();
            }
            catch (ResourceNotFoundException)
            {
                Console.WriteLine("The requested secret " + secretName + " was not found");
            }
            catch (InvalidRequestException e)
            {
                Console.WriteLine("The request was invalid due to: " + e.Message);
            }
            catch (InvalidParameterException e)
            {
                Console.WriteLine("The request had invalid params: " + e.Message);
            }

            if (response != null)
            {
                var secretVarialbles = JsonConvert.DeserializeObject<SecretManager>(response.SecretString);
                connString = $"Server={secretVarialbles.host};Port={secretVarialbles.port};database={dbName};User Id={secretVarialbles.username};Password={secretVarialbles.password}";

            }

            return connString;
        }


        #region GetSecretByKey        
        public string GetConfigValueByKey(string secretName)
        {
            #region Properties
            string region = string.Empty;
            string secret = string.Empty;
            #endregion Properties

            #region Logic

            if (_configManager["Region"] != null && _configManager["Region"] != string.Empty)
            {
                region = _configManager["Region"];
            }
            var aws_access_key_id = "";
            var aws_secret_access_key = "";
            MemoryStream memoryStream = new MemoryStream();
            IAmazonSecretsManager client = new
                AmazonSecretsManagerClient(RegionEndpoint.GetBySystemName(region));


            GetSecretValueRequest request = new GetSecretValueRequest();
            request.SecretId = secretName;
            request.VersionStage = "AWSCURRENT"; // VersionStage defaults to AWSCURRENT if unspecified.

            GetSecretValueResponse response = null;

            try
            {
                response = client.GetSecretValueAsync(request).Result;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            if (response.SecretString != null)
            {
                secret = response.SecretString;
            }
            else
            {
                memoryStream = response.SecretBinary;
                StreamReader reader = new StreamReader(memoryStream);
                decodedBinarySecret = System.Text.Encoding.UTF8.GetString(Convert.FromBase64String(reader.ReadToEnd()));
            }

            var jsonKey = !string.IsNullOrEmpty(secret) ? secret : decodedBinarySecret;
            JObject obj = JObject.Parse(jsonKey);
            string SecretKey = (string)obj[DBConnectionstring];

            return SecretKey;
            #endregion Logic
        }
        #endregion GetSecretByKey
    }
}
