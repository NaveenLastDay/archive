import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ArchiveHistoryComponent } from './archive-history.component';

describe('ArchiveHistoryComponent', () => {
  let component: ArchiveHistoryComponent;
  let fixture: ComponentFixture<ArchiveHistoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ArchiveHistoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ArchiveHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
