import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ArchiveHomeService } from '../../../services/archive-home.service';
import { EngagementService } from '../../../services/engagement.service';

@Component({
  selector: 'app-engagement-details',
  templateUrl: './wbs-details.component.html',
  styleUrls: ['./wbs-details.component.css']
})
export class EngagementDetailsComponent implements OnInit {
selectedWBS:string;
engagementData:any
archiveNumber:string;
  constructor(private engagementService: EngagementService,private archiveHomeService: ArchiveHomeService, private activatedRoute: ActivatedRoute,private spinnerService: NgxSpinnerService) {
  }

  ngOnInit() {
   // this.spinnerService.show();
    this.archiveNumber = this.activatedRoute.snapshot.parent.paramMap.get('aN');
    this.selectedWBS = this.activatedRoute.snapshot.params.optionWBSNumber;
    this.archiveHomeService.SyncForm3283SStatus(this.archiveNumber);
    console.log(this.selectedWBS);
    this.engagementService.getEngagementDetails(this.selectedWBS,this.archiveNumber).subscribe(data => {
        this.engagementData=data;
       // this.spinnerService.hide();
      });
  }
}
