﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
	public class EarlyTerminationCeasedDate
	{
		public string ArchiveNumber { get; set; }	
		public DateTime? EarlyTerminationDate { get; set; }
		public Boolean EarlyTerminated { get; set; }
		public string ModifiedBy { get; set; }
		public DateTime? ModifiedDate { get; set; }
        public int MetadataID { get; set; }

    }
}
