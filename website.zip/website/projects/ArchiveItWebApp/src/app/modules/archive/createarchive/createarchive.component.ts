import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { Router, NavigationEnd, ActivatedRoute } from '@angular/router';
import { ArchiveService } from '../../../services/archive.service';
import { ModalService } from '../../shared/modal';
import { NotifierService } from 'angular-notifier';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { PeoplePickerService } from '../../../services/MDREmployeeeDetails.service';
import { FormControl, FormGroup, FormBuilder, Validators, FormArray } from '@angular/forms';
import { NgxSpinnerService } from "ngx-spinner";
import { HomePageService } from '../../../services/homepage.service';
import { UserConfigSettingService } from '../../../guards/user-role-guard.service';
import { ArchiveHomeService } from '../../../services/archive-home.service';
import { MatAutocompleteTrigger } from '@angular/material/autocomplete';
import { archiveInfoService } from '../../../services/archiveinfo.service';
import { BehaviorSubject } from 'rxjs';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { NgbDate, NgbDateParserFormatter, NgbDatepicker, NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { CustomDateFormatter } from '../../shared/shared-custom-dateformatter';

@Component({
  selector: 'app-createarchive',
  templateUrl: './createarchive.component.html',
  styleUrls: ['./createarchive.component.css'],
  providers: [{provide: NgbDateParserFormatter, useClass: CustomDateFormatter}]
})
export class CreatearchiveComponent implements OnInit, OnDestroy {

  userName = this.adalSvc.LoggedInUserName;
  userEmail = this.adalSvc.LoggedInUserEmail;
  euserAlias = this.userEmail.replace("@deloitte.com", "");

  employeeUniqueIdentifier = this.adalSvc.LoggedInUserEmail.split('@')[0];
  isSubmitted = false;
  login_form: FormGroup;
  checkboxValue: any;
  currentUrl: string;

  //Variables get selected values
  selectedEngagementType: string;
  selectedEntityType: string;
  selectedEntity: string;
  selectedArchiveType: string;

  //Variables to get entered values
  myarchive_description: string;
  displaytextbox: boolean = false;

  // Assigning for Date field

  archiveDate: Date;
  estimatedDate: Date;
  estdate: Date;
  periodDate: any = undefined;
  toDates: string;
  //Declared myModel variable for a event
  myModel: any;
  //Variable for Creating Archive method
  createdArchive: any;
  ArchiveNumber: string;
  // Textbox variable
  ArchiveName: string = "";
  //Assigning variable for Dropdown
  EngagementType: number = 0;
  engagements: any;
  entitytype: number;
  entities: any;
  archivenames: any;
  // Assigning Variable for Textboxes
  AdditionalDescriptor: string = "";
  ArchivePartner: string = "";
  ArchiveFieldSenior: string = "";
  AdditionalArchiveFieldSenior: string = "";
  EntityType: number = 0;
  ArchiveType: number = 0;
  TitleCount: number = 0;
  Entity: number = 0;
  wbsData: any = "";
  //For people picker
  searchText: string;
  users: Array<any> = [];
  PPMDUsers: Array<any> = [];
  searchPeople: FormGroup;
  selectedPartner: string;
  selectedManager: string;
  selectedPartnerViewName: string = "";
  selectedFieldSenior: string = "";
  selectedAdditionalFieldSenior: string;
  selectedFieldSeniorViewName: string = "";
  selectedManagerViewName: string = "";
  selectedAdditionalFieldSeniorViewName: string = "";
  archivenum: any;
  archiveNmbr: any;
  showMyMessage: boolean = false;
  wbsinfo: any;
  selectedItem: any;
  archivenew: any;
  AdditionalDescriptorcount: number = 0;
  createarchivelst: any;
  archiveSearchBase: any[];
  isAccessAllowed: number = 0;
  isCopied: boolean = false;
  managervalue: any;
  archivePartnerr: any;
  archivepartneralias: any;
  defaultmanager: any;
  archivemanager: string;
  archivePtnr: any;
  addSigningPeopleMaxCount: number = 5;
  addSigningPeopleUserName: Array<any> = [];
  isSigningUserDuplicate: boolean[] = [];
  selectedSigningUserAlias: any = [];
  fieldArray: Array<any> = [];
  newAttribute: any = {};
  removeIndex: number;
  addIndex: number;
  duplicateValues: any;
  onlyFirstAttempt: number = 0;
  userConfig: any;
  expecteddate: any;
  isAdditionalDescriptorRequired: boolean = false;
  rolecode: string;
  isArchiveCompleted: boolean = true;
  signingUserDuplicate: boolean[] = [];

  @ViewChild('autoCompleteInputAP', { read: MatAutocompleteTrigger, static: false }) autoCompleteAP: MatAutocompleteTrigger;
  @ViewChild('autoCompleteInputAM', { read: MatAutocompleteTrigger, static: false }) autoCompleteAM: MatAutocompleteTrigger;
  @ViewChild('autoCompleteInputAFS', { read: MatAutocompleteTrigger, static: false }) autoCompleteAFS: MatAutocompleteTrigger;
  @ViewChild('autoCompleteInputAAFS', { read: MatAutocompleteTrigger, static: false }) autoCompleteAAFS: MatAutocompleteTrigger;
  @ViewChild('autoCompleteInputSP1', { read: MatAutocompleteTrigger, static: false }) autoCompleteSP1: MatAutocompleteTrigger;
  @ViewChild('autoCompleteInputSP2', { read: MatAutocompleteTrigger, static: false }) autoCompleteSP2: MatAutocompleteTrigger;
  @ViewChild('autoCompleteInputSP3', { read: MatAutocompleteTrigger, static: false }) autoCompleteSP3: MatAutocompleteTrigger;
  @ViewChild('autoCompleteInputSP4', { read: MatAutocompleteTrigger, static: false }) autoCompleteSP4: MatAutocompleteTrigger;
  @ViewChild('autoCompleteInputSP5', { read: MatAutocompleteTrigger, static: false }) autoCompleteSP5: MatAutocompleteTrigger;
  @ViewChild('estimatedDateEle', { static: false }) estimatedDateRef: NgbDatepicker;
  archiveNumber: string;
  autoestimatedate:  NgbDateStruct;;
  archiveNum: string;
  archivemanageralias: any;
  clientname: any;
  wbsnumber: any;
  wbsname: any;
  wbsinfodetails: any;
  lastSearchKeyword: string = '';
  currentSearchKeyword: string = '';
  isDisabled:any;
  private _subject: BehaviorSubject<string> = new BehaviorSubject<string>("");


  constructor(private archiveinfoSvc: archiveInfoService, private router: Router, private service: ArchiveService, private peoplePickerService: PeoplePickerService,
    private modalService: ModalService, private notifier: NotifierService, public fb: FormBuilder, private activatedRoute: ActivatedRoute,
    private _userConfig: UserConfigSettingService
    , private adalSvc: MsAdalAngular6Service, private SpinnerService: NgxSpinnerService, private homepageSvc: HomePageService, private archiveHomeService: ArchiveHomeService) {
    router.events.subscribe((_: NavigationEnd) => this.currentUrl = this.router.url);
    this.isDisabled = (date: NgbDate, current: { month: number; year: number }) => date.month !== current.month;
    this.login_form = fb.group({
      'archivepartner': [null, Validators.required],
      'archivemanager': [null, Validators.required],
      'fieldsenior': [null, Validators.required],
      'description': ['', Validators.compose([Validators.required, Validators.minLength(5)])],
      'EngagementType': [null, Validators.required],
      'entitytype': [null, Validators.required],
      'standardtype': [null, Validators.required],
      'archivetype': [null, Validators.required],
      'PeriodEndDate': [null, Validators.required],
      'EstimatedDate': [null, Validators.required],
      'terms': [false]
    });

  }

  ngOnInit() {
    this.userConfig = this._userConfig.FetchLoggedInUser(this.euserAlias);
    if(this.userConfig.value.IsManager||this.userConfig.value.IsPPD||this.userConfig.value.isAdmin){
   // this.SpinnerService.show();
    this.selectedItem = this.activatedRoute.snapshot.params.optionWBSNumber;
    this.archiveNum = this.activatedRoute.snapshot.parent.paramMap.get('aN');
    console.log("my archive number is" + this.archiveNum);
    window.addEventListener('scroll', this.scrollEvent, true);
    this.getengagementtypes();
    this.getentities();
    this.getentitytypes();
    this.getarchivetypes();
    if (this.archiveNum != null) {
      this.getautocreatearchivedetails();
    }
    // this.onInputChanged(this.userAlias);
    this.TitleCount = 250;
    this.AdditionalDescriptorcount = 20;
   if(this.archiveNum == null){
    this.getwbsinfo(this.selectedItem);
   this.defaultmanager = this.userConfig.value.lastName + ', ' + this.userConfig.value.firstName;
    this.archivemanager = this.userConfig.value.lastName + ', ' + this.userConfig.value.firstName;
    this.archivemanageralias = this.euserAlias;
   }

    //this.selectedItem="";
    if (this.fieldArray.length < 1) {
      this.fieldArray.push(this.newAttribute);
      this.signingUserDuplicate.push(false);
    }
  }
  else{
    this.router.navigate(["/"]);
  }
  }

  getautocreatearchivedetails() {
   // this.SpinnerService.show();
    this.archiveinfoSvc.getautocreatearchivedetails(this.archiveNum).subscribe(
      (info) => {
        this.clientname = info.clientName;
        this.wbsnumber = info.wbsLevelOne;
        this.wbsname = info.wbsLevelOneName;
        this.archivePartnerr = info.archivepartnerName;
        this.archivePtnr = info.archivepartnerName;
        this.autoestimatedate = this.toNGBDateFormatter(info.estimatedIssuanceReportDate);
        this.estimatedDateRef.onChange(this.autoestimatedate);
        this.defaultmanager = info.archivemanagername;
        this.archivemanager = info.archivemanagername;
        this.isArchiveCompleted = info.isArchiveCompleted;
        this.archivepartneralias = info.archivepartneralias;
        this.archivemanageralias = info.archivemanageralias;
       // this.SpinnerService.hide();
      });
  }

  redirecthomepage() {
    this.notifier.notify("success", "Archive creation cancelled successfully");
    setTimeout(() => this.router.navigate(["/"]), 3000);
  }

  scrollEvent = (event: any): void => {
    if (this.autoCompleteAP && this.autoCompleteAP.openPanel)
      this.autoCompleteAP.updatePosition();
    if (this.autoCompleteAM && this.autoCompleteAM.openPanel)
      this.autoCompleteAM.updatePosition();
    if (this.autoCompleteAFS && this.autoCompleteAFS.openPanel)
      this.autoCompleteAFS.updatePosition();
    if (this.autoCompleteAAFS && this.autoCompleteAAFS.openPanel)
      this.autoCompleteAAFS.updatePosition();
    if (this.autoCompleteSP1 && this.autoCompleteSP1.openPanel)
      this.autoCompleteSP1.updatePosition();
    if (this.autoCompleteSP2 && this.autoCompleteSP2.openPanel)
      this.autoCompleteSP2.updatePosition();
    if (this.autoCompleteSP3 && this.autoCompleteSP3.openPanel)
      this.autoCompleteSP3.updatePosition();
    if (this.autoCompleteSP4 && this.autoCompleteSP4.openPanel)
      this.autoCompleteSP4.updatePosition();
    if (this.autoCompleteSP5 && this.autoCompleteSP5.openPanel)
      this.autoCompleteSP5.updatePosition();
  };

  showMessageSoon() {
    this.showMyMessage = true

  }
  onPeriodEndDateChange(event: any) {
    this.archiveDate = event;
    if(this.archiveDate != null || this.archiveDate != undefined)
    this.periodDate = event; // this.toNGBDateFormatter(this.archiveDate);
  }

  onEstimatedDateChanges(event2: any) {
    this.estdate = event2;
    if (this.estdate == null || this.estdate == undefined) {
      this.estimatedDate = undefined;
    }
    else {
      this.estimatedDate = event2;
      this.autoestimatedate = event2;//new Date(event2.month+'/'+ event2.day +'/'+ event2.year);
    }
  }

  // Get Engagement Type

  getwbsinfo(selectedItem: string) {
   // this.SpinnerService.show();
    this.service.getwbsdetails(selectedItem).subscribe(
      (info) => {
        this.wbsinfodetails = info;
       // this.SpinnerService.hide();
        this.clientname = this.wbsinfodetails.clientName;
        this.wbsnumber = this.wbsinfodetails.wbsLevelOne;
        this.wbsname = this.wbsinfodetails.wbsLevelOneDescription;
        this.archivePartnerr = this.wbsinfodetails.partnerName;
        this.archivePtnr = this.wbsinfodetails.partnerName;
        this.archivepartneralias = this.wbsinfodetails.partnerAlias;
      },
      (err) => {
        console.log("error is ", err)
      }
    );

  }

  getengagementtypes() {
   // this.SpinnerService.show();
    this.service.GetEngagementType().subscribe(
      (data) => {
        this.engagements = data;
      },
      (err) => {
        console.log("error is ", err)
      }
    );
  }
  //Get Selected Engagement

  selectEngagement(engagementtype: string) {
    this.selectedEngagementType = engagementtype;
  }

  //Get Entity

  getentities() {
   // this.SpinnerService.show();
    this.service.GetEntity().subscribe(
      data => {
        this.entities = data;
      }
    );
  }
  // Get Selected Entity

  selectEntity(entity: string) {
    this.selectedEntity = entity;
  }

  //Get Entity Type
  getentitytypes() {
   // this.SpinnerService.show();
    this.service.GetEntityType().subscribe(
      data => {
        this.entitytype = data;
      }
    );
  }
  // Get Selected Entitity Type

  selectEntityType(entitytype: string) {
    this.selectedEntityType = entitytype;

  }
  //Get ArchvieType
  getarchivetypes() {
    this.service.GetArchiveType().subscribe(
      data => {
        this.archivenames = data;
      }
    );
  }
  // Get Selected ArchiveType
  selectArchiveType(args) {
    this.myarchive_description = args.target.options[args.target.selectedIndex].text;
    this.selectedArchiveType = args.target.value;
    if (this.myarchive_description == "Other") {
      this.displaytextbox = true;
      this.AdditionalDescriptorcount = 20;
    }
    else {
      this.displaytextbox = false;
      this.AdditionalDescriptor = "";
      this.AdditionalDescriptorcount = 0;
      this.isAdditionalDescriptorRequired = false;
    }
  }

  onKeyUp(event) {
    this.TitleCount = 250 - event.target.value.length;
  }

  onKey(event) {
    this.AdditionalDescriptorcount = 20 - event.target.value.length;
    if (event.target.value.length >= 1)
      this.isAdditionalDescriptorRequired = false;
    else
      this.isAdditionalDescriptorRequired = true;
  }

  //For PeoplePicker

  onInputChanged(searchString: string, indexValue?: number, rolecode?: string) {
    let element = document.getElementsByClassName("cdk-overlay-container")[0];
    if(element!==null && element !== undefined) {
     element.classList.add('custom-cdk-peoplepicker');
    }
    this.addIndex = indexValue;
    this.rolecode = rolecode;
    let haserror = this.isSigningUserDuplicate[this.addIndex];
    if (searchString == "") {
      this.lastSearchKeyword = '';
      this.isSigningUserDuplicate[this.addIndex] = false;
      this.signingUserDuplicate[this.addIndex] = false;
      this.selectedSigningUserAlias[this.addIndex] = "";
      let findDuplicates = arr => arr.filter((item, index) => arr.indexOf(item) != index)
      this.duplicateValues = findDuplicates(this.selectedSigningUserAlias);
      if (this.duplicateValues && !haserror) {
        let findIndex = this.isSigningUserDuplicate.indexOf(true);
        this.isSigningUserDuplicate[findIndex] = false;
        this.signingUserDuplicate[findIndex] = false;
      }
    }
    this.currentSearchKeyword = searchString;
    this._subject.next(this.currentSearchKeyword ? this.currentSearchKeyword.trim() : "");

    if (searchString.length >= 3) {
      console.log('role', rolecode);
      this._subject.pipe(
        distinctUntilChanged(),
        debounceTime(500),
      ).subscribe(value => this.getPeople(value))
    }
    else {
      this.users = [];
      this.PPMDUsers = [];
      this.lastSearchKeyword = '';
    }

  }

  onFocusTB() {
    this.users = [];
    this.PPMDUsers = [];
  }

  getPeople(searchString: string) {
    if (searchString.length >= 3 && this.lastSearchKeyword != searchString) {
      this.lastSearchKeyword = searchString;
      this.peoplePickerService.GetPeople(searchString, this.rolecode).subscribe(
        (value) => {
          this.users = [];
          this.PPMDUsers = [];
          value.forEach(element => {
            if (this.currentSearchKeyword.length >= 3) {
              // if (element.isPPD)
              this.PPMDUsers = value;
              this.users = value;
              console.log('1234567890', this.currentSearchKeyword);
            } else {
              this.PPMDUsers = [];
              this.users = [];
            }
          });
        },
        (err) => {
          console.log("error is ", err)
        }
      );
      this.SpinnerService.hide();
    }
  }

  selectedPartnerName(partner, index) {
    // this.myarchive_description = partner.target.options[partner.target.selectedIndex].text;
    this.selectedPartnerViewName = partner.source.viewValue;
    this.selectedPartner = this.users[index].userAlias;//change to useralias once lambda is changed.
    this.users = [];
    this.PPMDUsers = [];
  }

  selectedManagerName(partner, index) {
    this.selectedManagerViewName = partner.source.viewValue;
    this.selectedManager = this.users[index].userAlias;
    //change to useralias once lambda is changed.
    this.users = [];
    this.PPMDUsers = [];
  }

  selectedFieldSeniorName(fieldsenior, index) {
    this.selectedFieldSeniorViewName = fieldsenior.source.viewValue;
    this.selectedFieldSenior = this.users[index].userAlias;//change to useralias once lambda is changed.
    this.users = [];
    this.PPMDUsers = [];
  }

  selectedAdditionalFieldSeniorName(additionalfieldsenior, index) {
    this.selectedAdditionalFieldSeniorViewName = additionalfieldsenior.source.viewValue;
    this.selectedAdditionalFieldSenior = this.users[index].userAlias;//change to useralias once lambda is changed.
    this.users = [];
    this.PPMDUsers = [];
  }

  selecteSigningUserName(signingUser, index) {
    let result = this.getAllIndexes(this.selectedSigningUserAlias, this.users[index].userAlias);
    if (result.length > 0) {
      this.signingUserDuplicate[this.addIndex] = true;
      this.addSigningPeopleUserName[this.addIndex] = signingUser.source.viewValue;
      this.selectedSigningUserAlias[this.addIndex] = this.users[index].userAlias;
    }
    else {
      this.signingUserDuplicate[this.addIndex] = false;
      this.addSigningPeopleUserName[this.addIndex] = signingUser.source.viewValue;
      this.selectedSigningUserAlias[this.addIndex] = this.users[index].userAlias;
    }
    this.PPMDUsers = [];
    this.users = [];
  }

  //For Cancel Button
  onReset() {
    this.periodDate = undefined;
    this.toDates = undefined;
    this.selectedAdditionalFieldSeniorViewName = "";
    this.selectedAdditionalFieldSenior = undefined;
    this.selectedFieldSenior = '';
    this.selectedPartner = undefined;
    this.selectedManager = undefined;
    this.AdditionalDescriptor = "";
    this.login_form.get('EngagementType').reset();
    this.login_form.get('archivepartner').setValue(this.archivePtnr);
    this.login_form.get('fieldsenior').reset();
    this.login_form.get('description').reset();
    this.login_form.get('entitytype').reset();
    this.login_form.get('standardtype').reset();
    this.login_form.get('archivetype').reset();
    this.login_form.get('PeriodEndDate').reset();
    this.login_form.get('archivemanager').setValue(this.archivemanager);
    this.login_form.get('EstimatedDate').reset();
  }

  oninput(eventvalue: string) {
    this.managervalue = eventvalue;
  }

  CreateNewArchive() {
    this.userName = this.archivemanager;
    this.markFormTouched(this.login_form);
    let index = this.getAllIndexes(this.signingUserDuplicate, true);
    this.CheckAdditionalDescription();
    if (this.selectedPartnerViewName != '' && this.selectedPartner == undefined) {
      this.notifier.notify("error", "please select valid partner");
    }

    else if (this.selectedManager == undefined && (this.managervalue != this.userName && this.managervalue != undefined)) {
      this.notifier.notify("error", "please select valid manager");
      this.managervalue = this.userName;
    }

    else if (this.selectedFieldSeniorViewName != '' && this.selectedFieldSenior == "") {
      this.notifier.notify("error", "please select valid field senior");
    }

    else if (this.selectedAdditionalFieldSeniorViewName != '' && this.selectedAdditionalFieldSenior == undefined) {
      this.notifier.notify("error", "please select valid additional field senior");
    }

    else if (this.login_form.valid && index.length < 1 && !this.isAdditionalDescriptorRequired && this.AdditionalDescriptorcount<=15) {

      var role;
      var ppd = this.selectedPartnerViewName.length ? this.selectedPartner : this.archivepartneralias;
      var manager = this.selectedManagerViewName.length ? this.selectedManager : this.archivemanageralias;
      if (this.euserAlias == ppd) {
        role = 5;
      }
      else if (this.euserAlias == manager) {
        role = 6;
      }
      else if (this.euserAlias == this.selectedFieldSenior) {
        role = 7;
      }
      else {
        role = null;
      }

      var parameters = {

        "WBSLevelOneNumber": this.selectedItem,

        "WBSInfo":
        {

          "WBSEngagementPPMD": this.selectedPartnerViewName.length ? this.selectedPartner : this.archivepartneralias,
          "EngagementManager": this.selectedManagerViewName.length ? this.selectedManager : this.archivemanageralias,
          "SigningPartners": this.selectedSigningUserAlias.filter(function (el) { return el != null; }).toString()
        },
        "ArchiveInfo":
        {
          "Description": this.selectedArchiveType,
          "AdditionalDescription": this.AdditionalDescriptor,
          "EngagementDesc": this.ArchiveName,
          "PeriodEnd": this.convertToDateFormat(this.periodDate), //this.archiveDate != undefined && this.archiveDate != null ? new Date(this.archiveDate).toLocaleDateString() : this.periodDate,
          "EngagementType": this.selectedEngagementType,
          "EstimatedDate": this.convertToDateFormat(this.autoestimatedate), //this.estimatedDate != undefined && this.estimatedDate != null ? new Date(this.estimatedDate).toLocaleDateString() : this.autoestimatedate,
          "ArchiveType": this.selectedArchiveType,
          "EntityType": this.selectedEntityType,
          "CreatedBy": this.euserAlias,
          "RoleID": role,
          "ArchiveFieldSenior": this.selectedFieldSenior,
          "AdditionalArchiveFieldSenior": this.selectedAdditionalFieldSenior,
          "ProfessionalStandard": this.selectedEntity,
          "ArchiveNum": this.archiveNum
        }
      }
     // this.SpinnerService.show();
      /*var myobjstr = JSON.stringify(parameters);*/
      this.service.CreateArchive(parameters).subscribe(
        data => {
          this.archivenum = data;
          this.archiveNmbr = this.archivenum.archiveNumber;
          this.isAccessAllowed = this.archivenum.isAccessAllowed;
          /* this.isAccessAllowed=1;*/
         // this.SpinnerService.hide();
          if (data.archiveNumber == this.archiveNum) {
            this.notifier.notify("success", "Archive created successfully");
            setTimeout(() => this.router.navigate(["archive/myarchives"]), 3000);
          }
          if (data.archiveNumber != this.archiveNum && data.archiveNumber.length > 0) {
            // this.GetArchiveDueDate();
            this.modalService.openWithCustomWidth('create-archive-modal', "500");
          }
        }
      );
    }
    else {
      this.login_form.controls['terms'].setValue(false);
    }
  }

  CheckAdditionalDescription() {
    if (this.displaytextbox) {
      if (this.AdditionalDescriptor == '' || this.AdditionalDescriptor == undefined) {
        this.isAdditionalDescriptorRequired = true;
      }
    }
  }
  getDateInFormat(d:number)
  {
    return (d < 10 ? '0' +d : d);
  }
  convertToDateFormat(inputDate:any){
   return this.getDateInFormat(inputDate.month)  + "/" + this.getDateInFormat(inputDate.day) + "/" + inputDate.year;
  }
  toNGBDateFormatter(toDateString){
    var datearray = toDateString.split("/");
    var newdate = datearray[1] + '/' + datearray[0] + '/' + datearray[2];
    console.log(newdate);
    if(datearray.length>1)
    var date = new Date(newdate);
    else  date = new Date(toDateString);
    return { day: parseInt(date.getDate().toString()), month: parseInt((date.getMonth()+1).toString()), year: parseInt(date.getFullYear().toString())};
  }
  // GetArchiveDueDate() {
  //   this.archiveHomeService.GetArchiveDueDate(this.archiveNmbr, this.employeeUniqueIdentifier).subscribe(
  //     data => {
  //       this.expecteddate = data.expectedDocumentationCompletionDate;
  //     }
  //   );
  // }

  closeModalDialog(Action) {
    this.modalService.close(Action);
  }

  markFormTouched(group: FormGroup | FormArray) {
    Object.keys(group.controls).forEach((key: string) => {
      const control = group.controls[key];
      if (control instanceof FormGroup || control instanceof FormArray) { control.markAsTouched(); this.markFormTouched(control); }
      else { control.markAsTouched(); };
    });
  };

  OnClick(PageUrl) {
    this.router.navigate(["/" + PageUrl + ""]);
  }

  redirectToArchiveHomePage(PageUrl) {
    this.router.navigate(["/" + PageUrl + "/" + this.archiveNmbr]);
  }

  copyarchivenumber(copyValue: string) {
    const selBox = document.createElement('textarea');
    selBox.style.position = 'fixed';
    selBox.style.left = '0';
    selBox.style.top = '0';
    selBox.style.opacity = '0';
    selBox.value = copyValue;
    document.body.appendChild(selBox);
    selBox.focus();
    selBox.select();
    document.execCommand('copy');
    document.body.removeChild(selBox);
    this.isCopied = true;
  }

  addFieldValue() {
    if (this.fieldArray.length < this.addSigningPeopleMaxCount) {
      this.fieldArray.push(this.fieldArray.length + 1);
      this.signingUserDuplicate.push(false);
    }
  }

  removeAlertShow(indexValue) {
    this.removeIndex = indexValue;
    this.modalService.openWithCustomWidth('remove-alert-modal', "500");

  }

  cancelarchiveAlertShow() {
    this.modalService.openWithCustomWidth('cancelarchivecreation-alert-modal', "500");
  }

  removeFieldAndValue(removeSigningUser) {
    if (removeSigningUser) {
      let findIndex = this.getAllIndexes(this.selectedSigningUserAlias, this.selectedSigningUserAlias[this.removeIndex]);
      if (!this.signingUserDuplicate[this.removeIndex] && findIndex.length == 1)
        this.signingUserDuplicate[findIndex[findIndex.length]] = false;
      if (!this.signingUserDuplicate[this.removeIndex] && findIndex.length == 2)
        this.signingUserDuplicate[findIndex[findIndex.length - 1]] = false;
      else if (!this.signingUserDuplicate[this.removeIndex] && findIndex.length == 3)
        this.signingUserDuplicate[findIndex[findIndex.length - 2]] = false;
      else if (!this.signingUserDuplicate[this.removeIndex] && findIndex.length == 4)
        this.signingUserDuplicate[findIndex[findIndex.length - 3]] = false;
      else if (!this.signingUserDuplicate[this.removeIndex] && findIndex.length == 5)
        this.signingUserDuplicate[findIndex[findIndex.length - 4]] = false;

      this.fieldArray.splice(this.removeIndex, 1);
      this.signingUserDuplicate.splice(this.removeIndex, 1);
      this.addSigningPeopleUserName.splice(this.removeIndex, 1);
      this.selectedSigningUserAlias.splice(this.removeIndex, 1);
      this.notifier.notify("success", "Signing partner removed successfully");
    }
  }

  getAllIndexes(array, value) {
    var indexes = [], i = -1;
    while ((i = array.indexOf(value, i + 1)) != -1) { indexes.push(i); }
    return indexes;
  }

  clearadditionalfieldseniorvalue() {
    this.selectedAdditionalFieldSeniorViewName = "";
    this.selectedAdditionalFieldSenior = undefined;
  }

  clearFieldValue(clearIndex) {
    let findIndex = this.getAllIndexes(this.selectedSigningUserAlias, this.selectedSigningUserAlias[clearIndex]);
    if (this.signingUserDuplicate[clearIndex])
      this.signingUserDuplicate[clearIndex] = false;
    else {
      if (findIndex.length == 1)
        this.signingUserDuplicate[findIndex[findIndex.length - 1]] = false;
      if (findIndex.length == 2)
        this.signingUserDuplicate[findIndex[findIndex.length - 2]] = false;
      else if (findIndex.length == 3)
        this.signingUserDuplicate[findIndex[findIndex.length - 3]] = false;
      else if (findIndex.length == 4)
        this.signingUserDuplicate[findIndex[findIndex.length - 4]] = false;
      else if (findIndex.length == 5)
        this.signingUserDuplicate[findIndex[findIndex.length - 5]] = false;
    }
    this.addSigningPeopleUserName[clearIndex] = "";
    this.selectedSigningUserAlias[clearIndex] = "";
  }
   ngOnDestroy() {
    let element = document.getElementsByClassName("cdk-overlay-container")[0];
     if(element!==null && element !== undefined && element.classList.contains('custom-cdk-peoplepicker')) {
      element.classList.remove('custom-cdk-peoplepicker');
     }
   }
}
