﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DataModels
{
    public class ResubmissionReasonModel
    {
        public int ResubmissionReasonID { get; set; }
        public string Description { get; set; }
    }
}
