import { Injectable, Output, EventEmitter } from "@angular/core";
import { Subject } from 'rxjs';

@Injectable()
export class FileUploadEventService {

  @Output() showTriggerDialog: EventEmitter<any> = new EventEmitter();
  @Output() updateUploadStatus: EventEmitter<any> = new EventEmitter();
  @Output() getfileUploadStatus: EventEmitter<any> = new EventEmitter();
  @Output() abortUpload: EventEmitter<any> = new EventEmitter();
  @Output() notifyUploadProgress: EventEmitter<any> = new EventEmitter();
  @Output() loadEmsWorkingPapers: EventEmitter<any> = new EventEmitter();
  @Output() updateEmsWorkingPapers: EventEmitter<any> = new EventEmitter();

  navigateAwaySelection$ = new Subject<boolean>();
  fileArray = [];
  fileIndex = 0;
  currentModule="";
  lstEMSFiles:any;
  guardflag:number=0;

  onShowTriggerDialog(_module: string, _fuMetaData: any) {
    this.showTriggerDialog.emit({ module: _module, fuMetaData: _fuMetaData });
  }

  
  onLoadEmsWorkingPapers(_module: string, _archiveNumber: any) {
    this.loadEmsWorkingPapers.emit({ module: _module, archiveNumber: _archiveNumber });
  }

  onupdateUploadStatus(fileArray: any) {
    this.updateUploadStatus.emit(fileArray);
  }

  ongetfileUploadStatus(fileArrayObject: any) {
    this.getfileUploadStatus.emit(fileArrayObject);
  }

  onAbortUpload(_fileName: string, _uploadId: string, _stopSpinner?: boolean) {
    this.abortUpload.emit({ fileName: _fileName, uploadId: _uploadId, stopSpinner: _stopSpinner });
  }

  onNotifyUploadProgress(showNotifier?: boolean) {
    this.notifyUploadProgress.emit(showNotifier);
  }

  onUpdateMoveEMSFileStatus(lstEMSFiles:any) {
    this.updateEmsWorkingPapers.emit(lstEMSFiles);
  }

}
