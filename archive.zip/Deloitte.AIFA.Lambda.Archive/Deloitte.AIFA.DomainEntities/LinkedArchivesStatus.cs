﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
    public class LinkedArchivesStatus
    {
        public string ladescription { get; set; }
        public string createdBy { get; set; }
    }
}
