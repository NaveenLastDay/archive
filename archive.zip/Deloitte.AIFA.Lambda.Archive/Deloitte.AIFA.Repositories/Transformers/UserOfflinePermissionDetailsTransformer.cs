﻿using System;
using System.Collections.Generic;
using System.Text;
using Deloitte.AIFA.DataModels;
using Deloitte.AIFA.DBHelper;
using System.Data;

namespace Deloitte.AIFA.Repositories.Transformers
{
    public enum UserOfflinePageDetails
    {
        userAlias,
        isEnabled,
        isPartialOutage,
        offlinePage
    }

    public enum UserOfflinePermissionsParameter
    {
        [CreateField(Name = "p_EmployeeAlias", Direction = ParameterDirection.Input, Type = DbType.String)]
        userAlias

    }
    public class UserOfflinePermissionDetailsTransformer:BaseTransformer<UserOfflinePermissionsModel>
    {
        internal override UserOfflinePermissionsModel TransformElement(IDataReader dr, Func<IDataReader, UserOfflinePermissionsModel, UserOfflinePermissionsModel> bindExtraFields = null)
        {
            var userDetails = new UserOfflinePermissionsModel
            {
                userAlias= dr[UserOfflinePageDetails.userAlias.ToString()].ToString(),
                IsEnabled=  Convert.ToInt32(dr[UserOfflinePageDetails.isEnabled.ToString()].ToString()),
                IsPartialOutage=Convert.ToBoolean(dr[UserOfflinePageDetails.isPartialOutage.ToString()]),
                OfflinePage= dr[UserOfflinePageDetails.offlinePage.ToString()].ToString()
            };
            return userDetails;
        }
    }
}
