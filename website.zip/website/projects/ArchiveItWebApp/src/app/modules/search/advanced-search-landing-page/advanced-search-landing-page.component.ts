import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ArchiveSearchService } from '../../../services/archive-search.service';
import { SearchEventService } from '../search.event.service';
import { PeoplePickerService } from '../../../services/MDREmployeeeDetails.service';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { FaceSetSearchService } from '../../../services/facesetSearch.service';
import { NotifierService } from 'angular-notifier';
import { SearchService } from '../../../services/search.service';
import { HomePageService } from '../../../services/homepage.service';
@Component({
  selector: 'app-advanced-search-landing-page',
  templateUrl: './advanced-search-landing-page.component.html',
  styleUrls: ['./advanced-search-landing-page.component.css']
})
export class AdvancedSearchLandingPageComponent implements OnInit, OnDestroy {
  login_form: FormGroup;
  customRules: Array<any> = [];
  index: number = 0;
  containers = [];
  searchText: string;
  jsonData = [];
  ArchiveNames = [];
  ArchiveNumbers = [];
  Statuses = [];
  Clients = [];
  WBSNumbers = [];
  PeriodEndDates = [];
  ArchiveMembers = [];
  userEmail: string;
  userAlias: string;
  clientData = [];
  customRuleJson = {};
  Index = [];
  showCloseIcon: boolean = false;
  enableRemoveCRule: boolean = false;
  disableSearchBtn: boolean = true;
  searchEventService : SearchEventService;

  constructor(private router: Router, private search: ArchiveSearchService,
    private searchEventSvc: SearchEventService
    , private peoplePickerService: PeoplePickerService, private adalSvc: MsAdalAngular6Service,
    private fb: FormBuilder, private faceSetSearchService: FaceSetSearchService,
    private notifier: NotifierService, private homeService: HomePageService,  private homepageSvc: HomePageService) {
    this.login_form = fb.group({
      'archivemanager': [null, Validators.required],
    });
    this.searchEventService = searchEventSvc;
  }

  ngOnInit() {
    this.searchEventService.deleteClickEvent.subscribe(index => {
      this.customRules = this.customRules.filter(i => i._index != index)
    });
    this.intialization();
    this.searchEventService.selectedFieldName = [];
    this.searchEventService.selectedFields = [];
  }
  intialization(){
    this.searchEventService.bindCustomRules = false;
    this.searchEventService.finalSelectedJson = {
      "employeeAlias": "",
      "isKeywordbaseSearch": false,
      "searchKeyword": "",
      "from": 0,
      "pageSize": 10,
      "rules": {
        "archiveNumber": [],
        "archiveName": [],
        "archiveStatus": [],
        "archiveType": [],
        "archiveTeamMembers": [],
        "archiveDescription": [],
        "business": [],
        "clientName": [],
        "entityAssociatedwithArchives": [],
        "engagementType": [],
        "periodEndDate": [],
        "standardsApplied": [],
        "WBSNumber": []
      }
    };
    this.searchEventService.finalBackupJson = {
      "archiveNumber": [],
      "archiveName": [],
      "archiveStatus": [],
      "archiveType": [],
      "archiveTeamMembers": [],
      "archiveDescription": [],
      "business": [],
      "clientName": [],
      "entityAssociatedwithArchives": [],
      "engagementType": [],
      "periodEndDate": [],
      "standardsApplied": [],
      "WBSNumber": []
    };
    this.searchEventService.facesetJson=[];
    this.searchEventService.periodEndDate="";
    this.searchEventService.periodStartDate="";
    this.searchEventService.selectedFacetsCount = 0;
    this.searchEventService.selectedFieldName = [];
    this.homeService.advanceSearchBtnDisable = true;
    this.searchEventService.enableSearch = false;
    this.searchEventService.disableSearchBtn = true;
    this.homeService.simpleSearchVisible = true;
    this.searchEventService.customRuleJson = [];
    this.searchEventService.customRuleJsondata = [];
    this.searchEventService.selectedClientsList=[];
    this.searchEventService.selectedStatusList=[];
    this.searchEventService.selectedWbsList=[];
    this.searchEventService.selectedManagerList=[];
    this.searchEventService.enableCustomRuleBtn = true;
  }
  add() {
    this.containers.push(this.containers.length);
  }
  addCustomRule() {
    if(this.searchEventService.selectedFields.length < this.customRules.length)
    {
      this.notifier.notify("error", "Please provide value(s) for search parameters");
      return;
    }
    else
    {
    this.customRules.push({ _index: this.index++ });
    this.searchText = "";
    this.showCloseIcon = false;
    this.searchEventService.enableSearch = true;
    this.enableRemoveCRule = true;
    this.searchEventService.disableSearchBtn = false;
    this.searchEventService.customRuleCount = this.customRules.length;

    if (this.customRules.length == 7) {
      this.searchEventService.enableCustomRuleBtn = false;
    }
  }
  }
  deleteCustomRule(e) {
    if (this.customRules.length == 0) {
      this.searchEventService.enableSearch = false;
      this.enableRemoveCRule = false;
      this.searchEventService.disableSearchBtn = true;

    }
  }
  removeCustomRule() {
    this.searchEventService.enableCustomRuleBtn = true;
    this.searchEventService.disableSearchBtn = true;
    this.searchEventService.selectedFields = [];
    this.index = 0;
    this.customRules = [];
    this.enableRemoveCRule = false;
    this.searchEventService.enableSearch = false;
    this.searchEventService.customRuleJson = [];
    this.customRuleJson = {};
    this.searchEventService.selectedManagerList = [];
    this.searchEventService.selectedClientsList = [];
    this.searchEventService.selectedStatusList = [];
    this.searchEventService.selectedWbsList = [];
    this.searchEventService.selectedFieldName = [];
  }
  triggerAdvanceSearch() {
    this.searchEventService.enableBindfacets=true;
    this.customRuleJson = {};
    if (this.searchText) {
      this.searchEventService.customRules = [];
      this.searchEventService.searchText = this.searchText;
      this.searchEventService.enableNotifier = false;
      // console.log(this.searchEventService.searchText);
      this.searchEventService.finalSelectedJson.employeeAlias = this.userAlias;
      this.searchEventService.finalSelectedJson.searchKeyword = this.searchText;
      this.searchEventService.finalSelectedJson.isKeywordbaseSearch = true;
      this.router.navigate(["/search/advancedsearch/archives/"]);
      this.homeService.advanceSearchBtnDisable = false;
      this.homeService.simpleSearchVisible = false;
      // console.log(this.searchEventService.finalBackupJson);
      // console.log(this.searchEventService.finalSelectedJson);
    }
    else {
      //debugger;
      var crJson = this.searchEventService.customRuleJson;
      this.Index = [];
      this.customRules.forEach(index => {
        var Indexvalue = crJson.findIndex(x => x.Index == index._index)
        this.Index.push(Indexvalue);
      });
      var notExists = this.Index.findIndex(x => x == -1);
       //To check from date and to date 
      var fromDateExists="";
      var toDateExists="";
      if(this.searchEventService.customRuleJson.filter(x=>x.FromDate).length>0)
      {
        fromDateExists=this.searchEventService.customRuleJson.filter(x=>x.FromDate)[0].FromDate;
      }
      if(this.searchEventService.customRuleJson.filter(x=>x.ToDate).length>0){
        toDateExists=this.searchEventService.customRuleJson.filter(x=>x.ToDate)[0].ToDate;
      }
      
      if((fromDateExists=="" && toDateExists) ||(fromDateExists && toDateExists=="")  ){
        this.notifier.notify("error", "Please enter the From date & To date");
        return;
      }
      
      //To check Value exists or not 
      if (notExists != -1) {
        this.notifier.notify("error", "Please provide value(s) for  search parameters");
      }
      else {
        this.clearFinalRules();
        // console.log(crJson);
        crJson.forEach(x => {
          if (x["ArchiveName"]) this.searchEventService.finalSelectedJson.rules.archiveName.push(x["ArchiveName"]);
          if (x["ArchiveNumber"]) this.searchEventService.finalSelectedJson.rules.archiveNumber.push(x["ArchiveNumber"])
          if (x["Status"]) this.searchEventService.finalSelectedJson.rules.archiveStatus.push(x["Status"])
          if (x["ClientName"]) this.searchEventService.finalSelectedJson.rules.clientName.push(x["ClientName"]);
          if (x["ManagerName"]) this.searchEventService.finalSelectedJson.rules.archiveTeamMembers.push(x["DisplayName"])
          if (x["WBS"]) this.searchEventService.finalSelectedJson.rules.WBSNumber.push(x["WBS"])
        });
        if(fromDateExists && toDateExists){
          this.searchEventService.finalSelectedJson.rules.periodEndDate.push({
            StartDate: fromDateExists,
            EndDate: toDateExists
          });
        }
        this.userEmail = this.adalSvc.LoggedInUserEmail;
        this.userAlias = this.userEmail.substring(0, this.userEmail.lastIndexOf("@"));
        this.searchEventService.finalSelectedJson.employeeAlias = this.userAlias;
        this.searchEventService.finalSelectedJson.isKeywordbaseSearch=false;
        this.searchEventService.finalSelectedJson.searchKeyword="";
        this.searchEventService.bindCustomRules = true;
        this.searchEventService.selectedManagerList = [];
        this.searchEventService.selectedClientsList = [];
        this.searchEventService.selectedStatusList = [];
        this.searchEventService.selectedWbsList = [];
        this.searchEventService.customRuleCount = 0;
        this.searchEventService.cloneFinalJson();
        // console.log(this.searchEventService.finalBackupJson);
        // console.log(this.searchEventService.finalSelectedJson);
        // this.searchEventService.customRuleJson=[];
        this.searchEventService.customRules = this.customRules;
        this.searchEventService.enableNotifier = true;
        this.router.navigate(["/search/advancedsearch/archives/"]);
        this.homeService.advanceSearchBtnDisable = false;
        this.homeService.simpleSearchVisible = false;

      }
    }


  }

  onInputChange() {
    if (this.searchText.trim().length>= 3) {
      this.searchEventService.disableSearchBtn = false;
    }
    else {
      this.searchEventService.disableSearchBtn = true;
    }
  }
  resetSearch() {
    this.searchText = "";
    this.searchEventService.disableSearchBtn = true;
    this.showCloseIcon = false;
  }
  showClose() {

    if (this.searchText.length >= 1) {
      this.showCloseIcon = true;
    }
    else {
      this.showCloseIcon = false;
    }

  }
  clearFinalRules() {
    this.searchEventService.finalSelectedJson.rules.archiveName = [];
    this.searchEventService.finalSelectedJson.rules.archiveNumber = [];
    this.searchEventService.finalSelectedJson.rules.clientName = [];
    this.searchEventService.finalSelectedJson.rules.archiveTeamMembers = [];
    this.searchEventService.finalSelectedJson.rules.archiveStatus = [];
    this.searchEventService.finalSelectedJson.rules.WBSNumber = [];
    this.searchEventService.finalSelectedJson.rules.periodEndDate = [];
  }

  ngOnDestroy(){
    this.homepageSvc.simpleSearchVisible = false;
    this.homeService.advanceSearchBtnDisable = false;
  }

}
