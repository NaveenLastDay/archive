export interface TreeNode {
    name: string;
    showChildren: boolean;
    itemtype:number;
    children: any[];
    
}