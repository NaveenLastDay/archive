﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
    public class Form3283ReasonType
    {
        public int FormId { get; set; }
        public int ReasonTypeId { get; set; }
        public string ReasonTypeDescription { get; set; }
        public bool IsSelectedBefore { get; set; }
    }
}