﻿using Deloitte.AIFA.DataModels;
using Deloitte.AIFA.DBHelper;
using System;
using System.Collections.Generic;
using System.Data;

namespace Deloitte.AIFA.Repositories.Transformers
{
    public class ActionItemResponseTransformer : BaseTransformer<ActionItemResponseModel>
    {
        internal override ActionItemResponseModel TransformElement(IDataReader dr, Func<IDataReader, ActionItemResponseModel, ActionItemResponseModel> bindExtraFields = null)
        {
            ActionItemResponseModel actionItem = new ActionItemResponseModel();
            while (dr.Read())
            {
                actionItem.IsSuccessful = Convert.ToBoolean(dr[FormOutputFields.IsSuccessful.ToString()]);
                actionItem.CompletedDate = (dr[FormOutputFields.CompletedDate.ToString()] is DBNull) ? (DateTime?)null : DateTime.Parse(dr[FormOutputFields.CompletedDate.ToString()].ToString());
                actionItem.ActionItemStatusDescription = (dr[FormOutputFields.ActionItemStatusDescription.ToString()] is DBNull) ? string.Empty : dr[FormOutputFields.ActionItemStatusDescription.ToString()].ToString();
                actionItem.ResponseMessage = (dr[FormOutputFields.ResponseMessage.ToString()] is DBNull) ? string.Empty : dr[FormOutputFields.ResponseMessage.ToString()].ToString();
            };
            return actionItem;
        }
    }
}
