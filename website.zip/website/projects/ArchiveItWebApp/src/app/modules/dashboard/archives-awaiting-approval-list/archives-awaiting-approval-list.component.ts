import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ArchiveService } from '../../../services/archive.service';
// import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-archives-awaiting-approval-list',
  templateUrl: './archives-awaiting-approval-list.component.html',
  styleUrls: ['./archives-awaiting-approval-list.component.css']
})
export class ArchivesAwaitingApprovalListComponent implements OnInit {
  archiveDetails:any;
  @Input('archiveNumber') archiveNumber : string;
  @Input('entityTypeDescription') entityTypeDescription : string;
  @Input('professionalStandardDescription') professionalStandardDescription : string;
  @Output() archiveID = new EventEmitter();
  @Input('archiveAccessRequestID') archiveAccessRequestID : string;
  @Input('estimatedIssuanceReportDate') estimatedIssuanceReportDate : any;

  constructor(private archiveService : ArchiveService) { }

  ngOnInit() {
    // this.SpinnerService.show();
    this.archiveService.GetMyArchiveDetails(this.archiveNumber).subscribe(
      data => {
        this.archiveDetails = data;
        this.archiveService.SetArchiveIdChildVal(this.archiveAccessRequestID);
        this.archiveID.emit(this.archiveAccessRequestID);
        // this.SpinnerService.hide();
      });
  }

}
