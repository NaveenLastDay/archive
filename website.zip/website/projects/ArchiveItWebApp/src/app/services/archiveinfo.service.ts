import { Injectable } from '@angular/core';
import { archiveInfo} from '../models/archive-info';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
@Injectable({
    providedIn: 'root'
  })
  export class archiveInfoService {
    //data = [];
    //api: string = 
  apiData: any;

    public restURL ='https://stg2api.archiveit.us.deloitte.com/v1/api/archive/getarchivedetailsinfo?archiveNumber=AEA500182';
    private ArchiveInfo: archiveInfo = new archiveInfo('AEA367359','This eDRMS for Audit engagement archive was crea...','Annual Audit SP-2010-12 Test','EDR0001-01','Long client name (like really)','12/28/2020','Normal','Resubmitted — Open');
    constructor(private _http: HttpClient) { }

      //getArchiveInfo():archiveInfo{ return this.ArchiveInfo;}
    //getArchiveInfo(archiveNumber:string):  Observable<any>{
    //  console.log("Archive info service: ");
    //     const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
      //   this.apiData = this._http.get<any[]>('archive/getarchivedetailsinfo?archiveNumber='+archiveNumber, httpOptions);
         //this.apiData = this._http.get<any[]>('https://devapi.archiveit.us.deloitte.com/v1/api/archive/getarchivedetailsinfo?archiveNumber='+archiveNumber, httpOptions);
      //   return this.apiData;
          //return this._http.get<any>(this.restURL, this.httpOptions);
        //                        }
    updateEDCDDate(archiveNumber:string,estimatedReleaseDate:string):Observable<any>{
      const headers = new HttpHeaders().set('Content-Type', 'application/json; charset=utf-8');
      return this._http.post('archive/UpdateEstimatedReleaseDate?ArchiveNumber=' + archiveNumber + '&EstimatedReleaseDate=' + estimatedReleaseDate, {}, { headers, responseType: 'text' });  
    }
  getArchiveInfo(archiveNumber: string, employeeUniqueIdentifier?: string,loadfromServer?:boolean, showLoader? :boolean): Observable<any> {
    console.log("Archive info service: ");
    if(showLoader == undefined){
      showLoader = true;
    }
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    var apiURL:string = 'archive/getarchivedetailsinfo?archiveNumber=' + archiveNumber + '&showLoader='+ showLoader;

    /*
    //commented this to remove User alias
    // if(employeeUniqueIdentifier != undefined)
    // {
    //   apiURL += '&employeeUniqueIdentifier=' + employeeUniqueIdentifier;
    // }
    */

    // if(loadfromServer == false){
      
    //   this.apiData = localStorage.getItem('archiveinfo');
    // }
    // if(loadfromServer == true || this.apiData == null){
      
    //   this.apiData = this._http.get<any[]>(apiURL, httpOptions);
    //   localStorage.setItem('archiveinfo',this.apiData);
    // }
    this.apiData = this._http.get<any[]>(apiURL, httpOptions);
    return this.apiData;
   }

   public getautocreatearchivedetails(archiveNumber: string): Observable<any> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    this.apiData = this._http.get<any[]>('archive/GetAutoCreateArchiveDetails?archiveNumber=' + archiveNumber, httpOptions);
    return this.apiData;
  }

   public removeEngagementPersonnel(parameters: any): Observable<any> {
     //// debugger;
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    this.apiData = this._http.post<any>("erp/removeengagementpersonnel", parameters, httpOptions);
    console.log("emgagement personnel removed", this.apiData);
    return this.apiData;
  }
}
