import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddLinkedArchivesComponent } from './add-linked-archives.component';

describe('AddLinkedArchivesComponent', () => {
  let component: AddLinkedArchivesComponent;
  let fixture: ComponentFixture<AddLinkedArchivesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddLinkedArchivesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddLinkedArchivesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
