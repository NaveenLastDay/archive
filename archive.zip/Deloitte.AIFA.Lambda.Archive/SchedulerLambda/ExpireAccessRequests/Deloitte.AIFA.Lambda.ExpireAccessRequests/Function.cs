using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;

using System.Text;
using System.Threading.Tasks;

using Amazon.Lambda.Core;


using Deloitte.AIFA.DBHelper;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;

using MySql.Data.MySqlClient;
using Newtonsoft.Json.Linq;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration.Json;
using Deloitte.AIFA.Lambda.AutoExpireTemporaryAccessRequests;
using Deloitte.AIFA.Lambda.AutoExpireTemporaryAccessRequests.Services;
using Microsoft.Extensions.DependencyInjection;





// Assembly attribute to enable the Lambda function's JSON input to be converted into a .NET class.
[assembly: LambdaSerializer(typeof(Amazon.Lambda.Serialization.Json.JsonSerializer))]

namespace Deloitte.AIFA.Lambda.AutoExpireTemporaryAccessRequests
{
    public class Function
    {

        public const string DBConnectionstring = "DBConnectionString";
        /// <summary>
        /// A simple function that takes a string and does a ToUpper
        /// </summary>
        /// <param name="input"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        public string FunctionHandler()
        {
            AutoExpireActionItems();
            return "";
        }

        public void AutoExpireActionItems()
        {

            try
            {
                var sourceType = "In Scheduled Lambda: " + System.Reflection.Assembly.GetEntryAssembly().GetName().Name;
                LambdaLogger.Log(String.Format("{0} :", LogCategory.Information.ToString()) + " :" + "Calling Auto Expiration Sp");

                var provider = new ServiceCollection()
                                    .AddMemoryCache()
                                    .BuildServiceProvider();
                var cache = provider.GetService<IMemoryCache>();
                var builders = new ConfigurationBuilder()
                                   .AddJsonFile("appsettings.json");
                var config = builders.Build();
                LambdaLogger.Log(String.Format("{0} :", LogCategory.Information.ToString()) + " :" + "Built Configuration in InsertRecordValidationFailedDetails");

                SecretsManagerService secret = new SecretsManagerService(config, cache);
                LambdaLogger.Log(String.Format("{0} :", LogCategory.Information.ToString()) + " :" + "Connection string constructed in InsertRecordValidationFailedDetails");
                var connectionString = cache.Get<string>(DBConnectionstring);
                LambdaLogger.Log(String.Format("{0} :", LogCategory.Information.ToString()) + " :" + "Read connection string in InsertRecordValidationFailedDetails");


                List<MySqlParameter> mysqlparams = new List<MySqlParameter>();

                
                MySqlCommand cmd = new MySqlCommand();

                DataAccessHelper dataobj = new DataAccessHelper(connectionString);
                Console.WriteLine("connection established");
                dataobj.ExecuteNonQuery("pub_AIA_AutoExpireTempAccessActionItems ", mysqlparams.ToArray(), true, null);
                LambdaLogger.Log(String.Format("{0} :", LogCategory.Information.ToString()) + "SP Executed successfully");
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                LambdaLogger.Log(String.Format("{0} :", LogCategory.Error.ToString()) + ": InsertRecordValidationFailedDetails exception :" + e.Message);
            }
        }
    }
}
