import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpHandler, HttpRequest, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { mergeMap, catchError } from 'rxjs/operators';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { AppConfig } from '../appconfig.service';
import { PubsubService } from '../pubsub.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { NotifierService } from 'angular-notifier';
import { throwError } from 'rxjs';

@Injectable()
export class InsertAuthTokenInterceptor implements HttpInterceptor {

    notifier: NotifierService;
    constructor(private adal: MsAdalAngular6Service, private pubsub : PubsubService, private SpinnerService : NgxSpinnerService, private config:AppConfig, private _notifier: NotifierService) {
        this.notifier = _notifier;
    }

    intercept(req: HttpRequest<any>, next: HttpHandler) {
        this.config.refrshAppSettings();
        // get api url from adal config
        const resource = this.adal.GetResourceForEndpoint(AppConfig.settings.adalConfig.endpoints.api);

        if (!resource || !this.adal.isAuthenticated) {
            //renew AD token silently
            this.adal.RenewToken(AppConfig.settings.adalConfig.endpoints.api);
            console.log("Token renewal done, iSAuthenticated : " + this.adal.isAuthenticated + " "  + Date().toString());
        }

        // merge the bearer token into the existing headers
        return this.adal.acquireToken(resource).pipe(
            mergeMap((token: string) => {
                token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6Im5PbzNaRHJPRFhFSzFqS1doWHNsSFJfS1hFZyIsImtpZCI6Im5PbzNaRHJPRFhFSzFqS1doWHNsSFJfS1hFZyJ9.eyJhdWQiOiJodHRwczovL3N0ZzJhcGkuYXJjaGl2ZWl0LnVzLmRlbG9pdHRlLmNvbSIsImlzcyI6Imh0dHBzOi8vc3RzLndpbmRvd3MubmV0LzM2ZGE0NWYxLWRkMmMtNGQxZi1hZjEzLTVhYmU0NmI5OTkyMS8iLCJpYXQiOjE2MTk2MDc0MDMsIm5iZiI6MTYxOTYwNzQwMywiZXhwIjoxNjE5NjExMzAzLCJhY3IiOiIxIiwiYWlvIjoiQVVRQXUvOFRBQUFBaWwydDZwRS9rUWVLdWpiSWJ3ayt1Zklad0xIWW1qOXg3a3NScTdRM0FNL1hJU3RacmVIL1RRUUwzVG5qQ2NoTFhMeDVjY0svRzRmTjFkOCs3ZUI4bnc9PSIsImFtciI6WyJwd2QiLCJyc2EiLCJtZmEiXSwiYXBwaWQiOiIyZTg1Nzg5MS03NGM4LTRmMjgtYmI2Yi03ODYwZDQwMGM3MWEiLCJhcHBpZGFjciI6IjAiLCJkZXZpY2VpZCI6ImE3ZjI2ZWZmLTM3NzUtNDM2My1iYWI5LTk3MmEzMjU5ZTI3NCIsImZhbWlseV9uYW1lIjoiU2VlcmFwdSIsImdpdmVuX25hbWUiOiJOYXZlZW4iLCJpcGFkZHIiOiI0OS4yMDQuMjMwLjIwNSIsIm5hbWUiOiJTZWVyYXB1LCBOYXZlZW4iLCJvaWQiOiI5NDUyOWYzYy02MjhlLTQzMjYtOTY1YS04NDZkYWE5NzU5MjMiLCJvbnByZW1fc2lkIjoiUy0xLTUtMjEtMjM4NDQ3Mjc2LTEwNDA4NjE5MjMtMTg1MDk1Mjc4OC0xODU3NjIwIiwicmgiOiIwLkFTWUE4VVhhTml6ZEgwMnZFMXEtUnJtWklaRjRoUzdJZENoUHUydDRZTlFBeHhvbUFNYy4iLCJzY3AiOiJ1c2VyX2ltcGVyc29uYXRpb24iLCJzdWIiOiJEMGU0SVExZU5uc3lzMFNDQ2RxVEpiZVp2dlVoRE9QRk9PQk5ZeWt0c0h3IiwidGlkIjoiMzZkYTQ1ZjEtZGQyYy00ZDFmLWFmMTMtNWFiZTQ2Yjk5OTIxIiwidW5pcXVlX25hbWUiOiJuc2VlcmFwdUBkZWxvaXR0ZS5jb20iLCJ1cG4iOiJuc2VlcmFwdUBkZWxvaXR0ZS5jb20iLCJ1dGkiOiJGeEtNbElRUWwwNkdPNDZ2ZGZ6aUFBIiwidmVyIjoiMS4wIn0.Tp2f5a1y1AdNjOp5CDsoGfi7Eu5bJ6bZjsrvW09zf04scectnK0YsdV69GLE9vL4hRGTIWoxGSmZwSoZEMaEcxQ4Qji9nlwobamuHZM0Asp3KjHxZMbJr_Jj9VCq0-xBxcS_gcU6a1eLSKKUUtD_yEdNNv9oxpa93lVZO1xs37mkZgBGpjWWHI0TTJAL6sGkcGwUfzm44JCCDH6JuMfyhUhMTUBoUHJycC0G-bIhPJufWPzPD1HZbtn3OMsz1NKH_wibMpTHdfDh8Y6zEi4VeZPpYP0O9Ou1gsI50ofBxYPjAU-r9HodtyUedDT3f34vKXcpLhBCisueZBDza45iaA";
                sessionStorage.setItem("adalToken", token);
                var authorizedRequest;
                if (req.url.indexOf('localhost') >= 0 || req.url.indexOf('X-Amz-Security-Token') >= 0 || req.url.indexOf('x-amz-security-token') >= 0) {
                    authorizedRequest = req.clone({
                        url: `${req.url}`
                    });
                }else 
                {
                    authorizedRequest = req.clone({
                        headers: req.headers.set('Authorization', `Bearer ${token}`).set('Content-Type', 'application/json'),
                        url: `${AppConfig.settings.endpoints.apigatewayurl}/${req.url}`
                    });

                }

                // const headers = new HttpHeaders({
                //     'Authorization': `Bearer ${token}`,
                //     'Content-Type': 'application/json'
                //   });

                // const authorizedRequest = req.clone({headers});
                return next.handle(authorizedRequest).pipe(catchError(error => {

                    this.handlehttpException(error);
                    throw error;
                }));

            }), 
            catchError((error: HttpErrorResponse) => {
                if(JSON.stringify(error) === '"Token renewal operation failed due to timeout"')
                {
                    this.adal.login();
                }; return throwError(error);}));
    }

    handlehttpException(error: any) {
        this.SpinnerService.hide();
        console.log("Error while calling API");
        console.log(error.error.CorrelationId);
        if (error.error && error.error.CorrelationId) {
            console.log("CorrelationId: " + error.error.CorrelationId.replace('Root','').replace('=','').replaceAll('-',''));
           /* this.notifier.notify(
                "error", "Error: " + error.error.CorrelationId.replace('Root','').replace('=','').replaceAll('-','')
            );*/
            this.notifier.notify(
                "error", "Something went wrong, Please try again"
            );
        }
        else {
            return "";
        }
    }
}
