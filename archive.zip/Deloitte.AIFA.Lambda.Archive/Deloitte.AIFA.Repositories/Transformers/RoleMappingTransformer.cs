﻿using Deloitte.AIFA.DataModels;
using Deloitte.AIFA.DBHelper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace Deloitte.AIFA.Repositories.Transformers
{
    public enum RoleMappingField
    {
        RoleId,
        RoleName,
        FunctionName        
    }

    public enum UserRoleMappingParameter
    {
        [CreateField(Name = "EmployeeAlias_In", Direction = ParameterDirection.Input, Type = DbType.String)]
        userAlias,
        [CreateField(Name = "ArchiveNumber_In", Direction = ParameterDirection.Input, Type = DbType.String)]
        archiveNumber,

    }
    public class RoleMappingTransformer : BaseTransformer<RoleMappingModel>
    {
        internal override RoleMappingModel TransformElement(IDataReader dr, Func<IDataReader, RoleMappingModel, RoleMappingModel> bindExtraFields = null)
        {
            RoleMappingModel roleMapping = new RoleMappingModel();

            roleMapping.RoleId = Convert.ToInt32(dr[RoleMappingField.RoleId.ToString()].ToString());
            roleMapping.RoleDescription = (dr[RoleMappingField.RoleName.ToString()].ToString());
            List<string> UserActions = new List<string>();
            if (dr.NextResult())
            {
                while (dr.Read())
                {
                    var userAction = dr[RoleMappingField.FunctionName.ToString()].ToString();
                    UserActions.Add(userAction);
                };
            }
            roleMapping.ArchivePermissions = UserActions;
            return roleMapping;

        }



    }


}

