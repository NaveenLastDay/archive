import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ComplianceMetricsComponent } from './compliance-metrics.component';

describe('ComplianceMetricsComponent', () => {
  let component: ComplianceMetricsComponent;
  let fixture: ComponentFixture<ComplianceMetricsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ComplianceMetricsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ComplianceMetricsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
