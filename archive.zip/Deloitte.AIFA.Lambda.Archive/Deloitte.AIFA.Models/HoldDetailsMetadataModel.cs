﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.Models
{
    public class HoldDetailsMetadataModel
    {
        public string HoldNumber { get; set; }
        public string ClientName { get; set; }
        public string BusinessName { get; set; }
        public DateTime? EffectiveStartDate { get; set; }
        public DateTime? EffectiveEndDate { get; set; }
        public int HoldStatus { get; set; }
        public int ArchivesCount { get; set; }
        public List<HoldsDetailModel> lstholdsDetails { get; set; }
    }
}
