﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
    public class MyPendingSubmissionData
    {
        public string ArchiveNumber { get; set; }

        public string ClientName { get; set; }

        public string EngagementDescription { get; set; }

        public string PeriodEndDate { get; set; }

        public string WBSLevelOneNumber { get; set; }

        public string EstimatedIssuanceReportDate { get; set; }

        public string ArchiveStatus { get; set; }

        public string EngagementTypeDescription { get; set; }


        public string ArchiveDueDate { get; set; }

        public string IsResubmissionInProgress { get; set; }

        public string Description { get; set; }

        public string EntityTypeDescription { get; set; }

        public string ProfessionalStandardDescription { get; set; }

        public string ReportingEntity { get; set; }

        public string ArchivePartner { get; set; }

        public string ArchiveManager { get; set; }
        public string ArchiveFieldSenior { get; set; }

        public string AddArchiveFieldSenior { get; set; }
        public int IsArchiveCompleted { get; set; }


        public string Due { get; set; }
        public int RowNumber { get; set; }
        public int Count { get; set; }

        public int CountOrange { get; set; }
        public int CountRed { get; set; }
        public int CountYellow { get; set; }

    }
}
