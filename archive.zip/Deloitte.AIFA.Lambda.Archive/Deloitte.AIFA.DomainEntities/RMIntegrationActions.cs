﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
    public class RMIntegrationActions
    {
        public string ArchiveNumber { get; set; } 
        public int BinderID { get; set; }
        public string RequestedBy { get; set; }
        public int RequestTypeID { get; set; }
        public bool IsBinderOrDeliverable { get; set; }
    }
}
