import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable } from 'rxjs';
import { LoginuserdetailsService } from './loginuserdetails.service';
import { String } from 'aws-sdk/clients/acm';
import { PubsubService } from './pubsub.service';

@Injectable({
  providedIn: 'root'
})
export class Form3283SService {
  apiData: any;
  FormStatusinfo: any;
  FormStatus: any;
  FormStatusDate: any;

  constructor(private _http: HttpClient,private loginuserdetailsservice:LoginuserdetailsService
    ,private pubsub : PubsubService) { }
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  }

  public GetPrepopulatedFormInfo(ArchiveNumber:string,UserAlias:string):Observable<any>
  {
    this.apiData = this._http.get<any[]>('form/getprepopulateddata?archiveNumber='+ArchiveNumber);
    return this.apiData;
  }

  public SubmitForm3283S(parameters :any):Observable<any>
  {
    this.apiData = this._http.post<any[]>('form/submit',parameters);
    return this.apiData;
  }

  public ApproveForm3283(parameters:any):Observable<any>{
    this.apiData = this._http.post<any[]>('form/approve',parameters);
    return this.apiData;
  }

  public RejectForm3283(parameters:any):Observable<any>{
    this.apiData = this._http.post<any[]>('form/reject',parameters);
    return this.apiData;
  }

  public ChangePICPPD(parameters:any):Observable<any>{
    this.apiData = this._http.post<any[]>('form/changeapprover',parameters);
    return this.apiData;
  }

}
