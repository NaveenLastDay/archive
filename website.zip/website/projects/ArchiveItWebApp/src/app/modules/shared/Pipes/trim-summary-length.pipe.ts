import { Pipe, PipeTransform } from '@angular/core';

/*
 * Trims the description to supplied length.
 * Takes an argument of length.
 * Usage:
 *   value | trimmedDescription:length
 * Example:
 *   {{ 'Descriptionnnnnnnnnnnnnnn' | trimmedDescription:5 }}
 *   formats to: Descr..
*/

@Pipe({
    name: 'trimSummaryLength',
})
export class TrimSummaryLengthPipe implements PipeTransform {

    transform(value: string, limit?: number) {

        if (!value) {
            return null;
        }

        let actualLimit = (limit) ? limit : 50;

        if(value.length <= actualLimit){
            return value.substring(0, actualLimit)
        }
        else{
            return value.substring(0, actualLimit) + '...';
        }        
    }
}