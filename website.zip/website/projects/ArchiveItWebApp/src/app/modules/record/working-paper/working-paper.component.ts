import { Router, ActivatedRoute, Params } from "@angular/router";
import { Component, OnDestroy, OnInit } from "@angular/core";
import { ModalService } from "../../shared/modal";
import { NotifierService } from "angular-notifier";
import { WorkingPaperService } from "../../../services/working-paper.service";
import { NgxSpinnerService } from "ngx-spinner";
import { FileUploadEventService } from "../file-upload/fileupload.event.service";
import { FileUploadProcessService } from "../file-upload/fileupload.process.service";
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { ArchiveHomeService } from '../../../services/archive-home.service';
import { AngularEditorConfig } from '@kolkov/angular-editor';
import { archiveInfoService } from '../../../services/archiveinfo.service'
import { FielUploadService } from '../../../services/fileupload.service';
import { UserConfigSettingService } from '../../../guards/user-role-guard.service';
import { UserActions } from '../../../models/archive-role.model';
import { PubsubService } from '../../../services/pubsub.service';
import { SharedService } from '../../../services/shared.service';
import { TreeNode } from '../../shared/tree/tree-node';
import * as converter from 'xml-js';
import { BulkdownloadEventService } from '../bulk-download/bulkdownload.event.service';
//import { RoundProgressModule } from 'ng-circle-progress'

@Component({
  selector: "app-working-paper",
  templateUrl: "./working-paper.component.html",
  styleUrls: ["./working-paper.component.css"]
})
export class WorkingPaperComponent implements OnInit, OnDestroy {
  showMarorDelete:boolean=true;
  chunkSize = 10 * 1024 * 1024;
  lastUploadedFileName: string;
  isUploaded: boolean = true;
  isDownloaded: boolean = false;
  isArchiveDestroyed:number = 0;
  timeout = 3600;
  bucketName = "s3-bulk-files-upload";
  percentage = 0;
  uploadTime = "00:00";
  message = "";
  fileStatus = true;
  fileSize = "0";
  fileName = "";
  notifier: NotifierService;
  fileTypes: any = [];
  archiveNumber = "";
  selectedFileTypeId: number = 0;
  selectedFileTypeDescription: string = "";
  selectedFileMIMETypes: string = "";
  service: WorkingPaperService;
  isLoaded = false;
  workingPapers: any = [];
  IsSectionVisited: any;
  isInputElementActive: Boolean = false;
  displayArray = [];
  verificationInProgressStatus = [0, 1, 2, 5];
  fileNameToBeDeleted: string = "";
  fileNameToBeInActivated: string = "";
  s3fileNameToBeDeleted: string = "";
  archiveFileIdToBeDeleted: string = "";
  archiveFileIdToBeInActivated: string = "";
  fileTypeIdToBeDeleted: number = 0;
  emsFileIdToBeDeleted: string = "";
  fileTransferIdToBeDeleted: number = 0;
  employeeUniqueIdentifier: string = "";
  failedStatus = [4, 7, 8, 9, 10, 11, 15, 27, 28];
  DisplayReason: string = '';
  commentCategoryId: number = 2;
  employeeRoleId: number = 15; // admin role ID is 15
  verifiedWorkingPapers: any = [];
  unverifiedWorkingPapers: any = [];
  sectionid: number = 2;
  rejectionDiscrption: any;
  rejectionComments: any='';
  rejectionBy: any;
  rejectionTimeStamp: any;
  BodyCount: number = 0;
  wordCount: number = 0;
  userAlias = this.adalSvc.LoggedInUserEmail.substring(0, this.adalSvc.LoggedInUserEmail.lastIndexOf("@"));
  personnelNumber: number = 0;
  success: any;
  commentsData: any;
  isSectionApproved: boolean = false;
  isFirstlvlApproved: string = 'Change';
  IsButtonDisabled = true;
  WPEditedInResubmit: boolean;
  WPProvidedInResubmit: string = '';
  WPEditedDate: Date;
  canApprove = false;
  IsWorkingPaper = false;
  IsNoWorkingPaperWithReason = false;
  RejectedDateStamp = "";
  IsRejectedBy: boolean = false;
  IsRejectedByWithWP: boolean = false;
  IsRejectedByWithoutWP: boolean = false;
  IsChangeDecisionWithWP: boolean = false;
  IsChangeDecision: boolean = false;
  IsShowIfWorkingPapersExists: boolean = false;
  IsShowIfSubstantiationCommentsExists: boolean = false;
  IsChangeDecissionClicked: boolean = false;

  CurrentArchiveStatusForWorkingPapers: any;
  ShowContentForEditforWP: number;
  DisableWPSelectCheckboxes: boolean;

  isApproved: boolean = false;
  isReject: boolean = false;
  isDefaultState: boolean = false;

  dataToVerifyArchivePackage: any = [];
  roleArray: any = [];

  buttonToEnable: string = '';
  buttonToEnablePosition: any;
  IsFailedFile: any;

  // private properties
  private _havefilesBeenLoaded: boolean = false;
  private _haveCommentsforSectionBeenLoaded: boolean = false;
  private _hasArchiveStatusBeenChecked: boolean = false;
  private _hasUserRoleBeenChecked: boolean = false;
  userConfig: any;
  totalWorkingPapers: number = 0;
  readonly pageSize: number = 10;
  appendWPtoGrid: boolean = false;
  currentPageNumber: number = 1;
  OmniaEngagementID: string = '';

  roleMapping = new UserActions();
  workingPapersResultGridColumns: any = WorkingPapersResultGridColumns;
  readonly emptyStringInReport: string = " ";
  wpIntervalId: any;
  show: boolean = true;
  NODES: TreeNode[] = [];
  nodearray: TreeNode[] = [];
  objectKeys = Object.keys;
  counter: number = 0;
  placeholder: string = "-";
  PeriodEndDate: string = "";
  passwordvalue: string = "";

  bulkDownloadSelectedFiles = [];
  bulkDownloadIntervalId: any;
  bulkdownloadId = null;
  selectedAll = false;
  selectedWorkingPapers = [];
  zipFileName: string = '';

  legalHoldStatus: string;
  DisableWPSelectallCheckbox: boolean;
  currentModule: any;

  columnFilters: any[] =
    [
      {
        "displayName": "ArchiveFileId#",
        "value": this.workingPapersResultGridColumns.ArchiveFileId,
        "checked": true
      },
      {
        "displayName": "FileName#",
        "value": this.workingPapersResultGridColumns.FileName,
        "checked": true
      },
      {
        "displayName": "FileSize#",
        "value": this.workingPapersResultGridColumns.FileSize,
        "checked": true
      },
      {
        "displayName": "IsActive#",
        "value": this.workingPapersResultGridColumns.IsActive,
        "checked": true
      },
      {
        "displayName": "FileTypeId#",
        "value": this.workingPapersResultGridColumns.FileTypeId,
        "checked": true
      },
      {
        "displayName": "FileTransferId#",
        "value": this.workingPapersResultGridColumns.FileTransferId,
        "checked": true
      },
      {
        "displayName": "S3FileName#",
        "value": this.workingPapersResultGridColumns.S3FileName,
        "checked": true
      },
      {
        "displayName": "FileTypeDescription#",
        "value": this.workingPapersResultGridColumns.FileTypeDescription,
        "checked": true
      },
      {
        "displayName": "BypassIntegrityCheck#",
        "value": this.workingPapersResultGridColumns.BypassIntegrityCheck,
        "checked": true
      },
      {
        "displayName": "CreatedBy#",
        "value": this.workingPapersResultGridColumns.CreatedBy,
        "checked": true
      },
      {
        "displayName": "CreatedByFullName#",
        "value": this.workingPapersResultGridColumns.CreatedByFullName,
        "checked": true
      },
      {
        "displayName": "CreatedDate#",
        "value": this.workingPapersResultGridColumns.CreatedDate,
        "checked": true
      },
      {
        "displayName": "SubmissionPackageID#",
        "value": this.workingPapersResultGridColumns.SubmissionPackageID,
        "checked": true
      },
      {
        "displayName": "FileVerificationStatusId#",
        "value": this.workingPapersResultGridColumns.FileVerificationStatusId,
        "checked": true
      },
      {
        "displayName": "FileVerificationStatus#",
        "value": this.workingPapersResultGridColumns.FileVerificationStatus,
        "checked": true
      },
      {
        "displayName": "FailedDescription#",
        "value": this.workingPapersResultGridColumns.FailedDescription,
        "checked": true
      },
      {
        "displayName": "EmsFileId#",
        "value": this.workingPapersResultGridColumns.EmsFileId,
        "checked": true
      },
      {
        "displayName": "TransferFinishDate#",
        "value": this.workingPapersResultGridColumns.TransferFinishDate,
        "checked": true
      }

    ]
  pendingOmniaData: string;
  IsAdmin: Boolean;
  isPendingOmnia: boolean = false;


  // constructor
  constructor(
    private pubsub: PubsubService,
    private router: Router,
    private modalService: ModalService,
    private _fuService: FielUploadService,
    private _notifier: NotifierService,
    private _service: WorkingPaperService,
    private activatedRoute: ActivatedRoute,
    private SpinnerService: NgxSpinnerService,
    private _uploadEventService: FileUploadEventService,
    private _bdownloadEventService: BulkdownloadEventService,
    private adalSvc: MsAdalAngular6Service,
    private archiveHomeService: ArchiveHomeService,
    private archiveInfoService: archiveInfoService,
    private sharedService: SharedService,
    private _userConfig: UserConfigSettingService
  ) {
    this.notifier = _notifier;
    this.service = _service;
    this.roleMapping = this.pubsub.getRoleMappingResult();
  }
  /*text editor config*/

  editorConfig: AngularEditorConfig = {

    editable: true,
    spellcheck: true,
    height: 'auto',
    minHeight: '120',
    maxHeight: 'auto',
    width: 'auto',
    minWidth: '0',
    translate: 'yes',
    enableToolbar: true,
    showToolbar: true,
    placeholder: 'Please enter the reason',
    defaultParagraphSeparator: '',
    defaultFontName: '',
    defaultFontSize: '',
    fonts: [
      { class: 'arial', name: 'Arial' },
      { class: 'times-new-roman', name: 'Times New Roman' },
      { class: 'calibri', name: 'Calibri' },
      { class: 'comic-sans-ms', name: 'Comic Sans MS' }
    ],

    customClasses: [
      {
        name: 'quote',
        class: 'quote',
      },
      {
        name: 'redText',
        class: 'redText'
      },
      {
        name: 'titleText',
        class: 'titleText',
        tag: 'h1',
      },
    ],
    uploadUrl: '',
    uploadWithCredentials: false,
    sanitize: true,
    toolbarPosition: 'top',
    toolbarHiddenButtons: [
      [
        'undo',
        'redo',
        'subscript',
        'superscript',
        'justifyFull',
        'indent',
        'outdent',
        'insertOrderedList',
        'heading',
        //'fontName'
      ],
      [
        'textColor',
        'backgroundColor',
        'customClasses',
        'link',
        'unlink',
        'insertImage',
        'insertVideo',
        'insertHorizontalRule',
        'removeFormat',
        'toggleEditorMode'
      ]
    ]
  };
  ngOnInit() {
    var self = this;
    this._uploadEventService.currentModule = "workingpaper";    
    this.employeeUniqueIdentifier = this.adalSvc.LoggedInUserEmail.split('@')[0];
    this.archiveNumber = this.activatedRoute.snapshot.paramMap.get("aN");
    console.log(this.activatedRoute.snapshot.params.aN);
    this.GetFileTypes();

    localStorage['IsSectionVisited'] = '0';
    console.log("LocalStorage ReSet to 0 in WP for aR (688):", localStorage['IsSectionVisited']);

    //update working papers for every 30 secs
    self.GetWorkingPapersforArchive(self.archiveNumber);
    self.wpIntervalId = setInterval(function () {
      let showLoader = false;
      self.GetWorkingPapersforArchive(self.archiveNumber, showLoader);
    }, 60000);

    //debugger;
    this.userConfig = this._userConfig.FetchLoggedInUser(this.userAlias);
    this.personnelNumber = this.userConfig.value.employeePersonnelNumber;
    this.IsAdmin = this.userConfig.value.isAdmin;
    this._hasUserRoleBeenChecked = true;

    this.currentModule="workingpaper";
    //================================= Start: File Upload ===========================

    //FileUploadStep 12:
    //Update the uploaded status in DB and refresh the working papers list
    this._uploadEventService.getfileUploadStatus.subscribe(fileArrayObject => {

      if(fileArrayObject.module!=self.currentModule)
      return;
      if (fileArrayObject) {

        let etag = "";

        if (fileArrayObject.eTag) {
          etag = fileArrayObject.eTag.substr(1, fileArrayObject.eTag.length - 2);
        }

        let fuparams = {
          ArchiveFileId: fileArrayObject.metaData.ArchiveFileId,
          FileTransferId: fileArrayObject.metaData.FileTransferId,
          FileUploadStatusCode: fileArrayObject.uploadStatus,
          ETag: etag,
          UploadId: fileArrayObject.uploadId,
          FailedDescription: fileArrayObject.errorMessage,
          ArchiveNumber: this.archiveNumber
        };

        console.log("updating in DB");
        console.log(fuparams);

        self.service.CreateOrUpdateWorkingPaper(fuparams).subscribe(response => {

          console.log("updated in DB");
          console.log(response);

          if (!self.bulkdownloadId) {
           // self.SpinnerService.hide();
          }

          //Update the working papers upload files list on file upload success
          if (fileArrayObject.uploadStatus == "success") {

            self.service.GetWorkingPapersByArchiveFileId(response.archiveFileId, this.archiveNumber).subscribe(data => {

              let dataLength = data.length;
              if (this.verificationInProgressStatus.includes(data.fileVerificationStatusId)) {
                let unverifiedWorkingPapers = this.unverifiedWorkingPapers;
                this.unverifiedWorkingPapers.unshift(data);
                for (var i = dataLength; i < this.unverifiedWorkingPapers.length; i++) {
                  this.unverifiedWorkingPapers[i] = unverifiedWorkingPapers[i].chkSelect;
                }
              }
              else {
                let verifiedWorkingPapers = this.verifiedWorkingPapers;
                this.verifiedWorkingPapers.unshift(data);
                for (var i = dataLength; i < this.verifiedWorkingPapers.length; i++) {
                  this.verifiedWorkingPapers[i] = verifiedWorkingPapers[i].chkSelect;
                }
              }

            },
              err => {
               // self.SpinnerService.hide();
                console.log("failed to refresh working papers");
              }

            );
          }

        },
          err => {
           // self.SpinnerService.hide();
            console.log("failed to update in working papers DB");
            console.log(err);
          });
      }
    });

     /*this._uploadEventService.updateEmsWorkingPapers.subscribe(emsFileDetails => {

      let emsData =
      {
        "name": "emsFileDetails",
        "eMSPackagesDetails": emsFileDetails,
      };
      console.log("ems Data", emsData);

      self.service.MoveAssociatedEMSPackges(this.archiveNumber, this.userAlias, emsData).subscribe(
        (data) => {
          self.GetWorkingPapersforArchive(this.archiveNumber);
        }
      );
    })*/

    this._uploadEventService.loadEmsWorkingPapers.subscribe(data => {
      //debugger;
      self.GetWorkingPapersforArchive(data.archiveNumber);

    });
    //================================ End: File Upload ==========================================

    /* For Legal Hold applied on Archives */
    if(localStorage.getItem('archiveInfoData') !=''){
    var data = JSON.parse(localStorage.getItem('archiveInfoData'));
    localStorage.setItem('archiveInfoData', JSON.stringify(data));
    this.legalHoldStatus = data.legalHoldStatus;
    this.isArchiveDestroyed = data.isDestroyed;
  }else{
    this.archiveInfoService.getArchiveInfo(this.archiveNumber, this.employeeUniqueIdentifier).subscribe(
      (info) => {
        localStorage.setItem('archiveInfoData', JSON.stringify(info));
        this.legalHoldStatus = info.legalHoldStatus;
        this.isArchiveDestroyed = info.isDestroyed;
        this.HideorShowlogic();
    });
  }
    /* For Legal Hold applied on Archives */
    this.Getsectioncomments(this.archiveNumber, this.sectionid, 2);
    this.GetArchiveStatus();
    this._service.Getpendingomniaengagements(this.archiveNumber).subscribe((data) => {
      this.pendingOmniaData = data;
      if(data && data.length > 0) {
        this.isPendingOmnia = true;
      } else {
        this.isPendingOmnia = false;
      }
    })

  }

  ngOnDestroy() {
    clearInterval(this.wpIntervalId);
  }

  ngDoCheck() {
    this.roleMapping = this.pubsub.getRoleMappingResult();
  }
  getFlagsUpdate() {
    //debugger;
    //State : Default, isSectionApproved = 0, comments = ""
    if (!this.isSectionApproved && this.rejectionComments == '') {
      this.isReject = false;
      this.isApproved = false;
      this.isDefaultState = true;
    }

    //State : Rejected, isSectionApproved = 0, comments = "hello"
    if (!this.isSectionApproved && this.rejectionComments != '') {
      this.isApproved = false;
      this.isReject = true; //
      this.IsButtonDisabled = true;
    }

    //State : Approved, isSectionApproved = 1
    if (this.isSectionApproved) {
      this.isReject = false;
      this.isApproved = true; //
      this.IsButtonDisabled = true;
    }

    // if Default State allow user to approve/reject
    if (this.isDefaultState) {
      this.IsButtonDisabled = false;
    }

    // Reject By
    //Removing CanApprove to show the Rejected status to Archive Team also
    // this.IsRejectedBy = this.canApprove && this.isReject;
    this.IsRejectedBy = this.isReject;
    this.IsRejectedByWithWP = this.IsRejectedBy && this.IsWorkingPaper;
    this.IsRejectedByWithoutWP = this.IsRejectedBy && this.DisplayReason != '';

    console.log("==========*****============");
    console.log("isDefaultState: " + this.isDefaultState);
    console.log("isApproved: " + this.isApproved);
    console.log("isReject: " + this.isReject);
    console.log("other details: ");
    console.log(" >> canApprove: " + this.canApprove);
    console.log(" >> isSectionApproved: " + this.isSectionApproved);
    console.log(" >> rejectionComments: " + this.rejectionComments);
    console.log(" >> IsWorkingPaper: " + this.IsWorkingPaper);
    console.log(" >> No Working Paper Comments: " + this.DisplayReason);
    console.log(" >> Is Rejected >> With WP: " + this.IsRejectedByWithWP);
    console.log(" >> Is Rejected >> Without WP: " + this.IsRejectedByWithoutWP);

    console.log("===========================");
  }

  //=============================== Start: File Upload ======================================

  //FileUploadStep 1:
  //This Event is triggered on selecting file type and triggers 'showTriggerDialog'
  //This event will open file upload popup
  selectFileType(fileType: any) {
    var fuMetaData = {
      archiveNumber: this.archiveNumber,
      CreatedBy: this.employeeUniqueIdentifier,
      fileTypeId: fileType.fileTypeId,
      fileTypeDescription: fileType.fileTypeDescription,
      acceptedMIMETypes: fileType.acceptedMIMETypes,
      employeePersonnelNumber: this.personnelNumber,
      currentArchiveStatus: this.CurrentArchiveStatusForWorkingPapers
    };

    this._uploadEventService.onShowTriggerDialog("workingpaper", fuMetaData);

  }

  //====================================End: File Upload =======================================

  OnClick(PageUrl) {
    if(PageUrl.type != 'click')
    this.router.navigate(["/" + PageUrl + ""]);
  }
  
  changetWorkingPapers() {
    this.modalService.openWithCustomWidth('reject-workingpaper-modal', "500");
  }

  changetDecision() {
    this.IsChangeDecissionClicked = true;
    this.IsButtonDisabled = false;
  }

  rejectWorkingPapers() {
    this.modalService.openWithCustomWidth('reject-workingpaper-modal', "500");
  }
  rejectWorkingPaperRedirect() {
    console.log('approveWorkingPapers==');
    if (!this.IsChangeDecissionClicked) {
      localStorage['IsSectionVisited'] = '1';
      console.log("LocalStorage Set to 1 in WP for AR (560):", localStorage['IsSectionVisited']);
    }
    setTimeout(() => { this.router.navigate(["/archive/myarchives/" + this.archiveNumber + "/archivehome"]) }, 1000);
  }
  approveWorkingPapers() {
    console.log('approveWorkingPapers==');
    if (!this.IsChangeDecissionClicked) {
      localStorage['IsSectionVisited'] = '1';
      console.log("LocalStorage Set to 1 in WP for AR (566):", localStorage['IsSectionVisited']);
    }
 }

  stripHtml(html: string) {
    // Create a new div element
    var temporalDivElement = document.createElement("div");
    // Set the HTML content with the providen
    temporalDivElement.innerHTML = html;
    // Retrieve the text property of the element (cross-browser support)
    return temporalDivElement.textContent || temporalDivElement.innerText || "";
  }


  onKeyUpBody(boxInput) {
    this.wordCount = this.stripHtml(boxInput).length;
    this.BodyCount = 250 - this.wordCount;
    this.rejectionDiscrption = boxInput;
    console.log(this.wordCount);
  }
  closeModalDialog(Action) {
    this.modalService.close(Action);
  }
  OnApproveOrRejection(ActionType) {
   // this.SpinnerService.show();
    debugger;
    var parameters =
    {
      "ArchiveNumber": this.archiveNumber,
      "ArchiveSectionId": this.sectionid,
      "ActionTypeId": ActionType,
      "Comments": this.rejectionDiscrption,
      "CreatedBy": ''
    }
    var myobjstr = JSON.stringify(parameters);
    this.archiveHomeService.OnApproveOrRejection(myobjstr)
      .subscribe(
        data => {
          this.success = data;
          localStorage['IsSectionVisited'] = '1';
          console.log("LocalStorage Set to 1 in WP for AR (608):", localStorage['IsSectionVisited']);
          this.getFlagsUpdate();
          console.log(this.success);
          this.router.navigate(["/archive/myarchives/" + this.archiveNumber + "/archivehome"]);
        }
      );
  //  this.SpinnerService.hide();
  }

  /*Commenting this method as we're showing the reasons popup on add button
   NavigateShowReasonsPopup()
   {
     if(this.CurrentArchiveStatusForWorkingPapers == "Resubmitted – Open" || this.CurrentArchiveStatusForWorkingPapers == "Resubmitted - Ready for Approval")
     {
       this.archiveHomeService.GetResubmissionReasonsforArchive(this.archiveNumber).subscribe(data=>{
         debugger;
         if(data){
          if(data.length>0)
          {
           this.WPEditedInResubmit=data[1].actionTypeId==3?true:false;
           this.WPProvidedInResubmit=data[1].comments!=""?data[1].comments:"";
           if(this.WPEditedInResubmit==true && this.WPProvidedInResubmit=='')
           {
             this.modalService.openWithCustomWidth("SaveChanges-AdministrativeResubmission-Modal", "544");
           }
           else{
             this.router.navigate(['/archive/myarchives/' + this.archiveNumber + '/archivehome']);
           }
         }
        }
       });
       //if(localStorage['ArefilesAddedinWP']==1)
       //{
       //this.modalService.openWithCustomWidth("SaveChanges-AdministrativeResubmission-Modal", "544");
       //}
     }
     else{
       this.router.navigate(["/archive/myarchives/" + this.archiveNumber + "/archivehome"]);
     }
   }*/
  Navigatetohomepage() {
    this.router.navigate(["/archive/myarchives/" + this.archiveNumber + "/archivehome"]);
  }

  GetArchiveStatus() {
    //debugger;
  //  this.SpinnerService.show();
    console.log('GetArchiveStatus====');
    //this.SpinnerService.show();
    var data = JSON.parse(localStorage.getItem('archiveSubmissionStatusData'));
    console.log('workingpaperarchiveSubmissionStatusData', data);
    // this.archiveHomeService.GetArchiveStatus(this.archiveNumber, this.userAlias).subscribe(data => {
    if (data) {
      //debugger;
      this.canApprove = data.canApprove;
      console.log(data);
      this.CurrentArchiveStatusForWorkingPapers = data.archiveInfo.archiveStatus;
      this.getFlagsUpdate();
      this.HideorShowlogic();
      //this.isLoaded = true;

      this._hasArchiveStatusBeenChecked = true;
      this.hideSpinner();
    }
    // },
    // err => {
    //   console.log('error:GetArchiveStatus');
    //   this.SpinnerService.hide();
    // });
  }

  //Centric logic to Hide or show
  HideorShowlogic() {
    var archiveStatusHome: string = this.CurrentArchiveStatusForWorkingPapers;
    switch (archiveStatusHome) {
      case 'Ready For Approval': {
        this.archiveHomeService.GetArchiveApproverForArchiveSubmission(this.archiveNumber, this.roleMapping.roleId).subscribe(data => {
          if (data) {
            console.log('GetArchiveApproverForArchiveSubmission-Working Papers', data.canApprove);
            this.canApprove = data.canApprove;
          }
          if (this.canApprove) {
            this.commonViewForEdit();
          }
          else {
            this.showMarorDelete=false;
            this.commonViewForReadonly();
          }
        });
        break;
      }
      case "Resubmitted - Ready for Approval": {
        debugger;
        this.GetResubmissionApprovalFlow();

        break;
      }

      /* common for Open, Resubmitted – Open*/
      case 'Open': {
        this.commonViewForEdit();
        break;
      }
      case "Resubmitted – Open": {
        this.commonViewForEdit();
        this.archiveHomeService.GetResubmissionReasonsforArchive(this.archiveNumber).subscribe(data => {
          debugger;
          if (data) {
            if (data.length > 0) {
              this.WPEditedInResubmit = data[1].actionTypeId == 3 ? true : false;
              this.WPProvidedInResubmit = data[1].comments != "" ? data[1].comments : "";
              this.WPEditedDate = data[1].rejectedDate;
            }
          }
        });
        break;
      }
      /*End common for Open, Resubmitted – Open*/

      /*Common for Approved, Resubmitted – Approved and Resubmitted - Rejected */
      case "Approved": {
        this.legalHoldStatus = '';
        this.commonViewForReadonly();
        this.checkBoxForApproved();
        break;
      }
      case "Resubmitted – Approved": {
        this.legalHoldStatus = '';
        this.commonViewForReadonly();
        this.isReject = false;
        this.isApproved = false;
        this.IsRejectedBy = false;
        break;
      }
      case "Resubmitted - Rejected": {
        if (this.roleMapping.roleId == 11 || this.roleMapping.roleId == 12) {
          this.commonViewForReadonly();
        }
        else {
          this.commonViewForEdit();
        }
        break;
      }
      /*End Common for Approved, Resubmitted – Approved and Resubmitted - Rejected */

      case "Rejected":
        {
          this.commonViewForEdit();
          break;
        }

    }


  }
  //Method For Open and Resubmitted – Open
  commonViewForEdit() {
    this.ShowContentForEditforWP = 1;
    this.DisableWPSelectCheckboxes = false;
  }

  checkBoxForApproved() {
       this.DisableWPSelectCheckboxes = false;
  }
  //End Method For Open and Resubmitted – Open
  //Method for Approved, Rejected, Resubmitted - Approved and Resubmitted - Rejected
  commonViewForReadonly() {
    this.ShowContentForEditforWP = 0;
    this.DisableWPSelectCheckboxes = true;
    this.DisableWPSelectallCheckbox=true;
  }

  //End of Method for Approved, Rejected, Resubmitted - Approved and Resubmitted - Rejected

  //end
  GetResubmissionApprovalFlow() {
    //debugger;
    var inparameters = {
      "ArchiveNumber": this.archiveNumber,
      "UserAlias": ''
    }
    var parameters = JSON.stringify(inparameters);
    this.archiveHomeService.GetResubmissionApprovalFlowStatuses(parameters).subscribe(
      (obj) => {
        debugger;
        this.canApprove = obj[0].canApprove;
        if (obj[0].completedApprovel >= 1) {
          this.isFirstlvlApproved='Nochange'
          this.canApprove = false;
        }
        // else if(obj[0].completedApprovel==0){
        //   if(localStorage['isFirstLevelEdited']=="null" || localStorage['isFirstLevelEdited']==0)
        //   this.canApprove=false;
        // }
        //Added from outside method to inside method
        this.archiveHomeService.GetResubmissionReasonsforArchive(this.archiveNumber).subscribe(data => {
          debugger;
          if (data) {
            if (data.length > 0) {
              this.WPEditedInResubmit = data[1].actionTypeId == 3 ? true : false;
              this.WPProvidedInResubmit = data[1].comments != "" ? data[1].comments : "";
              this.WPEditedDate = data[1].rejectedDate;
            }
          }
        });

        if (this.canApprove) {
          console.log("Add", this.ShowContentForEditforWP)
          this.commonViewForEdit();
          console.log("Add", this.ShowContentForEditforWP)
          //this.IsButtonDisabled = false;
        }
        else {
          this.showMarorDelete=false;
          this.commonViewForReadonly();
        }
        //
      },
      (err) => {
        console.log("error is ", err)
      }
    );

  }

  Getsectioncomments(archiveNumber: string, SectionId: number, ActionTypeId: number) {
    // // debugger;
    //this.SpinnerService.show();
    console.log("called Getsectioncomments()");
    this.archiveHomeService.Getsectioncomments(archiveNumber, SectionId, ActionTypeId)
      .subscribe(
        data => {
          this.commentsData = data;
          this.rejectionDiscrption = this.commentsData["comments"];
          this.rejectionComments = this.commentsData["comments"];

          if (this.commentsData["rejectedBy"] == '') {
            this.rejectionBy = "Won, Cindy";
          }
          else {
            this.rejectionBy = this.commentsData["rejectedBy"];
          }

          this.rejectionTimeStamp = "01/01/2020";
          this.isSectionApproved = this.commentsData["isSectionApproved"];
          this.RejectedDateStamp = this.commentsData["rejectedDate"];

          this.getFlagsUpdate();
          //this.isLoaded = true;
          this._haveCommentsforSectionBeenLoaded = true;
          this.hideSpinner();
          console.log(this.commentsData);
        },
        err => {
          console.log('error:Getsectioncomments');
         // this.SpinnerService.hide();
        }
      );
  }



  downloadFile(s3fileName: string, fileName: string) {
    //debugger;
    if (!s3fileName && !fileName) return false;
    var metaData = {};
    var fileUploadProcessService = new FileUploadProcessService(
      this._fuService,
      this._uploadEventService,
      this.SpinnerService,
      null,
      null,
      metaData
    );
    fileUploadProcessService.downloadFile(s3fileName, fileName);
  }

  onwpSelectAll(evt: any) {
    debugger;
    if (evt.target.checked) {
      this.bulkDownloadSelectedFiles = [];
      this.selectedWorkingPapers = [];
      for (var i = 0; i < this.verifiedWorkingPapers.length; i++) {
        // if(this.CheckActiveFileStatus(this.verifiedWorkingPapers[i]))
        //{
          if ((this.verifiedWorkingPapers[i].fileVerificationStatusId == 6 || this.verifiedWorkingPapers[i].fileVerificationStatusId == 3) && this.verifiedWorkingPapers[i].buttonToEnable != "RestrictedAccess" && this.verifiedWorkingPapers[i].isArchiveDestroyed!=1) {

          this.verifiedWorkingPapers[i].chkSelect = true;
          this.selectedWorkingPapers.push({
            archiveFileId: this.verifiedWorkingPapers[i].archiveFileId,
            checked: true
          });
          var zipEntry = {
            ArchiveFileId: this.verifiedWorkingPapers[i].archiveFileId,
            FileName: this.verifiedWorkingPapers[i].fileName,
            S3FileName: this.verifiedWorkingPapers[i].s3FileName,
            S3FileSize: this.verifiedWorkingPapers[i].fileSize
          };
          var strZipEntry = JSON.stringify(zipEntry);
          this.bulkDownloadSelectedFiles.push(strZipEntry);
        }
        // }
      }
    }
    else {
      for (var i = 0; i < this.verifiedWorkingPapers.length; i++) {
        this.verifiedWorkingPapers[i].chkSelect = false;

        var archiveFileId = this.verifiedWorkingPapers[i].archiveFileId;
        this.bulkDownloadSelectedFiles = this.bulkDownloadSelectedFiles.filter(x => x.ArchiveFileId != archiveFileId);
        this.selectedWorkingPapers = this.selectedWorkingPapers.filter(x => x.archiveFileId != archiveFileId);
      }
      this.selectedWorkingPapers = [];
      this.bulkDownloadSelectedFiles = [];
    }
    console.log(this.bulkDownloadSelectedFiles);
  }

  onSelectFile(evt: any, index: number, archiveFileId: number, fileName: string, s3fileName: string, fileSize: number,) {
    debugger;
    if (evt.target.checked) {
      var zipEntry = {
        ArchiveFileId: archiveFileId,
        FileName: fileName,
        S3FileName: s3fileName,
        S3FileSize: fileSize
      };
      var strZipEntry = JSON.stringify(zipEntry);
      this.bulkDownloadSelectedFiles.push(strZipEntry);
      this.selectedWorkingPapers.push({
        archiveFileId: archiveFileId,
        checked: true
      });
    } else {
      this.verifiedWorkingPapers[index].chkSelect = false;
      this.selectedAll = false;
      var archivefileId = this.verifiedWorkingPapers[index].archiveFileId;
      this.bulkDownloadSelectedFiles = this.bulkDownloadSelectedFiles.filter(x => x.indexOf(archivefileId) == -1);
      this.selectedWorkingPapers = this.selectedWorkingPapers.filter(x => x.archiveFileId != archiveFileId);
    }
    console.log(this.bulkDownloadSelectedFiles);
  }

  bulkDownload() {
    var self = this;
    if (this.bulkDownloadSelectedFiles.length == 0) {
      this.notifier.notify("error", "Please select at least one file.");
      return;
    }
    //self.SpinnerService.show();
    console.log("====this.bulkDownloadSelectedFiles====");
    console.log(this.bulkDownloadSelectedFiles);
    self.zipFileName = self.archiveNumber + "_WorkingPapers_.zip";
    var bulkdownloadModel = {
      ArchiveNumber: self.archiveNumber,
      ZipFileName: self.zipFileName,
      SelectedFiles: this.bulkDownloadSelectedFiles
    }
    this._service.bulkDownload(bulkdownloadModel).subscribe(
      (data) => {
        self.bulkdownloadId = data.jobId;
        if (self.bulkdownloadId) {
          self._bdownloadEventService.bulkDownloadsArray.push(self.bulkdownloadId);
          this.notifier.hideNewest();
          self.notifier.notify("success", "Your file downloads will run in the backend and dowloads when ready. Do not close the browser to ensure the download process completes",);
          self.clearFileSelections();
        }
        else {
         // self.SpinnerService.hide();
          self.notifier.notify("error", "Something went wrong, please try again.");
        }
      },
      (err) => {
        console.log(err);
        //self.SpinnerService.hide();
        self.notifier.notify("error", "Something went wrong, please try again.");
        self.clearFileSelections();
      }
    );
  }

  clearFileSelections() {
    this.selectedAll = false;
    this.selectedWorkingPapers = [];
    this.bulkDownloadSelectedFiles = [];
    for (var i = 0; i < this.verifiedWorkingPapers.length; i++) {
      this.verifiedWorkingPapers[i].chkSelect = false;
    }
    for (var i = 0; i < this.unverifiedWorkingPapers.length; i++) {
      this.unverifiedWorkingPapers[i].chkSelect = false;
    }
  }


  //FileUploadStep 14:
  //Opens delete confirmation popup
  showDeletePopup(s3FileName: string, fileId: string, fileName: string, fileTypeId: number, emsFileId: string, failedFile: any) {
    this.archiveFileIdToBeDeleted = fileId;
    this.fileNameToBeDeleted = fileName;
    this.s3fileNameToBeDeleted = s3FileName;
    this.fileTypeIdToBeDeleted = fileTypeId;
    this.emsFileIdToBeDeleted = emsFileId;
    this.IsFailedFile = failedFile;
    this.modalService.openWithCustomWidth("deletePopUp", "480");
  }

  showInActivePopup(fileName: string, fileId: string) {
    //debugger;
    this.archiveFileIdToBeInActivated = fileId;
    this.fileNameToBeInActivated = fileName;
    this.modalService.openWithCustomWidth("InActivePopUp", "480");
  }

  //FileUploadStep 15:
  //Close delete confirmation popup
  closeDeletePopUp() {
    this.modalService.close("deletePopUp");
  }

  closeInActivePopUp() {
    this.modalService.close("InActivePopUp");
  }

  //FileUploadStep 13:
  //Deletes file from S3 and on success deletes the record from DB and refresh working papers list
  deleteFile() {
    //debugger;
    var self = this;

    if (!self.fileNameToBeDeleted) return false;

    self.SpinnerService.show();

    var deleteRequest = {
      "ArchiveNumber":self.archiveNumber,
      "FileName": self.s3fileNameToBeDeleted,
      "ArchiveFileId": self.archiveFileIdToBeDeleted,
      "ModifiedBy": ''
    }

    //If Archive File is EMS FileType then move file to S3 EMS folder before deleting from S3 Engagement folder
    if (self.fileTypeIdToBeDeleted == 2) {
      /* var metaData = {};
      var fileUploadProcessService = new FileUploadProcessService(
        this._fuService,
        this._uploadEventService,
        null,
        null,
        null,
        metaData
      );*/
      if (self.IsFailedFile === false) {
        self.CopyFiletoS3EMS(self.s3fileNameToBeDeleted, self.fileNameToBeDeleted,this.emsFileIdToBeDeleted, function (isDeleted) {
          if (isDeleted) {
            self.deleteRequest(deleteRequest);
          }
          else {
           // self.SpinnerService.hide();
            self.closeDeletePopUp();
            self.notifier.notify(
              "error",
              self.fileNameToBeDeleted + " deletion failed"
            );
          }
        });
      }
      else {
        self.deleteRequest(deleteRequest);
      }
    }
    else {
      self.deleteRequest(deleteRequest);
    }
  }

  CopyFiletoS3EMS(engFilePath: string, fileName: string, emsFileId: string, deletedCallback:any) {
    var self = this;
    var sourcekey = engFilePath;
    var S3FileName;
    if(String(sourcekey.toUpperCase()).split('/')[1]=="ENGAGEMENT"){
      S3FileName = sourcekey.split('/')[3].split("_")[1];
    }
    else{
        S3FileName = sourcekey.split('/')[2];
    }
    
    var destinationkey = "Audit/EMS/" + S3FileName;
    var isDeleted=false;
    var batchType = "delete";
    
     var deleteBatchRequest = {
      "BatchType": batchType,
      "SourcePath": engFilePath,
      "DestinationPath": destinationkey,
      "EmsFileId": emsFileId
    }

    self.service.IsBatchJobDeleteTriggeredAsync(deleteBatchRequest).subscribe(
        (data) => {
          console.log("EMS Batch job triggered for Delete successfully");
          isDeleted=true;
          deletedCallback(isDeleted);
        },
        err => {
          //self._spinnerService.hide();
          isDeleted=false;
          deletedCallback(isDeleted);
      });
}

  deleteRequest(deleteRequest: any) {
    var self = this;
    self.service.DeleteFile(deleteRequest).subscribe(
      res => {
        if (res == true) {
          console.log(self.emsFileIdToBeDeleted);
          if (self.fileTypeIdToBeDeleted == 2) {
            self.service.MoveDeleteEmsFiletoSNS(self.emsFileIdToBeDeleted, self.archiveNumber).subscribe(
              (data) => {
                console.log("EMS File Delete Message pushed to SNS ");
              },
              err => {
                console.log("EMS SNS Delete error is ", err);
              }
            );
          }
          self.verifiedWorkingPapers = self.verifiedWorkingPapers.filter(x => x.archiveFileId !== self.archiveFileIdToBeDeleted);
          self.notifier.notify(
            "success",
            self.fileNameToBeDeleted + " successfully deleted"
          );
          self.closeDeletePopUp();
          self.totalWorkingPapers = self.totalWorkingPapers - 1;
          var currentnumber = self.currentPageNumber;
          self.currentPageNumber = Math.round(self.totalWorkingPapers / self.pageSize);
          if (currentnumber !== self.currentPageNumber) {
            self.GetWorkingPapersforArchive(self.archiveNumber);
          }
        }
      //  self.SpinnerService.hide();
      },
      err => {
      //  self.SpinnerService.hide();
        self.closeDeletePopUp();
        self.notifier.notify(
          "error",
          self.fileNameToBeDeleted + " deletion failed"
        );
      }
    );
  }

  inActiveFile() {
    //debugger;
    var self = this;

    if (!self.fileNameToBeInActivated) return false;

    //self.SpinnerService.show();

    self.service.InActiveFile(self.archiveFileIdToBeInActivated, self.employeeUniqueIdentifier, 2, this.archiveNumber).subscribe(
      res => {

        if (res == true) {
          self.verifiedWorkingPapers = self.verifiedWorkingPapers.filter(x => x.archiveFileId !== self.archiveFileIdToBeDeleted);
          self.notifier.notify(
            "success",
            self.fileNameToBeInActivated + " successfully InActivated"
          );
          self.closeInActivePopUp();
          self.GetWorkingPapersforArchive(self.archiveNumber);
        }
        //self.SpinnerService.hide();
      },
      err => {
     //   self.SpinnerService.hide();
        self.closeInActivePopUp();
        self.notifier.notify(
          "error",
          self.fileNameToBeInActivated + " InActivation failed"
        );
      }
    );

  }

  GetFileTypes() {
    // this.SpinnerService.show();
    this.service.GetFileTypes().subscribe(
      data => {
        this.fileTypes = data;
        console.log(this.fileTypes);
        this._havefilesBeenLoaded = true;
        this.hideSpinner();
      },
      err => {
      //  this.SpinnerService.hide();
        console.log("error is ", err);
      }
    );
  }

  setButtonToEnable(verifieddata) {
    for (var i = 0; i < verifieddata.length; i++) {
      if (!verifieddata[i].isRDCDDatePassed
        && (verifieddata[i].archiveSubmissionStatus == 1 || verifieddata[i].archiveSubmissionStatus == 2
          || verifieddata[i].archiveSubmissionStatus == 6 || verifieddata[i].archiveSubmissionStatus == 7)
        && verifieddata[i].archiveFileSubmissionStatus != 10
        && !(verifieddata[i].fileTypeId == 12 && verifieddata[i].fileTypeDescription == 'Omnia Package'))
      //RDCD not passed, Archive Sub Status (Open/Submitted/ReadyForApproval/Reject), ArchiveFile Sub Status (If not mark with restricted access)
      {
        this.buttonToEnable = "Delete";
        if (verifieddata[i].fileTypeId == 2 || verifieddata[i].fileTypeDescription == 'AS/2') {
          this.buttonToEnablePosition = {
            'width': '256px',
            'right': '50px'
          };
        }
        else
          this.buttonToEnablePosition = {
            'width': '150px',
            'right': '190px'
          };
      }
      else if ((verifieddata[i].archiveFileSubmissionStatus != 10) && !(verifieddata[i].fileTypeId == 12 && verifieddata[i].fileTypeDescription == 'Omnia Package')) {
        this.buttonToEnable = "MarkWithRestricted";
        if (verifieddata[i].fileTypeId == 2 || verifieddata[i].fileTypeDescription == 'AS/2') {
          this.buttonToEnablePosition = {
            'width': '256px',
            'right': '180px'
          };
        }
        else
          this.buttonToEnablePosition = {
            'width': '256px',
            'right': '80px'
          };
      }
      else {
        if (!(verifieddata[i].fileTypeId == 12 && verifieddata[i].fileTypeDescription == 'Omnia Package')) {
          this.buttonToEnable = "RestrictedAccess";
        }
        if (this.roleMapping.roleId == 15) {
          this.buttonToEnablePosition = {
            'width': '106px',
            'right': '170px'
          };
        }
        if((verifieddata[i].fileTypeId == 12 && verifieddata[i].fileTypeDescription == 'Omnia Package')) {
          this.buttonToEnablePosition = {
            'width': '256px',
            'right': '-136px'
          };
        }
         else {
          this.buttonToEnablePosition = {
            'width': '256px',
            'right': '170px'
          };
        }
      }

      verifieddata[i].buttonToEnable = this.buttonToEnable;
      verifieddata[i].buttonToEnablePosition = this.buttonToEnablePosition;
    }
  }

  GetWorkingPapersforArchive(archiveNumber: string, showLoader?:boolean) {
    //this.SpinnerService.show();
    if(showLoader == undefined){
      showLoader = true;
    }
    this.service.GetWorkingPapersByArchiveNumber(archiveNumber, this.currentPageNumber, this.pageSize, showLoader).subscribe(
      data => {
        //this.workingPapers = data;
      
        var verifieddata = data.filter(x => !this.verificationInProgressStatus.includes(x.fileVerificationStatusId));
        var unverifieddata = data.filter(x => this.verificationInProgressStatus.includes(x.fileVerificationStatusId));
        if (this.appendWPtoGrid && data) {
          for (var i = 0; i < verifieddata.length; i++) {
            this.verifiedWorkingPapers.push(verifieddata[i]);
          }
          for (var i = 0; i < unverifieddata.length; i++) {
            this.unverifiedWorkingPapers.push(unverifieddata[i]);
          }
          this.verifiedWorkingPapers = this.verifiedWorkingPapers.filter((v, i) => this.verifiedWorkingPapers.findIndex(item => item.archiveFileId == v.archiveFileId) === i);
          this.unverifiedWorkingPapers = this.unverifiedWorkingPapers.filter((v, i) => this.unverifiedWorkingPapers.findIndex(item => item.archiveFileId == v.archiveFileId) === i);
        }
        else {
          this.verifiedWorkingPapers = verifieddata ? verifieddata : [];
          this.unverifiedWorkingPapers = unverifieddata ? unverifieddata : [];
        }

        for (let i = 0; i < this.verifiedWorkingPapers.length; i++) {
          let archiveFileId = this.verifiedWorkingPapers[i].archiveFileId;
          let wp = this.selectedWorkingPapers.find(x => x.archiveFileId == archiveFileId);
          if (wp) {
            this.verifiedWorkingPapers[i].chkSelect = wp.checked;
          }
        }
        for (let i = 0; i < this.unverifiedWorkingPapers.length; i++) {
          let archiveFileId = this.unverifiedWorkingPapers[i].archiveFileId;
          let wp = this.selectedWorkingPapers.find(x => x.archiveFileId == archiveFileId);
          if (wp) {
            this.unverifiedWorkingPapers[i].chkSelect = wp.checked;
          }
        }

        this.setButtonToEnable(this.verifiedWorkingPapers);
        var finalist=this.verifiedWorkingPapers.filter(x => x.buttonToEnable!='RestrictedAccess' && !this.CheckFailedFileStatus(x) && x.isArchiveDestroyed!=1);
        finalist.length<=1?this.DisableWPSelectallCheckbox=true:this.DisableWPSelectallCheckbox=false;
        /* Added for changing to substantive in resubmission*/
        if(this.CurrentArchiveStatusForWorkingPapers == "Resubmitted – Open" || this.CurrentArchiveStatusForWorkingPapers == "Resubmitted - Ready for Approval"){          
            this.archiveInfoService.getArchiveInfo(this.archiveNumber, this.employeeUniqueIdentifier, undefined, showLoader).subscribe(
              (info) => {
                if(info.resubmissionType == 'Substantive')
                this.archiveHomeService.updateArchiveSubstantiation();
            });
        }
        /* Added for changing to substantive in resubmission*/

        if (data.length > 0) {
          this.OmniaEngagementID = data[0].omniaEngagementId;
          this.isLoaded = true;
          this.totalWorkingPapers = data[0]["count"];
          this.IsWorkingPaper = true;
          console.log("working papers====");
          console.log(this.IsWorkingPaper);
          // if(this.verifiedWorkingPapers.length > 0 && this.unverifiedWorkingPapers.length > 0){
          //   this.totalWorkingPapers = (this.verifiedWorkingPapers[0]["count"] + this.unverifiedWorkingPapers[0]["count"]);
          // }
          // else if (this.verifiedWorkingPapers.length > 0){
          //   this.totalWorkingPapers = this.verifiedWorkingPapers[0]["count"];
          // }
          // else if (this.unverifiedWorkingPapers.length > 0){
          //   this.totalWorkingPapers = this.unverifiedWorkingPapers[0]["count"];
          // }

        }
        else {
          this.totalWorkingPapers = 0;
          this.GetSubstantiation(this.archiveNumber, this.commentCategoryId, showLoader);
        }
        this.hideSpinner();
      },
      err => {
       // this.SpinnerService.hide();
        console.log("error is ", err);
      }
    );
  }
  CheckActiveFileStatus(file: any) {
    if (file.fileTypeDescription == 'Omnia Package') {
      return ((file.fileVerificationStatusId == 6) || (file.fileVerificationStatusId == 3));
    } else {
      return (file.isActive === true && !(this.verificationInProgressStatus.includes(file.fileVerificationStatusId) || this.failedStatus.includes(file.fileVerificationStatusId)));
    }
  }
  CheckFileInProgressFileStatus(file: any) {
    return (file.isActive === true && this.verificationInProgressStatus.includes(file.fileVerificationStatusId));
  }
  CheckFailedFileStatus(file: any) {
    if (file.fileTypeDescription == 'Omnia Package') {
      return (!((file.fileVerificationStatusId == 6) || (file.fileVerificationStatusId == 3)));
    } else {
      return (file.isActive === true && this.failedStatus.includes(file.fileVerificationStatusId));
    }
  }






  // No working papers Substantiation
  GetSubstantiation(archiveNumber: string, commentCategoryId: number, showLoader: boolean) {
    //this.SpinnerService.show();
    this.service.GetSubstantiationByArchiveNumber(archiveNumber, commentCategoryId, showLoader).subscribe(
      data => {
        this.DisplayReason = data;
        if (this.DisplayReason != '') {
        }
        this.isLoaded = true;
        this.getFlagsUpdate();
        this.hideSpinner();
      },
      err => {
        console.log("error is ", err);
      }
    );
  }
  SaveSubstantiation(reason) {
    var parameter =
    {
      "ArchiveNumber": this.archiveNumber,
      "Comment": reason,
      "CreatedBy": '',
      "CommentCategoryId": 2,
    }
    var myobjstr = JSON.stringify(parameter);
    // this.SpinnerService.show();

    this.service.AddEditSubstantiation(myobjstr).subscribe(
      data => {
        if (data == true) {
          this.DisplayReason = reason;
          this.notifier.notify(
            "success",
            this.fileNameToBeDeleted + "Successfully added"
          );
        }
        else {
          this.notifier.notify(
            "error",
            this.fileNameToBeDeleted + "Error occured"
          );
        }
       // this.SpinnerService.hide();
      },
      err => {
        console.log("error is ", err);
      }
    );
  }

  private hideSpinner(): void {
    if (this._havefilesBeenLoaded
      && this.isLoaded
      && this._haveCommentsforSectionBeenLoaded
      && this._hasArchiveStatusBeenChecked
      && this._hasUserRoleBeenChecked)
      if (!this.bulkdownloadId) {
       // this.SpinnerService.hide();
      }
  }

  GetDataToVerifyArchivePackage(eMSFileID: string) {
    //this.SpinnerService.show();
    this.service.GetDataToVerifyArchivePackage(eMSFileID, this.archiveNumber).subscribe(
      data => {
        if (data != null && data != undefined) {
          this.modalService.openWithCustomWidth('verify-archivepackage-modal', "500");
          this.dataToVerifyArchivePackage = data;
          if (this.dataToVerifyArchivePackage.emsEngagementTeamMembers && this.dataToVerifyArchivePackage.emsEngagementTeamMembers.length > 0) {
            this.roleArray = Array.from(new Set(this.dataToVerifyArchivePackage.emsEngagementTeamMembers.map((item: any) => item.emsEngagementTeamMembersRole))).sort();
          }
        }
        //this.SpinnerService.hide();
      },
      err => {
       // this.SpinnerService.hide();
        console.log("error is ", err);
      }
    );
  }
  filterItemsByRole(role: string) {
    return this.dataToVerifyArchivePackage.emsEngagementTeamMembers.filter(x => x.emsEngagementTeamMembersRole == role);
  }
  updateGridData(event) {
   // this.SpinnerService.show();
    this.appendWPtoGrid = event.isLoadMoreClicked;
    this.currentPageNumber = event.pageNumber;
    this.GetWorkingPapersforArchive(this.archiveNumber);
  }
  generateReportClicked(data1) {
    debugger;
   // this.SpinnerService.show();
    let archiveForReport: any[] = [];
    let filterdColumns = (data1.filter(x => x.checked));
    this.service.GetWorkingPapersByArchiveNumber(this.archiveNumber).subscribe(
      data => {
        if (data.length > 0) {
          debugger;
          data.forEach(element => {
            let archive = {};
            filterdColumns.forEach(column => {

              if (column["value"] == this.workingPapersResultGridColumns.ArchiveFileId) { //Archive#
                archive[this.workingPapersResultGridColumns[this.workingPapersResultGridColumns.ArchiveFileId]] = element.archiveFileId || this.emptyStringInReport;
              }

              if (column["value"] == this.workingPapersResultGridColumns.FileName) { //Archive#
                archive[this.workingPapersResultGridColumns[this.workingPapersResultGridColumns.FileName]] = element.fileName || this.emptyStringInReport;
              }

              if (column["value"] == this.workingPapersResultGridColumns.FileSize) { //Archive#
                archive[this.workingPapersResultGridColumns[this.workingPapersResultGridColumns.FileSize]] = element.fileSize || this.emptyStringInReport;
              }

              if (column["value"] == this.workingPapersResultGridColumns.IsActive) { //Archive#
                archive[this.workingPapersResultGridColumns[this.workingPapersResultGridColumns.IsActive]] = element.isActive || this.emptyStringInReport;
              }

              if (column["value"] == this.workingPapersResultGridColumns.FileTypeId) { //Archive#
                archive[this.workingPapersResultGridColumns[this.workingPapersResultGridColumns.FileTypeId]] = element.fileTypeId || this.emptyStringInReport;
              }

              if (column["value"] == this.workingPapersResultGridColumns.FileTransferId) { //Archive#
                archive[this.workingPapersResultGridColumns[this.workingPapersResultGridColumns.FileTransferId]] = element.fileTransferId || this.emptyStringInReport;
              }

              if (column["value"] == this.workingPapersResultGridColumns.S3FileName) { //Archive#
                archive[this.workingPapersResultGridColumns[this.workingPapersResultGridColumns.S3FileName]] = element.s3FileName || this.emptyStringInReport;
              }

              if (column["value"] == this.workingPapersResultGridColumns.FileTypeDescription) { //Archive#
                archive[this.workingPapersResultGridColumns[this.workingPapersResultGridColumns.FileTypeDescription]] = element.fileTypeDescription || this.emptyStringInReport;
              }

              if (column["value"] == this.workingPapersResultGridColumns.BypassIntegrityCheck) { //Archive#
                archive[this.workingPapersResultGridColumns[this.workingPapersResultGridColumns.BypassIntegrityCheck]] = element.bypassIntegrityCheck || this.emptyStringInReport;
              }

              if (column["value"] == this.workingPapersResultGridColumns.CreatedBy) { //Archive#
                archive[this.workingPapersResultGridColumns[this.workingPapersResultGridColumns.CreatedBy]] = element.createdBy || this.emptyStringInReport;
              }

              if (column["value"] == this.workingPapersResultGridColumns.CreatedByFullName) { //Archive#
                archive[this.workingPapersResultGridColumns[this.workingPapersResultGridColumns.CreatedByFullName]] = element.createdByFullName || this.emptyStringInReport;
              }

              if (column["value"] == this.workingPapersResultGridColumns.CreatedDate) { //Archive#
                archive[this.workingPapersResultGridColumns[this.workingPapersResultGridColumns.CreatedDate]] = element.createdByFullName || this.emptyStringInReport;
              }

              if (column["value"] == this.workingPapersResultGridColumns.SubmissionPackageID) { //Archive#
                archive[this.workingPapersResultGridColumns[this.workingPapersResultGridColumns.SubmissionPackageID]] = element.submissionPackageId || this.emptyStringInReport;
              }

              if (column["value"] == this.workingPapersResultGridColumns.FileVerificationStatusId) { //Archive#
                archive[this.workingPapersResultGridColumns[this.workingPapersResultGridColumns.FileVerificationStatusId]] = element.fileVerificationStatusId || this.emptyStringInReport;
              }

              if (column["value"] == this.workingPapersResultGridColumns.FileVerificationStatus) { //Archive#
                archive[this.workingPapersResultGridColumns[this.workingPapersResultGridColumns.FileVerificationStatus]] = element.fileVerificationStatus || this.emptyStringInReport;
              }

              if (column["value"] == this.workingPapersResultGridColumns.FailedDescription) { //Archive#
                archive[this.workingPapersResultGridColumns[this.workingPapersResultGridColumns.FailedDescription]] = element.failedDescription || this.emptyStringInReport;
              }

              if (column["value"] == this.workingPapersResultGridColumns.EmsFileId) { //Archive#
                archive[this.workingPapersResultGridColumns[this.workingPapersResultGridColumns.EmsFileId]] = element.emsFileId || this.emptyStringInReport;
              }

              if (column["value"] == this.workingPapersResultGridColumns.TransferFinishDate) { //Archive#
                archive[this.workingPapersResultGridColumns[this.workingPapersResultGridColumns.TransferFinishDate]] = element.transferFinishDate || this.emptyStringInReport;
              }

            });
            archiveForReport.push(archive);
          });
          if (archiveForReport && archiveForReport.length) {
            this.sharedService.generateExcel("WorkingpapersFor" + this.archiveNumber, "working-papers", filterdColumns.map(x => x.displayName), archiveForReport);
          }
        }
      });

  }
  enableshow() {
    this.show = !this.show;
    if (this.placeholder == '+')
      this.placeholder = '-';
    else
      this.placeholder = '+';
  }
  as2filetree(AS2xml: string, periodEndDate) {
    this.NODES = [];
    this.PeriodEndDate = '';
    this.getxml(AS2xml);
    var fulldate = new Date(periodEndDate);
    let date = ("0" + fulldate.getDate()).slice(-2);

    // current month
    let month = ("0" + (fulldate.getMonth() + 1)).slice(-2);

    // current year
    let year = fulldate.getFullYear();
    this.PeriodEndDate = month + "/" + date + "/" + year;
    this.modalService.openWithCustomWidth('as2filetreepopup', "500");
  }
  getxml(AS2xml: string) {
    this.placeholder = '-';
    this.show = true;
    var re = /@lt;/gi;
    var re1 = /@gt;/gi;
    var re2 = /&amp;/gi;
    var xml = AS2xml.replace(re, "<").replace(re1, ">").replace(re2, "&");
    //var xml="<Password password='1234'/><Tree><Node Title='Unfiled' Reference='' DocumentType='' ItemType='1'><Node Title='Fax' Reference='***' DocumentType='WORD' ItemType='2' /><Node Title='Letter' Reference='***' DocumentType='WORD' ItemType='2' /> <Node Title='Memo' Reference='***' DocumentType='WORD' ItemType='2' /></Node></Tree>";
    //var xml="<Password password='' /><Tree><Node Title='Unfiled' Reference='' DocumentType='' ItemType='1'><Node Title='Blank Word Document no AS 2 Header Footer' Reference='**' DocumentType='WORD' ItemType='2'/><Node Title='Blank Word Document no AS 2 Header Footer' Reference='**' DocumentType='WORD' ItemType='2'/></Node></Tree>"
    //var xml="<Password password='' /><Tree><Node Title='1) PLANNING (1000)' Reference='' DocumentType='' ItemType='1'><Node Title='1400 UNDERSTAND THE CLIENTS BUSINESS' Reference='' DocumentType='' ItemType='1'><Node Title='Understand the Entity and Its Environment [S]' Reference='1410' DocumentType='WORD' ItemType='2' /></Node><Node Title='1700 DETERMINE PLANNING MATERIALITY' Reference='' DocumentType='' ItemType='1'><Node Title='Determine Materiality (05-10)  [S]' Reference='1710' DocumentType='EXCEL' ItemType='2' /></Node></Node><Node Title='2) REPORTING TO MANAGEMENT (2000)' Reference='' DocumentType='' ItemType='1'><Node Title='2110 Preliminary Official Statement + Documents' Reference='' DocumentType='' ItemType='1'><Node Title='2110.1 Preliminary Official Statement 3/9/2011' Reference='' DocumentType='' ItemType='1'><Node Title='City of Whittier Bonds Series 2011 - Preliminary Official Statement - 3/9/2011' Reference='2110.1' DocumentType='GEN' ItemType='2' /><Node Title='PIH 2011 Purchase Contract - PIH Board pa- 2 28' Reference='2110.1A' DocumentType='WORD' ItemType='2' /></Node></Node></Node></Tree>"
    console.log(xml);
    let result1 = converter.xml2json(xml, { compact: true, spaces: 2 });

    const JSONData = JSON.parse(result1);
    //console.log(JSONData);
    for (let k of this.objectKeys(JSONData.Password)) {
      this.passwordvalue = JSONData.Password[k].password;
    }
    if (this.passwordvalue == "")
      this.passwordvalue = "No password";
    var objects = (JSONData.Tree).Node;
    if (objects.length > 1) {
      for (let i = 0; i < objects.length; i++) {
        //console.log(objects[i]);
        this.nodearray = [];
        this.pushobject(objects[i], 0);
      }
    }
    else {
      // console.log(objects);
      this.nodearray = [];
      this.pushobject(objects, 0);
    }
    // console.log(this.NODES);
  }

  pushobject(object, callvalue) {
    //console.log(object);
    if (object.length > 1) {
      var subnodearray = [];
      for (let ik = 0; ik < object.length; ik++) {
        let n = this.objectKeys(object[ik]);
        if (this.objectKeys(object[ik]).length > 1) {
          var obj;

          console.log(object[ik][n[0]].Title);
          obj = {
            name: object[ik][n[0]].Reference + " " + object[ik][n[0]].Title,
            showChildren: true,
            itemtype: object[ik][n[0]].ItemType,
            ...(Array.isArray(this.pushobject(object[ik][n[1]], 2))) ? { children: this.pushobject(object[ik][n[1]], 2), } : { children: [this.pushobject(object[ik][n[1]], 2)] },
          }

          subnodearray.push(obj);
          if (ik == object.length - 1)
            return this.nodearray.concat(subnodearray);
        }
        else {

          var obj;
          obj = {
            name: object[ik]._attributes.Reference + " " + object[ik]._attributes.Title,
            showChildren: true,
            itemtype: object[ik]._attributes.ItemType,
            children: [],
          }
          subnodearray.push(obj);
          if (ik == object.length - 1)
            return this.nodearray.concat(subnodearray);

        }
      }
    }
    else {

      let n = this.objectKeys(object);
      if (this.objectKeys(object).length > 1) {
        this.counter++;
        var obj;
        //console.log(object[n[0]].Title);
        obj = {
          name: object[n[0]].Reference + " " + object[n[0]].Title,
          showChildren: true,
          itemtype: object[n[0]].ItemType,
          ...(Array.isArray(this.pushobject(object[n[1]], 1))) ? { children: this.pushobject(object[n[1]], 1), } : { children: [this.pushobject(object[n[1]], 1)] },

        }
        this.counter--;
        if (this.counter == 0)
          this.NODES.push(obj);
        else
          return obj;
      }
      else {
        if (object[n[0]] == Array) {
          object[n[0]].forEach((item, index) => {
            var obj;
            // console.log(item);
            obj = {
              name: item._attributes.Reference + " " + item._attributes.Title,
              showChildren: true,
              itemtype: item._attributes.ItemType,
              children: [],
            }
            //  console.log(obj);
            return obj;
          });
        }
        else {
          var obj;
          obj = {
            name: object._attributes.Reference + " " + object._attributes.Title,
            showChildren: true,
            itemtype: object._attributes.ItemType,
            children: [],
          }
          //  console.log(obj);
          return obj;
        }
      }
    }
  }
  getbypassintegritycheck(workingpaper) {
    if (workingpaper.fileTypeId == 2)
      return workingpaper.bypassIntegrityCheck == false ? 'Not Applicable' : 'Applicable';
    else
      return workingpaper.bypassIntegrityCheck == false ? 'No' : 'Yes';
  }

} /// end of class

export enum WorkingPapersResultGridColumns {
  ArchiveFileId = 1,
  FileName = 2,
  FileSize = 3,
  IsActive = 4,
  FileTypeId = 5,
  FileTransferId = 6,
  S3FileName = 7,
  FileTypeDescription = 8,
  BypassIntegrityCheck = 9,
  CreatedBy = 10,
  CreatedByFullName = 11,
  CreatedDate = 12,
  SubmissionPackageID = 13,
  FileVerificationStatusId = 14,
  FileVerificationStatus = 15,
  FailedDescription = 16,
  EmsFileId = 17,
  TransferFinishDate = 18,

}
