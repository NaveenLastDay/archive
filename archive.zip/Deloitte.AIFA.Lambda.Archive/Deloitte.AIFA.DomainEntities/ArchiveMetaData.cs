﻿using System;

namespace Deloitte.AIFA.DomainEntities
{
    public class ArchiveMetaData
    {
        public bool IsAuditEngagement { get; set; }
        public bool IsArchiveNeeded { get; set; }
        public string EngagementDesc { get; set; }
        public DateTime? PeriodEnd { get; set; }
        public string EngagementType { get; set; }
        public bool IsDeliverable { get; set; }
        public DateTime? EstimatedDate { get; set; }
        public DateTime CompletionDate { get; set; }
        public string Office { get; set; }
        public string EntityType { get; set; }
        public string ProfessionalStandard { get; set; }
        public string WBSLevel1Archive { get; set; }
        public string AdditionalDescription { get; set; }
        public string ArchiveType { get; set; }
        public string ArchiveFieldSenior { get; set; }
        public string AdditionalArchiveFieldSenior { get; set; }
        public string Createdby { get; set; }
        public int? RoleID { get; set; }
        public string ArchiveNum { get; set; }
        public string Description { get; set; }


    }
}
