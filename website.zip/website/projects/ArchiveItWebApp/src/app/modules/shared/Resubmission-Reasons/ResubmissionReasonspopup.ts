import { Component, OnInit,Output,EventEmitter} from '@angular/core';
import { AngularEditorConfig } from '@kolkov/angular-editor';
import { ModalService} from '../../shared/modal';
import { NgxSpinnerService } from "ngx-spinner";
import { ArchiveHomeService } from '../../../services/archive-home.service';
import { ActivatedRoute,Router} from '@angular/router';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { ArchiveHomeComponent } from '../../archive/archive-home/archive-home.component';


@Component({
    selector: 'app-Resubmission-Reasons',
    templateUrl: './ResubmissionReasonspopup.html',
    styleUrls: ['./ResubmissionReasonspopup.css'],
    providers:[ArchiveHomeComponent]
  })

  export class ResubmissionReasonsPopupComponent implements OnInit{
    @Output() addReason: EventEmitter<string> = new EventEmitter();
    ResubmissionReasons:string='';
    BodyCount:number;
    IdentifytheSection:number;
    ProvideReasonbuttonmethod:number=0;
    archiveNumber:string;
    employeeUniqueIdentifier:string;
    Title:string='State the reason for changes';
    CommentTitle:string='';
    showStatereasonEditor:boolean=true;
    showYesNo:boolean=true;
    OperationType:string='';
    //ArchiveStatus: string='';
    showCancel:boolean=true;
    IsRejectReason:boolean =true;
    ActionType:number;
    constructor(
        private archivehomecomponent:ArchiveHomeComponent,
        private modalService:ModalService,
        private SpinnerService:NgxSpinnerService,
        private archiveHomeService:ArchiveHomeService,
        private activatedRoute: ActivatedRoute,
        private adalSvc: MsAdalAngular6Service,
        private router: Router
    ){}
    
    ngOnInit() {
      this.archiveNumber = this.activatedRoute.snapshot.parent.paramMap.get('aN');
      this.employeeUniqueIdentifier = this.adalSvc.LoggedInUserEmail.split('@')[0];
    }


    SaveResubmissionReasons()
    {
      if(this.IsRejectReason && this.ProvideReasonbuttonmethod==0)
      {
        this.ActionType=2;
      }
      else
      {
        this.ActionType=3;
      }
      
      var parameters =
      {
          "ArchiveNumber": this.archiveNumber,
          "ArchiveSectionId": this.IdentifytheSection,
          "ActionTypeId": this.ActionType,
          "Comments": this.ResubmissionReasons,
          "CreatedBy": ''
      }
      debugger;
      var myobjstr = JSON.stringify(parameters);
     // this.SpinnerService.show();
      this.archiveHomeService.OnApproveOrRejection(myobjstr)
            .subscribe(
              data => {
                 debugger;
             //   this.SpinnerService.hide();
                this.modalService.close("Reasons-resubmission-modal");
                if(data=='success' && this.IdentifytheSection==1  )
                {
                  if(this.OperationType !="Reject")
                  {
                  this.archivehomecomponent.ShowSuccessToasterMessageforADPage();
                  }
                }

                this.router.navigate(['/archive/myarchives/' + this.archiveNumber + '/archivehome']);
                if(this.ProvideReasonbuttonmethod==8)
                {
                  this.archivehomecomponent.ProvideReasonsButtonRefresh();
                }
                
              }
    
            );
    }

    // Inside sections
    openModalDialog(SectionId,ReasonsText,OperationType, ArchiveStatus)
    {

     // this.ArchiveStatus=ArchiveStatus;
      this.OperationType=OperationType;
     //Reject reasons which will be provided in RFA and RRFA by approver
     if(OperationType=='Reject' || OperationType=='RejectEdit' )
     {

     if(OperationType=='Reject')
     {
      localStorage['IsSectionVisited'] = '1';
     }

// 1	Engagement Details
        // 2	Working Papers
        // 3	Deliverables
        // 4	Linked Archives
        // 5	Engagement Related Personnel
        // 6	Retention Exception
        // 7  Binders



    switch(SectionId)
    {

    case '1':
    {
    this.Title='Reject Archive details';
    break;
    }
    case '2':
    {
    this.Title='Reject Working Papers';
    break;
    }

    case '3':
    {
    this.Title='Reject Deliverables';
    break;
    } 
    case '4':
    {
    this.Title='Reject Linked Archives';
    break;
    }

    case '5':
      {
      this.Title='Reject Engagement Related Personnel';
      break;
      }

      case '6':
        {
        this.Title='Reject Retention Exception';
        break;
        }
    }
        
      this.IsRejectReason =true;

     this.CommentTitle='Please document the reason for reject and select the Save button.';
      this.showStatereasonEditor=true;
      this.showYesNo=false;
      this.IdentifytheSection=SectionId;
      this.BodyCount=250;
      this.ResubmissionReasons=ReasonsText;
      this.showCancel=true;
      this.modalService.openWithCustomWidth('Reasons-resubmission-modal','600');

    
    }


    // Edited reasons which will be provided in resubmission only by suibmitter or approver
    else
    {
      if(ArchiveStatus=='Resubmitted – Open' || ArchiveStatus=='Resubmitted - Ready for Approval')
     {

      this.IsRejectReason =false;
      this.CommentTitle='Document the reason for making changes to this section and then select Confirm.';
      //Ribbon Edit
      if(OperationType == "Edit")
      {
        
        this.Title='State the reason for changes';
        this.showStatereasonEditor=true;
        this.showYesNo=false;
        this.IdentifytheSection=SectionId;
        this.BodyCount=250;
        this.ResubmissionReasons=ReasonsText;
        this.showCancel=true;
        this.modalService.openWithCustomWidth('Reasons-resubmission-modal','600');
      
      }


      // Change
      else if(OperationType == "Change")
      {
       
        this.IdentifytheSection=SectionId;
        this.Title='Finish Making Changes to Resubmission Changes';   
        this.showStatereasonEditor=false;
        this.showYesNo=true;
        this.BodyCount=250;
        this.ResubmissionReasons=ReasonsText;
        this.showCancel=false;
        this.modalService.openWithCustomWidth('Reasons-resubmission-modal','670');
      
      }
    }

    }
      
      
    }


    //In home provide reasons button
    openModalDialogforProvideReasonsbutton(ActionType,ReasonsText,Pageflag)
    {
      this.Title='State the reason for changes';
      this.showStatereasonEditor=true;
      this.showYesNo=false;
      this.IdentifytheSection=ActionType;
      this.ProvideReasonbuttonmethod=Pageflag;
      this.BodyCount=250;
      this.ResubmissionReasons=ReasonsText;
      this.showCancel=true;
      this.modalService.openWithCustomWidth('Reasons-resubmission-modal','600');
    }




    closeModalDialog(userActionType:string)
    {
      if(userActionType==='No')
      {
        this.SaveResubmissionReasons();
      }
      this.modalService.close('Reasons-resubmission-modal');
    }

    StateReasonsYesClick()
    {
      this.showStatereasonEditor=true;
      
    }
      
  }
