﻿using Deloitte.AIFA.DataModels;
using Deloitte.AIFA.DomainEntities;
using Deloitte.AIFA.IRepositories;
using Deloitte.AIFA.Repositories.Transformers;
using Microsoft.Extensions.Caching.Memory;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Deloitte.AIFA.Repositories.Repository
{
    public class ArchiveSearchRepository : BaseRepository<ArchiveSearchFields>, IArchiveSearchRepository
    {
        IMemoryCache _cache;
        public ArchiveSearchRepository(IMemoryCache cache) : base(cache)
        {
            _cache = cache;
        }
        public List<SearchOptions> SearchByCategory(string Search, string CategoryType)
        {
            Exception e = new Exception();
            try
            {
                var parameters = Builder.Bind(ArchiveSearchParameter.Search).On(Search)
                                 .Bind(ArchiveSearchParameter.Category).On(CategoryType)
                                 .Build();
                return DbHelper.ExecuteReader(
                    "pub_AIFA_GetArchiveSearchData",
                    parameters,
                        dr =>
                        {
                            var archiveEntity = new ArchiveSearchTransformer().Transform(dr).ToList();
                            var archive = _mapper.Map<List<SearchOptionsModel>, List<SearchOptions>>(archiveEntity);
                            return archive;
                            //return null;
                        }
                    );
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
