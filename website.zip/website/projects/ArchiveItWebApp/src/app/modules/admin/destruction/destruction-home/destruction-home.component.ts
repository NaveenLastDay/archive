import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-destruction-home',
  templateUrl: './destruction-home.component.html',
  styleUrls: ['./destruction-home.component.css']
})
export class DestructionHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
