﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
    public class ArchiveTeamChangeDetailsData
    {
        public int ArchiveStatus { get; set; }
        public string TeamChangedBy { get; set; }
        public string RolePartner { get; set; }
        public string NewPartnerAlias { get; set; }
        public string NewPartnerName { get; set; }
        public string OldPartnerAlias { get; set; }
        public string OldPartnerName { get; set; }

        public string RoleManager { get; set; }
        public string NewManagerAlias { get; set; }
        public string NewManagerName { get; set; }
        public string OldManagerAlias { get; set; }
        public string OldManagerName { get; set; }

        public string RoleFieldSenior { get; set; }
        public string NewFieldSeniorAlias { get; set; }
        public string NewFieldSeniorName { get; set; }
        public string OldFieldSeniorAlias { get; set; }
        public string OldFieldSeniorName { get; set; }

        public string RoleAddFieldSenior { get; set; }
        public string NewAddFieldSeniorAlias { get; set; }
        public string NewAddFieldSeniorName { get; set; }
        public string OldAddFieldSeniorAlias { get; set; }
        public string OldAddFieldSeniorName { get; set; }

        public int? FormID { get; set; }

    }
}
