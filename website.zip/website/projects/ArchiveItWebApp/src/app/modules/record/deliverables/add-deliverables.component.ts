import { Component, OnInit, Output, EventEmitter, ViewChild, ElementRef, Renderer2, Inject } from '@angular/core';
import { ModalService } from "../../shared/modal";
import { StsserviceService } from "../../shared/stsservice.service"
import { Router } from '@angular/router';
import { MatInput } from '@angular/material';
import { DeliverableService } from '../../../services/deliverable.service';
import { ArchiveHomeService } from '../../../services/archive-home.service';
import { NotifierService } from 'angular-notifier';
import { NgxSpinnerService } from "ngx-spinner";
import { ActivatedRoute } from '@angular/router';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { FormGroup, FormBuilder, NgForm, Validators } from '@angular/forms';
import { archiveInfoService } from '../../../services/archiveinfo.service'
import { AngularEditorConfig } from '@kolkov/angular-editor';
import { FileUploadRecordService } from '../../../services/fileupload.record.service';
import { FileUploadEventService } from '../file-upload/fileupload.event.service';
import { FielUploadService } from '../../../services/fileupload.service';
import { WorkingPaperService } from '../../../services/working-paper.service';
import { FileUploadProcessService } from '../file-upload/fileupload.process.service';
import { Console } from 'console';
import { NativeDateAdapter } from '@angular/material';
import { MatDateFormats } from '@angular/material/core';
import { DateAdapter, MAT_DATE_FORMATS } from '@angular/material/core';
import { UserActions } from '../../../models/archive-role.model';
import { PubsubService } from '../../../services/pubsub.service';
import { String } from 'aws-sdk/clients/acm';
import { Subject, BehaviorSubject } from 'rxjs';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { SharedService } from '../../../services/shared.service';
import { IfStmt } from '@angular/compiler';
import { BulkdownloadEventService } from '../bulk-download/bulkdownload.event.service';
import { ArchiveService } from './../../../services/archive.service';
import { NgbDate } from '@ng-bootstrap/ng-bootstrap';

export class AppDateAdapter extends NativeDateAdapter {
  format(date: Date, displayFormat: Object): string {
    if (displayFormat === 'input') {
      let day: string = date.getDate().toString();
      day = +day < 10 ? '0' + day : day;
      let month: string = (date.getMonth() + 1).toString();
      month = +month < 10 ? '0' + month : month;
      let year = date.getFullYear();
      return `${month}/${day}/${year}`;
    }
    return date.toDateString().split(' ')[1] + " " + date.toDateString().split(' ')[3];
  }
}
export const APP_DATE_FORMATS: MatDateFormats = {
  parse: {
    dateInput: { month: 'short', year: 'numeric', day: 'numeric' },
  },
  display: {
    dateInput: 'input',
    monthYearLabel: { year: 'numeric', month: 'numeric' },
    dateA11yLabel: {
      year: 'numeric', month: 'long', day: 'numeric'
    },
    monthYearA11yLabel: { year: 'numeric', month: 'long' },
  }
};
@Component({
  selector: 'app-add-deliverables',
  templateUrl: './add-deliverables.component.html',
  styleUrls: ['./add-deliverables.component.css'],
  providers: [
    { provide: DateAdapter, useClass: AppDateAdapter },
    { provide: MAT_DATE_FORMATS, useValue: APP_DATE_FORMATS }
  ]
})
export class AddDeliverablesComponent implements OnInit {

  EDCDNoCalculation: boolean = true;
  unverified: any = []; verified: any = [];
  engRelatedDateModal: boolean = true;
  engFieldRelatedModal: boolean = true;
  engRelatedDate: boolean = true;
  engRelatedDate1: boolean = true;
  disabledColor: any;
  rejectDisabledColor: any;
  archiveNumber: string;
  FlagforCancelbuttonClick_ROI:boolean=false;
  FlagforCancelbuttonClick_Del:boolean=false;
  rejectionDescription: any;
  rejectedBy: string;
  rejectedComments: any;
  originalComments: any;
  topCss: any;
  hideRejectedMessage: boolean;
  hideAddBotton: boolean;
  hideRefreshROIBotton: boolean;
  hideRejectedLabel: boolean = false;
  hidechangeDecision: boolean = true;
  BodyCount: number = 250;
  ApproveDisabled: boolean;
  RejectDisabled: boolean;
  result: string = "";
  popUpHeaderText: string = "";
  popUpROIHeaderText: string = "";
  showPopUp: number = 0;
  displayHeader: boolean = true;
  isManualClicked: boolean = false;
  isMATROIClicked: boolean = true;
  ROIArchiveSource: string = "";
  DeliverableReleaseDate: Date = undefined;
  DeliverableDate: Date = undefined;
  maxDate: any;
  IsSectionVisited: any;
  DeliverablesEditedInResubmit: boolean;
  DeliverablesProvidedInResubmit: string;
  DeliverablesEditedDate: Date;
  statusText:any = "Verification in progress";

  // flags
  show: boolean = false;
  isShowROIUpdateTipBox: boolean = false;
  isBasicShow: boolean = true;
  isDefaultResult: boolean = true;
  isLoadedResult: boolean = false;
  isInputSearchResult: boolean = true;
  FileAddedinResubmitOpen: boolean = false;
  IsChangeDecissionClicked: boolean = false;

  lastUpdatedDtShow: boolean = false;
  deliverableDtShow: boolean = false;
  deliverableReleaseDtShow: boolean = false;

  isFirstlvlApproved: string = 'Change';

  readonly searchParamDTPrefix: string = "Deliverable type:";
  readonly searchParamDRDPrefix: String = "Deliverable Release date:";
  readonly searchParamDDPrefix: string = "Deliverable date:";
  readonly searchParamLUPPrefix: string = "Last Updated date:";
  readonly roiDateFormat: string = "MM/DD/YYYY";

  lastUpdatedDate: string;
  lastDeliverableReleaseDate: string;
  lastDeliverableDate: string;
  eventValueDRD:any;
  eventValueDD:any;
  eventValueDLU:any;


  //from and to dates
  lastUpdatedDateFrom: string;
  lastUpdatedDateTo: string;
  lastDeliverableReleaseDateFrom: string;
  lastDeliverableReleaseDateTo: string;
  lastDeliverableDateFrom: string;
  lastDeliverableDateTo: string;
  archiveinfo: any;

  filterarray: any = [];
  paramindex: number = 0;
  searchtextvalue: string = '';
  readonly DeliverablespageSize: number = 10;
  totalDeliverables: number = 0;
  deliverableIDtobeInactivated: string = '';
  deliverableResultGridColumns: any = DeliverableResultGridColumns;
  readonly emptyStringInReport: string = " ";
  bulkDownloadSelectedFiles = [];
  bulkDownloadIntervalId: any;
  bulkdownloadId = null;
  selectedAll = false;
  selectedWorkingPapers = [];
  zipFileName: string = '';
  showhidenotification : boolean =true;
  FileUploadList : any = [];
  columnFilters: any[] =
    [
      {
        "displayName": "DeliverableID#",
        "value": this.deliverableResultGridColumns.DeliverableID,
        "checked": true
      },
      {
        "displayName": "ReportingEntity#",
        "value": this.deliverableResultGridColumns.ReportingEntity,
        "checked": true
      },
      {
        "displayName": "Description#",
        "value": this.deliverableResultGridColumns.Description,
        "checked": true
      },
      {
        "displayName": "DeliverableDate#",
        "value": this.deliverableResultGridColumns.DeliverableDate,
        "checked": true
      },
      {
        "displayName": "DeliverableTypeID#",
        "value": this.deliverableResultGridColumns.DeliverableTypeID,
        "checked": true
      },
      {
        "displayName": "DeliverableReleaseDate#",
        "value": this.deliverableResultGridColumns.DeliverableReleaseDate,
        "checked": true
      },
      {
        "displayName": "GroupAuditReportReleaseDate#",
        "value": this.deliverableResultGridColumns.GroupAuditReportReleaseDate,
        "checked": true
      },
      {
        "displayName": "DeliverableTypeDescription#",
        "value": this.deliverableResultGridColumns.DeliverableTypeDescription,
        "checked": true
      },
      {
        "displayName": "RecordOfIssuanceName#",
        "value": this.deliverableResultGridColumns.RecordOfIssuanceName,
        "checked": true
      },
      {
        "displayName": "ROIStatus#",
        "value": this.deliverableResultGridColumns.ROIStatus,
        "checked": true
      },
      {
        "displayName": "RoiNumber#",
        "value": this.deliverableResultGridColumns.RoiNumber,
        "checked": true
      },
      {
        "displayName": "ROISize#",
        "value": this.deliverableResultGridColumns.ROISize,
        "checked": true
      },
      {
        "displayName": "ROIUpdates#",
        "value": this.deliverableResultGridColumns.ROIUpdates,
        "checked": true
      },
      {
        "displayName": "DeliverableName#",
        "value": this.deliverableResultGridColumns.DeliverableName,
        "checked": true
      },
      {
        "displayName": "DeliverableStatus#",
        "value": this.deliverableResultGridColumns.DeliverableStatus,
        "checked": true
      },
      {
        "displayName": "DeliverableSize#",
        "value": this.deliverableResultGridColumns.DeliverableSize,
        "checked": true
      },
      {
        "displayName": "ArchivedBy#",
        "value": this.deliverableResultGridColumns.ArchivedBy,
        "checked": true
      },
      {
        "displayName": "ArchiveDate#",
        "value": this.deliverableResultGridColumns.ArchiveDate,
        "checked": true
      },
      {
        "displayName": "DeliverableDriveDueDate#",
        "value": this.deliverableResultGridColumns.DeliverableDriveDueDate,
        "checked": true
      },
      {
        "displayName": "BarCode#",
        "value": this.deliverableResultGridColumns.BarCode,
        "checked": true
      },
      {
        "displayName": "HardCopyFileStatus#",
        "value": this.deliverableResultGridColumns.HardCopyFileStatus,
        "checked": true
      },
      {
        "displayName": "DeletedBy#",
        "value": this.deliverableResultGridColumns.DeletedBy,
        "checked": true
      },
      {
        "displayName": "IncludeInCalculation#",
        "value": this.deliverableResultGridColumns.IncludeInCalculation,
        "checked": true
      },
      {
        "displayName": "ROIFileVerificationStatusId#",
        "value": this.deliverableResultGridColumns.ROIFileVerificationStatusId,
        "checked": true
      },
      {
        "displayName": "DeliveableFileVerificationStatusId#",
        "value": this.deliverableResultGridColumns.DeliveableFileVerificationStatusId,
        "checked": true
      },
      {
        "displayName": "ROIFileVerificationStatus#",
        "value": this.deliverableResultGridColumns.ROIFileVerificationStatus,
        "checked": true
      },
      {
        "displayName": "ROIFailedDescription#",
        "value": this.deliverableResultGridColumns.ROIFailedDescription,
        "checked": true
      },
      {
        "displayName": "DeliverableFileVerificationStatus#",
        "value": this.deliverableResultGridColumns.DeliverableFileVerificationStatus,
        "checked": true
      },
      {
        "displayName": "DeliverableFailedDescription#",
        "value": this.deliverableResultGridColumns.DeliverableFailedDescription,
        "checked": true
      },
      {
        "displayName": "IsMATROI#",
        "value": this.deliverableResultGridColumns.IsMATROI,
        "checked": true
      },
      {
        "displayName": "ROIFileStatus#",
        "value": this.deliverableResultGridColumns.ROIFileStatus,
        "checked": true
      },
      {
        "displayName": "DeliverableFileStatus#",
        "value": this.deliverableResultGridColumns.DeliverableFileStatus,
        "checked": true
      }
    ]


  @ViewChild('DRDDatePicker', { read: MatInput, static: false }) DRDDatePicker: MatInput;
  @ViewChild('DDDatePicker', { read: MatInput, static: false }) DDDatePicker: MatInput;
  @ViewChild('CeasedDatePicker', { read: MatInput, static: false }) CeasedDatePicker: MatInput;
  @ViewChild('ROIFileUpload', { static: false }) inputROIFileUploadVariable: ElementRef;
  @ViewChild('DeliverableFileUpload', { static: false }) inputDeliverableFileUploadVariable: ElementRef;
  @ViewChild("NonMatForm", { static: false }) nonMatForm: NgForm;
  RejectedReasonForm: FormGroup;
  add_del_form: FormGroup;
  add_del_dd_form: FormGroup;
  add_del_drd_form: FormGroup;
  add_del_grd_form: FormGroup;
  formError: { [id: string]: string };
  private validationMessages: { [id: string]: { [id: string]: string } };
  Message: string;
  IsEditDeliverables: boolean = false;
  priorToCompletion: boolean = undefined;
  priorToCompletiondate: boolean = undefined;
  priorToCompletion1: boolean = undefined;
  EngDecisionYesCss: any;
  EngDecisionNoCss: any;
  QuestionBottomBarCss: any;
  priorToCompletionCss: any;
  EngagementCeasedDate: Date = undefined;
  EngagementFieldRelated: Date = undefined;
  btnpriorToCompletion: boolean = true;

  UserName = this.adalSvc.LoggedInUserName;
  userEmail = this.adalSvc.LoggedInUserEmail;
  euserAlias = this.userEmail.replace("@deloitte.com", "");
  IschkBoxClientName: boolean = true;
  divROIDeliverabledetails: boolean[] = [];
  divEntityDeliverabledetails: boolean[] = [];

  //Assigning variable for Dropdown
  DeliverableType: number;
  Deliverabletypes: any;
  MATDeliverabletypes: any;
  MATDeliverableDesc: any;
  DeliverableTypeName: string

  //Adding Deliverable

  RecordOfIssuanceName: string = '';
  ROISize: number = 0;
  MATROIFlag: number = 0;
  DeliverableName: string = ""
  HardCopyStatus: string = ""
  DeliverableSize: number = -1;
  ArchiveNumber: string
  ClientName: string
  DeliverableTypeID: number = 0;
  Description: string
  ReportingEntity: string
  CreatedBy: any;
  displayLandingPageForEngagement: boolean = false;
  isHardCopyScenario: number = 0;
  DeliverableArchiveFileID: number = 0;
  ROIFileID: number = 0;
  displayRibbonForEngagement: boolean = false;
  displayLandingPage: boolean = false;
  displyaDeliverables: boolean = false;
  expand: boolean[] = [];
  expand1: boolean[] = [];
  collapse: boolean[] = [];
  collapse1: boolean[] = [];
  DeliverablesCount: number = 0;
  DeliverablesData: any;
  ReportingEntitytextareacount: number = 180;
  Descriptiontextareacount: number = 180;
  deliverableID: number = 0;
  maxlength: number = 250;
  isApprover: boolean = false;
  EEDEngDecisionYesCss: any;
  EEDEngDecisionYesCss1: any;
  EEDEngDecisionNoCss: any;
  EEDEngDecisionNoCss1: any;
  EEDpriorToCompletionCss: any;
  EEDpriorToCompletionCss1: any;
  EEDNoTextPositionCss: any;
  EEDNoTextPositionCss1: any;
  EEDNoPositionCss: any;
  EEDNoPositionCss1: any;
  btnEEDpriorToCompletion: boolean = false;
  btnEEDpriorToCompletion1: boolean = false;

  rejectedDate: Date;
  // displayNoEngagementRibbon: boolean =false

  //No Deliverables
  DisplayReason: string = '';
  commentCategoryId: number = 3;
  employeeUniqueIdentifier: string = "";
  isLoaded = false;
  displayNoDeliverableRibbon: boolean = false;
  displayNoDeliverableClick: boolean = false;

  // Flags for internal logic
  isEngagementYesNo: boolean = false;
  isNoDeliverableClick: boolean = false;

  // ROI Grid
  sortByEnum: any = matROIGridDataSortBy;
  dtPickerEnum: any = ROIDateRangePicker;
  matROIGridData: any[];
  pageSize: number = 10;
  pageCount: number = 1;
  pageArray = Array();
  totalMATROIs: number = -1;
  deliverableCurrentPageNumber: number = 1;
  matROICurrentPageNumber: number = 1;
  sortBy: number = this.sortByEnum.SortBy_ReportingEntity_Asc;
  hoverIndex: number = -1;
  filterBy: number = 1;
  filterText: string = '';
  appendArchiveToGrid: boolean = false;

  ModeOfOperation: string
  //Fileupload functionality
  ROIfileId: string = "";
  DeliverablefileId: string = "";
  acceptedMIMETypes: any;
  fileName: string;
  fileSize: string = "";
  sunits: string = "";
  verificationInProgressStatus = [0, 1, 2, 5];
  verifiedROIS: any = [];
  unverifiedROIS: any = [];
  verifiedDeliverables: any = [];
  unverifiedDeliverables: any = [];
  roiArchiveFileId: string;
  roiFileTransferId: string;
  roiResponseMessage: string;
  deliverableArchiveFileId: string;
  deliverableFileTransferId: string;
  deliverableResponseMessage: string;
  roiS3FileName: string;
  deliverableS3FileName: string;
  module: string = "deliverables";
  legalHoldStatus: string;
  isArchiveDestroyed:number = 0;

  //Added newly to diable editing the deiverable to archive team except for the archive approver
  ShowContentForEditDeliverables: number = 0;
  CurrentArchiveStatusforDeliverables: any;
  DisableSelectCheckboxes: boolean;

  //Substantive Resubmission
  ResubmissionReason: any = "";
  ResubmissionDeliverableActionType: any = "";
  IsEngagementDecisions: boolean = true;
  //Substantive Resubmission

  //Delete Variables
  ROIarchiveFileIdToBeDeleted: string = "";
  ROIfileNameToBeDeleted: string = "";
  ROIs3fileNameToBeDeleted: string = "";
  DeliverablearchiveFileIdToBeDeleted: string = "";
  DeliverablefileNameToBeDeleted: string = "";
  Deliverables3fileNameToBeDeleted: string = "";
  fileTypeIdToBeDeleted: number = 0;
  //End of Delete Variables

  //ROI file details
  //SelectedROI:boolean;

  FileSelectionFlag: boolean;
  ROIDeliverableType: string;
  ROIID: number;
  IsMatROI: boolean;
  GroupAuditReleaseDate: Date;

  MatRadioid: boolean;
  ROIMetadataid: number;
  ROINumber: string;
  private _interimReviewNoReportIssued: string = 'Interim Review - No Report Issued';
  roleMapping = new UserActions();
  roiEditMode: number;
  private _subject: BehaviorSubject<string> = new BehaviorSubject<string>("");
  updateedcd: boolean;
  etagId: string;
  IsMaxDate: boolean;
  id: any;
  displayLoading: any;
  isSectionApproved: boolean = false;
  roitooltip: string;
  deliverabletooltip: string;
  DisableSelectallCheckbox: boolean;
  currentModule: any;
  showMarorDelete: boolean = true;

  constructor(private modalService: ModalService, private route: Router, private stsserviceService: StsserviceService,
    private deliverableservice: DeliverableService, private notifier: NotifierService,
    private archiveHomeService: ArchiveHomeService,
    private _uploadEventService: FileUploadEventService,
    private _bdownloadEventService: BulkdownloadEventService,
    private _service: WorkingPaperService,
    private routeValue: ActivatedRoute, private archiveInfoService: archiveInfoService, private SpinnerService: NgxSpinnerService, private adalSvc: MsAdalAngular6Service,
    private fb: FormBuilder, private activatedRoute: ActivatedRoute, private router: Router,
    private _fileUploadRecordService: FileUploadRecordService, private _fuService: FielUploadService,
    private _fuEventService: FileUploadEventService, private _wservice: WorkingPaperService, private pubsub: PubsubService, private sharedService: SharedService,
    private archiveService: ArchiveService) {
    this.add_del_form = fb.group({
      'ECD': [null, [Validators.required, Validators.pattern('[0-9]{2}/[0-9]{2}/[0-9]{4}')]],
      'EED': [null, [Validators.required, Validators.pattern('[0-9]{2}/[0-9]{2}/[0-9]{4}')]]
    });

    this.add_del_dd_form = fb.group({
      'DRD': [null, [Validators.required, Validators.pattern('[0-9]{2}/[0-9]{2}/[0-9]{4}')]],
    });

    this.add_del_drd_form = fb.group({
      'DRD2': [null, [Validators.required, Validators.pattern('[0-9]{2}/[0-9]{2}/[0-9]{4}')]]
    });

    this.add_del_grd_form = fb.group({
      'GDRD': [null, [Validators.required, Validators.pattern('[0-9]{2}/[0-9]{2}/[0-9]{4}')]]
    });
    var date = new Date();
    this.maxDate = { day: date.getUTCDate(), month: date.getUTCMonth() + 1, year: date.getUTCFullYear()};
  
    this.roleMapping = this.pubsub.getRoleMappingResult();
  
  }


  editorConfig: AngularEditorConfig = {

    editable: true,
    spellcheck: true,
    height: '276px',
    minHeight: '0',
    maxHeight: '100px',
    width: 'auto',
    minWidth: '0',
    translate: 'yes',
    enableToolbar: true,
    showToolbar: true,
    placeholder: 'Please enter the reason',
    defaultParagraphSeparator: '',
    defaultFontName: '',
    defaultFontSize: '',
    fonts: [
      { class: 'arial', name: 'Arial' },
      { class: 'times-new-roman', name: 'Times New Roman' },
      { class: 'calibri', name: 'Calibri' },
      { class: 'comic-sans-ms', name: 'Comic Sans MS' }
    ],

    customClasses: [
      {
        name: 'quote',
        class: 'quote',
      },
      {
        name: 'redText',
        class: 'redText'
      },
      {
        name: 'titleText',
        class: 'titleText',
        tag: 'h1',
      },
    ],
    uploadUrl: '',
    uploadWithCredentials: false,
    sanitize: true,
    toolbarPosition: 'top',
    toolbarHiddenButtons: [
      [
        'undo',
        'redo',
        'subscript',
        'superscript',
        'justifyFull',
        'indent',
        'outdent',
        'insertOrderedList',
        'heading',
        //'fontName'
      ],
      [
        'textColor',
        'backgroundColor',
        'customClasses',
        //'link',
        'unlink',
        'insertImage',
        'insertVideo',
        'insertHorizontalRule',
        'removeFormat',
        'toggleEditorMode'
      ]
    ]
  };
  ngOnInit() {
    this.archiveNumber = this.activatedRoute.snapshot.parent.paramMap.get('aN');
    this.employeeUniqueIdentifier = this.adalSvc.LoggedInUserEmail.split('@')[0];
    
    /* For Legal Hold applied on Archives */
    if(localStorage.getItem('archiveInfoData') !=''){
    var data = JSON.parse(localStorage.getItem('archiveInfoData'));
    this.legalHoldStatus = data.legalHoldStatus;
    this.isArchiveDestroyed = data.isDestroyed;
    }else{
      this.archiveInfoService.getArchiveInfo(this.archiveNumber, this.employeeUniqueIdentifier).subscribe(
        (info) => {
          localStorage.setItem('archiveInfoData', JSON.stringify(info));
          this.legalHoldStatus = info.legalHoldStatus;
          this.isArchiveDestroyed = info.isDestroyed;
        }
      );
    }
    /* For Legal Hold applied on Archives */
    localStorage['IsSectionVisited'] = '0';
    console.log("LocalStorage ReSet to 0 in Del for AR (582):", localStorage['IsSectionVisited']);
    //Removing this api call as part of duplicate api calls PE issue
    //this.GetDeliverablesByArchiveNumber(this.archiveNumber);
    this._uploadEventService.currentModule = "deliverables";
    this.currentModule="deliverables";

    //================================= Start: File Upload ===========================

    //FileUploadStep 12:
    //Update the uploaded status in DB and refresh the working papers list
    this._fuEventService.getfileUploadStatus.subscribe(fileArrayObject => {
      var self=this;
      if(fileArrayObject.module!=self.currentModule)
      return;
      debugger;
      if (fileArrayObject) {

        if(fileArrayObject.module !== 'deliverables'){
          this.FileUploadList = [];
        }

        let etag = "";
        if (fileArrayObject.eTag) {
          etag = fileArrayObject.eTag.substr(1, fileArrayObject.eTag.length - 2);
          this.FileUploadList.push(etag);
        }

        let fuparams = {
          ArchiveFileId: fileArrayObject.metaData.archiveFileId,
          FileTransferId: fileArrayObject.metaData.fileTransferId,
          FileUploadStatusCode: fileArrayObject.uploadStatus,
          ETag: etag,
          UploadId: fileArrayObject.uploadId,
          FailedDescription: fileArrayObject.errorMessage,
          ArchiveNumber: this.archiveNumber
        };

        console.log("updating in DB");
        console.log(fuparams);

        this._wservice.CreateOrUpdateWorkingPaper(fuparams).subscribe(response => {
          console.log("updated in DB");
          console.log(response);

          //Update the working papers upload files list on file upload success
          if (fileArrayObject.uploadStatus == "success") {
            this._wservice.GetWorkingPapersByArchiveFileId(response.archiveFileId, this.archiveNumber).subscribe(data => {
              if (this.verificationInProgressStatus.includes(data.fileVerificationStatusId)) {
                this.unverifiedDeliverables.unshift(data);
              }
              else {
                this.verifiedDeliverables.unshift(data);
              }
            },
              err => {
                console.log("failed to refresh Deliverables");
              }

            );
          }
          debugger;
          if (this.Message !== undefined && this.Message !== "" && (this.FileUploadList.length === 2 || this.IsMatROI )) {
            this.notifier.notify("success", this.Message);
            this.Message = "";
            //setTimeout(() => this.GetDeliverablesByArchiveNumber(this.archiveNumber),2000);
            this.GetDeliverablesByArchiveNumber(this.archiveNumber);
            this.FileUploadList = [];
          }
         
        },
          err => {
            console.log("failed to update in Deliverables DB");
            console.log(err);
          });
      }
    });
    this.initialize();
    this._subject.pipe(
      distinctUntilChanged(),
      debounceTime(500),
    ).subscribe(value => this.searchROI(value))
  }

  ngDoCheck() {
    this.roleMapping = this.pubsub.getRoleMappingResult();
  }

  OnClick(PageUrl) {
    if(PageUrl.type != 'click')
    this.router.navigate(["/" + PageUrl + ""]);
  }
  
  HideorShowlogic() {
    debugger;
    var archiveStatusHome: string = this.CurrentArchiveStatusforDeliverables;
    switch (archiveStatusHome) {
      case 'Ready For Approval': {
        this.archiveHomeService.GetArchiveApproverForArchiveSubmission(this.archiveNumber, this.roleMapping.roleId).subscribe(data => {
          if (data) {
            console.log('GetArchiveApproverForArchiveSubmission-Deliverables', data.canApprove);
            this.isApprover = data.canApprove;
          }
          if (this.isApprover) {
            this.commonViewForEdit();
            this.specificViewToApprover();
          }
          else {
            this.showMarorDelete=false;
            this.commonViewForReadonly();
          }
        });
        break;
      }
      case "Resubmitted - Ready for Approval": {
        this.GetResubmissionApprovalFlow();

        break;
      }

      /* common for Open, Resubmitted – Open*/
      case 'Open': {
        this.commonViewForEdit();
        break;
      }
      case "Resubmitted – Open": {
        this.commonViewForEdit();
        this.archiveHomeService.GetResubmissionReasonsforArchive(this.archiveNumber).subscribe(data => {
          if (data) {
            if (data.length > 0) {
              this.DeliverablesEditedInResubmit = data[2].actionTypeId == 3 ? true : false;
              this.DeliverablesProvidedInResubmit = data[2].comments != "" ? data[2].comments : "";
              this.DeliverablesEditedDate = data[2].rejectedDate;
            }
          }
        });
        break;
      }
      /*End common for Open, Resubmitted – Open*/

      /*Common for Approved, Resubmitted – Approved and Resubmitted - Rejected */
      case "Approved": {
        this.legalHoldStatus = '';
        this.commonViewForReadonly();
        break;
      }
      case "Resubmitted – Approved": {
        this.legalHoldStatus = '';
        this.commonViewForReadonly();
        break;
      }
      case "Resubmitted - Rejected": {
        if (this.roleMapping.roleId == 11 || this.roleMapping.roleId == 12) {
          this.commonViewForReadonly();
        }
        else {
          this.commonViewForEdit();
        }
        break;
      }
      /*End Common for Approved, Resubmitted – Approved and Resubmitted - Rejected */

      case "Rejected":
        {
          this.commonViewForEdit();
          break;
        }

    }


  }
  specificViewToApprover() {
    this.ApproveDisabled = false;
    this.RejectDisabled = false;
    this.hideAddBotton = false;
    this.hideRefreshROIBotton = false;
  }
  //Method For Open and Resubmitted – Open
  commonViewForEdit() {
    this.ShowContentForEditDeliverables = 1;
    this.hideAddBotton = false;
    this.hideRefreshROIBotton = false;
  }
  //End Method For Open and Resubmitted – Open
  //Method for Approved, Rejected, Resubmitted - Approved and Resubmitted - Rejected
  commonViewForReadonly() {
    this.ShowContentForEditDeliverables = 0;
    this.DisableSelectCheckboxes = true;
    this.DisableSelectallCheckbox =true;
    this.hideAddBotton = true;
    this.hideRefreshROIBotton = true;
  }

  //End of Method for Approved, Rejected, Resubmitted - Approved and Resubmitted - Rejected

  initialize() {
    var self = this;

    this.hideRejectedLabel = true;
    this.hideRejectedMessage = true;
    this.ArchiveNumber = this.archiveNumber;
    this.hidechangeDecision = true;
    this.DeliverableType = 0;
    this.originalComments = undefined;
    this.MatRadioid = false;
    self.GetDeliverablesByArchiveNumber(this.archiveNumber);
    //this.GetDeliverablesCountByArchiveNumber(this.ArchiveNumber);
    //update working papers for every 30 secs

    self.GetMatROIUpdateStatus(this.ArchiveNumber);
    // var wpIntervalId = setInterval(function () {
    //   self.GetDeliverablesByArchiveNumber(this.archiveNumber);
    // }, 60000);
    this.IsUserApprover(this.archiveNumber, this.euserAlias)
    // this.Descriptiontextareacount = 180;
    this.CreatedBy = this.adalSvc.LoggedInUserEmail.split('@')[0];
    this.getDefaultState();

  }
  IsUserApprover(archivenumber, userlias) {

    this.deliverableservice.IsUserApprover(archivenumber, userlias).subscribe(
      (data) => {
        debugger;
        if (data != undefined) {
          this.isApprover = data.canApprove;
          this.CurrentArchiveStatusforDeliverables = data.archiveInfo.archiveStatus;
          //Added newly to diable editing the deiverable to archive team except for the archive approver
          //ShowContentForEditDeliverables will hide
          //DisableSelectCheckboxes will disable the Select all & individual checkboxes for each deliverable added.
          // debugger;
          this.HideorShowlogic();

        }
        setTimeout(() => { this.DeliverableDetails(archivenumber) }, 1000);
      });
  }
  GetResubmissionApprovalFlow() {
    debugger;
    var inparameters = {
      "ArchiveNumber": this.archiveNumber,
      "UserAlias": ''
    }
    var parameters = JSON.stringify(inparameters);
    this.archiveHomeService.GetResubmissionApprovalFlowStatuses(parameters).subscribe(
      (obj) => {
        debugger;
        this.isApprover = obj[0].canApprove;
        let isApprover = obj[0].canApprove;
        if (obj[0].completedApprovel >= 1) {
          this.isFirstlvlApproved='Nochange'
          this.isApprover = false;
        }
        // else if (obj[0].completedApprovel == 0) {
        //   if (localStorage['isFirstLevelEdited'] == "null" || localStorage['isFirstLevelEdited'] == 0)
        //     this.isApprover = false;
        // }
        this.archiveHomeService.GetResubmissionReasonsforArchive(this.archiveNumber).subscribe(data => {
          if (data) {
            if (data.length > 0) {
              this.DeliverablesEditedInResubmit = data[2].actionTypeId == 3 ? true : false;
              this.DeliverablesProvidedInResubmit = data[2].comments != "" ? data[2].comments : "";
              this.DeliverablesEditedDate = data[2].rejectedDate;
            }
          }
        });
        //Added from outside of the method to inside
        if (this.isApprover) {
          this.commonViewForEdit();
          this.specificViewToApprover();
        }
        else {
          this.showMarorDelete=false;
          this.commonViewForReadonly();
        }

        if (isApprover && (obj[0].completedApprovel == 1 || obj[0].completedApprovel == 2)) {
          this.hideRefreshROIBotton = false;
        }
        // this.ShowContentForEditDeliverables = 1;
        // this.DisableSelectCheckboxes = false;
      },
      (err) => {
        console.log("error is ", err)
      }
    );

  }

  getDefaultState() {
    this.isDefaultResult = this.searchtextvalue.length < 3 && this.searchtextvalue.trim().length < 3 && this.filterarray.length == 0;
    // console.log("Resulet Set State=========");
    // console.log("this.searchtextvalue:" + this.searchtextvalue);
    // console.log("this.filterarray.length:" + this.filterarray.length);
    // console.log("totalMATROIs" + this.totalMATROIs);
    // console.log(this.isDefaultResult);
  }

  sortOrderChanged(event) {
    // debugger;
    this.resetPage();
    this.sortBy = parseInt(event.target.value);
    this.getMatROI();
  }

  toggle() {
    this.show = !this.show;
    this.lastUpdatedDtShow = false;
    this.deliverableDtShow = false;
    this.deliverableReleaseDtShow = false;
    this.showhidenotification=true;
  }
  ShowROIUpdateTipToggle() {
    this.isShowROIUpdateTipBox = false;
  }

  SaveLastUpdatedDate(event) {
    if (event != undefined) {
      this.lastUpdatedDate = "";
      if (event[0].fromdate != "" && event[1].todate != "") {
        this.lastUpdatedDateFrom = this.getDateInMySQLFomat(event[0].fromdate);
        this.lastUpdatedDateTo = this.getDateInMySQLFomat(event[1].todate);
        this.lastUpdatedDate = event[0].fromdate + " — " + event[1].todate;
        console.log("lastUpdatedDate:" + this.lastUpdatedDate);
      }
    }
  }

  filterList(isAddFilter: boolean, textToFilter: string, isCommitFilter: boolean = false, isFilterPrefix: number = 0) {

    if (isAddFilter) {
      if (isCommitFilter && this.filterarray) {
        if (textToFilter != undefined) {
          var filterPrefix = this.searchParamDTPrefix;
          var filterPrefixString = "";
          if (isFilterPrefix == 1) {
            filterPrefix = this.searchParamDRDPrefix;
          }
          else if (isFilterPrefix == 2) {
            filterPrefix = this.searchParamDDPrefix;
          }
          else if (isFilterPrefix == 3) {
            filterPrefix = this.searchParamLUPPrefix;
          }
          filterPrefixString = filterPrefix + textToFilter;
          this.deleteItemFromFilterArray(filterPrefix);
          this.filterarray.push(filterPrefixString);
          this.checkBasicSearch();
        }
      }
    }
  }

  checkBasicSearch() {
    if (this.filterarray && this.filterarray.length > 0) {
      this.filterarray.forEach(textToFilter => {
        if (textToFilter.includes(this.searchParamDTPrefix)
          || textToFilter.includes(this.searchParamLUPPrefix)
          || textToFilter.includes(this.searchParamDDPrefix)
          || textToFilter.includes(this.searchParamDRDPrefix)
        ) {
          this.isBasicShow = false;
        }
        else {
          this.isBasicShow = true;
        }
      });
    }
    else {
      this.isBasicShow = true;
    }
  }

  deleteItemFromFilterArray(msg: string) {
    if (this.filterarray && this.filterarray.length > 0) {
      this.filterarray.forEach(textToFilter => {
        if (textToFilter.includes(msg)) {
          const index: number = this.filterarray.indexOf(textToFilter);
          if (index !== -1) {
            this.filterarray.splice(index, 1);
          }
        }
      });
    }
  }
  onKeyup(): void {
    let term = this.searchtextvalue;
    this._subject.next(term ? term.trim() : "");
  }
  searchROI(searchText: string) {
    if (!searchText) searchText = "";
    this.isDefaultResult = false;
    this.matROIGridData = [];
    this.totalMATROIs = -1;
    this.FileSelectionFlag = false;
    this.getDefaultState();

    if (this.searchtextvalue && this.searchtextvalue.trim() != '' && this.searchtextvalue.trim().length >= 3) {
      this.isInputSearchResult = false;
      this.getMatROI();

      console.log("*****************************Start*******");
      console.log("this.isDefaultResult:  " + this.isDefaultResult);
      console.log("this.isLoadedResult: " + this.isLoadedResult);
      console.log("this.totalMATROIs:  " + this.totalMATROIs);
      console.log("Condition: " + !this.isDefaultResult && this.isLoadedResult && this.totalMATROIs == 0);
      console.log("*****************************End*******");

    }
    else {
      return false;
    }
  }


  removeparam(event, searchparam: any, index: any) {
    if(searchparam.includes('Deliverable Release date')) {
      this.eventValueDRD = '';
    } 
    if(searchparam.includes('Deliverable date')) {
      this.eventValueDD = '';
    } 
    if(searchparam.includes('Last Updated date')) {
      this.eventValueDLU = '';
    } 
    this.matROIGridData = [];
    this.totalMATROIs = -1;
    this.FileSelectionFlag = false;
    this.isDefaultResult = false;
    this.paramindex = index;
    this.filterarray.splice(this.paramindex, 1);

    if (searchparam.includes(this.searchParamDTPrefix)) {
      this.DeliverableType = null;
      this.DeliverableTypeName = '';
    }

    if (searchparam.includes(this.searchParamDDPrefix)) {
      this.lastDeliverableDate = '';
      this.lastDeliverableDateFrom = '';
      this.lastDeliverableDateTo = '';
    }

    if (searchparam.includes(this.searchParamDRDPrefix)) {
      this.lastDeliverableReleaseDate = '';
      this.lastDeliverableReleaseDateFrom = '';
      this.lastDeliverableReleaseDateTo = '';
    }

    if (searchparam.includes(this.searchParamLUPPrefix)) {
      this.lastUpdatedDate = '';
      this.lastUpdatedDateFrom = '';
      this.lastUpdatedDateTo = '';
    }

    this.checkBasicSearch();

    if (this.filterarray.length > 0) {
      this.getMatROI();
    }

    //result set
    this.getDefaultState();
  }

  resetfilter() {

    // mat grid
    this.matROIGridData = [];
    this.totalMATROIs = -1;
    this.FileSelectionFlag = false;
    this.isDefaultResult = false;

    // search param
    this.searchtextvalue = '';
    this._subject.next('');
    this.filterarray = [];

    // dropdown clear
    this.DeliverableType = null;
    this.DeliverableTypeName = '';

    this.lastDeliverableDate = '';
    this.lastDeliverableDateFrom = '';
    this.lastDeliverableDateTo = '';

    this.lastDeliverableReleaseDate = '';
    this.lastDeliverableReleaseDateFrom = '';
    this.lastDeliverableReleaseDateTo = '';

    this.lastUpdatedDate = '';
    this.lastUpdatedDateFrom = '';
    this.lastUpdatedDateTo = '';

    this.eventValueDRD = '';
    this.eventValueDD = '';
    this.eventValueDLU = '';

    // call default and isBasic
    this.getDefaultState();
    this.checkBasicSearch();
  }

  searchBtnClicked(event) {
    this.filterarray = [];
    this.totalMATROIs = -1;
    this.matROIGridData = [];
    this.searchtextvalue = '';
    this._subject.next('');
    this.isLoadedResult = false;

    //// debugger;
    if ((this.DeliverableTypeName || this.lastUpdatedDate || this.lastDeliverableDate || this.lastDeliverableReleaseDate) && this.filterarray) {

      // deliverable type
      if (this.DeliverableTypeName != '' && !this.filterarray.includes(this.DeliverableTypeName)) {
        this.filterList(true, this.DeliverableTypeName, true, 0);
      }

      // deliverable release date
      if (this.lastDeliverableReleaseDate != '' && !this.filterarray.includes(this.lastDeliverableReleaseDate)) {
        this.filterList(true, this.lastDeliverableReleaseDate, true, 1);
      }

      // deliverable date
      if (this.lastDeliverableDate != '' && !this.filterarray.includes(this.lastDeliverableDate)) {
        this.filterList(true, this.lastDeliverableDate, true, 2);
      }

      // Last updated date
      if (this.lastUpdatedDate != '' && !this.filterarray.includes(this.lastUpdatedDate)) {
        this.filterList(true, this.lastUpdatedDate, true, 3);
      }

      this.toggle();
      this.getMatROI();
    }
    else {
      return false;
    }
  }
  
  DtPickerFormatDRD(event)
  {
    console.log("==========DtPickerFormatDRD", event);
    this.eventValueDRD = event;
  }

  DtPickerFormatDD(event)
  {
    console.log("==========DtPickerFormatDD", event);
    this.eventValueDD = event;
  }

  DtPickerFormatDLU(event)
  {
    console.log("==========DtPickerFormatDLU", event);
    this.eventValueDLU = event;
  }

  SaveDeliverableReleaseDate(event) {
    console.log("SATTTTTTTT",event);
    // debugger;
    this.lastDeliverableReleaseDate = "";
    if (event != undefined && event !='' && event != null) {
      if (event[0].fromdate != "" && event[1].todate != "") {
        this.lastDeliverableReleaseDateFrom = this.getDateInMySQLFomat(event[0].fromdate);
        this.lastDeliverableReleaseDateTo = this.getDateInMySQLFomat(event[1].todate);
        this.lastDeliverableReleaseDate = event[0].fromdate + " — " + event[1].todate;
        console.log("lastDeliverableReleaseDate:" + this.lastDeliverableReleaseDate);
      }
    }
  }

  getDateInMySQLFomat(date: string) {
    // current date format
    // date.split("/")[0] -- mm
    // date.split("/")[1] -- dd
    // date.split("/")[2] -- yyyy

    // db requried format {yyyy-mm-dd} ex: 2017-10-26
    return date.split("/")[2] + "-" + date.split("/")[0] + "-" + date.split("/")[1];
  }

  SaveDeliverableDate(event) {
    // debugger;
    if (event != undefined) {
      this.lastDeliverableDate = "";
      if (event[0].fromdate != "" && event[1].todate != "") {
        this.lastDeliverableDateFrom = this.getDateInMySQLFomat(event[0].fromdate);
        this.lastDeliverableDateTo = this.getDateInMySQLFomat(event[1].todate);
        this.lastDeliverableDate = event[0].fromdate + " — " + event[1].todate;
        console.log("lastDeliverableDate:" + this.lastDeliverableDate);
      }
    }
  }

  DatePickerToggle(pickerEnum: number) {
    if (this.dtPickerEnum.DeliverableReleaseDtEnum == pickerEnum)
      this.DeliverableReleaseDtToggle();
    else if (this.dtPickerEnum.DeliverableDtEnum == pickerEnum)
      this.DeliverableDtToggle();
    else if (this.dtPickerEnum.LastUpdatedDtEnum == pickerEnum)
      this.LastUpdatedDtToggle();
  }

  LastUpdatedDtToggle() {
    this.lastUpdatedDtShow = !this.lastUpdatedDtShow;
    this.deliverableDtShow = false;
    this.deliverableReleaseDtShow = false;
  }

  DeliverableDtToggle() {
    this.lastUpdatedDtShow = false;
    this.deliverableDtShow = !this.deliverableDtShow;
    this.deliverableReleaseDtShow = false;
  }

  DeliverableReleaseDtToggle() {
    this.lastUpdatedDtShow = false;
    this.deliverableDtShow = false;
    this.deliverableReleaseDtShow = !this.deliverableReleaseDtShow;
  }

  DeliverableDetails(archivenumber: string) {
    this.disabledColor = {
      'background': '#007CB0'
    };
    this.archiveHomeService.Getsectioncomments(archivenumber, 3, 2).subscribe(
      //this.deliverableservice.GetDeliverablesDetails(archivenumber).subscribe(
      (data) => {
        debugger;
        //if(this.CurrentArchiveStatusforDeliverables != "Resubmitted - Ready for Approval"){
        if (data.comments != "") {
          this.rejectedComments = data.comments;
          this.originalComments = data.comments;
          // this.BodyCount=250-data.comments.length;
          this.RejectDisabled = true;
          this.ApproveDisabled = true;
          this.rejectedBy = data.rejectedBy;
          this.rejectedDate = data.rejectedDate;
          this.hideRejectedLabel = false;
          this.hideRejectedMessage = false;
          if (this.isApprover) {
            this.hidechangeDecision = false;
          }
          this.topCss = {
            'top': '145px'
          };
        }
        else {
          this.topCss = {
            'top': '0px'
          };
          if (data.isSectionApproved === 1) {
            this.hideRejectedLabel = true;
            this.hideRejectedMessage = true;
            this.isSectionApproved = true;
            if (this.isApprover) {
              this.hidechangeDecision = false;
            }
            this.RejectDisabled = true;
            this.ApproveDisabled = true;
          }
          else {
            this.isSectionApproved = false;
          }
        }
        //}
        if (this.CurrentArchiveStatusforDeliverables == "Approved" || this.CurrentArchiveStatusforDeliverables == "Resubmitted – Approved" || this.CurrentArchiveStatusforDeliverables == "Resubmitted - Rejected") {
          this.hidechangeDecision = true;
        }

      });

    this.CreatedBy = this.euserAlias;

    this.GetClientNameDetails(this.ArchiveNumber);
  }

  ExpansionCollapse(Action, id) {
    if (Action === 'plus') {
      this.expand[id] = true;
      this.collapse[id] = false;
      this.divROIDeliverabledetails[id] = true;
    }
    if (Action === 'minus') {
      this.expand[id] = false;
      this.collapse[id] = true;
      this.divROIDeliverabledetails[id] = false;
    }
    if (Action === 'FullEntity') {
      // debugger;
      this.collapse1[id] = true;

    }
    if (Action === 'LessEntity') {
      this.collapse1[id] = false;

    }
    if (Action === 'Fulldescription') {
      this.expand1[id] = true;

    }
    if (Action === 'Lessdescription') {
      // debugger;
      this.expand1[id] = false;

    }
  }

  EngagementTerminatedDecision(option) {
    if (option === true) {
      this.EngDecisionYesCss = {
        'height': '171px',
        'border-color': '#007CB0'
      };
      this.EngDecisionNoCss = {
        'top': '275px'
      }
      this.QuestionBottomBarCss = {
        'bottom': '-275px'
      }
      if (this.EngagementCeasedDate == undefined) {
        this.priorToCompletionCss = {
          'background-color': '#BBBCBC'
        }
        this.btnpriorToCompletion = true;
      }
      else {
        this.btnpriorToCompletion = false;
      }
    }
    else if (option === false) {
      this.EngDecisionYesCss = {
        'height': '88px'
      };
      this.EngDecisionNoCss = {
        'top': '196px',
        'border-color': '#007CB0'
      }
      this.QuestionBottomBarCss = {
        'bottom': '-190px'
      }
      this.priorToCompletionCss = {
        'background-color': '#007CB0'
      }
      this.EngagementCeasedDate = undefined;
      this.btnpriorToCompletion = false;
    }
    else {
      this.EngagementCeasedDate = undefined;
      this.priorToCompletionCss = {
        'background-color': '#BBBCBC'
      }
      this.btnpriorToCompletion = true;
      this.EngDecisionYesCss = {
        'height': '88px',
        'border-color': '#E6E6E6'
      }
      this.EngDecisionNoCss = {
        'top': '196px',
        'border-color': '#E6E6E6'
      }
      this.QuestionBottomBarCss = {
        'bottom': '-190px'
      }
    }
    this.priorToCompletion = option;
  }

  NavigateToHomePage()
  {
    this.router.navigate(["archive/myarchives/" + this.archiveNumber + '/archivehome']);
  }

  getDateInFormat(d: number) {
    return (d < 10 ? '0' + d : d);
  }

  convertToDateFormat(inputDate: any) {
    if (inputDate instanceof NgbDate) {
      return this.getDateInFormat(inputDate.month) + "/" + this.getDateInFormat(inputDate.day) + "/" + inputDate.year;
    }
    else {
      inputDate = new Date(inputDate);
      inputDate.setMinutes(inputDate.getMinutes() - inputDate.getTimezoneOffset());
      
      return this.getDateInFormat(inputDate.getUTCMonth()+1)  + "/" + this.getDateInFormat(inputDate.getUTCDate()) + "/" + inputDate.getUTCFullYear();
    }
  }

  onECDChange(event: any) {
    this.EngagementCeasedDate = event;
    if (this.EngagementCeasedDate != undefined) {
      this.priorToCompletionCss = {
        'background-color': '#007CB0'
      }
      this.btnpriorToCompletion = false;
    }
    else {
      this.notifier.notify("error", "Engagement Ceased Date is required")
      this.EngagementCeasedDate = undefined;
      this.btnpriorToCompletion = true;
    }
  }

  onReleaseChange(event: any) {
    this.EngagementFieldRelated = new Date(event);
    if (this.EngagementFieldRelated != undefined) {
      this.priorToCompletionCss = {
        'background-color': '#007CB0'
      }
      this.btnpriorToCompletion = false;
    }
    else {
      this.notifier.notify("error", "Date Fieldwork Related to this Archive was Substantially Completed, Date of Other Issued Communications or Letters or Group Audit Report Release Date")
      this.EngagementFieldRelated = undefined;
      this.btnpriorToCompletion = true;
    }
  }
  /* Not Used */
  /* Not Used */
  SaveEngagementCeasedDate() {
    debugger;
    var parameters = {};
    if (this.EngagementCeasedDate != undefined && this.EngagementCeasedDate != null) {
      parameters = {
        "ArchiveNumber": this.archiveNumber,
        "EarlyTerminationDate": this.convertToDateFormat(this.EngagementCeasedDate),
        "EarlyTerminated": this.priorToCompletion,
        "ModifiedBy": ''
      }
    }
    else {
      parameters = {
        "ArchiveNumber": this.archiveNumber,
        "EarlyTerminationDate": null,
        "EarlyTerminated": false,
        "ModifiedBy": ''
      }
    }
    this.deliverableservice.SaveEngagementCeasedDate(parameters).subscribe((result) => {

      // debugger;
      if (result != null && result != undefined) {
        this.updateedcd = true;
        this.GetEnagementCeasedDate();
        this.sendArchiveDueDate();

      }

    },
      (err) => {
        console.log("error", "Exception while saving Engagement Ceased Date", err)
      });
  }
  sendArchiveDueDate() {
    this.pubsub.sendduedate(this.updateedcd);
  }
  /*
    GetEngagementFieldRelatedSubstansive(){
      var parameters = {
        "ArchiveNumber": this.archiveNumber
      }
      debugger;
      this.deliverableservice.GetEngagementCeasedDateByArchiveNumber(parameters).subscribe((result) => {
        //this.displayLandingPage=true;
        if (result === null)
        {

          this.isEngagementYesNo = true;
          this.ShowhideForEngagementAndNoDeliverable();
        }
        else if (result != null && result != undefined) {

          if (result.earlyTerminationDate != null && result.earlyTerminationDate != undefined && result.earlyTerminationDate != "0001-01-01T00:00:00" && result.metadataID==1) {
            this.priorToCompletion = true;
            this.priorToCompletion1=false;
            this.EngagementCeasedDate = result.earlyTerminationDate;
            this.EEDEngDecisionNoCss = {
              'top': '275px'
            };
            this.EEDNoPositionCss = {
              'top': '372px'
            };
            this.EEDNoTextPositionCss = {
              'top': '402px'
            }
          }
          else {
            this.priorToCompletion = false;
            this.EngagementCeasedDate = undefined;
          }

          if (result.earlyTerminationDate != null && result.earlyTerminationDate != undefined && result.earlyTerminationDate != "0001-01-01T00:00:00" && result.metadataID==6) {
            this.priorToCompletion1 = true;
            this.priorToCompletion = false;
            this.EngagementFieldRelated = result.earlyTerminationDate;
            this.EEDEngDecisionNoCss = {
              'top': '275px'
            };
            this.EEDNoPositionCss = {
              'top': '372px'
            };
            this.EEDNoTextPositionCss = {
              'top': '402px'
            }
          }
          else {
            this.priorToCompletion1 = false;
            this.EngagementFieldRelated = undefined;
          }
          // this.displayLandingPageForEngagement=false;
          this.isEngagementYesNo = false;
          this.GetSubstantiation(this.archiveNumber, this.commentCategoryId);

        }

      },
        (err) => {

          this.notifier.notify("Error", "Exception while fetching Engagement Date");
          console.log("error", "Exception while fetching Engagement  Date", err);
        });
      //this.closeModalDialog('EditEngagementDecisions');
    }
    */
  GetEnagementCeasedDate() {
    debugger;
    var parameters = {
      "ArchiveNumber": this.archiveNumber
    }
    debugger;
    this.deliverableservice.GetEngagementCeasedDateByArchiveNumber(parameters).subscribe((result) => {
      //this.displayLandingPage=true;
      if (result === null) // Showing Engagement decisions with Yes and No options
      {

        this.isEngagementYesNo = true;
        this.ShowhideForEngagementAndNoDeliverable();

        // this.displayLandingPageForEngagement=true;
        //this.displayNoDeliverableRibbon = false;
        //this.displayNoDeliverableClick = false;

      }
      else if (result != null && result != undefined) {
        debugger;
        if (result.earlyTerminationDate != null && result.earlyTerminationDate != undefined && result.earlyTerminationDate != "0001-01-01T00:00:00" && result.metadataID == 1) {
          this.priorToCompletion = true;
          this.priorToCompletion1 = false;
          this.EngagementCeasedDate = result.earlyTerminationDate;
          this.EEDEngDecisionNoCss = {
            'top': '275px'
          };
          this.EEDNoPositionCss = {
            'top': '372px'
          };
          this.EEDNoTextPositionCss = {
            'top': '402px'
          }
        }
        /*else {
          this.priorToCompletion = result.earlyTerminated
          this.EngagementCeasedDate = undefined;
        }*/

        if (result.metadataID == 3) {
          debugger;
          this.priorToCompletion = false;

          if (result.earlyTerminationDate != undefined && result.earlyTerminationDate != null && result.earlyTerminationDate != '0001-01-01T00:00:00')
            this.priorToCompletion1 = true;

          this.EngagementFieldRelated = result.earlyTerminationDate;
          this.EEDEngDecisionNoCss = {
            'top': '275px'
          };
          this.EEDNoPositionCss = {
            'top': '372px'
          };
          this.EEDNoTextPositionCss = {
            'top': '402px'
          }
        }
        /* else {
           this.priorToCompletion = result.earlyTerminated
           this.EngagementCeasedDate = undefined;
         }*/
        // this.displayLandingPageForEngagement=false;
        this.isEngagementYesNo = false;
        this.GetSubstantiation(this.archiveNumber, this.commentCategoryId);

      }

    },
      (err) => {
        console.log("error", "Exception while fetching Engagement Ceased Date", err)
      });
    //  this.closeModalDialog('EditEngagementDecisions');
  }


  GetEnagementCeasedDateforEdit() {

    var parameters = {
      "ArchiveNumber": this.archiveNumber
    }
    this.deliverableservice.GetEngagementCeasedDateByArchiveNumber(parameters).subscribe((result) => {
      if (result != null && result != undefined) {
        if (result.earlyTerminationDate != null && result.earlyTerminationDate != undefined && result.earlyTerminationDate != "0001-01-01T00:00:00") {

          this.EngagementCeasedDate = result.earlyTerminationDate
          this.priorToCompletion = true;
        }
        else {

          this.EngagementCeasedDate = undefined;
          this.priorToCompletion = result.earlyTerminated
        }
        this.EEDEngagementTerminatedDecision(this.priorToCompletion);
      }
    },
      (err) => {
        console.log("error", "Exception while editing Engagement Ceased Date", err)
      });
  }

  // Get Deliverable Types
  getDeliverableTypes() {
    this.deliverableservice.GetDeliverableTypes().subscribe(
      (data) => {

        this.Deliverabletypes = data.filter(
          type => type.deliverableTypeID == 1 || type.deliverableTypeID == 2 || type.deliverableTypeID == 3 || type.deliverableTypeID == 4);

        this.MATDeliverabletypes = data.filter(
          type => type.deliverableTypeID != 1 && type.deliverableTypeID != 2 && type.deliverableTypeID != 3 && type.deliverableTypeID != 4);

        this.MATDeliverableDesc = Array.from(new Set(this.MATDeliverabletypes.map(t => t.description)));

        console.log(data);
      },
      (err) => {
        console.log("error is ", err)
      }
    );
  }

  GetDeliverableByDeliverableID(deliverableID: any) {
    debugger;
    this.deliverableservice.GetDeliverableByDeliverableID(deliverableID,this.archiveNumber).subscribe(
      (data) => {
        //this.DeliverablesData = data;
        this.RecordOfIssuanceName = data.recordOfIssuanceName,
          this.ROISize = data.roiSize;
        this.DeliverableName = data.deliverableName,
          this.DeliverableSize = data.deliverableSize,
          this.IsEditDeliverables = true;
        this.DeliverableTypeID = data.deliverableTypeId;
        this.DeliverableType = data.deliverableTypeId,
          this.ReportingEntity = data.reportingEntity,
          //this.Description = data.description,
          this.DeliverableDate = data.deliverableDate,
          this.DeliverableReleaseDate = data.deliverableReleaseDate,
          // this.Descriptiontextareacount=180-data.description.length,
          // this.ReportingEntitytextareacount= 180 - data.reportingEntity.length;


          this.showModelDialog("Edit");
      },
      (err) => {
        console.log("error is ", err)
      });
  }
  NavigateShowReasonsPopup() {
    /*Commenting this code as we're removing this logic part to add button
    if (this.CurrentArchiveStatusforDeliverables == "Resubmitted – Open" || this.CurrentArchiveStatusforDeliverables == "Resubmitted - Ready for Approval") {
      this.archiveHomeService.GetResubmissionReasonsforArchive(this.archiveNumber).subscribe(data => {
        debugger;
        if (data) {
          if (data.length > 0) {
            this.DeliverablesEditedInResubmit = data[2].actionTypeId == 3 ? true : false;
            this.DeliverablesProvidedInResubmit = data[2].comments != "" ? data[2].comments : "";
            if (this.DeliverablesEditedInResubmit == true && this.DeliverablesProvidedInResubmit == '') {
              this.modalService.openWithCustomWidth("SaveChanges-AdministrativeResubmission-Modal", "544");
            }
            else {
              this.router.navigate(['/archive/myarchives/' + this.archiveNumber + '/archivehome']);
            }
          }
        }
      });
    }
    else {*/
    this.router.navigate(["archive/myarchives/" + this.archiveNumber + '/archivehome'])
    //}
  }
  refreshROI(deliverableID: any) {
    console.log("refreshROI deliverableID ====" + deliverableID);
    this.Message = "ROI Refreshed successfully";

    var parameters = {
      "ArchiveNumber":this.archiveNumber,
      "DeliverableID": deliverableID,
      "CreatedBy": ''
    }
    this.deliverableservice.RefreshROI(parameters).subscribe((result) => {
      // debugger;
      if (result == 1) {
        this.updateedcd = true;
        this.sendArchiveDueDate();
        this.GetMatROIUpdateStatus(this.archiveNumber);
        this.GetDeliverablesByArchiveNumber(this.ArchiveNumber);
        this.notifier.notify("success", this.Message);
      }
      else {
        this.notifier.notify("error", "Unable to Refresh ROI ");
      }
    },
      (err) => {
        console.log("error", "Exception while refreshing the Mat ROI", err)
      });
  }

  GetMatROIUpdateStatus(archiveNumber: string) {
    this.archiveHomeService.GetMatRoiUpdates(archiveNumber).subscribe(data => {
      if (data) {
        // debugger;
        if (data.matRoiUpdates == 0) {
          this.isShowROIUpdateTipBox = false;
        }
        else {
          this.isShowROIUpdateTipBox = true;
        }
      }
    });
  }

  GetDeliverablesByArchiveNumber(archiveNumber: string) {
    this.deliverableservice.GetDeliverablesByArchiveNumber(archiveNumber, this.deliverableCurrentPageNumber, this.DeliverablespageSize).subscribe(
      (data) => {
        debugger;
        var finalist=data.filter(x=>x.archiveFileSubmissionStatus!=10 && ((x.isArchiveDestroyed==1 && x.deliverable.deliverableTypeDescription=='Engagement Letter') || x.isArchiveDestroyed==0));
        finalist.length<=1?this.DisableSelectallCheckbox=true:this.DisableSelectallCheckbox=false; 
        if (this.appendArchiveToGrid && data) {
          this.DeliverablesData = this.DeliverablesData.concat(data);
        }
        else {
          this.DeliverablesData = data ? data : [];
        }
        this.DeliverablesData = this.DeliverablesData.filter((v, i) => this.DeliverablesData.findIndex(item => item.deliverableID == v.deliverableID) === i);
        /* to update substantive on header banner*/

        if(this.CurrentArchiveStatusforDeliverables == "Resubmitted – Open" || this.CurrentArchiveStatusforDeliverables == "Resubmitted - Ready for Approval"){
          this.archiveinfo = this.archiveInfoService.getArchiveInfo(this.archiveNumber, this.employeeUniqueIdentifier).subscribe(
            (info) => {
                if(info.resubmissionType == 'Substantive')
                this.archiveHomeService.updateArchiveSubstantiation();
            });
        }
        /* to update substantive on header banner*/


        console.log(this.DeliverablesData);
        debugger;
        this.GetEnagementCeasedDate();
        if (data.length === 0) { // No Deliverables
          debugger;
          this.displayLandingPage = true;
          this.displyaDeliverables = false;
          this.totalDeliverables = 0;
          // this.verifiedROIS = data.filter(x => !this.verificationInProgressStatus.includes(x.ROIfileVerificationStatusId));
          // this.unverifiedROIS = data.filter(x => this.verificationInProgressStatus.includes(x.ROIfileVerificationStatusId))
          // this.verifiedDeliverables = data.filter(x => !this.verificationInProgressStatus.includes(x.DeliverablefileVerificationStatusId));
          // this.unverifiedDeliverables = data.filter(x => this.verificationInProgressStatus.includes(x.DeliverablefileVerificationStatusId))
         ////Removing this api call as part of duplicate api calls PE issue
          //this.GetEnagementCeasedDate();  // To know the entry from DB for Engagement Ceased
          //this.GetEngagementFieldRelatedSubstansive();

        }
        else { // Deliverables
          this.totalDeliverables = data[0]["count"];
          this.IsEngagementDecisions = false;
          this.verifiedDeliverables = data.filter(x => !this.verificationInProgressStatus.includes(x.fileVerificationStatusId));
          this.unverifiedDeliverables = data.filter(x => this.verificationInProgressStatus.includes(x.fileVerificationStatusId))
          for (let index = 0; index < data.length; index++) {
            //this.expand[data[index].deliverableID] = false;
            this.collapse[data[index].deliverableID] = true;
          }
          this.displayLandingPage = false;
          this.displyaDeliverables = true;
          //this.isLoaded = false;
          // this.displayNoDeliverableRibbon= false;
          //  if(data.deliverableTypeId==2 || data.deliverableTypeId==3 || data.deliverableTypeId==4 ){
          //    this.EDCDNoCalculation=false;
          //  }
        }
      },
      (err) => {
        console.log("error is ", "GetDeliverablesCountByArchiveNumber", err)
      }
    );
  }

  GetClientNameDetails(archiveNumber: string) {
    // this.archiveInfoService.getArchiveInfo(archiveNumber).subscribe(
    //   data => {
         var data = JSON.parse(localStorage.getItem('archiveInfoData'));
           if (data.clientName != null && data.clientName != undefined) {
            this.ClientName = data.clientName;
            if (this.IschkBoxClientName && this.ClientName != undefined) {
              this.ReportingEntity = this.ClientName;
              // this.ReportingEntitytextareacount = 180 - this.ClientName.length;
            }
            else {
              this.ReportingEntity = "";
            }
          }
      
    console.log('deliverablesarchiveInfoData', data);
  
    // });

  }

  // Get Deliverable archives count by archive number
  GetDeliverablesCountByArchiveNumber(archiveNumber: string) {

    this.deliverableservice.GetDeliverablesCountByArchiveNumber(archiveNumber).subscribe(
      (data) => {
        this.DeliverablesCount = data;
        if (this.DeliverablesCount === 0) {
          this.displayLandingPage = true;
          this.displyaDeliverables = false;
        }
        else {
          this.displayLandingPage = false;
          this.displyaDeliverables = true;
        }
        console.log(data);
      },
      (err) => {
        console.log("error is ", "GetDeliverablesCountByArchiveNumber", err)
      }
    );
  }

  EditDeliverablePopUp(deliverable) {
    debugger;
    this.HardCopyStatus = deliverable.hardCopyFileStatus;

    if (deliverable.isMATROI) {
      this.isMATROIClicked = true;
      this.RecordOfIssuanceName = deliverable.recordOfIssuanceName,
        this.ROISize = deliverable.roiSize;
      this.DeliverableName = deliverable.deliverableName,
        this.DeliverableSize = deliverable.deliverableSize,
        //this.IsEditDeliverables = true;
        this.DeliverableTypeID = deliverable.deliverableTypeId;
      this.DeliverableType = deliverable.deliverableTypeId,
        this.ReportingEntity = deliverable.reportingEntity,
        this.Description = deliverable.description,
        this.DeliverableDate = deliverable.deliverableDate,
        this.DeliverableReleaseDate = deliverable.deliverableReleaseDate,
        this.ROIDeliverableType = deliverable.deliverableTypeDescription,
        this.GroupAuditReleaseDate = deliverable.groupAuditReportReleaseDate,
        this.deliverableID = deliverable.deliverableID;
      this.FileSelectionFlag = false;
      this.IsEditDeliverables = true;
      this.roiEditMode = 4;
      this.IsMatROI = true;
      //this.add_del_grd_form.controls['GDRD'].markAsTouched();
      // this.Descriptiontextareacount=180-data.description.length,
      // this.ReportingEntitytextareacount= 180 - data.reportingEntity.length;
      this.showModelDialog("Continue", false);
    }
    else {
      this.IsMatROI = false;
      this.isMATROIClicked = false;
      this.IsEditDeliverables = true;
      this.deliverableID = deliverable.deliverableID;
      this.HardCopyFlags(deliverable);
      this.GetDeliverableByDeliverableID(this.deliverableID);
    }
  }

  HardCopyFlags(deliverable) {
    this.isHardCopyScenario = 0;
    this.Description = deliverable.description;
    this.ROIFileID = deliverable.roiArchiveFileID;
    this.DeliverableArchiveFileID = deliverable.deliverableArchiveFileID;

    /*isROIOnlyHardCopy*/
    if ((this.HardCopyStatus != '' && deliverable.barcode != '') && this.ROIFileID == 0 && this.DeliverableArchiveFileID != 0) {
      this.isHardCopyScenario = 1;
      this.Description = deliverable.description + ',' + deliverable.barcode;
    }

    /*isDeliverableOnlyHardCopy*/
    if ((this.HardCopyStatus != '' && deliverable.barcode != '') && this.ROIFileID != 0 && this.DeliverableArchiveFileID == 0) {
      this.isHardCopyScenario = 2;
      this.Description = deliverable.description + ',' + deliverable.barcode;
    }

    /*isBothHardCopy*/
    if ((this.HardCopyStatus != '' && deliverable.barcode != '') && this.ROIFileID == 0 && this.DeliverableArchiveFileID == 0) {
      this.isHardCopyScenario = 3;
      this.Description = deliverable.barcode;
    }
  }

  clearAddPopUpControls() {
    // debugger;
    this.DeliverableTypeID = 0;
    // if (!this.IsEditDeliverables) {
    //   this.inputROIFileUploadVariable.nativeElement.value = "";
    //   this.inputDeliverableFileUploadVariable.nativeElement.value = "";
    // }
    this.deliverableID = 0;
    this.RecordOfIssuanceName = undefined;
    this.DeliverableName = undefined;
    this.DeliverableType = null;
    this.IschkBoxClientName = true;
    this.ReportingEntity = this.ClientName;
    this.Description = "";
    this.DeliverableDate = undefined;
    this.DeliverableReleaseDate = undefined;
    this.FileSelectionFlag = false;
    this.ROIDeliverableType = undefined;
    this.GroupAuditReleaseDate = null;
    // this.Descriptiontextareacount=180,
    // this.ReportingEntitytextareacount= 180 - this.ClientName.length;
    this.nonMatForm.form.markAsPristine();
    this.nonMatForm.form.markAsUntouched();
    this.nonMatForm.form.updateValueAndValidity();
    this.IsMaxDate = undefined;
    this.IsEditDeliverables = false;
  }

  showModelDialog(Action, wipeReportingEntity: boolean = true) {
    this.IsMaxDate = undefined;
    if (Action === 'Continue' && this.isMATROIClicked) {
      this.getDeliverableTypes();
      this.popUpHeaderText = "Add MAT-ROI and Deliverable";
      this.roitooltip = "Click Select file to search for and import an ROI from MAT-ROI. The Deliverable Type, Reporting Entity, Description, Deliverable Date, and Deliverable Release Date fields will be imported from the MAT-ROI system and cannot be edited within Archive It Audit."
      this.deliverabletooltip = "Click Select file to upload the deliverable associated with your ROI. Note: If multiple deliverables are associated with a single ROI, add them all into a single zip file. Click Browse next to the Deliverable field to upload the zip file."
      this.showPopUp = 1;
      this.ROIArchiveSource = "MATROI";
      setTimeout(() => {
        if (wipeReportingEntity) this.ReportingEntity = null;
        this.modalService.openWithCustomWidth("addMatROIPopUpModel", "544")
      }, 500);
    }
    else if (Action === 'Continue' && !this.isMATROIClicked) {
      this.getDeliverableTypes();
      //Bug Fix As Reporting Entity is not showing by Default when clicked on Add//
      this.GetClientNameDetails(this.ArchiveNumber);
      //End Bug//
      this.popUpHeaderText = "Add ROI and Deliverable";
      this.showPopUp = 1;
      this.ROIArchiveSource = "MATROI";
      this.roitooltip = "Click Select file to upload the ROI from your local machine.";
      this.deliverabletooltip = "Click Select file to upload the deliverable associated with your ROI. Note: If multiple deliverables are associated with a single ROI, add them all into a single zip file. Click Browse next to the Deliverable field to upload the zip file.";
      setTimeout(() => { this.modalService.openWithCustomWidth("addNonMatPopUpModel", "544") }, 500);
    }
    else if (Action === 'Open') {
      this.getDeliverableTypes();
      this.resetfilter();
      this.getMatROI();
      this.popUpROIHeaderText = "Search and select Record of Issuance";
      this.showPopUp = 1;
      this.ROIArchiveSource = "MATROI";
      this.MatRadioid = true;
      this.show = false;
      this.showhidenotification=false;
      //document.getElementById("radioButtonID").checked = false;
      // document.getElementById("MatROIRadio").checked = false
      setTimeout(() => { this.modalService.openWithCustomWidth("MatROIPopUpModel", "1232") }, 500);
    }
    else if (Action === 'Add') {
      this.popUpHeaderText = "Select Record of Issuance source";
      this.showPopUp = 1;
      this.ROIArchiveSource = "MATROI";
      this.HardCopyStatus = '';
      this.modalService.openWithCustomWidth("addDeliverableModel", "595");
      this.hideAddBotton = false;
      this.hideRefreshROIBotton = false;
    }
    else if (Action === 'Edit') {
      this.getDeliverableTypes();
      this.popUpHeaderText = "Edit a non MAT-ROI deliverable pair";
      this.showPopUp = 1;
      this.ROIArchiveSource = "MATROI";
      setTimeout(() => { this.modalService.openWithCustomWidth("addNonMatPopUpModel", "544") }, 500);
    }
    else if (Action === 'Rejected') {
      console.log("Rejection" + this.rejectedComments);
      this.popUpHeaderText = "Edit Rejection Reason";
      this.modalService.openWithCustomWidth("RejectedReasonPopup", "640");
    }

    else if (Action === 'EditEngagement') {
      debugger;
      this.popUpHeaderText = "Edit engagement decisions";
      this.GetEnagementCeasedDateforEdit();
      this.showPopUp = 1;
      // this.modalService.openWithCustomWidth("EditEngagementDecisions", "544");
      setTimeout(() => { this.modalService.openWithCustomWidth("EditEngagementDecisions", "544") }, 500);
      this.hideAddBotton = false;
      this.hideRefreshROIBotton = false;
    }
  }
  IsGAARDEnable() {
    if (this.ROIDeliverableType == 'Component Auditor Clearance Memo (audit, review, specified audit procedures)' ||
      this.ROIDeliverableType == 'Component Auditor Procedures - No Clearance Issued (audit, review, specified audit procedures)' ||
      this.ROIDeliverableType == 'Component Auditor Procedures - Clearance Issued (audit, review, specified audit procedures)' ||
      (this.ROIDeliverableType == 'Component Auditor - Other Communications' && this.MATROIFlag == 2) ||
      this.ROIDeliverableType == 'Clearance from group team to components (i.e. GITC Work)'

    ) {
      return true;
    }
    else {
      return false;
    }
  }
  CancelEditEngagementPopup() {
    this.priorToCompletion = false;

    this.EEDEngDecisionYesCss = {
      'height': '88px',
      'border-color': '#BBBCBC'
    };

    this.EEDEngDecisionNoCss = {
      'top': '290px',
      'border-color': '#BBBCBC',
    };
    this.EEDNoPositionCss = {
      'top': '291px'
    };
    this.EEDNoTextPositionCss = {
      'top': '322px'
    }

  }

  closeModalDialog(Action) {
    debugger;
    this.showhidenotification=true;
    this.deliverableID = 0;
    if (Action == 'EditEngagementDecisions') {
      this.CancelEditEngagementPopup()
      this.clearAddPopUpControls();
      this.GetEnagementCeasedDate();
      //this.GetEngagementFieldRelatedSubstansive();
      this.modalService.close(Action);

    }
    else if (Action == 'MatROIPopUpModel') {
      //this.SelectedROI=null;
      this.ROIDeliverableType = undefined;
      this.RecordOfIssuanceName = undefined;
      this.ROISize = undefined;//
      this.DeliverableTypeID = undefined//
      this.ReportingEntity = undefined;
      this.Description = undefined;
      this.DeliverableDate = undefined;
      this.DeliverableReleaseDate = undefined;
      this.FileSelectionFlag = false;
      this.MatRadioid = false;
      // this.DeliverableType=null;
      // this.reportingEntity=null;
      // this.roiDescription=null;
      // this.deliverableDate=null;
      // this.deliverableReleaseDate=null;
      console.log("ROI selected");
      console.log("Deliverables data:" + this.DeliverableDate);
      this.modalService.close(Action);
    }
    else {
      this.isMATROIClicked = true;
      this.isManualClicked = false;
      this.clearAddPopUpControls();
      this.modalService.close(Action);
    }
  }
  AddROIItem(Action) {

    if (Action == 'MatROIPopUpModel') {
      //this.matROIGridSelectedData=this.matROIGridData.find(x => x.id == this.SelectedROI);

      // this.DeliverableType=item.deliverableType;
      // this.reportingEntity=item.reportingEntity;
      // this.roiDescription=item.deliverableName;
      // this.deliverableDate=item.deliverableDate;
      // this.deliverableReleaseDate=item.deliverableReleaseDate;
      // this.ROIID=item.roiNumber;
      //this.SelectedROI=false;
      this.MatRadioid = false;
      this.modalService.close(Action);
      this.FileSelectionFlag = true;
      this.showhidenotification=true;
    }
    console.log("Add selected ROI")
    console.log("FileSelectionFlag: " + this.FileSelectionFlag)
    console.log("DeliverableName:" + this.DeliverableName);
    // this.modalService.close(Action);
  }
  selectROIArchiveSource(source: string) {
    this.ROIArchiveSource = source;
    if (source === "MATROI") {
      this.isMATROIClicked = true;
      this.isManualClicked = false;
    } else {
      this.isMATROIClicked = false;
      this.isManualClicked = true;
    }
  }

  keyupGDRDDateChange(event:string, picker:any){
    this.GroupAuditReleaseDate = null;
    picker.date = null;
  }

  keyupDDateChange(event:string, picker:any){
    this.DeliverableDate = null;
    picker.date = null;
  }

  keyupDRDDateChange(event:string, picker:any){
    this.DeliverableReleaseDate = null;
    picker.date = null;
  }

  onDeliverableDateChange(event: any, picker:any) {
    this.DeliverableDate = new Date(event.month+'/'+ event.day +'/'+ event.year);
    if (this.DeliverableReleaseDate != undefined) {
      if (this.DeliverableDate > new Date(this.DeliverableReleaseDate)) {
        this.notifier.notify("error", "Deliverable date should not be later than Deliverable Release date")
        this.DeliverableDate = null;
        picker.focusDate(null); 
        //this.DDDatePicker.value = "";
      }
    }
  }

  onDeliverableReleaseDateChange(event: any, picker:any) {
    this.DeliverableReleaseDate = new Date(event.month+'/'+ event.day +'/'+ event.year);
    if (this.DeliverableDate != undefined) {
      if (new Date(this.DeliverableDate) > this.DeliverableReleaseDate) {
        this.notifier.notify("error", "Deliverable date should not be later than Deliverable Release date")
        this.DeliverableReleaseDate = null;
        picker.focusDate(null); 
        //this.DRDDatePicker.value = "";
      }
    }
  }

  txtAreaClientNameChangeEvent(event: any) {
    this.IschkBoxClientName = false;
    // this.ReportingEntitytextareacount = 180 - this.ReportingEntity.length;
  }

  // txtAreaDescriptionChangeEvent(event: any){
  //   this.Descriptiontextareacount = 180 - this.Description.length;
  // }

  chkBoxClientNameChange(event: any) {
    if (this.IschkBoxClientName && this.ClientName != undefined) {
      this.ReportingEntity = this.ClientName;
      // this.ReportingEntitytextareacount = 180 - this.ClientName.length;
    }
    else {
      this.ReportingEntity = "";
      // this.ReportingEntitytextareacount = 180 - this.ReportingEntity.length;
    }
  }

  requestImageAction(deliverableId: number) {
    this.requestImageActiontoRM(deliverableId);
    setTimeout(() => {
      this.Message = "Within 1 business day you will receive an email about the request status.";
      this.notifier.notify("success", this.Message);
    }, 2000);

    setTimeout(() => {
      this.router.navigate(["/archive/myarchives/" + this.archiveNumber + "/archivehome"]);
    }, 5000);
  }
  requestImageActiontoRM(deliverableId: number) {
    debugger;
    var parameters = {
      "ArchiveNumber": this.archiveNumber,
      "BinderID": deliverableId,
      "RequestedBy": this.euserAlias,
      "RequestTypeID": 1,
      "IsBinderOrDeliverable": 0
    }
    this.archiveService.CreateRequestImageAction(parameters).subscribe(data => {
      let success = data;
      console.log(success);
    });
  }

  ROIFileUploadEvent(event: any) {
    let ROIfile = event.target.files[0];
    this.RecordOfIssuanceName = ROIfile.name;
    this.ROISize = ROIfile.size;
  }

  DeliverableUploadEvent(event: any) {
    let Deliverablefile = event.target.files[0];
    this.DeliverableName = Deliverablefile.name;
    this.DeliverableSize = Deliverablefile.size;
  }

  selectedDeliverableType(event: any) {
    this.DeliverableTypeID = event.target.value;
    this.DeliverableTypeName = event.target.options[event.target.selectedIndex].text;
  }

  CreateorAddDeliverable(Action) {
    // this.deliverableID = 0;
    // this.ModeOfOperation = "Add";
    if (Action == 'NonMatROI') {
      this.deliverableID = 0;
      this.ModeOfOperation = "Add";
      this.IsMatROI = false;
      this.ROIID = null;
      this.GroupAuditReleaseDate = null;
      this.ROIMetadataid = null;
      this.ROINumber = null;
      this.Message = "Non Mat ROI - Deliverable added successfully";
    }
    else if (Action == 'MatROI') {
      if (this.deliverableID == 0 || this.deliverableID == undefined) {
        this.deliverableID = 0;
        this.ModeOfOperation = "Add";
        this.Message = "Mat ROI - Deliverable added successfully";
        this.roiEditMode = 0;
      }
      else {
        this.ModeOfOperation = "Edit";
        this.Message = "Mat ROI - Deliverable updated successfully";
        this.roiEditMode = this.roiEditMode == 2 ? (this.FileSelectionFlag ? 3 : 2) : (this.FileSelectionFlag ? 1 : 4);
      }
      this.IsMatROI = true;

    }
    this.CreateorUpdateDeliverable(this.deliverableID, this.Message, false);

  }
  SaveCreateDeliverableandStateReason() {
    // debugger;
    this.modalService.close('SaveChanges-AdministrativeResubmission-Modal');
    this.CreateorAddDeliverable(this.ResubmissionDeliverableActionType);
    this.AproveArchive("3");
  }

  CreateDeliverable(Action) {
    // if(this.CurrentArchiveStatusforDeliverables == "Resubmitted – Open" || this.CurrentArchiveStatusforDeliverables == "Resubmitted - Ready for Approval") {/*Commenting this code as we're showing Save & state reasons popup in back button*/
    //   this.modalService.close('addMatROIPopUpModel');
    //   this.modalService.close('addNonMatPopUpModel');
    //   this.ResubmissionDeliverableActionType=Action;
    //   //this.modalService.openWithCustomWidth("SaveChanges-AdministrativeResubmission-Modal", "544");
    //   //this.CreateorAddDeliverable(Action)
    //   //this.FileAddedinResubmitOpen = true;
    //   //this.AproveArchive('3');
    // }
    // else {
    this.CreateorAddDeliverable(Action)
    // }
  }
  /*Not Used*/
  SaveDeliverableSectionReasons() {
    // debugger;
    var parameter =
    {
      "ArchiveNumber": this.archiveNumber,
      "Comment": this.ResubmissionReason,
      "CreatedBy": '',
      "CommentCategoryId": 8,
    }
    var myobjstr = JSON.stringify(parameter);
    this.AddEditSubstantiation(this.ResubmissionReason, myobjstr);
  }
  /*Not Used*/

  UpdateDeliverable(Action) {
    if (Action == 'NonMatROI') {
      this.IsMatROI = false;
    }
    this.ModeOfOperation = "Edit";
    this.Message = "Non Mat ROI - Deliverable Updated successfully";
    this.CreateorUpdateDeliverable(this.deliverableID, this.Message, true);
  }

  CreateorUpdateDeliverable(deliverableID: number, message: string, IsUpdateDeliverables: boolean) {
    debugger;
    if (this.DeliverableTypeID == undefined || this.DeliverableTypeID == 0) {
      this.notifier.notify("error", "Select a Deliverable Type")
    }
    else if (this.RecordOfIssuanceName == undefined || this.RecordOfIssuanceName == "" ) {
      this.notifier.notify("error", "Please Upload ROI File")
    }
    else if ((this.DeliverableName == undefined || this.DeliverableName=="") && this.ROIDeliverableType != 'Interim Review - No Report Issued') {
      this.notifier.notify("error", "Please Upload Deliverable")
    }
    else if (this.ArchiveNumber == undefined) {
      this.notifier.notify("error", "ArchiveNumber required")
    }
    else if (this.ReportingEntity == "") {
      this.notifier.notify("error", "Reporting Entity Desc required")
    }
    else if (this.ReportingEntity.length < 5 && !this.IschkBoxClientName) {
      this.notifier.notify("error", "Reporting entity field requires a minimum of 5 characters.")
    }
    else if (this.Description == "") {
      this.notifier.notify("error", "Description required")
    }
    else if (this.Description.length < 5) {
      this.notifier.notify("error", "Description field requires a minimum of 5 characters.")
    }
    else if (this.DeliverableDate == undefined && this.ROIDeliverableType != 'Interim Review - No Report Issued') {
      this.notifier.notify("error", "Deliverable Date required")
    }
    else if (this.DeliverableReleaseDate == undefined) {
      this.notifier.notify("error", "Deliverable Release Date required")
    }
  

    else {
      var parameters = {
        "RecordOfIssuanceName": this.RecordOfIssuanceName
        , "ROISize": this.ROISize
        , "DeliverableName": !this.DeliverableName || this.DeliverableName.trim() == '' ? null : this.DeliverableName
        , "DeliverableSize": this.DeliverableSize
        , "ArchiveNumber": this.ArchiveNumber
        , "DeliverableTypeID": this.DeliverableTypeID
        , "ReportingEntity": this.ReportingEntity
        , "Description": this.Description
        , "DeliverableDate": (this.DeliverableDate != undefined && this.DeliverableDate != null) ? this.convertToDateFormat(this.DeliverableDate) : this.DeliverableDate
        , "DeliverableReleaseDate": (this.DeliverableReleaseDate != undefined && this.DeliverableReleaseDate != null) ? this.convertToDateFormat(this.DeliverableReleaseDate) : this.DeliverableReleaseDate
        , "CreatedBy": ''
        , "DeliverableID": deliverableID
        , "IsMATROI": this.IsMatROI
        , "RoiMetaDataID": this.ROIMetadataid
        , "RoiID": this.ROIID
        , "RoiNumber": this.ROINumber
        , "GroupAuditReportReleaseDate": (this.GroupAuditReleaseDate != undefined && this.GroupAuditReleaseDate != null) ? this.convertToDateFormat(this.GroupAuditReleaseDate) : this.GroupAuditReleaseDate
        , "ETag": this.etagId
        , "RoiEditMode": this.roiEditMode

      }

      this.deliverableservice.CreateOrUpdateDeliverable(parameters).subscribe((result) => {
        debugger;
        if (result != undefined && result.roiResponseMessage === '' && result.deliverableResponseMessage === '') {
          if ((deliverableID !== null && deliverableID != undefined && deliverableID !== 0 )||(this.isDeliverableSelectFileDisabled)) {
            this.notifier.notify("success", message);
            this.initialize();
          }
          this.roiArchiveFileId = result.roiArchiveFileId;
          this.roiFileTransferId = result.roiFileTransferId;
          this.roiResponseMessage = result.roiResponseMessage;
          this.deliverableArchiveFileId = result.deliverableArchiveFileId;
          this.deliverableFileTransferId = result.deliverableFileTransferId;
          this.deliverableResponseMessage = result.deliverableResponseMessage;
          this.roiS3FileName = result.roiS3FileName;
          this.deliverableS3FileName = result.deliverableS3FileName;

          if (this.ModeOfOperation === "Add" || (this.ModeOfOperation === "Edit" && this.isMATROIClicked==false)){//|| (this.ModeOfOperation === "Edit" && (this.roiEditMode === 2 || this.roiEditMode === 3))) {
            let timeout = this.IsMatROI ? 0 : 5000;
            let deliverablefilename = this.DeliverableName;
            if (!this.IsMatROI && +this.roiArchiveFileId>0) this.triggerFileUploadProcess(this.roiArchiveFileId, this.roiFileTransferId, this.ROIfileId, this.RecordOfIssuanceName, this.ROISize, this.roiS3FileName);
            if (+this.deliverableArchiveFileId > 0) setTimeout(() => { this.triggerFileUploadProcess(this.deliverableArchiveFileId, this.deliverableFileTransferId, this.DeliverablefileId, deliverablefilename, this.DeliverableSize, this.deliverableS3FileName) }, timeout);
          }
          if (this.IsMatROI == true) {
            //this.GetDeliverablesByArchiveNumber(this.archiveNumber);
            this.closeModalDialog('addMatROIPopUpModel');
            /*Handled the common reasons popup logic in shared folder
            if(this.CurrentArchiveStatusforDeliverables == "Resubmitted – Open")
            {
            this.modalService.openWithCustomWidth("Reasons-Adminstrativeresubmission-modal", "900");
            }*/
          }
          else {
            this.closeModalDialog('addNonMatPopUpModel');
            /*Handled the common reasons popup logic in shared folder
            if(this.CurrentArchiveStatusforDeliverables == "Resubmitted – Open")
            {
            this.modalService.openWithCustomWidth("Reasons-Adminstrativeresubmission-modal", "900");
            }*/
          }
          this.updateedcd = true;
          this.sendArchiveDueDate();
          // this.DeliverablesData = null;
          //this.GetDeliverablesByArchiveNumber(this.archiveNumber);
         
          this.clearAddPopUpControls();
        }
        else {
          if (result.roiResponseMessage != '' && result.roiResponseMessage != undefined) {
            this.notifier.notify("error", "ROI File " + result.roiResponseMessage);
          }
          else if (result.deliverableResponseMessage != '' && result.deliverableResponseMessage != undefined) {
            this.notifier.notify("error", "Deliverable File " + result.deliverableResponseMessage);
          }
        }
      },
        (err) => {
          console.log("error", "Exception while creating or updating Non Mat deliverable", err)
        });
    }
  }

  AproveArchive(ActionType) {

    var parameters = {
      "ArchiveNumber": this.archiveNumber,
      "ArchiveSectionId": "3",
      "ActionTypeId": ActionType,
      "Comments": "",
      "CreatedBy": ''

    }
    this.deliverableservice.ApproveRejectDeliverable(parameters).subscribe(data => {
      if (data == "success") {
        if (!this.IsChangeDecissionClicked) {
          localStorage['IsSectionVisited'] = '1';
          console.log("LocalStorage Set to 1 in Del for AR (2277):", localStorage['IsSectionVisited']);
        }
        if (ActionType != "3") {
          setTimeout(() => { this.router.navigate(["archive/myarchives/" + this.archiveNumber + '/archivehome']) }, 50);
        }

      }
    });
  }

  closeRejectModalDialog(Action) {
    this.rejectedComments = this.originalComments;
    // this.BodyCount = 250 - this.originalComments.length;
    this.modalService.close(Action);
  }

  closeRejectDialog(Action) {
    this.modalService.close(Action);
  }

  onchangeBody(e: any) {
    if (this.rejectedCommentsPlainText && this.rejectedCommentsPlainText.length >= 250) {
      if (!(e.ctrlKey && (e.keyCode >= 65 || e.keyCode <= 90)) && (e.keyCode > 47 || e.keyCode == 32 || e.keyCode == 9 || e.keyCode == 13)) {
        event.preventDefault();
      }
    }
  }

  get rejectedCommentsPlainText(): string {
    return this.rejectedComments ? this.stripHtml(this.rejectedComments) : null;
  }

  changedecisionbtnClick() {
    // debugger;
    this.hideRefreshROIBotton = false;
    this.hideAddBotton = false;
    this.ApproveDisabled = false;
    this.RejectDisabled = false;
    this.IsChangeDecissionClicked = true;

    // this.disabledColor = {
    //   'background': '#007CB0'
    // };
  }




  EEDEngagementTerminatedDecision(option) {
    if (option === true) {

      this.EEDEngDecisionYesCss = {
        'height': '171px',
        'border-color': '#007CB0'
      };
      this.EEDEngDecisionNoCss = {
        'top': '275px'
      };
      this.EEDNoPositionCss = {
        'top': '372px'
      };
      this.EEDNoTextPositionCss = {
        'top': '402px'
      }
      if (this.EngagementCeasedDate == undefined) {

        this.EEDpriorToCompletionCss = {
          'background-color': '#BBBCBC'
        }
        this.btnEEDpriorToCompletion = true;
      }
      else {
        this.btnEEDpriorToCompletion = false;
      }
    }
    else if (option === false) {
      this.EEDEngDecisionYesCss = {
        'height': '88px'
      };
      this.EEDEngDecisionNoCss = {
        'top': '290px',
        'border-color': '#007CB0',
      };
      this.EEDNoPositionCss = {
        'top': '291px'
      };
      this.EEDNoTextPositionCss = {
        'top': '322px'
      }
      this.EEDpriorToCompletionCss = {
        'background-color': '#007CB0'
      }
      this.btnEEDpriorToCompletion = false;
      this.EngagementCeasedDate = undefined;
    }

    else {

      this.EngagementCeasedDate = undefined;
      this.btnEEDpriorToCompletion = true;
      this.EngDecisionYesCss = {
        'height': '88px',
        'border-color': '#E6E6E6'
      }
      this.EngDecisionNoCss = {
        'top': '290px',
        'border-color': '#E6E6E6'
      }


    }
    this.priorToCompletion = option;
  }

  onGDRDChange(event: any,picker:any) {
    this.GroupAuditReleaseDate = new Date(event.month+'/'+ event.day +'/'+ event.year);
    //picker.focusDate(null); 
  }


  onEEDChange(event: any) {
    this.EngagementFieldRelated = undefined;
    this.EngagementCeasedDate = event;
    if (this.EngagementCeasedDate != undefined) {
      this.EEDpriorToCompletionCss = {
        'background-color': '#007CB0'
      }
      this.btnEEDpriorToCompletion = false;
    }
    else {
      this.notifier.notify("error", "Engagement Ceased Date is required")
      this.EngagementCeasedDate = undefined;
      this.btnEEDpriorToCompletion = true;
    }
    this.EngagementFieldRelated == undefined;
  }
  onEEDFieldChange(event: any) {
    this.EngagementCeasedDate = undefined;
    this.EngagementFieldRelated = new Date(event);
    if (this.EngagementFieldRelated != undefined) {
      this.EEDpriorToCompletionCss = {
        'background-color': '#007CB0'
      }
      this.btnEEDpriorToCompletion = false;
    }
    else {
      this.notifier.notify("error", "Engagement Ceased Date is required");
      this.EngagementFieldRelated = undefined;
      this.btnEEDpriorToCompletion = true;
    }
    this.EngagementCeasedDate == undefined;
  }

  SaveRejectDeliverable(ActionType) {
    var parameters = {
      "ArchiveNumber": this.archiveNumber,
      "ArchiveSectionId": "3",
      "ActionTypeId": ActionType,
      "Comments": this.rejectedComments,
      "CreatedBy": ''
    }
    this.deliverableservice.ApproveRejectDeliverable(parameters).subscribe(data => {
      if (data == "success") {
        this.originalComments = this.rejectedComments;
        if (!this.IsChangeDecissionClicked) {
          localStorage['IsSectionVisited'] = '1';
          console.log("LocalStorage Set to 1 in Del for AR (2436):", localStorage['IsSectionVisited']);
        }
        setTimeout(() => { this.notifier.notify("success", "Comments Saved Succesfully!!") }, 500);
        setTimeout(() => { this.router.navigate(["archive/myarchives/" + this.archiveNumber + '/archivehome']) }, 5000);
      }
    });
  }

  // No Deliverables Substantiation
  GetSubstantiation(archiveNumber: string, commentCategoryId: number) {
    this.deliverableservice.GetSubstantiationByArchiveNumber(archiveNumber, commentCategoryId).subscribe(
      data => {
        this.DisplayReason = data;

        if (this.DisplayReason.length == 0) {
          this.isNoDeliverableClick = true;
        }

        else {
          this.isNoDeliverableClick = false;
        }
        this.isEngagementYesNo = false;
        this.ShowhideForEngagementAndNoDeliverable();

        //this.isLoaded = true;
        //this.displayNoDeliverableRibbon= true;
      },
      err => {
        console.log("error is ", err);
      }
    );
  }

  /*Not Used */
  AddEditSubstantiation(reason, myobjstr) {
    this.deliverableservice.AddEditSubstantiation(myobjstr).subscribe(
      data => {
        if (data == true) {
          this.DisplayReason = reason;
          this.notifier.notify(
            "success",
            "Successfully added"
          );
          this.displayNoDeliverableClick = false;
          this.GetSubstantiation(this.archiveNumber, this.commentCategoryId);
        }
        else {
          this.notifier.notify(
            "error",
            "Error occured"
          );
        }
      },
      err => {
        console.log("error is ", err);
      }
    );
  }
  /*Not Used */
  /* Not Used*/
  SaveSubstantiation(reason) {
    var parameter =
    {
      "ArchiveNumber": this.archiveNumber,
      "Comment": reason,
      "CreatedBy": '',
      "CommentCategoryId": 3,
    }
    var myobjstr = JSON.stringify(parameter);
    this.AddEditSubstantiation(reason, myobjstr)

  }
  /* Not Used*/

  ShowhideForEngagementAndNoDeliverable() {

    if (this.isEngagementYesNo) // incase of engagement Yes/No  True case
    {

      this.displayLandingPageForEngagement = this.isEngagementYesNo;
      this.displayRibbonForEngagement = false;
      this.displayNoDeliverableRibbon = false;
      this.displayNoDeliverableClick = false;
    }

    else  // Incase of Engagement Ribbon
    {
      this.displayRibbonForEngagement = true;
      this.displayLandingPageForEngagement = this.isEngagementYesNo;
      if (this.isNoDeliverableClick) // there is no entry in DB for NoDeliverable comments
      {
        // Showing clik here for adding No Deliverables comments
        // this.isLoaded = true;

        this.displayNoDeliverableRibbon = false;
        this.displayNoDeliverableClick = true;
      }

      else {
        // Showing ribbon
        this.displayNoDeliverableRibbon = true;
        this.displayNoDeliverableClick = false;
      }
    }
  }

  // Mat ROI Grid
  getMatROI() {
    // debugger;
    this.FileSelectionFlag = false;
    if (this.isBasicShow)
      this.getMatROIInfo();
    else
      this.getMatROIAdvancedInfo();
  }

  getMatROIInfo() {
    console.log("=========Abhi:" + this.searchtextvalue);

    if (this.searchtextvalue != '') {
      this.deliverableservice.GetMatROIInfo(this.matROICurrentPageNumber
        , this.pageSize
        , this.sortBy
        , this.searchtextvalue
      ).subscribe(
        data => {
          if (this.appendArchiveToGrid && data) {
            this.matROIGridData = this.matROIGridData.concat(data);
          }
          else {
            this.matROIGridData = data ? data : [];
          }

          if (this.matROIGridData.length > 0) {
            this.totalMATROIs = this.matROIGridData[0]["count"];
          }
          else {
            this.totalMATROIs = 0;
          }

          this.isLoadedResult = true;
          this.isInputSearchResult = true;
          this.getDefaultState();
        }
      );
    }
  }

  getMatROIAdvancedInfo() {
    if (this.filterarray.length > 0) {
      this.deliverableservice.GetMatROIAdvancedInfo(this.matROICurrentPageNumber
        , this.pageSize
        , this.sortBy
        , (this.DeliverableType == null) ? "" : this.DeliverableTypeName
        , this.lastDeliverableReleaseDateFrom
        , this.lastDeliverableReleaseDateTo
        , this.lastDeliverableDateFrom
        , this.lastDeliverableDateTo
        , this.lastUpdatedDateFrom
        , this.lastUpdatedDateTo
      ).subscribe(
        data => {
          if (this.appendArchiveToGrid && data) {
            this.matROIGridData = this.matROIGridData.concat(data);
          }
          else {
            this.matROIGridData = data ? data : [];
          }

          if (this.matROIGridData.length > 0) {
            this.totalMATROIs = this.matROIGridData[0]["count"];
          }
          else {
            this.totalMATROIs = 0;
          }

          this.isLoadedResult = true;
          this.getDefaultState();
        }
      );
    }
  }


  updateGridData(event) {
    this.appendArchiveToGrid = event.isLoadMoreClicked;
    this.matROICurrentPageNumber = event.pageNumber;
    this.getMatROI();
  }

  resetPage(){
    this.appendArchiveToGrid = false;
    this.matROICurrentPageNumber=1;
    this.pageSize=10;
    this.totalMATROIs = 0;
  }

  mouseOver(event: any, index: number) {
    this.hoverIndex = index;
  }

  mouseOut(event: any) {
    let name: string = '';
    let present: number = -1;

    name = event.toElement ? event.toElement.getAttribute('name') : '';
    present = name ? name.search("AccessArchiveTop") : -1;

    if (event.toElement && present == -1 && (event.toElement["tagName"] != 'td' || event.toElement.className == 'trMatROIGridHeadFont')) {
      this.hoverIndex = -1;
    }
  }
  browseFileDialogClick(filetype: string) {
    if (this.roiEditMode == 4 && this.IsMatROI == true) this.roiEditMode = 2;
    var self = this;
    var fileElem = document.createElement('input');
    var fileIndex = self._fuEventService.fileIndex++;
    if (filetype === 'ROIFile') {
      self.ROIfileId = 'fileId-' + fileIndex;
      fileElem.setAttribute("id", self.ROIfileId);
    }
    else if (filetype === 'DeliverableFile') {
      self.DeliverablefileId = 'fileId-' + fileIndex;
      fileElem.setAttribute("id", self.DeliverablefileId);
    }

    fileElem.setAttribute("type", "file");
    //fileElem.setAttribute("accept", this.acceptedMIMETypes);
    document.getElementById("div_fileupload").appendChild(fileElem);

    fileElem.click();
    fileElem.onchange = function (e: any) {

      var file = e.target.files[0];

      if (file.name) {
        if (filetype === 'ROIFile') {
          self.RecordOfIssuanceName = file.name;
          self.ROISize = file.size;
        }
        else if (filetype === 'DeliverableFile') {
          self.DeliverableName = file.name;
          self.DeliverableSize = file.size;
        }
      }
    }
  }

  updateDeliverableGridData(event) {
    debugger;
    this.appendArchiveToGrid = event.isLoadMoreClicked;
    this.deliverableCurrentPageNumber = event.pageNumber;
    this.GetDeliverablesByArchiveNumber(this.archiveNumber);
  }
  MatRoiSelectedRow(item) {
    // debugger;
    this.MatRadioid = true;
    //this.SelectedROI=true;
    this.FileSelectionFlag = true;
    this.ROIDeliverableType = item.deliverableType;
    this.DeliverableTypeID = item.deliverableTypeId;
    this.ROIID = item.roiID;
    this.ROIMetadataid = item.id;
    this.ROINumber = item.roiNumber;
    this.MATROIFlag = item.isMATROI;
    //this.deliverableID = 0;
    console.log("ROI selected");
    this.RecordOfIssuanceName = item.roiNumber + '.pdf';
    //this.ROISize = 20;
    this.ReportingEntity = item.reportingEntity;
    this.Description = item.description;
    this.DeliverableReleaseDate = item.deliverableReleaseDate;
    this.etagId = item.eTag;
    this.ROISize = item.roiSize;
    if (item.deliverableType == "Interim Review - No Report Issued") {
      this.DeliverableDate = null;
    }
    else {
      this.DeliverableDate = item.deliverableDate;
    }
    //this.add_del_grd_form.controls['GDRD'].markAsTouched();
  }
  disablebutton() {
    if ((this.RecordOfIssuanceName === '' || this.RecordOfIssuanceName === undefined)) {
      return true;
    }
    else if (this.ROIDeliverableType == this._interimReviewNoReportIssued) {
      return false;
    }
    else if ((this.IsGAARDEnable() && ((this.DeliverableName == '' || this.DeliverableName == undefined) || (this.GroupAuditReleaseDate == null || this.GroupAuditReleaseDate == undefined))) ||
      (!this.IsGAARDEnable() && (this.DeliverableName == '' || this.DeliverableName == undefined))) {
      return true;
    }
    else {
      return false;
    }
  }
  disableContinuebutton() {
    if ((this.DeliverableTypeID === undefined || this.DeliverableTypeID === 0) || (this.RecordOfIssuanceName === undefined || this.RecordOfIssuanceName === '') || (this.DeliverableName === undefined || this.DeliverableName === '')
      || (this.ReportingEntity === "" || this.ReportingEntity === undefined) || (this.Description === undefined || this.Description === '')
      || (this.DeliverableDate === undefined || this.DeliverableReleaseDate === undefined)
    ) {
      return true;
    }
    else {
      return false;
    }
  }
  cancelSelectedFile(filetype: string) {
    let div_fileupload = document.getElementById("div_fileupload")
    if (filetype === 'ROIFile') {
      var fileElement = document.getElementById(this.ROIfileId);
      if (div_fileupload && fileElement) div_fileupload.removeChild(fileElement);

      this.ROIfileId = "";
      this.RecordOfIssuanceName = "";
      this.ROISize = undefined;
      this.GroupAuditReleaseDate = undefined;
      this.FlagforCancelbuttonClick_ROI=true;
    }
    else if (filetype === 'DeliverableFile') {
      var fileElement = document.getElementById(this.DeliverablefileId);
      if (div_fileupload && fileElement) div_fileupload.removeChild(fileElement);

      this.DeliverablefileId = "";
      this.DeliverableName = "";
      this.DeliverableSize = -1;
      this.FlagforCancelbuttonClick_Del=true;
    }
    else if (filetype === 'MatROIFile') {
      // var fileElement = document.getElementById(this.ROIfileId);
      // document.getElementById("div_fileupload").removeChild(fileElement);

      // this.ROIfileId = "";
      // this.RecordOfIssuanceName = "";
      // this.ROISize = "";
      this.FileSelectionFlag = false;
      //this.SelectedROI=null;
      this.ROIDeliverableType = undefined;
      this.RecordOfIssuanceName = undefined;
      this.ROISize = undefined;
      this.DeliverableTypeID = undefined
      this.ReportingEntity = undefined;
      this.Description = undefined;
      this.DeliverableDate = undefined;
      this.DeliverableReleaseDate = undefined;
      this.etagId = undefined;
      this.GroupAuditReleaseDate = undefined;
    }
  }
  triggerFileUploadProcess(archiveFileId: any, fileTransferId: any, fileid: any, fileName: any, fileSize: any, s3FileName: any) {

    var self = this;

    self._fuEventService.fileArray.push({
      module: self.module,
      fileId: fileid,
      fileName: fileName,
      s3FileName: s3FileName,
      fileSize: fileSize,
      eTag: "",
      uploadId: "",
      uploadPercentage: "",
      uploadStatus: "add",
      uploadMessage: "",
      errorMessage: "",
      uploadRemaingTime: "",
      sunits: "",
      tunits: "",
      metaData: {}
    });

    var metaData = {
      archiveFileId: archiveFileId.toString(),
      fileTransferId: fileTransferId.toString()
    }


    var fileUploadProcessService = new FileUploadProcessService(
      self._fuService,
      self._fuEventService,
      self.SpinnerService,
      fileid,
      s3FileName,
      metaData
    );

    var fileElement = document.getElementById(fileid);
    fileUploadProcessService.uploadFile(fileElement);
  }

  matROIGetExternalLink(s3filePath: string) {
    console.log("======(s3filePath)=====");
    console.log("s3filePath" + s3filePath);

    //s3filePath = 'MAT ROI/ROI-202012.pdf';
    if (!s3filePath) return false;
    var metaData = {};
    var fileUploadProcessService = new FileUploadProcessService(
      this._fuService,
      this._uploadEventService,
      null,
      null,
      null,
      metaData
    );
    fileUploadProcessService.OpenDocument(s3filePath);
  }

  private stripHtml(html: string): string {
    var temporalDivElement = document.createElement("div");
    temporalDivElement.innerHTML = html;
    return temporalDivElement.textContent || temporalDivElement.innerText || "";
  }

  public onPaste(prevData: string, el): void {
    let clipboardData = el.clipboardData;
    let pastedText: string = clipboardData.getData('text');
    let PastedTextCount = this.stripHtml(pastedText.trim()).length;
    let prevDataCount = prevData ? this.stripHtml(prevData).length : 0;
    pastedText = pastedText.substring(0, 250 - prevDataCount);
    let concatedText = (prevData + pastedText)
    if (prevDataCount >= 250) el.preventDefault();
    else if ((prevDataCount + PastedTextCount) > 250) {
      el.preventDefault();
      this.rejectedComments = concatedText
    }
  }

  public get isDeliverableSelectFileDisabled(): boolean {
    if (this.ROIDeliverableType === this._interimReviewNoReportIssued) this.cancelSelectedFile('DeliverableFile');
    return this.ROIDeliverableType === this._interimReviewNoReportIssued;
  }

  getBorderColor(deliverable) {
    if (deliverable.roiUpdates > 0) {
      return 'border-box-yellow';
    }
    else {
      if ((deliverable.roiFileStatus == fileVerificationStatus.New || deliverable.roiFileStatus == fileVerificationStatus.InProgress || deliverable.roiFileStatus == fileVerificationStatus.Completed || deliverable.roiFileStatus == fileVerificationStatus.VerificationSuccessful || deliverable.roiFileStatus == '') 
      && (deliverable.deliverableFileStatus == fileVerificationStatus.New || deliverable.deliverableFileStatus == fileVerificationStatus.InProgress || deliverable.deliverableFileStatus == fileVerificationStatus.Completed || deliverable.deliverableFileStatus == fileVerificationStatus.VerificationSuccessful|| deliverable.deliverableFileStatus == '')) {
        return 'border-box-grey';
      }
    }
    return 'border-box-red';
  }

  fileStatusColorCode(status): string {
    // debugger;
    return status === fileVerificationStatus.Failed ? '#DA291C'
      : status === fileVerificationStatus.VerificationSuccessful ? "#43B02A"
      : status === fileVerificationStatus.New ? "#63666A"
        : status === fileVerificationStatus.InProgress ? "#9D5C00" :
          "#9D5C00";
  }

  fileStatusBGColorCode(status): string {
    // debugger;
    return status === fileVerificationStatus.Failed ? 'rgba(218, 41, 28, 0.2)'
      : status === fileVerificationStatus.VerificationSuccessful ? "rgba(67, 176, 42, 0.2)"
      : status === fileVerificationStatus.New ? "#F0F0F0"
        : status === fileVerificationStatus.InProgress ? "rgba(157, 92, 0, 0.2)" :
          "rgba(157, 92, 0, 0.2)";
  }

  showInActivePopup(deliverableID: string) {
    this.deliverableIDtobeInactivated = deliverableID;
    this.modalService.openWithCustomWidth("InActivePopUp", "480");
  }
  closeInActivePopUp() {
    this.modalService.close("InActivePopUp");
  }
  inActiveFile() {
    //debugger;
    var self = this;

    if (!self.deliverableIDtobeInactivated) return false;

    self._wservice.InActiveFile(self.deliverableIDtobeInactivated, self.employeeUniqueIdentifier, 3, this.archiveNumber).subscribe(
      res => {

        if (res == true) {
          // self.verifiedDeliverables = self.verifiedDeliverables.filter(x => x.DeliverableId !== self.deliverableIDtobeInactivated);
          self.notifier.notify(
            "success",
            "Deliverabel successfully InActivated"
          );
          self.closeInActivePopUp();
          this.updateedcd = true;
          this.sendArchiveDueDate();
          self.GetDeliverablesByArchiveNumber(self.archiveNumber);
        }
      },
      err => {
        self.closeInActivePopUp();
        self.notifier.notify(
          "error",
          self.deliverableIDtobeInactivated + " InActivation failed"
        );
      }
    );

  }
  private validateFileSize(fileId: string): boolean {
    let fileElement = <any>(document.getElementById(fileId));
    if (!fileElement) return true;
    let fileObject = fileElement.files[0];
    let fileSize = fileObject.size;
    return fileSize && fileSize > 0;
  }

  generateReportClicked(data1) {
    debugger;
    let archiveForReport: any[] = [];
    let filterdColumns = (data1.filter(x => x.checked));
    this.deliverableservice.GetDeliverablesByArchiveNumber(this.archiveNumber, 0, 0).subscribe(
      (data) => {
        debugger;
        if (data.length != 0) {


          data.forEach(element => {
            let archive = {};
            filterdColumns.forEach(column => {
              debugger;

              if (column["value"] == this.deliverableResultGridColumns.DeliverableID) { //Archive#
                archive[this.deliverableResultGridColumns[this.deliverableResultGridColumns.DeliverableID]] = element.deliverableID || this.emptyStringInReport;
              }

              if (column["value"] == this.deliverableResultGridColumns.ReportingEntity) { //Archive#
                archive[this.deliverableResultGridColumns[this.deliverableResultGridColumns.ReportingEntity]] = element.reportingEntity || this.emptyStringInReport;
              }

              if (column["value"] == this.deliverableResultGridColumns.Description) { //Archive#
                archive[this.deliverableResultGridColumns[this.deliverableResultGridColumns.Description]] = element.description || this.emptyStringInReport;
              }

              if (column["value"] == this.deliverableResultGridColumns.DeliverableDate) { //Archive#
                archive[this.deliverableResultGridColumns[this.deliverableResultGridColumns.DeliverableDate]] = element.deliverableDate || this.emptyStringInReport;
              }

              if (column["value"] == this.deliverableResultGridColumns.DeliverableTypeID) { //Archive#
                archive[this.deliverableResultGridColumns[this.deliverableResultGridColumns.DeliverableTypeID]] = element.deliverableTypeID || this.emptyStringInReport;
              }

              if (column["value"] == this.deliverableResultGridColumns.DeliverableReleaseDate) { //Archive#
                archive[this.deliverableResultGridColumns[this.deliverableResultGridColumns.DeliverableReleaseDate]] = element.deliverableReleaseDate || this.emptyStringInReport;
              }

              if (column["value"] == this.deliverableResultGridColumns.GroupAuditReportReleaseDate) { //Archive#
                archive[this.deliverableResultGridColumns[this.deliverableResultGridColumns.GroupAuditReportReleaseDate]] = element.groupAuditReportReleaseDate || this.emptyStringInReport;
              }

              if (column["value"] == this.deliverableResultGridColumns.DeliverableTypeDescription) { //Archive#
                archive[this.deliverableResultGridColumns[this.deliverableResultGridColumns.DeliverableTypeDescription]] = element.deliverableTypeDescription || this.emptyStringInReport;
              }

              if (column["value"] == this.deliverableResultGridColumns.RecordOfIssuanceName) { //Archive#
                archive[this.deliverableResultGridColumns[this.deliverableResultGridColumns.RecordOfIssuanceName]] = element.recordOfIssuanceName || this.emptyStringInReport;
              }

              if (column["value"] == this.deliverableResultGridColumns.ROIStatus) { //Archive#
                archive[this.deliverableResultGridColumns[this.deliverableResultGridColumns.ROIStatus]] = element.rOIStatus || this.emptyStringInReport;
              }

              if (column["value"] == this.deliverableResultGridColumns.RoiNumber) { //Archive#
                archive[this.deliverableResultGridColumns[this.deliverableResultGridColumns.RoiNumber]] = element.roiNumber || this.emptyStringInReport;
              }

              if (column["value"] == this.deliverableResultGridColumns.ROISize) { //Archive#
                archive[this.deliverableResultGridColumns[this.deliverableResultGridColumns.ROISize]] = element.rOISize || this.emptyStringInReport;
              }

              if (column["value"] == this.deliverableResultGridColumns.ROIUpdates) { //Archive#
                archive[this.deliverableResultGridColumns[this.deliverableResultGridColumns.ROIUpdates]] = element.rOIUpdates || this.emptyStringInReport;
              }

              if (column["value"] == this.deliverableResultGridColumns.DeliverableName) { //Archive#
                archive[this.deliverableResultGridColumns[this.deliverableResultGridColumns.DeliverableName]] = element.deliverableName || this.emptyStringInReport;
              }

              if (column["value"] == this.deliverableResultGridColumns.DeliverableStatus) { //Archive#
                archive[this.deliverableResultGridColumns[this.deliverableResultGridColumns.DeliverableStatus]] = element.deliverableStatus || this.emptyStringInReport;
              }

              if (column["value"] == this.deliverableResultGridColumns.DeliverableSize) { //Archive#
                archive[this.deliverableResultGridColumns[this.deliverableResultGridColumns.DeliverableSize]] = element.deliverableSize || this.emptyStringInReport;
              }

              if (column["value"] == this.deliverableResultGridColumns.ArchivedBy) { //Archive#
                archive[this.deliverableResultGridColumns[this.deliverableResultGridColumns.ArchivedBy]] = element.archivedBy || this.emptyStringInReport;
              }

              if (column["value"] == this.deliverableResultGridColumns.ArchiveDate) { //Archive#
                archive[this.deliverableResultGridColumns[this.deliverableResultGridColumns.ArchiveDate]] = element.archiveDate || this.emptyStringInReport;
              }

              if (column["value"] == this.deliverableResultGridColumns.DeliverableDriveDueDate) { //Archive#
                archive[this.deliverableResultGridColumns[this.deliverableResultGridColumns.DeliverableDriveDueDate]] = element.deliverableDriveDueDate || this.emptyStringInReport;
              }

              if (column["value"] == this.deliverableResultGridColumns.DeliverableDriveDueDate) { //Archive#
                archive[this.deliverableResultGridColumns[this.deliverableResultGridColumns.DeliverableDriveDueDate]] = element.deliverableDriveDueDate || this.emptyStringInReport;
              }

              if (column["value"] == this.deliverableResultGridColumns.BarCode) { //Archive#
                archive[this.deliverableResultGridColumns[this.deliverableResultGridColumns.BarCode]] = element.barcode || this.emptyStringInReport;
              }

              if (column["value"] == this.deliverableResultGridColumns.HardCopyFileStatus) { //Archive#
                archive[this.deliverableResultGridColumns[this.deliverableResultGridColumns.HardCopyFileStatus]] = element.hardCopyFileStatus || this.emptyStringInReport;
              }

              if (column["value"] == this.deliverableResultGridColumns.DeletedBy) { //Archive#
                archive[this.deliverableResultGridColumns[this.deliverableResultGridColumns.DeletedBy]] = element.deletedBy || this.emptyStringInReport;
              }

              if (column["value"] == this.deliverableResultGridColumns.IncludeInCalculation) { //Archive#
                archive[this.deliverableResultGridColumns[this.deliverableResultGridColumns.IncludeInCalculation]] = element.includeInCalculation || this.emptyStringInReport;
              }

              if (column["value"] == this.deliverableResultGridColumns.ROIFileVerificationStatusId) { //Archive#
                archive[this.deliverableResultGridColumns[this.deliverableResultGridColumns.ROIFileVerificationStatusId]] = element.rOIFileVerificationStatusId || this.emptyStringInReport;
              }

              if (column["value"] == this.deliverableResultGridColumns.DeliveableFileVerificationStatusId) { //Archive#
                archive[this.deliverableResultGridColumns[this.deliverableResultGridColumns.DeliveableFileVerificationStatusId]] = element.deliveableFileVerificationStatusId || this.emptyStringInReport;
              }

              if (column["value"] == this.deliverableResultGridColumns.ROIFileVerificationStatus) { //Archive#
                archive[this.deliverableResultGridColumns[this.deliverableResultGridColumns.ROIFileVerificationStatus]] = element.rOIFileVerificationStatus || this.emptyStringInReport;
              }

              if (column["value"] == this.deliverableResultGridColumns.ROIFailedDescription) { //Archive#
                archive[this.deliverableResultGridColumns[this.deliverableResultGridColumns.ROIFailedDescription]] = element.rOIFailedDescription || this.emptyStringInReport;
              }

              if (column["value"] == this.deliverableResultGridColumns.DeliverableFileVerificationStatus) { //Archive#
                archive[this.deliverableResultGridColumns[this.deliverableResultGridColumns.DeliverableFileVerificationStatus]] = element.deliverableFileVerificationStatus || this.emptyStringInReport;
              }

              if (column["value"] == this.deliverableResultGridColumns.DeliverableFailedDescription) { //Archive#
                archive[this.deliverableResultGridColumns[this.deliverableResultGridColumns.DeliverableFailedDescription]] = element.deliverableFailedDescription || this.emptyStringInReport;
              }

              if (column["value"] == this.deliverableResultGridColumns.IsMATROI) { //Archive#
                archive[this.deliverableResultGridColumns[this.deliverableResultGridColumns.IsMATROI]] = element.isMATROI || this.emptyStringInReport;
              }

              if (column["value"] == this.deliverableResultGridColumns.ROIFileStatus) { //Archive#
                archive[this.deliverableResultGridColumns[this.deliverableResultGridColumns.ROIFileStatus]] = element.rOIFileStatus || this.emptyStringInReport;
              }

              if (column["value"] == this.deliverableResultGridColumns.DeliverableFileStatus) { //Archive#
                archive[this.deliverableResultGridColumns[this.deliverableResultGridColumns.DeliverableFileStatus]] = element.deliverableFileStatus || this.emptyStringInReport;
              }

            });
            archiveForReport.push(archive);
          });
          if (archiveForReport && archiveForReport.length) {
            this.sharedService.generateExcel("DeliverablesandLettersFor" + this.archiveNumber, "deliverables", filterdColumns.map(x => x.displayName), archiveForReport);
          }

        }

      }
      ,
      (err) => {
        console.log("error is ", "generateReportClicked", err)
      }
    );

  }


  downloadSingleFile(FileName: string, S3fileName: string) {
    //debugger;
    if (!FileName && !S3fileName) return false;
    var metaData = {};
    var fileUploadProcessService = new FileUploadProcessService(
      this._fuService,
      this._uploadEventService,
      this.SpinnerService,
      null,
      null,
      metaData
    );
    fileUploadProcessService.downloadFile(S3fileName, FileName);
  }

  downloadFile(roiFileName: string, roiS3fileName: string, deliverableFileName: string, deliverables3fileName: string) {
    debugger;

    if (!roiFileName && !roiS3fileName) return false;
    var metaData = {};
    var fileUploadProcessService = new FileUploadProcessService(
      this._fuService,
      this._uploadEventService,
      this.SpinnerService,
      null,
      null,
      metaData
    );
    fileUploadProcessService.downloadFile(roiS3fileName, roiFileName);
    
    setTimeout(() => {
      if (!deliverableFileName && !deliverables3fileName) return false;
      var metaData = {};
      var fileUploadProcessService1 = new FileUploadProcessService(
        this._fuService,
        this._uploadEventService,
        this.SpinnerService,
        null,
        null,
        metaData
      );
      fileUploadProcessService1.downloadFile(deliverables3fileName, deliverableFileName);
    }, 10000);
      

  //   downloadPair();
  //   async function downloadPair () {
  //     await fileUploadProcessService.downloadFile(roiS3fileName, roiFileName);
  //     await fileUploadProcessService1.downloadFile(deliverables3fileName, deliverableFileName);
  //  }

  }

  showDeletePopup(roiS3FileName: string, roiFileId: string, roiFileName: string, deliverableS3FileName: string, deliverableFileId: string, deliverableFileName: string) {
    debugger;
    this.ROIarchiveFileIdToBeDeleted = roiFileId;
    this.ROIfileNameToBeDeleted = roiFileName;
    this.ROIs3fileNameToBeDeleted = roiS3FileName;

    this.DeliverablearchiveFileIdToBeDeleted = deliverableFileId;
    this.DeliverablefileNameToBeDeleted = deliverableFileName;
    this.Deliverables3fileNameToBeDeleted = deliverableS3FileName;

    this.fileTypeIdToBeDeleted = 0;
    this.modalService.openWithCustomWidth("deletePopUp", "480");
  }

  //Close delete confirmation popup
  closeDeletePopUp() {
    this.modalService.close("deletePopUp");
  }

  deleteFile() {
    debugger;
    var self = this;

    if (!self.ROIfileNameToBeDeleted) return false;

    var deleteRequest = {
      "ArchiveNumber":self.archiveNumber,
      "FileName": self.ROIs3fileNameToBeDeleted,
      "ArchiveFileId": self.ROIarchiveFileIdToBeDeleted,
      "ModifiedBy": ''
    }

    //If Archive File is EMS FileType then move file to S3 EMS folder before deleting from S3 Engagement folder

    self._wservice.DeleteFile(deleteRequest).subscribe(
      res => {
        debugger;
        if (res == true) {
          //self.verifiedDeliverables = self.verifiedDeliverables.filter(x => x.ROIArchiveFileID !== self.ROIarchiveFileIdToBeDeleted);
          self.notifier.notify(
            "success",
            self.ROIfileNameToBeDeleted + " successfully deleted"
          );
          this.updateedcd = true;
          this.sendArchiveDueDate();
          self.closeDeletePopUp();
          this.totalDeliverables = this.totalDeliverables - 1;
          var currentnumber = this.deliverableCurrentPageNumber;
          this.deliverableCurrentPageNumber = Math.round(this.totalDeliverables / this.pageSize);
          if (currentnumber !== this.deliverableCurrentPageNumber) {
            self.GetDeliverablesByArchiveNumber(self.archiveNumber);
          }
        }
      },
      err => {
        self.closeDeletePopUp();
        self.notifier.notify(
          "error",
          self.ROIfileNameToBeDeleted + " deletion failed"
        );
      }
    );
    debugger;
    if (self.DeliverablearchiveFileIdToBeDeleted != "0") {
      setTimeout(() => {
        var self = this;

        if (!self.DeliverablefileNameToBeDeleted) return false;


        var deleteRequest = {
          "ArchiveNumber":self.archiveNumber,
          "FileName": self.Deliverables3fileNameToBeDeleted,
          "ArchiveFileId": self.DeliverablearchiveFileIdToBeDeleted,
          "ModifiedBy": ''
        }

        //If Archive File is EMS FileType then move file to S3 EMS folder before deleting from S3 Engagement folder

        self._wservice.DeleteFile(deleteRequest).subscribe(
          res => {
            debugger;
            if (res == true) {
              //self.verifiedDeliverables = self.verifiedDeliverables.filter(x => x.ROIArchiveFileID !== self.ROIarchiveFileIdToBeDeleted);
              self.notifier.notify(
                "success",
                self.DeliverablefileNameToBeDeleted + " successfully deleted"
              );
              this.updateedcd = true;
              this.sendArchiveDueDate();
              self.closeDeletePopUp();
              // self.GetDeliverablesByArchiveNumber(self.archiveNumber);
            }
          },
          err => {
            self.closeDeletePopUp();
            self.notifier.notify(
              "error",
              self.ROIfileNameToBeDeleted + " deletion failed"
            );
          }
        );

      }, 500);
    }
    setTimeout(() => {
      self.GetDeliverablesByArchiveNumber(self.archiveNumber);
    }, 500);
  }
  ondelSelectAll(evt: any) {
    debugger;
    if (evt.target.checked) {
      this.bulkDownloadSelectedFiles = [];
      this.selectedWorkingPapers = [];
      for (var i = 0; i < this.DeliverablesData.length; i++) {
        if (this.DeliverablesData[i].archiveFileSubmissionStatus != 10 && ((this.DeliverablesData[i].isArchiveDestroyed==1 && this.DeliverablesData[i].deliverable.deliverableTypeDescription=='Engagement Letter') || this.DeliverablesData[i].isArchiveDestroyed==0)) {
          this.DeliverablesData[i].chkSelect = true;
          if (this.DeliverablesData[i].roiS3FileName && this.DeliverablesData[i].recordOfIssuanceName) {
            var roizipEntry = {
              ArchiveFileId: this.DeliverablesData[i].roiArchiveFileID,
              FileName: this.DeliverablesData[i].recordOfIssuanceName,
              S3FileName: this.DeliverablesData[i].roiS3FileName,
              S3FileSize: this.DeliverablesData[i].roiSize
            };
            var roistrZipEntry = JSON.stringify(roizipEntry);
            this.bulkDownloadSelectedFiles.push(roistrZipEntry);
            this.selectedWorkingPapers.push({
              archiveFileId: this.DeliverablesData[i].deliverableArchiveFileID,
              checked: true
            });
          }
        }
        if (this.DeliverablesData[i].deliverableName && this.DeliverablesData[i].deliverableS3FileName) {
          var zipEntry = {
            ArchiveFileId: this.DeliverablesData[i].deliverableArchiveFileID,
            FileName: this.DeliverablesData[i].deliverableName,
            S3FileName: this.DeliverablesData[i].deliverableS3FileName,
            S3FileSize: this.DeliverablesData[i].deliverableSize
          };
          var strZipEntry = JSON.stringify(zipEntry);
          this.bulkDownloadSelectedFiles.push(strZipEntry);
          this.selectedWorkingPapers.push({
            archiveFileId: this.DeliverablesData[i].archiveFileId,
            checked: true
          });
        }
      }
    }
    else {
      for (var i = 0; i < this.DeliverablesData.length; i++) {
        this.DeliverablesData[i].chkSelect = false;

        var archiveFileId = this.DeliverablesData[i].deliverableArchiveFileID;
        var roiarchiveFileId = this.DeliverablesData[i].roiArchiveFileID;
        this.bulkDownloadSelectedFiles = this.bulkDownloadSelectedFiles.filter(x => x.ArchiveFileId != archiveFileId && x.ArchiveFileId != roiarchiveFileId);
        this.selectedWorkingPapers = this.selectedWorkingPapers.filter(x => x.archiveFileId != archiveFileId);
      }
      this.bulkDownloadSelectedFiles = [];
      this.selectedWorkingPapers = [];
    }
    console.log(this.bulkDownloadSelectedFiles);
  }
  onSelectFile(evt: any, index: number, roiarchiveFileId: number, roifileName: string, rois3fileName: string, roifileSize: number, archiveFileId: number, fileName: string, s3fileName: string, fileSize: number) {
    debugger;
    if (evt.target.checked) {
      if (roifileName && rois3fileName) {
        var roizipEntry = {
          ArchiveFileId: roiarchiveFileId,
          FileName: roifileName,
          S3FileName: rois3fileName,
          S3FileSize: roifileSize
        };
        var roistrZipEntry = JSON.stringify(roizipEntry);
        this.bulkDownloadSelectedFiles.push(roistrZipEntry);
        this.selectedWorkingPapers.push({
          archiveFileId: roiarchiveFileId,
          checked: true
        });
      }
      if (fileName && s3fileName) {
        var zipEntry = {
          ArchiveFileId: archiveFileId,
          FileName: fileName,
          S3FileName: s3fileName,
          S3FileSize: fileSize
        };
        var strZipEntry = JSON.stringify(zipEntry);
        this.bulkDownloadSelectedFiles.push(strZipEntry);
        this.selectedWorkingPapers.push({
          archiveFileId: archiveFileId,
          checked: true
        });
      }
    } else {
      this.DeliverablesData[index].chkSelect = false;
      this.selectedAll = false;
      var archivefileId = this.DeliverablesData[index].deliverableArchiveFileID;
      var roiarchivefileId = this.DeliverablesData[index].roiArchiveFileID;
      this.bulkDownloadSelectedFiles = this.bulkDownloadSelectedFiles.filter(x => x.indexOf(archivefileId) == -1);
      this.bulkDownloadSelectedFiles = this.bulkDownloadSelectedFiles.filter(x => x.indexOf(roiarchivefileId) == -1);
      this.selectedWorkingPapers = this.selectedWorkingPapers.filter(x => x.archiveFileId != archiveFileId && x.archiveFileId != roiarchiveFileId);
    }
    console.log(this.bulkDownloadSelectedFiles);
  }
  bulkDownload() {
    debugger;
    var self = this;
    if (this.bulkDownloadSelectedFiles.length == 0) {
      this.notifier.notify("error", "Please select at least one file.");
      return;
    }
    console.log("====this.bulkDownloadSelectedFiles====");
    console.log(this.bulkDownloadSelectedFiles);
    self.zipFileName = self.archiveNumber + "_Deliverables_.zip";
    var bulkdownloadModel = {
      ArchiveNumber: self.archiveNumber,
      ZipFileName: self.zipFileName,
      SelectedFiles: this.bulkDownloadSelectedFiles
    }
    this._service.bulkDownload(bulkdownloadModel).subscribe(
      (data) => {
        self.bulkdownloadId = data.jobId;
        if (self.bulkdownloadId) {
          self._bdownloadEventService.bulkDownloadsArray.push(self.bulkdownloadId);
          this.notifier.hideNewest();
          self.notifier.notify("success", "Your file downloads will run in the backend and dowloads when ready. Do not close the browser to ensure the download process completes",);
          self.clearFileSelections();
        }
        else {
          self.notifier.notify("error", "Something went wrong, please try again.");
        }
      },
      (err) => {
        console.log(err);
        self.notifier.notify("error", "Something went wrong, please try again.");
        self.clearFileSelections();
      }
    );
  }
  clearFileSelections() {
    this.selectedAll = false;
    this.selectedWorkingPapers = [];
    this.bulkDownloadSelectedFiles = [];
    for (var i = 0; i < this.DeliverablesData.length; i++) {
      this.DeliverablesData[i].chkSelect = false;
    }

  }
  /*
    deleteFile(proiFilename,pdeliverablefilename) {
      debugger;
            var self = this;
        //Delete record of issuance

            if (!proiFilename) return false;
            var s3FileName = this.roiArchiveFileId + "_" + proiFilename;
            var deleteRequest = {
              "ArchiveNumber":self.archiveNumber,
              "FileName": s3FileName,
              "ArchiveFileId": this.roiArchiveFileId,
              "ModifiedBy": self.employeeUniqueIdentifier
            }

            this.archiveHomeService.DeleteFile(deleteRequest).subscribe(
              res => {

                if (res == true) {
                  self.verified = self.verified.filter(x => x.roiArchiveFileId !== self.roiArchiveFileId);
                  self.notifier.notify(
                    "success",
                    proiFilename + " successfully deleted"
                  );
                 // self.closeDeletePopUp();
                //  this.GetUploadedMemo(this.archiveNumber);
                }
              },
              err => {
                //self.closeDeletePopUp();
                self.notifier.notify(
                  "error",
                  proiFilename + " deletion failed"
                );
              }
            );

          // Delete Deliverable file for associated ROI

          if (!pdeliverablefilename) return false;
          var s3FileName1 = this.deliverableID + "_" + pdeliverablefilename;
          var deleteRequest1 = {
            "ArchiveNumber":self.archiveNumber,
            "FileName": s3FileName1,
            "ArchiveFileId": this.deliverableID,
            "ModifiedBy": self.employeeUniqueIdentifier
          }

          this.archiveHomeService.DeleteFile(deleteRequest1).subscribe(
            res => {

              if (res == true) {
                self.verified = self.verified.filter(x => x.deliverableArchiveFileId !== self.deliverableID);
                self.notifier.notify(
                  "success",
                  self.DeliverableName + " successfully deleted"
                );
               // self.closeDeletePopUp();
              //  this.GetUploadedMemo(this.archiveNumber);
              }
            },
            err => {
              //self.closeDeletePopUp();
              self.notifier.notify(
                "error",
                pdeliverablefilename + " deletion failed"
              );
            }
          );

      }
  */

}//end of class

export enum ROIDateRangePicker {
  DeliverableReleaseDtEnum = 1,
  DeliverableDtEnum = 2,
  LastUpdatedDtEnum = 3
}

export enum matROIGridDataSortBy {
  SortBy_ROINumber_Asc = 1,
  SortBy_ROINumber_Desc = 2,

  SortBy_ReportingEntity_Asc = 3,
  SortBy_ReportingEntity_Desc = 4,

  SortBy_DeliverableType_Asc = 5,
  SortBy_DeliverableType_Desc = 6,

  SortBy_DeliverableName_Asc = 7,
  SortBy_DeliverableName_Desc = 8,

  SortBy_DeliverableReleaseDt_Asc = 9,
  SortBy_DeliverableReleaseDt_Desc = 10,

  SortBy_DeliverableDt_Asc = 11,
  SortBy_DeliverableDt_Desc = 12,

  SortBy_LastUpdatedDt_Asc = 13,
  SortBy_LastUpdatedDt_Desc = 14,

  SortBy_ClientName_Asc = 15,
  SortBy_ClientName_Desc = 16,

  SortBy_EngagementName_Asc = 17,
  SortBy_EngagementName_Desc = 18,

  SortBy_MATROIProfileNumber_Asc = 19,
  SortBy_MATROIProfileNumber_Desc = 20,
}

export enum fileVerificationStatus {
  New = "New"
  , Queued = "Queued"
  , InProgress = "In Progress"
  , VerificationInProgress = "Verification In Progress"
  , Completed = "Completed"
  , Failed = "Failed"
  , VerificationStarted = "Verification Started"
  , VerificationSuccessful = "Verification Successful"
  , VirusScanFailed = "Virus Scan Failed"
  , PasswordProtected = "Password Protected"
  , ChangeTrackingFound = "Change Tracking Found"
  , CarbonCopiesFound = "Carbon Copies Found"
  , CommentsFound = "Comments Found"
  , Canceled = "Canceled"
  , Suspended = "Suspended"
  , UploadedtoRMS = "Uploaded to RMS"
  , VerificationFailed = "Verification Failed"
  , LegacyWAUApproved = "Legacy WAU – Approved"
  , LegacyWAUFailed = "Legacy WAU – Failed"
  , TransferFailed = "Transfer Failed"
  , FileDeletionQueued = "File Deletion Queued"
  , FileDeletionCompleted = "File Deletion Completed"
  , EMSCopyCommandRaised = "EMS Copy Command Raised"
  , EMSCopyCommandQueued = "EMS Copy Command Queued"
  , EMSFileDeletionQueued = "EMS File Deletion Queued"
  , EMSFileDeletionCompleted = "EMS File Deletion Completed"
  , EMSCopyFailed = "EMS Copy Failed"
  , EMSDeletionFailed = "EMS Deletion Failed"
  , FileNotExists = "File Not Exists"
  , FileAIPProtected = "File AIP Protected"
}
export enum DeliverableResultGridColumns {
  DeliverableID = 1,
  ReportingEntity = 2,
  Description = 3,
  DeliverableDate = 4,
  DeliverableTypeID = 5,
  DeliverableReleaseDate = 6,
  GroupAuditReportReleaseDate = 7,
  DeliverableTypeDescription = 8,
  RecordOfIssuanceName = 9,
  ROIStatus = 10,
  RoiNumber = 11,
  ROISize = 12,
  ROIUpdates = 13,
  DeliverableName = 14,
  DeliverableStatus = 15,
  DeliverableSize = 16,
  ArchivedBy = 17,
  ArchiveDate = 18,
  DeliverableDriveDueDate = 19,
  BarCode = 20,
  HardCopyFileStatus = 21,
  DeletedBy = 22,
  IncludeInCalculation = 23,
  ROIFileVerificationStatusId = 24,
  DeliveableFileVerificationStatusId = 25,
  ROIFileVerificationStatus = 26,
  ROIFailedDescription = 27,
  DeliverableFileVerificationStatus = 28,
  DeliverableFailedDescription = 29,
  IsMATROI = 30,
  ROIFileStatus = 31,
  DeliverableFileStatus = 32
}
