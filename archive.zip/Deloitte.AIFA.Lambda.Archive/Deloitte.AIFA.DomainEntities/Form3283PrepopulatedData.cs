﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
    public class Form3283PrepopulatedData
    {
        public List<Form> Forms { get; set; }
        public List<Form3283ReasonType> ReasonTypes { get; set; }
        public List<FormAction> FormActions { get; set; }
    }
}
