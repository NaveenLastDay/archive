﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Deloitte.AIFA.DomainEntities;
using Deloitte.AIFA.DomainServices.Contracts;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Deloitte.AIFA.PushMessageSNSHelper;
using Deloitte.AIFA.DataModels;
using Deloitte.AIFA.ICloudServices;
using Amazon.Lambda.Core;
using Newtonsoft.Json;

namespace Deloitte.AIFA.Lambda.Archive.Controllers
{
    [Route("api/linkedarchives")]
    [ApiController]
    public class LinkedArchiveController : ControllerBase
    {
        ILinkedArchiveService _linkedArchiveService;
        ILogger _logger { get; set; }
        private readonly IHttpContextAccessor _contextAccessor;
        private string userAlias;
        private readonly IUtilityService _utilityServie;
        private List<RoleFunction> roleFunctions;
        public LinkedArchiveController(ILinkedArchiveService linkedArchiveService, ILogger<LinkedArchiveController> logger, IHttpContextAccessor contextAccessor, ICloudCacheService cloudCacheService, IUtilityService utilityServie)
        {
            _logger = logger;
            _linkedArchiveService = linkedArchiveService;
            this._contextAccessor = contextAccessor;
            this._utilityServie = utilityServie;

            _logger.LogInformation("Linked Archive Controller Initiated");
            try
            {
                LambdaLogger.Log("Inside Linked Archive Controller");
                var _context = this._contextAccessor.HttpContext;
                try
                {
                    if (_context?.User?.Claims.Any() == true)
                    {
                        LambdaLogger.Log("Has claims in Linked Archive Controller");
                        foreach (var claim in _context?.User?.Claims)
                        {
                            //LambdaLogger.Log(claim.Type);
                            if (claim.Type == "UserAlias")
                            {
                                userAlias = claim.Value.Split('@')[0].ToString();
                            }
                            LambdaLogger.Log("User Alias from Linked Archive Controller," + userAlias);
                        }
                    }
                    else
                    {
                        LambdaLogger.Log("Has No claims");
                    }
                }
                catch (Exception ex)
                {
                    LambdaLogger.Log("Error with Http context in Linked Archive Controller: " + ex.Message);
                }
            }
            catch (Exception e)
            {
                LambdaLogger.Log("Error in Linked Archive Controller: " + e.Message);
            }
            try
            {
                CacheRequestModel cacheRequestModel = new CacheRequestModel();

                cacheRequestModel.Key = "RoleFunctions";
                _logger.LogInformation("RoleFunctions Cache RequestModelKey from Linked Archive Controller : " + System.Web.HttpUtility.HtmlEncode(cacheRequestModel.Key));
                var data = cloudCacheService.GetValue(cacheRequestModel);
                _logger.LogInformation("cacheLog from Linked Archive Controller :" + System.Web.HttpUtility.HtmlEncode(data));
                if (data == null)
                {
                    roleFunctions = utilityServie.GetRoleFunctions();
                    cacheRequestModel.Value = JsonConvert.SerializeObject(roleFunctions);
                    _logger.LogInformation("RoleFunctions Cache Model Value from Linked Archive Controller : " + System.Web.HttpUtility.HtmlEncode(JsonConvert.SerializeObject(cacheRequestModel.Value)));
                    var val = cloudCacheService.SetValue(cacheRequestModel);
                    _logger.LogInformation("RoleFunctions Cache Service Response from Linked Archive Controller : " + System.Web.HttpUtility.HtmlEncode(val.ToString()));
                }
                else
                {
                    roleFunctions = JsonConvert.DeserializeObject<List<RoleFunction>>(data);
                    _logger.LogInformation("RoleFunctions Cache Value from Linked Archive Controller : " + System.Web.HttpUtility.HtmlEncode(JsonConvert.SerializeObject(roleFunctions)));
                }

            }
            catch (Exception e)
            {
                _logger.LogError("Exception in Cloud Cache Linked Archive Controller :" + e.Message);
            }
        }

        [HttpGet]
        [Route("GetLinkedArchiveDetails")]
        public IActionResult GetLinkedArchiveDetails(string userAlias, string archiveNumber, int pageNumber, int pageSize, int sortBy)
        {
            var id = GetFuntionID("Access Archive");
            var isValid = _utilityServie.IsUserAuthorizedtoPerformAction(archiveNumber, id, userAlias);
            if (isValid)
            {
                _logger.LogInformation("GetListofLinkedArchiveDetails: " + System.Web.HttpUtility.HtmlEncode(archiveNumber));
            var lnkedArchiveResults = _linkedArchiveService.GetListofLinkedArchiveDetails(userAlias,archiveNumber, pageNumber, pageSize, sortBy);
            _logger.LogInformation("GetArchiveDetail: " + System.Web.HttpUtility.HtmlEncode(archiveNumber));
            return Ok(lnkedArchiveResults);
            }
            else
            {
                _logger.LogInformation("Unauthorized Request Details: Action: GetLinkedArchiveDetails, Object " + System.Web.HttpUtility.HtmlEncode(userAlias));
                return Forbid();
            }
        }
        [HttpGet]
        [Route("GetLinkingTypes")]
        public IActionResult GetLinkingTypes()
        {
            _logger.LogInformation("GetLinkingTypes: started");
            var linkTypes = _linkedArchiveService.GetLinkingTypes();
            _logger.LogInformation("GetLinkingTypes: ended");
            return Ok(linkTypes);

        }

        [HttpPost]
        [Route("InsertLinkedArchiveDetails")]
        public IActionResult InsertLinkedArchiveDetails(string archiveNumber, string linkedArchiveNumber, string createdBy)
        {
            var id = GetFuntionID("Archive Linking");
            var isValid = _utilityServie.IsUserAuthorizedtoPerformAction(archiveNumber, id, userAlias);
            if (isValid)
            {
                _logger.LogInformation("InsertLinkedArchiveDetails: " + System.Web.HttpUtility.HtmlEncode(archiveNumber));
            var lnkedArchiveResults = _linkedArchiveService.InsertLinkedArchiveDetails(archiveNumber, linkedArchiveNumber, createdBy);
            _logger.LogInformation("InsertLinkedArchiveDetails: " + System.Web.HttpUtility.HtmlEncode(archiveNumber));
            _logger.LogInformation("Push Message To SNS");
            string input = archiveNumber;
                
                _logger.LogInformation("Archive created with " + System.Web.HttpUtility.HtmlEncode(input));
            string jsonData = @"{""requestParameters"":{""OperationType"":""Insert"",""ArchiveNumber"":""" + input + @"""}}";
            _logger.LogInformation("Json Data : " + System.Web.HttpUtility.HtmlEncode(jsonData));
            PushMessageSNS obj = new PushMessageSNS("esindexingNotifyArn");
            var messageId = obj.PushMsgtoSNS(jsonData).Result;
            jsonData = @"{""requestParameters"":{""OperationType"":""Insert"",""ArchiveNumber"":""" + linkedArchiveNumber + @"""}}";
            messageId = obj.PushMsgtoSNS(jsonData).Result;
            _logger.LogInformation("Before calling UpsertEventSource method from InsertLinkedArchiveDetails action.");
            UpsertEventSource(archiveNumber, userAlias, 2);
                if (messageId != null || messageId != string.Empty || messageId != "")
            {
                _logger.LogInformation("SNS MessageId: " + System.Web.HttpUtility.HtmlEncode(messageId) + " for Archive: " + System.Web.HttpUtility.HtmlEncode(archiveNumber));
            }
            else
            {
                _logger.LogInformation("SNS Message Id is null");
            }
            return Ok(lnkedArchiveResults);
            }
            else
            {
                _logger.LogInformation("Unauthorized Request Details: Action: InsertLinkedArchiveDetails, Object " + System.Web.HttpUtility.HtmlEncode(userAlias));
                return Forbid();
            }            
        }
        [HttpPost]
        [Route("UpdateLinkedArchiveDetails")]
        public IActionResult UpdateLinkedArchiveDetails(string archiveNumber, string linkedArchiveNumber, int? linkTypeId, string OpertaionType, string createdBy)
        {
            var id = GetFuntionID("Archive Linking");
            var isValid = _utilityServie.IsUserAuthorizedtoPerformAction(archiveNumber, id, userAlias);
            if (isValid)
            {
            _logger.LogInformation("UpdateLinkedArchiveDetails: " + System.Web.HttpUtility.HtmlEncode(archiveNumber));
            var lnkedArchiveResults = _linkedArchiveService.UpdateLinkedArchiveDetails(archiveNumber, linkedArchiveNumber, linkTypeId,OpertaionType, createdBy);
            _logger.LogInformation("UpdateLinkedArchiveDetails: " + System.Web.HttpUtility.HtmlEncode(archiveNumber));
                if (OpertaionType == "Delete") {
                string jsonData = @"{""requestParameters"":{""OperationType"":""Insert"",""ArchiveNumber"":""" + archiveNumber + @"""}}";
                _logger.LogInformation("Json Data : " + System.Web.HttpUtility.HtmlEncode(jsonData));
                PushMessageSNS obj = new PushMessageSNS("esindexingNotifyArn");
                var messageId = obj.PushMsgtoSNS(jsonData).Result;
                jsonData = @"{""requestParameters"":{""OperationType"":""Insert"",""ArchiveNumber"":""" + linkedArchiveNumber + @"""}}";
                messageId = obj.PushMsgtoSNS(jsonData).Result;
                if (messageId != null || messageId != string.Empty || messageId != "")
                {
                    _logger.LogInformation("SNS MessageId: " + System.Web.HttpUtility.HtmlEncode(messageId) + " for Archive: " + System.Web.HttpUtility.HtmlEncode(archiveNumber));
                }
                else
                {
                    _logger.LogInformation("SNS Message Id is null");
                }
                }
                _logger.LogInformation("Before calling UpsertEventSource method from UpdateLinkedArchiveDetails action.");
                UpsertEventSource(archiveNumber, userAlias, 2);
                return Ok(lnkedArchiveResults);
            }
            else
            {
                _logger.LogInformation("Unauthorized Request Details: Action: UpdateLinkedArchiveDetails, Object " + System.Web.HttpUtility.HtmlEncode(userAlias));
                return Forbid();
            }
        }
        private int GetFuntionID(string functionName)
        {
            LambdaLogger.Log("cacheLog43234432:" + functionName);
            _logger.LogInformation("cacheLog12798778:" + System.Web.HttpUtility.HtmlEncode(functionName));
            var Id = roleFunctions.Where(e => e.FunctionName == functionName).Select(x => x.Id).FirstOrDefault();
            _logger.LogInformation("functionId: " + System.Web.HttpUtility.HtmlEncode(Id.ToString()));
            return Id;
        }
        #region UpsertEventSource        
        [NonAction]
        private void UpsertEventSource(string metadata, string empAlias, int eventTypeID)
        {
            EventSource eventSource = null, eventSourceOut = null;
            try
            {
                eventSource = new EventSource() { Metadata = metadata, CreatedBy = empAlias, CreatedDate = DateTime.Now, IsProcessed = false, EventTypeID = eventTypeID };
                eventSourceOut = _utilityServie.UpsertEventSource(eventSource);
            }
            catch (Exception ex)
            {
                _logger.LogError(string.Format("Exception occured in UpsertEventSource method ArchiveController. ExceptionMessage: {0}, StackTrace: {1}", ex.Message, ex.StackTrace));
            }
        }
        #endregion UpsertEventSource
    }
}