﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
    public  class ResubmissionApprover
    {
        public int TotalLevelofApproval { get; set; }
        public List<ResubmissionApproverList> lstResubmissionApprover { get; set; }
        public string CompletedApprovel { get; set; }
        public bool CanApprove { get; set; }
    }
}
