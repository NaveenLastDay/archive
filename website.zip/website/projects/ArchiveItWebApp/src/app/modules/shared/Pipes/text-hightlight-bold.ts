import { Pipe, PipeTransform } from '@angular/core';
import { DatePipe } from '@angular/common';

@Pipe({
  name: 'texthighlightbold',
  pure: false
})
export class TextHighlightboldPipe implements PipeTransform {

  constructor( private datePipe: DatePipe){

  }

  transform(value: string, args: any) {
    value = String(value);
    if (value && args) {
      if (!Array.isArray(args)) {
        args = args.replace(/^[^a-zA-Z0-9]*|[^a-zA-Z0-9]*$/g, '');       
        const orginalVal = value.substr(value.toLowerCase().indexOf(args.toLowerCase()), args.length);
        const re = new RegExp(args, 'gi');
        return value.replace(re, "<mark>" + orginalVal + "</mark>");
      }
      else if (args.length > 0) {        
        if (args[0].StartDate && args[0].EndDate) {
          var fromDate = Date.parse(this.datePipe.transform(args[0].StartDate, "yyyy-MM-dd"));
          var toDate = Date.parse(this.datePipe.transform(args[0].EndDate, "yyyy-MM-dd"));
          var dateValue = Date.parse(this.datePipe.transform(value, "yyyy-MM-dd"));
          if (fromDate <= dateValue && dateValue <= toDate) {
            return "<mark>" + value + "</mark>";
          }
        }
        else {
          if (args.findIndex(x => x.toLowerCase() == value.toLowerCase()) != -1) {
            return "<mark>" + value + "</mark>";
          }
        }
      }
    }
    return value;
  }
}
