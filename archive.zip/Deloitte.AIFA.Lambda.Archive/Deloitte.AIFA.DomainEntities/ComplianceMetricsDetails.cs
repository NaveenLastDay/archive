﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
    public class ComplianceMetricsDetails
    {
        public string ArchiveNumber { get; set; }

        public string ClientName { get; set; }

        public string EngagementDescription { get; set; }

        public string PeriodEndDate { get; set; }

        public string DueDate { get; set; }

        public string InitialApproval { get; set; }

        public string WBSLevelOneNumber { get; set; }

        public string ComplianceStatus { get; set; }


        public string EngagementTypeDescription { get; set; }

        public string EstimatedIssuanceReportDate { get; set; }

        public string ArchiveDueDate { get; set; }

        public string ADCED { get; set; }

        public string IsResubmissionInProgress { get; set; }

        public string Description { get; set; }

        public string EntityTypeDescription { get; set; }

        public string ProfessionalStandardDescription { get; set; }

        public string ReportingEntity { get; set; }

        public string ArchivePartner { get; set; }

        public string ArchiveManager { get; set; }

        public string ArchiveFieldSenior { get; set; }

        public string AddArchiveFieldSenior { get; set; }
        public int RowNumber { get; set; }
        public int Count { get; set; }
        public int OnTimeCount { get; set; }
        public int LateWithApprovalCount { get; set; }
        public int LateCount { get; set; }
        public int LatePast45DaysCount { get; set; }
        public int CountBeforeFiltering { get; set; }
    }
}
