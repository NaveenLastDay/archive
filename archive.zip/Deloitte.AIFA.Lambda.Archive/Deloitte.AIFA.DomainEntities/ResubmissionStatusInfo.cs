﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
    public class ResubmissionStatusInfo
    {
        public string Message { get; set; }
        public string ArchiveStatus { get; set; }
        public string OfficeCode { get; set; }
    }
}
