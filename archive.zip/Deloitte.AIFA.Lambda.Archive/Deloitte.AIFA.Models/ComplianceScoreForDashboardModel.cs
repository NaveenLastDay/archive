﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DataModels
{
    public class ComplianceScoreForDashboardModel
    {
        public int ComplianceMetricsScore { get; set; }

    }
}
