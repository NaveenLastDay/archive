import { Component, OnInit, ElementRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { LegalHoldService } from '../../../services/legalhold.service';
import { ModalService } from '../../shared/modal';
import { AngularEditorConfig } from '@kolkov/angular-editor';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { ArchiveHomeService } from '../../../services/archive-home.service';
import { NotifierService } from 'angular-notifier';
import { PeoplePickerService } from '../../../services/MDREmployeeeDetails.service';
import { ArchiveService } from '../../../services/archive.service';
import { BehaviorSubject } from 'rxjs';
import { distinctUntilChanged, debounceTime } from 'rxjs/operators';
/*import { NgbDate, NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';*/
import { CustomDateFormatter } from '../../shared/shared-custom-dateformatter';
import { archiveInfoService } from '../../../services/archiveinfo.service'

@Component({
  selector: 'app-legal-hold',
  templateUrl: './legal-hold.component.html',
  styleUrls: ['./legal-hold.component.css']
 /* providers: [{provide: NgbDateParserFormatter, useClass: CustomDateFormatter}]*/
})
export class LegalHoldComponent implements OnInit {
  [x: string]: any;
  archiveNumber: string;
  employeeUniqueIdentifier: string = "";
  isArchiveDestroyed:number = 0;
  userAlias = this.adalSvc.LoggedInUserEmail.substring(0, this.adalSvc.LoggedInUserEmail.lastIndexOf("@"));
  Description: string;
  legalhold_form: FormGroup;
  selectedPartnerViewName: string = "";
  selectedPartner: string;
  activeroles: any;
  fieldArray: Array<any> = [];
  archivepartner: any;
  PPMDUsers: Array<any> = [];
  users: Array<any> = [];
  newAttribute: any = {};
  addIndex: number;
  rolecode: string;
  matterid: number;
  OGCDate: Date = undefined;
  //isDisabled:any;

  maxDate: Date;
  mailText: string = "";
  mailBody: string = "Hi Records Management Holds Processing team, ";
  holdsMailBoxAddress = "RecordsHolds@deloitte.com";

  lastSearchKeyword: string = '';
  currentSearchKeyword: string = '';

  private _subject: BehaviorSubject<string> = new BehaviorSubject<string>("");

  constructor(private legalHoldService: LegalHoldService, private archiveInfoService: archiveInfoService, private peoplePickerService: PeoplePickerService, private archiveHomeService: ArchiveHomeService, private modalService: ModalService, private service: ArchiveService, public formBuilder: FormBuilder,
    private notifier: NotifierService, private activatedRoute: ActivatedRoute, private spinnerService: NgxSpinnerService, private router: Router, public fb: FormBuilder, private adalSvc: MsAdalAngular6Service) {
     // this.isDisabled = (date: NgbDate, current: { month: number; year: number }) => date.month !== current.month;
      this.legalhold_form = fb.group({
      'archivepartner': [null, Validators.required],
      'matterid': [null, Validators.required],
      'OGC': [null, [Validators.required, Validators.pattern('[0-9]{2}/[0-9]{2}/[0-9]{4}')]],
    });
    this.maxDate = new Date();
  }

  /*text editor config*/
  editorConfig: AngularEditorConfig = {

    editable: true,
    spellcheck: true,
    height: 'auto',
    minHeight: '120',
    maxHeight: 'auto',
    width: 'auto',
    minWidth: '0',
    translate: 'yes',
    enableToolbar: true,
    showToolbar: true,
    placeholder: 'Please enter the reason',
    defaultParagraphSeparator: '',
    defaultFontName: '',
    defaultFontSize: '',
    fonts: [
      { class: 'arial', name: 'Arial' },
      { class: 'times-new-roman', name: 'Times New Roman' },
      { class: 'calibri', name: 'Calibri' },
      { class: 'comic-sans-ms', name: 'Comic Sans MS' }
    ],

    customClasses: [
      {
        name: 'quote',
        class: 'quote',
      },
      {
        name: 'redText',
        class: 'redText'
      },
      {
        name: 'titleText',
        class: 'titleText',
        tag: 'h1',
      },
    ],
    uploadUrl: '',
    uploadWithCredentials: false,
    sanitize: true,
    toolbarPosition: 'top',
    toolbarHiddenButtons: [
      [
        'undo',
        'redo',
        'subscript',
        'superscript',
        'justifyFull',
        'indent',
        'outdent',
        'insertOrderedList',
        'heading',
        //'fontName'
      ],
      [
        'textColor',
        'backgroundColor',
        'customClasses',
        //'link',
        'unlink',
        'insertImage',
        'insertVideo',
        'insertHorizontalRule',
        'removeFormat',
        'toggleEditorMode'
      ]
    ]
  };

  ngOnInit() {
    this.archiveNumber = this.activatedRoute.snapshot.parent.paramMap.get('aN');
    this.archiveHomeService.SyncForm3283SStatus(this.archiveNumber); 
    this.employeeUniqueIdentifier = this.adalSvc.LoggedInUserEmail.split('@')[0];
    this.archiveInfoService.getArchiveInfo(this.archiveNumber, this.employeeUniqueIdentifier).subscribe(
      (info) => {
        this.isArchiveDestroyed = info.isDestroyed;
      }
    );
  }


  mailToAddress() {
    this.mailText = "mailto:" + this.holdsMailBoxAddress + "?subject=Questions&body=" + this.mailBody;
    window.location.href = this.mailText;
  }

  getDateInFormat(d:number)
  {
    return (d < 10 ? '0' +d : d);
  }
  convertToDateFormat(inputDate:any){
   return this.getDateInFormat(inputDate.month)  + "/" + this.getDateInFormat(inputDate.day) + "/" + inputDate.year;
  }

  onInputChanged(searchString: string, roleType?: string, indexValue?: number) {
    this.users = [];
    this.addIndex = indexValue;
    switch (roleType) {
      case "ArchivePartner":
        this.rolecode = "AP";
    }
    this.currentSearchKeyword = searchString;
    this._subject.next(this.currentSearchKeyword ? this.currentSearchKeyword.trim() : "");

    if (searchString.length >= 3) {
      this._subject.pipe(
        distinctUntilChanged(),
        debounceTime(500),
      ).subscribe(value => this.getPeople(value))
    }
    else {
      this.users = [];
      this.lastSearchKeyword = '';
    }
    //this.spinnerService.hide();
  }
  getPeople(searchString: string) {
    if (searchString.length >= 3 && this.lastSearchKeyword != searchString) {
      this.lastSearchKeyword = searchString;
      this.peoplePickerService.GetPeople(searchString).subscribe(
        (value) => {
          this.users = [];
          value.forEach(element => {
            if (this.currentSearchKeyword.length >= 3) {
              // if (element.isPPD)
              this.users = value;
            } else {
              this.users = [];
            }
          });
        },
        (err) => {
          console.log("error is ", err)
        }
      );
     this.spinnerService.hide();
    }
  }

  markFormTouched(group: FormGroup | FormArray) {
    Object.keys(group.controls).forEach((key: string) => {
      const control = group.controls[key];
      if (control instanceof FormGroup || control instanceof FormArray) { control.markAsTouched(); this.markFormTouched(control); }
      else { control.markAsTouched(); };
    });
  };

  saveLegalHold(){
    if (this.selectedPartnerViewName == "" && this.selectedPartner == undefined) {
      this.notifier.notify("error", "Please select valid OGC team member");
      return;
    }
    this.markFormTouched(this.legalhold_form);
    if (this.legalhold_form.valid) {
      var parameters =
      {
        "ArchiveNumber": this.archiveNumber,
        "OGCHoldNumber": this.matterid,
        "OGCPreservationNoticeDate": this.convertToDateFormat(this.OGCDate),
        "OGCAttorneyName": this.selectedPartner,
        "Description": this.Description,
        "CreatedBy": this.userAlias
      }
      var myobjstr = JSON.stringify(parameters);
      console.log("SATEESH::::::::::::::");
      console.log(myobjstr);
      this.legalHoldService.SaveLegalHold(myobjstr).subscribe(data => {
        this.notifier.notify("success", "Success! Your legal hold proposal has been sent to Records Management Services.");
        if(data)
        {
          setTimeout(() => { this.goToArchiveHomePage(); }, 2500);
        }
      });
    }
  }

  onChange(event: any) {
    this.OGCDate = event;
  }

  selectedPartnerName(partner, index) {
    this.selectedPartnerViewName = partner.source.viewValue;
    this.selectedPartner = this.users[index].userAlias;//change to useralias once lambda is changed.
  }

  cancelLegalHold() {
    this.legalhold_form.get('archivepartner').setValue(this.selectedPartnerViewName);
    this.goToArchiveHomePage();
  }

  goToArchiveHomePage() {
    this.router.navigate(["/archive/myarchives/" + this.archiveNumber]);
  }
}

