import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManagearchiveteamComponent } from './managearchiveteam.component';

describe('ManagearchiveteamComponent', () => {
  let component: ManagearchiveteamComponent;
  let fixture: ComponentFixture<ManagearchiveteamComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManagearchiveteamComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManagearchiveteamComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
