﻿using Deloitte.AIFA.DataModels;
using Deloitte.AIFA.DBHelper;
using System;
using System.Collections.Generic;
using System.Data;

namespace Deloitte.AIFA.Repositories.Transformers
{
    public enum FormFieldParameter
    {
        [CreateField(Name = "p_FormId", Direction = ParameterDirection.Input, Type = DbType.String)]
        Id,
        [CreateField(Name = "p_ArchiveNumber", Direction = ParameterDirection.Input, Type = DbType.String)]
        ArchiveNumber,
        [CreateField(Name = "p_ArchivePartner", Direction = ParameterDirection.Input, Type = DbType.String)]
        ArchivePartner,
        [CreateField(Name = "p_ProposedADCEDDate", Direction = ParameterDirection.Input, Type = DbType.DateTime)]
        ProposedADCEDDate,
        [CreateField(Name = "p_ReasonTypeIDs", Direction = ParameterDirection.Input, Type = DbType.String)]
        ReasonType,
        [CreateField(Name = "p_ReasonDescription", Direction = ParameterDirection.Input, Type = DbType.String)]
        ReasonDescription,
        [CreateField(Name = "p_AdditionalDetails", Direction = ParameterDirection.Input, Type = DbType.String)]
        AdditionalDetails,
        [CreateField(Name = "p_ActionsToBeTaken", Direction = ParameterDirection.Input, Type = DbType.String)]
        ActionsTobeTaken,
        [CreateField(Name = "p_AuditPIC", Direction = ParameterDirection.Input, Type = DbType.String)]
        AuditPIC,
        [CreateField(Name = "p_AuditPPD", Direction = ParameterDirection.Input, Type = DbType.String)]
        AuditPPD,
        [CreateField(Name = "p_CreatedBy", Direction = ParameterDirection.Input, Type = DbType.String)]
        CreatedBy,
        [CreateField(Name = "p_ActionItemId", Direction = ParameterDirection.Input, Type = DbType.Int32)]
        ActionItemId,
        [CreateField(Name = "p_ModifiedBy", Direction = ParameterDirection.Input, Type = DbType.String)]
        ModifiedBy,
        [CreateField(Name = "p_ApprovedBy", Direction = ParameterDirection.Input, Type = DbType.String)]
        ApprovedBy,
        [CreateField(Name = "p_RejectedBy", Direction = ParameterDirection.Input, Type = DbType.String)]
        RejectedBy,
        [CreateField(Name = "p_LoggedInUser", Direction = ParameterDirection.Input, Type = DbType.String)]
        LoggedInUser,
        [CreateField(Name = "p_RejectionReason", Direction = ParameterDirection.Input, Type = DbType.String)]
        RejectionReason,
        [CreateField(Name = "p_IsEditRequired", Direction = ParameterDirection.Input, Type = DbType.Boolean)]
        IsEditRequired,
        [CreateField(Name = "p_ChangedTo", Direction = ParameterDirection.Input, Type = DbType.String)]
        ChangedTo,
        [CreateField(Name = "p_ChangedBy", Direction = ParameterDirection.Input, Type = DbType.String)]
        ChangedBy,
        [CreateField(Name = "p_Identifier", Direction = ParameterDirection.Input, Type = DbType.String)]
        Identifier,
        [CreateField(Name = "p_TimeOffset", Direction = ParameterDirection.Input, Type = DbType.Int32)]
        TimeOffset,
        [CreateField(Name = "p_ArchiveDueDateCriteria", Direction = ParameterDirection.Input, Type = DbType.String)]
        ArchiveDueDateCriteria,
        [CreateField(Name = "p_DeliverableType", Direction = ParameterDirection.Input, Type = DbType.String)]
        DeliverableType,
        [CreateField(Name = "p_DateThatDrivesEDCD", Direction = ParameterDirection.Input, Type = DbType.DateTime)]
        DateThatDrivesEDCD,
        [CreateField(Name = "p_RDCDDate", Direction = ParameterDirection.Input, Type = DbType.DateTime)]
        RDCDDate
    }

    public enum FormOutputFields
    {
        FormId,
        ReasonDescription,
        ArchivePartner,
        TypeOfEntity,
        EDCDDate,
        RDCDDate,
        Id,
        ArchiveNumber,
        ProposedADCEDDate,
        Reason,
        ReasonTypeId,
        ReasonTypeDescription,
        AdditionalDetails,
        ActionsToBeTaken,
        CreatedBy,
        FormActionId,
        FormActionAssignedTo,
        FormActionIdentifier,
        FormActionAssignedToFullName,
        FormActionStatusDescription,
        IsApprover,
        IsSelectedBefore,
        ResponseMessage,
        IsSuccessful,
        CompletedDate,
        FormStatus,
        RejectionReason,
        RejectionReasonDate,
        RejectionReasonByFullName,
        IsActive,
        IsNewFormData,
        SubmittedDate,
        ActionItemStatusDescription,
        ApprovedBy,
        SubmittedBy,
        ADCED,
        ArchiveDueDateCriteria,
        DeliverableType,
        DateThatDrivesEDCD
}
    public class Form3283PrepopulatedDataTransformer : BaseTransformer<Form3283PrepopulatedDataModel>
    {
        internal override Form3283PrepopulatedDataModel TransformElement(IDataReader dr, Func<IDataReader, Form3283PrepopulatedDataModel, Form3283PrepopulatedDataModel> bindExtraFields = null)
        {
            var form3283PrepopulatedData = new Form3283PrepopulatedDataModel();

            List<FormModel> forms = new List<FormModel>();
            while (dr.Read())
            {
                FormModel form = new FormModel()
                {
                    FormId = dr[FormOutputFields.FormId.ToString()] is DBNull ? 0 : Convert.ToInt32(dr[FormOutputFields.FormId.ToString()]),
                    ArchivePartner = (dr[FormOutputFields.ArchivePartner.ToString()] is DBNull) ? string.Empty : dr[FormOutputFields.ArchivePartner.ToString()].ToString(),
                    TypeOfEntity = (dr[FormOutputFields.TypeOfEntity.ToString()] is DBNull ? string.Empty : dr[FormOutputFields.TypeOfEntity.ToString()].ToString()),
                    EDCDDate = (dr[FormOutputFields.EDCDDate.ToString()] is DBNull) ? DateTime.MinValue : DateTime.Parse(dr[FormOutputFields.EDCDDate.ToString()].ToString()),
                    RDCDDate = (dr[FormOutputFields.RDCDDate.ToString()] is DBNull) ? DateTime.MinValue : DateTime.Parse(dr[FormOutputFields.RDCDDate.ToString()].ToString()),
                    ProposedADCEDDate = (dr[FormOutputFields.ProposedADCEDDate.ToString()] is DBNull) ? (DateTime?) null : DateTime.Parse(dr[FormOutputFields.ProposedADCEDDate.ToString()].ToString()),
                    AdditionalDetails = (dr[FormOutputFields.AdditionalDetails.ToString()] is DBNull) ? string.Empty : dr[FormOutputFields.AdditionalDetails.ToString()].ToString(),
                    ActionsToBeTaken = (dr[FormOutputFields.ActionsToBeTaken.ToString()] is DBNull) ? string.Empty : dr[FormOutputFields.ActionsToBeTaken.ToString()].ToString(),
                    FormStatus = (dr[FormOutputFields.FormStatus.ToString()] is DBNull) ? string.Empty : dr[FormOutputFields.FormStatus.ToString()].ToString(),
                    RejectionReason = (dr[FormOutputFields.RejectionReason.ToString()] is DBNull) ? string.Empty : dr[FormOutputFields.RejectionReason.ToString()].ToString(),
                    RejectionReasonByFullName = (dr[FormOutputFields.RejectionReasonByFullName.ToString()] is DBNull) ? string.Empty : dr[FormOutputFields.RejectionReasonByFullName.ToString()].ToString(),
                    RejectionReasonDate = (dr[FormOutputFields.RejectionReasonDate.ToString()] is DBNull) ? (DateTime?)null : DateTime.Parse(dr[FormOutputFields.RejectionReasonDate.ToString()].ToString()),
                    IsApprover = dr[FormOutputFields.IsApprover.ToString()] is DBNull ? false : Convert.ToBoolean(dr[FormOutputFields.IsApprover.ToString()]),              
                    IsActive = dr[FormOutputFields.IsActive.ToString()] is DBNull ? false : Convert.ToBoolean(dr[FormOutputFields.IsActive.ToString()]),
                    IsNewFormData = dr[FormOutputFields.IsNewFormData.ToString()] is DBNull ? false : Convert.ToBoolean(dr[FormOutputFields.IsNewFormData.ToString()]),
                    SubmittedDate = (dr[FormOutputFields.SubmittedDate.ToString()] is DBNull) ? (DateTime?)null : DateTime.Parse(dr[FormOutputFields.SubmittedDate.ToString()].ToString()),
                    ArchiveDueDateCriteria = (dr[FormOutputFields.ArchiveDueDateCriteria.ToString()] is DBNull) ? string.Empty : dr[FormOutputFields.ArchiveDueDateCriteria.ToString()].ToString(),
                    DeliverableType = (dr[FormOutputFields.DeliverableType.ToString()] is DBNull) ? string.Empty : dr[FormOutputFields.DeliverableType.ToString()].ToString(),
                    DateThatDrivesEDCD = (dr[FormOutputFields.DateThatDrivesEDCD.ToString()] is DBNull) ? (DateTime?)null : DateTime.Parse(dr[FormOutputFields.DateThatDrivesEDCD.ToString()].ToString())
    };
                forms.Add(form);
            }
            form3283PrepopulatedData.Forms = forms;

            List<Form3283ReasonTypeModel> reasonTypes = new List<Form3283ReasonTypeModel>();

            if (dr.NextResult())
            {           
                while(dr.Read())
                {
                    Form3283ReasonTypeModel reasonType = new Form3283ReasonTypeModel
                    {
                        FormId = dr[FormOutputFields.FormId.ToString()] is DBNull ? 0 : Convert.ToInt32(dr[FormOutputFields.FormId.ToString()]),
                        ReasonTypeId = Convert.ToInt32(dr[FormOutputFields.ReasonTypeId.ToString()]),
                        ReasonTypeDescription = (dr[FormOutputFields.ReasonTypeDescription.ToString()] is DBNull) ? string.Empty : dr[FormOutputFields.ReasonTypeDescription.ToString()].ToString(),
                        IsSelectedBefore = dr[FormOutputFields.IsSelectedBefore.ToString()] is DBNull ? false : Convert.ToBoolean(dr[FormOutputFields.IsSelectedBefore.ToString()])
                    };
                    reasonTypes.Add(reasonType);
                };
            }
            form3283PrepopulatedData.ReasonTypes = reasonTypes;

            List<FormActionModel> actions = new List<FormActionModel>();
            if (dr.NextResult())
            {
                while (dr.Read())
                {
                    FormActionModel action = new FormActionModel
                    {
                        EntityId = Convert.ToInt32(dr[FormOutputFields.FormId.ToString()]),
                        ActionItemId = Convert.ToInt32(dr[FormOutputFields.FormActionId.ToString()]),
                        ActionItemIdentifier = (dr[FormOutputFields.FormActionIdentifier.ToString()] is DBNull) ? string.Empty : dr[FormOutputFields.FormActionIdentifier.ToString()].ToString(),
                        ActionItemAssignedTo = (dr[FormOutputFields.FormActionAssignedTo.ToString()] is DBNull) ? string.Empty : dr[FormOutputFields.FormActionAssignedTo.ToString()].ToString(),
                        ActionItemAssignedToFullName = (dr[FormOutputFields.FormActionAssignedToFullName.ToString()] is DBNull) ? string.Empty : dr[FormOutputFields.FormActionAssignedToFullName.ToString()].ToString(),
                        ActionItemStatusDescription = (dr[FormOutputFields.FormActionStatusDescription.ToString()] is DBNull) ? string.Empty : dr[FormOutputFields.FormActionStatusDescription.ToString()].ToString(),
                        CompletedDate = (dr[FormOutputFields.CompletedDate.ToString()] is DBNull) ? (DateTime?)null : DateTime.Parse(dr[FormOutputFields.CompletedDate.ToString()].ToString())
                };
                    actions.Add(action);
                };
            }
            form3283PrepopulatedData.FormActions = actions;

            return form3283PrepopulatedData;
        }
    }
}
