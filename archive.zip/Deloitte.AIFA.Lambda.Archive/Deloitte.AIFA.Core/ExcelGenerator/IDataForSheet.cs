﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.Helpers.ExcelGenerator
{
    public interface IDataForSheet
    {
    }
}
