import { CanDeactivate,Router, ActivatedRoute } from "@angular/router";
import { Injectable } from "@angular/core";
import { FileuploadProgressComponent } from "../modules/record/fileUpload-progress/fileupload-progress.component";
import { FileUploadEventService } from '../modules/record/file-upload/fileupload.event.service';
import { LinkedArchivesComponent } from '../modules/archive/linked-archives/linked-archives.component';
import { Observable } from 'rxjs';
import { ModalService } from '../modules/shared/modal';
import { FileUploadProcessService } from '../modules/record/file-upload/fileupload.process.service';
import { FielUploadService } from '../services/fileupload.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { NotifierService } from 'angular-notifier';
import { LinkedArchivesService } from '../services/linked-archives.service';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';

@Injectable()
export class LinkedDashboardValidationGuard
  implements CanDeactivate<LinkedArchivesComponent> {
  constructor(
    private linkedArchivesService: LinkedArchivesService,
    private adalSvc: MsAdalAngular6Service,
    private activatedRoute: ActivatedRoute,
    private _spinnerService: NgxSpinnerService,
    private modalService: ModalService,
    private notifier: NotifierService,
    private router: Router,
    private _activatedRoute: ActivatedRoute) { }

  result: boolean = false;
  linkedArchives: any = [];
  archiveNumber = "";
  userEmail = this.adalSvc.LoggedInUserEmail;
  euserAlias = this.userEmail.replace("@deloitte.com", "");
  currentPageNumber: number = 1;
  readonly pageSize: number = 10;
  sortBy: number = 12;

  canDeactivate(
    linkedArchivecomponent: LinkedArchivesComponent
  ): boolean | Observable<boolean> | Promise<boolean> {
    
    var nResult = true;
    console.log("linkedArchivecomponent:::::::");
    console.log(linkedArchivecomponent.linkedArchives);
    if(linkedArchivecomponent.linkedArchives.length > 0)
    {
        linkedArchivecomponent.linkedArchives.forEach(function(element,index){
        if(element.linkTypeID==0  && element.linkLevel==1 && element.isDirectLink==1)
        {
          console.log("linkTypeID:::" + element.linkTypeID);
          nResult = false;
        }
      });
    }
    
    if(!nResult)
      this.notifier.notify("error", "Select the Type of link before proceeding.");
    return nResult;
  }  
}
