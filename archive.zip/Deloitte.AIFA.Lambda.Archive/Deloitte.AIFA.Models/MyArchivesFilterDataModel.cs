﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.Models
{
    public class MyArchivesFilterDataModel
    {
        public int RowNumber { get; set; }
        public string FilterData { get; set; }
    }
}
