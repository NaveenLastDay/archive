import { Component, OnInit, ViewChild } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { ArchiveService } from '../../../services/archive.service';
import { ModalService } from '../../shared/modal';
import { NotifierService } from 'angular-notifier';
import { SearchWbsService } from '../../../services/searchwbs.service';
import { PeoplePickerService } from '../../../services/MDREmployeeeDetails.service';
import { FormGroup } from '@angular/forms';
import { BehaviorSubject } from 'rxjs';
import { distinctUntilChanged, debounceTime } from 'rxjs/operators';



@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})

export class CreateComponent implements OnInit {
  currentUrl: string;

  //Variables get selected values
  selectedEngagementType: string = "";
  selectedEntityType: string = "";
  selectedEntity: string = "";
  selectedArchiveType: string = "";

  //Variables to get entered values
  myarchive_description: string;
  displaytextbox: boolean = false;

  // Assigning for Date field

  archiveDate: Date;
  toDate: Date = undefined;

  //Declared myModel variable for a event
  myModel: any;

  //Variable for Creating Archive method
  createdArchive: any;
  ArchiveNumber: string;

  // Textbox variable
  ArchiveName: string = "";
  //Assigning variable for Dropdown
  EngagementType: number = 0;
  engagements: any;
  entitytype: number;
  entities: any;
  archivenames: any;
  // Assigning Variable for Textboxes 
  AdditionalDescriptor: string = "";
  ArchivePartner: string = "";
  ArchiveFieldSenior: string = "";
  AdditionalArchiveFieldSenior: string = "";
  EntityType: number = 0;
  ArchiveType: number = 0;
  Entity: number = 0;
  wbsData: any = "";

  //For people picker
  searchText: string;
  users: Array<any> = [];
  searchPeople: FormGroup;
  selectedPartner: string;
  selectedPartnerViewName: string = "";
  selectedFieldSenior: string = "";
  selectedAdditionalFieldSenior: string;
  selectedFieldSeniorViewName: string = "";
  selectedAdditionalFieldSeniorViewName: string = "";
  selectedSigningPartnet1: string;
  selectedSigningPartnet1ViewName: string = "";
  selectedSigningPartnet2ViewName: string = "";
  selectedSigningPartnet2: string;
  selectedSigningPartnet3ViewName: string = "";
  selectedSigningPartnet3: string;
  selectedSigningPartnet4ViewName: string = "";
  selectedSigningPartnet4: string;
  service : ArchiveService;

  
  lastSearchKeyword: string = '';
  currentSearchKeyword: string = '';

  private _subject: BehaviorSubject<string> = new BehaviorSubject<string>("");


  constructor(private router: Router, private archiveService: ArchiveService, private peoplePickerService: PeoplePickerService,
    private modalService: ModalService, private notifier: NotifierService, private searchwbs: SearchWbsService) {

    router.events.subscribe((_: NavigationEnd) => this.currentUrl = this.router.url);
    this.service = archiveService;
  }

  ngOnInit() {
    // // debugger;
    //For WBS No,Client Name Binding

    /*this.searchwbs.getSelectedWbsData().toPromise().then(x => {
      console.log(x);
      this.wbsData = x[0]

    }
    );*/

    // For dropdown binding

    this.getengagementtypes();
    this.getentities();
    this.getentitytypes();
    this.getarchivetypes();
    //this.getEmployeesFromPeoplePicker();

  }

  //For PeoplePicker

  onInputChanged(searchString: string) {
    // // debugger;
    this.users = [];
    
    this.currentSearchKeyword = searchString;
    this._subject.next(this.currentSearchKeyword ? this.currentSearchKeyword.trim() : "");

    if (searchString.length >= 3) {
      this._subject.pipe(
        distinctUntilChanged(),
        debounceTime(500),
      ).subscribe(value => this.getPeople(value))
    }
    else if (searchString.length == 0) {
      this.users = [];
    }
    else {
      this.users = [];
    }
  }

  getPeople(searchString: string) {
    if (searchString.length >= 3 && this.lastSearchKeyword != searchString) {
      this.lastSearchKeyword = searchString;
      this.peoplePickerService.GetPeople(searchString).subscribe(
        (value) => {
          this.users = [];
          value.forEach(element => {
            if (this.currentSearchKeyword.length >= 3) {
              // if (element.isPPD)
              this.users = value;
            } else {
              this.users = [];
            }
          });
        },
        (err) => {
          console.log("error is ", err)
        }
      );

    }
  }

  selectedPartnerName(partner, index) {
    // // debugger;
    // this.myarchive_description = partner.target.options[partner.target.selectedIndex].text;
    this.selectedPartnerViewName = partner.source.viewValue;
    this.selectedPartner = this.users[index].userAlias;//change to useralias once lambda is changed.
  }

  selectedFieldSeniorName(fieldsenior, index) {
    // // debugger;
    this.selectedFieldSeniorViewName = fieldsenior.source.viewValue;
    this.selectedFieldSenior = this.users[index].userAlias;//change to useralias once lambda is changed.
  }

  selectedAdditionalFieldSeniorName(additionalfieldsenior, index) {
    // // debugger;
    this.selectedAdditionalFieldSeniorViewName = additionalfieldsenior.source.viewValue;
    this.selectedAdditionalFieldSenior = this.users[index].userAlias;//change to useralias once lambda is changed.
  }

  selectedSigningPartnetName1(signingpartner1, index) {
    // // debugger;
    this.selectedSigningPartnet1ViewName = signingpartner1.source.viewValue;
    this.selectedSigningPartnet1 = this.users[index].userAlias;//change to useralias once lambda is changed.
  }

  selectedSigningPartnetName2(signingpartner2, index) {
    // // debugger;
    this.selectedSigningPartnet2ViewName = signingpartner2.source.viewValue;
    this.selectedSigningPartnet2 = this.users[index].userAlias;//change to useralias once lambda is changed.
  }

  selectedSigningPartnetName3(signingpartner3, index) {
    // // debugger;
    this.selectedSigningPartnet3ViewName = signingpartner3.source.viewValue;
    this.selectedSigningPartnet3 = this.users[index].userAlias;//change to useralias once lambda is changed.
  }

  selectedSigningPartnetName4(signingpartner4, index) {
    // // debugger;
    this.selectedSigningPartnet4ViewName = signingpartner4.source.viewValue;
    this.selectedSigningPartnet4 = this.users[index].userAlias;//change to useralias once lambda is changed.
  }

  //For Cancel Button
  onReset() {
    this.ArchiveName = "";
    this.toDate = undefined;
    this.EngagementType = 0;
    this.Entity = 0;
    this.EntityType = 0;
    this.ArchiveType = 0;
    this.AdditionalDescriptor = "";
    this.selectedPartnerViewName = "";
    this.selectedAdditionalFieldSeniorViewName = "";
    this.selectedFieldSeniorViewName = "";
    this.selectedSigningPartnet1ViewName = "";
    this.selectedSigningPartnet2ViewName = "";
    this.selectedSigningPartnet3ViewName = "";
    this.selectedSigningPartnet4ViewName = "";
  }
  onChange(event: any) {
    this.archiveDate = event;

  }

  // Get Engagement Type

  getengagementtypes() {
    this.service.GetEngagementType().subscribe(
      (data) => {
        this.engagements = data;
      },
      (err) => {
        console.log("error is ", err)
      }
    );
  }
  //Get Selected Engagement

  selectEngagement(args) {
    this.selectedEngagementType = args.target.options[args.target.selectedIndex].text;
  }
  //Get Entity 

  getentities() {

    this.service.GetEntity().subscribe(
      data => {
        this.entities = data;
      }
    );
  }
  // Get Selected Entity

  selectEntity(args) {
    this.selectedEntity = args.target.options[args.target.selectedIndex].text;
  }

  //Get Entity Type
  getentitytypes() {

    this.service.GetEntityType().subscribe(
      data => {
        this.entitytype = data;
      }
    );
  }
  // Get Selected Entitity Type 

  selectEntityType(args) {
    // // debugger;
    this.selectedEntityType = args.target.options[args.target.selectedIndex].text;

  }
  //Get ArchvieType
  getarchivetypes() {
    this.service.GetArchiveType().subscribe(
      data => {
        this.archivenames = data;
      }
    );
  }
  // Get Selected ArchiveType 
  selectArchiveType(args) {
    this.selectedArchiveType = args.target.options[args.target.selectedIndex].text;
    if (this.selectedArchiveType == "Other") {
      this.displaytextbox = true;

    }
    else {
      this.displaytextbox = false;
      this.AdditionalDescriptor = "";
    }
  }

  //Method for Create Archive
  CreateNewArchive() {
    if (this.ArchiveName == "") {
      this.notifier.notify("error", "Archive Name required") //error message
    }
    else if (this.archiveDate == null) {
      this.notifier.notify("error", "Period end date required")
    }
    else if (this.selectedEngagementType == "") {
      this.notifier.notify("error", "Engagement type required")
    }
    else if (this.selectedEntity == "") {
      this.notifier.notify("error", "Standards Applied required")
    }
    else if (this.selectedEntityType == "") {
      this.notifier.notify("error", "Entity Associated with archive required")
    }
    else if (this.selectedArchiveType == "") {
      this.notifier.notify("error", "Archive name required")
    }
    else if (this.myarchive_description == "Other" && this.AdditionalDescriptor == "") {
      this.notifier.notify("error", "Additional Descriptor required")
    }
    else if (this.selectedPartnerViewName == "") {
      this.notifier.notify("error", "Archive Partner required")
    }
    else if (this.selectedFieldSeniorViewName == "") {
      this.notifier.notify("error", "Field Senior required")
    }
    //Commenting out as it is Optional 
    // else if (this.AdditionalArchiveFieldSenior == "") {
    //   this.notifier.notify("error", "Additional Archive Field Senior required")
    // }
    // if (this.SigningPartners == "") {
    //   this.notifier.notify("error", "Signing Partners required") 
    // }

    else {
      // // debugger;
      // var parameters = {
      //   "WBSLevelOne": "testwbs12345",
      //   "EngagementDescription": this.EngagementDescription,
      //   "EngagementTypeId": this.selectedEngagementType,
      //   "Description": "test12345",
      //   "AdditionalDescription": this.AdditionalDescriptor,
      //   "OfficeCode": "testofc",
      //   "ArchiveTypeId": this.selectedArchiveType,
      //   "EntityTypeId": this.selectedEntityType,
      //   "ProfessionalStandardID": this.selectedEntity,
      //   "CreatedBy": 452403,
      //   "PeriodEndDate": this.archiveDate, // "2020-02-06 01:10:05.000"
      //   "EstimatedIssuanceDate": "2020-02-06 01:10:05.000",
      //   "ArchivePartner": this.selectedPartner,
      //   "ArchiveFieldSenior": this.selectedFieldSenior,
      //   "AdditionalArchiveFieldSenior": this.selectedAdditionalFieldSenior,
      //   "SigningPartner1": this.selectedSigningPartnet1,//dmukundapriya
      //   "SigningPartner2": this.selectedSigningPartnet2,
      //   "SigningPartner3": this.selectedSigningPartnet3,
      //   "SigningPartner4": this.selectedSigningPartnet4,// ""
      //   "ArchiveManager": "resunanda"
      // }

      var parameters = {
        "WBSLevelOneNumber": "testwbs24125",


        "WBSInfo":
        {

          "WBSEngagementPPMD": this.selectedPartner,
          "EngagementManager": "dmukundapriya"
        },
        "ArchiveInfo":
        {
          "Description": "test24512123",
          "AdditionalDescription": this.AdditionalDescriptor,
          "EngagementDesc": this.ArchiveName,//Engagement description is changed to Archive name 
          "PeriodEnd": this.archiveDate,
          "EngagementType": this.selectedEngagementType,
          "EstimatedDate": "2020-02-06 01:10:05.000",
          "ArchiveType": this.selectedArchiveType,
          "EntityType": this.selectedEntityType,
          "CreatedBy": 454891,
          "ArchiveFieldSenior": this.selectedFieldSenior,
          "AdditionalArchiveFieldSenior": this.selectedAdditionalFieldSenior,
          "SigningPartner1": this.selectedSigningPartnet1,
          "SigningPartner2": this.selectedSigningPartnet2,
          "SigningPartner3": this.selectedSigningPartnet3,
          "SigningPartner4": this.selectedSigningPartnet4
        }


      }

      this.service.CreateArchive(parameters);
      this.modalService.openWithCustomWidth('create-archive-modal', "500");

    }
  }
  closeModalDialog(id : string){

  }
}
