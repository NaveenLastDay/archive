import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RequestTemporaryAccessComponent } from './request-temporary-access.component';

describe('RequestTemporaryAccessComponent', () => {
  let component: RequestTemporaryAccessComponent;
  let fixture: ComponentFixture<RequestTemporaryAccessComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RequestTemporaryAccessComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RequestTemporaryAccessComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
