﻿using Deloitte.AIFA.Repositories.UtilityHelper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace Deloitte.AIFA.Repositories.Transformers
{
    public enum NoCreateParameter
    {
    }

    public abstract class BaseTransformer<T>
    {
        public const string DateFormat = "MM/dd/yyyy";

        public const string DateTimeFormat = "MM/dd/yyyy hh:mm";

        public static Func<IDataReader, T, T> NoExtraFields
        {
            get { return (dr, obj) => obj; }
        }

        public IList<T> Transform(IDataReader dr)
        {
            return Transform(dr, NoExtraFields);
        }

        public IList<T> Transform(IDataReader dr, Func<IDataReader, T, T> extraParam)
        {
            var results = new List<T>();
            while (dr.Read())
            {
                results.Add(TransformSubElement(dr, extraParam));
            }

            return results;
        }

        public IList<T> Transform(IDataReader dr, Func<IDataReader, Func<IDataReader, T, T>> extraParam)
        {
            var results = new List<T>();
            while (dr.Read())
            {
                results.Add(TransformSubElement(dr, extraParam.Invoke(dr)));
            }

            return results;
        }

        public T Transform(IDataReader dr, bool singleElement)
        {
            var result = TransformElement(dr);
            return result;
        }

        public T Transform(IDataReader dr, Func<IDataReader, T, T> extraParam, bool singleElement)
        {
            var result = TransformSubElement(dr, extraParam);
            return result;
        }

        public string GetSafeDate(IDataReader dataReader, string nameField, string dateTimeFormat = DateFormat)
        {
            DateTime dateTime;
            return dataReader[nameField] is DBNull
                ? string.Empty
                : DateTime.TryParse(dataReader[nameField].ToString(), out dateTime)
                    ? TimeZoneHelper.ConvertCentralTimeToUtc(DateTime.Parse(dataReader[nameField].ToString())).ToString(dateTimeFormat)
                    : string.Empty;
        }

        public DateTime? ConvertToSafeDateTimeUtc(IDataReader dataReader, string nameField)
        {
            return dataReader[nameField] is DBNull
                       ? (DateTime?)null
                       : TimeZoneInfo.ConvertTimeToUtc(DateTime.Parse(dataReader[nameField].ToString()), TimeZoneInfo.Utc);
        }

        public string GetSafeDateNoTimeZoneInfoConvert(IDataReader dataReader, string nameField, string dateTimeFormat = "MM/dd/yyyy hh:mm tt")
        {
            DateTime dateTime;
            return dataReader[nameField] is DBNull
                       ? string.Empty
                       : DateTime.TryParse(dataReader[nameField].ToString(), out dateTime)
                             ? dateTime.ToString(dateTimeFormat)
                             : string.Empty;
        }

        public T TransformSubElement(IDataReader dr, Func<IDataReader, T, T> bindExtraFields = null)
        {
            return bindExtraFields != null ? bindExtraFields(dr, TransformElement(dr, bindExtraFields)) : TransformElement(dr);
        }

        internal abstract T TransformElement(IDataReader dr, Func<IDataReader, T, T> bindExtraFields = null);
    }

    public abstract class BaseSpreadsheetReportTransformer<T> : BaseTransformer<T>
    {
        public const string ReportDateTimeFormat = "MM/dd/yyyy hh:mm tt";
        private readonly int _clientTimeZoneOffset;
        private readonly TimeZoneInfo _clientTimeZoneInfo;

        protected BaseSpreadsheetReportTransformer(int clientTimeZoneOffset)
        {
            _clientTimeZoneOffset = clientTimeZoneOffset;
            _clientTimeZoneInfo = TimeZoneInfo.GetSystemTimeZones().FirstOrDefault(t => (int)t.BaseUtcOffset.TotalMinutes == _clientTimeZoneOffset) ?? TimeZoneInfo.Local;
        }

        public string GetSafeSpreadsheetDate(IDataReader dataReader, string nameField, string dateTimeFormat = ReportDateTimeFormat)
        {
            return dataReader[nameField] is DBNull
                       ? string.Empty
                       : TimeZoneInfo.ConvertTimeFromUtc(TimeZoneInfo.ConvertTimeToUtc(DateTime.Parse(dataReader[nameField].ToString()), TimeZoneInfo.Local), _clientTimeZoneInfo).ToString(dateTimeFormat);
        }
    }
}
