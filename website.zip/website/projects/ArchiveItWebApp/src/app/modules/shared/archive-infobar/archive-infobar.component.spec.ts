import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ArchiveInfobarComponent } from './archive-infobar.component';

describe('ArchiveInfobarComponent', () => {
  let component: ArchiveInfobarComponent;
  let fixture: ComponentFixture<ArchiveInfobarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ArchiveInfobarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ArchiveInfobarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
