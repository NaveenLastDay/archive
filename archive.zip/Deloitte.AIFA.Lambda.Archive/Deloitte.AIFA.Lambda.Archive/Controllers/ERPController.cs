﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Amazon.Runtime.Internal.Util;
using Microsoft.Extensions.Configuration;
using Deloitte.AIFA.DomainServices.Contracts;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Deloitte.AIFA.DomainEntities;
using Amazon.Lambda.Core;
using Deloitte.AIFA.ICloudServices;
using Deloitte.AIFA.DataModels;
using Newtonsoft.Json;

namespace Deloitte.AIFA.Lambda.Archive.Controllers
{
    [Route("api/erp")]
    [ApiController]
    public class ERPController : ControllerBase
    {
        IERPService _eRPService;
        private readonly IHttpContextAccessor _contextAccessor;
        private string userAlias;
        private readonly IUtilityService _utilityServie;
        private List<RoleFunction> roleFunctions;
        Microsoft.Extensions.Logging.ILogger _logger { get; set; }

        public ERPController(IHttpContextAccessor contextAccessor,IERPService eRPService, ILogger<ERPController> logger, ICloudCacheService cloudCacheService, IUtilityService utilityServie)
        {
            _logger = logger;
            _eRPService = eRPService;
            this._contextAccessor = contextAccessor;
            this._utilityServie = utilityServie;

            //_configuration = configuration;
            _logger.LogInformation("ERP Controller Initiated");
            try
            {
                LambdaLogger.Log("Inside ERP Controller");
                var _context = this._contextAccessor.HttpContext;
                try
                {
                    if (_context?.User?.Claims.Any() == true)
                    {
                        LambdaLogger.Log("Has claims in ERP Controller");
                        foreach (var claim in _context?.User?.Claims)
                        {
                            //LambdaLogger.Log(claim.Type);
                            if (claim.Type == "UserAlias")
                            {
                                userAlias = claim.Value.Split('@')[0].ToString();
                            }
                            LambdaLogger.Log("User Alias from ERP Controller," + userAlias);
                        }
                    }
                    else
                    {
                        LambdaLogger.Log("Has No claims");
                    }
                }
                catch (Exception ex)
                {
                    LambdaLogger.Log("Error with Http context in ERP controller: " + ex.Message);
                }
            }
            catch (Exception e)
            {
                LambdaLogger.Log("Error in ERP controller: " + e.Message);
            }
            try
            {
                CacheRequestModel cacheRequestModel = new CacheRequestModel();

                cacheRequestModel.Key = "RoleFunctions";
                _logger.LogInformation("RoleFunctions Cache RequestModelKey from ERP Controller : " + System.Web.HttpUtility.HtmlEncode(cacheRequestModel.Key));
                var data = cloudCacheService.GetValue(cacheRequestModel);
                _logger.LogInformation("cacheLog from ERP Controller :" + data);
                if (data == null)
                {
                    roleFunctions = utilityServie.GetRoleFunctions();
                    cacheRequestModel.Value = JsonConvert.SerializeObject(roleFunctions);
                    _logger.LogInformation("RoleFunctions Cache Model Value from ERP Controller : " + System.Web.HttpUtility.HtmlEncode(JsonConvert.SerializeObject(cacheRequestModel.Value)));
                    var val = cloudCacheService.SetValue(cacheRequestModel);
                    _logger.LogInformation("RoleFunctions Cache Service Response from ERP Controller : " + System.Web.HttpUtility.HtmlEncode(val.ToString()));
                }
                else
                {
                    roleFunctions = JsonConvert.DeserializeObject<List<RoleFunction>>(data);
                    _logger.LogInformation("RoleFunctions Cache Value from ERP Controller : " + System.Web.HttpUtility.HtmlEncode(JsonConvert.SerializeObject(roleFunctions)));
                }

            }
            catch (Exception e)
            {
                _logger.LogError("Exception in Cloud Cache ERP Controller :" + e.Message);
            }
        }

        [HttpGet]
        [Route("GetPersonnelForWBSNumber")]
        public IActionResult GetPersonnelForWBSNumber(string WbsNumber, string ArchiveNumber)
        {
            var id = GetFuntionID("Access Archive");
            var isValid = _utilityServie.IsUserAuthorizedtoPerformAction(ArchiveNumber, id, userAlias);
            if (isValid)
            {
            _logger.LogInformation("Inside GetTimeAllocationForWbsNumber Method. WbsNumber : " + System.Web.HttpUtility.HtmlEncode(WbsNumber));
			bool hasError = false;
			(bool hasError, List<EngagementPersonnelInfo> data) response = (hasError, new List<EngagementPersonnelInfo>());

			try
			{
                _logger.LogInformation(string.Format("the _eRPService.GetPersonnelForWBSNumber() started {0:HH:mm:ss.fff}",DateTime.UtcNow));
                response = _eRPService.GetPersonnelForWBSNumber(WbsNumber, ArchiveNumber);
                _logger.LogInformation(string.Format("the _eRPService.GetPersonnelForWBSNumber() endded {0:HH:mm:ss.fff}", DateTime.UtcNow));

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return Ok(response);
            }
            else
            {
                _logger.LogInformation("Unauthorized Request Details: Action: GetPersonnelForWBSNumber, Object " + System.Web.HttpUtility.HtmlEncode(userAlias));
                return Forbid();
            }
        }

        [HttpGet]
        [Route("GetERPSearchResults")]
        public IActionResult GetERPSearchResults(string searchquery)
        {
            _logger.LogInformation("Processing GetErpDetails action method.");

            var erps = _eRPService.GetERPDetails(searchquery);
            _logger.LogInformation("Completed GetErpDetails action method.");
            return Ok(erps);
        }

        #region RemoveEngagementPersonnel        
        [HttpPost]
        [Route("RemoveEngagementPersonnel")]
        public IActionResult RemoveEngagementPersonnel(DistributionList distributionList)
        {
            var id = GetFuntionID("Manage ERP");
            var isValid = false;
            distributionList = (DistributionList)_utilityServie.IsUserAuthorizedAndInputIsValid(distributionList.ArchiveNumber, id, userAlias, distributionList, out isValid);
            if (isValid)
            {
            _logger.LogInformation("Processing RemoveEngagementPersonnel action method.");
            distributionList.DeletedBy = userAlias;
            var addEngagementPersonnels = _eRPService.RemoveEngagementPersonnel(distributionList);
            _logger.LogInformation("Completed processing RemoveEngagementPersonnel action method.");
            return Ok(addEngagementPersonnels);
            }
            else
            {
                _logger.LogInformation("Unauthorized Request Details: Action: RemoveEngagementPersonnel, Object " + System.Web.HttpUtility.HtmlEncode(userAlias));
                return Forbid();
            }
        }
        #endregion RemoveEngagementPersonnel

        #region AddEngagementPersonnels
        [HttpPost]
        [Route("AddEngagementPersonnels")]
        public IActionResult AddEngagementPersonnels(DistributionList distributionList)
        {
            var id = GetFuntionID("Manage ERP");
            var isValid = false;
            distributionList = (DistributionList)_utilityServie.IsUserAuthorizedAndInputIsValid(distributionList.ArchiveNumber, id, userAlias, distributionList, out isValid);
            if (isValid)
            {
            _logger.LogInformation("Processing AddEngagementPersonnels action method.");
            var addEngagementPersonnels = _eRPService.AddEngagementPersonnels(distributionList);
            _logger.LogInformation("Completed processing AddEngagementPersonnels action method.");
            return Ok(addEngagementPersonnels);
            }
            else
            {
                _logger.LogInformation("Unauthorized Request Details: Action: AddEngagementPersonnels, Object " + System.Web.HttpUtility.HtmlEncode(userAlias));
                return Forbid();
            }
        }
        #endregion AddEngagementPersonnels

        private int GetFuntionID(string functionName)
        {
            LambdaLogger.Log("cacheLog43234432:" + functionName);
            _logger.LogInformation("cacheLog12798778:" + System.Web.HttpUtility.HtmlEncode(functionName));
            var Id = roleFunctions.Where(e => e.FunctionName == functionName).Select(x => x.Id).FirstOrDefault();
            _logger.LogInformation("functionId: " + System.Web.HttpUtility.HtmlEncode(Id.ToString()));
            return Id;
        }
    }
}