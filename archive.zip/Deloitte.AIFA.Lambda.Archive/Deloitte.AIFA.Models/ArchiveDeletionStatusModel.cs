﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DataModels
{
    public class ArchiveDeletionStatusModel
    {
    
        public string ArchiveDeletionReason { get; set; }
        public int CompletedByPersonnelNumber { get; set; }
        public string RejectionReason { get; set; }
        public string ArchiveDeletionActionStatus { get; set; }
        public DateTime CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public bool IsActiveAction { get; set; }
        public bool IsRequestcancelled { get; set; }
    }
}
