﻿using Deloitte.AIFA.DomainEntities;
using Deloitte.AIFA.DomainEntities.EmailEntities;
using Deloitte.AIFA.EmailNotificationServices.NotificationEntities;
using Deloitte.AIFA.EmailNotificationServices.NotificationServices.Interfaces;
using Deloitte.AIFA.IRepositories;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.EmailNotificationServices.NotificationServices.Services
{
    public class Form3283SNotification : IForm3283SNotification
    {
        IUserRepository _userRepository;
        ILogger _logger;        
       
        public Form3283SNotification(){
           
        }
     
        public BaseEmailEntity Form3283S_Fully_Approved_Notification(string argOperationType, string argOperationDescription, string argTemplateId, string ArchiveNumber, string ApprovedBy, string ADCED, string ActionItemId)
        {
            BaseEmailEntity objTAR = new BaseEmailEntity();
            //Build Tag Values
            objTAR.MinimumTagValues = new Dictionary<string, string>();
            //ArchiveNumber for Subject
            objTAR.MinimumTagValues.Add(EmailPlaceholders.ArchiveNumber, ArchiveNumber);
            
            //For Body - ADCED DATE
            
            objTAR.MinimumTagValues.Add(EmailPlaceholders.ADCED,ADCED);

            objTAR.AdditionalInfo = ActionItemId;
            //Hyperlink to Access for Body

            objTAR.TemplateId = argTemplateId;
            objTAR.OperationDescription = argOperationDescription;
            objTAR.OperationType = argOperationType;

            return objTAR;
        }

        public BaseEmailEntity Form3283S_AP_Awaiting_Approval_Notification(string argOperationType, string argOperationDescription, string argTemplateId, string ArchiveNumber, string ApprovedBy, string ActionItemId)
        {
            BaseEmailEntity objTAR = new BaseEmailEntity();
            //Build Tag Values
            objTAR.MinimumTagValues = new Dictionary<string, string>();
            //ArchiveNumber for Subject
            objTAR.MinimumTagValues.Add(EmailPlaceholders.ArchiveNumber, ArchiveNumber);

            //For Body - ADCED DATE


            objTAR.AdditionalInfo = ActionItemId;
            //Hyperlink to Access for Body

            objTAR.TemplateId = argTemplateId;
            objTAR.OperationDescription = argOperationDescription;
            objTAR.OperationType = argOperationType;

            return objTAR;
        }
        public BaseEmailEntity Form3283S_PIC_Awaiting_Approval_Notification(string argOperationType, string argOperationDescription, string argTemplateId, string ArchiveNumber, string ApprovedBy, string ActionItemId)
        {
            BaseEmailEntity objTAR = new BaseEmailEntity();
            //Build Tag Values
            objTAR.MinimumTagValues = new Dictionary<string, string>();
            //ArchiveNumber for Subject
            objTAR.MinimumTagValues.Add(EmailPlaceholders.ArchiveNumber, ArchiveNumber);

            //For Body - ADCED DATE


            objTAR.AdditionalInfo = ActionItemId;
            //Hyperlink to Access for Body

            objTAR.TemplateId = argTemplateId;
            objTAR.OperationDescription = argOperationDescription;
            objTAR.OperationType = argOperationType;

            return objTAR;
        }
        public BaseEmailEntity Form3283S_PPD_Awaiting_Approval_Notification(string argOperationType, string argOperationDescription, string argTemplateId, string ArchiveNumber, string ApprovedBy, string ActionItemId)
        {
            BaseEmailEntity objTAR = new BaseEmailEntity();
            //Build Tag Values
            objTAR.MinimumTagValues = new Dictionary<string, string>();
            //ArchiveNumber for Subject
            objTAR.MinimumTagValues.Add(EmailPlaceholders.ArchiveNumber, ArchiveNumber);

            //For Body - ADCED DATE

            objTAR.AdditionalInfo = ActionItemId;
            //Hyperlink to Access for Body

            objTAR.TemplateId = argTemplateId;
            objTAR.OperationDescription = argOperationDescription;
            objTAR.OperationType = argOperationType;

            return objTAR;
        }

        public BaseEmailEntity Form3283S_Rejected_Notification(string argOperationType, string argOperationDescription, string argTemplateId, string ArchiveNumber, string RejectedBy, string SubmittedBy, string RejectionReason, string ActionItemId)
        {
            BaseEmailEntity objTAR = new BaseEmailEntity();
            //Build Tag Values
            objTAR.MinimumTagValues = new Dictionary<string, string>();
            //ArchiveNumber for Subject
            objTAR.MinimumTagValues.Add(EmailPlaceholders.ArchiveNumber, ArchiveNumber);

            //For Body - 
            if (RejectionReason != null && RejectionReason != "")
            {
                objTAR.MinimumTagValues.Add(EmailPlaceholders.RejectionReasons, RejectionReason);
            }
            objTAR.MinimumTagValues.Add(EmailPlaceholders.Rejecter, RejectedBy);
            objTAR.MinimumTagValues.Add(EmailPlaceholders.RequestorFirstName, SubmittedBy);

            objTAR.AdditionalInfo = ActionItemId;
            //Hyperlink to Access for Body

            objTAR.TemplateId = argTemplateId;
            objTAR.OperationDescription = argOperationDescription;
            objTAR.OperationType = argOperationType;

            return objTAR;
        }


    }
}
