import { TestBed, async, inject } from '@angular/core/testing';

import { CandeactivateguardGuard } from './candeactivateguard.guard';

describe('CandeactivateguardGuard', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CandeactivateguardGuard]
    });
  });

  it('should ...', inject([CandeactivateguardGuard], (guard: CandeactivateguardGuard) => {
    expect(guard).toBeTruthy();
  }));
});
