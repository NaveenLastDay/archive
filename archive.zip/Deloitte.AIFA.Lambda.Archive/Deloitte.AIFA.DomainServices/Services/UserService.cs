﻿using Deloitte.AIFA.DataModels;
using Deloitte.AIFA.DomainEntities;
using Deloitte.AIFA.DomainServices.Contracts;
using Deloitte.AIFA.ICloudServices;
using Deloitte.AIFA.IRepositories;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainServices.Services
{
    public class UserService : BaseService, IUserService
    {
        IUserRepository _userRepository;
        ILogger _logger;
        IMemoryCache _cache;
        public UserService(IMemoryCache cache, IConfigManager configManager,
                              IUserRepository userRepository
                                , ILogger<UserService> logger
            ) : base(cache, configManager)
        {
            _cache = cache;
            _logger = logger;
            _userRepository = userRepository;
        }

        public List<UserDetail> FetchLoggedInUser(string userAlias)
        {
            _logger.LogError("This error from UserService: FetchLoggedInUser");
            var users = _userRepository.FetchLoggedInUser(userAlias);
            return users;
        }

		public List<FooterConfigurationDataModel> GetFooterConfigurationData()
		{
			_logger.LogError("Getting footer data.");
			return _userRepository.GetFooterConfigurationData();
			throw new NotImplementedException();
		}

		public RoleMapping GetRoleMappingsForUser(string UserAlias, string ArchiveNumber)
        {
            _logger.LogError("This error from UserService: GetRoleMappingsForUser");
            var rolemappingDetails = _userRepository.GetRoleMappingsForUser(UserAlias, ArchiveNumber);
            return rolemappingDetails;
        }

        public UserOfflinePermissions FetchUserofflinePermissions(string userAlias)
        {
            _logger.LogError("This error from UserService: FetchUserofflinePermissions");
            var users = _userRepository.FetchUserofflinePermissions(userAlias);
            return users;
        }

    }
}
