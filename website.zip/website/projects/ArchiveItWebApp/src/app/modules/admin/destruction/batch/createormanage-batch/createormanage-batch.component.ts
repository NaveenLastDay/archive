import { DestructionService } from '../../../../../services/destruction.service';
import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { NgxSpinnerService } from 'ngx-spinner';
import { NotifierService, NotifierModule, NotifierOptions } from "angular-notifier";
import { FormControl, FormGroup, FormBuilder, Validators, FormArray,NgForm, Form } from '@angular/forms';
import { ModalService } from "../../../../shared/modal";
import { UserConfigSettingService } from '../../../../../guards/user-role-guard.service';
import { SharedService } from '../../../../../services/shared.service';
import { NgbCalendar, NgbDate } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-createormanage-batch',
  templateUrl: './createormanage-batch.component.html',
  styleUrls: ['./createormanage-batch.component.css']
})
export class CreateormanageBatchComponent implements OnInit {

  currentUrl: string;
  batchData : any[];

  employeeUniqueIdentifier: string;
  hoverIndex: number = -1;
  currentPageNumber: number = 1;
  totalBatches: number = 0;
  readonly pageSize: number = 10;
  pageCount: number = 1;
  sortBy: number = 5;
  filterBy: number = 0;
  filterText: string = "";
  batchIdSimpleSearch:string;
  UserName =this.adalSvc.LoggedInUserName;
  userEmail = this.adalSvc.LoggedInUserEmail;
  userConfig: any;
  show : boolean = false;
  display : string = '';
  Name : string = '';
  Date : string;
  euserAlias =this.userEmail.replace("@deloitte.com", "");
  dataSource:any;


  /*Pagination Param's*/
  appendWPtoGrid : boolean = false;
  showDetailsGrid : boolean= true;
  /* */

  /*sorting */
  searchBatchNumber : string ='';
  columnByEnum: any = BatchesColumnBy;
  sortColumnDialog: number = -1;
  sortColumn : string ='';
  sortdesc: number;
  /*sorting*/
  popUpHeaderText:string;
  selectedBusinessType:string;
  selectedStatusType:string;
  destructionEligibleDateShow:boolean = false;
  isBatchTypeEdit:boolean = true;
  readonly eligibleDateFormat: string = "MM/DD/YYYY";
  createEditBatchform:FormGroup;
  businessTypes: any[];
  batchStatusTypes: any[]=[{"statusTypeID":1,"statusType":"Active"},{"statusTypeID":2,"statusType":"In Active"}];

  batchNumber:string;
  DestrElgStartDate:string;
  DestrElgEndDate:string;
  DestructionEligibleFullDate:string;
  Business:string;
  Status:string;
  StatusId:number;
  BusinessId:number;
  batchInfo:any;
  hoveredDate: NgbDate | null = null;
  fromDate: any;
  toDate: any | null = null;
  sortByCreatedDate:boolean = true;
  isSimpleSearch:boolean = false;
  isDTScreen:number = 0;
  constructor(private router: Router,private _userConfig:UserConfigSettingService, private destructionService: DestructionService, private adalSvc: MsAdalAngular6Service,
    private fb: FormBuilder,private SpinnerService: NgxSpinnerService, private notifier: NotifierService,private modalService: ModalService, private sharedService: SharedService, private calendar: NgbCalendar) {
    router.events.subscribe((_: NavigationEnd) => this.currentUrl = this.router.url);
    this.createEditBatchform = fb.group({
      'batchIDControl': [null, [Validators.required]],
      'distructionEligibleDateControl': [null, [Validators.required]],
      'businessControl': [null],
      'statusControl': [null],
      'ngbdistructionEligibleDateControl': [null],
    });
  }

  ngOnInit() {
    this.employeeUniqueIdentifier = this.adalSvc.LoggedInUserEmail.split('@')[0];
    this.userConfig = this._userConfig.FetchLoggedInUser(this.employeeUniqueIdentifier);
    this.Business="Audit";
    this.BusinessId=1;
    this.selectedStatusType="1";
    this.initialize();
  }

  initialize()
  {
    this.isSimpleSearch = false;
    this.GetBusinessType();
    this.getBatchData();
  }


  mouseOver(event: any, index: number) {
    this.hoverIndex = index;
    //event.stopPropagation();
  }

  mouseOut(event: any) {
    let name: string = '';
    let present: number = -1;

    name = event.toElement ? event.toElement.getAttribute('name') : '';
    present = name ? name.search("AccessBatchTop") : -1;

    if (event.toElement && present == -1 && (event.toElement["tagName"] != 'td' || event.toElement.className == 'myBatchListRow')) {
      this.hoverIndex = -1;
    }
  }

  GetBusinessType(){
    this.destructionService.GetBusinessType().subscribe(
      data => {
        if (data)
        this.businessTypes = data ? data : [];
      }
    );
    console.log(this.businessTypes + " businessTypes");
  }
  getBatchData() {
    this.destructionService.GetBatchInfo(this.currentPageNumber, this.pageSize, this.sortdesc, this.filterBy, this.sortColumn,this.searchBatchNumber,this.isDTScreen).subscribe(
      data => {
        if (data.length > 0)
        {
          this.showDetailsGrid=true;
          this.batchData = data ? data : [];
          this.totalBatches = data[0]['recordsCount'];
          this.SpinnerService.hide();
        }
        else{
          this.batchData = [];
          this.showDetailsGrid=false;
          this.SpinnerService.hide();
        }
      },
        err => {
          this.notifier.notify("error", "Error occurred while fetching destruction batch");
          this.showDetailsGrid=false;
          this.SpinnerService.hide();
        }

    );
  }

  updateGridData(event) {
    //this.SpinnerService.show();
    this.appendWPtoGrid = event.isLoadMoreClicked;
    this.currentPageNumber = event.pageNumber;
    this.destructionService.GetBatchInfo(this.currentPageNumber, this.pageSize, this.sortdesc, this.filterBy, this.sortColumn,this.searchBatchNumber,this.isDTScreen).subscribe(
      data => {
        if (this.appendWPtoGrid && data) {
            for(var i =0;i<data.length;i++){
              this.batchData.push(data[i]);
            }
          }
          else{
              this.batchData = data ? data : [];
          }

      }
    );
  }


    TextSearch(){
      this.isSimpleSearch = true;
      this.filterBy=1;
      this.searchBatchNumber=this.batchIdSimpleSearch;
      this.getBatchData();

    }


    memberSortDialogASCDESC(event){
    this.sortByCreatedDate =false;
     var clickedColumn:number=event;
      /*For BatchNumber*/
      if(clickedColumn==1 && this.sortBy!=1){
      this.sortBy=1;
       this.sortColumn="BatchNumber";
       this.sortdesc=0;
     }
     else if(clickedColumn==1 && this.sortBy==1){
      this.sortBy=0;
      this.sortColumn="BatchNumber";
      this.sortdesc=1;
     }

     /*for DestructionEligibleToDate */
     else if(clickedColumn==2 && this.sortBy!=2){
      this.sortBy=2;
       this.sortColumn="DestructionEligibleFromDate";
       this.sortdesc=0;
     }
     else if(clickedColumn==2 && this.sortBy==2){
      this.sortBy=0;
      this.sortColumn="DestructionEligibleFromDate";
      this.sortdesc=1;
     }

     /*for Business */
     else if(clickedColumn==3 && this.sortBy!=3){
      this.sortBy=3;
       this.sortColumn="Business";
       this.sortdesc=0;
     }
     else if(clickedColumn==3 && this.sortBy==3){
      this.sortBy=0;
      this.sortColumn="Business";
      this.sortdesc=1;
     }/*for CreatedBy */
     else if(clickedColumn==4 && this.sortBy!=4){
      this.sortBy=4;
       this.sortColumn="CreatedBy";
       this.sortdesc=0;
     }
     else if(clickedColumn==4 && this.sortBy==4){
      this.sortBy=0;
      this.sortColumn="CreatedBy";
      this.sortdesc=1;
     }/*for CreatedDate */
     else if(clickedColumn==5 && this.sortBy!=5){
      this.sortBy=5;
       this.sortColumn="CreatedDate";
       this.sortdesc=0;
     }
     else if(clickedColumn==5 && this.sortBy==5){
      this.sortBy=0;
      this.sortColumn="CreatedDate";
      this.sortdesc=1;
     }/*for ModifiedDate */
     else if(clickedColumn==6 && this.sortBy!=6){
      this.sortBy=6;
       this.sortColumn="ModifiedDate";
       this.sortdesc=0;
     }
     else if(clickedColumn==6 && this.sortBy==6){
      this.sortBy=0;
      this.sortColumn="ModifiedDate";
      this.sortdesc=1;
     }/*for ArchivesLeft */
     else if(clickedColumn==7 && this.sortBy!=7){
      this.sortBy=7;
       this.sortColumn="ArchivesLeft";
       this.sortdesc=0;
     }
     else if(clickedColumn==7 && this.sortBy==7){
      this.sortBy=0;
      this.sortColumn="ArchivesLeft";
      this.sortdesc=1;
     }/*for ObjectsLeft */
     else if(clickedColumn==8 && this.sortBy!=8){
      this.sortBy=8;
       this.sortColumn="ObjectsLeft";
       this.sortdesc=0;
     }
     else if(clickedColumn==8 && this.sortBy==8){
      this.sortBy=0;
      this.sortColumn="ObjectsLeft";
      this.sortdesc=1;
     }/*for Status */
     else if(clickedColumn==9 && this.sortBy!=9){
      this.sortBy=9;
       this.sortColumn="Status";
       this.sortdesc=0;
     }
     else if(clickedColumn==9 && this.sortBy==9){
      this.sortBy=0;
      this.sortColumn="Status";
      this.sortdesc=1;
     }
     this.currentPageNumber=1;
     this.getBatchData();

    }

    showCreateOrEditPopup(modeType:string, batchNumber?:any){
      this.destructionEligibleDateShow=false
      if(modeType=="createBatch"){
        this.popUpHeaderText="Create Batch";
        this.isBatchTypeEdit=false;
      }
      else{
        this.popUpHeaderText="Edit Batch";
        this.isBatchTypeEdit=true;
        this.fetchBatchDetails(batchNumber);
      }
      this.modalService.openWithCustomWidth("createAndEditBatch", "450")
   }
   fetchBatchDetails(batchNumber:any){
    this.batchInfo = this.batchData.find(x => x.batchNumber === batchNumber);
    console.log(this.batchInfo);
    this.batchNumber = this.batchInfo.batchNumber;
    this.DestrElgStartDate = this.convertToMMDDYYYY(this.batchInfo.destructionEligibleFromDate);
    this.DestrElgEndDate =  this.convertToMMDDYYYY(this.batchInfo.destructionEligibleToDate);
    this.DestructionEligibleFullDate = this.convertToMMDDYYYY(this.batchInfo.destructionEligibleFromDate) +' - '+ this.convertToMMDDYYYY(this.batchInfo.destructionEligibleToDate);
    this.Business = this.batchInfo.business;
    if(this.batchInfo.business == "Audit")
    this.BusinessId = BusinessTypes.Audit;
    this.Status = this.batchInfo.status;
    this.StatusId = this.batchInfo.statusID;
    this.setBusinessStatus();
    this.createEditBatchform.controls.ngbdistructionEligibleDateControl.setValue(this.DestructionEligibleFullDate);
    this.fromDate =  this.toNGBDateFormatter(this.batchInfo.destructionEligibleFromDate);
    this.toDate = this.toNGBDateFormatter(this.batchInfo.destructionEligibleToDate);
   }
   convertToMMDDYYYY(toDate: string){
     console.log(toDate);
     let dateInput = new Date(toDate);
     return (dateInput.getMonth()+1) +'/'+dateInput.getDate()+'/'+dateInput.getFullYear();
   }
   setBusinessStatus(){
     if(this.Status == "Active")
     this.selectedStatusType = BatchStatus.Active.toString();
     if(this.Status == "InActive")
     this.selectedStatusType = BatchStatus.InActive.toString();
     if(this.Status == "Completed")
     this.selectedStatusType = BatchStatus.Completed.toString();
   }
   closeModalDialog(Action:string) {
    this.modalService.close(Action);
    this.resetForm();
  }
   selecteBusinessType(event:any){
    console.log(event.target.value);
    this.BusinessId=event.target.value;
    if(event.target.value==1)
    this.Business="Audit";
   }

  selecteStatusType(event:any){
    console.log(event.target.value +" "+event.target.innerText);
    this.StatusId=event.target.value;
    if(event.target.value==1)
    this.Status='Active';
    if(event.target.value==2)
    this.Status='InActive';
    else
    this.Status='Completed';
   }
   selectDistEligibleDate(event) {
    if (event != undefined) {
      this.DestructionEligibleFullDate = "";
      if (event[0].fromdate != "" && event[1].todate != "") {
        this.DestrElgStartDate = this.getDateInMySQLFomat(event[0].fromdate);
        this.DestrElgEndDate = this.getDateInMySQLFomat(event[1].todate);
        this.DestructionEligibleFullDate = event[0].fromdate + " — " + event[1].todate;
        console.log("DestructionEligibleFullDate:" + this.DestructionEligibleFullDate);
      }
    }
  }
  getDateInMySQLFomat(date: string) {
    // current date format
    return date.split("/")[2] + "-" + date.split("/")[0] + "-" + date.split("/")[1];
  }
   createOrEditBatch(){
    var parameters = {
      "BatchNumber": this.batchNumber,
      "DestructionEligibleFromDate": this.DestrElgStartDate,
      "DestructionEligibleToDate":this.DestrElgEndDate,
      "BusinessID":this.BusinessId,
      "StatusID":this.StatusId,
      "OperationType": this.isBatchTypeEdit ? 2 : 1
    }
    this.destructionService.CreateAndUpdateBatch(parameters).subscribe(
      data => {
        if(data[0].message=="Batch Id already exists")
        {
          this.notifier.notify("error", data[0].message);
        }
        else if (data[0].batchNumber != null && data[0].statusID != BatchStatus.InActive)
        {
          this.router.navigate(["/admin/adminsidenavbar/destructions/createormanagebatches/batchdetails/"+ data[0].batchNumber]);
        }
        else
        this.getBatchData();
      }
    );
    this.closeModalDialog('createAndEditBatch');
   }
   eligibleDatePickerToggle(){
    this.destructionEligibleDateShow = !this.destructionEligibleDateShow;
    if(!this.isBatchTypeEdit){
    this.ngbInitialDates();
    }
   }
   resetForm(){
     this.createEditBatchform.reset();
    this.createEditBatchform.get('batchIDControl').reset();
    this.createEditBatchform.get('distructionEligibleDateControl').reset();
    this.createEditBatchform.get('businessControl').reset();
    this.createEditBatchform.get('statusControl').reset();
    this.createEditBatchform.controls.businessControl.setValue('1');
    this.createEditBatchform.controls.statusControl.setValue('1');
    this.selectedStatusType="1";
    this.Business="Audit";
    this.BusinessId=1;
   }
   onDateSelection(date: NgbDate) {
    if (!this.fromDate && !this.toDate) {
      this.fromDate = date;
    } else if (this.fromDate && !this.toDate && date.after(this.fromDate)) {
      this.toDate = date;
    } else {
      this.toDate = null;
      this.fromDate = date;
    }
    let selectedfromDate = this.getDateInFormat(this.fromDate.month)  + "/" + this.getDateInFormat(this.fromDate.day) + "/" + this.fromDate.year;
    let selectedtodate = this.getDateInFormat(this.toDate.month) + "/" + this.getDateInFormat(this.toDate.day) + "/" + this.toDate.year;
    if(selectedfromDate && selectedtodate){
    this.DestructionEligibleFullDate = selectedfromDate +' - ' + selectedtodate;
    this.DestrElgStartDate = selectedfromDate;
    this.DestrElgEndDate = selectedtodate;
    this.destructionEligibleDateShow = false;
    }
  }

  isHovered(date: NgbDate) {
    return this.fromDate && !this.toDate && this.hoveredDate && date.after(this.fromDate) && date.before(this.hoveredDate);
  }

  isInside(date: NgbDate) {
    return this.toDate && date.after(this.fromDate) && date.before(this.toDate);
  }

  isRange(date: NgbDate) {
    return date.equals(this.fromDate) || (this.toDate && date.equals(this.toDate)) || this.isInside(date) || this.isHovered(date);
  }
  toNGBDateFormatter(toDateString){
    var datearray = toDateString.split("/");
    var newdate = datearray[1] + '/' + datearray[0] + '/' + datearray[2];
    console.log(newdate);
    if(datearray.length>1)
    var date = new Date(newdate);
    else  date = new Date(toDateString);
    return { day: parseInt(date.getDate().toString()), month: parseInt((date.getMonth()+1).toString()), year: parseInt(date.getFullYear().toString())};
  }

  getDateInFormat(d:number)
  {
    return (d < 10 ? '0' +d : d);
  }
  ngbInitialDates(){
    this.fromDate = this.calendar.getToday();
    this.toDate = this.calendar.getNext(this.calendar.getToday(), 'd', 0);
  }
  clearDate(){
    this.ngbInitialDates();
    this.destructionEligibleDateShow = false;
  }
}

export enum BatchesColumnBy {
  ColumnBy_Default = -1,
  ColumnBy_BatchNumber = 1,
  ColumnBy_DestructionEligibleFromDate = 2,
  ColumnBy_Business = 3,
  ColumnBy_CreatedBy = 4,
  ColumnBy_CreatedDate = 5,
  ColumnBy_ModifiedDate = 6,
  ColumnBy_ArchivesLeft = 7,
  ColumnBy_ObjectsLeft = 8,
  ColumnBy_Status = 9,
}

export enum BusinessTypes{
Audit=1
}

export enum BatchStatus{
  Active=1,
  InActive,
  Completed
}
