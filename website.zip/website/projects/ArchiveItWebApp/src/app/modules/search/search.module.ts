import { SharedService } from './../../services/shared.service';
import { PaginationComponent } from './../shared/pagination/pagination.component';
import { PipeModule } from './../shared/Pipes/pipe.module';
import { SearchArchiveListItemComponent } from './search-archive-list-item/search-archive-list-item.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdvancedSearchComponent } from './advanced-search/advanced-search.component';
import { SearchArchivesComponent } from './search-archives/search-archives.component';
import { RouterModule, Route } from '@angular/router';
import { AuthenticationGuard } from 'microsoft-adal-angular6';
import { TrimSummaryLengthPipe } from '../shared/Pipes/trim-summary-length.pipe';
import { AdvancedSearchLandingPageComponent } from './advanced-search-landing-page/advanced-search-landing-page.component';
import { NotifierModule, NotifierOptions } from "angular-notifier";
import { FormBuilder, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedComponentsModule } from './../shared/shared-components.module';
import { AdvancedSearchCustomRuleComponent } from './advanced-search-custom-rule/advanced-search-custom-rule.component';
import {MatAutocompleteModule} from '@angular/material/autocomplete';
import { ArchivesFacetSearchComponent } from './facet-search/archive-facet-search.component';
import { FacetFilterComponent } from './facet-search/facet-filter.component';
import { CustomRuleComponent } from './custom-rule/custom-rule.component';
import { HighlightTextPipe } from './../shared/Pipes/highlight-text.pipe';
import { MatCheckboxModule, MatButtonToggleModule, MatFormFieldModule, MatOptionModule, MatInputModule, MatTableModule, MatDatepickerModule, MatDividerModule} from '@angular/material';
import { SearchEventService } from './search.event.service';
import {MatIconModule} from '@angular/material/icon'; 


let routes: Route[] = [
  {
    path: 'advancedsearch', component: AdvancedSearchComponent, data: { title: 'Advanced Search', showbreadcrumb: 'true' }, canActivate: [AuthenticationGuard], children: [
      { path: '', component: AdvancedSearchLandingPageComponent, data: { title: 'Advanced Search', showbreadcrumb: 'true' }, pathMatch: 'full' },
      {path: 'archives/:searchTerm', component:SearchArchivesComponent, data: { title: 'Advanced Search', showbreadcrumb: 'true' } },
      { path: 'archives', component: SearchArchivesComponent, data: { title: 'Advanced Search', showbreadcrumb: 'true' } }
    ]
  }
];
const customNotifierOptions: NotifierOptions = {
  position: {
    horizontal: {
      position: 'right',
      distance: 12
    },
    vertical: {
      position: 'top',
      distance: 12,
      gap: 10
    }
  },
  theme: 'material',
  behaviour: {
    autoHide: 500,
    onClick: 'hide',
    onMouseover: 'pauseAutoHide',
    showDismissButton: true,
    stacking: 1
  },
  animations: {
    enabled: true,
    show: {
      preset: 'slide',
      speed: 200,
      easing: 'ease'
    },
    hide: {
      preset: 'fade',
      speed: 3000,
      easing: 'ease-in',
      offset: 50
    },
    shift: {
      speed: 300,
      easing: 'ease'
    },
    overlap: 150
  }
};

@NgModule({
  declarations: [
    AdvancedSearchComponent,
    SearchArchivesComponent,
    SearchArchiveListItemComponent,
    AdvancedSearchLandingPageComponent,
    //PaginationComponent,    
    AdvancedSearchCustomRuleComponent,
    FacetFilterComponent,
    ArchivesFacetSearchComponent,
    FacetFilterComponent,
    CustomRuleComponent
//,
   // HighlightTextPipe

    
    

  ],
  imports: [
    CommonModule,    
    RouterModule.forChild(routes),
    PipeModule,
    FormsModule,
    ReactiveFormsModule,
    SharedComponentsModule,
    MatAutocompleteModule, 
    ReactiveFormsModule,  
     MatFormFieldModule,
        MatOptionModule,
        MatInputModule,
    MatDatepickerModule,
    MatIconModule,
    NotifierModule.withConfig(customNotifierOptions)
  ],
  providers: [SearchEventService, SharedService]
})
export class SearchModule { }
