﻿using Amazon.Lambda.Core;
using Deloitte.AIFA.DomainEntities;
using Deloitte.AIFA.DomainServices.Contracts;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MySqlConnector;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

namespace Deloitte.AIFA.Lambda.Archive.Controllers
{
    [Route("api/ratethisapp")]
    [ApiController]
    public class RateThisAppController : ControllerBase
    {
        IRateThisAppService _rateThisAppService;
        private readonly IHttpContextAccessor _contextAccessor;
        private string userAlias;
        ILogger _logger { get; set; }
        public RateThisAppController(IHttpContextAccessor contextAccessor, IRateThisAppService rateThisAppService, ILogger<ArchiveFolderController> logger)
        {
            _logger = logger;
            _rateThisAppService = rateThisAppService;
            this._contextAccessor = contextAccessor;

            _logger.LogInformation("Rate This App Controller Initiated");
            try
            {
                LambdaLogger.Log("Inside RateThisApp Controller");
                var _context = this._contextAccessor.HttpContext;
                try
                {
                    if (_context?.User?.Claims.Any() == true)
                    {
                        LambdaLogger.Log("Has claims in RateThisApp Controller");
                        foreach (var claim in _context?.User?.Claims)
                        {
                            //LambdaLogger.Log(claim.Type);
                            if (claim.Type == "UserAlias")
                            {
                                userAlias = claim.Value.Split('@')[0].ToString();
                            }
                            LambdaLogger.Log("User Alias from RateThisApp Controller," + userAlias);
                        }
                    }
                    else
                    {
                        LambdaLogger.Log("Has No claims");
                    }
                }
                catch (Exception ex)
                {
                    LambdaLogger.Log("Error with Http context in RateThisApp controller: " + ex.Message);
                }
            }
            catch (Exception e)
            {
                LambdaLogger.Log("Error in RateThisApp controller: " + e.Message);
            }
        }

        [HttpGet]
        [Route("GetRatingByUserAlias")]
        public IActionResult GetRatingByUserAlias(int applicationId)
        {
            //Archive details
            var archiveDetail = _rateThisAppService.GetRatingByUserAlias(userAlias, applicationId);
            _logger.LogInformation("GetRatingByUserAlias: " + System.Web.HttpUtility.HtmlEncode(userAlias));
            return Ok(archiveDetail);
        }

        [HttpPost]
        [Route("SubmitRating")]
        public IActionResult SubmitRating(RatingSubmissionInfo ratingInfo)
        {
            ratingInfo.UserAlias = userAlias;
            var result = _rateThisAppService.SubmitRating(ratingInfo);
            _logger.LogInformation("Submit Rating for: ", System.Web.HttpUtility.HtmlEncode(ratingInfo.UserAlias));
            return Ok(result);
        }
    }
}