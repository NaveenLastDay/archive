﻿using Deloitte.AIFA.DataModels;
using Deloitte.AIFA.DomainEntities;
using Deloitte.AIFA.IRepositories;
using Deloitte.AIFA.Models;
using Deloitte.AIFA.Repositories.Transformers;
using Microsoft.Extensions.Caching.Memory;
using System;


namespace Deloitte.AIFA.Repositories.Repository
{
    public class FormRepository : BaseRepository<ArchiveField>, IFormRepository
    {
        IMemoryCache _cache;
        public FormRepository(IMemoryCache cache) : base(cache)
        {
            _cache = cache;
        }

        public Form3283PrepopulatedData GetForm3283PrepopulatedData(string archiveNumber, string loggedInUser)
        {
            try
            {
                var parameters = Builder.Bind(FormFieldParameter.ArchiveNumber).On(archiveNumber)
                                        .Bind(FormFieldParameter.LoggedInUser).On(loggedInUser)
                                 .Build();
                var result = DbHelper.ExecuteReader(
                    "pub_AIFA_GetForm3283PrepopulatedData",
                    parameters,
                        dr => new Form3283PrepopulatedDataTransformer().TransformElement(dr));
                return _mapper.Map<Form3283PrepopulatedDataModel, Form3283PrepopulatedData>(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public FormActionResponse CreateOrUpdateForm(FormSubmitInfo submitForm)
        {
            try
            {
                var parameters = Builder.Bind(FormFieldParameter.Id).On(submitForm.Id)
                                        .Bind(FormFieldParameter.ArchiveNumber).On(submitForm.ArchiveNumber)
                                        .Bind(FormFieldParameter.ProposedADCEDDate).On(submitForm.ProposedADCEDDate)
                                        .Bind(FormFieldParameter.ReasonType).On(submitForm.ReasonTypeIDs)
                                        .Bind(FormFieldParameter.ReasonDescription).On(submitForm.ReasonDescription)
                                        .Bind(FormFieldParameter.AdditionalDetails).On(submitForm.AdditionalDetails)
                                        .Bind(FormFieldParameter.ActionsTobeTaken).On(submitForm.ActionsToBeTaken)
                                        .Bind(FormFieldParameter.AuditPIC).On(submitForm.AuditPICAlias)
                                        .Bind(FormFieldParameter.AuditPPD).On(submitForm.AuditPPDAlias)
                                        .Bind(FormFieldParameter.CreatedBy).On(submitForm.CreatedBy)
                                        .Build();

                var result = DbHelper.ExecuteReader(
                    "pub_AIFA_CreateOrUpdateForm3283",
                    parameters,
                        dr => new FormActionResponseTransformer().TransformElement(dr));
                return _mapper.Map<FormActionResponseModel, FormActionResponse>(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public FormActionResponse ApproveForm(ApproveOrRejectFormRequest request)
        {
            try
            {
                var parameters = Builder.Bind(FormFieldParameter.ActionItemId).On(request.ActionItemId)
                                        .Bind(FormFieldParameter.ApprovedBy).On(request.ApprovedBy)
                                        .Bind(FormFieldParameter.ArchiveDueDateCriteria).On(request.ArchiveDueDateCriteria)
                                        .Bind(FormFieldParameter.DeliverableType).On(request.DeliverableType)
                                        .Bind(FormFieldParameter.DateThatDrivesEDCD).On(request.DateThatDrivesEDCD)
                                        .Bind(FormFieldParameter.RDCDDate).On(request.RDCDDate)
                                 .Build();
                var result = DbHelper.ExecuteReader(
                    "pub_AIFA_ApproveForm3283",
                    parameters,
                        dr => new FormActionResponseTransformer().TransformElement(dr));
                return _mapper.Map<FormActionResponseModel, FormActionResponse>(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public FormActionResponse RejectForm(ApproveOrRejectFormRequest request)
        {
            try
            {
                var parameters = Builder.Bind(FormFieldParameter.ActionItemId).On(request.ActionItemId)
                                        .Bind(FormFieldParameter.RejectedBy).On(request.RejectedBy)
                                        .Bind(FormFieldParameter.IsEditRequired).On(request.IsEditRequired)
                                        .Bind(FormFieldParameter.RejectionReason).On(request.RejectionReason)
                                        .Bind(FormFieldParameter.ArchiveDueDateCriteria).On(request.ArchiveDueDateCriteria)
                                        .Bind(FormFieldParameter.DeliverableType).On(request.DeliverableType)
                                        .Bind(FormFieldParameter.DateThatDrivesEDCD).On(request.DateThatDrivesEDCD)
                                 .Build();
                var result = DbHelper.ExecuteReader(
                    "pub_AIFA_RejectForm3283",
                    parameters,
                        dr => new FormActionResponseTransformer().TransformElement(dr));
                return _mapper.Map<FormActionResponseModel, FormActionResponse>(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public FormActionResponse ChangeApprover(ChangeApproverRequest request)
        {
            try
            {
                var parameters = Builder.Bind(FormFieldParameter.Id).On(request.FormId)
                                        .Bind(FormFieldParameter.ChangedTo).On(request.ChangedTo)
                                        .Bind(FormFieldParameter.ChangedBy).On(request.ChangedBy)
                                        .Bind(FormFieldParameter.Identifier).On(request.Identifier)
                                 .Build();
                var result = DbHelper.ExecuteReader(
                    "pub_AIFA_ChangeApproverForForm3283",
                    parameters,
                        dr => new FormActionResponseTransformer().TransformElement(dr));
                return _mapper.Map<FormActionResponseModel, FormActionResponse>(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
