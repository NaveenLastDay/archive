﻿using System;
using System.Collections.Generic;
using System.Text;
using Amazon.SQS.Model;
using Deloitte.AIFA.DataModels;
using Microsoft.AspNetCore.Mvc;
using Deloitte.AIFA.IMessageServices.Contracts;
using System.Linq;

namespace Deloitte.AIFA.Lambda.Archive.Controllers
{
	[Route("api/matconnector")]
	[ApiController]
	public class MATConnectorController : ControllerBase
	{
		private readonly ISQSService _sqsService;
		public MATConnectorController(ISQSService sqsService)
		{
			_sqsService = sqsService;
		}

		[HttpGet]
		[Route("GetMessages")]
		public IActionResult GetMessages(string identifier = "MAT")
		{
			var response = _sqsService.ReceiveMessageAsync().Result;

            List<Message> messages = response.Messages.Where(message => message.Body.Split(",")[0] == identifier)
                .Select(message => {
                    message.Body = message.Body.Split(",")[1];
                    return message;
                    }).ToList();
			return Ok(messages);
		}

		[HttpPost]
		[Route("DeleteMessages")]
		public IActionResult DeleteMessages(DeleteMessagesModel model)
		{
			bool areAllMessagesDeleted = true;
			var response = _sqsService.DeleteMessageBatchAsync(model.Entries).Result;
			if (response.Failed.Count > 0) areAllMessagesDeleted = false;
			return Ok(new { areAllMessagesDeleted, response.Failed });
		}
	}
}