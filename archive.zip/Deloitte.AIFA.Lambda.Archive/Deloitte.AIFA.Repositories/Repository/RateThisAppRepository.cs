﻿using Deloitte.AIFA.DataModels;
using Deloitte.AIFA.DomainEntities;
using Deloitte.AIFA.DomainEntities.Report;
using Deloitte.AIFA.IRepositories;
using Deloitte.AIFA.Models;
using Deloitte.AIFA.Repositories.Transformers;
using Microsoft.Extensions.Caching.Memory;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Deloitte.AIFA.Repositories.Repository
{
    public class RateThisAppRepository : BaseRepository<RateThisAppField>, IRateThisAppRepository
    {
        IMemoryCache _cache;
        public RateThisAppRepository(IMemoryCache cache) : base(cache)
        {
            _cache = cache;
        }

        public int GetRatingByUserAlias(string userAlias, int applicationId)
        {
            var rating = 1;
            Exception e = new Exception();
            try
            {
                var parameters = Builder.Bind(GetUserRatingParameter.UserAlias).On(userAlias)
                                            .Bind(GetUserRatingParameter.ApplicationId).On(applicationId)
                                            .Bind(GetUserRatingParameter.RatingVal).On()
                                            .Build();
                DbHelper.ExecuteNonQuery(
                        "pub_AIFA_GetLastUserRatingByApplicationIdAndPageName",
                        parameters,
                        cmd =>
                        {
                            int.TryParse(cmd.Parameters[RateThisAppField.RatingVal.ToString()].Value.ToString(), out rating);
                            if (rating == 0)
                                rating = 1;
                            return rating;
                        });
            }
            catch (Exception ex)
            {
                e = ex;
            }
            return rating;
        }

        public string SubmitRating(RatingSubmissionInfo ratingInfo)
        {
            try
            {
                var parameters = Builder.Bind(RatingSubmissionInfoSubmitParameter.UserAlias).On(ratingInfo.UserAlias)
                                            .Bind(RatingSubmissionInfoSubmitParameter.Comments).On(ratingInfo.Comment)
                                            .Bind(RatingSubmissionInfoSubmitParameter.Rating).On(ratingInfo.Rating)
                                            .Bind(RatingSubmissionInfoSubmitParameter.PageName).On(ratingInfo.Url)
                                            .Bind(RatingSubmissionInfoSubmitParameter.ApplicationId).On(ratingInfo.ApplicationId)
                                            .Bind(RatingSubmissionInfoSubmitParameter.FeedbackProvidedDateTime).On(DateTime.Now)
                                            .Build();
                DbHelper.ExecuteNonQuery(
                    "pub_AIFA_InsertApplicationFeedback",
                    parameters);

                return "Success";
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
