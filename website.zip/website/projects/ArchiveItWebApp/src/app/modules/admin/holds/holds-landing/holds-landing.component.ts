import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-holds-landing',
  templateUrl: './holds-landing.component.html',
  styleUrls: ['./holds-landing.component.css']
})
export class HoldsLandingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
