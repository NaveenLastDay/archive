import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { ArchiveService } from './../../../services/archive.service';
import { PeoplePickerService } from './../../../services/MDREmployeeeDetails.service';
import { FormControl, FormGroup, FormBuilder, Validators, FormArray } from '@angular/forms';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { NgxSpinnerService } from 'ngx-spinner';
import { NotifierService } from 'angular-notifier';
import { HomePageService } from '../../../services/homepage.service';
import { archiveInfoService } from '../../../services/archiveinfo.service';
import { ModalService } from '../../shared/modal';
import { UserConfigSettingService } from '../../../guards/user-role-guard.service';
import { UserActions } from '../../../models/archive-role.model';
import { PubsubService } from '../../../services/pubsub.service';
import { MatAutocompleteTrigger } from '@angular/material';
import { BehaviorSubject } from 'rxjs';
import { distinctUntilChanged, debounceTime } from 'rxjs/operators';
import { ArchiveHomeService } from '../../../services/archive-home.service';
import { CanComponentDeactivate } from '../../shared/guard/candeactivateguard.guard';

@Component({
  selector: 'app-managearchiveteam',
  templateUrl: './managearchiveteam.component.html',
  styleUrls: ['./managearchiveteam.component.css']
})
export class ManagearchiveteamComponent implements OnInit, CanComponentDeactivate, OnDestroy {
  userName = this.adalSvc.LoggedInUserName;
  userEmail = this.adalSvc.LoggedInUserEmail;
  euserAlias = this.userEmail.replace("@deloitte.com", "");
  activeroles: any;
  selectarchiveid: number;
  archivepartner: any;
  archivemanager: any;
  fieldsenior: any;
  archiveTempPartner: any;
  archiveTempManager: any;
  archiveTempFieldsenior: any;
  additionalfieldsenior: any;
  //For people picker
  searchText: string;
  users: Array<any> = [];
  searchPeople: FormGroup;
  selectedPartner: string;
  selectedManager: string;
  selectedTempPartner: string;
  selectedTempManager: string;
  selectedPartnerViewName: string = "";
  selectedFieldSenior: string = "";
  selectedTempFieldSenior: string;
  selectedAdditionalFieldSenior: string;
  selectedFieldSeniorViewName: string = "";
  selectedManagerViewName: string = "";
  selectedTempPartnerViewName: string;
  selectedTempManagerViewName: string;
  selectedTempFieldSeniorViewName: string;
  selectedAdditionalFieldSeniorViewName: string = "";
  success: any;
  currentUrl: string;
  showMyMessage: boolean = false;
  selectarchivenumber: string;
  isArchiveDestroyed:number = 0;
  showadditional: boolean;
  additionalfieldsenioralias: any;
  activeroles_form: FormGroup;
  fieldseniorvalue: any;
  addfieldsenioralias: any;
  currentPageNumber: number = 1;
  readonly pageSize: number = 10;
  mydata: any;
  pageCount: number = 1;
  pageArray = Array();
  totalhistory: number = 0;
  displayinghistoryfrom: number = 0;
  displayinghistoryto: number = 0;
  sortDir: number = 2;

  defaultDate = "0001-01-01T00:00:00";
  maxDate: Date;
  minDate: Date;
  tempPartnerExpireDate: Date;
  tempManagerExpireDate: Date;
  tempFieldSeniorExpireDate: Date;
  isPrivacyPeriodEnd: boolean;
  employeeRoleId: number = 15;
  userAlias = this.adalSvc.LoggedInUserEmail.substring(0, this.adalSvc.LoggedInUserEmail.lastIndexOf("@"));
  PPMDUsers: Array<any> = [];
  selectedSigningUserNames: any = [];
  archivePrivacyPeriodEndDate: Date;
  addSigningPeopleMaxCount: number = 5;
  addSigningPeopleUserName: any = [];
  isSigningUserDuplicate: boolean[] = [];
  selectedSigningUserAlias: any = [];
  compareSigningUserAlias: any = [];
  fieldArray: Array<any> = [];
  newAttribute: any = {};
  removeIndex: number;
  addIndex: number;
  duplicateValues: any;
  onlyFirstAttempt: number = 0;
  compareSelectedPartner: string;
  compareSelectedManager: string;
  compareSelectedFieldSenior: string;
  compareSelectedAdditionalFieldSenior: string;
  userConfig: any;
  roleMapping = new UserActions();
  rolecode: string;
  appendTeamMembersGrid: boolean = false;
  signingUserDuplicate: boolean[] = [];
  existingSelectedPartner: string;
  existingSelectedManager: string;
  existingSelectedFieldSenior: string;
  existingSelectedAdditionalFieldSenior: string;
  redirectURL:any;

  @ViewChild('autoCompleteInputTAP', { read: MatAutocompleteTrigger, static: false }) autoCompleteTAP: MatAutocompleteTrigger;
  @ViewChild('autoCompleteInputTAM', { read: MatAutocompleteTrigger, static: false }) autoCompleteTAM: MatAutocompleteTrigger;
  @ViewChild('autoCompleteInputTAFS', { read: MatAutocompleteTrigger, static: false }) autoCompleteTAFS: MatAutocompleteTrigger;
  @ViewChild('autoCompleteInputAP', { read: MatAutocompleteTrigger, static: false }) autoCompleteAP: MatAutocompleteTrigger;
  @ViewChild('autoCompleteInputAM', { read: MatAutocompleteTrigger, static: false }) autoCompleteAM: MatAutocompleteTrigger;
  @ViewChild('autoCompleteInputAFS', { read: MatAutocompleteTrigger, static: false }) autoCompleteAFS: MatAutocompleteTrigger;
  @ViewChild('autoCompleteInputAAFS', { read: MatAutocompleteTrigger, static: false }) autoCompleteAAFS: MatAutocompleteTrigger;
  @ViewChild('autoCompleteInputSP1', { read: MatAutocompleteTrigger, static: false }) autoCompleteSP1: MatAutocompleteTrigger;
  @ViewChild('autoCompleteInputSP2', { read: MatAutocompleteTrigger, static: false }) autoCompleteSP2: MatAutocompleteTrigger;
  @ViewChild('autoCompleteInputSP3', { read: MatAutocompleteTrigger, static: false }) autoCompleteSP3: MatAutocompleteTrigger;
  @ViewChild('autoCompleteInputSP4', { read: MatAutocompleteTrigger, static: false }) autoCompleteSP4: MatAutocompleteTrigger;
  @ViewChild('autoCompleteInputSP5', { read: MatAutocompleteTrigger, static: false }) autoCompleteSP5: MatAutocompleteTrigger;

  lastSearchKeyword: string = '';
  currentSearchKeyword: string = '';

  private _subject: BehaviorSubject<string> = new BehaviorSubject<string>("");


  constructor(private router: Router, private _userConfig: UserConfigSettingService, private pubsub: PubsubService, private service: ArchiveService, private peoplePickerService: PeoplePickerService, private homepageSvc: HomePageService, private notifier: NotifierService,
    private modalService: ModalService, private archiveinfoSvc: archiveInfoService,
     private activatedRoute: ActivatedRoute, public fb: FormBuilder,private archiveHomeService: ArchiveHomeService
     ,private adalSvc: MsAdalAngular6Service, private spinnerService: NgxSpinnerService) {
    router.events.subscribe((_nav: NavigationEnd) => {
    if(typeof(_nav)=='object')
    this.redirectURL =_nav;
    this.currentUrl = this.router.url});
    this.activeroles_form = fb.group({
      'archivepartner': [null, Validators.required],
      'archivemanager': [null, Validators.required],
      'fieldsenior': [null, Validators.required],
      'addtiobalfieldsenior': [null],
      'signingpartner1': [null],
      'signingpartner2': [null],
      'signingpartner3': [null],
      'signingpartner4': [null],
      'signingpartner5': [null],
      'temparchivepartner': [null],'temparchivepartnerExpiration': [null],
      'temparchivemanager': [null],'temparchivemanagerExpiration': [null],
      'tempfieldsenior': [null], 'tempfieldseniorExpiration': [null],
      'terms': [false]
    });
  }
  ngOnInit() {
   // this.spinnerService.show();

    // element.classList.remove("spn-li-breadcrumb");
    window.addEventListener('scroll', this.scrollEvent, true);
    this.selectarchivenumber = this.activatedRoute.snapshot.parent.params.aN;
    this.userConfig = this._userConfig.FetchLoggedInUser(this.userAlias);
    this.archiveHomeService.SyncForm3283SStatus(this.selectarchivenumber);
    // this.archiveinfoSvc.getArchiveInfo(this.selectarchivenumber, this.userAlias).subscribe(
    //   (archiveinfo) => {
    var archiveinfo = JSON.parse(localStorage.getItem('archiveInfoData'));
    this.isArchiveDestroyed = archiveinfo.isDestroyed;
    console.log('ArchiveTeamarchiveInfoData', archiveinfo);
    this.archivePrivacyPeriodEndDate = archiveinfo.privacyPeriodEndDate;
    this.isPrivacyPeriodEnd = new Date(this.archivePrivacyPeriodEndDate) < new Date() && Date.parse(this.defaultDate) != Date.parse(this.archivePrivacyPeriodEndDate.toString());
    // });
    this.getactiveroles(this.selectarchivenumber);
    // this.spinnerService.hide();
    var currentDate = new Date();
    this.minDate = new Date();
    this.maxDate = new Date(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate() + 29);
    this.setExpirationDates();
    this.getassignmnethistory();
  }
  setExpirationDates(){
    this.tempManagerExpireDate = this.maxDate;
    this.tempPartnerExpireDate = this.maxDate;
    this.tempFieldSeniorExpireDate = this.maxDate;
  }

  ngDoCheck() {
    this.roleMapping = this.pubsub.getRoleMappingResult();
  }

  scrollEvent = (event: any): void => {
    if (this.autoCompleteTAP && this.autoCompleteTAP.openPanel)
      this.autoCompleteTAP.updatePosition();
    if (this.autoCompleteTAM && this.autoCompleteTAM.openPanel)
      this.autoCompleteTAM.updatePosition();
    if (this.autoCompleteTAFS && this.autoCompleteTAFS.openPanel)
      this.autoCompleteTAFS.updatePosition();
    if (this.autoCompleteAP && this.autoCompleteAP.openPanel)
      this.autoCompleteAP.updatePosition();
    if (this.autoCompleteAM && this.autoCompleteAM.openPanel)
      this.autoCompleteAM.updatePosition();
    if (this.autoCompleteAFS && this.autoCompleteAFS.openPanel)
      this.autoCompleteAFS.updatePosition();
    if (this.autoCompleteAAFS && this.autoCompleteAAFS.openPanel)
      this.autoCompleteAAFS.updatePosition();
    if (this.autoCompleteSP1 && this.autoCompleteSP1.openPanel)
      this.autoCompleteSP1.updatePosition();
    if (this.autoCompleteSP2 && this.autoCompleteSP2.openPanel)
      this.autoCompleteSP2.updatePosition();
    if (this.autoCompleteSP3 && this.autoCompleteSP3.openPanel)
      this.autoCompleteSP3.updatePosition();
    if (this.autoCompleteSP4 && this.autoCompleteSP4.openPanel)
      this.autoCompleteSP4.updatePosition();
    if (this.autoCompleteSP5 && this.autoCompleteSP5.openPanel)
      this.autoCompleteSP5.updatePosition();
  };

  getassignmnethistory() {
   // this.spinnerService.show();
    this.service.getassignmenthistory(this.selectarchivenumber, this.currentPageNumber, this.pageSize, this.sortDir).subscribe(
      data => {

        if (this.appendTeamMembersGrid && data)
          this.mydata = this.mydata.concat(data);
        else
          this.mydata = data ? data : [];

        if (this.mydata.length > 0) {
          this.calculatePageCount();
        }
        else {
          this.clearPageCount();
        }
       // this.spinnerService.hide();
      }
    );
  }

  calculatePageCount() {
    let possiblePages: number;

    if (this.mydata && this.mydata.length > 0) {
      let possiblePages = Math.ceil(parseInt(this.mydata[0]["count"]) / this.pageSize);
      this.pageCount = possiblePages;
      this.pageArray = Array(this.pageCount).fill(0).map((e, i) => i + 1);
      this.totalhistory = this.mydata[0]["count"];
      this.displayinghistoryfrom = this.mydata[0]["rowNumber"];
      this.displayinghistoryto = this.mydata[this.mydata.length - 1]["rowNumber"];
    }
    else {
      this.clearPageCount();
    }
  }

  clearPageCount() {
    this.currentPageNumber = 1;
    this.pageCount = 1;
    this.pageArray = Array();
  }

  changePage(event, requestedPage: any) {
    if (isNaN(requestedPage) || requestedPage < 1 || requestedPage > this.pageCount) {
      this.notifier.notify("error", "Invalid page number.");
      return false;
    }
    this.currentPageNumber = parseInt(requestedPage);
    this.getassignmnethistory();

  }

  jumpToNextPage() {
    console.log('jumpToNextPage');

    if (this.currentPageNumber < this.pageArray.length) {
      this.currentPageNumber++;
      this.getassignmnethistory();
    }

  }

  jumpToPreviousPage() {
    console.log('jumpToPreviousPage');

    if (this.currentPageNumber > 1) {
      this.currentPageNumber--;
      this.getassignmnethistory();
    }
  }

  jumpToStartPage() {
    console.log('jumpToStartPage');
    this.currentPageNumber = 1;
    this.getassignmnethistory();
  }

  jumToEndPage() {
    console.log('jumToEndPage');
    this.currentPageNumber = this.pageArray[this.pageArray.length - 1];
    this.getassignmnethistory();
  }

  onSortClick(event) {
    let target = event.currentTarget,
      classList = target.classList;

    if (classList.contains('icon-Sort_amount_descending_SPECIAL')) {
      classList.remove('icon-Sort_amount_descending_SPECIAL');
      classList.add('icon-Sort_amount_ascending_SPECIAL');
      this.sortDir = 1;
      this.getassignmnethistory();
    } else {
      classList.add('icon-Sort_amount_descending_SPECIAL');
      classList.remove('icon-Sort_amount_ascending_SPECIAL');
      this.sortDir = 2;
      this.getassignmnethistory();

    }
  }

  showMessageSoon() {
    this.showMyMessage = true
  }

  getactiveroles(archivenumber: any) {
    this.addSigningPeopleUserName = [];
    this.selectedSigningUserAlias = [];
    this.compareSigningUserAlias = [];
    this.fieldArray = [];
    //this.spinnerService.show();
    this.service.GetActiveRoles(archivenumber).subscribe(
      data => {
        this.activeroles = data;
        data.forEach(element => {
          if (element.roleId == UserRoles.Partner) {
            this.archivepartner = element.employeeName;
            this.selectedPartnerViewName = element.employeeName;
            this.existingSelectedPartner = element.employeeName;
            this.selectedPartner = element.employeeAlias;
            this.compareSelectedPartner = element.employeeAlias;
          }
          else if (element.roleId == UserRoles.Manager) {
            this.archivemanager = element.employeeName;
            this.selectedManagerViewName = element.employeeName;
            this.existingSelectedManager = element.employeeName;
            this.selectedManager = element.employeeAlias;
            this.compareSelectedManager = element.employeeAlias;
          }
          else if (element.roleId == UserRoles.FieldSenior && element.displayOrder == UserRoles.FieldSeniorOrder) {
            this.fieldsenior = element.employeeName;
            this.selectedFieldSeniorViewName = element.employeeName;
            this.existingSelectedFieldSenior = element.employeeName;
            this.selectedFieldSenior = element.employeeAlias;
            this.compareSelectedFieldSenior = element.employeeAlias;
          }
          else if (element.roleId == UserRoles.AdditionalFieldSenior && element.displayOrder == UserRoles.AdditionalFieldSeniorOrder) {
            this.additionalfieldsenior = element.employeeName;
            this.selectedAdditionalFieldSeniorViewName = element.employeeName;
            this.existingSelectedAdditionalFieldSenior = element.employeeName;
            this.selectedAdditionalFieldSenior = element.employeeAlias;
            this.compareSelectedAdditionalFieldSenior = element.employeeAlias;
          }
          else if (element.roleId == UserRoles.TempPartner) {
            this.archiveTempPartner = element.employeeName;
            this.selectedTempPartner = element.employeeAlias;
            this.tempPartnerExpireDate = element.expirationDate;
          }
          else if (element.roleId == UserRoles.TempManager) {
            this.archiveTempManager = element.employeeName;
            this.selectedTempManager = element.employeeAlias
            this.tempManagerExpireDate = element.expirationDate;
          }
          else if (element.roleId == UserRoles.TempFieldSenior) {
            this.archiveTempFieldsenior = element.employeeName;
            this.selectedTempFieldSenior = element.employeeAlias;
            this.tempFieldSeniorExpireDate = element.expirationDate;
          }
          else if (element.roleId == UserRoles.SigningPartner) {
            this.selectedSigningUserNames.push(element.employeeName);
            this.addSigningPeopleUserName.push(element.employeeName);
            this.selectedSigningUserAlias.push(element.employeeAlias);
            this.compareSigningUserAlias.push(element.employeeAlias);
            this.fieldArray.push(this.newAttribute);
          }
         // this.spinnerService.hide();
        });
        if (this.fieldArray.length == 0)
          this.fieldArray.push(this.newAttribute);
          this.signingUserDuplicate.push(false);
      });
  }

  //For PeoplePicker

  onInputChanged(searchString: string, roleType?: string, indexValue?: number) {
    let element = document.getElementsByClassName("cdk-overlay-container")[0];
     if(element!==null && element !== undefined) {
      element.classList.add('custom-cdk-peoplepicker');
     }
     let matElement = document.getElementsByClassName("mat-autocomplete-panel")[0];
     if(matElement != null && matElement != undefined) {
      matElement.classList.add('clscustom-mat-options');
     }
    this.users = [];
    this.PPMDUsers = [];

    this.addIndex = indexValue;
    let haserror = this.isSigningUserDuplicate[this.addIndex];

    this.currentSearchKeyword = searchString;
    this._subject.next(this.currentSearchKeyword ? this.currentSearchKeyword.trim() : "");


    switch (roleType) {
      case "AdditionalFiledSenior":
        this.rolecode = "AAFS";
        break;
      case "TempPartner":
        this.rolecode = "TAP";
        break;
      case "TempManager":
        this.rolecode = "TAM";
        break;
      case "TempFiledSenior":
        this.rolecode = "TAFS";
        break;
      case "SigningPartner":
        this.rolecode = "SP";
        break;
      case "ArchivePartner":
        this.rolecode = "AP";
        break;
      case "ArchiveFieldSenior":
        this.rolecode = "AFS";
        break;
      case "ArchiveManager":
        this.rolecode = "AM";
    }
    if (searchString == "") {
      switch (roleType) {
        case "AdditionalFiledSenior":
          this.selectedAdditionalFieldSenior = undefined;
          break;
        case "TempPartner":
          this.selectedTempPartner = undefined;
          break;
        case "TempManager":
          this.selectedTempManager = undefined;
          break;
        case "TempFiledSenior":
          this.selectedTempFieldSenior = undefined;
          break;
        case "SigningPartner":
          this.isSigningUserDuplicate[this.addIndex] = false;
          this.signingUserDuplicate[this.addIndex] = false;
          this.selectedSigningUserAlias[this.addIndex] = "";
          let findDuplicates = arr => arr.filter((item, index) => arr.indexOf(item) != index)
          this.duplicateValues = findDuplicates(this.selectedSigningUserAlias);
          if (this.duplicateValues && !haserror) {
            let findIndex = this.isSigningUserDuplicate.indexOf(true);
            this.isSigningUserDuplicate[findIndex] = false;
            this.signingUserDuplicate[findIndex] = false;
          }
          break;
      }
    }
    else if (searchString.length >= 3) {
      this._subject.pipe(
        distinctUntilChanged(),
        debounceTime(500),
      ).subscribe(value => this.getPeople(value))
    }
    else {
      this.users = [];
      this.PPMDUsers = [];
      this.lastSearchKeyword = '';
    }


  }


  onFocusTB() {
    this.users = [];
    this.PPMDUsers = [];
  }

  getPeople(searchString: string) {
    if (searchString.length >= 3 && this.lastSearchKeyword != searchString) {
      this.lastSearchKeyword = searchString;
      this.peoplePickerService.GetPeople(searchString, this.rolecode).subscribe(
        (value) => {
          this.users = [];
          this.PPMDUsers = [];
          value.forEach(element => {
            if (this.currentSearchKeyword.length >= 3) {
              // if (element.isPPD)
              this.PPMDUsers = value;
              this.users = value;
            } else {
              this.PPMDUsers = [];
              this.users = [];
            }
          });
        },
        (err) => {
          console.log("error is ", err)
        }
      );
      this.spinnerService.hide();
    }
  }

  selectedPartnerName(partner, index) {

    // this.myarchive_description = partner.target.options[partner.target.selectedIndex].text;
    this.selectedPartnerViewName = partner.source.viewValue;
    this.selectedPartner = this.users[index].userAlias;//change to useralias once lambda is changed.
  }

  selectedManagerName(partner, index) {

    this.selectedManagerViewName = partner.source.viewValue;
    this.selectedManager = this.users[index].userAlias;
    //change to useralias once lambda is changed.
  }

  selectedFieldSeniorName(fieldsenior, index) {

    this.selectedFieldSeniorViewName = fieldsenior.source.viewValue;
    this.selectedFieldSenior = this.users[index].userAlias;//change to useralias once lambda is changed.
  }

  selectedAdditionalFieldSeniorName(additionalfieldsenior, index) {

    this.selectedAdditionalFieldSeniorViewName = additionalfieldsenior.source.viewValue;
    this.selectedAdditionalFieldSenior = this.users[index].userAlias;//change to useralias once lambda is changed.
  }
  selecteTemporaryPartnerName(partner, index) {
    this.selectedTempPartnerViewName = partner.source.viewValue;
    this.selectedTempPartner = this.users[index].userAlias;//change to useralias once lambda is changed.
  }

  selecteTemporaryManagerName(partner, index) {
    this.selectedTempManagerViewName = partner.source.viewValue;
    this.selectedTempManager = this.users[index].userAlias;
  }

  selecteTemporaryFieldSeniorName(fieldsenior, index) {
    this.selectedTempFieldSeniorViewName = fieldsenior.source.viewValue;
    this.selectedTempFieldSenior = this.users[index].userAlias;//change to useralias once lambda is changed.
  }
  onExpireDateChange(event: any, dateType?: string) {
    if (dateType == "partner") this.tempPartnerExpireDate = event;
    if (dateType == "manager") this.tempManagerExpireDate = event;
    if (dateType == "fieldsenior") this.tempFieldSeniorExpireDate = event;
  }

  canDeactivate() {
    if(this.activeroles_form.dirty)
    this.modalService.openWithCustomWidth('managearchiveteam-cancel-alert-modal', "500");
    else
    return true;
  }
  cancelAlert() {
    if(this.activeroles_form.dirty)
    this.modalService.openWithCustomWidth('managearchiveteam-cancel-alert-modal', "500");
    else
    this.redirectToArchiveHomePage("archive/myarchives");
  }
  cancelAndRedirectArchiveHomePage(){
    this.activeroles_form.reset();
    this.activeroles_form.get('archivepartner').setValue(this.existingSelectedPartner);
    this.activeroles_form.get('archivemanager').setValue(this.existingSelectedManager);
    this.activeroles_form.get('fieldsenior').setValue(this.existingSelectedFieldSenior);
    this.additionalfieldsenior = this.existingSelectedAdditionalFieldSenior;
    //this.activeroles_form.get('fieldsenior').setValue(this.existingSelectedFieldSenior);
    this.fieldArray=[];
    this.signingUserDuplicate=[];
    this.fieldArray.push(this.newAttribute);
    this.signingUserDuplicate.push(false);
    this.selectedSigningUserAlias = [];
    this.addSigningPeopleUserName = [];
    if(this.redirectURL.url == this.currentUrl)
     this.redirectToArchiveHomePage("archive/myarchives");
     else{
       this.router.navigate([this.redirectURL.url]);
     }
  }

  oninput(eventvalue: string) {
    this.fieldseniorvalue = eventvalue.length;
  }

  updateteamroles() {
    let index = this.getAllIndexes(this.signingUserDuplicate, true);
    if (this.fieldseniorvalue == undefined) {

      this.addfieldsenioralias = this.additionalfieldsenioralias;
    }
    else if (this.fieldseniorvalue == 0) {

      this.addfieldsenioralias = undefined;
    }
    else {
    }
    this.markFormTouched(this.activeroles_form);
    if (this.activeroles_form.valid && index.length < 1) {
      if (!this.isPrivacyPeriodEnd) {
        var parameter =
        {
          "ArchiveNumber": this.selectarchivenumber,
          "CreatedBy": '',
          "ArchivePartner": this.selectedPartner,
          "ArchiveManager": this.selectedManager,
          "ArchiveFieldSenior": this.selectedFieldSenior,
          "AdditionalArchiveFieldSenior": this.selectedAdditionalFieldSenior,
          "SigningPartners": this.selectedSigningUserAlias.filter(function (el) { return el != null; }).toString()
        }
        var myobjstr = JSON.stringify(parameter);
       // this.spinnerService.show();
        let isCoreTeamChanged = this.isCoreTeamModified();
        let isSigningPartnerChanged = this.isSigningPartnerModified();
        this.service.updateteamroles(myobjstr)
          .subscribe(
            data => {
              this.success = data;
              console.log(this.success);
              this.roleMappingResult();
              this.getactiveroles(this.selectarchivenumber);
              this.getassignmnethistory();
              this.selectedAdditionalFieldSenior = undefined;
              this.addfieldsenioralias = undefined;
              this.fieldseniorvalue = undefined;
              this.selectedAdditionalFieldSeniorViewName = "";
              //this.spinnerService.hide();
              if (isCoreTeamChanged && this.success == 'Success')
                this.notifier.notify("success", "Core team saved successfully.");
              if (isSigningPartnerChanged && this.success == 'Success')
                this.notifier.notify("success", "Signing Partner(s) added successfully.");
              if (this.success == 'UnAuthorized')
                this.notifier.notify("error", "User does not have access to perform action");
            });

      }
      if (this.isPrivacyPeriodEnd) {
        var tempArchiveParameter =
        {
          "ArchiveNumber": this.selectarchivenumber,
          "CreatedBy": '',
          "TempArchivePartner": this.selectedTempPartner,
          "TempArchiveManager": this.selectedTempManager,
          "TempArchiveFieldSenior": this.selectedTempFieldSenior,
          "TempArchivePartnerExpDate": this.tempPartnerExpireDate != undefined && this.tempPartnerExpireDate != null ? new Date(this.tempPartnerExpireDate).toLocaleDateString() : this.tempPartnerExpireDate,
          "TempArchiveManagerExpDate": this.tempManagerExpireDate != undefined && this.tempManagerExpireDate != null ? new Date(this.tempManagerExpireDate).toLocaleDateString() : this.tempManagerExpireDate,
          "TempArchiveFieldSeniorExpDate": this.tempFieldSeniorExpireDate != undefined && this.tempFieldSeniorExpireDate != null ? new Date(this.tempFieldSeniorExpireDate).toLocaleDateString() : this.tempFieldSeniorExpireDate
        }
        var archiveTeamObject = JSON.stringify(tempArchiveParameter);
       // this.spinnerService.show();
        this.service.createTemporaryArchiveTeam(archiveTeamObject)
          .subscribe(data => {
            this.success = data;
            this.setExpirationDates();
            console.log(this.success);
            this.roleMappingResult();
            this.getactiveroles(this.selectarchivenumber);
            this.getassignmnethistory();
            this.selectedAdditionalFieldSenior = undefined;
            this.addfieldsenioralias = undefined;
            this.fieldseniorvalue = undefined;
            this.selectedAdditionalFieldSeniorViewName = "";
           // this.spinnerService.hide();
            this.notifier.notify("success", "Temporary team saved successfully.");
          });
      }
    }
    else {
      this.activeroles_form.controls['terms'].setValue(false);
    }
    this.activeroles_form.reset();
  }
  redirectToArchiveHomePage(PageUrl) {
    this.router.navigate(["/" + PageUrl + "/" + this.selectarchivenumber]);
  }

  OnClick(PageUrl) {
    this.router.navigate(["/" + PageUrl + ""]);
  }
  markFormTouched(group: FormGroup | FormArray) {
    Object.keys(group.controls).forEach((key: string) => {
      const control = group.controls[key];
      if (control instanceof FormGroup || control instanceof FormArray) { control.markAsTouched(); this.markFormTouched(control); }
      else { control.markAsTouched(); };
    });
  };

  selecteSigningUserName(signingUser, index) {
    let result = this.getAllIndexes(this.selectedSigningUserAlias, this.users[index].userAlias);
    if (result.length > 0) {
      this.signingUserDuplicate[this.addIndex] = true;
      this.addSigningPeopleUserName[this.addIndex] = signingUser.source.viewValue;
      this.selectedSigningUserAlias[this.addIndex] = this.users[index].userAlias;
    }
    else {
      this.signingUserDuplicate[this.addIndex] = false;
      this.addSigningPeopleUserName[this.addIndex] = signingUser.source.viewValue;
      this.selectedSigningUserAlias[this.addIndex] = this.users[index].userAlias;
    }
    this.PPMDUsers = [];
    this.users = [];
  }
  addFieldValue() {
    if (this.fieldArray.length < this.addSigningPeopleMaxCount) {
      this.fieldArray.push(this.fieldArray.length + 1);
      this.signingUserDuplicate.push(false);
    }
  }

  removeAlertShow(indexValue) {
    this.removeIndex = indexValue;
    this.modalService.openWithCustomWidth('remove-alert-modal', "500");
  }
  removeFieldAndValue(removeSigningUser) {
    if (removeSigningUser) {
      let findIndex = this.getAllIndexes(this.selectedSigningUserAlias, this.selectedSigningUserAlias[this.removeIndex]);
      if (!this.signingUserDuplicate[this.removeIndex] && findIndex.length == 1)
        this.signingUserDuplicate[findIndex[findIndex.length]] = false;
      if (!this.signingUserDuplicate[this.removeIndex] && findIndex.length == 2)
        this.signingUserDuplicate[findIndex[findIndex.length - 1]] = false;
      else if (!this.signingUserDuplicate[this.removeIndex] && findIndex.length == 3)
        this.signingUserDuplicate[findIndex[findIndex.length - 2]] = false;
      else if (!this.signingUserDuplicate[this.removeIndex] && findIndex.length == 4)
        this.signingUserDuplicate[findIndex[findIndex.length - 3]] = false;
      else if (!this.signingUserDuplicate[this.removeIndex] && findIndex.length == 5)
        this.signingUserDuplicate[findIndex[findIndex.length - 4]] = false;

      this.fieldArray.splice(this.removeIndex, 1);
      this.signingUserDuplicate.splice(this.removeIndex, 1);
      this.addSigningPeopleUserName.splice(this.removeIndex, 1);
      this.selectedSigningUserAlias.splice(this.removeIndex, 1);
      this.notifier.notify("success", "Signing partner removed successfully");
    }
  }
  clearadditionalfieldseniorvalue() {
    this.additionalfieldsenior = "";
    this.selectedAdditionalFieldSeniorViewName="";
    this.selectedAdditionalFieldSenior = undefined;
  }
  closeModalDialog(Action) {
    this.modalService.close(Action);
  }
  clearFieldValue(clearIndex) {
    let findIndex = this.getAllIndexes(this.selectedSigningUserAlias, this.selectedSigningUserAlias[clearIndex]);
    if (this.signingUserDuplicate[clearIndex])
      this.signingUserDuplicate[clearIndex] = false;
    else {
      if (findIndex.length == 1)
        this.signingUserDuplicate[findIndex[findIndex.length - 1]] = false;
      if (findIndex.length == 2)
        this.signingUserDuplicate[findIndex[findIndex.length - 2]] = false;
      else if (findIndex.length == 3)
        this.signingUserDuplicate[findIndex[findIndex.length - 3]] = false;
      else if (findIndex.length == 4)
        this.signingUserDuplicate[findIndex[findIndex.length - 4]] = false;
      else if (findIndex.length == 5)
        this.signingUserDuplicate[findIndex[findIndex.length - 5]] = false;
    }
    this.addSigningPeopleUserName[clearIndex] = "";
    this.selectedSigningUserAlias[clearIndex] = "";
  }
  getAllIndexes(array, value) {
    var indexes = [], i = -1;
    while ((i = array.indexOf(value, i + 1)) != -1) { indexes.push(i); }
    return indexes;
  }
  isCoreTeamModified(): boolean {
    return this.selectedPartner != this.compareSelectedPartner || this.selectedManager != this.compareSelectedManager
      || this.selectedFieldSenior != this.compareSelectedFieldSenior || this.selectedAdditionalFieldSenior != this.compareSelectedAdditionalFieldSenior;
  }
  isSigningPartnerModified(): boolean {
    return this.compareSigningUserAlias.filter(function (el) { return el != null; }).toString() != this.selectedSigningUserAlias.filter(function (el) { return el != null; }).toString();
  }
  roleMappingResult() {
    this.service.GetRoleMappingsForUser(this.euserAlias, this.selectarchivenumber).subscribe(x => {
      // debugger;
      if (x) {
        this.roleMapping.roleId = x.roleId;
        this.roleMapping.roleDescription = x.roleDescription;
        this.roleMapping.canSearchArchives = x.archivePermissions.includes('Search Archives');
        this.roleMapping.canAccessArchives = x.archivePermissions.includes('Access Archive');
        this.roleMapping.canCreateArchive = x.archivePermissions.includes('Manual Archive Creation');
        this.roleMapping.canManageArchiveInfo = x.archivePermissions.includes('Manage Archive Info');
        this.roleMapping.canManageAccess = x.archivePermissions.includes('Manage Access');
        this.roleMapping.canSubmit = x.archivePermissions.includes('Submission');
        this.roleMapping.canUpload = x.archivePermissions.includes('Upload Record');
        this.roleMapping.canDownload = x.archivePermissions.includes('Download Record');
        this.roleMapping.canDelete = x.archivePermissions.includes('Delete Record');
        this.roleMapping.canMarkAsInactive = x.archivePermissions.includes('Mark as Inactive');
        this.roleMapping.canManageERP = x.archivePermissions.includes('Manage ERP');
        this.roleMapping.canRequestRetentionException = x.archivePermissions.includes('Request Retention Exception');
        this.roleMapping.canRequestAccess = x.archivePermissions.includes('Request Access');
        this.roleMapping.canApproveTemporaryAccess = x.archivePermissions.includes('Approve Temporary Access');
        this.roleMapping.canViewArchiveHistory = x.archivePermissions.includes('View Archive History');
        this.roleMapping.canPrintBinderReportCovers = x.archivePermissions.includes('Print Binder & Report Covers');
        this.roleMapping.canRequestImage = x.archivePermissions.includes('Request Image');
        this.roleMapping.canLinkArchives = x.archivePermissions.includes('Archive Linking');
        this.roleMapping.canApprove = x.archivePermissions.includes('Approval');
        this.roleMapping.canResubmit = x.archivePermissions.includes('Resubmission (Substantive or Adminstrative)');
        // this.roleMapping.canResubmitAdminApproval = x.archivePermissions.includes('Resubmission (Substantive or Adminstrative)');
        this.roleMapping.canResubmitAdminApproval = x.archivePermissions.includes('Administrative Resubmission Approval');
        this.roleMapping.canRequestArchiveDeletion = x.archivePermissions.includes('Request Archive Deletion');
        this.roleMapping.canApproveForm3283S = x.archivePermissions.includes('Approve Form 3283S');
        this.roleMapping.canRequestForm3283S = x.archivePermissions.includes('Request Form 3283S');
        this.roleMapping.canRequestLegalHold = x.archivePermissions.includes('Request Legal Hold');
        this.roleMapping.canTempArchiveAccess = x.archivePermissions.includes('Temporary Archive Access');
        this.roleMapping.canViewSwiftEngagementDetails = x.archivePermissions.includes('View Swift EngagementDetails');
        this.roleMapping.canMarkRestrictedAccess = x.archivePermissions.includes('Mark with restricted access');
        this.roleMapping.canChangeEstimatedReleaseDate = x.archivePermissions.includes('Change Estimated Release Date');
      }
      // console.log(this.roleMapping);
      // localStorage.setItem('roleMapping', JSON.stringify(this.roleMapping));
      this.pubsub.setRoleMappingResult(this.roleMapping);
      // this.service.setRoleMappingResult(this.roleMapping);
    });
  }
  updateGridData(event) {
    this.appendTeamMembersGrid = event.isLoadMoreClicked;
    this.currentPageNumber = event.pageNumber;
    this.getassignmnethistory();
  }
  ngOnDestroy() {
    let element = document.getElementsByClassName("cdk-overlay-container")[0];
    if(element!==null && element !== undefined && element.classList.contains('custom-cdk-peoplepicker')) {
     element.classList.remove('custom-cdk-peoplepicker');
    }
    let matElement = document.getElementsByClassName("mat-autocomplete-panel")[0];
    if(matElement != null && matElement != undefined) {
     matElement.classList.remove('clscustom-mat-options');
    }
  }
}
enum UserRoles {
  FieldSeniorOrder = 0,
  AdditionalFieldSeniorOrder = 1,
  TempPartner = 3,
  TempManager = 4,
  TempFieldSenior = 2,
  Partner = 5,
  Manager = 6,
  FieldSenior = 7,
  AdditionalFieldSenior = 7,
  SigningPartner = 27
}
