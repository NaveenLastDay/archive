﻿using Deloitte.AIFA.DomainEntities;
using System.Collections.Generic;

namespace Deloitte.AIFA.IRepositories
{
    public  interface IArchiveSearchRepository
    {
        List<SearchOptions> SearchByCategory(string Search,string CategoryType);
    }
}
