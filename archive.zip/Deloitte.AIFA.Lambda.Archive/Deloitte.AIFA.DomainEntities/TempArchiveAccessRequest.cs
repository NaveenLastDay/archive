﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
    public class TempArchiveAccessRequest
    {
        public string RequestedBy { get; set; }
        public string RequestDesc { get; set; }
        public string ArchiveAccessRequestID { get; set; }
    }
}
