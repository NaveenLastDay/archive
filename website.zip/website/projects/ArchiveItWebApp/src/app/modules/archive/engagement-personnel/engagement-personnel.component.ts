import { Router, ActivatedRoute, Params } from "@angular/router";
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { ArchiveService } from './../../../services/archive.service';
import { NotifierService, NotifierModule, NotifierOptions } from "angular-notifier";
import { ArchiveHomeService } from '../../../services/archive-home.service';
import { archiveInfoService } from '../../../services/archiveinfo.service'
import { ModalService } from "../../shared/modal";
import { EmployeeService } from '../../../services/employee.service'
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { AngularEditorConfig } from '@kolkov/angular-editor';
import { UserActions } from '../../../models/archive-role.model';
import { PubsubService } from '../../../services/pubsub.service';
import { PaginationComponent } from "../../shared/pagination/pagination.component";

@Component({
  selector: 'app-engagement-personnel',
  templateUrl: './engagement-personnel.component.html',
  styleUrls: ['./engagement-personnel.component.css']
})
export class EngagementPersonnelComponent implements OnInit {
  totalMembers: number = 0;
  currentPageNumber: number = 1;
  popupname: string = '';
  popupindex: number = 0;
  hoverIndex: number = -1;
  readonly pageSize: number = 10;
  archiveNumber: string = '';
  sortByEnum: any = MyMembersSortBy;
  columnByEnum: any = MyMembersColumnBy;
  wbsNumber: string = '';
  filterBy: number = 1
  myMembers: any[];
  myMemberData: any[];
  myMemberMasterData: any[];
  myMemberFilterData: any[];
  pageCount: number = 1;
  pageArray = Array();
  appendMembersGrid: boolean = false;
  sortBy: number = this.sortByEnum.SortBy_EmployeeName_Asc;
  sortColumnDialog: number = -1;
  displayingRecordsFrom: number = 0;
  displayingRecordsTo: number = 0;
  filterText: string = "";
  eventType: string = '';
  show: boolean = false;
  paramindex: number = 0;
  searchtextvalue: string = '';
  filtercheck: boolean = false;
  businessvalue: string = '';
  filterarray: any = [];
  officevalue: string = '';
  methodvalue: string = '';
  ActionType:any;
 

  // Multi Select Compeoent

  searchTerm: string;
  term: string;
  personels = [];
  selectAll: boolean;
  selectedMember: number = 0;
  searchText: string = "";
  filter = '';
  filterCount: number = 0;
  selectedemps = [];
  userAlias =this.adalSvc.LoggedInUserEmail.substring(0, this.adalSvc.LoggedInUserEmail.lastIndexOf("@"));
  deleteEmployeeAlias: string = '';
  officeDropdownData: any = [];
  businessDropdownData: any = [];
  addMethodDropdownData: any = [];
  public lastUpdatedSwiftDataOn: Date | string;
  public initialDataLoaded: boolean = false;

  popUpHeaderText: string = "";
  retentionInfo: any;
  canApprove: boolean = false;
  isEditMode: boolean = false;
  BodyCount: number = 250;
  success: any;
  sectionid: number = 5;
  ApproveDisabled: boolean = true;
  rejectionDiscrption: any = "";
  ResubmissionReasonForERPSection:any="";
  rejectionDiscrptionDisplay: any = "";
  isRejectDiscrptionMin: boolean = false;
  isRejectDiscrptionMax: boolean = false;
  rejectedBy: any;
  isSectionApproved: boolean = false;
  isSectionRejected: boolean = false;
  topCss: any;
  showEdit: boolean = false;
  disabledColor: any;
  rejectedb: any;
  rejectedDate: any;
  IsSectionVisited: any;
  rejectionComments: any;
  wordCount: number = 0;
  ERPEditedInResubmit:boolean;
  ERPReasonsProvidedInResubmit:string='';
  ERPEditedDate:Date;
  roleMapping = new UserActions();
  //Added below properties to disable the editing feature for Non-Approvers.
  CurrentArchiveStatus:any;
  ShowContentForEdit:number=0;
  isERPSectionVisitedinOpenBySubmitter:any;
  IsChangeDecissionClicked: boolean=false;
  @ViewChild('searchtab',{static: false}) searchtab: ElementRef;
  @ViewChild(PaginationComponent, {static: false}) pagination : PaginationComponent;
  showEmptyResultTosterForFilter : boolean = true;

  constructor(private SpinnerService: NgxSpinnerService
    , private archiveService: ArchiveService
    , private notifier: NotifierService
    , private archiveHomeService: ArchiveHomeService
    , private archiveInfoService: archiveInfoService,
    private pubsub: PubsubService,
    private adalSvc: MsAdalAngular6Service,
    private dataService: EmployeeService,
    private modalservice: ModalService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
  ) {
    this.roleMapping = this.pubsub.getRoleMappingResult();
   }
  /*text editor config*/

  editorConfig: AngularEditorConfig = {

    editable: true,
    spellcheck: true,
    height: 'auto',
    minHeight: '120',
    maxHeight: 'auto',
    width: 'auto',
    minWidth: '0',
    translate: 'yes',
    enableToolbar: true,
    showToolbar: true,
    placeholder: 'Please enter the reason',
    defaultParagraphSeparator: '',
    defaultFontName: '',
    defaultFontSize: '',
    fonts: [
      { class: 'arial', name: 'Arial' },
      { class: 'times-new-roman', name: 'Times New Roman' },
      { class: 'calibri', name: 'Calibri' },
      { class: 'comic-sans-ms', name: 'Comic Sans MS' }
    ],

    customClasses: [
      {
        name: 'quote',
        class: 'quote',
      },
      {
        name: 'redText',
        class: 'redText'
      },
      {
        name: 'titleText',
        class: 'titleText',
        tag: 'h1',
      },
    ],
    uploadUrl: '',
    uploadWithCredentials: false,
    sanitize: true,
    toolbarPosition: 'top',
    toolbarHiddenButtons: [
      [
        'undo',
        'redo',
        'subscript',
        'superscript',
        'justifyFull',
        'indent',
        'outdent',
        'insertOrderedList',
        'heading',
        //'fontName'
      ],
      [
        'textColor',
        'backgroundColor',
        'customClasses',
        //'link',
        'unlink',
        'insertImage',
        'insertVideo',
        'insertHorizontalRule',
        'removeFormat',
        'toggleEditorMode'
      ]
    ]
  };
  ngOnInit() {
    this.archiveNumber = this.activatedRoute.snapshot.parent.params.aN;   
    this.GetWbsNumberDetails(this.archiveNumber);
    localStorage['IsSectionVisited'] = '0';
    console.log("LocalStorage Reset to 0 in ERP (197):",localStorage['IsSectionVisited']);
    localStorage['isERPSectionVisitedinOpenBySubmitter']='1';
    this.Getsectioncomments(this.archiveNumber, this.sectionid,2);
    var data = JSON.parse(localStorage.getItem('archiveSubmissionStatusData'));
        console.log('erparchiveSubmissionStatusData',data);
    // this.archiveHomeService.GetArchiveStatus(this.archiveNumber, this.userAlias).subscribe(data => {
      if (data) {
        this.canApprove = data.canApprove;
        this.CurrentArchiveStatus=data.archiveInfo.archiveStatus;
        this.Getsectioncomments(this.archiveNumber, this.sectionid,2);
        this.HideorShowlogic();

        // //If the archive is in RFA State, then hide the edit part to the archive team so that only approver can edit the archive.
        // if((this.CurrentArchiveStatus=="Ready For Approval" && this.canApprove===false)||this.CurrentArchiveStatus=="Approved"|| (this.CurrentArchiveStatus=="Resubmitted - Ready for Approval" && this.canApprove===false))
        // {
        //   this.ShowContentForEdit=0;
        // }
        // else{
        //   this.ShowContentForEdit=1;
        // }

        // if(this.CurrentArchiveStatus=="Resubmitted - Ready for Approval")
        // {
        //   this.GetResubmissionApprovalFlow();
        // }
      }
    // }); 
    }

//Flags and its Use:

   // UI flags
  // this.showEdit=true;  // It is for enabling edit button
  // this.ShowApproveRejectButtons=true;  // It is for showing approve/Reject button
   // this.ShowContentForEdit=1;  // It is to show content in edit mode
  // this.ReadOnlyArchiveDetails=true;  // It is to show content in readonly mode
  // this.isSectionRejected // to know whether the section is rejected or not
  // this.SaveChangestoArchiveDetailsForm=true;  // Using this flag to show  Save/Cancel button
  // this.hideRejectedMessage = true;  // It is not required
  // this.changeDecision = false;  // Showing or hiding change decision
  // this. IsSectionVisited // To know whether the user visited the section or not
       //DB Flags
        // this.CurrentArchiveStatusforArchiveDetails  Using this for Archive status
        // this.isApprover  // To know whether he/She can approve it or not
         // this.isSectionRejected // to know whether the section is rejected or not



         HideorShowlogic(){
          var archiveStatusHome: string =this.CurrentArchiveStatus;
          switch(archiveStatusHome){
      
            /* ====== Edit mode for Archive team All the times ======*/
             /* common for Open, Resubmitted – Open*/
             case 'Open':{
              this.commonViewForEdit();
              break;
            }
            case "Resubmitted – Open":{
              this.commonViewForEdit();
              this.archiveHomeService.GetResubmissionReasonsforArchive(this.archiveNumber).subscribe(data=>
                {
                  debugger;
                  if(data){
                   if(data.length>0)
                   {
                    this.ERPEditedInResubmit=data[4].actionTypeId==3?true:false;
                    this.ERPReasonsProvidedInResubmit= data[4].comments!=""?data[4].comments:"";
                    this.ERPEditedDate=data[4].rejectedDate;
                   }
                   }
                });
              break;
            }
      
               /*End common for Open, Resubmitted – Open*/
      
      
               /* common for Rejected, Resubmitted – Rejected*/
            case "Rejected":
              {
                this.commonViewForEdit();
                break;
              }
        
              case "Resubmitted - Rejected":{
                if(this.roleMapping.roleId==11 || this.roleMapping.roleId==12)
                {
                  this.CommonViewForReadonly();
                }
                else{
                this.commonViewForEdit();}
                break;
              }
      
             /*End common for Rejected, Resubmitted – Rejected*/
      
              /* ====== Edit mode for Archive team All the times ======*/
      
            case 'Ready For Approval':{
              this.archiveHomeService.GetArchiveApproverForArchiveSubmission(this.archiveNumber,this.roleMapping.roleId).subscribe(data =>
                {
                    if(data){
                        console.log('GetArchiveApproverForArchiveSubmission-ERP',data.canApprove);
                        this.canApprove=data.canApprove;
                    }
                    if(this.canApprove){
                      this.specificViewToApprover();
                    }
                    else{
                      this.CommonViewForReadonly();
                    }
                });
              break;
            }
            case "Resubmitted - Ready for Approval":{
              this.GetResubmissionApprovalFlow();
              
         
              break;
            }
          
      
            /*Common for Approved, Resubmitted – Approved */
            case "Approved":{
              this.CommonViewForReadonly();
              break;
            }
            case "Resubmitted – Approved":{
              this.CommonViewForReadonly();
              break;
            }
           
            /*End Common for Approved, Resubmitted – Approved and Resubmitted - Rejected */
      
             }
          
        }
      
      
         //This will have the common view for Archive team. Remaining should be handled in cases.
         // Don't keep any conditions here 
         commonViewForEdit(){
          this.ShowContentForEdit=1;
        }
      
        CommonViewForReadonly()
        {
          this.ShowContentForEdit=0;
        }
      
        // Approver view
        specificViewToApprover()
         {
          this.ShowContentForEdit=1;
         }


  GetResubmissionApprovalFlow(){
    // debugger;
    var inparameters = {
      "ArchiveNumber": this.archiveNumber,
      "UserAlias": ''
    }
    var parameters = JSON.stringify(inparameters);
    this.archiveHomeService.GetResubmissionApprovalFlowStatuses(parameters).subscribe(
      (obj) => {
          this.canApprove=obj[0].canApprove;
          if(obj[0].completedApprovel>=1){
            this.canApprove=false;
          }
        //    //1st level by default read only view (After clicking it will be in edit modw)
        // else if(obj[0].completedApprovel==0){
        //               if(localStorage['isFirstLevelEdited']=="null" || localStorage['isFirstLevelEdited']==0)
        //               this.canApprove=false;
        //           } 
          this.archiveHomeService.GetResubmissionReasonsforArchive(this.archiveNumber).subscribe(data=>{
            debugger;
            if(data){
             if(data.length>0)
             {
              this.ERPEditedInResubmit=data[4].actionTypeId==3?true:false;
              this.ERPReasonsProvidedInResubmit=data[4].comments!=""?data[4].comments:"";
              this.ERPEditedDate=data[4].rejectedDate;
            }
             
            }
          });

          if(this.canApprove){
            this.specificViewToApprover();

          }
  
          else{
            this.CommonViewForReadonly();
          }
         },
      (err) => {
        console.log("error is ", err)
      }
    );
    
  }

  ngDoCheck() {
    this.roleMapping = this.pubsub.getRoleMappingResult();
  }

  refreshSWIFTData() {
    this.resetpage();
    this.getMembers();
  }

  GetWbsNumberDetails(archiveNumber: string) {
    // this.archiveInfoService.getArchiveInfo(archiveNumber).subscribe(
    //   data => {
      if(localStorage.getItem('archiveInfoData') !=''){
      var data = JSON.parse(localStorage.getItem('archiveInfoData'));
      this.initializeWbs(data);
      }else{
        this.archiveInfoService.getArchiveInfo(this.archiveNumber, this.adalSvc.LoggedInUserEmail.split('@')[0]).subscribe(
          (info) => {
            localStorage.setItem('archiveInfoData', JSON.stringify(info));
            this.initializeWbs(info);
           }
        );
      }
      console.log('engPersonalarchiveInfoData',data);
        
      // });
  }

  initializeWbs(data:any){
    if (data.wbsNumber != null && data.wbsNumber != undefined) {
      this.wbsNumber = data.wbsNumber;
      this.getMembers();
    }
    else {
      this.lastUpdatedSwiftDataOn = this.convertDatetoCST(new Date(), true);
    }
  }

  mouseOut(event: any) {
    let name: string = '';
    let present: number = -1;

    name = event.toElement ? event.toElement.getAttribute('name') : '';
    present = name ? name.search("AccessArchiveTop") : -1;

    if (event.toElement && present == -1 && (event.toElement["tagName"] != 'td' || event.toElement.className == 'memberGridHeadFont')) {
      this.hoverIndex = -1;
    }
  }

  calculatePageCount() {
    // // debugger;
    let possiblePages: number;
    if (this.myMembers && this.myMembers.length > 0) {
      let possiblePages = Math.ceil(parseInt(this.myMembers[0]["count"]) / this.pageSize);
      this.pageCount = possiblePages;
      this.pageArray = Array(this.pageCount).fill(0).map((e, i) => i + 1);
      this.totalMembers = this.myMembers[0]["count"];
      // this.displayingRecordsFrom  = this.myMembers[0]["rowNumber"];
      // this.displayingRecordsTo = this.myMembers[this.myMembers.length -1]["rowNumber"];
      this.displayingRecordsFrom = this.pageSize * (this.currentPageNumber - 1) + 1;
      this.displayingRecordsTo = this.displayingRecordsFrom + this.pageSize - 1;
      if (this.displayingRecordsTo > this.totalMembers) {
       // this.displayingRecordsTo = this.myMembers[this.myMembers.length - 1]["rowNumber"];
       this.displayingRecordsTo=this.totalMembers;
      }
    }
    else {
      this.clearPageCount();
    }
  }

  clearPageCount() {
    this.currentPageNumber = 1;
    this.pageCount = 1;
    this.pageArray = Array();
  }

  mouseOver(event: any, index: number) {
    this.hoverIndex = index;
    //event.stopPropagation();
  }

  showRecordDetails(archiveNumber, index) {
    if (this.archiveNumber == archiveNumber) {
      this.archiveNumber = '';
      this.eventType = ''

    }
    else {
      this.archiveNumber = archiveNumber;
      this.eventType = 'select';

    }
  }
  memberSortDialog(event) {
    //// debugger;
    if (this.sortColumnDialog == event) this.sortColumnDialog = -1;
    else this.sortColumnDialog = event;
  }

  sortOrderChanged(event) {
    //// debugger;
    this.resetfilter();    
    this.resetpage();
    this.memberSortDialog(this.columnByEnum.ColumnBy_Default);
    this.sortBy = event;
    //this.getMembersFilterDataWithPaging();
    this.getMembers();
  }

  changePage(event, requestedPage: any) {


    if (isNaN(requestedPage) || requestedPage < 1 || requestedPage > this.pageCount) {
      this.notifier.notify("error", "Invalid page number.");
      return false;
    }
    this.currentPageNumber = parseInt(requestedPage);
    this.getMembersFilterDataWithPaging();

  }

  jumpToStartPage() {
    console.log('jumpToStartPage');
    this.currentPageNumber = 1;
    this.getMembersFilterDataWithPaging();
  }

  jumToEndPage() {
    console.log('jumToEndPage');
    this.currentPageNumber = this.pageArray[this.pageArray.length - 1];
    this.getMembersFilterDataWithPaging();
  }

  jumpToPreviousPage() {
    console.log('jumpToPreviousPage');

    if (this.currentPageNumber > 1) {
      this.currentPageNumber--;
      this.getMembersFilterDataWithPaging();
    }
  }

  jumpToNextPage() {
   // console.log('jumpToNextPage');

    //if (this.currentPageNumber <= this.pageArray.length) {
      //this.currentPageNumber++;
      this.getMembersFilterDataWithPaging();
   // }
  }
  
  AddEngagementPersonnel(myobjstr: any) {
    this.archiveHomeService.AddEngagementPersonnels(myobjstr).subscribe(
      data => {
        if (data == true) {
          this.notifier.notify(
            "success",
            "Successfully added"
          );
        }
      },
      err => {
        console.log("error is ", err);
      }
    );
  }
  getPaginationMembers()
  {
    if (this.appendMembersGrid) {
      this.jumpToNextPage();
      this.appendMembersGrid=false;
    }
  else{
    this.getMembersFilterDataWithPaging();
  }
  }
  getMembers(showRemovePersonnelMessage: boolean = false,isfiltersearch: boolean = false) {
    // // debugger;
    this.archiveHomeService.GetPersonnelForWBSNumber(this.archiveNumber, this.wbsNumber).subscribe(
      (data: any) => {

        let systemGeneratedSubmissionsCreatedDates = (data.item2 && data.item2.length > 0) ? data.item2.filter(d1 => d1.isManualSubmission === 0).map(d2 => new Date(d2.createdDate)) : [];

        this.lastUpdatedSwiftDataOn = (systemGeneratedSubmissionsCreatedDates.length > 0)
          ? this.convertDatetoCST(new Date(Math.max.apply(null, systemGeneratedSubmissionsCreatedDates))) :
          null;
        if(!isfiltersearch)
        this.myMemberFilterData = this.myMemberMasterData = this.myMemberData = this.myMembers = data.item2 ? data.item2 : [];

        this.fillDataInFilterDropdowns();
        this.getMembersFilterDataWithPaging();

        if (showRemovePersonnelMessage) {
          this.notifier.notify('success', 'Member deleted successfully.');
        }

        this.initialDataLoaded = true;
        if (data.item1) {
          setTimeout(() => { this.notifier.notify("error", "Refreshing WBS details failed") }, 500);
        }
      },
      (error) => {
        setTimeout(() => { this.notifier.notify("error", "Refreshing WBS details failed") }, 500);
      });
  }
  getMembersFilterDataWithPaging() {
    this.totalMembers = this.myMembers && this.myMembers[0] ? this.myMembers[0]["count"] : 0;
    if (this.myMemberData && this.myMemberData.length > 0) {
     if(!this.appendMembersGrid)
      this.getMembersFilterData();
      this.calculatePageCount();
      this.getMembersData();
    }
    else {
      this.clearPageCount();
    }
  }

  getMembersFilterData() {
    
     // getMemberData
     this.myMembers = this.getAddMethodToMemberData(this.myMembers);

    // Employee name
    if (this.sortBy == 1) {
      this.myMembers = this.myMemberData.sort((a, b) => a.employeeName.localeCompare(b.employeeName));
    }
    else if (this.sortBy == 2) {
      this.myMembers = this.myMemberData.sort((a, b) => b.employeeName.localeCompare(a.employeeName));
    }

    // Office
    if (this.sortBy == 3) {
      this.myMembers = this.myMemberData.sort((a, b) => a.office.localeCompare(b.office));
    }
    else if (this.sortBy == 4) {
      this.myMembers = this.myMemberData.sort((a, b) => b.office.localeCompare(a.office));
    }

    // Business
    if (this.sortBy == 5) {
      this.myMembers = this.myMemberData.sort((a, b) => a.business.localeCompare(b.business));
    }
    else if (this.sortBy == 6) {
      this.myMembers = this.myMemberData.sort((a, b) => b.business.localeCompare(a.business));
    }

    // add method
    if (this.sortBy == 7) {
      this.myMembers = this.myMemberData.sort((a, b) => a.addMethod.localeCompare(b.addMethod));
    }
    else if (this.sortBy == 8) {
       this.myMembers = this.myMemberData.sort((a, b) => b.addMethod.localeCompare(a.addMethod));
    }

    // getMemberData
    this.myMembers = this.getColumnsToMemberData(this.myMembers);
  }

  getColumnsToMemberData(data: any) {
    var nCounter: number = 1;
    data.forEach(element => {
      element["rowNumber"] = nCounter;
      element["count"] = this.myMemberData.length;
      element["addMethod"] = element["isManualSubmission"] == 1 ? "Manually" : "From SWIFT";
      //element["addMethod"] = "From SWIFT";
      nCounter++;
    });
    return data;
  }

  getAddMethodToMemberData(data: any) {
    var nCounter: number = 1;
    data.forEach(element => {
      element["addMethod"] = element["isManualSubmission"] == 1 ? "Manually" : "From SWIFT";
      nCounter++;
    });
    return data;
  }

  getMembersData() {
    //getMemberData()
    if(this.appendMembersGrid)
    {
    this.myMembers =this.myMembers.concat(this.myMemberData.slice(this.displayingRecordsFrom - 1, this.displayingRecordsTo));
    }
    else
    {
    this.myMembers = this.myMemberData.slice(this.displayingRecordsFrom - 1, this.displayingRecordsTo);
    }

    //console.log(this.myMembers);
  }

 /* Checktheresubmissionreasons()
  {
    if(this.CurrentArchiveStatus=="Resubmitted - Ready for Approval")
    {
      this.archiveHomeService.GetResubmissionReasonsforArchive(this.archiveNumber).subscribe(data=>{
        debugger;
        if(data){
         if(data.length>0)
         {
          this.ERPEditedInResubmit=data[4].actionTypeId==3?true:false;
          this.ERPReasonsProvidedInResubmit=data[4].comments!=""?data[4].comments:"";
          if(this.ERPEditedInResubmit==true && this.ERPReasonsProvidedInResubmit=='')
          {
            this.modalservice.openWithCustomWidth("SaveChanges-AdministrativeResubmission-Modal", "544");
          }
          else{
            this.router.navigate(['/archive/myarchives/' + this.archiveNumber + '/archivehome']);
          }
        }
         
        }
      });
    }
    else
    {
      this.router.navigate(['/archive/myarchives/' + this.archiveNumber + '/archivehome']);
    }
  }*/

  showDeletePopup(event, name: any, index: any, deleteEmployeeAlias: string) {
    this.modalservice.openWithCustomWidth("deletePopUp", "525");
    this.popupname = name;
    this.popupindex = index;
    this.deleteEmployeeAlias = deleteEmployeeAlias;
    //console.log(name);
  }
  ShowEditedReasonPop(ActionType)
  { 
    debugger;
  // if(this.CurrentArchiveStatus=="Resubmitted – Open" || this.CurrentArchiveStatus=="Resubmitted - Ready for Approval")
  //  {
    // //Initial popup
    // if(Action==='SaveChanges-AdministrativeResubmission-Modal' && ActionType==='Add')
    //   {
    //     this.modalservice.close("addPersonnelPopup");
    //     this.modalservice.openWithCustomWidth("SaveChanges-AdministrativeResubmission-Modal", "544");
    //   }
    //  if(Action==='SaveChanges-DeleteMember-AdministrativeResubmission-Modal' && ActionType==='Delete')
    //   {
    //     this.closeDeletePopUp();
    //     this.modalservice.openWithCustomWidth("SaveChanges-DeleteMember-AdministrativeResubmission-Modal", "544");
    //   }
    // Upon click on Save & State changes button from above popup below popup will be called
    //  if(Action==='Reasons-Adminstrativeresubmission-modal' && ActionType==='DeleteReason')
    //   {
    //   this.removePersonnel();
    //   // this.OnApproveOrRejection("3");
    //   // this.modalservice.close("SaveChanges-DeleteMember-AdministrativeResubmission-Modal");
    //   // this.BodyCount = 250;
    //   // this.ResubmissionReasonForERPSection="";
    //   //this.modalservice.openWithCustomWidth("Reasons-Adminstrativeresubmission-modal", "544");
    //   }
    //   if(Action==='Reasons-Adminstrativeresubmission-modal' && ActionType==='AddReason')
    //   {
    //     this.addpersonel('addPersonnelPopup');
    //   //   this.OnApproveOrRejection("3");
    //   //   this.BodyCount = 250;
    //   //   this.ResubmissionReasonForERPSection="";
    //   //  this.modalservice.close("SaveChanges-AdministrativeResubmission-Modal");
    //    //this.modalservice.openWithCustomWidth("Reasons-Adminstrativeresubmission-modal", "544");
    //   }
    // }
   if(ActionType==='Add')
    {
      this.addpersonel('addPersonnelPopup');
    }
    else if(ActionType==='Delete'){
      this.resetpage();
       this.removePersonnel();
    }
  // }
}
  
  closeDeletePopUp() {
    this.modalservice.close("deletePopUp");
  }
  //This method is to save the ERP section reasons
  SaveERPSectionReasons()
  {
    var reasonparameters =
    {
      "ArchiveNumber": this.archiveNumber,
      "Comment":this.ResubmissionReasonForERPSection,
      "CreatedBy": '',
      "CommentCategoryId": 6,
    }
    this.archiveHomeService.SavereasonsForArchiveDetails(reasonparameters).subscribe(data=>{
        if(data==false)
        {
          this.notifier.notify("error", "Reasons are not saved successfully");
        }
        else{
          console.log("Engagement personnel Reasons are saved successfully");
          setTimeout(() => { this.router.navigate(["archive/myarchives/" + this.archiveNumber + '/archivehome']) }, 5000);

          // this.router.navigate(['/archive/myarchives/' + this.archiveNumber + '/archivehome']).then(() => {
          //   location.reload();
          // });
        }
    })
  }

  removePersonnel() {
    // // debugger;
    // var self = this;
    // this.myMembers.splice(this.popupindex,1);
    // this.closeDeletePopUp();
    let employeeUniqueIdentifier = this.adalSvc.LoggedInUserEmail.split('@')[0];
    let dateTimeObj = new Date();
    let strDateTimeNow = (dateTimeObj.getMonth() + 1) + '/' + dateTimeObj.getDate() + '/' + dateTimeObj.getFullYear();
    let requestParameters = {
      'ArchiveNumber': this.archiveNumber,
      'DeletedBy': '',
      'DeletedDate': strDateTimeNow,
      'EngagementPersonnel': this.deleteEmployeeAlias
    }
    this.archiveInfoService.removeEngagementPersonnel(requestParameters).subscribe(
      data => {
        //Dos something here
        // console.log(JSON.stringify(data));
        this.getMembers(true);
      });
    this.closeDeletePopUp();
  }

  toggle() {
    this.show = !this.show;
  }
  selectmethod() {
    this.methodvalue = this.methodvalue;
    this.filterarray.push(this.methodvalue);
    this.filtercheck = true;
  }
  selectoffice() {
    this.officevalue = this.officevalue;
    this.filterarray.push(this.officevalue);
    console.log(this.filterarray);
    console.log(this.filtercheck);
    this.filtercheck = true;
  }
  selectbusiness() {
    this.businessvalue = this.businessvalue;
    this.filterarray.push(this.businessvalue);
    console.log(this.businessvalue);
    this.filtercheck = true;
  }
  resetfilter() {
    if(this.pagination){
      this.pagination.updatePagination();
    }
    this.businessvalue = '';
    this.methodvalue = '';
    this.officevalue = '';
    this.filterarray = [];
    this.searchtextvalue = '';
    this.filtersRemoved();
    this.showEmptyResultTosterForFilter=true;
  }
  removeparam(event, searchparam: any, index: any) {
    this.paramindex = index;
    this.filterarray.splice(this.paramindex, 1);
    this.clearPageCount();
    this.filtersRemoved();
    
    if(this.pagination){
      this.pagination.updatePagination();
    }

    if (searchparam == this.officevalue)
      this.officevalue = '';
    if (searchparam == this.methodvalue)
      this.methodvalue = '';
    if (searchparam == this.businessvalue)
      this.businessvalue = '';
    this.showEmptyResultTosterForFilter = true;

  }
  convertext() {
    console.log(this.searchtextvalue.length);
    if (this.searchtextvalue.length >= 4) {
      console.log(this.searchtextvalue);
      this.filtercheck = true;
      this.filterarray.push(this.searchtextvalue);

      this.searchtextvalue = '';

    }
  }
  onKeydown(event) {
    if (event.key === "Enter") {
      if (this.searchtextvalue.length >= 3) {
        console.log(this.searchtextvalue);
        this.filtercheck = true;
        this.filterarray.push(this.searchtextvalue);

        this.searchtextvalue = '';

      }
      console.log(event);
    }
  }

  // Multi-Select  Compeonent


  updateSearch(e) {
    this.searchTerm = e.target.value
  }


  searchPersonel(searchText: string) {
    if (searchText.length < 3) {
      this.personels = [];
      this.filterCount = 0;
      this.selectAll = false;
      return;
    }
    this.dataService.getPersonel(searchText).subscribe((data: any[]) => {

      this.personels = data.filter(x => x.personnel !== "").map(emp => ({
        ...emp,
        active: false,
        company_html: this.highlight(emp.fullname, searchText
        )
      }));
      this.filterCount = this.personels.length;
    })
    this.SpinnerService.hide();
  }


  addpersonel(Action) {

    var personnelStr = "";
    for (var i = 0; i < this.selectedemps.length; i++) {
      personnelStr += this.selectedemps[i].personnel + ",";
    }

    personnelStr = personnelStr.substring(0, personnelStr.length - 1);

    var body = {
      "ArchiveNumber": this.archiveNumber,
      "IsManualSubmission": true,
      "CreatedBy": this.userAlias,
      "CreatedDate": new Date(),
      "Personnels": personnelStr
    }

    this.dataService.addPersonel(body).subscribe(response => {
      this.notifier.notify("success", "You have successfully added the selected user(s).");
      this.refreshSWIFTData();
    },
      err => {
        console.log("failed to add personels");
        this.notifier.notify("error", "Failed to add personnel");
      }

    );

    this.modalservice.close(Action);


  }



  highlight(value: string, args: string) {

    if (args && value) {
      value = String(value);
      args = args.replace(/[^a-zA-Z0-9]/g, '');
      if (args.length > 0) {
        const orginalVal = value.substr(value.toLowerCase().indexOf(args.toLowerCase()), args.length);
        const re = new RegExp(args, 'gi');
        return value.replace(re, "<mark>" + orginalVal + "</mark>");
      }
    }
    return value;
  }

  removeSelected(personnel) {    
    this.selectedemps = this.selectedemps.filter(e => e.personnel != personnel);
    const index = this.personels.findIndex(emp => personnel === emp.personnel);
    this.personels[index] = { ...this.personels[index], active: false };
    this.selectedMember = this.selectedemps.length;
    this.filterCount = this.personels.length;
  }



  checkboxSelected(e) {

    if (e.target.checked) {
      const emp = this.personels.find(emp => emp.personnel == e.target.value);
      var isPersonnelExist = this.selectedemps.find(x => x.personnel == emp.personnel);
      if (!isPersonnelExist && this.selectedemps.length < 50) {
        this.selectedemps = [...this.selectedemps, emp];
        this.selectedMember = this.selectedemps.length;
      }
      else if (this.selectedemps.length >= 50) {
        e.target.checked = false;
        this.notifier.notify("error", "Maximum 50 personnels can be selected.");
        return false;
      }
    }
    else {
      this.removeSelected(e.target.value);
    }
  }

  checkboxSelectedAll() {
    if (this.selectAll) {
      this.selectedemps = [...this.personels.slice(0, 50)];
      this.personels.slice(0, 50).forEach(e => e.active = true);
      this.selectedMember = this.selectedemps.length;
    }
    else {

      this.personels = this.personels.map(e => {
        e = { ...e, active: false };
        return e;
      });
      this.selectedemps = [];
      this.selectedMember = this.selectedemps.length;
    }
  }

  clearPersonnels() {
    this.selectedemps = [];
    this.selectedMember = 0;
    this.term = "";
    this.personels = [];
    this.selectAll = false;
    this.filterCount = 0;
  }

  // PopUp

  openAddPersonelModel() {
    this.clearPersonnels();
    this.modalservice.openWithCustomWidth('addPersonnelPopup', "725");
  }

  closeModalDialog(Action) {
    this.modalservice.close(Action);
    this.rejectionDiscrption = this.rejectionComments;
  }

  searchTextKeyUpEvent(event) {
    this.clearPageCount();
    //// debugger;  
    //console.log(event, event.keyCode, event.keyIdentifier);
    
    if(this.pagination){
      this.pagination.updatePagination();
    }

    if (event.charCode == 13) { //enterkey
      //add to filters array
      if (this.searchtextvalue.trim() != '') {
        this.myMemberFilterData = this.myMemberData;
        this.filterarray.push(this.searchtextvalue);
        this.searchtextvalue = '';
      }
      else {
        return false;
      }
    }
    else {
      if (event.key === 'Backspace') {
        this.filterList(false, this.searchtextvalue);
      }
      else {
        var searchText = this.searchtextvalue + event.key
        this.filterList(true, searchText);
      }
    }

  }
  filterList(isAddFilter: boolean, textToFilter: string, isCommitFilter: boolean = false, isfiltersearch:  boolean = false) {
  
    if (isAddFilter) {
      this.myMemberData = this.myMemberData.filter(item => {
        return (item["employeeName"].toLowerCase().includes(textToFilter.toLowerCase())
          || item["office"].toLowerCase().includes(textToFilter.toLowerCase())
          || item["business"].toLowerCase().includes(textToFilter.toLowerCase())
          || item["addMethod"].toLowerCase().includes(textToFilter.toLowerCase())
        );
      });

      if (isCommitFilter && this.filterarray) {
        this.myMemberFilterData = this.myMemberData;
        this.filterarray.push(textToFilter);
      }
    }
    else {
      this.myMemberData = this.myMemberFilterData.filter(item => {
        return (item["employeeName"].toLowerCase().includes(textToFilter.toLowerCase())
          || item["office"].toLowerCase().includes(textToFilter.toLowerCase())
          || item["business"].toLowerCase().includes(textToFilter.toLowerCase())
          || item["addMethod"].toLowerCase().includes(textToFilter.toLowerCase())
        );
      });
    }
   
    if (this.myMemberData.length == 0) {
      this.myMembers = this.myMemberData; 
      this.notifier.hideNewest();
      if (this.showEmptyResultTosterForFilter){
        this.notifier.notify("error", "No results found");
        this.showEmptyResultTosterForFilter = false;
      }
    }
    else {
      this.notifier.hideNewest();
      this.showEmptyResultTosterForFilter = true;
      if(isfiltersearch)
      this.getMembers(false,true);
      else
      this.getMembersFilterDataWithPaging();
    }
  }

  filtersRemoved() {
    this.myMemberFilterData = this.myMemberMasterData;
    this.myMembers = this.myMemberFilterData;
    this.myMemberData = this.myMemberFilterData;

    if (this.filterarray && this.filterarray.length > 0) {
      this.filterarray.forEach(textToFilter => {
        this.myMemberData = this.myMemberData.filter(item => {
          return (item["employeeName"].toLowerCase().includes(textToFilter.toLowerCase())
            || item["office"].toLowerCase().includes(textToFilter.toLowerCase())
            || item["business"].toLowerCase().includes(textToFilter.toLowerCase())
            || item["addMethod"].toLowerCase().includes(textToFilter.toLowerCase())
          );
        });
      });

      if (this.searchtextvalue.trim() != '') {
        this.myMemberData = this.myMemberData.filter(item => {
          return (item["employeeName"].toLowerCase().includes(this.searchtextvalue.toLowerCase())
            || item["office"].toLowerCase().includes(this.searchtextvalue.toLowerCase())
            || item["business"].toLowerCase().includes(this.searchtextvalue.toLowerCase())
            || item["addMethod"].toLowerCase().includes(this.searchtextvalue.toLowerCase())
          );
        });
      }
    }

    if (this.myMemberData.length == 0) {
      this.myMembers = this.myMemberData;
    }
    else {
      this.myMemberFilterData = this.myMemberData;
      this.getMembersFilterDataWithPaging();
    }
  }

  fillDataInFilterDropdowns() {
    if (this.myMemberMasterData && this.myMemberMasterData.length) {
      this.myMemberMasterData.forEach(x => {        
        let addMethodValue = x['isManualSubmission'] == 1 ? 'Manually' : 'From SWIFT';        

        if ((!this.officeDropdownData.includes(x['office'])) && (x['office'] != "")) {
          this.officeDropdownData.push(x['office']);
        }

        if ((!this.businessDropdownData.includes(x['business'])) && (x['business'] != "")) {
          this.businessDropdownData.push(x['business']);
        }

        if (!this.addMethodDropdownData.includes(addMethodValue)) {
          this.addMethodDropdownData.push(addMethodValue);
        }
      });

      if (this.officeDropdownData && this.officeDropdownData.length) {
        this.officeDropdownData = this.officeDropdownData.sort();
      }

      if (this.businessDropdownData && this.businessDropdownData.length) {
        this.businessDropdownData = this.businessDropdownData.sort();
      }
    }
  }

  // filterDropdownChanged(filterDropdownType : number){
  //   var searchText : string;

  //   if(filterDropdownType == 1){ //Office
  //     searchText = this.officevalue;
  //   }
  //   else if(filterDropdownType == 2){ //Business
  //     searchText = this.businessvalue;
  //   }
  //   else if(filterDropdownType == 3){ //Add method
  //     searchText = this.methodvalue;
  //   }
  //   this.filterarray.push(searchText);
  //   this.filterList(true, searchText);
  // }

  searchBtnClicked(event) {
    //// debugger;    
this.resetpage();
    if ((this.officevalue || this.businessvalue || this.methodvalue) && this.filterarray) {

      if (this.officevalue != '' && !this.filterarray.includes(this.officevalue)) {
        //this.filterarray.push(this.officevalue);
        this.filterList(true, this.officevalue, true,true);
      }

      if (this.businessvalue != '' && !this.filterarray.includes(this.businessvalue)) {
        //this.filterarray.push(this.businessvalue);
        this.filterList(true, this.businessvalue, true,true);
      }

      if (this.methodvalue != '' && !this.filterarray.includes(this.methodvalue)) {
        //this.filterarray.push(this.methodvalue);
        this.filterList(true, this.methodvalue, true,true);
      }
      this.toggle();
    }
    else {
      return false;
    }
    this.showEmptyResultTosterForFilter=true;
  }
  showModelDialog(Action? : any) {
    if (Action)
      this.popUpHeaderText = "Edit Engagement related personnel";
    else
      this.popUpHeaderText = "Reject Engagement related personnel";

    if ((Action === "Reject" && this.rejectionDiscrption != "") || Action === "Edit") {
      this.BodyCount = 250;
    }
    else if (Action === "Reject" && this.rejectionDiscrption == "") {
      this.rejectionDiscrption = "";
      this.BodyCount = 250;
    }
    this.modalservice.openWithCustomWidth("reject-engagement-modal", "500");

  }
  changedecisionbtnClick() {
    this.ApproveDisabled = false;
    this.showEdit = true;
    this.disabledColor = {
      'background': '#007CB0'
    };

    this.IsChangeDecissionClicked=true;
  }
  OnApproveOrRejection(ActionType) {
    var parameters =
    {
      "ArchiveNumber": this.archiveNumber,
      "ArchiveSectionId": this.sectionid,
      "ActionTypeId": ActionType,
      "Comments": this.rejectionDiscrption,
      "CreatedBy": ''
    }
    if (this.rejectionDiscrption !== undefined && this.stripHtml(this.rejectionDiscrption).length < 5 && ActionType == 2) {
      this.isRejectDiscrptionMin = true;
      this.isRejectDiscrptionMax = false;
    }
    if (this.rejectionDiscrption !== undefined && this.stripHtml(this.rejectionDiscrption).length > 250 && ActionType == 2) {
      this.isRejectDiscrptionMax = true;
      this.isRejectDiscrptionMin = false;
    }
    if (this.rejectionDiscrption === undefined && ActionType == 2 || this.rejectedCommentsPlainText == null && ActionType == 2) {
      this.notifier.notify("error", "Please write down the reason for Rejection");
    }
    else {
      this.isRejectDiscrptionMin = false;
      this.isRejectDiscrptionMax = false;
      var myobjstr = JSON.stringify(parameters);
      this.archiveHomeService.OnApproveOrRejection(myobjstr)
        .subscribe(data => {
          this.success = data;
          this.ApproveDisabled = true;
          if(!this.IsChangeDecissionClicked)
          {
          localStorage['IsSectionVisited'] = '1';
          console.log("LocalStorage Set to 1 in ERP for AR (1249):",localStorage['IsSectionVisited']);
          
          }
          // let CurrentURL = this.router.url;
          //  let urlList = CurrentURL.split("/");
          //  this.archiveNumber = urlList[urlList.length-2];
          if(ActionType!="3")
          {
              // this.router.navigate(['/archive/myarchives/' + this.archiveNumber + '/archivehome']).then(() => {
              //   location.reload();
              // });
              setTimeout(() => { this.router.navigate(["archive/myarchives/" + this.archiveNumber + '/archivehome']) }, 50);
              this.closeModalDialog('reject-engagement-modal');      
          }
        });
    }
  }

  rejectengagementpersonalRedirect() {
    if(!this.IsChangeDecissionClicked)
    {
    localStorage['IsSectionVisited'] = '1';
    }
    // this.router.navigate(["/archive/myarchives/" + this.archiveNumber + "/archivehome"]).then(() => {
    //   location.reload();
    // });

    setTimeout(() => { this.router.navigate(["archive/myarchives/" + this.archiveNumber + '/archivehome']) }, 5000);
  }

  stripHtml(html: string) {
    // Create a new div element
    var temporalDivElement = document.createElement("div");
    // Set the HTML content with the providen
    temporalDivElement.innerHTML = html;
    // Retrieve the text property of the element (cross-browser support)
    return temporalDivElement.textContent || temporalDivElement.innerText || "";
  }

  get rejectedCommentsPlainText(): string {
    return this.rejectionDiscrption ? this.stripHtml(this.rejectionDiscrption) : null;
  }
  onchangeBody(boxInput, e: any) {
    this.wordCount = this.stripHtml(boxInput).length;
    this.rejectionDiscrption = boxInput;
    if (this.rejectedCommentsPlainText && this.rejectedCommentsPlainText.length >= 250) {
      if (!(e.ctrlKey && (e.keyCode >= 65 || e.keyCode <= 90)) && (e.keyCode > 47 || e.keyCode == 32 || e.keyCode == 9 || e.keyCode == 13)) {
        event.preventDefault();
      }
    }
    else {
      if (this.rejectionDiscrption !== undefined && this.stripHtml(this.rejectionDiscrption).length < 5) {
        this.isRejectDiscrptionMin = true;
        this.isRejectDiscrptionMax = false;
      }
      else if (this.rejectionDiscrption !== undefined && this.stripHtml(this.rejectionDiscrption).length > 250) {
        this.isRejectDiscrptionMax = true;
        this.isRejectDiscrptionMin = false;
      }
      else {
        this.isRejectDiscrptionMax = false;
        this.isRejectDiscrptionMin = false;
      }
    }
  }
  Getsectioncomments(archiveNumber: any, sectionId: number,ActionTypeId: number) {
    this.archiveHomeService.Getsectioncomments(archiveNumber, sectionId,ActionTypeId)
      .subscribe(data => {
        this.rejectedb = data.rejectedBy;
        this.isSectionApproved = data.isSectionApproved;
        this.rejectedDate = data.rejectedDate;
        this.SetSection(data.comments);
      });
  }
  SetSection(comments) {
    // debugger;
    if (!this.isSectionApproved && comments) {
      this.isSectionRejected = true;
      this.isSectionApproved = false;
      this.rejectionDiscrption = comments;
      this.rejectionComments = comments;
      this.rejectedBy = this.rejectedb;
      this.ApproveDisabled = true;
      this.showEdit = false;
      this.disabledColor = {
        'background': '#959494',
        'color': '#1C1B1B'
      };
      this.topCss = {
        'top': '175px'
      }
    }
    else if (this.isSectionApproved && !(this.CurrentArchiveStatus=="Resubmitted - Ready for Approval")) {
      this.disabledColor = {
        'background': '#959494',
        'color': '#1C1B1B'
      };
      this.topCss = {
        'top': '175px'
      }
      this.isSectionRejected = false;
      if (this.isSectionApproved)
        this.isSectionApproved = true;
      this.showEdit = false;
      this.ApproveDisabled = true;
    }
    //Added for Resubmitted - Ready for Approval//
    else if (this.isSectionApproved && (this.CurrentArchiveStatus=="Resubmitted - Ready for Approval"))
    {
      this.isSectionRejected = false;
      this.isSectionApproved = false;
      if(this.canApprove){
        this.showEdit = true;
      this.ApproveDisabled = true;
      }
      else
      {
        this.showEdit = false;
      this.ApproveDisabled = false;
      }
    }
    //end of Resubmitted - Ready for Approval
    else
      this.ApproveDisabled = false;
  }

  private convertDatetoCST(date: Date, isLocalDate = false): Date | string {
    let time = date.getTime();
    let localOffset = date.getTimezoneOffset() * 60000;
    let utc = time + (isLocalDate ? localOffset : 0);
    let dateJan = new Date(date.getFullYear(), 0, 1);
    let dateJul = new Date(date.getFullYear(), 6, 1);
    let timezoneOffset = Math.max(dateJan.getTimezoneOffset(), dateJul.getTimezoneOffset());
    let offset = date.getTimezoneOffset() <  timezoneOffset ?  -5 : -6;
    let cst = utc + (3600000 * offset)
    let cstDate = this.formatDateString(new Date(cst));
    return cstDate;
  }

  private formatDateString(date: Date): string {
    let currentHours = date.getHours();
    let currentMonth = date.getMonth() + 1;
    let currentMonthString = ("0" + currentMonth).slice(-2);
    let currentDate = date.getDate();
    let currentDateString = ("0" + currentDate).slice(-2);
    let currentMinutes = date.getMinutes();
    let ampm = currentHours >= 12 ? 'PM' : 'AM';
    currentHours = currentHours % 12;
    currentHours = currentHours ? currentHours : 12;
    let currentHoursString = ("0" + currentHours).slice(-2);
    let currentMinutesString = ("0" + currentMinutes).slice(-2);
    return `${currentMonthString}/${currentDateString}/${date.getFullYear()}, ${currentHoursString}:${currentMinutesString} ${ampm} CST`;
  }
  onPaste(prevData: string, el): void {
    let clipboardData = el.clipboardData;
    let pastedText: string = clipboardData.getData('text');
    console.log(pastedText);
    let PastedTextCount = this.stripHtml(pastedText.trim()).length;
    if (PastedTextCount > 5)
      this.isRejectDiscrptionMin = false;
    let prevDataCount = prevData ? this.stripHtml(prevData).length : 0;
    pastedText = pastedText.substring(0, 250 - prevDataCount);
    let concatedText = (prevData + pastedText)
    if (prevDataCount >= 250) el.preventDefault();
    else if ((prevDataCount + PastedTextCount) > 250) {
      el.preventDefault();
      this.rejectionDiscrption = concatedText
    }
  }
 
  getfocus(){
    this.searchtab.nativeElement.focus();
  }

 updateGridData(event) {
    this.appendMembersGrid = event.isLoadMoreClicked;
    this.currentPageNumber = event.pageNumber;
    this.getPaginationMembers();
  }
  resetpage()
  {
    this.appendMembersGrid =false;
    this.currentPageNumber=1;
    this.totalMembers=0;
    this.showEmptyResultTosterForFilter=true;
  }
}

export enum MyMembersSortBy {
  SortBy_EmployeeName_Asc = 1,
  SortBy_EmployeeName_Desc = 2,
  SortBy_Office_Asc = 3,
  SortBy_Office_Desc = 4,
  SortBy_Business_Asc = 5,
  SortBy_Business_Desc = 6
}

export enum MyMembersColumnBy {
  ColumnBy_Default = -1,
  ColumnBy_EmployeeName = 1,
  ColumnBy_Office = 2,
  ColumnBy_Business = 3,
  ColumnBy_AddMethod = 4,
}

