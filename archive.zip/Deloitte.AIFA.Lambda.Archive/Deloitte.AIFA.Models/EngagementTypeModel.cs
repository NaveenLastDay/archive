﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.Models
{
    public class EngagementTypeModel
    {
        public int EngagementTypeId { get; set; }

        public string EngagementTypeDescription { get; set; }
        

    }
}
