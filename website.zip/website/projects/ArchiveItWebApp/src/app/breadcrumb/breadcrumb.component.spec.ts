/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { BreadcrumbComponent } from './breadcrumb.component';

describe('Component: Breadcrumb', () => {
  it('should create an instance', () => {
    let component = new BreadcrumbComponent();
    expect(component).toBeTruthy();
  });
});
