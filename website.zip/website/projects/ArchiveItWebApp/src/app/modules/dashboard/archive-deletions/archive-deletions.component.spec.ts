import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ArchiveDeletionsComponent } from './archive-deletions.component';

describe('ArchiveDeletionsComponent', () => {
  let component: ArchiveDeletionsComponent;
  let fixture: ComponentFixture<ArchiveDeletionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ArchiveDeletionsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ArchiveDeletionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
