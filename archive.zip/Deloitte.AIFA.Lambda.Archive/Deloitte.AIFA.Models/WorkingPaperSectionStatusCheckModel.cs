﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DataModels
{
    public class WorkingPaperSectionStatusCheckModel
    {
        public string wkpdescription { get; set; }
        public string createdBy { get; set; }
    }
}
