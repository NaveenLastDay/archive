﻿using Deloitte.AIFA.DomainEntities;
using Deloitte.AIFA.DomainEntities.EmailEntities;
using Deloitte.AIFA.EmailNotificationServices.NotificationEntities;
using Deloitte.AIFA.EmailNotificationServices.NotificationServices.Interfaces;
using Deloitte.AIFA.IRepositories;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.EmailNotificationServices.NotificationServices.Services
{
    public class ArchiveDeletionNotification : IArchiveDeletionNotification
    {
        IUserRepository _userRepository;
        ILogger _logger;        
       
        public ArchiveDeletionNotification(                              
                                )        {
           
        }
     
        public BaseEmailEntity ArchiveDeletionRequest_Notification(string argOperationType, string argOperationDescription, string argTemplateId, string ArchiveNumber,string AMName, string APName)
        {
            BaseEmailEntity objTAR = new BaseEmailEntity();
            //Build Tag Values
            objTAR.MinimumTagValues = new Dictionary<string, string>();
            //ArchiveNumber for Subject
            objTAR.MinimumTagValues.Add(EmailPlaceholders.ArchiveNumber, ArchiveNumber);
            //Requestor Name for Body
          
            objTAR.MinimumTagValues.Add(EmailPlaceholders.RequestorFirstName, APName);
            //Requestee Name for Body

            objTAR.MinimumTagValues.Add(EmailPlaceholders.RequesteeFirstName, AMName);


            //Hyperlink to Access for Body
            objTAR.MinimumTagValues.Add(EmailPlaceholders.GrantDenyLink, "GrantDenyLink");

           
            objTAR.TemplateId = argTemplateId;
            objTAR.OperationDescription = argOperationDescription;
            objTAR.OperationType = argOperationType;

            return objTAR;
        }

        public BaseEmailEntity ArchiveDeletionRequest_ApproveNotification(string argOperationType, string argOperationDescription, string argTemplateId, string ArchiveNumber, string AMName, string APName)
        {
            BaseEmailEntity objTAR = new BaseEmailEntity();
            //Build Tag Values
            objTAR.MinimumTagValues = new Dictionary<string, string>();
            //ArchiveNumber for Subject
            objTAR.MinimumTagValues.Add(EmailPlaceholders.ArchiveNumber, ArchiveNumber);
           
            //Requestor Name for Body

            objTAR.MinimumTagValues.Add(EmailPlaceholders.RequestorFirstName, APName);
            //Requestee Name for Body

            objTAR.MinimumTagValues.Add(EmailPlaceholders.RequesteeFirstName, AMName);


            //Hyperlink to Access for Body
            objTAR.MinimumTagValues.Add(EmailPlaceholders.GrantDenyLink, "GrantDenyLink");


            objTAR.TemplateId = argTemplateId;
            objTAR.OperationDescription = argOperationDescription;
            objTAR.OperationType = argOperationType;

            return objTAR;
        }

        public BaseEmailEntity ArchiveDeletionRequest_RejectNotification(string argOperationType, string argOperationDescription, string argTemplateId, string ArchiveNumber, string AMName, string APName)
        {
            BaseEmailEntity objTAR = new BaseEmailEntity();
            //Build Tag Values
            objTAR.MinimumTagValues = new Dictionary<string, string>();
            //ArchiveNumber for Subject
            objTAR.MinimumTagValues.Add(EmailPlaceholders.ArchiveNumber, ArchiveNumber);

            //Requestor Name for Body

            objTAR.MinimumTagValues.Add(EmailPlaceholders.RequestorFirstName, APName);
            //Requestee Name for Body

            objTAR.MinimumTagValues.Add(EmailPlaceholders.RequesteeFirstName, AMName);


            //Hyperlink to Access for Body
            objTAR.MinimumTagValues.Add(EmailPlaceholders.GrantDenyLink, "GrantDenyLink");


            objTAR.TemplateId = argTemplateId;
            objTAR.OperationDescription = argOperationDescription;
            objTAR.OperationType = argOperationType;

            return objTAR;
        }

    }
}
