﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DataModels
{
    public class MemoModel
    {
        public string FileName { get; set; }
        public int FileSize { get; set; }
        public string CreatedBy { get; set; }
        public string ArchiveNumber { get; set; }
        public string ETag { get; set; }
        public int FileTypeID { get; set; }
        public int FileVerificationStatusID { get; set; }
        public string FileVerificationStatusDescription { get; set; }
        public string S3FileNameOut { get; set; }
        public int? ArchiveFileIdOut { get; set; }
        public int? FileTransferIdOut { get; set; }
        public string ResponseMessageOut { get; set; }

    }
}
