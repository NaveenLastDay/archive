import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { NotifierService } from 'angular-notifier';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { NgxSpinnerService } from 'ngx-spinner';
import { UserConfigSettingService } from '../../../guards/user-role-guard.service';
import { UserActions } from '../../../models/archive-role.model';
import { ArchiveHomeService } from '../../../services/archive-home.service';
import { ArchiveService } from '../../../services/archive.service';
import { PubsubService } from '../../../services/pubsub.service';
import { ModalService } from '../../shared/modal';

@Component({
  selector: 'app-delete-archive',
  templateUrl: './delete-archive.component.html',
  styleUrls: ['./delete-archive.component.css']
})
export class DeleteArchiveComponent implements OnInit {
  userEmail = this.adalSvc.LoggedInUserEmail;
  euserAlias = this.userEmail.replace("@deloitte.com", "");
  deletionReason: string = "";
  DeleteRejectReason: string = "";
  WBSInfo: any;
  selectedWBSNumber: string;
  archiveDeletion_form: FormGroup;
  selectedArchiveNumber: string;
  archiveDeleteRequestInfo: any;
  roleMapping = new UserActions();
  roleId: any;
  roleDescription: any;
  isArchiveDeleteHistory: boolean;
  showOrHideContent: boolean;
  clientName: string;
  WBSNumber: string;
  WBSName: string;
  userConfig: any;
  omniaLinked: boolean;
  ispartnercanviewtextarea: boolean;
  isarchivecompleted: boolean;
  Recordexists: boolean;
  HoldApplied: boolean;
  past45days: boolean;
  username: string;
  createdbyusername: string;
  archivedeletionstatus: any;
  Archivename: any;
  omniaholdpast45daysrecordexists: boolean;
  omniaholdpast45days: boolean;
  holdpast45daysrecordexists: boolean;
  HoldAppliedrecordexists: boolean;
  omniapast45days: boolean;
  omniarecordexists: boolean;
  holdpast45days: boolean;
  omniahold: boolean;
  omniaholdrecordexists: boolean;
  validationexists: boolean;
  isactiveaction: boolean;
  constructor(private router: Router, private archiveHomeService: ArchiveHomeService,private activatedRoute: ActivatedRoute, private adalSvc: MsAdalAngular6Service,private notifier: NotifierService, private _userConfig: UserConfigSettingService,private modalService: ModalService, private pubsub: PubsubService, private service: ArchiveService, public formObject: FormBuilder, private SpinnerService: NgxSpinnerService) {
    this.archiveDeletion_form = formObject.group({
      'inputDeleteReason': ['', Validators.compose([Validators.required, Validators.minLength(5)])]
    });
  }

  ngOnInit() {
    this.userConfig = this._userConfig.FetchLoggedInUser(this.euserAlias);
    this.username = this.userConfig.value.lastName + ', ' + this.userConfig.value.firstName;
    console.log("username is" + this.username);
   // this.SpinnerService.show();
    this.selectedArchiveNumber = this.activatedRoute.snapshot.parent.params.aN;
    this.archiveHomeService.SyncForm3283SStatus(this.selectedArchiveNumber);
    this.selectedWBSNumber = localStorage.getItem('WBS_Number');
    this.getwbsinfo(this.selectedWBSNumber);
    this.service.GetDeleteArchiveRequestStatus(this.selectedArchiveNumber).subscribe(data => {
      this.archiveDeleteRequestInfo = data;
      this.isarchivecompleted = this.archiveDeleteRequestInfo[0].isArchiveCompleted;
      this.Archivename = this.archiveDeleteRequestInfo[0].archiveName;
      this.isactiveaction = this.archiveDeleteRequestInfo[0].isActiveAction;
      if(this.archiveDeleteRequestInfo.length != 0){
      this.createdbyusername = this.archiveDeleteRequestInfo[0].createdBy;
      this.archivedeletionstatus = this.archiveDeleteRequestInfo[0].archiveDeletionActionStatus;
    }
      console.log("createdby username is"+this.createdbyusername);
     
      if (this.archiveDeleteRequestInfo[0].response == "latepast45days") {
        this.showOrHideContent = true;
        this.past45days = true;
        this.validationexists = true;
      }
      else if (this.archiveDeleteRequestInfo[0].response == "RecordExists") {
        this.showOrHideContent = true;
        this.Recordexists = true;
        this.validationexists = true;
      }
      else if (this.archiveDeleteRequestInfo[0].response == "Omnialinked") {
        this.showOrHideContent = true;
        this.omniaLinked = true;
        this.validationexists = true;
      }
      else if (this.archiveDeleteRequestInfo[0].response == "HoldAppliedrecordexists") {
        this.showOrHideContent = true;
        this.HoldAppliedrecordexists = true;
        this.validationexists = true;
      }
      else if (this.archiveDeleteRequestInfo[0].response == "omniapast45days") {
        this.showOrHideContent = true;
        this.omniapast45days = true;
        this.validationexists = true;
      }
      else if (this.archiveDeleteRequestInfo[0].response == "omniarecordexists") {
        this.showOrHideContent = true;
        this.omniarecordexists = true;
        this.validationexists = true;
      }
      else if (this.archiveDeleteRequestInfo[0].response == "omniahold") {
        this.showOrHideContent = true;
        this.omniahold = true;
        this.validationexists = true;
      }
      else if (this.archiveDeleteRequestInfo[0].response == "omniaholdrecordexists") {
        this.showOrHideContent = true;
        this.omniaholdrecordexists = true;
        this.validationexists = true;
      }
      else if(this.archiveDeleteRequestInfo[0].response == "holdpast45daysrecordexists"){
        this.showOrHideContent = true;
        this.holdpast45daysrecordexists = true;
        this.validationexists = true;
      }
      else if(this.archiveDeleteRequestInfo[0].response == "omniaholdpast45days"){
        this.showOrHideContent = true;
        this.omniaholdpast45days = true;
        this.validationexists = true;
      }
      else if(this.archiveDeleteRequestInfo[0].response == "omniaholdpast45daysrecordexists"){
        this.showOrHideContent = true;
        this.omniaholdpast45daysrecordexists = true;
        this.validationexists = true;
      }
      else {
      if (this.archiveDeleteRequestInfo.length == 1 && this.archiveDeleteRequestInfo[0].archiveDeletionActionStatus == "")
      {
        this.isArchiveDeleteHistory = false;
      }
      else 
      {
        this.isArchiveDeleteHistory = true;
      }
      this.showOrHideContent = this.archiveDeleteRequestInfo.some(action => action.isActiveAction == true);
      if (this.archiveDeleteRequestInfo[0].archiveDeletionActionStatus == 'Rejected'){
        this.ispartnercanviewtextarea = true;
      }
      setTimeout(()=>this.SpinnerService.hide(),2000);
    }
    });
  }
  ngDoCheck() {
    this.roleMapping = this.pubsub.getRoleMappingResult();
    this.roleId = this.roleMapping.roleId;
    this.roleDescription = this.roleMapping.roleDescription;
  }

  getwbsinfo(WBSNumber: string) {
   // this.SpinnerService.show();
    this.service.getwbsdetails(WBSNumber).subscribe(
      (data) => {
        this.WBSInfo = data;
        this.clientName = this.WBSInfo.clientName;
        this.WBSNumber = this.WBSInfo.wbsLevelOne;
        this.WBSName = this.WBSInfo.wbsLevelOneDescription;
        //this.SpinnerService.hide();
      },
      (err) => {
        console.log("error is ", err)
      });
  }
  SubmitDeleteRequest(actionTypeId: string) {
    this.markFormTouched(this.archiveDeletion_form);
    if (this.archiveDeletion_form.valid && actionTypeId == '1' || actionTypeId == '2' || actionTypeId == '3' || actionTypeId == '4' || actionTypeId == '5') {
      //this.SpinnerService.show();
      var parameters = {
        "ArchiveNumber": this.selectedArchiveNumber,
        "DeleteReason": this.deletionReason,
        "RejectionReason": this.DeleteRejectReason,
        "ActionTypeID": actionTypeId
      }
      /*var myobjstr = JSON.stringify(parameters);*/
      this.service.DeleteArchive(parameters).subscribe(data => {
        let success = data;
        console.log(success);
        if (success == "Unable to proceed your request.") {
          this.notifier.notify("error", "Unable to proceed your request.");
          this.router.navigate(["/archive/myarchives/"+ this.selectedArchiveNumber]).then(() => {
          location.reload();
          });
        } 
        else {
          this.router.navigate(["/"]);
        }
        //this.SpinnerService.hide();
      });
    }
  }

  showDeletePopup() {
    this.modalService.openWithCustomWidth("deletePopUp", "480");
  }

  closeDeletePopUp() {
    this.modalService.close("deletePopUp");
  }

  markFormTouched(group: FormGroup | FormArray) {
    Object.keys(group.controls).forEach((key: string) => {
      const control = group.controls[key];
      if (control instanceof FormGroup || control instanceof FormArray) { control.markAsTouched(); this.markFormTouched(control); }
      else { control.markAsTouched(); };
    });
  };
  openModalDialog() {
    this.modalService.openWithCustomWidth('Reject-DeleteRequest-Modal', '600');
  }
  closeModalDialog() {
    this.DeleteRejectReason = "";
    this.modalService.close('Reject-DeleteRequest-Modal');
  }
  showCancelRequestPopup() {
    this.modalService.openWithCustomWidth("cancelRequestPopup", "480");
  }
  closeCancelRequestPopUp() {
    this.modalService.close("cancelRequestPopup");
  }
}
