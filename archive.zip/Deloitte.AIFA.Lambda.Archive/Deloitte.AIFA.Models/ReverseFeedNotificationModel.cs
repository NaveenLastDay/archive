﻿using Deloitte.AIFA.Common;
using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DataModels
{
    public class ReverseFeedNotificationModel
    {
        public ReverseFeedNotificationModel()
        {
            Source = new Source();
        }

        public string Action => Constants.Action;
        public Issuer Issuer => new Issuer();
        public Source Source { get; private set; }
    }

    public class Issuer
    {
        public string App => Constants.App;
        public string Country => Constants.Country;
    }

    public class Source
    {
        public Source()
        {
            ROINumbers = new List<string>();
        }
        public IList<string> ROINumbers { get; set; }
    }
}
