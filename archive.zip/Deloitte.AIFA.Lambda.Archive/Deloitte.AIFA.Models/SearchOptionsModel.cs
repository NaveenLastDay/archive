﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DataModels
{
   public class SearchOptionsModel
    {
        public long ItemId { get; set; } 
        public string ItemName { get; set; }
    }
}
