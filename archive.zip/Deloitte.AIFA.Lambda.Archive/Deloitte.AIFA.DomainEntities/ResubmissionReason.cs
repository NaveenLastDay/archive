﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
    public class ResubmissionReason
    {
        public int ResubmissionReasonID { get; set; }
        public string Description { get; set; }
    }
}
