﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.Lambda.AutoArchiveCreation.Entities
{
    public class AutoCreateArchive
	{
        public string ArchiveNumber { get; set; }
        public string WBSLevelOneNumber { get; set; }
        public string ClientName { get; set; }
        public string EstimatedDate { get; set; }
        public string ArchivePartnerName { get; set; }
        public string ArchivePartnerAlias { get; set; }
        public string ArchiveManagerAlias { get; set; }
        public string ArchiveManagerName { get; set; }
        public string IsArchiveCompleted { get; set; }
    }
}
