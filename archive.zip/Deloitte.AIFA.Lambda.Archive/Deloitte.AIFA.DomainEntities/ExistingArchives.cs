﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainEntities
{
    public class ExistingArchives:ArchiveInfo
    {
        public string ArchiveNumber { get; set; }
        public string Description { get; set; }
        public DateTime PeriodEndDate { get; set; }
        public string EngagementDescription { get; set; }
        public string ClientName { get; set; }
        public string WBSLevelOne { get; set; }
        public string WBSLevelOneName { get; set; }
        public int WBSLevelStatus { get; set; }

        public int IsAccessible { get; set; }
        public int RowNumber { get; set; }
        public int count { get; set; }
    }
}
