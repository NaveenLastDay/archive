﻿using Deloitte.AIFA.DomainEntities;
using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DomainServices.Contracts
{
    public interface IERPService
    {
        (bool, List<EngagementPersonnelInfo>)GetPersonnelForWBSNumber(string wbsNumber, string ArchiveNumber);

        List<ERPDetails> GetERPDetails(string searchquery);
        DistributionList RemoveEngagementPersonnel(DistributionList distributionList);
        DistributionList AddEngagementPersonnels(DistributionList distributionList);
    }
}
