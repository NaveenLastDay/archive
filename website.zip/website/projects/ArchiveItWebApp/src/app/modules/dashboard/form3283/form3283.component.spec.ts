import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Form3283Component } from './form3283.component';

describe('Form3283Component', () => {
  let component: Form3283Component;
  let fixture: ComponentFixture<Form3283Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Form3283Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Form3283Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
