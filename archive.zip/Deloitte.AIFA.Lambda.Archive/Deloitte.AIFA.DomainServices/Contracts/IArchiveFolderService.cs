﻿using Deloitte.AIFA.DomainEntities;
using System.Collections.Generic;

namespace Deloitte.AIFA.DomainServices.Contracts
{
    public interface IArchiveFolderService
    {
        List<ArchiveFolder> GetArchiveFolders(ArchiveFolder archiveFolder);
    }
}
