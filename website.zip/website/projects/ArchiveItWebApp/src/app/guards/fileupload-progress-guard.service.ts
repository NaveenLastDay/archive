import { CanDeactivate, ActivatedRoute } from "@angular/router";
import { Injectable } from "@angular/core";
import { FileuploadProgressComponent } from "../modules/record/fileUpload-progress/fileupload-progress.component";
import { FileUploadEventService } from '../modules/record/file-upload/fileupload.event.service';
import { WorkingPaperComponent } from '../modules/record/working-paper/working-paper.component';
import { Observable } from 'rxjs';
import { ModalService } from '../modules/shared/modal';
import { FileUploadProcessService } from '../modules/record/file-upload/fileupload.process.service';
import { FielUploadService } from '../services/fileupload.service';
import { NgxSpinnerService } from 'ngx-spinner';

@Injectable()
export class FileuploadProgressGuard
  implements CanDeactivate<WorkingPaperComponent> {
  constructor(
    private _fuService: FielUploadService,
    private _fuEventService: FileUploadEventService,
    private _spinnerService: NgxSpinnerService,
    private modalService: ModalService,
    private _activatedRoute: ActivatedRoute) { }

  result: boolean = false;
  canDeactivate(
    workingPapercomponent: WorkingPaperComponent
  ): boolean | Observable<boolean> | Promise<boolean> {

   /* var filearray = this._fuEventService.fileArray.filter(x => x.uploadStatus != "add");
    var filearraystarted = this._fuEventService.fileArray.filter(x => x.uploadStatus == "started");

    if (filearray && filearray.length > 0) {

      if (filearraystarted && filearraystarted.length > 0) {
        this._fuEventService.onNotifyUploadProgress(true);
        return this._fuEventService.navigateAwaySelection$;
      }
      else {
        this._fuEventService.onNotifyUploadProgress(false);
        return true;
      }

    }
    else {
      return true;
    }
*/
  return true;
  }  
}
