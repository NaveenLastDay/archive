﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace Deloitte.AIFA.DomainEntities.Enums
{
    public enum Role
    {
        [Description("Archive Partner")]
        ArchivePartner = 5,
        [Description("Archive Manager")]
        ArchiveManager = 6,
        [Description("Archive Filed Senior")]
        ArchiveFieldSenior = 7,
        [Description("PPD")]
        PPD = 11,
        [Description("Admin")]
        Admin = 15
    }
}
