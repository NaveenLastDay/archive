import { TestBed } from '@angular/core/testing';

import { EmspackagesService } from './emspackages.service';

describe('EmspackagesService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: EmspackagesService = TestBed.get(EmspackagesService);
    expect(service).toBeTruthy();
  });
});
