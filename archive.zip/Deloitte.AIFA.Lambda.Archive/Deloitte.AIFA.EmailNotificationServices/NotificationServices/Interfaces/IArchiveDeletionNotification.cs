﻿using Deloitte.AIFA.DomainEntities;
using Deloitte.AIFA.DomainEntities.EmailEntities;
using Deloitte.AIFA.EmailNotificationServices.NotificationEntities;
using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.EmailNotificationServices.NotificationServices.Interfaces
{
    interface IArchiveDeletionNotification
    {
        BaseEmailEntity ArchiveDeletionRequest_Notification(string argOperationType, string argOperationDescription, string argTemplateId, string ArchiveNumber, string AMName, string APName);

        BaseEmailEntity ArchiveDeletionRequest_ApproveNotification(string argOperationType, string argOperationDescription, string argTemplateId, string ArchiveNumber, string AMName, string APName);

        BaseEmailEntity ArchiveDeletionRequest_RejectNotification(string argOperationType, string argOperationDescription, string argTemplateId, string ArchiveNumber, string AMName, string APName);


    }
}
