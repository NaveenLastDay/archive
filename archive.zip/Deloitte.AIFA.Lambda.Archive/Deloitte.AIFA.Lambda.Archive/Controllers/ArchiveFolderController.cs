﻿using Deloitte.AIFA.DomainEntities;
using Deloitte.AIFA.DomainServices.Contracts;
using Microsoft.AspNetCore.Mvc;
using MySqlConnector;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading;

namespace Deloitte.AIFA.Lambda.Archive.Controllers
{
    [Route("api/archivefolder")]
    [ApiController]
    public class ArchiveFolderController : ControllerBase
    {
        IArchiveFolderService _archiveFolderService;
        ILogger _logger { get; set; }
        public ArchiveFolderController(IArchiveFolderService archiveFolderServie, ILogger<ArchiveFolderController> logger)
        {
            _logger = logger;
            _archiveFolderService = archiveFolderServie;

            _logger.LogInformation("Archive Folder Controller Initiated");
        }

        [HttpPost]
        [Route("")]
        public IActionResult GetArchiveFolders([FromBody] ArchiveFolder archiveFolder)
        {
           // List<ArchiveFolder> afs = new List<ArchiveFolder>();

            //try
           // {

                //    SqlConnection con = new SqlConnection("data source=archiveitforaudit.chnorvdum0zk.us-east-1.rds.amazonaws.com,1433;  persist security info=True; Initial Catalog =ArchiveItForAudit; integrated security=false;Uid=ArchiveIT_Audit;Pwd=9Kru2xH4;");
                //    SqlCommand cmd = new SqlCommand("pub_GetArchiveFolders", con);
                //    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                //    cmd.Parameters.AddWithValue("@ArchiveId", archiveFolder.ArchiveId);
                //    cmd.Parameters.AddWithValue("@ArchiveFolderId", archiveFolder.ArchiveFolderId);
                //    con.Open();
                //    var dr = cmd.ExecuteReader();

                //    while (dr.Read())
                //    {
                //        afs.Add(new ArchiveFolder()
                //        {
                //            ArchiveFolderName = dr["ArchiveFolderName"].ToString()
                //        });
                //    }
                //    con.Close();
                //}
                //catch (System.Exception ex)
                //{
                //    return Ok(ex.StackTrace.ToString());
                //}
                //return Ok(1);


                var archiveFolders = _archiveFolderService.GetArchiveFolders(archiveFolder);
                 _logger.LogInformation("GetArchiveFolders: ArchiveId: " + archiveFolder.ArchiveId + "ParentFolderId: " + archiveFolder.ArchiveFolderId);
                return Ok(archiveFolders);
            }
    }
}