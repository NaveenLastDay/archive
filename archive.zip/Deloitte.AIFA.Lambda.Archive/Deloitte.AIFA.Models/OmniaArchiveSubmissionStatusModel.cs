﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deloitte.AIFA.DataModels
{
    public class OmniaArchiveSubmissionStatusModel
    { 
        public bool IsAllowed { get; set; }
    }
}
